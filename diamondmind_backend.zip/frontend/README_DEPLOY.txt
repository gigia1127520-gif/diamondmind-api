DiamondMind 前端快照 V18.14.4

此資料夾只供版本同步與測試，Render 後端不會讀取它。
正式前端請將 index.html 單獨覆蓋到 diamondmind-web GitHub Pages 儲存庫根目錄。
不要新增 admin.html，也不要新增 assets 資料夾；保留前端儲存庫原本的圖示、manifest 與其他圖片。
