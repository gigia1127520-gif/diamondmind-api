-- DiamondMind V18.11.0
-- One-time Supabase migration: allow one public free pick per league and date.
-- Run this entire file once in Supabase > SQL Editor before deploying V18.11.0.

begin;

alter table public.recommendations
  add column if not exists league text;

update public.recommendations
set league = upper(
  coalesce(
    nullif(league, ''),
    nullif(prediction_snapshot ->> 'league', ''),
    nullif(prediction_snapshot -> 'publication' ->> 'league', ''),
    'MLB'
  )
);

-- Protect legacy or malformed rows before applying the league constraint.
update public.recommendations
set league = 'MLB'
where league not in ('MLB', 'NPB');

alter table public.recommendations
  alter column league set default 'MLB',
  alter column league set not null;

-- Older DiamondMind schemas used recommendation_date as the only unique key.
-- Drop any one-column UNIQUE constraint on that field, regardless of its name.
do $$
declare
  constraint_name text;
begin
  for constraint_name in
    select constraint_row.conname
    from pg_constraint as constraint_row
    join pg_class as table_row on table_row.oid = constraint_row.conrelid
    join pg_namespace as schema_row on schema_row.oid = table_row.relnamespace
    where schema_row.nspname = 'public'
      and table_row.relname = 'recommendations'
      and constraint_row.contype = 'u'
      and cardinality(constraint_row.conkey) = 1
      and (
        select attribute_row.attname
        from pg_attribute as attribute_row
        where attribute_row.attrelid = constraint_row.conrelid
          and attribute_row.attnum = constraint_row.conkey[1]
      ) = 'recommendation_date'
  loop
    execute format(
      'alter table public.recommendations drop constraint %I',
      constraint_name
    );
  end loop;
end
$$;

-- Cover a legacy manually-created unique index that was not backed by a
-- constraint. Constraint-owned indexes were already removed above.
do $$
declare
  index_name text;
begin
  for index_name in
    select index_row.relname
    from pg_index as index_meta
    join pg_class as index_row on index_row.oid = index_meta.indexrelid
    join pg_class as table_row on table_row.oid = index_meta.indrelid
    join pg_namespace as schema_row on schema_row.oid = table_row.relnamespace
    where schema_row.nspname = 'public'
      and table_row.relname = 'recommendations'
      and index_meta.indisunique
      and not index_meta.indisprimary
      and index_meta.indnkeyatts = 1
      and pg_get_indexdef(index_meta.indexrelid) ~* '\(recommendation_date\)(\s+where.*)?$'
      and not exists (
        select 1
        from pg_constraint as constraint_row
        where constraint_row.conindid = index_meta.indexrelid
      )
  loop
    execute format('drop index public.%I', index_name);
  end loop;
end
$$;

do $$
begin
  if not exists (
    select 1
    from pg_constraint
    where conrelid = 'public.recommendations'::regclass
      and conname = 'recommendations_recommendation_date_league_key'
  ) then
    alter table public.recommendations
      add constraint recommendations_recommendation_date_league_key
      unique (recommendation_date, league);
  end if;

  if not exists (
    select 1
    from pg_constraint
    where conrelid = 'public.recommendations'::regclass
      and conname = 'recommendations_league_check'
  ) then
    alter table public.recommendations
      add constraint recommendations_league_check
      check (league in ('MLB', 'NPB'));
  end if;
end
$$;

create index if not exists recommendations_league_date_status_idx
  on public.recommendations (league, recommendation_date desc, status);

commit;

-- Expected result after this migration:
-- one row for MLB and one row for NPB may share the same recommendation_date.
select recommendation_date, league, count(*) as rows_per_league
from public.recommendations
group by recommendation_date, league
order by recommendation_date desc, league;
