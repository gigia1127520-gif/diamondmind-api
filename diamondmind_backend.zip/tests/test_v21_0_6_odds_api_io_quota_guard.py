from __future__ import annotations

from datetime import date, datetime, timedelta, timezone

import httpx
import pytest

from app.config import Settings
from app.odds_api_io import OddsApiIoService, OddsApiIoUpstreamError


def settings_for(tmp_path, **overrides):
    values = {
        "odds_api_io_key": "test-key",
        "odds_api_io_daily_limit": 10,
        "odds_api_io_daily_soft_limit": 2,
        "odds_api_io_hourly_limit": 10,
        "odds_api_io_hourly_soft_limit": 2,
        "odds_api_io_quota_ledger_path": str(tmp_path / "quota.json"),
        "odds_api_io_cache_ttl_seconds": 900,
        "odds_api_io_events_cache_ttl_seconds": 900,
        "odds_api_io_metadata_cache_ttl_seconds": 21600,
        "odds_api_io_stale_ttl_seconds": 86400,
    }
    values.update(overrides)
    return Settings(**values)


@pytest.mark.asyncio
async def test_standard_requests_stop_at_soft_limit_but_priority_can_use_reserve(tmp_path):
    calls = []

    def handler(request: httpx.Request) -> httpx.Response:
        calls.append(str(request.url))
        return httpx.Response(200, json={"ok": True}, request=request)

    service = OddsApiIoService(settings_for(tmp_path), transport=httpx.MockTransport(handler))
    try:
        await service._get_json("events", {"apiKey": "test-key", "request": 1})
        await service._get_json("events", {"apiKey": "test-key", "request": 2})
        with pytest.raises(OddsApiIoUpstreamError) as blocked:
            await service._get_json("events", {"apiKey": "test-key", "request": 3})
        assert blocked.value.status_code == 429
        assert len(calls) == 2

        token = service._priority_context.set(True)
        try:
            await service._get_json("events", {"apiKey": "test-key", "request": 4})
        finally:
            service._priority_context.reset(token)
        assert len(calls) == 3
        quota = service.status()["quota"]
        assert quota["daily"]["used"] == 3
        assert quota["blocked_requests"] == 1
        assert quota["state"] == "reserve_only"
    finally:
        await service.aclose()


@pytest.mark.asyncio
async def test_full_feed_cache_avoids_new_network_requests(tmp_path):
    service = OddsApiIoService(settings_for(tmp_path), transport=httpx.MockTransport(lambda request: httpx.Response(500, request=request)))
    try:
        start = datetime.now(timezone.utc) + timedelta(hours=3)
        cached_payload = {
            "date": date.today().isoformat(),
            "timezone": "Asia/Taipei",
            "configured": True,
            "count": 1,
            "items": [{"commence_time": start.isoformat().replace("+00:00", "Z"), "markets": {"moneyline": {}}}],
            "meta": {"provider": "Odds-API.io", "fresh_for_model": True},
        }
        service.feed_cache.set(
            f"odds-api-io:cpbl-feed:{date.today().isoformat()}",
            cached_payload,
            1800,
            86400,
        )
        result = await service.odds_for_cpbl_date(date.today())
        assert result["meta"]["cache"] == "hit"
        assert service.status()["quota"]["daily"]["used"] == 0
    finally:
        await service.aclose()


def test_free_plan_filters_to_recreational_bookmakers(tmp_path):
    configured = Settings(
        odds_api_io_key="test-key",
        odds_api_io_free_plan_only=True,
        odds_api_io_cpbl_bookmakers_raw="Bet365,Pinnacle,Betfair,Unibet",
        odds_api_io_free_bookmakers_raw="Bet365,Unibet,DraftKings,FanDuel",
        odds_api_io_quota_ledger_path=str(tmp_path / "quota.json"),
    )
    assert configured.odds_api_io_cpbl_bookmakers == ["Bet365", "Unibet"]
