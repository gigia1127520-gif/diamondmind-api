from __future__ import annotations

import unittest
from datetime import date
from pathlib import Path

from app.asian_baseball import parse_cpbl_schedule, parse_kbo_schedule
from app.records import settlement_for
import app.main as main


class CompleteScoreParsingTests(unittest.TestCase):
    def test_cpbl_compact_card_accepts_split_score_nodes(self):
        html = """
        <div>7/21 週二</div>
        <div>一軍例行賽</div>
        <div>台鋼雄鷹</div><span>9</span>
        <div>中信兄弟</div><span>6</span>
        <div>GAME</div><span>211</span><span>已結束</span>
        <div>18:35</div><div>洲際</div>
        <div>賽程列表</div>
        """
        games = parse_cpbl_schedule(html, date(2026, 7, 21), "https://stats.cpbl.com.tw/schedule")
        self.assertEqual(len(games), 1)
        game = games[0]
        self.assertEqual(game["status"], "final")
        self.assertEqual(game["away"]["score"], 9)
        self.assertEqual(game["home"]["score"], 6)
        self.assertEqual(game["display_time_taiwan"], "台灣 18:35")

    def test_cpbl_split_score_can_settle_public_pick(self):
        html = """
        <div>7月21日</div>
        <div>GAME 211 已結束</div><div>一軍例行賽</div>
        <div>台鋼雄鷹</div><span>9</span>
        <div>中信兄弟</div><span>6</span>
        <div>18:35</div><div>洲際</div>
        """
        game = parse_cpbl_schedule(html, date(2026, 7, 21), "official")[0]
        result = settlement_for({
            "game_datetime": "2026-07-21T18:35:00+08:00",
            "pick_team_name": "中信兄弟",
        }, game)
        self.assertIsNotNone(result)
        self.assertEqual(result["status"], "lost")
        self.assertEqual(result["away_score"], 9)
        self.assertEqual(result["home_score"], 6)

    def test_kbo_table_accepts_split_score_cells(self):
        html = """
        <table id="tblScheduleList">
          <tr><td>07.21(TUE)</td><td>18:30</td><td>SSG</td><td>4</td><td>LOTTE</td><td>2</td><td>FINAL</td><td>SAJIK</td></tr>
        </table>
        """
        games = parse_kbo_schedule(html, date(2026, 7, 21), "official")
        self.assertEqual(len(games), 1)
        self.assertEqual(games[0]["status"], "final")
        self.assertEqual(games[0]["away"]["score"], 4)
        self.assertEqual(games[0]["home"]["score"], 2)

    def test_frontend_requires_complete_score_before_final(self):
        frontend = (Path(__file__).resolve().parents[1] / 'frontend' / 'index.html').read_text()
        member_js = (Path(__file__).resolve().parents[1] / 'frontend' / 'assets' / 'member.js').read_text()
        self.assertIn('賽果同步中', member_js)
        self.assertIn('awayScore!==null&&homeScore!==null', member_js)
        self.assertIn('21.1.0', frontend)

    def test_release_version(self):
        self.assertEqual(main.APP_VERSION, "21.1.0")


if __name__ == "__main__":
    unittest.main(verbosity=2)
