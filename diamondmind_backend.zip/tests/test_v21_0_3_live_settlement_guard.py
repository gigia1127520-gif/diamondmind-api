from datetime import datetime, timedelta

from app.asian_baseball import TAIPEI, _status


def test_cpbl_live_score_is_not_final_when_official_status_is_live():
    start = datetime(2026, 7, 22, 18, 35, tzinfo=TAIPEI)
    status, detail = _status("比賽中", (3, 2), start, start + timedelta(hours=2))
    assert status == "live"
    assert detail == "In Progress"


def test_cpbl_final_score_requires_official_final_marker():
    start = datetime(2026, 7, 22, 18, 35, tzinfo=TAIPEI)
    status, detail = _status("已結束", (5, 3), start, start + timedelta(hours=3))
    assert status == "final"
    assert detail == "Final"


def test_score_without_marker_during_game_window_stays_live():
    start = datetime(2026, 7, 22, 18, 35, tzinfo=TAIPEI)
    status, _ = _status("", (1, 0), start, start + timedelta(hours=2))
    assert status == "live"


def test_score_without_marker_after_safety_window_can_fallback_final():
    start = datetime(2026, 7, 21, 18, 35, tzinfo=TAIPEI)
    status, detail = _status("", (6, 4), start, start + timedelta(hours=9))
    assert status == "final"
    assert "fallback" in detail.lower()


def test_future_game_with_accidental_score_does_not_settle():
    start = datetime(2026, 7, 23, 18, 35, tzinfo=TAIPEI)
    status, _ = _status("", (1, 0), start, start - timedelta(hours=1))
    assert status == "upcoming"
