from __future__ import annotations

import asyncio
import unittest
from datetime import date

import httpx

from app.asian_baseball import cpbl_expected_game_count, parse_cpbl_schedule
from app.config import Settings
from app.markets import match_odds_event, moneyline_candidate
from app.odds import OddsService


class PrimaryOddsRegressionTests(unittest.TestCase):
    def run_async(self, coro):
        return asyncio.run(coro)


    def test_official_cpbl_schedule_shape_for_2026_07_22(self):
        # Mirrors the two first-team games listed by the official CPBL schedule
        # for 2026-07-22. This validates the unchanged V20.1.2 schedule parser.
        html = """
        <div>7月22日,星期三</div>
        <div>GAME 211未開始</div><div>台鋼雄鷹</div><div>vs</div><div>洲際</div><div>02:35</div><div>中信兄弟</div>
        <div>GAME 212 未開始</div><div>樂天桃猿</div><div>vs</div><div>大巨蛋</div><div>02:35</div><div>味全龍</div>
        """
        games = parse_cpbl_schedule(html, date(2026, 7, 22), "https://stats.cpbl.com.tw/schedule")
        self.assertEqual(len(games), 2)
        self.assertEqual(games[0]["away"]["name"], "TSG Hawks")
        self.assertEqual(games[0]["home"]["name"], "CTBC Brothers")
        self.assertEqual(games[1]["away"]["name"], "Rakuten Monkeys")
        self.assertEqual(games[1]["home"]["name"], "Wei Chuan Dragons")
        self.assertEqual({game["time_taiwan"] for game in games}, {"18:35"})


    def test_cpbl_schedule_parser_accepts_split_game_marker_nodes(self):
        # Mirrors the responsive Chakra/Next.js DOM where GAME, game number and
        # status may be emitted as separate adjacent text nodes.
        html = """
        <section><h3>7月22日,星期三</h3><p>共 2 場</p>
          <article><span>GAME</span><span>211</span><span>未開始</span>
            <img alt="台鋼雄鷹"><span>台鋼雄鷹</span><span>vs</span><span>洲際</span><span>02:35</span>
            <img alt="中信兄弟"><span>中信兄弟</span>
          </article>
          <article><span>GAME 212</span><span>未開始</span>
            <img alt="樂天桃猿"><span>樂天桃猿</span><span>vs</span><span>大巨蛋</span><span>02:35</span>
            <img alt="味全龍"><span>味全龍</span>
          </article>
        </section>
        """
        games = parse_cpbl_schedule(html, date(2026, 7, 22), "https://stats.cpbl.com.tw/schedule")
        self.assertEqual(len(games), 2)
        self.assertEqual([game["game_pk"] for game in games], ["cpbl_20260722_211", "cpbl_20260722_212"])
        self.assertEqual([game["time_taiwan"] for game in games], ["18:35", "18:35"])


    def test_cpbl_current_day_cards_override_shifted_monthly_label(self):
        # The live CPBL page can show the compact current-day header as 7/21
        # while the monthly list serializes the same games under 7/22.  GAME is
        # also rendered after the teams in the compact card.
        html = """
        <main>
          <h2>賽程</h2><div>7/21 週二</div><button>昨日</button><button>今日</button><button>明日</button>
          <a href="/schedule/2026-A-211"><div>一軍例行賽</div><img alt="台鋼雄鷹"><span>台鋼雄鷹</span><span>vs</span><span>洲際</span><span>02:35</span><img alt="中信兄弟"><span>中信兄弟</span><span>GAME</span><span>211</span><span>未開始</span></a>
          <a href="/schedule/2026-A-212"><div>一軍例行賽</div><img alt="樂天桃猿"><span>樂天桃猿</span><span>vs</span><span>大巨蛋</span><span>02:35</span><img alt="味全龍"><span>味全龍</span><span>GAME 212</span><span>未開始</span></a>
          <a href="/schedule/2026-B-166"><div>二軍例行賽</div><span>中信兄弟二軍</span><span>vs</span><span>斗六</span><span>00:05</span><span>味全龍二軍</span><span>GAME 166 未開始</span></a>
          <h1>賽程列表</h1>
          <section><h3>7月22日,星期三</h3><p>共 2 場</p>
            <div>GAME 211未開始</div><div>台鋼雄鷹</div><div>vs</div><div>洲際</div><div>02:35</div><div>中信兄弟</div>
            <div>GAME 212未開始</div><div>樂天桃猿</div><div>vs</div><div>大巨蛋</div><div>02:35</div><div>味全龍</div>
          </section>
        </main>
        """
        games = parse_cpbl_schedule(html, date(2026, 7, 21), "https://stats.cpbl.com.tw/schedule")
        self.assertEqual(len(games), 2)
        self.assertEqual(cpbl_expected_game_count(html, date(2026, 7, 21)), 2)
        self.assertEqual([game["game_pk"] for game in games], ["cpbl_20260721_211", "cpbl_20260721_212"])
        self.assertEqual([game["time_taiwan"] for game in games], ["18:35", "18:35"])
        self.assertEqual([game["venue"] for game in games], ["洲際", "大巨蛋"])

        analysis = {"game": games[0], "game_date": games[0]["game_date"]}
        event = {
            "event_id": "cpbl-211",
            "away_team": "TSG Hawks",
            "home_team": "CTBC Brothers",
            "commence_time": games[0]["game_date"],
            "markets": {"moneyline": {}},
        }
        self.assertIs(match_odds_event(analysis, [event]), event)

    def test_mlb_npb_kbo_primary_adapter_remains_operational(self):
        event = {
            "id": "primary-1",
            "sport_key": "baseball_mlb",
            "commence_time": "2026-07-22T23:05:00Z",
            "away_team": "New York Yankees",
            "home_team": "Los Angeles Dodgers",
            "bookmakers": [{
                "key": "draftkings",
                "title": "DraftKings",
                "last_update": "2026-07-20T10:00:00Z",
                "markets": [
                    {"key": "h2h", "outcomes": [{"name": "New York Yankees", "price": 120}, {"name": "Los Angeles Dodgers", "price": -135}]},
                    {"key": "spreads", "outcomes": [{"name": "New York Yankees", "point": 1.5, "price": -110}, {"name": "Los Angeles Dodgers", "point": -1.5, "price": -110}]},
                    {"key": "totals", "outcomes": [{"name": "Over", "point": 8.5, "price": -105}, {"name": "Under", "point": 8.5, "price": -115}]},
                ],
            }],
        }

        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, json=[event], headers={"x-requests-remaining": "499"})

        settings = Settings(odds_api_key="primary-test")
        for sport_key in ("baseball_mlb", "baseball_npb", "baseball_kbo"):
            with self.subTest(sport_key=sport_key):
                service = OddsService(settings, transport=httpx.MockTransport(handler))
                try:
                    feed = self.run_async(service.odds_for_date(date(2026, 7, 23), sport_key=sport_key))
                    self.assertEqual(feed["count"], 1)
                    self.assertEqual(feed["meta"]["coverage"], {"moneyline": 1, "run_line": 1, "totals": 1})
                    self.assertEqual(feed["items"][0]["markets"]["moneyline"]["bookmaker"], "DraftKings")
                finally:
                    self.run_async(service.aclose())

    def test_existing_top_level_market_source_still_builds_candidate(self):
        analysis = {
            "game_pk": 1,
            "matchup": "Away @ Home",
            "game_date": "2026-07-22T10:00:00Z",
            "time_taiwan": "18:00",
            "home_probability": 60.0,
            "away_probability": 40.0,
            "data_quality": 0.8,
            "game": {
                "league": "MLB",
                "away": {"id": 1, "name": "Away", "abbr": "AWY"},
                "home": {"id": 2, "name": "Home", "abbr": "HME"},
            },
            "projections": {"quality": 0.8},
        }
        event = {"markets": {"moneyline": {
            "type": "real_bookmaker",
            "provider": "The Odds API",
            "bookmaker_key": "draftkings",
            "bookmaker": "DraftKings",
            "away_price": 120,
            "home_price": -135,
        }}}
        candidate = moneyline_candidate(analysis, event, minimum_probability=0, minimum_edge=-100)
        self.assertIsNotNone(candidate)
        self.assertEqual(candidate["odds_source"]["bookmaker_key"], "draftkings")
        self.assertEqual(candidate["odds_source"]["provider"], "The Odds API")


if __name__ == "__main__":
    unittest.main(verbosity=2)
