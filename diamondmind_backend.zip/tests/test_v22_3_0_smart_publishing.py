from __future__ import annotations

from datetime import date
from pathlib import Path
from types import SimpleNamespace

import pytest

from app import main
from app.records import (
    RecordsStorageError,
    build_package_payload,
    build_record_payload,
)


def free_selection(*, market: str = "moneyline") -> dict:
    return {
        "league": "MLB",
        "game_pk": "777",
        "game_date": "2026-07-27T01:00:00Z",
        "matchup": "AWY @ HOM",
        "market": market,
        "game": {
            "league": "MLB",
            "away": {"id": 1, "name": "Away", "abbr": "AWY"},
            "home": {"id": 2, "name": "Home", "abbr": "HOM"},
        },
        "pick": {
            "market": market,
            "side": "away",
            "team_id": 1,
            "team_name": "Away",
            "abbr": "AWY",
            "label": "Away ML",
        },
        "opponent": {
            "team_id": 2,
            "team_name": "Home",
            "abbr": "HOM",
        },
        "confidence": 62.5,
    }


def test_free_storage_is_hard_limited_to_public_moneyline() -> None:
    payload = build_record_payload("2026-07-27", free_selection())
    snapshot = payload["prediction_snapshot"]

    assert payload["is_public"] is True
    assert snapshot["access_level"] == "free"
    assert snapshot["visibility"] == "public"
    assert snapshot["publication"]["channel"] == "free"

    with pytest.raises(RecordsStorageError, match="only accepts one moneyline"):
        build_record_payload(
            "2026-07-27",
            free_selection(market="run_line"),
        )


def test_pro_storage_is_members_only() -> None:
    payload = build_package_payload(
        "2026-07-27",
        {
            "generated_at": "2026-07-26T12:00:00Z",
            "moneylines": [],
            "run_lines": [],
            "totals": [],
            "parlays": {"two_leg": [], "three_leg": []},
            "publication": {},
        },
    )
    publication = payload["thresholds"]["publication"]

    assert publication["channel"] == "pro"
    assert publication["access_level"] == "pro"
    assert publication["visibility"] == "members_only"


@pytest.mark.asyncio
async def test_publishing_status_never_combines_free_and_pro(monkeypatch) -> None:
    async def founder(_request, _authorization):
        return {"id": "founder", "role": "admin"}

    class FakeRecords:
        enabled = True

        async def get_record_for_date(self, _target, _league):
            return None

        async def get_prediction_package_for_date(self, _target):
            return None

    monkeypatch.setattr(main, "admin_member", founder)
    monkeypatch.setattr(main, "records_repository", lambda _request: FakeRecords())
    request = SimpleNamespace(
        app=SimpleNamespace(
            state=SimpleNamespace(
                publishing_status={
                    "state": "idle",
                    "running": False,
                    "mode": "background_only",
                }
            )
        )
    )

    payload = await main.founder_publishing_status(
        request,
        date(2026, 7, 27),
        "MLB",
        "Bearer founder",
    )

    assert payload["version"] == "22.4.0"
    assert payload["plan"]["combined_publish"] is False
    assert payload["channels"]["free"]["storage"] == "recommendations"
    assert payload["channels"]["pro"]["storage"] == "prediction_packages"
    assert payload["automatic"]["mode"] == "manual_only"
    assert payload["model_optimization"]["mode"] == "test_candidates_only"
    assert payload["model_optimization"]["automatic_deploy"] is False
    assert payload["safety"]["server_side_pro_gate"] is True


def test_external_cron_uses_background_queue() -> None:
    source = Path("app/main.py").read_text(encoding="utf-8")

    assert "diamondmind-asian-auto-publish" in source
    assert "Asian Free and Pro checks were queued" in source
    assert '"mode": "background_only"' in source
    assert "external_publish_lock" in source
