from datetime import date
from app import main


def test_waiting_bundle_is_structured_and_non_publishable():
    bundle = main._candidate_waiting_bundle(
        date(2026, 7, 26), "MLB", stage="odds", message="等待最新盤口"
    )
    assert bundle["available"] is False
    assert bundle["failure_stage"] == "odds"
    assert bundle["diagnostics"]["odds"]["status"] == "waiting"
    assert bundle["readiness"]["MLB"]["ready"] is False
    assert bundle["message"] == "等待最新盤口"


def test_waiting_bundle_has_empty_candidate_groups():
    bundle = main._candidate_waiting_bundle(
        date(2026, 7, 26), "KBO", stage="model", message="模型稍後重試"
    )
    candidates = bundle.get("candidates") or {}
    assert candidates["moneylines"] == []
    assert candidates["run_lines"] == []
    assert candidates["totals"] == []
    assert candidates["parlays"]["two_leg"] == []
    assert candidates["parlays"]["three_leg"] == []
    assert bundle["league_status"]["KBO"]["formal"] == 0


def test_release_version():
    assert main.APP_VERSION == "22.1.1"
