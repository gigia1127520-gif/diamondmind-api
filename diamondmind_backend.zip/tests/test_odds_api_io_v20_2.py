from __future__ import annotations

import asyncio
import json
import unittest
from datetime import date
from urllib.parse import parse_qs

import httpx

from app.config import Settings
from app.markets import (
    is_asian_baseball_pro_selection,
    is_real_odds_selection,
    match_odds_event,
    moneyline_candidate,
    run_line_candidate,
    totals_candidate,
)
from app.odds_api_io import OddsApiIoService


EVENT_ID = "7001"
EVENT = {
    "id": 7001,
    "home": "CTBC Brothers",
    "away": "Rakuten Monkeys",
    "date": "2026-07-22T10:35:00Z",
    "status": "pending",
    "sport": {"name": "Baseball", "slug": "baseball"},
    "league": {"name": "Taiwan CPBL", "slug": "taiwan-cpbl"},
}


def event_with_books(bookmakers):
    return {**EVENT, "bookmakers": bookmakers}


BOOK_A = [
    {"name": "ML", "updatedAt": "2026-07-20T10:00:00Z", "odds": [{"home": "1.80", "away": "2.10"}]},
    {"name": "Spread", "updatedAt": "2026-07-20T10:00:00Z", "odds": [{"hdp": -1.5, "home": "1.92", "away": "1.91"}]},
    {"name": "Totals", "updatedAt": "2026-07-20T10:00:00Z", "odds": [{"hdp": 8.5, "over": "1.91", "under": "1.95"}]},
]
BOOK_B = [
    {"name": "ML", "updatedAt": "2026-07-20T10:01:00Z", "odds": [{"home": "1.95", "away": "2.00"}]},
    {"name": "Spread", "updatedAt": "2026-07-20T10:01:00Z", "odds": [{"hdp": -1.5, "home": "1.88", "away": "2.02"}]},
    {"name": "Totals", "updatedAt": "2026-07-20T10:01:00Z", "odds": [{"hdp": 8.5, "over": "2.03", "under": "1.90"}]},
]


class FakeProvider:
    def __init__(self, *, force_single_fallback: bool = False, empty_markets: bool = False):
        self.force_single_fallback = force_single_fallback
        self.empty_markets = empty_markets
        self.calls = []

    def __call__(self, request: httpx.Request) -> httpx.Response:
        path = request.url.path
        query = parse_qs(request.url.query.decode())
        self.calls.append((path, query))
        if path.endswith("/leagues"):
            return httpx.Response(200, json=[{"name": "Taiwan - CPBL", "slug": "taiwan-cpbl", "eventsCount": 1}])
        if path.endswith("/bookmakers/selected"):
            return httpx.Response(200, json={"bookmakers": ["Book A", "Book B"]})
        if path.endswith("/bookmakers"):
            return httpx.Response(200, json=[
                {"id": 101, "name": "Book A", "active": True},
                {"slug": "book-b", "name": "Book B", "active": True},
                {"name": "Inactive", "active": False},
            ])
        if path.endswith("/events"):
            return httpx.Response(200, json=[EVENT])
        if path.endswith("/odds/multi"):
            if self.force_single_fallback:
                return httpx.Response(400, json={"message": "batch rejected for test"})
            books = {} if self.empty_markets else {"Book A": BOOK_A, "Book B": BOOK_B}
            return httpx.Response(200, json=[event_with_books(books)])
        if path.endswith("/odds"):
            requested = query.get("bookmakers", [""])[0]
            if "," in requested and self.force_single_fallback:
                return httpx.Response(400, json={"message": "group rejected for test"})
            books = {}
            if not self.empty_markets:
                if requested == "Book A":
                    books["Book A"] = BOOK_A
                elif requested == "Book B":
                    books["Book B"] = BOOK_B
                else:
                    books = {"Book A": BOOK_A, "Book B": BOOK_B}
            return httpx.Response(200, json=event_with_books(books))
        return httpx.Response(404, json={"message": f"unhandled {path}"})


def settings() -> Settings:
    return Settings(
        odds_api_io_key="test-key",
        odds_api_io_cpbl_bookmakers_raw="Book A,Book B",
        odds_api_io_cache_ttl_seconds=60,
        odds_api_io_events_cache_ttl_seconds=300,
        odds_api_io_metadata_cache_ttl_seconds=3600,
        odds_api_io_bookmaker_group_size=2,
        odds_api_io_cpbl_max_bookmakers=2,
    )


class OddsApiIoV202Tests(unittest.TestCase):
    def run_async(self, coro):
        return asyncio.run(coro)

    def test_end_to_end_merge_best_odds_and_cache(self):
        provider = FakeProvider()
        service = OddsApiIoService(settings(), transport=httpx.MockTransport(provider))
        try:
            first = self.run_async(service.odds_for_cpbl_date(date(2026, 7, 22)))
            self.assertEqual(first["meta"]["coverage_status"], "available")
            self.assertEqual(first["count"], 1)
            event = first["items"][0]
            ml = event["markets"]["moneyline"]
            self.assertEqual(ml["home_source"]["bookmaker"], "Book B")
            self.assertEqual(ml["away_source"]["bookmaker"], "Book A")
            self.assertEqual(ml["home_source"]["bookmaker_id"], "book-b")
            self.assertEqual(ml["away_source"]["bookmaker_id"], "101")
            run_line = event["markets"]["run_line"]
            self.assertEqual(run_line["home_source"]["bookmaker"], "Book A")
            self.assertEqual(run_line["away_source"]["bookmaker"], "Book B")
            totals = event["markets"]["totals"]
            self.assertEqual(totals["over_source"]["bookmaker"], "Book B")
            self.assertEqual(totals["under_source"]["bookmaker"], "Book A")
            self.assertTrue(first["meta"]["best_odds"])
            self.assertEqual(len(first["meta"]["bookmaker_results"]), 2)
            calls_after_first = len(provider.calls)

            second = self.run_async(service.odds_for_cpbl_date(date(2026, 7, 22)))
            self.assertEqual(len(provider.calls), calls_after_first)
            self.assertEqual(second["meta"]["cache_diagnostics"]["request_delta"]["network_requests"], 0)
            self.assertGreater(second["meta"]["cache_diagnostics"]["request_delta"]["cache_hits"], 0)
        finally:
            self.run_async(service.aclose())

    def test_multi_and_group_rejection_degrades_to_single_bookmaker(self):
        provider = FakeProvider(force_single_fallback=True)
        service = OddsApiIoService(settings(), transport=httpx.MockTransport(provider))
        try:
            feed = self.run_async(service.odds_for_cpbl_date(date(2026, 7, 22)))
            self.assertEqual(feed["meta"]["coverage_status"], "available")
            self.assertEqual(feed["count"], 1)
            self.assertTrue(any(row["fallback_events"] for row in feed["meta"]["batch_results"]))
            individual_calls = [
                query.get("bookmakers", [""])[0]
                for path, query in provider.calls
                if path.endswith("/odds") and "," not in query.get("bookmakers", [""])[0]
            ]
            self.assertEqual(set(individual_calls), {"Book A", "Book B"})
        finally:
            self.run_async(service.aclose())

    def test_empty_provider_event_does_not_unlock_pro(self):
        provider = FakeProvider(empty_markets=True)
        service = OddsApiIoService(settings(), transport=httpx.MockTransport(provider))
        try:
            feed = self.run_async(service.odds_for_cpbl_date(date(2026, 7, 22)))
            self.assertEqual(feed["count"], 0)
            self.assertEqual(feed["meta"]["events_found"], 1)
            self.assertEqual(feed["meta"]["events_with_real_markets"], 0)
            self.assertEqual(feed["meta"]["coverage_status"], "events_found_no_odds")
            fake_selection = {
                "market_basis": "real_odds",
                "price": -110,
                "decimal_odds": 1.91,
                "odds_source": {"type": "real_bookmaker", "bookmaker_key": ""},
            }
            self.assertFalse(is_real_odds_selection(fake_selection))
        finally:
            self.run_async(service.aclose())

    def test_real_odds_generate_publishable_cpbl_recommendations(self):
        provider = FakeProvider()
        service = OddsApiIoService(settings(), transport=httpx.MockTransport(provider))
        try:
            feed = self.run_async(service.odds_for_cpbl_date(date(2026, 7, 22)))
            event = feed["items"][0]
            analysis = {
                "game_pk": "cpbl_20260722_212",
                "matchup": "Rakuten Monkeys @ CTBC Brothers",
                "game_date": "2026-07-22T10:35:00Z",
                "time_taiwan": "18:35",
                "home_probability": 58.0,
                "away_probability": 42.0,
                "data_quality": 0.82,
                "game": {
                    "league": "CPBL",
                    "away": {"id": "cpbl-monkeys", "name": "Rakuten Monkeys", "abbr": "RM"},
                    "home": {"id": "cpbl-brothers", "name": "CTBC Brothers", "abbr": "CTB"},
                },
                "projections": {"quality": 0.82, "home_margin": 1.9, "total_runs": 7.6},
                "factors": [],
                "analysis_groups": {},
                "engine": {},
            }
            candidates = [
                moneyline_candidate(analysis, event, minimum_probability=0, minimum_edge=-100),
                run_line_candidate(analysis, event, minimum_probability=0, minimum_edge=-100, minimum_projection_quality=0),
                totals_candidate(analysis, event, minimum_probability=0, minimum_edge=-100, minimum_projection_quality=0),
            ]
            self.assertTrue(all(candidate is not None for candidate in candidates))
            self.assertTrue(all(is_asian_baseball_pro_selection(candidate, "CPBL") for candidate in candidates))
            self.assertEqual({candidate["market"] for candidate in candidates}, {"moneyline", "run_line", "totals"})
            self.assertTrue(all(candidate["odds_source"]["provider"] == "Odds-API.io" for candidate in candidates))
        finally:
            self.run_async(service.aclose())

    def test_cpbl_team_alias_schedule_match(self):
        odds_event = {
            "away_team": "Rakuten Monkeys",
            "home_team": "CTBC Brothers",
            "commence_time": "2026-07-22T10:35:00Z",
            "markets": {"moneyline": {}},
        }
        analysis = {
            "game": {
                "away": {"name": "Rakuten Monkeys"},
                "home": {"name": "Chinatrust Brothers"},
                "game_date": "2026-07-22T10:35:00Z",
            }
        }
        self.assertIs(match_odds_event(analysis, [odds_event]), odds_event)


if __name__ == "__main__":
    unittest.main(verbosity=2)
