from __future__ import annotations

from app import main
from app.records import build_package_payload


def package_record(target_date: str, *, published_at: str, league: str = "CPBL") -> dict:
    selection = {
        "candidate_id": f"{league.lower()}-{target_date}",
        "league": league,
        "game_pk": f"{league.lower()}_{target_date.replace('-', '')}_1",
        "game_date": f"{target_date}T18:35:00+08:00",
        "matchup": "客隊 @ 主隊",
        "market": "moneyline",
        "pick": {"market": "moneyline", "team_name": "主隊", "label": "主隊獨贏"},
        "publication": {"mode": "ai_auto", "status": "published", "is_active": True},
        "published_at": published_at,
        "target_date": target_date,
        "status": "published",
    }
    package = {
        "date": target_date,
        "published": True,
        "locked": True,
        "generated_at": published_at,
        "moneylines": [selection],
        "run_lines": [],
        "totals": [],
        "parlays": {"two_leg": [], "three_leg": []},
        "publication": {
            "mode": "ai_auto",
            "status": "published",
            "is_active": True,
            "target_date": target_date,
            "published_at": published_at,
            "league": league,
            "league_batches": {
                league: {
                    "league": league,
                    "target_date": target_date,
                    "published_at": published_at,
                    "status": "published",
                    "is_active": True,
                    "game_ids": [selection["game_pk"]],
                    "recommendation_type": "pro",
                }
            },
        },
        "recommendation_status": "formal_published",
    }
    record = build_package_payload(target_date, package)
    record.update({"id": f"pkg-{target_date}", "results": {}, "settled": False})
    return record


def test_past_cpbl_pro_is_not_returned_as_current_recommendation() -> None:
    yesterday = package_record("2026-07-22", published_at="2026-07-22T09:00:00Z")
    record, package, metadata = main._latest_package_for_league(
        [yesterday], "CPBL", minimum_target_date="2026-07-23"
    )
    assert record is None
    assert package is None
    assert metadata is None


def test_today_cpbl_pro_remains_visible() -> None:
    today = package_record("2026-07-23", published_at="2026-07-23T09:00:00Z")
    record, package, metadata = main._latest_package_for_league(
        [today], "CPBL", minimum_target_date="2026-07-23"
    )
    assert record is today
    assert metadata["target_date"] == "2026-07-23"


def test_future_slate_published_early_remains_visible() -> None:
    tomorrow = package_record("2026-07-24", published_at="2026-07-23T14:00:00Z", league="MLB")
    record, package, metadata = main._latest_package_for_league(
        [tomorrow], "MLB", minimum_target_date="2026-07-23"
    )
    assert record is tomorrow
    assert metadata["target_date"] == "2026-07-24"


def test_latest_eligible_batch_ignores_more_recent_past_publication() -> None:
    future = package_record("2026-07-24", published_at="2026-07-23T08:00:00Z", league="MLB")
    past = package_record("2026-07-22", published_at="2026-07-23T10:00:00Z", league="MLB")
    record, package, metadata = main._latest_package_for_league(
        [future, past], "MLB", minimum_target_date="2026-07-23"
    )
    assert record is future
    assert metadata["target_date"] == "2026-07-24"
