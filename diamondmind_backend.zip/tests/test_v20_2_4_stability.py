from __future__ import annotations

import asyncio
import inspect
import time
import unittest
from types import SimpleNamespace

import httpx

from app.config import Settings
from app.records import SupabaseRecordsRepository
import app.main as main


class ReadCacheTests(unittest.TestCase):
    def run_async(self, coro):
        return asyncio.run(coro)

    def test_supabase_get_cache_and_stale_fallback(self):
        calls = {"get": 0, "patch": 0}

        def handler(request: httpx.Request) -> httpx.Response:
            if request.method == "GET":
                calls["get"] += 1
                if calls["get"] == 1:
                    return httpx.Response(200, json=[{"id": "1", "status": "pending"}])
                return httpx.Response(503, json={"message": "temporary"})
            calls["patch"] += 1
            return httpx.Response(200, json=[])

        settings = Settings(
            supabase_url="https://example.supabase.co",
            supabase_secret_key="secret",
            records_request_retries=0,
            read_api_cache_ttl_seconds=5,
            read_api_stale_ttl_seconds=300,
            read_api_timeout_seconds=2.0,
        )
        repository = SupabaseRecordsRepository(settings, transport=httpx.MockTransport(handler))

        async def scenario():
            first = await repository.list_records()
            second = await repository.list_records()
            self.assertEqual(first, second)
            self.assertEqual(calls["get"], 1)
            for item in repository._read_cache.values():
                item["fresh_until"] = 0.0
                item["stale_until"] = time.monotonic() + 60
            stale = await repository.list_records()
            self.assertEqual(stale, first)
            self.assertEqual(calls["get"], 2)
            self.assertEqual(repository.cache_status()["stale_hits"], 1)
            await repository._request("PATCH", "recommendations", json={"status": "won"})
            self.assertEqual(repository.cache_status()["entries"], 0)
            await repository.aclose()

        self.run_async(scenario())


class SettlementIsolationTests(unittest.TestCase):
    def run_async(self, coro):
        return asyncio.run(coro)

    def test_member_read_endpoints_do_not_run_settlement(self):
        for function in (
            main.latest_predictions_for_member,
            main.daily_predictions_for_member,
            main.recommendation_records,
        ):
            source = inspect.getsource(function)
            self.assertNotIn("await settle_pending_records", source)
            self.assertNotIn("await settle_pending_prediction_packages", source)

    def test_internal_pregame_loop_does_not_run_settlement_or_social_inline(self):
        source = inspect.getsource(main._pregame_refresh_loop)
        self.assertNotIn("_settle_pending_records_with", source)
        self.assertNotIn("_settle_pending_prediction_packages_with", source)
        self.assertNotIn("await sync_social_publications", source)

    def test_social_image_rendering_is_offloaded(self):
        source = inspect.getsource(main.social_asset)
        self.assertIn("await asyncio.to_thread(social.render", source)

    def test_settlement_game_lookup_is_shared(self):
        calls = {"count": 0}
        original = main._game_result_for_ref

        async def fake(*args, **kwargs):
            calls["count"] += 1
            return {"game_pk": "kbo_1", "status": "final", "away_score": 2, "home_score": 3}

        async def scenario():
            main._game_result_for_ref = fake
            cache = {}
            try:
                one = await main._settlement_game_result_cached(None, None, None, None, "KBO", "kbo_1", cache)
                two = await main._settlement_game_result_cached(None, None, None, None, "KBO", "kbo_1", cache)
                self.assertEqual(one, two)
                self.assertEqual(calls["count"], 1)
            finally:
                main._game_result_for_ref = original

        self.run_async(scenario())

    def test_settlement_queue_respects_cooldown(self):
        fake_app = SimpleNamespace(
            state=SimpleNamespace(
                external_settlement_task=None,
                last_settlement_completed_monotonic=main.monotonic(),
                settlement_status={"running": False},
            )
        )
        result = main._queue_settlement_background(fake_app, "test")
        self.assertTrue(result["cooldown"])
        self.assertFalse(result["already_running"])

    def test_version_and_all_league_support(self):
        self.assertEqual(main.APP_VERSION, "20.2.4")
        source = inspect.getsource(main._run_settlement_pass)
        for league_attr in ("mlb", "npb", "kbo", "cpbl"):
            self.assertIn(f"app.state.{league_attr}", source)


if __name__ == "__main__":
    unittest.main()
