from __future__ import annotations

import asyncio
from types import SimpleNamespace

import pytest

from app.performance import DEFAULT_MODEL_WEIGHTS, PerformanceRepository


class FakePerformance(PerformanceRepository):
    def __init__(self):
        self.enabled = True
        self.backfill_called = False

    async def list_snapshots(self, **kwargs):
        return [
            {
                "status": "won",
                "market": "moneyline",
                "league": "KBO",
                "confidence": 64,
                "price": 1.9,
                "result": {},
                "publication_snapshot": {"mode": "ai_auto"},
                "recommendation_date": "2026-07-22",
                "module_scores": {},
            }
        ]

    async def backfill_financial_metadata(self, rows, limit=300):
        self.backfill_called = True
        raise AssertionError("read-only dashboard must not PATCH legacy rows")

    async def active_weights(self):
        return dict(DEFAULT_MODEL_WEIGHTS)


@pytest.mark.asyncio
async def test_performance_dashboard_is_read_only_and_fast():
    repo = FakePerformance()
    payload = await asyncio.wait_for(
        repo.performance_dashboard(days=30, market="all", source_type="all"),
        timeout=1,
    )
    assert payload["summary"]["total"] == 1
    assert payload["summary"]["decisions"] == 1
    assert repo.backfill_called is False
