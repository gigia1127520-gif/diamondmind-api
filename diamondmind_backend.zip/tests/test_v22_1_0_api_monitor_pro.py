from pathlib import Path

def test_api_monitor_route_and_pro_fallback():
    main=Path("app/main.py").read_text(encoding="utf-8")
    odds=Path("app/odds.py").read_text(encoding="utf-8")
    assert "/admin/api-monitor" in main
    assert "regions_fallback" in odds
    assert "Founder candidate loading must not disappear" in main

def test_release_version():
    import app.main as main
    assert main.APP_VERSION == "22.2.0"
