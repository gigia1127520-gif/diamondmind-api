from __future__ import annotations

import unittest
from unittest.mock import AsyncMock

from app.calibration import CalibrationRegistry, apply_registry_to_selection, apply_registry_to_bundle
from app.value import ValuePolicy, evaluate_selection_value
from app.performance import PerformanceRepository
from app.config import Settings


POLICY = ValuePolicy(
    minimum_ev_percent=3.0,
    minimum_edge_points=2.5,
    minimum_data_quality=0.8,
    anomaly_ev_percent=10.0,
    anomaly_edge_points=12.0,
    minimum_reliability=0.35,
    high_value_ev_percent=6.0,
)


def selection(*, probability: float, market_probability: float, decimal_odds: float, data_quality: float = 0.95) -> dict:
    return {
        "candidate_id": f"moneyline:1:home::{decimal_odds}",
        "league": "CPBL",
        "game_pk": "213",
        "game_date": "2026-07-22T10:35:00Z",
        "matchup": "TSG @ CTB",
        "market": "moneyline",
        "market_basis": "real_odds",
        "pick": {"side": "home", "label": "中信兄弟"},
        "model_probability": probability,
        "implied_probability": market_probability,
        "price": -120,
        "decimal_odds": decimal_odds,
        "odds_source": {
            "type": "real_bookmaker",
            "bookmaker_key": "bet365",
            "bookmaker": "Bet365",
            "last_update": "2099-01-01T00:00:00Z",
        },
        "data_quality": data_quality,
        "projection_quality": data_quality,
        "qualification_thresholds": {
            "minimum_probability": 53,
            "minimum_edge": 2.5,
            "minimum_projection_quality": 0.5,
        },
        "meets_threshold": True,
    }


class ValueMathTests(unittest.TestCase):
    def test_low_price_favourite_can_be_negative_ev(self):
        item = selection(probability=66, market_probability=70, decimal_odds=1.45)
        result = evaluate_selection_value(item, calibrated_probability=66, policy=POLICY)
        self.assertLess(result["conservative_ev_percent"], 0)
        self.assertEqual(result["decision"], "blocked_negative_ev")
        self.assertFalse(result["qualified"])

    def test_positive_ev_candidate_uses_reliability_shrinkage(self):
        item = selection(probability=61.5, market_probability=55.0, decimal_odds=1.78)
        result = evaluate_selection_value(item, calibrated_probability=61.5, policy=POLICY)
        self.assertGreater(result["conservative_probability"], 55.0)
        self.assertLess(result["conservative_probability"], 61.5)
        self.assertGreater(result["conservative_ev_percent"], 3.0)
        self.assertIn(result["decision"], {"candidate", "high_value"})

    def test_extreme_ev_requires_manual_review(self):
        item = selection(probability=78, market_probability=52, decimal_odds=2.05)
        result = evaluate_selection_value(item, calibrated_probability=78, policy=POLICY)
        self.assertTrue(result["manual_review_required"])
        self.assertEqual(result["decision"], "manual_review")
        self.assertFalse(result["qualified"])


class ValueGateTests(unittest.TestCase):
    def test_selection_is_blocked_when_conservative_ev_is_negative(self):
        item = selection(probability=66, market_probability=70, decimal_odds=1.45)
        result = apply_registry_to_selection(
            item,
            CalibrationRegistry.empty(),
            minimum_probability=53,
            minimum_edge=2.5,
            value_policy=POLICY,
            enforce_value=True,
        )
        self.assertFalse(result["meets_threshold"])
        self.assertEqual(result["candidate_tier"], "blocked_negative_ev")

    def test_bundle_promotes_watchlist_when_recalculated_value_passes(self):
        item = selection(probability=61.5, market_probability=55.0, decimal_odds=1.78)
        item["meets_threshold"] = False
        bundle = {
            "candidates": {"moneylines": [], "run_lines": [], "totals": []},
            "watchlist": {"moneylines": [item], "run_lines": [], "totals": []},
            "thresholds": {"minimum_parlay_leg_probability": 54},
            "recommended": {},
        }
        result = apply_registry_to_bundle(
            bundle,
            CalibrationRegistry.empty(),
            minimum_probability=53,
            minimum_edge=2.5,
            value_policies={"moneyline": POLICY},
            enforce_value=True,
        )
        self.assertEqual(len(result["candidates"]["moneylines"]), 1)
        self.assertIn(result["candidates"]["moneylines"][0]["candidate_tier"], {"formal", "high_value"})


class CandidateSnapshotRepositoryTests(unittest.IsolatedAsyncioTestCase):
    async def test_duplicate_candidate_capture_does_not_reset_settled_rows(self):
        repository = PerformanceRepository(Settings(supabase_url="https://example.supabase.co", supabase_secret_key="service-role-key"))
        repository._request = AsyncMock(return_value=[])
        await repository.insert_candidate_snapshots([{"candidate_id": "candidate-1"}])
        kwargs = repository._request.await_args.kwargs
        self.assertEqual(kwargs["headers"]["Prefer"], "resolution=ignore-duplicates,return=representation")


if __name__ == "__main__":
    unittest.main()
