from datetime import date, datetime

from app.asian_baseball import (
    TAIPEI,
    _game_payload,
    parse_kbo_schedule,
    parse_kbo_scoreboard_results,
    KBO_TEAMS,
)
from app.records import game_disposition, settlement_for


def test_kbo_no_game_payload_is_terminal_void():
    game = _game_payload(
        "KBO", date(2026, 7, 22), "kbo_20260722_NC_LG_2",
        "NC", "LG", KBO_TEAMS, local_time="18:30", local_tz=TAIPEI,
        away_score=0, home_score=0, raw_status="No Game / Cancelled",
    )
    assert game["status"] == "cancelled"
    assert game["settlement_disposition"] == "void"
    assert game["away"]["score"] is None
    assert game["home"]["score"] is None
    assert game_disposition(game) == "void"


def test_kbo_postponed_is_void_not_pending():
    game = {
        "league": "KBO", "status": "postponed", "detailed_status": "Postponed",
        "away": {"id": "NC", "score": None}, "home": {"id": "LG", "score": None},
    }
    assert game_disposition(game) == "void"
    result = settlement_for({"pick_team_id": "NC"}, game)
    assert result is not None
    assert result["status"] == "void"


def test_kbo_schedule_korean_rain_cancel_is_void():
    html = """<table id='tblScheduleList'><tr><td>07.22(WED)</td><td>18:30</td><td>NC</td><td>LG</td><td>우천취소</td><td>JAMSIL</td></tr></table>"""
    games = parse_kbo_schedule(html, date(2026, 7, 22), "official")
    assert len(games) == 1
    assert games[0]["status"] == "cancelled"
    assert games[0]["settlement_disposition"] == "void"


def test_kbo_scoreboard_no_game_marker_is_parsed():
    html = "<html><body>NC NO GAME LG</body></html>"
    results = parse_kbo_scoreboard_results(html)
    result = results[("NC", "LG")]
    assert result["status"] == "cancelled"
    assert result["settlement_disposition"] == "void"


def test_pending_free_record_is_persisted_as_void_by_settlement_job():
    import asyncio
    import app.main as main

    record = {
        "id": "free-kbo-nogame", "status": "pending", "league": "KBO",
        "game_pk": "kbo_20260722_NC_LG_2", "game_datetime": "2026-07-22T18:30:00+08:00",
        "matchup": "NC恐龍 @ LG雙子", "pick_team_id": "NC", "pick_team_name": "NC恐龍",
        "prediction_snapshot": {
            "league": "KBO", "game_pk": "kbo_20260722_NC_LG_2",
            "game_date": "2026-07-22T18:30:00+08:00",
            "pick": {"team_id": "NC", "team_name": "NC恐龍", "market": "moneyline"},
            "publication": {"status": "published", "is_active": True},
        },
    }
    no_game = {
        "league": "KBO", "game_pk": record["game_pk"],
        "game_date": record["game_datetime"], "status": "cancelled",
        "detailed_status": "No Game / Cancelled", "settlement_disposition": "void",
        "away": {"id": "NC", "name_zh": "NC恐龍", "score": None},
        "home": {"id": "LG", "name_zh": "LG雙子", "score": None},
    }

    class Repo:
        enabled = True
        settled_payload = None
        async def list_records(self, **kwargs): return [record]
        async def settle(self, game_pk, payload):
            self.settled_payload = payload
            return {**record, **payload}
        async def update_prediction_snapshot(self, *args): return None
        async def reconcile_prediction(self, *args): return None

    class KBO:
        async def game_result(self, game_pk, selection=None): return no_game

    class Unused:
        async def game_result(self, *args, **kwargs): raise AssertionError("unused adapter")

    async def scenario():
        repo = Repo()
        settled_ids = []
        count = await main._settle_pending_records_with(
            repo, Unused(), Unused(), KBO(), Unused(), None, {}, [], settled_ids
        )
        assert count == 1
        assert repo.settled_payload["status"] == "void"
        assert repo.settled_payload["away_score"] is None
        assert repo.settled_payload["home_score"] is None
        assert settled_ids == ["free:free-kbo-nogame:void"]

    asyncio.run(scenario())
