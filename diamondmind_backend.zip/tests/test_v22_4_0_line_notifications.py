from __future__ import annotations

import asyncio
from copy import deepcopy
from dataclasses import replace
from datetime import datetime
from types import SimpleNamespace
from zoneinfo import ZoneInfo

import httpx

from app.config import settings
from app.line_messaging import LineMessagingService
from app.main import sync_line_notifications


TAIPEI = ZoneInfo("Asia/Taipei")


def run(coro):
    return asyncio.run(coro)


def test_line_client_uses_broadcast_and_stable_retry_key():
    seen: list[httpx.Request] = []

    def handler(request: httpx.Request) -> httpx.Response:
        seen.append(request)
        return httpx.Response(200, headers={"x-line-request-id": "req-1"}, json={})

    cfg = replace(
        settings,
        line_messaging_enabled_raw=True,
        line_channel_access_token="test-token",
        line_request_retries=0,
    )
    service = LineMessagingService(cfg, transport=httpx.MockTransport(handler))
    try:
        first = run(service.broadcast_text("測試通知", event_key="event-a"))
        second_key = service.retry_key("event-a")
    finally:
        run(service.aclose())

    assert first["status"] == "sent"
    assert first["retry_key"] == second_key
    assert len(seen) == 1
    request = seen[0]
    assert request.url.path == "/v2/bot/message/broadcast"
    assert request.headers["authorization"] == "Bearer test-token"
    assert request.headers["x-line-retry-key"] == second_key
    assert '"type":"text"' in request.content.decode("utf-8")


def test_line_client_treats_accepted_retry_as_success():
    def handler(_request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            409,
            headers={
                "x-line-request-id": "retry-2",
                "x-line-accepted-request-id": "accepted-1",
            },
            json={"message": "The retry key is already accepted"},
        )

    cfg = replace(
        settings,
        line_messaging_enabled_raw=True,
        line_channel_access_token="test-token",
        line_request_retries=0,
    )
    service = LineMessagingService(cfg, transport=httpx.MockTransport(handler))
    try:
        result = run(service.broadcast_text("測試通知", event_key="event-b"))
    finally:
        run(service.aclose())

    assert result["status"] == "already_accepted"
    assert result["accepted_request_id"] == "accepted-1"


def test_line_client_retries_transient_failure_with_same_key():
    attempts: list[str] = []

    def handler(request: httpx.Request) -> httpx.Response:
        attempts.append(request.headers["x-line-retry-key"])
        if len(attempts) == 1:
            return httpx.Response(503, json={"message": "temporary"})
        return httpx.Response(200, headers={"x-line-request-id": "req-ok"}, json={})

    cfg = replace(
        settings,
        line_messaging_enabled_raw=True,
        line_channel_access_token="test-token",
        line_request_retries=1,
        line_retry_backoff_seconds=0.01,
    )
    service = LineMessagingService(cfg, transport=httpx.MockTransport(handler))
    try:
        result = run(service.broadcast_text("測試通知", event_key="event-c"))
    finally:
        run(service.aclose())

    assert result["status"] == "sent"
    assert result["attempts"] == 2
    assert len(attempts) == 2
    assert attempts[0] == attempts[1]


class FakeRecords:
    enabled = True

    def __init__(self, record: dict):
        self.record = deepcopy(record)

    async def list_records(self, *, status=None, limit=None):
        return [deepcopy(self.record)]

    async def list_prediction_packages(self, *, limit=None):
        return []

    async def get_record_for_date(self, recommendation_date: str, league: str):
        if (
            self.record.get("recommendation_date") == recommendation_date
            and self.record.get("league") == league
        ):
            return deepcopy(self.record)
        return None

    async def update_prediction_snapshot_by_id(self, record_id, snapshot):
        assert str(record_id) == str(self.record["id"])
        self.record["prediction_snapshot"] = deepcopy(snapshot)
        return deepcopy(self.record)


class FakeLine:
    enabled = True

    def __init__(self):
        self.messages: list[tuple[str, str]] = []

    def status(self):
        return {
            "enabled": True,
            "configured": True,
            "community_url_configured": True,
        }

    @staticmethod
    def retry_key(event_key: str) -> str:
        return f"retry:{event_key}"

    async def broadcast_text(self, text: str, *, event_key: str):
        self.messages.append((event_key, text))
        return {
            "status": "sent",
            "retry_key": self.retry_key(event_key),
            "request_id": f"request-{len(self.messages)}",
            "attempts": 1,
        }


def test_line_sync_sends_publish_then_settlement_once():
    now = datetime.now(TAIPEI).isoformat()
    record = {
        "id": "free-1",
        "recommendation_date": datetime.now(TAIPEI).date().isoformat(),
        "league": "MLB",
        "published_at": now,
        "settled_at": None,
        "status": "pending",
        "prediction_snapshot": {
            "game_pk": "123",
            "league": "MLB",
            "published_at": now,
            "publication": {
                "published_at": now,
                "status": "published",
            },
            "game": {
                "away": {"name": "Away", "abbr": "AWY"},
                "home": {"name": "Home", "abbr": "HME"},
            },
            "pick": {
                "market": "moneyline",
                "team_name": "Away",
                "abbr": "AWY",
                "label": "Away 獨贏",
            },
        },
    }
    records = FakeRecords(record)
    line = FakeLine()
    app = SimpleNamespace(
        state=SimpleNamespace(
            records=records,
            line=line,
            line_status={},
        )
    )
    request = SimpleNamespace(app=app)

    first = run(sync_line_notifications(request))
    assert first["sent_now"] == 1
    assert len(line.messages) == 1
    assert "每日免費精選已發布" in line.messages[0][1]

    records.record["status"] = "won"
    records.record["settled_at"] = datetime.now(TAIPEI).isoformat()
    records.record["away_score"] = 5
    records.record["home_score"] = 2
    second = run(sync_line_notifications(request))
    assert second["sent_now"] == 1
    assert len(line.messages) == 2
    assert "賽後結算完成" in line.messages[1][1]
    assert "獨贏｜1 中 0 未中" in line.messages[1][1]

    third = run(sync_line_notifications(request))
    assert third["sent_now"] == 0
    assert len(line.messages) == 2
