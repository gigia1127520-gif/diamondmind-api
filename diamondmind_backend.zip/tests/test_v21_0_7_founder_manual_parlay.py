from __future__ import annotations

import pytest

from app.markets import _manual_parlay_candidates, build_selected_market_package


def single(candidate_id: str, game_pk: str, market: str = "moneyline", *, probability: float = 51.0, price: int = -110, formal: bool = False) -> dict:
    side = "over" if market == "totals" else "home"
    line = 8.5 if market == "totals" else (-1.5 if market == "run_line" else None)
    return {
        "candidate_id": candidate_id,
        "league": "MLB",
        "game_pk": game_pk,
        "matchup": f"A{game_pk} @ H{game_pk}",
        "game_date": "2026-07-23T10:00:00Z",
        "market": market,
        "market_basis": "real_odds",
        "pick": {"side": side, "line": line, "label": candidate_id},
        "price": price,
        "decimal_odds": 1.91,
        "model_probability": probability,
        "confidence": probability,
        "rank_score": probability - 50,
        "meets_threshold": formal,
        "candidate_tier": "formal" if formal else "unclassified",
        "odds_source": {
            "type": "real_bookmaker",
            "provider": "Odds-API.io",
            "bookmaker_key": "bet365",
            "bookmaker": "Bet365",
        },
        "game": {"game_pk": game_pk, "league": "MLB", "status": "Scheduled"},
    }


def base_bundle(items: list[dict]) -> dict:
    return {
        "date": "2026-07-23",
        "generated_at": "2026-07-23T00:00:00Z",
        "candidates": {"moneylines": [], "run_lines": [], "totals": [], "parlays": {"two_leg": [], "three_leg": []}},
        "watchlist": {"moneylines": [], "run_lines": [], "totals": []},
        "manual_pool": {
            "moneylines": [item for item in items if item["market"] == "moneyline"],
            "run_lines": [item for item in items if item["market"] == "run_line"],
            "totals": [item for item in items if item["market"] == "totals"],
        },
        "limits": {"moneylines": 10, "run_lines": 10, "totals": 10, "two_leg": 2, "three_leg": 1},
        "model_version": "test",
    }


def test_nonqualified_real_odds_single_is_available_for_manual_parlay() -> None:
    item = single("low-probability", "1", probability=50.2, formal=False)
    pool = _manual_parlay_candidates([item])
    assert len(pool) == 1
    assert pool[0]["candidate_id"] == "low-probability"
    assert pool[0]["candidate_tier"] == "founder_manual_available"


def test_founder_can_build_two_two_leg_and_one_three_leg_parlays() -> None:
    items = [
        single("m1", "1"),
        single("r2", "2", "run_line"),
        single("t3", "3", "totals"),
        single("m4", "4"),
    ]
    package = build_selected_market_package(
        base_bundle(items),
        {
            "manual_two_leg": [["m1", "r2"], ["t3", "m4"]],
            "manual_three_leg": ["m1", "t3", "m4"],
        },
        publication_mode="founder_selected",
    )
    assert package["published"] is True
    assert len(package["parlays"]["two_leg"]) == 2
    assert len(package["parlays"]["three_leg"]) == 1
    assert package["parlays"]["two_leg"][0]["label"] == "2關串關①"
    assert package["parlays"]["two_leg"][1]["label"] == "2關串關②"
    assert package["parlays"]["three_leg"][0]["publication"]["mode"] == "founder_manual_parlay"
    assert package["parlays"]["three_leg"][0]["publication"]["counts_as_ai_formal"] is False


def test_same_game_cannot_appear_twice_in_one_manual_parlay() -> None:
    items = [single("m1", "1"), single("t1", "1", "totals")]
    with pytest.raises(ValueError, match="同一場比賽"):
        build_selected_market_package(
            base_bundle(items),
            {"manual_two_leg": [["m1", "t1"]]},
            publication_mode="founder_selected",
        )


def test_live_game_cannot_be_added_to_manual_parlay() -> None:
    first = single("m1", "1")
    second = single("m2", "2")
    second["game"]["status"] = "Live"
    with pytest.raises(ValueError, match="已開始"):
        build_selected_market_package(
            base_bundle([first, second]),
            {"manual_two_leg": [["m1", "m2"]]},
            publication_mode="founder_selected",
        )


def test_ai_and_manual_parlays_share_the_same_limits() -> None:
    items = [single("m1", "1"), single("m2", "2"), single("m3", "3")]
    bundle = base_bundle(items)
    bundle["candidates"]["parlays"]["two_leg"] = [{
        "candidate_id": "auto-two",
        "market": "2_leg",
        "label": "2關串關",
        "legs": [items[0], items[1]],
        "combined_decimal_odds": 3.65,
        "combined_american_odds": 265,
        "combined_model_probability": 26.0,
    }]
    with pytest.raises(ValueError, match="合計最多只能發布 2 組"):
        build_selected_market_package(
            bundle,
            {
                "two_leg": ["auto-two"],
                "manual_two_leg": [["m1", "m2"], ["m2", "m3"]],
            },
            publication_mode="founder_selected",
        )


def test_second_manual_two_leg_slot_keeps_its_label() -> None:
    items = [single("m1", "1"), single("m2", "2")]
    package = build_selected_market_package(
        base_bundle(items),
        {"manual_two_leg": [[], ["m1", "m2"]]},
        publication_mode="founder_selected",
    )
    assert package["parlays"]["two_leg"][0]["label"] == "2關串關②"
    assert package["parlays"]["two_leg"][0]["publication"]["slot"] == 2
