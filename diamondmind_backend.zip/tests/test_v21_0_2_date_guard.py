from __future__ import annotations

import unittest
from datetime import date

import app.main as main


class DateGuardTests(unittest.TestCase):
    def test_accepts_today_upcoming_game(self):
        game = {
            "game_pk": "cpbl_20260722_213",
            "game_date": "2026-07-22T18:35:00+08:00",
            "status": "upcoming",
            "away": {"score": None},
            "home": {"score": None},
        }
        self.assertTrue(main._asian_game_matches_target_date(game, date(2026, 7, 22)))

    def test_rejects_yesterday_final_even_if_loaded_for_today(self):
        game = {
            "game_pk": "cpbl_20260721_211",
            "game_date": "2026-07-21T18:35:00+08:00",
            "status": "final",
            "away": {"score": 9},
            "home": {"score": 6},
        }
        self.assertFalse(main._asian_game_matches_target_date(game, date(2026, 7, 22)))

    def test_rejects_stale_scores_on_today_game_id(self):
        game = {
            "game_pk": "cpbl_20260722_211",
            "game_date": "2026-07-22T18:35:00+08:00",
            "status": "upcoming",
            "away": {"score": 9},
            "home": {"score": 6},
        }
        self.assertFalse(main._asian_game_matches_target_date(game, date(2026, 7, 22)))

    def test_release_version(self):
        self.assertEqual(main.APP_VERSION, "22.0.0")


if __name__ == "__main__":
    unittest.main(verbosity=2)
