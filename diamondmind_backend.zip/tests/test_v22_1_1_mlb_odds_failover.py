from __future__ import annotations

from datetime import date

import httpx
import pytest

from app import main
from app.config import Settings
from app.odds import OddsUpstreamError
from app.odds_api_io import OddsApiIoService


def settings_for(tmp_path, **overrides):
    values = {
        "odds_api_io_key": "test-key",
        "odds_api_io_daily_limit": 100,
        "odds_api_io_daily_soft_limit": 90,
        "odds_api_io_hourly_limit": 100,
        "odds_api_io_hourly_soft_limit": 90,
        "odds_api_io_quota_ledger_path": str(tmp_path / "quota.json"),
        "odds_api_io_mlb_bookmakers_raw": "Bet365,Unibet",
        "odds_api_io_mlb_max_bookmakers": 2,
    }
    values.update(overrides)
    return Settings(**values)


@pytest.mark.asyncio
async def test_odds_api_io_builds_real_mlb_feed(tmp_path):
    target = date(2026, 7, 27)
    event = {
        "id": 771,
        "date": "2026-07-27T00:10:00Z",
        "home": "Los Angeles Dodgers",
        "away": "New York Yankees",
        "league": {"name": "USA - MLB", "slug": "usa-mlb"},
        "sport": {"name": "Baseball", "slug": "baseball"},
        "status": "pending",
    }

    def handler(request: httpx.Request) -> httpx.Response:
        path = request.url.path
        if path.endswith("/leagues"):
            payload = [{"name": "USA - MLB", "slug": "usa-mlb", "eventsCount": 15}]
        elif path.endswith("/bookmakers/selected"):
            payload = ["Bet365", "Unibet"]
        elif path.endswith("/bookmakers"):
            payload = [{"name": "Bet365"}, {"name": "Unibet"}]
        elif path.endswith("/events"):
            payload = [event]
        elif path.endswith("/odds/multi") or path.endswith("/odds"):
            payload = [{
                **event,
                "bookmakers": {
                    "Bet365": [
                        {"name": "ML", "odds": [{"home": 1.80, "away": 2.10}]},
                        {"name": "Spread", "odds": [{"hdp": -1.5, "home": 2.05, "away": 1.82}]},
                        {"name": "Totals", "odds": [{"hdp": 8.5, "over": 1.91, "under": 1.91}]},
                    ],
                    "Unibet": [
                        {"name": "ML", "odds": [{"home": 1.83, "away": 2.06}]},
                        {"name": "Spread", "odds": [{"hdp": -1.5, "home": 2.02, "away": 1.85}]},
                        {"name": "Totals", "odds": [{"hdp": 8.5, "over": 1.93, "under": 1.89}]},
                    ],
                },
            }]
        else:
            raise AssertionError(f"Unexpected provider path: {path}")
        return httpx.Response(
            200,
            json=payload,
            request=request,
            headers={"x-ratelimit-remaining": "88", "x-ratelimit-limit": "100"},
        )

    service = OddsApiIoService(
        settings_for(tmp_path),
        transport=httpx.MockTransport(handler),
    )
    try:
        feed = await service.odds_for_mlb_date(target)
        assert feed["count"] == 1
        assert feed["meta"]["provider"] == "Odds-API.io"
        assert feed["meta"]["sport_key"] == "baseball_mlb"
        assert feed["meta"]["provider_league"] == "usa-mlb"
        assert feed["meta"]["coverage"] == {
            "moneyline": 1,
            "run_line": 1,
            "totals": 1,
        }
        assert sorted(feed["items"][0]["markets"]) == [
            "moneyline",
            "run_line",
            "totals",
        ]
        assert feed["items"][0]["markets"]["moneyline"]["type"] == "real_bookmaker"
        assert service.status()["last_checks"]["MLB"]["count"] == 1
    finally:
        await service.aclose()


@pytest.mark.asyncio
async def test_mlb_discovery_accepts_both_official_sport_slugs(tmp_path):
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path.endswith("/leagues")
        sport = request.url.params.get("sport")
        payload = (
            [{"name": "MLB Regular Season", "slug": "mlb-regular-season"}]
            if sport == "mlb"
            else []
        )
        return httpx.Response(200, json=payload, request=request)

    service = OddsApiIoService(
        settings_for(tmp_path, odds_api_io_mlb_sport="baseball"),
        transport=httpx.MockTransport(handler),
    )
    try:
        discovery = await service.discover_mlb()
        assert discovery["supported"] is True
        assert discovery["provider_sport"] == "mlb"
        assert discovery["sports_checked"] == ["baseball", "mlb"]
        assert discovery["league"]["slug"] == "mlb-regular-season"
    finally:
        await service.aclose()


@pytest.mark.asyncio
async def test_mlb_feed_uses_fallback_after_primary_failure(monkeypatch):
    class Primary:
        enabled = True

        async def odds_for_date(self, target_date):
            raise OddsUpstreamError("primary unavailable")

    class Fallback:
        enabled = True

        async def odds_for_mlb_date(self, target_date, *, priority=False):
            return {
                "date": target_date.isoformat(),
                "count": 1,
                "items": [{"markets": {"moneyline": {"type": "real_bookmaker"}}}],
                "meta": {
                    "provider": "Odds-API.io",
                    "fresh_for_model": True,
                    "coverage": {"moneyline": 1, "run_line": 0, "totals": 0},
                },
            }

    monkeypatch.setattr(main, "odds_service", lambda request: Primary())
    monkeypatch.setattr(main, "odds_api_io_service", lambda request: Fallback())

    feed = await main.mlb_odds_feed_for_date(
        object(),
        date(2026, 7, 27),
        priority=True,
    )
    assert feed["meta"]["provider"] == "Odds-API.io"
    assert feed["meta"]["fallback_activated"] is True
    assert feed["meta"]["provider_chain"] == ["The Odds API", "Odds-API.io"]
    assert feed["meta"]["fallback_reason"] == "OddsUpstreamError"


@pytest.mark.asyncio
async def test_founder_reports_started_schedule_before_querying_odds(monkeypatch):
    class Repository:
        async def get_record_for_date(self, target_date, league):
            return None

    class MLB:
        async def games_for_date(self, target_date):
            return {
                "date": target_date.isoformat(),
                "items": [
                    {"game_pk": 1, "status": "live"},
                    {"game_pk": 2, "status": "final"},
                ],
            }

    class Primary:
        enabled = True

        async def odds_for_date(self, target_date):
            raise AssertionError("Odds must not be queried after every game has started")

    class Fallback:
        enabled = True

    monkeypatch.setattr(main, "records_repository", lambda request: Repository())
    monkeypatch.setattr(main, "service", lambda request: MLB())
    monkeypatch.setattr(main, "odds_service", lambda request: Primary())
    monkeypatch.setattr(main, "odds_api_io_service", lambda request: Fallback())

    bundle = await main.founder_market_candidate_bundle(
        object(),
        date(2026, 7, 26),
        "MLB",
    )
    assert bundle["available"] is False
    assert bundle["failure_stage"] == "schedule"
    assert bundle["retryable"] is False
    assert bundle["diagnostics"]["schedule"] == {
        "status": "confirmed",
        "games": 2,
        "upcoming": 0,
        "live": 1,
        "final": 1,
    }
    assert "均已開賽或結束" in bundle["message"]


def test_release_version():
    assert main.APP_VERSION == "22.1.2"
