from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
INDEX = ROOT / "frontend" / "index.html"


class V18144FrontendRegressionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.frontend = INDEX.read_text()

    def test_original_member_interface_is_preserved(self):
        for page_id in ("homePage", "gamesPage", "predictionPage", "recordsPage", "morePage"):
            self.assertIn(f'id="{page_id}"', self.frontend)
        self.assertIn('class="bottom-nav"', self.frontend)
        self.assertIn('diamondmind-version" content="18.14.4"', self.frontend)

    def test_founder_console_remains_integrated_in_index(self):
        self.assertIn('id="founderMarketCandidates"', self.frontend)
        self.assertIn('id="founderPredictionTitle"', self.frontend)
        self.assertIn('data-auth-admin', self.frontend)
        self.assertNotIn('assets/shared.js', self.frontend)
        self.assertNotIn('assets/member.js', self.frontend)

    def test_ev_controls_are_additive(self):
        for text in (
            'EV 發布規則', '保守 EV', '市場公平機率', '等待真實盤口',
            'confirm_value_override', 'confirm_anomaly_review', 'AI 趨勢推薦',
        ):
            self.assertIn(text, self.frontend)

    def test_all_leagues_remain_available(self):
        for league in ('MLB', 'NPB', 'KBO', 'CPBL'):
            self.assertIn(f'value="{league}"', self.frontend)

    def test_complete_score_guard_is_still_present(self):
        self.assertIn('賽果同步中', self.frontend)
        self.assertIn('awayScore!==null&&homeScore!==null', self.frontend)

    def test_mobile_safe_area_and_auth_session_are_preserved(self):
        self.assertIn('env(safe-area-inset-bottom)', self.frontend)
        self.assertIn('diamondmind.auth.session.v1', self.frontend)


if __name__ == '__main__':
    unittest.main()
