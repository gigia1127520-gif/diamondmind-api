from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
MEMBER = ROOT / 'frontend'


class V21FrontendTests(unittest.TestCase):
    def test_member_site_is_modular_and_admin_separate(self):
        index = MEMBER.joinpath('index.html').read_text()
        self.assertIn('assets/shared.js?v=21.0.0', index)
        self.assertIn('assets/member.js?v=21.0.0', index)
        self.assertIn('admin.html', index)
        self.assertNotIn('PRO PUBLISH CONTROL', index)
        self.assertNotIn('founder-console', index)

    def test_existing_auth_session_is_preserved(self):
        shared = MEMBER.joinpath('assets/shared.js').read_text()
        admin = MEMBER.joinpath('assets/admin-v21.js').read_text()
        self.assertIn('diamondmind.auth.session.v1', shared)
        self.assertIn('diamondmind.auth.session.v1', admin)

    def test_member_site_uses_live_health_and_quality(self):
        member = MEMBER.joinpath('assets/member.js').read_text()
        self.assertIn('/health', member)
        self.assertIn('/model/status', member)
        self.assertIn('/system/data-quality', member)
        self.assertIn('/announcements/active?placement=home', member)
        self.assertIn('loadGameDetail', member)

    def test_mobile_navigation_safe_area(self):
        styles = MEMBER.joinpath('assets/styles.css').read_text()
        self.assertIn('env(safe-area-inset-bottom)', styles)
        self.assertIn('--nav-h', styles)


if __name__ == '__main__':
    unittest.main()
