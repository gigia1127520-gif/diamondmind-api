from pathlib import Path


def test_version_and_healthz_route():
    text = Path('app/main.py').read_text(encoding='utf-8')
    assert 'APP_VERSION = "22.2.1"' in text
    assert '@app.get("/healthz"' in text
    assert 'def platform_healthz()' in text
    assert '/api/v1/ready' not in text or 'settings.api_prefix}/ready' in text


def test_render_uses_lightweight_health_check():
    text = Path('render.yaml').read_text(encoding='utf-8')
    assert 'healthCheckPath: /healthz' in text


def test_workers_are_supervised():
    text = Path('app/main.py').read_text(encoding='utf-8')
    assert 'WorkerRegistry' in text
    assert '"pregame_refresh"' in text
    assert '"settlement_scheduler"' in text
    assert '"model_calibration"' in text
