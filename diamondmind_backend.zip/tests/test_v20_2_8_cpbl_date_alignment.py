from __future__ import annotations

import asyncio
import unittest
from datetime import date

from app.asian_baseball import AsianBaseballService, cpbl_expected_game_count, parse_cpbl_schedule
from app.config import Settings
import app.main as main


SHIFTED_PAGE = """
<main>
  <h2>賽程</h2><div>7/21 週二</div><button>昨日</button><button>今日</button><button>明日</button>
  <a><div>一軍例行賽</div><span>台鋼雄鷹</span><span>9</span><span>中信兄弟</span><span>6</span><span>GAME</span><span>211</span><span>已結束</span><span>18:35</span><span>洲際</span></a>
  <a><div>一軍例行賽</div><span>樂天桃猿</span><span>2</span><span>味全龍</span><span>3</span><span>GAME</span><span>212</span><span>已結束</span><span>18:35</span><span>大巨蛋</span></a>
  <h1>賽程列表</h1>
  <section><h3>7月22日,星期三</h3><p>共 2 場</p>
    <div>GAME 211 已結束</div><div>台鋼雄鷹</div><div>9</div><div>中信兄弟</div><div>6</div><div>洲際</div><div>18:35</div>
    <div>GAME 212 已結束</div><div>樂天桃猿</div><div>2</div><div>味全龍</div><div>3</div><div>大巨蛋</div><div>18:35</div>
  </section>
  <section><h3>7月23日,星期四</h3><p>共 3 場</p>
    <div>GAME 213 未開始</div><div>台鋼雄鷹</div><div>vs</div><div>洲際</div><div>18:35</div><div>中信兄弟</div>
    <div>GAME 214 未開始</div><div>樂天桃猿</div><div>vs</div><div>大巨蛋</div><div>18:35</div><div>味全龍</div>
    <div>GAME 215 未開始</div><div>富邦悍將</div><div>vs</div><div>亞太主</div><div>18:35</div><div>統一7-ELEVEn獅</div>
  </section>
</main>
"""


class CpblDateAlignmentTests(unittest.TestCase):
    def test_previous_day_finals_do_not_leak_into_requested_day(self):
        games = parse_cpbl_schedule(SHIFTED_PAGE, date(2026, 7, 22), "official")
        self.assertEqual(len(games), 3)
        self.assertEqual([game["game_pk"] for game in games], [
            "cpbl_20260722_213", "cpbl_20260722_214", "cpbl_20260722_215",
        ])
        self.assertTrue(all(game["status"] == "upcoming" for game in games))
        self.assertEqual({game["official_source_date"] for game in games}, {"2026-07-23"})
        self.assertEqual({game["date_correction_days"] for game in games}, {-1})

    def test_actual_previous_day_keeps_completed_scores(self):
        games = parse_cpbl_schedule(SHIFTED_PAGE, date(2026, 7, 21), "official")
        self.assertEqual(len(games), 2)
        self.assertEqual([(g["away"]["score"], g["home"]["score"]) for g in games], [(9, 6), (2, 3)])
        self.assertTrue(all(game["status"] == "final" for game in games))

    def test_expected_count_uses_translated_monthly_date(self):
        self.assertEqual(cpbl_expected_game_count(SHIFTED_PAGE, date(2026, 7, 22)), 3)
        self.assertEqual(cpbl_expected_game_count(SHIFTED_PAGE, date(2026, 7, 21)), 2)

    def test_no_shift_when_provider_dates_are_aligned(self):
        html = """
        <div>7/22 週三</div>
        <div>一軍例行賽</div><div>台鋼雄鷹</div><div>中信兄弟</div><div>GAME 213 未開始</div><div>18:35</div><div>洲際</div>
        <div>賽程列表</div>
        <div>7月22日,星期三</div><div>共 1 場</div>
        <div>GAME 213 未開始</div><div>台鋼雄鷹</div><div>vs</div><div>洲際</div><div>18:35</div><div>中信兄弟</div>
        """
        games = parse_cpbl_schedule(html, date(2026, 7, 22), "official")
        self.assertEqual(len(games), 1)
        self.assertEqual(games[0]["date_correction_days"], 0)
        self.assertEqual(games[0]["game_pk"], "cpbl_20260722_213")

    def test_service_meta_exposes_alignment_diagnosis(self):
        class TestService(AsianBaseballService):
            async def _get_html(self):
                return SHIFTED_PAGE

        service = TestService(Settings(), "CPBL")
        payload = asyncio.run(service.games_for_date(date(2026, 7, 22)))
        self.assertEqual(payload["count"], 3)
        self.assertEqual(payload["meta"]["parser_status"], "ok")
        self.assertEqual(payload["meta"]["expected_count"], 3)
        self.assertEqual(payload["meta"]["official_source_dates"], ["2026-07-23"])
        self.assertEqual(payload["meta"]["date_correction_days"], [-1])

    def test_release_version(self):
        self.assertEqual(main.APP_VERSION, "21.0.0")


if __name__ == "__main__":
    unittest.main(verbosity=2)
