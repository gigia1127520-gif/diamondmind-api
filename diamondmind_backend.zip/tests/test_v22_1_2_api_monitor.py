from __future__ import annotations

from datetime import date
from types import SimpleNamespace

import pytest

from app import main


def test_monitor_error_redacts_query_credentials():
    error = RuntimeError(
        "provider failed: apiKey=secret-value&league=MLB token=other-secret"
    )

    safe = main._monitor_safe_error(error)

    assert safe["type"] == "RuntimeError"
    assert "secret-value" not in safe["message"]
    assert "other-secret" not in safe["message"]
    assert "apiKey=***" in safe["message"]
    assert "token=***" in safe["message"]


def test_monitor_effective_mlb_status_prefers_usable_fallback():
    primary = {
        "configured": True,
        "last_checks": {
            "MLB": {
                "checked_at": "2026-07-26T02:20:00Z",
                "count": 15,
                "last_error": "OddsUpstreamError",
                "coverage": {"moneyline": 15, "run_line": 15, "totals": 15},
            }
        },
    }
    fallback = {
        "configured": True,
        "last_checks": {
            "MLB": {
                "checked_at": "2026-07-26T02:21:00Z",
                "count": 15,
                "last_error": "one bookmaker was unavailable",
                "coverage": {"moneyline": 15, "run_line": 15, "totals": 14},
                "quota": {"remaining": 94, "limit": 100},
            }
        },
    }

    status = main._monitor_effective_mlb_status(primary, fallback)

    assert status["available"] is True
    assert status["provider"] == "Odds-API.io"
    assert status["count"] == 15
    assert status["coverage"]["totals"] == 14
    assert status["providers"][0]["usable"] is False
    assert status["providers"][1]["usable"] is True


@pytest.mark.asyncio
async def test_api_monitor_reports_release_and_provider_chain(monkeypatch):
    async def founder(_request, _authorization):
        return {"role": "admin"}

    class StatusService:
        def __init__(self, payload):
            self.payload = payload

        def status(self):
            return self.payload

    primary = {
        "configured": True,
        "last_checks": {
            "MLB": {
                "checked_at": "2026-07-26T02:20:00Z",
                "count": 0,
                "last_error": "OddsUpstreamError",
            }
        },
    }
    fallback = {
        "configured": True,
        "last_checks": {
            "MLB": {
                "checked_at": "2026-07-26T02:21:00Z",
                "count": 15,
                "coverage": {"moneyline": 15, "run_line": 15, "totals": 14},
            }
        },
    }
    monkeypatch.setattr(main, "admin_member", founder)
    monkeypatch.setattr(main, "odds_service", lambda _request: StatusService(primary))
    monkeypatch.setattr(
        main,
        "odds_api_io_service",
        lambda _request: StatusService(fallback),
    )
    request = SimpleNamespace(
        app=SimpleNamespace(
            state=SimpleNamespace(
                worker_supervisor_status={},
                api_monitor_history=[],
            )
        )
    )

    payload = await main.admin_api_monitor(request, "Bearer founder")

    assert payload["version"] == "22.4.0"
    assert payload["services"]["mlb_effective"]["provider"] == "Odds-API.io"
    assert len(payload["services"]["mlb_effective"]["providers"]) == 2


@pytest.mark.asyncio
async def test_founder_can_run_selected_league_api_test(monkeypatch):
    async def founder(_request, _authorization):
        return {"role": "admin"}

    class ScheduleService:
        async def games_for_date(self, target):
            return {
                "date": target.isoformat(),
                "items": [
                    {"status": "upcoming"},
                    {"status": "upcoming"},
                    {"status": "final"},
                ],
                "meta": {"cache": "fresh", "updated_at": "2026-07-26T02:21:00Z"},
            }

    async def mlb_feed(_request, target, *, priority=False):
        assert target == date(2026, 7, 27)
        assert priority is True
        return {
            "count": 2,
            "items": [{}, {}],
            "meta": {
                "fresh_for_model": True,
                "provider": "Odds-API.io",
                "provider_chain": ["The Odds API", "Odds-API.io"],
                "fallback_activated": True,
                "coverage": {"moneyline": 2, "run_line": 2, "totals": 1},
                "coverage_status": "available",
                "cache": "feed_cache",
                "quota": {"remaining": 92, "limit": 100},
            },
        }

    monkeypatch.setattr(main, "admin_member", founder)
    monkeypatch.setattr(
        main,
        "baseball_service",
        lambda _request, league: ScheduleService(),
    )
    monkeypatch.setattr(main, "mlb_odds_feed_for_date", mlb_feed)
    request = SimpleNamespace(
        app=SimpleNamespace(state=SimpleNamespace(api_monitor_history=[]))
    )
    command = main.ApiMonitorTestCommand(
        league="MLB",
        target_date=date(2026, 7, 27),
    )

    payload = await main.admin_api_monitor_test(
        request,
        command,
        "Bearer founder",
    )

    assert payload["ok"] is True
    assert payload["ready"] is True
    assert payload["schedule"]["count"] == 3
    assert payload["odds"]["provider"] == "Odds-API.io"
    assert payload["odds"]["fallback_activated"] is True
    assert request.app.state.api_monitor_history[0] == payload


def test_release_version():
    assert main.APP_VERSION == "22.4.0"
