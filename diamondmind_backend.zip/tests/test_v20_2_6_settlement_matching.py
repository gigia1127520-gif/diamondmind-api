from __future__ import annotations

import asyncio
import inspect
import unittest
from datetime import date

from app.asian_baseball import AsianBaseballService
from app.config import Settings
from app.records import settlement_for, settle_market_selection
import app.main as main


class AsianSettlementMatchingTests(unittest.TestCase):
    def run_async(self, coro):
        return asyncio.run(coro)

    def test_cpbl_resolves_final_result_on_provider_plus_one_date(self):
        service = AsianBaseballService(Settings(), "CPBL")
        pending = {
            "league": "CPBL", "game_pk": "cpbl_20260721_211",
            "game_date": "2026-07-21T18:35:00+08:00", "status": "result_pending",
            "detailed_status": "Result Pending",
            "away": {"id": "HAWKS", "name": "TSG Hawks", "name_zh": "台鋼雄鷹", "abbr": "TSG", "score": None},
            "home": {"id": "BROTHERS", "name": "CTBC Brothers", "name_zh": "中信兄弟", "abbr": "CTB", "score": None},
        }
        final = {
            **pending,
            "game_pk": "cpbl_20260722_211",
            "game_date": "2026-07-22T18:35:00+08:00",
            "status": "final", "detailed_status": "Final",
            "away": {**pending["away"], "score": 9},
            "home": {**pending["home"], "score": 6},
        }

        async def fake_games_for_date(target):
            if target == date(2026, 7, 21):
                return {"items": [pending]}
            if target == date(2026, 7, 22):
                return {"items": [final]}
            return {"items": []}

        service.games_for_date = fake_games_for_date
        selection = {
            "game": {
                "away": {"name": "台鋼雄鷹"},
                "home": {"name": "中信兄弟"},
            }
        }

        async def scenario():
            try:
                result = await service.game_result("cpbl_20260721_211", selection)
                self.assertEqual(result["status"], "final")
                self.assertEqual(result["away"]["score"], 9)
                self.assertEqual(result["settlement_match"]["date_offset_days"], 1)
                self.assertIn("cpbl_game_number", result["settlement_match"]["method"])
                self.assertTrue(result["settlement_match"]["provider_date_offset_only"])
                settled = settlement_for({
                    "game_datetime": "2026-07-21T18:35:00+08:00",
                    "pick_team_name": "台鋼雄鷹",
                }, result)
                self.assertEqual(settled["status"], "won")
            finally:
                await service.aclose()

        self.run_async(scenario())

    def test_kbo_resolves_regenerated_sequence_by_normalized_matchup(self):
        service = AsianBaseballService(Settings(), "KBO")
        final = {
            "league": "KBO", "game_pk": "kbo_20260721_SSG_LOTTE_4",
            "game_date": "2026-07-21T18:30:00+08:00", "status": "final",
            "detailed_status": "Final",
            "away": {"id": "SSG", "name": "SSG Landers", "name_zh": "SSG登陸者", "abbr": "SSG", "score": 4},
            "home": {"id": "LOTTE", "name": "Lotte Giants", "name_zh": "樂天巨人", "abbr": "LOT", "score": 2},
        }

        async def fake_games_for_date(target):
            return {"items": [final]} if target == date(2026, 7, 21) else {"items": []}

        service.games_for_date = fake_games_for_date
        selection = {
            "game": {
                "away": {"name": "SSG Landers"},
                "home": {"name_zh": "樂天巨人"},
            }
        }

        async def scenario():
            try:
                result = await service.game_result("kbo_20260721_SSG_LOTTE_1", selection)
                self.assertEqual(result["game_pk"], "kbo_20260721_SSG_LOTTE_4")
                self.assertIn("normalized_matchup", result["settlement_match"]["method"])
            finally:
                await service.aclose()

        self.run_async(scenario())

    def test_public_settlement_accepts_stored_name_against_official_key(self):
        record = {
            "game_datetime": "2026-07-21T18:35:00+08:00",
            "pick_team_id": "CTBC Brothers",
            "pick_team_name": "中信兄弟",
            "pick_team_abbr": "CTB",
        }
        game = {
            "game_date": "2026-07-21T18:35:00+08:00", "status": "final", "detailed_status": "Final",
            "away": {"id": "HAWKS", "name": "TSG Hawks", "name_zh": "台鋼雄鷹", "abbr": "TSG", "score": 9},
            "home": {"id": "BROTHERS", "name": "CTBC Brothers", "name_zh": "中信兄弟", "abbr": "CTB", "score": 6},
        }
        result = settlement_for(record, game)
        self.assertIsNotNone(result)
        self.assertEqual(result["status"], "lost")

    def test_run_line_accepts_localized_team_identity(self):
        selection = {
            "game_date": "2026-07-21T18:35:00+08:00",
            "market": "run_line",
            "candidate_id": "rl-1",
            "pick": {"market": "run_line", "team_name": "味全龍", "line": -1.5},
        }
        game = {
            "game_date": "2026-07-21T18:35:00+08:00", "status": "final", "detailed_status": "Final",
            "away": {"id": "MONKEYS", "name": "Rakuten Monkeys", "name_zh": "樂天桃猿", "score": 2},
            "home": {"id": "DRAGONS", "name": "Wei Chuan Dragons", "name_zh": "味全龍", "score": 4},
        }
        result = settle_market_selection(selection, game)
        self.assertIsNotNone(result)
        self.assertEqual(result["status"], "won")


    def test_free_cpbl_record_is_persisted_after_alias_resolution(self):
        record = {
            "id": "free-1", "status": "pending", "league": "CPBL",
            "game_pk": "cpbl_20260721_211", "game_datetime": "2026-07-21T18:35:00+08:00",
            "matchup": "台鋼雄鷹 @ 中信兄弟",
            "pick_team_id": "CTBC Brothers", "pick_team_name": "中信兄弟", "pick_team_abbr": "CTB",
            "prediction_snapshot": {
                "league": "CPBL", "game_pk": "cpbl_20260721_211",
                "game_date": "2026-07-21T18:35:00+08:00",
                "pick": {"team_name": "中信兄弟", "market": "moneyline"},
                "publication": {"status": "published", "is_active": True},
            },
        }
        final = {
            "game_pk": "cpbl_20260722_211", "game_date": "2026-07-22T18:35:00+08:00",
            "status": "final", "detailed_status": "Final",
            "away": {"id": "HAWKS", "name": "TSG Hawks", "name_zh": "台鋼雄鷹", "score": 9},
            "home": {"id": "BROTHERS", "name": "CTBC Brothers", "name_zh": "中信兄弟", "score": 6},
            "settlement_match": {"provider_date_offset_only": True, "method": "cpbl_game_number+normalized_matchup"},
        }

        class Repo:
            enabled = True
            settled_payload = None
            async def list_records(self, **kwargs): return [record]
            async def settle(self, game_pk, payload):
                self.settled_payload = payload
                return {**record, **payload}
            async def update_prediction_snapshot(self, *args): return None
            async def reconcile_prediction(self, *args): return None

        class CPBL:
            async def game_result(self, game_pk, selection=None): return final

        class Unused:
            async def game_result(self, *args, **kwargs): raise AssertionError("unused adapter")

        async def scenario():
            repo = Repo()
            diagnostics = []
            settled_ids = []
            count = await main._settle_pending_records_with(
                repo, Unused(), Unused(), Unused(), CPBL(), None, {}, diagnostics, settled_ids
            )
            self.assertEqual(count, 1)
            self.assertEqual(repo.settled_payload["status"], "lost")
            self.assertEqual(settled_ids, ["free:free-1:lost"])
            self.assertTrue(any(item.get("status") == "settled" for item in diagnostics))

        self.run_async(scenario())

    def test_status_keeps_scheduler_fields_and_suppresses_duplicate_social(self):
        source = inspect.getsource(main._run_external_settlement_job)
        self.assertIn("scheduler_last_check", source)
        self.assertIn("duplicate_settlement_notification_suppressed", source)
        self.assertIn("settlement_diagnostics", source)

    def test_release_version(self):
        self.assertEqual(main.APP_VERSION, "21.1.1")


if __name__ == "__main__":
    unittest.main(verbosity=2)
