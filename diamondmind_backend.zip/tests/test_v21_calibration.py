from __future__ import annotations

import math
import unittest

from app import main
from app.calibration import (
    CalibrationRegistry,
    apply_platt,
    apply_registry_to_selection,
    build_calibration_candidate,
    calibration_metrics,
    fit_platt,
)
from app.data_quality import audit_games


class CalibrationMathTests(unittest.TestCase):
    def test_release_version(self):
        self.assertEqual(main.APP_VERSION, "21.0.1")

    def test_platt_fit_improves_overconfident_sample(self):
        probabilities = []
        labels = []
        # Deliberately overconfident: 0.78 group wins 62%; 0.22 group wins 38%.
        for index in range(100):
            probabilities.append(0.78)
            labels.append(1 if index < 62 else 0)
        for index in range(100):
            probabilities.append(0.22)
            labels.append(1 if index < 38 else 0)
        slope, intercept = fit_platt(probabilities, labels)
        raw = calibration_metrics(probabilities, labels)
        calibrated = calibration_metrics([apply_platt(p, slope, intercept) for p in probabilities], labels)
        self.assertLess(calibrated["brier"], raw["brier"])
        self.assertLess(calibrated["log_loss"], raw["log_loss"])
        self.assertGreater(slope, 0.25)
        self.assertLess(slope, 1.0)

    def test_registry_hierarchical_fallback(self):
        registry = CalibrationRegistry.from_rows([
            {"id": "global", "league": "GLOBAL", "market": "all", "slope": 0.9, "intercept": 0, "status": "active"},
            {"id": "kbo", "league": "KBO", "market": "all", "slope": 0.8, "intercept": 0.1, "status": "active"},
            {"id": "kbo-total", "league": "KBO", "market": "totals", "slope": 0.7, "intercept": -0.1, "status": "active"},
        ])
        exact, source = registry.resolve("KBO", "totals")
        self.assertEqual(exact["id"], "kbo-total")
        self.assertEqual(source, "league_market")
        league, source = registry.resolve("KBO", "moneyline")
        self.assertEqual(league["id"], "kbo")
        self.assertEqual(source, "league")
        global_profile, source = registry.resolve("CPBL", "moneyline")
        self.assertEqual(global_profile["id"], "global")
        self.assertEqual(source, "global")

    def test_selection_recalculates_edge_and_integrity(self):
        registry = CalibrationRegistry.from_rows([
            {"id": "cpbl", "league": "CPBL", "market": "moneyline", "slope": 0.8, "intercept": 0, "status": "active", "version": "v1"}
        ])
        selection = {
            "league": "CPBL",
            "game_pk": "213",
            "game_date": "2026-07-22T10:35:00Z",
            "matchup": "TSG @ CTB",
            "market": "moneyline",
            "market_basis": "real_odds",
            "pick": {"side": "away", "label": "TSG"},
            "model_probability": 65,
            "implied_probability": 55,
            "price": -122,
            "odds_source": {"type": "real_bookmaker", "bookmaker": "Bet365"},
            "data_quality": 0.8,
            "meets_threshold": True,
        }
        result = apply_registry_to_selection(selection, registry, minimum_probability=53, minimum_edge=3)
        self.assertEqual(result["raw_model_probability"], 65.0)
        self.assertTrue(result["calibration"]["applied"])
        self.assertTrue(result["data_integrity"]["publish_safe"])
        self.assertAlmostEqual(result["edge"], result["model_probability"] - 55.0, places=1)

    def test_candidate_uses_chronological_validation(self):
        rows = []
        for index in range(90):
            probability = 70 if index % 2 == 0 else 30
            won = (index % 10) < (6 if probability == 70 else 4)
            rows.append({
                "recommendation_date": f"2026-{(index // 28) + 1:02d}-{(index % 28) + 1:02d}",
                "league": "MLB",
                "market": "moneyline",
                "status": "won" if won else "lost",
                "confidence": probability,
                "publication_snapshot": {"counts_as_ai_formal": True},
                "is_test": False,
            })
        candidate = build_calibration_candidate(rows, league="MLB", market="moneyline", minimum_sample=60, minimum_validation_sample=18)
        self.assertTrue(candidate["ready"])
        self.assertGreaterEqual(candidate["validation_sample"], 18)
        self.assertIn(candidate["reason"], {"validation_improved", "validation_not_improved"})


class DataQualityTests(unittest.TestCase):
    def test_css_noise_and_missing_score_are_detected(self):
        report = audit_games([
            {
                "game_pk": "211",
                "date_taiwan": "2026-07-21",
                "status": "final",
                "away": {"name": "台鋼雄鷹", "abbr": "TSG", "score": 9},
                "home": {"name": "中信兄弟", "abbr": "CTB"},
                "venue": ".css-abc{display:flex;--chakra-colors-x:red}",
            }
        ], league="CPBL", expected_date="2026-07-21")
        item = report["items"][0]
        self.assertFalse(item["checks"]["score_complete_if_final"])
        self.assertFalse(item["checks"]["clean_venue"])
        self.assertFalse(item["publish_safe"])


if __name__ == "__main__":
    unittest.main()
