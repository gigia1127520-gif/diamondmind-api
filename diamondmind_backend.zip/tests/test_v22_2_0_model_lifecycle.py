from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace

import pytest

from app import main
from app.calibration import CalibrationRegistry
from app.runtime import RequestMetrics


def test_v22_2_release_and_worker_roles_are_present():
    source = Path("app/main.py").read_text(encoding="utf-8")
    worker = Path("app/worker.py").read_text(encoding="utf-8")

    assert main.APP_VERSION == "22.3.0"
    assert '"api": set()' in source
    assert '"publish": {"publish", "retry"}' in source
    assert "DIAMONDMIND_PROCESS_ROLE" in worker


def test_request_metrics_are_bounded_and_secret_free():
    metrics = RequestMetrics(max_events=100)
    metrics.record(
        method="GET",
        route="/api/v1/admin/model/lifecycle",
        status_code=200,
        duration_ms=12.5,
    )
    metrics.record(
        method="POST",
        route="/api/v1/admin/model/challenger/run",
        status_code=503,
        duration_ms=37.5,
    )

    snapshot = metrics.snapshot()

    assert snapshot["requests"] == 2
    assert snapshot["errors"] == 1
    assert snapshot["average_ms"] == 25.0
    assert all("query" not in item for item in snapshot["top_routes"])


@pytest.mark.asyncio
async def test_force_run_never_auto_promotes_without_explicit_override():
    captured: dict = {}

    class FakePerformance:
        enabled = True

        async def auto_calibrate(self, **kwargs):
            captured.update(kwargs)
            return {
                "ok": True,
                "status": "completed",
                "completed_at": "2026-07-26T04:00:00Z",
                "rows_scanned": 100,
                "candidates": [],
                "promoted": [],
                "promoted_count": 0,
            }

        async def calibration_registry(self):
            return CalibrationRegistry.empty()

    app = SimpleNamespace(
        state=SimpleNamespace(
            performance=FakePerformance(),
            calibration_lock=__import__("asyncio").Lock(),
            calibration_status={},
            calibration_registry=CalibrationRegistry.empty(),
        )
    )

    result = await main._run_auto_calibration(
        app,
        reason="founder_test",
        force=True,
        promote_override=None,
    )

    assert result["ok"] is True
    assert captured["promote"] is False


@pytest.mark.asyncio
async def test_lifecycle_separates_production_and_test(monkeypatch):
    async def founder(_request, _authorization):
        return {"id": "founder", "role": "admin"}

    class FakeRepository:
        async def list_calibration_profiles(self, *, active_only=False):
            assert active_only is False
            return [
                {"id": "champion", "status": "active", "version": "prod-v1"},
                {"id": "history", "status": "superseded", "version": "prod-v0"},
            ]

        async def list_calibration_runs(self, *, limit):
            assert limit == 20
            return [
                {
                    "id": "run-1",
                    "status": "completed",
                    "candidates": [{"league": "MLB", "market": "moneyline"}],
                    "promoted": [{"league": "MLB", "market": "moneyline"}],
                }
            ]

        async def active_profile(self):
            return None

    monkeypatch.setattr(main, "admin_member", founder)
    monkeypatch.setattr(main, "performance_repository", lambda _request: FakeRepository())
    request = SimpleNamespace(
        app=SimpleNamespace(
            state=SimpleNamespace(calibration_status={"status": "completed"})
        )
    )

    payload = await main.admin_model_lifecycle(request, "Bearer founder")

    assert payload["mode"] == "production_test"
    assert payload["policy"]["automatic_deploy"] is False
    assert payload["production_profiles"][0]["id"] == "champion"
    assert payload["latest_test_run"]["id"] == "run-1"
    assert payload["latest_test_run"]["candidates"][0]["deployed"] is True


@pytest.mark.asyncio
async def test_lifecycle_keeps_weight_test_separate_from_probability_test(monkeypatch):
    async def founder(_request, _authorization):
        return {"id": "founder", "role": "admin"}

    weights = {
        "team_strength": 0.16,
        "starter": 0.28,
        "lineup": 0.25,
        "bullpen": 0.15,
        "advanced": 0.12,
        "environment": 0.04,
    }

    class FakeRepository:
        async def list_calibration_profiles(self, *, active_only=False):
            return []

        async def list_calibration_runs(self, *, limit):
            return [
                {
                    "id": "weight-run",
                    "status": "completed",
                    "candidates": [{
                        "kind": "weight_profile",
                        "league": "GLOBAL",
                        "market": "weights",
                        "weights": weights,
                        "ready": True,
                        "promote": True,
                    }],
                    "promoted": [],
                },
                {
                    "id": "probability-run",
                    "status": "completed",
                    "candidates": [{
                        "league": "MLB",
                        "market": "moneyline",
                        "ready": True,
                        "promote": True,
                    }],
                    "promoted": [],
                },
            ]

        async def active_profile(self):
            return {"id": "weights-active", "weights": weights}

    monkeypatch.setattr(main, "admin_member", founder)
    monkeypatch.setattr(main, "performance_repository", lambda _request: FakeRepository())
    request = SimpleNamespace(
        app=SimpleNamespace(
            state=SimpleNamespace(calibration_status={"status": "completed"})
        )
    )

    payload = await main.admin_model_lifecycle(request, "Bearer founder")

    assert payload["latest_test_run"]["id"] == "probability-run"
    assert payload["latest_weight_test_run"]["id"] == "weight-run"
    assert payload["latest_weight_test_run"]["candidates"][0]["deployed"] is True
    assert payload["production_weight_profile"]["id"] == "weights-active"


@pytest.mark.asyncio
async def test_weight_apply_creates_test_without_changing_runtime(monkeypatch):
    async def founder(_request, _authorization):
        return {"id": "founder", "role": "admin"}

    created: dict = {}

    class FakeRepository:
        async def list_snapshots(self, **_kwargs):
            rows = []
            for index in range(40):
                won = index % 2 == 0
                rows.append({
                    "status": "won" if won else "lost",
                    "market": "moneyline",
                    "is_test": False,
                    "module_scores": {
                        key: {
                            "edge_for_pick": 0.08 if won else -0.04,
                            "quality": 0.8,
                        }
                        for key in main.DEFAULT_MODEL_WEIGHTS
                    },
                })
            return rows

        async def create_weight_challenger(self, **kwargs):
            created.update(kwargs)
            return {
                "run": {"id": "weight-run"},
                "candidate": {
                    "kind": "weight_profile",
                    "weights": kwargs["weights"],
                },
            }

    monkeypatch.setattr(main, "admin_member", founder)
    monkeypatch.setattr(main, "performance_repository", lambda _request: FakeRepository())
    original = dict(main.DEFAULT_MODEL_WEIGHTS)
    request = SimpleNamespace(
        app=SimpleNamespace(
            state=SimpleNamespace(mlb=SimpleNamespace(model_weights=dict(original)))
        )
    )
    command = main.ModelWeightCommand(
        weights={
            **original,
            "team_strength": 0.20,
            "lineup": 0.21,
        },
        confirm=True,
    )

    payload = await main.admin_apply_model_calibration(
        request,
        command,
        "Bearer founder",
    )

    assert payload["mode"] == "test"
    assert payload["deployed"] is False
    assert created["calibration"]["ready"] is True
    assert request.app.state.mlb.model_weights == original


@pytest.mark.asyncio
async def test_weight_deploy_changes_runtime_only_after_confirmation(monkeypatch):
    async def founder(_request, _authorization):
        return {"id": "founder", "role": "admin"}

    deployed: dict = {}
    weights = {
        "team_strength": 0.16,
        "starter": 0.28,
        "lineup": 0.25,
        "bullpen": 0.15,
        "advanced": 0.12,
        "environment": 0.04,
    }

    class FakeRepository:
        async def get_calibration_run(self, run_id):
            return {
                "id": run_id,
                "candidates": [{
                    "kind": "weight_profile",
                    "weights": weights,
                    "ready": True,
                    "promote": True,
                }],
                "promoted": [],
            }

        async def activate_weights(self, **kwargs):
            deployed["activated"] = kwargs
            return {"id": "weight-profile"}

        async def record_weight_promotion(self, **kwargs):
            deployed["promotion"] = kwargs

    monkeypatch.setattr(main, "admin_member", founder)
    monkeypatch.setattr(main, "performance_repository", lambda _request: FakeRepository())
    request = SimpleNamespace(
        app=SimpleNamespace(
            state=SimpleNamespace(
                mlb=SimpleNamespace(model_weights=dict(main.DEFAULT_MODEL_WEIGHTS)),
                calibration_status={},
            )
        )
    )

    payload = await main.admin_deploy_model_calibration(
        request,
        main.ModelWeightDeployCommand(run_id="weight-run", confirm=True),
        "Bearer founder",
    )

    assert payload["mode"] == "production"
    assert request.app.state.mlb.model_weights == main.normalize_weights(weights)
    assert deployed["promotion"]["run_id"] == "weight-run"


@pytest.mark.asyncio
async def test_challenger_deploy_requires_founder_confirmation(monkeypatch):
    async def founder(_request, _authorization):
        return {"id": "founder", "role": "admin"}

    monkeypatch.setattr(main, "admin_member", founder)
    request = SimpleNamespace(app=SimpleNamespace(state=SimpleNamespace()))
    command = main.ModelChallengerDeployCommand(
        run_id="run-1",
        league="MLB",
        market="moneyline",
        confirm=False,
    )

    with pytest.raises(main.HTTPException) as exc:
        await main.admin_model_challenger_deploy(
            request,
            command,
            "Bearer founder",
        )

    assert exc.value.status_code == 409


@pytest.mark.asyncio
async def test_challenger_cannot_be_deployed_twice(monkeypatch):
    async def founder(_request, _authorization):
        return {"id": "founder", "role": "admin"}

    class FakeRepository:
        async def get_calibration_run(self, run_id):
            assert run_id == "run-1"
            return {
                "id": run_id,
                "status": "completed",
                "candidates": [
                    {
                        "league": "MLB",
                        "market": "moneyline",
                        "ready": True,
                        "promote": True,
                        "slope": 1.2,
                        "intercept": -0.1,
                        "sample": 70,
                        "train_sample": 50,
                        "validation_sample": 20,
                    }
                ],
                "promoted": [],
            }

        async def list_calibration_profiles(self, *, active_only=False):
            assert active_only is False
            return [
                {
                    "league": "MLB",
                    "market": "moneyline",
                    "slope": 1.2,
                    "intercept": -0.1,
                    "sample": 70,
                    "train_sample": 50,
                    "validation_sample": 20,
                    "status": "active",
                }
            ]

    monkeypatch.setattr(main, "admin_member", founder)
    monkeypatch.setattr(main, "performance_repository", lambda _request: FakeRepository())
    request = SimpleNamespace(app=SimpleNamespace(state=SimpleNamespace()))
    command = main.ModelChallengerDeployCommand(
        run_id="run-1",
        league="MLB",
        market="moneyline",
        confirm=True,
    )

    with pytest.raises(main.HTTPException) as exc:
        await main.admin_model_challenger_deploy(
            request,
            command,
            "Bearer founder",
        )

    assert exc.value.status_code == 409
    assert "不能重複部署" in str(exc.value.detail)


def test_candidate_profile_fallback_detects_missing_promotion_marker():
    run = {"promoted": []}
    candidate = {
        "league": "GLOBAL",
        "market": "all",
        "slope": 1.23456789,
        "intercept": -0.12345678,
        "sample": 70,
        "train_sample": 50,
        "validation_sample": 20,
    }
    profile = {
        "league": "GLOBAL",
        "market": "all",
        "slope": 1.23456789,
        "intercept": -0.12345678,
        "sample": 70,
        "train_sample": 50,
        "validation_sample": 20,
        "status": "active",
    }

    assert main._calibration_candidate_was_deployed(
        run,
        candidate,
        [profile],
    ) is True
