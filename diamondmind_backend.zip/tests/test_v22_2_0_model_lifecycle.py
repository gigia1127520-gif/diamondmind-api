from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace

import pytest

from app import main
from app.calibration import CalibrationRegistry
from app.runtime import RequestMetrics


def test_v22_2_release_and_worker_roles_are_present():
    source = Path("app/main.py").read_text(encoding="utf-8")
    worker = Path("app/worker.py").read_text(encoding="utf-8")

    assert main.APP_VERSION == "22.2.1"
    assert '"api": set()' in source
    assert '"publish": {"publish", "retry"}' in source
    assert "DIAMONDMIND_PROCESS_ROLE" in worker


def test_request_metrics_are_bounded_and_secret_free():
    metrics = RequestMetrics(max_events=100)
    metrics.record(
        method="GET",
        route="/api/v1/admin/model/lifecycle",
        status_code=200,
        duration_ms=12.5,
    )
    metrics.record(
        method="POST",
        route="/api/v1/admin/model/challenger/run",
        status_code=503,
        duration_ms=37.5,
    )

    snapshot = metrics.snapshot()

    assert snapshot["requests"] == 2
    assert snapshot["errors"] == 1
    assert snapshot["average_ms"] == 25.0
    assert all("query" not in item for item in snapshot["top_routes"])


@pytest.mark.asyncio
async def test_force_run_never_auto_promotes_without_explicit_override():
    captured: dict = {}

    class FakePerformance:
        enabled = True

        async def auto_calibrate(self, **kwargs):
            captured.update(kwargs)
            return {
                "ok": True,
                "status": "completed",
                "completed_at": "2026-07-26T04:00:00Z",
                "rows_scanned": 100,
                "candidates": [],
                "promoted": [],
                "promoted_count": 0,
            }

        async def calibration_registry(self):
            return CalibrationRegistry.empty()

    app = SimpleNamespace(
        state=SimpleNamespace(
            performance=FakePerformance(),
            calibration_lock=__import__("asyncio").Lock(),
            calibration_status={},
            calibration_registry=CalibrationRegistry.empty(),
        )
    )

    result = await main._run_auto_calibration(
        app,
        reason="founder_test",
        force=True,
        promote_override=None,
    )

    assert result["ok"] is True
    assert captured["promote"] is False


@pytest.mark.asyncio
async def test_lifecycle_separates_production_and_test(monkeypatch):
    async def founder(_request, _authorization):
        return {"id": "founder", "role": "admin"}

    class FakeRepository:
        async def list_calibration_profiles(self, *, active_only=False):
            assert active_only is False
            return [
                {"id": "champion", "status": "active", "version": "prod-v1"},
                {"id": "history", "status": "superseded", "version": "prod-v0"},
            ]

        async def list_calibration_runs(self, *, limit):
            assert limit == 20
            return [
                {
                    "id": "run-1",
                    "status": "completed",
                    "candidates": [{"league": "MLB", "market": "moneyline"}],
                    "promoted": [{"league": "MLB", "market": "moneyline"}],
                }
            ]

    monkeypatch.setattr(main, "admin_member", founder)
    monkeypatch.setattr(main, "performance_repository", lambda _request: FakeRepository())
    request = SimpleNamespace(
        app=SimpleNamespace(
            state=SimpleNamespace(calibration_status={"status": "completed"})
        )
    )

    payload = await main.admin_model_lifecycle(request, "Bearer founder")

    assert payload["mode"] == "production_test"
    assert payload["policy"]["automatic_deploy"] is False
    assert payload["production_profiles"][0]["id"] == "champion"
    assert payload["latest_test_run"]["id"] == "run-1"
    assert payload["latest_test_run"]["candidates"][0]["deployed"] is True


@pytest.mark.asyncio
async def test_challenger_deploy_requires_founder_confirmation(monkeypatch):
    async def founder(_request, _authorization):
        return {"id": "founder", "role": "admin"}

    monkeypatch.setattr(main, "admin_member", founder)
    request = SimpleNamespace(app=SimpleNamespace(state=SimpleNamespace()))
    command = main.ModelChallengerDeployCommand(
        run_id="run-1",
        league="MLB",
        market="moneyline",
        confirm=False,
    )

    with pytest.raises(main.HTTPException) as exc:
        await main.admin_model_challenger_deploy(
            request,
            command,
            "Bearer founder",
        )

    assert exc.value.status_code == 409


@pytest.mark.asyncio
async def test_challenger_cannot_be_deployed_twice(monkeypatch):
    async def founder(_request, _authorization):
        return {"id": "founder", "role": "admin"}

    class FakeRepository:
        async def get_calibration_run(self, run_id):
            assert run_id == "run-1"
            return {
                "id": run_id,
                "status": "completed",
                "candidates": [
                    {
                        "league": "MLB",
                        "market": "moneyline",
                        "ready": True,
                        "promote": True,
                    }
                ],
                "promoted": [{"league": "MLB", "market": "moneyline"}],
            }

    monkeypatch.setattr(main, "admin_member", founder)
    monkeypatch.setattr(main, "performance_repository", lambda _request: FakeRepository())
    request = SimpleNamespace(app=SimpleNamespace(state=SimpleNamespace()))
    command = main.ModelChallengerDeployCommand(
        run_id="run-1",
        league="MLB",
        market="moneyline",
        confirm=True,
    )

    with pytest.raises(main.HTTPException) as exc:
        await main.admin_model_challenger_deploy(
            request,
            command,
            "Bearer founder",
        )

    assert exc.value.status_code == 409
    assert "不能重複部署" in str(exc.value.detail)
