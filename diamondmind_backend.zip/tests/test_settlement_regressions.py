from __future__ import annotations

import unittest
from copy import deepcopy
from datetime import date
from types import SimpleNamespace

from app.npb import _merge_scoreboard
from app.main import (
    _package_result_for_selection,
    _settle_pending_prediction_packages_with,
    sync_existing_model_snapshots,
)
from app.records import (
    _parlay_result,
    build_package_payload,
    reopen_rescheduled_package_results,
    settle_market_selection,
    settle_prediction_package,
)


def game(
    game_pk: str,
    *,
    status: str,
    detailed_status: str,
    away_score: int | None = None,
    home_score: int | None = None,
) -> dict:
    return {
        "game_pk": game_pk,
        "status": status,
        "detailed_status": detailed_status,
        "away": {"id": "A", "score": away_score},
        "home": {"id": "H", "score": home_score},
    }


def moneyline(game_pk: str, candidate_id: str, team_id: str = "A") -> dict:
    return {
        "candidate_id": candidate_id,
        "game_pk": game_pk,
        "market": "moneyline",
        "price": -110,
        "pick": {"team_id": team_id, "market": "moneyline"},
    }


class NPBMergeRegressionTests(unittest.TestCase):
    def test_monthly_score_row_cannot_downgrade_daily_final(self) -> None:
        daily = [{
            "game_pk": "npb_20260717_D_G",
            "status": "final",
            "detailed_status": "Final",
            "inning": 9,
            "inning_state": "End",
            "venue": "Tokyo Dome",
            "away": {"short_name": "Chunichi", "score": 1},
            "home": {"short_name": "Yomiuri", "score": 4},
            "source_url": "daily",
        }]
        monthly = [{
            "game_pk": "npb_20260717_D_G",
            "status": "live",
            "detailed_status": "4 - 1",
            "inning": None,
            "inning_state": "",
            "venue": "Tokyo Dome",
            "away": {"short_name": "Chunichi", "score": 1},
            "home": {"short_name": "Yomiuri", "score": 4},
            "source_url": "monthly",
        }]

        merged = _merge_scoreboard(deepcopy(daily), monthly, date(2026, 7, 17), "daily")

        self.assertEqual(merged[0]["status"], "final")
        self.assertEqual(merged[0]["detailed_status"], "Final")
        self.assertEqual(merged[0]["away"]["score"], 1)
        self.assertEqual(merged[0]["home"]["score"], 4)


class ResultIdentityRegressionTests(unittest.TestCase):
    def test_sparse_results_never_fall_back_to_another_candidate_position(self) -> None:
        package = {
            "results": {
                "moneylines": [{"candidate_id": "padres", "status": "lost"}],
                "two_leg": [{"candidate_id": "reds-padres", "status": "lost"}],
            }
        }

        self.assertEqual(
            _package_result_for_selection(package, "moneylines", {"candidate_id": "tigers"}, 0)["status"],
            "pending",
        )
        self.assertEqual(
            _package_result_for_selection(package, "two_leg", {"candidate_id": "reds-pirates"}, 0)["status"],
            "pending",
        )


class IncrementalPerformanceSyncTests(unittest.IsolatedAsyncioTestCase):
    async def test_partial_package_advances_completed_model_snapshots(self) -> None:
        won_selection = moneyline("101", "won-selection")
        pending_selection = moneyline("102", "pending-selection")
        record = build_package_payload(
            "2026-07-18",
            {
                "moneylines": [won_selection, pending_selection],
                "parlays": {},
                "publication": {"mode": "founder_selected"},
            },
        )
        record.update({"id": "package-1", "settled": False})

        class Repository:
            enabled = True

            async def list_prediction_packages(self, **_kwargs):
                return [record]

            async def settle_prediction_package(self, _record_id, payload):
                return {**record, **(payload or {})}

        class MLB:
            async def game_result(self, game_pk):
                if game_pk == 101:
                    return game("101", status="final", detailed_status="Final", away_score=2, home_score=1)
                return game("102", status="final", detailed_status="Postponed")

        class Performance:
            def __init__(self):
                self.calls = []

            async def settle_package(self, source_record_id, result):
                self.calls.append((source_record_id, result))

        performance = Performance()
        settled_count = await _settle_pending_prediction_packages_with(
            Repository(), MLB(), object(), performance
        )

        self.assertEqual(settled_count, 0)
        self.assertEqual(len(performance.calls), 1)
        source_record_id, result = performance.calls[0]
        self.assertEqual(source_record_id, "package-1")
        self.assertFalse(result["settled"])
        self.assertEqual(result["results"]["moneylines"][0]["candidate_id"], "won-selection")
        self.assertEqual(result["results"]["moneylines"][0]["status"], "won")

    async def test_dashboard_backfill_repairs_partial_package_snapshots(self) -> None:
        selection = moneyline("101", "won-selection")
        record = build_package_payload(
            "2026-07-18",
            {
                "moneylines": [selection],
                "parlays": {},
                "publication": {"mode": "founder_selected"},
            },
        )
        record.update({
            "id": "package-1",
            "settled": False,
            "results": {"moneylines": [{"candidate_id": "won-selection", "status": "won"}]},
        })

        class Repository:
            enabled = True

            async def list_records(self, **_kwargs):
                return []

            async def list_pending_prediction_packages(self):
                return [record]

            async def list_settled_prediction_packages(self, **_kwargs):
                return []

        class Performance:
            enabled = True

            def __init__(self):
                self.settled = []

            async def capture_package(self, *_args):
                return None

            async def settle_package(self, source_record_id, result):
                self.settled.append((source_record_id, result))

        performance = Performance()
        request = SimpleNamespace(
            app=SimpleNamespace(
                state=SimpleNamespace(records=Repository(), performance=performance)
            )
        )

        result = await sync_existing_model_snapshots(request)

        self.assertEqual(result["packages"], 1)
        self.assertEqual(performance.settled[0][0], "package-1")
        self.assertEqual(
            performance.settled[0][1]["results"]["moneylines"][0]["status"],
            "won",
        )


class ParlaySettlementRegressionTests(unittest.TestCase):
    def setUp(self) -> None:
        self.won = game("won", status="final", detailed_status="Final", away_score=2, home_score=1)
        self.lost = game("lost", status="final", detailed_status="Final", away_score=1, home_score=2)
        self.postponed = game("postponed", status="final", detailed_status="Postponed")

    def test_won_plus_postponed_stays_pending_in_either_order(self) -> None:
        won_leg = moneyline("won", "won-leg")
        pending_leg = moneyline("postponed", "pending-leg")
        games = {"won": self.won, "postponed": self.postponed}

        for legs in ([won_leg, pending_leg], [pending_leg, won_leg]):
            with self.subTest(order=[leg["game_pk"] for leg in legs]):
                self.assertIsNone(_parlay_result({"candidate_id": "p", "legs": legs}, games))

    def test_lost_plus_postponed_is_lost_in_either_order(self) -> None:
        lost_leg = moneyline("lost", "lost-leg")
        pending_leg = moneyline("postponed", "pending-leg")
        games = {"lost": self.lost, "postponed": self.postponed}

        for legs in ([lost_leg, pending_leg], [pending_leg, lost_leg]):
            with self.subTest(order=[leg["game_pk"] for leg in legs]):
                result = _parlay_result({"candidate_id": "p", "legs": legs}, games)
                self.assertIsNotNone(result)
                self.assertEqual(result["status"], "lost")

    def test_officially_cancelled_leg_is_void_not_lost(self) -> None:
        cancelled = game("cancelled", status="final", detailed_status="Cancelled")
        result = settle_market_selection(moneyline("cancelled", "cancelled-leg"), cancelled)

        self.assertIsNotNone(result)
        self.assertEqual(result["status"], "void")

    def test_old_false_loss_is_reopened_for_won_plus_postponed(self) -> None:
        parlay = {
            "candidate_id": "won-plus-postponed",
            "legs": [moneyline("won", "won-leg"), moneyline("postponed", "pending-leg")],
        }
        record = build_package_payload(
            "2026-07-18",
            {"parlays": {"two_leg": [parlay]}, "publication": {"mode": "founder_selected"}},
        )
        record["results"] = {"two_leg": [{"candidate_id": parlay["candidate_id"], "status": "lost"}]}
        games = {"won": self.won, "postponed": self.postponed}

        reconciled, reopened = reopen_rescheduled_package_results(record, games)
        settlement = settle_prediction_package(reconciled, games)

        self.assertEqual(reopened, {parlay["candidate_id"]})
        self.assertFalse(settlement["settled"])
        self.assertNotIn("two_leg", settlement["results"])

    def test_confirmed_loss_remains_terminal_while_other_leg_is_postponed(self) -> None:
        parlay = {
            "candidate_id": "lost-plus-postponed",
            "legs": [moneyline("postponed", "pending-leg"), moneyline("lost", "lost-leg")],
        }
        record = build_package_payload(
            "2026-07-18",
            {"parlays": {"two_leg": [parlay]}, "publication": {"mode": "founder_selected"}},
        )
        record["results"] = {"two_leg": [{"candidate_id": parlay["candidate_id"], "status": "lost"}]}
        games = {"lost": self.lost, "postponed": self.postponed}

        reconciled, reopened = reopen_rescheduled_package_results(record, games)
        settlement = settle_prediction_package(reconciled, games)

        self.assertFalse(reopened)
        self.assertEqual(settlement["results"]["two_leg"][0]["status"], "lost")


if __name__ == "__main__":
    unittest.main()
