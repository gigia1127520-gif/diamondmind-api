from __future__ import annotations

import json
import unittest
from copy import deepcopy
from datetime import date
from types import SimpleNamespace

import httpx

from app.config import Settings
from app.npb import _merge_scoreboard
from app.main import (
    _package_result_for_selection,
    _settle_pending_prediction_packages_with,
    settlement_dashboard,
    sync_existing_model_snapshots,
)
from app.records import (
    _parlay_result,
    SupabaseRecordsRepository,
    build_record_payload,
    build_package_payload,
    reopen_rescheduled_package_results,
    settle_market_selection,
    settle_prediction_package,
)


def game(
    game_pk: str,
    *,
    status: str,
    detailed_status: str,
    away_score: int | None = None,
    home_score: int | None = None,
) -> dict:
    return {
        "game_pk": game_pk,
        "status": status,
        "detailed_status": detailed_status,
        "away": {"id": "A", "score": away_score},
        "home": {"id": "H", "score": home_score},
    }


def moneyline(game_pk: str, candidate_id: str, team_id: str = "A") -> dict:
    return {
        "candidate_id": candidate_id,
        "game_pk": game_pk,
        "market": "moneyline",
        "price": -110,
        "pick": {"team_id": team_id, "market": "moneyline"},
    }


def public_pick(league: str, game_pk: str) -> dict:
    return {
        "league": league,
        "game_pk": game_pk,
        "game_date": "2026-07-18T10:00:00Z",
        "time_taiwan": "07/18 18:00",
        "matchup": f"{league} Away @ {league} Home",
        "game": {
            "league": league,
            "venue": "Test Park",
            "away": {"id": f"{league}-A", "name": f"{league} Away", "abbr": "AWY"},
            "home": {"id": f"{league}-H", "name": f"{league} Home", "abbr": "HME"},
        },
        "pick": {
            "team_id": f"{league}-A",
            "team_name": f"{league} Away",
            "abbr": "AWY",
            "label": f"{league} Away 獨贏",
            "market": "moneyline",
        },
        "opponent": {
            "team_id": f"{league}-H",
            "team_name": f"{league} Home",
            "abbr": "HME",
        },
        "publication": {"league": league, "status": "published"},
        "confidence": 60.0,
    }


class TwoLeagueFreePickTests(unittest.IsolatedAsyncioTestCase):
    def test_record_payload_keeps_the_selected_league(self) -> None:
        mlb = build_record_payload("2026-07-18", public_pick("MLB", "101"))
        npb = build_record_payload("2026-07-18", public_pick("NPB", "npb-101"))

        self.assertEqual(mlb["league"], "MLB")
        self.assertEqual(npb["league"], "NPB")
        self.assertEqual(mlb["recommendation_date"], npb["recommendation_date"])

    async def test_repository_uses_date_and_league_as_the_conflict_key(self) -> None:
        requests: list[dict] = []

        def handler(request: httpx.Request) -> httpx.Response:
            payload = json.loads(request.content.decode()) if request.content else None
            requests.append({
                "method": request.method,
                "params": dict(request.url.params),
                "json": payload,
            })
            if request.method == "POST":
                return httpx.Response(201, json=[{"id": f"row-{payload['league']}", **payload}])
            return httpx.Response(200, json=[])

        repository = SupabaseRecordsRepository(
            Settings(supabase_url="https://test.supabase.co", supabase_secret_key="test-key"),
            transport=httpx.MockTransport(handler),
        )
        try:
            mlb, mlb_created = await repository.publish_prediction_once(
                "2026-07-18", public_pick("MLB", "101")
            )
            npb, npb_created = await repository.publish_prediction_once(
                "2026-07-18", public_pick("NPB", "npb-101")
            )
            await repository.get_record_for_date("2026-07-18", "NPB")
        finally:
            await repository.aclose()

        self.assertTrue(mlb_created)
        self.assertTrue(npb_created)
        self.assertEqual(mlb["league"], "MLB")
        self.assertEqual(npb["league"], "NPB")
        self.assertEqual(requests[0]["params"]["on_conflict"], "recommendation_date,league")
        self.assertEqual(requests[1]["params"]["on_conflict"], "recommendation_date,league")
        self.assertEqual(requests[2]["params"]["league"], "eq.NPB")

    async def test_settlement_dashboard_lists_both_free_picks(self) -> None:
        rows = []
        for league, game_pk in (("MLB", "101"), ("NPB", "npb-101")):
            selection = public_pick(league, game_pk)
            rows.append({
                "id": f"row-{league}",
                "recommendation_date": "2026-07-18",
                "league": league,
                "game_pk": game_pk,
                "matchup": selection["matchup"],
                "pick_label": selection["pick"]["label"],
                "published_at": "2026-07-17T20:00:00Z",
                "status": "pending",
                "prediction_snapshot": selection,
            })

        class Repository:
            enabled = True

            async def list_records_for_date(self, _date):
                return rows

            async def get_prediction_package_for_date(self, _date):
                return None

        class MLB:
            async def game_result(self, _game_pk):
                return game(
                    "101", status="final", detailed_status="Final", away_score=4, home_score=2
                ) | {"away": {"id": "MLB-A", "score": 4}, "home": {"id": "MLB-H", "score": 2}}

        class NPB:
            async def game_result(self, _game_pk):
                return game(
                    "npb-101", status="final", detailed_status="Final", away_score=5, home_score=1
                ) | {"away": {"id": "NPB-A", "score": 5}, "home": {"id": "NPB-H", "score": 1}}

        payload = await settlement_dashboard(Repository(), MLB(), NPB(), date(2026, 7, 18))

        self.assertEqual(len(payload["public_items"]), 2)
        self.assertEqual({item["league"] for item in payload["public_items"]}, {"MLB", "NPB"})
        self.assertEqual(payload["summary"]["total"], 2)
        self.assertEqual(payload["summary"]["won"], 2)


class NPBMergeRegressionTests(unittest.TestCase):
    def test_monthly_score_row_cannot_downgrade_daily_final(self) -> None:
        daily = [{
            "game_pk": "npb_20260717_D_G",
            "status": "final",
            "detailed_status": "Final",
            "inning": 9,
            "inning_state": "End",
            "venue": "Tokyo Dome",
            "away": {"short_name": "Chunichi", "score": 1},
            "home": {"short_name": "Yomiuri", "score": 4},
            "source_url": "daily",
        }]
        monthly = [{
            "game_pk": "npb_20260717_D_G",
            "status": "live",
            "detailed_status": "4 - 1",
            "inning": None,
            "inning_state": "",
            "venue": "Tokyo Dome",
            "away": {"short_name": "Chunichi", "score": 1},
            "home": {"short_name": "Yomiuri", "score": 4},
            "source_url": "monthly",
        }]

        merged = _merge_scoreboard(deepcopy(daily), monthly, date(2026, 7, 17), "daily")

        self.assertEqual(merged[0]["status"], "final")
        self.assertEqual(merged[0]["detailed_status"], "Final")
        self.assertEqual(merged[0]["away"]["score"], 1)
        self.assertEqual(merged[0]["home"]["score"], 4)


class ResultIdentityRegressionTests(unittest.TestCase):
    def test_sparse_results_never_fall_back_to_another_candidate_position(self) -> None:
        package = {
            "results": {
                "moneylines": [{"candidate_id": "padres", "status": "lost"}],
                "two_leg": [{"candidate_id": "reds-padres", "status": "lost"}],
            }
        }

        self.assertEqual(
            _package_result_for_selection(package, "moneylines", {"candidate_id": "tigers"}, 0)["status"],
            "pending",
        )
        self.assertEqual(
            _package_result_for_selection(package, "two_leg", {"candidate_id": "reds-pirates"}, 0)["status"],
            "pending",
        )


class IncrementalPerformanceSyncTests(unittest.IsolatedAsyncioTestCase):
    async def test_partial_package_advances_completed_model_snapshots(self) -> None:
        won_selection = moneyline("101", "won-selection")
        pending_selection = moneyline("102", "pending-selection")
        record = build_package_payload(
            "2026-07-18",
            {
                "moneylines": [won_selection, pending_selection],
                "parlays": {},
                "publication": {"mode": "founder_selected"},
            },
        )
        record.update({"id": "package-1", "settled": False})

        class Repository:
            enabled = True

            async def list_prediction_packages(self, **_kwargs):
                return [record]

            async def settle_prediction_package(self, _record_id, payload):
                return {**record, **(payload or {})}

        class MLB:
            async def game_result(self, game_pk):
                if game_pk == 101:
                    return game("101", status="final", detailed_status="Final", away_score=2, home_score=1)
                return game("102", status="final", detailed_status="Postponed")

        class Performance:
            def __init__(self):
                self.calls = []

            async def settle_package(self, source_record_id, result):
                self.calls.append((source_record_id, result))

        performance = Performance()
        settled_count = await _settle_pending_prediction_packages_with(
            Repository(), MLB(), object(), performance
        )

        self.assertEqual(settled_count, 0)
        self.assertEqual(len(performance.calls), 1)
        source_record_id, result = performance.calls[0]
        self.assertEqual(source_record_id, "package-1")
        self.assertFalse(result["settled"])
        self.assertEqual(result["results"]["moneylines"][0]["candidate_id"], "won-selection")
        self.assertEqual(result["results"]["moneylines"][0]["status"], "won")

    async def test_dashboard_backfill_repairs_partial_package_snapshots(self) -> None:
        selection = moneyline("101", "won-selection")
        record = build_package_payload(
            "2026-07-18",
            {
                "moneylines": [selection],
                "parlays": {},
                "publication": {"mode": "founder_selected"},
            },
        )
        record.update({
            "id": "package-1",
            "settled": False,
            "results": {"moneylines": [{"candidate_id": "won-selection", "status": "won"}]},
        })

        class Repository:
            enabled = True

            async def list_records(self, **_kwargs):
                return []

            async def list_pending_prediction_packages(self):
                return [record]

            async def list_settled_prediction_packages(self, **_kwargs):
                return []

        class Performance:
            enabled = True

            def __init__(self):
                self.settled = []

            async def capture_package(self, *_args):
                return None

            async def settle_package(self, source_record_id, result):
                self.settled.append((source_record_id, result))

        performance = Performance()
        request = SimpleNamespace(
            app=SimpleNamespace(
                state=SimpleNamespace(records=Repository(), performance=performance)
            )
        )

        result = await sync_existing_model_snapshots(request)

        self.assertEqual(result["packages"], 1)
        self.assertEqual(performance.settled[0][0], "package-1")
        self.assertEqual(
            performance.settled[0][1]["results"]["moneylines"][0]["status"],
            "won",
        )


class ParlaySettlementRegressionTests(unittest.TestCase):
    def setUp(self) -> None:
        self.won = game("won", status="final", detailed_status="Final", away_score=2, home_score=1)
        self.lost = game("lost", status="final", detailed_status="Final", away_score=1, home_score=2)
        self.postponed = game("postponed", status="final", detailed_status="Postponed")

    def test_won_plus_postponed_stays_pending_in_either_order(self) -> None:
        won_leg = moneyline("won", "won-leg")
        pending_leg = moneyline("postponed", "pending-leg")
        games = {"won": self.won, "postponed": self.postponed}

        for legs in ([won_leg, pending_leg], [pending_leg, won_leg]):
            with self.subTest(order=[leg["game_pk"] for leg in legs]):
                self.assertIsNone(_parlay_result({"candidate_id": "p", "legs": legs}, games))

    def test_lost_plus_postponed_is_lost_in_either_order(self) -> None:
        lost_leg = moneyline("lost", "lost-leg")
        pending_leg = moneyline("postponed", "pending-leg")
        games = {"lost": self.lost, "postponed": self.postponed}

        for legs in ([lost_leg, pending_leg], [pending_leg, lost_leg]):
            with self.subTest(order=[leg["game_pk"] for leg in legs]):
                result = _parlay_result({"candidate_id": "p", "legs": legs}, games)
                self.assertIsNotNone(result)
                self.assertEqual(result["status"], "lost")

    def test_officially_cancelled_leg_is_void_not_lost(self) -> None:
        cancelled = game("cancelled", status="final", detailed_status="Cancelled")
        result = settle_market_selection(moneyline("cancelled", "cancelled-leg"), cancelled)

        self.assertIsNotNone(result)
        self.assertEqual(result["status"], "void")

    def test_old_false_loss_is_reopened_for_won_plus_postponed(self) -> None:
        parlay = {
            "candidate_id": "won-plus-postponed",
            "legs": [moneyline("won", "won-leg"), moneyline("postponed", "pending-leg")],
        }
        record = build_package_payload(
            "2026-07-18",
            {"parlays": {"two_leg": [parlay]}, "publication": {"mode": "founder_selected"}},
        )
        record["results"] = {"two_leg": [{"candidate_id": parlay["candidate_id"], "status": "lost"}]}
        games = {"won": self.won, "postponed": self.postponed}

        reconciled, reopened = reopen_rescheduled_package_results(record, games)
        settlement = settle_prediction_package(reconciled, games)

        self.assertEqual(reopened, {parlay["candidate_id"]})
        self.assertFalse(settlement["settled"])
        self.assertNotIn("two_leg", settlement["results"])

    def test_confirmed_loss_remains_terminal_while_other_leg_is_postponed(self) -> None:
        parlay = {
            "candidate_id": "lost-plus-postponed",
            "legs": [moneyline("postponed", "pending-leg"), moneyline("lost", "lost-leg")],
        }
        record = build_package_payload(
            "2026-07-18",
            {"parlays": {"two_leg": [parlay]}, "publication": {"mode": "founder_selected"}},
        )
        record["results"] = {"two_leg": [{"candidate_id": parlay["candidate_id"], "status": "lost"}]}
        games = {"lost": self.lost, "postponed": self.postponed}

        reconciled, reopened = reopen_rescheduled_package_results(record, games)
        settlement = settle_prediction_package(reconciled, games)

        self.assertFalse(reopened)
        self.assertEqual(settlement["results"]["two_leg"][0]["status"], "lost")


if __name__ == "__main__":
    unittest.main()
