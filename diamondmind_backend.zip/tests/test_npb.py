from datetime import date, datetime
from zoneinfo import ZoneInfo

from app.npb import _merge_scoreboard, parse_npb_daily_page, parse_npb_japanese_scoreboard


def test_schedule_page_parses_and_converts_japan_time():
    body = """
    <html><body><h3>Regular Season (Schedules)</h3><h4>Saturday, July 18, 2026</h4>
    <div>CENTRAL LEAGUE</div><div>Yomiuri</div><div>Tokyo Dome</div><div>14:00</div><div>Chunichi</div>
    <div>DeNA</div><div>Yokohama</div><div>18:00</div><div>Yakult</div>
    <footer>Copyright (C) NPB</footer></body></html>
    """
    games = parse_npb_daily_page(body, date(2026, 7, 18), "https://npb.jp/example", now=datetime(2026, 7, 18, 10, tzinfo=ZoneInfo("Asia/Taipei")))
    assert len(games) == 2
    assert games[0]["away"]["abbr"] == "D"
    assert games[0]["home"]["abbr"] == "G"
    assert games[0]["time_taiwan"] == "13:00"


def test_score_page_parses_final_scores():
    body = """
    <html><body><h3>Regular Season (Scores)</h3>
    <a href="fs2026071500733.html">Yakult 2 Game 15 Jingu 8 Yomiuri</a>
    <a href="fs2026071500734.html">Nippon-Ham 7 Game 13 ES CON FIELD 6 SoftBank</a>
    </body></html>
    """
    games = parse_npb_daily_page(body, date(2026, 7, 15), "https://npb.jp/bis/eng/2026/games/gm20260715.html")
    assert len(games) == 2
    first = next(game for game in games if game["away"]["abbr"] == "G")
    assert first["status"] == "final"
    assert first["away"]["score"] == 8
    assert first["home"]["score"] == 2


def test_japanese_monthly_scoreboard_overlays_final_result():
    schedule_body = """
    <html><body><h3>Regular Season (Schedules)</h3><h4>Thursday, July 16, 2026</h4>
    <div>PACIFIC LEAGUE</div><div>Nippon-Ham</div><div>ES CON FIELD</div><div>13:00</div><div>SoftBank</div>
    <footer>Copyright (C) NPB</footer></body></html>
    """
    scoreboard_body = """
    <html><body>
      <a href="/scores/2026/0716/f-h-14/">2-6 （エスコンＦ） 試合終了</a>
    </body></html>
    """
    scheduled = parse_npb_daily_page(
        schedule_body,
        date(2026, 7, 16),
        "https://npb.jp/bis/eng/2026/games/gm20260716.html",
        now=datetime(2026, 7, 16, 22, tzinfo=ZoneInfo("Asia/Taipei")),
    )
    scoreboard = parse_npb_japanese_scoreboard(
        scoreboard_body,
        date(2026, 7, 16),
        "https://npb.jp/games/2026/schedule_07_detail.html",
    )
    merged = _merge_scoreboard(
        scheduled,
        scoreboard,
        date(2026, 7, 16),
        "https://npb.jp/bis/eng/2026/games/gm20260716.html",
    )
    assert len(merged) == 1
    assert merged[0]["status"] == "final"
    assert merged[0]["away"]["abbr"] == "H"
    assert merged[0]["away"]["score"] == 6
    assert merged[0]["home"]["abbr"] == "F"
    assert merged[0]["home"]["score"] == 2
    assert merged[0]["time_taiwan"] == "12:00"


def test_japanese_scoreboard_parses_live_inning():
    body = """
    <html><body><a href="/scores/2026/0716/e-b-12/">7-6 （楽天モバイル） 7回裏</a></body></html>
    """
    games = parse_npb_japanese_scoreboard(
        body,
        date(2026, 7, 16),
        "https://npb.jp/games/2026/schedule_07_detail.html",
    )
    assert len(games) == 1
    assert games[0]["status"] == "live"
    assert games[0]["inning"] == 7
    assert games[0]["inning_state"] == "Bottom"
    assert games[0]["away"]["score"] == 6
    assert games[0]["home"]["score"] == 7
