from datetime import date, datetime
from zoneinfo import ZoneInfo

from app.npb import parse_npb_daily_page


def test_schedule_page_parses_and_converts_japan_time():
    body = """
    <html><body><h3>Regular Season (Schedules)</h3><h4>Saturday, July 18, 2026</h4>
    <div>CENTRAL LEAGUE</div><div>Yomiuri</div><div>Tokyo Dome</div><div>14:00</div><div>Chunichi</div>
    <div>DeNA</div><div>Yokohama</div><div>18:00</div><div>Yakult</div>
    <footer>Copyright (C) NPB</footer></body></html>
    """
    games = parse_npb_daily_page(body, date(2026, 7, 18), "https://npb.jp/example", now=datetime(2026, 7, 18, 10, tzinfo=ZoneInfo("Asia/Taipei")))
    assert len(games) == 2
    assert games[0]["away"]["abbr"] == "G"
    assert games[0]["home"]["abbr"] == "D"
    assert games[0]["time_taiwan"] == "13:00"


def test_score_page_parses_final_scores():
    body = """
    <html><body><h3>Regular Season (Scores)</h3>
    <a href="fs2026071500733.html">Yakult 2 Game 15 Jingu 8 Yomiuri</a>
    <a href="fs2026071500734.html">Nippon-Ham 7 Game 13 ES CON FIELD 6 SoftBank</a>
    </body></html>
    """
    games = parse_npb_daily_page(body, date(2026, 7, 15), "https://npb.jp/bis/eng/2026/games/gm20260715.html")
    assert len(games) == 2
    first = next(game for game in games if game["away"]["abbr"] == "S")
    assert first["status"] == "final"
    assert first["away"]["score"] == 2
    assert first["home"]["score"] == 8
