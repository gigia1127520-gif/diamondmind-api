from copy import deepcopy

from app.main import _mark_founder_value_overrides, _selection_for_member, _value_package_errors


def item(decision: str, *, qualified: bool = False, ev: float = 1.0, real_odds: bool = True, available: bool = True, blocked: bool = False, manual_review: bool = False):
    return {
        "candidate_id": f"moneyline:test:{decision}",
        "market": "moneyline",
        "candidate_tier": "formal" if qualified else "watchlist",
        "publication_blocked": blocked,
        "value": {
            "decision": decision,
            "qualified": qualified,
            "conservative_ev_percent": ev,
            "real_odds": real_odds,
            "available": available,
            "manual_review_required": manual_review,
            "reasons": [decision],
        },
    }


def package(selection):
    return {
        "moneylines": [selection],
        "run_lines": [],
        "totals": [],
        "parlays": {"two_leg": [], "three_leg": []},
    }


def test_formal_positive_ev_passes_without_override():
    assert _value_package_errors(package(item("candidate", qualified=True, ev=4.2))) == []


def test_low_positive_and_negative_singles_require_explicit_override():
    low = package(item("watchlist", ev=1.4))
    negative = package(item("blocked_negative_ev", ev=-3.1))
    assert _value_package_errors(low)[0]["overrideable"] is True
    assert _value_package_errors(negative)[0]["overrideable"] is True
    assert _value_package_errors(low, allow_value_override=True) == []
    assert _value_package_errors(negative, allow_value_override=True) == []


def test_waiting_odds_cannot_be_overridden():
    waiting = package(item("unavailable", ev=0, real_odds=False, available=False, blocked=True))
    errors = _value_package_errors(waiting, allow_value_override=True, allow_anomaly_override=True)
    assert len(errors) == 1
    assert errors[0]["overrideable"] is False


def test_anomaly_requires_separate_confirmation():
    anomaly = package(item("manual_review", ev=12.0, manual_review=True))
    errors = _value_package_errors(anomaly, allow_value_override=True)
    assert errors and errors[0]["requires_anomaly_confirmation"] is True
    assert _value_package_errors(anomaly, allow_value_override=True, allow_anomaly_override=True) == []


def test_parlay_never_accepts_founder_override():
    bad_leg = item("blocked_negative_ev", ev=-2.0)
    value_package = {
        "moneylines": [], "run_lines": [], "totals": [],
        "parlays": {"two_leg": [{"candidate_id": "two:1", "legs": [bad_leg]}], "three_leg": []},
    }
    errors = _value_package_errors(value_package, allow_value_override=True, allow_anomaly_override=True)
    assert len(errors) == 1
    assert errors[0]["group"] == "two_leg"
    assert errors[0]["overrideable"] is False


def test_founder_override_is_labelled_as_trend_and_internal_reason_is_hidden_from_members():
    source = package(item("blocked_negative_ev", ev=-2.5))
    stamped = _mark_founder_value_overrides(deepcopy(source), override_reason="internal review note")
    selection = stamped["moneylines"][0]
    assert selection["publication"]["value_override_confirmed"] is True
    assert stamped["publication"]["negative_ev_override_count"] == 1

    member = _selection_for_member(selection, founder=False)
    assert member["recommendation_label"] == "AI 趨勢推薦"
    assert member["publication"]["value_override_confirmed"] is True
    assert "value_override_reason" not in member["publication"]


def test_model_only_candidate_remains_visible_as_waiting_odds():
    from app.calibration import CalibrationRegistry, apply_registry_to_selection

    model_only = {
        "candidate_id": "moneyline:cpbl:model-only",
        "league": "CPBL",
        "game_pk": "cpbl-1",
        "game_date": "2026-07-22T10:35:00Z",
        "matchup": "TSG @ CTB",
        "market": "moneyline",
        "market_basis": "model_only",
        "pick": {"side": "home", "label": "中信兄弟"},
        "model_probability": 61.0,
        "data_quality": 0.8,
        "projection_quality": 0.8,
        "publication_blocked": True,
        "candidate_tier": "waiting_odds",
    }
    result = apply_registry_to_selection(
        model_only,
        CalibrationRegistry.empty(),
        minimum_probability=53,
        minimum_edge=2.5,
        enforce_value=True,
    )
    assert result["candidate_tier"] == "waiting_odds"
    assert result["recommendation_state"] == "waiting_odds"
    assert result["meets_threshold"] is False


def test_free_model_analysis_is_not_forced_through_ev_gate():
    from app.calibration import CalibrationRegistry, apply_registry_to_selection

    free_pick = {
        "candidate_id": "free:npb:model-only",
        "league": "NPB",
        "game_pk": "npb-1",
        "game_date": "2026-07-22T09:00:00Z",
        "matchup": "G @ T",
        "market": "moneyline",
        "market_basis": "model_only",
        "pick": {"side": "home", "label": "阪神"},
        "model_probability": 60.0,
        "data_quality": 0.72,
        "projection_quality": 0.72,
        "qualification_thresholds": {"minimum_probability": 0, "minimum_projection_quality": 0},
    }
    result = apply_registry_to_selection(
        free_pick,
        CalibrationRegistry.empty(),
        enforce_value=False,
    )
    assert result["meets_threshold"] is True
    assert result["candidate_tier"] == "formal"
