from __future__ import annotations

import asyncio
import inspect
import unittest
from datetime import date, datetime
from zoneinfo import ZoneInfo

import httpx

from app.asian_baseball import (
    AsianBaseballService,
    parse_cpbl_schedule,
    parse_kbo_scoreboard_results,
)
from app.config import Settings
import app.main as main


TAIPEI = ZoneInfo("Asia/Taipei")


class ScheduleSanitationTests(unittest.TestCase):
    def run_async(self, coro):
        return asyncio.run(coro)

    def test_cpbl_style_payload_never_becomes_venue(self):
        page = """
        <style>.css-1SW9wh0{background:#5A6773;--chakra-colors-white:#fff;display:flex;}</style>
        <script>window.__CSS__='.css-bad{font-size:12px}'</script>
        <div>7月21日</div><div>共 1 場</div>
        <div>GAME 211 已結束</div><div>台鋼雄鷹</div><div>vs</div>
        <div>洲際</div><div>18:35</div><div>中信兄弟</div><div>3:5</div>
        """
        games = parse_cpbl_schedule(page, date(2026, 7, 21), "https://stats.cpbl.com.tw/schedule")
        self.assertEqual(len(games), 1)
        self.assertEqual(games[0]["venue"], "洲際")
        self.assertEqual(games[0]["status"], "final")
        self.assertNotIn("css", games[0]["venue"].lower())

    def test_kbo_scoreboard_final_pattern(self):
        page = """
        <style>.css-noise{display:flex}</style>
        <div>Image: lotte KIA 2 FINAL 3 DOOSAN Image: doosan</div>
        <div>Image: lotte SSG 4 FINAL 2 LOTTE Image: doosan</div>
        """
        results = parse_kbo_scoreboard_results(page)
        self.assertEqual(results[("KIA", "DOOSAN")]["away_score"], 2)
        self.assertEqual(results[("KIA", "DOOSAN")]["home_score"], 3)
        self.assertEqual(results[("SSG", "LOTTE")]["status"], "final")

    def test_kbo_service_merges_scoreboard_into_schedule(self):
        schedule = """
        <h1>KBO Daily Schedule</h1>
        <table id="tblScheduleList">
          <tr><td>07.21(TUE)</td><td>REGULAR</td><td>18:30</td><td>KIA</td><td>VS</td><td>DOOSAN</td><td>KN-T</td><td>JAMSIL</td><td>-</td></tr>
        </table>
        """
        scoreboard = "<html><h1>Scoreboard</h1><div>KIA 2 FINAL 3 DOOSAN</div></html>"

        def handler(request: httpx.Request) -> httpx.Response:
            if "Scoreboard.aspx" in str(request.url):
                return httpx.Response(200, text=scoreboard)
            return httpx.Response(200, text=schedule)

        settings = Settings(
            kbo_schedule_url="https://example.test/DailySchedule.aspx",
            kbo_scoreboard_url="https://example.test/Scoreboard.aspx",
            request_timeout_seconds=2.0,
        )
        service = AsianBaseballService(settings, "KBO", transport=httpx.MockTransport(handler))

        async def scenario():
            try:
                payload = await service.games_for_date(date(2020, 7, 21))
                self.assertEqual(payload["count"], 1)
                self.assertEqual(payload["items"][0]["status"], "final")
                self.assertEqual(payload["items"][0]["away"]["score"], 2)
                self.assertEqual(payload["items"][0]["home"]["score"], 3)
                self.assertEqual(payload["items"][0]["result_source"], "KBO official scoreboard")
            finally:
                await service.aclose()

        self.run_async(scenario())


class SettlementFallbackTests(unittest.TestCase):
    def test_internal_scheduler_is_background_only(self):
        source = inspect.getsource(main._settlement_scheduler_loop)
        self.assertIn("_queue_settlement_background", source)
        self.assertNotIn("await _run_settlement_pass", source)
        self.assertTrue(main.settings.settlement_internal_scheduler_enabled)

    def test_existing_asian_cron_also_queues_settlement(self):
        source = inspect.getsource(main.asian_auto_publish_job)
        self.assertIn("asian_auto_publish_job", source)
        self.assertIn("_queue_settlement_background", source)

    def test_zero_settlements_do_not_queue_social_retry(self):
        source = inspect.getsource(main._run_external_settlement_job)
        self.assertIn('"no_new_settlements"', source)
        self.assertNotIn('"settlement_retry"', source)

    def test_version(self):
        self.assertEqual(main.APP_VERSION, "20.2.7")


if __name__ == "__main__":
    unittest.main(verbosity=2)
