from __future__ import annotations

import asyncio
import unittest

import app.main as main
from app.records import build_package_payload


class RecordsAndMonitorFixTests(unittest.TestCase):
    def run_async(self, coro):
        return asyncio.run(coro)

    @staticmethod
    def ai_auto_record():
        selection = {
            "candidate_id": "mlb-auto-1",
            "league": "MLB",
            "game_pk": 999001,
            "game_date": "2026-07-23T18:00:00+08:00",
            "matchup": "Away @ Home",
            "market": "moneyline",
            "pick": {"market": "moneyline", "team_name": "Home", "team_id": "HOME", "label": "Home ML"},
            "game": {
                "game_pk": 999001,
                "game_date": "2026-07-23T18:00:00+08:00",
                "away": {"id": "AWAY", "name": "Away", "abbr": "AWY"},
                "home": {"id": "HOME", "name": "Home", "abbr": "HME"},
            },
            "publication": {"mode": "ai_auto", "status": "published", "is_active": True},
            "counts_as_formal_record": True,
            "published_at": "2026-07-23T09:00:00Z",
            "target_date": "2026-07-23",
            "status": "published",
        }
        package = {
            "date": "2026-07-23",
            "published": True,
            "locked": True,
            "generated_at": "2026-07-23T09:00:00Z",
            "moneylines": [selection],
            "run_lines": [],
            "totals": [],
            "parlays": {"two_leg": [], "three_leg": []},
            "publication": {
                "mode": "ai_auto",
                "status": "published",
                "is_active": True,
                "target_date": "2026-07-23",
                "published_at": "2026-07-23T09:00:00Z",
                "league": "MLB",
                "league_batches": {
                    "MLB": {
                        "league": "MLB",
                        "target_date": "2026-07-23",
                        "published_at": "2026-07-23T09:00:00Z",
                        "status": "published",
                        "is_active": True,
                        "game_ids": ["999001"],
                        "recommendation_type": "pro",
                    }
                },
            },
            "recommendation_status": "formal_published",
        }
        record = build_package_payload("2026-07-23", package)
        record.update({"id": "pkg-ai-auto-1", "results": {}, "settled": False})
        return record

    def test_ai_auto_package_is_visible_as_latest_formal_package(self):
        record = self.ai_auto_record()
        selected_record, package, metadata = main._latest_package_for_league([record], "MLB")
        self.assertIs(selected_record, record)
        self.assertEqual((package.get("publication") or {}).get("mode"), "ai_auto")
        self.assertIn(metadata.get("status"), {"published", "live"})

    def test_ai_auto_package_is_settled(self):
        record = self.ai_auto_record()

        class Repo:
            enabled = True
            payload = None
            async def list_prediction_packages(self, **kwargs):
                return [record]
            async def settle_prediction_package(self, record_id, payload):
                self.payload = payload
                return {**record, **(payload or {})}
            async def reconcile_prediction_package(self, record_id, payload):
                self.payload = payload
                return {**record, **(payload or {})}

        class MLB:
            async def game_result(self, game_pk, selection=None):
                return {
                    "game_pk": str(game_pk),
                    "game_date": "2026-07-23T18:00:00+08:00",
                    "status": "final",
                    "detailed_status": "Final",
                    "away": {"id": "AWAY", "name": "Away", "abbr": "AWY", "score": 2},
                    "home": {"id": "HOME", "name": "Home", "abbr": "HME", "score": 5},
                }

        class Unused:
            async def game_result(self, *args, **kwargs):
                raise AssertionError("unused league adapter")

        async def scenario():
            repo = Repo()
            settled_ids = []
            count = await main._settle_pending_prediction_packages_with(
                repo, MLB(), Unused(), Unused(), Unused(), None, {}, [], settled_ids
            )
            self.assertEqual(count, 1)
            self.assertIsNotNone(repo.payload)
            self.assertTrue(repo.payload.get("settled"))
            self.assertEqual(settled_ids, ["pro:pkg-ai-auto-1:settled"])

        self.run_async(scenario())

    def test_release_version(self):
        self.assertEqual(main.APP_VERSION, "22.4.0")


if __name__ == "__main__":
    unittest.main(verbosity=2)
