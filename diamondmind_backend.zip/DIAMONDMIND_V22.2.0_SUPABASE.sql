-- DiamondMind V22.2.0
-- Durable Retry Queue for publish / settlement / model background work.
-- Idempotent: safe to run again in Supabase SQL Editor.

create extension if not exists pgcrypto;

create table if not exists public.system_retry_jobs (
  id uuid primary key default gen_random_uuid(),
  job_type text not null,
  worker_role text not null check (worker_role in ('publish', 'settlement', 'model', 'monitor')),
  payload jsonb not null default '{}'::jsonb,
  status text not null default 'pending'
    check (status in ('pending', 'running', 'completed', 'failed')),
  attempts integer not null default 0 check (attempts >= 0),
  max_attempts integer not null default 5 check (max_attempts > 0),
  dedupe_key text not null unique,
  last_error text,
  next_attempt_at timestamptz not null default now(),
  locked_at timestamptz,
  locked_by text,
  completed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists system_retry_jobs_ready_idx
  on public.system_retry_jobs (worker_role, status, next_attempt_at, created_at);

create or replace function public.diamondmind_retry_jobs_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists system_retry_jobs_updated_at
  on public.system_retry_jobs;

create trigger system_retry_jobs_updated_at
before update on public.system_retry_jobs
for each row execute function public.diamondmind_retry_jobs_updated_at();

create or replace function public.diamondmind_claim_retry_job(
  p_worker_role text,
  p_locked_by text
)
returns setof public.system_retry_jobs
language plpgsql
security definer
set search_path = public
as $$
begin
  return query
  with next_job as (
    select id
    from public.system_retry_jobs
    where worker_role = p_worker_role
      and status = 'pending'
      and attempts < max_attempts
      and next_attempt_at <= now()
    order by next_attempt_at asc, created_at asc
    for update skip locked
    limit 1
  )
  update public.system_retry_jobs as job
  set status = 'running',
      attempts = job.attempts + 1,
      locked_at = now(),
      locked_by = p_locked_by,
      updated_at = now()
  from next_job
  where job.id = next_job.id
  returning job.*;
end;
$$;

alter table public.system_retry_jobs enable row level security;

revoke all on public.system_retry_jobs from anon, authenticated;
grant all on public.system_retry_jobs to service_role;
revoke all on function public.diamondmind_claim_retry_job(text, text)
  from public, anon, authenticated;
grant execute on function public.diamondmind_claim_retry_job(text, text)
  to service_role;

