from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass
from typing import Any


@dataclass
class CacheEntry:
    value: Any
    stored_at: float
    expires_at: float
    stale_until: float

    @property
    def is_fresh(self) -> bool:
        return time.monotonic() < self.expires_at

    @property
    def can_serve_stale(self) -> bool:
        return time.monotonic() < self.stale_until


class AsyncTTLCache:
    """Small in-memory TTL cache with stale-on-error support and request locks."""

    def __init__(self) -> None:
        self._entries: dict[str, CacheEntry] = {}
        self._locks: dict[str, asyncio.Lock] = {}

    def get(self, key: str) -> CacheEntry | None:
        entry = self._entries.get(key)
        if entry and not entry.can_serve_stale:
            self._entries.pop(key, None)
            return None
        return entry

    def set(self, key: str, value: Any, ttl_seconds: int, stale_seconds: int) -> CacheEntry:
        now_monotonic = time.monotonic()
        entry = CacheEntry(
            value=value,
            stored_at=time.time(),
            expires_at=now_monotonic + max(1, ttl_seconds),
            stale_until=now_monotonic + max(ttl_seconds + 1, stale_seconds),
        )
        self._entries[key] = entry
        return entry

    def lock(self, key: str) -> asyncio.Lock:
        if key not in self._locks:
            self._locks[key] = asyncio.Lock()
        return self._locks[key]

    def clear(self) -> None:
        self._entries.clear()

