from __future__ import annotations

import math
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from typing import Any

UTC = timezone.utc
EPS = 1e-9
SUPPORTED_MARKETS = {"moneyline", "run_line", "totals"}


def _float(value: Any) -> float | None:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return number if math.isfinite(number) else None


def _probability(value: Any) -> float | None:
    number = _float(value)
    if number is None:
        return None
    if number > 1.0:
        number /= 100.0
    return min(1.0 - EPS, max(EPS, number))


def _decimal_odds(selection: dict[str, Any]) -> float | None:
    decimal = _float(selection.get("decimal_odds"))
    if decimal is not None and decimal > 1.0:
        return decimal
    price = _float(selection.get("price"))
    if price is None or price == 0:
        return None
    if price < 0:
        return 1.0 + 100.0 / abs(price)
    return 1.0 + price / 100.0


def _parse_time(value: Any) -> datetime | None:
    if not isinstance(value, str) or not value.strip():
        return None
    try:
        parsed = datetime.fromisoformat(value.strip().replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=UTC)
    return parsed.astimezone(UTC)


def _odds_freshness(selection: dict[str, Any], *, now: datetime | None = None) -> tuple[float, float | None]:
    source = selection.get("odds_source") or {}
    updated = _parse_time(source.get("last_update") or selection.get("odds_updated_at"))
    if updated is None:
        return 0.55, None
    current = (now or datetime.now(UTC)).astimezone(UTC)
    age_minutes = max(0.0, (current - updated).total_seconds() / 60.0)
    if age_minutes <= 15:
        factor = 1.0
    elif age_minutes <= 60:
        factor = 0.88
    elif age_minutes <= 180:
        factor = 0.68
    elif age_minutes <= 360:
        factor = 0.50
    else:
        factor = 0.30
    return factor, round(age_minutes, 1)


@dataclass(frozen=True)
class ValuePolicy:
    minimum_ev_percent: float
    minimum_edge_points: float
    minimum_data_quality: float
    anomaly_ev_percent: float = 10.0
    anomaly_edge_points: float = 12.0
    minimum_reliability: float = 0.35
    high_value_ev_percent: float = 6.0

    @classmethod
    def from_mapping(cls, value: dict[str, Any] | None) -> "ValuePolicy":
        raw = value or {}
        return cls(
            minimum_ev_percent=float(raw.get("minimum_ev_percent", 3.0)),
            minimum_edge_points=float(raw.get("minimum_edge_points", 2.5)),
            minimum_data_quality=float(raw.get("minimum_data_quality", 0.80)),
            anomaly_ev_percent=float(raw.get("anomaly_ev_percent", 10.0)),
            anomaly_edge_points=float(raw.get("anomaly_edge_points", 12.0)),
            minimum_reliability=float(raw.get("minimum_reliability", 0.35)),
            high_value_ev_percent=float(raw.get("high_value_ev_percent", 6.0)),
        )


def reliability_score(selection: dict[str, Any], calibration: dict[str, Any] | None = None) -> dict[str, Any]:
    """Estimate how much of the model-market disagreement is safe to trust.

    The score is deliberately conservative. It uses model sample evidence,
    data completeness, integrity checks and odds freshness. The output is used
    only to shrink the calibrated probability toward the no-vig market; it is
    not presented as a probability of winning.
    """
    calibration = calibration or selection.get("calibration") or {}
    data_quality = _float(selection.get("data_quality"))
    if data_quality is None:
        data_quality = _float(selection.get("projection_quality"))
    data_quality = min(1.0, max(0.0, data_quality if data_quality is not None else 0.50))

    sample = _float(calibration.get("sample")) or 0.0
    if calibration.get("applied"):
        sample_factor = min(1.0, math.sqrt(max(0.0, sample) / 200.0))
    else:
        sample_factor = 0.35

    metrics = calibration.get("validation_metrics") or {}
    ece = _float(metrics.get("ece"))
    if ece is None:
        metric_factor = 0.60 if calibration.get("applied") else 0.45
    else:
        metric_factor = min(1.0, max(0.20, 1.0 - ece * 4.0))

    integrity = selection.get("data_integrity") or {}
    integrity_factor = 1.0 if integrity.get("publish_safe") is True else 0.55
    freshness_factor, age_minutes = _odds_freshness(selection)

    score = (
        data_quality * 0.34
        + sample_factor * 0.24
        + metric_factor * 0.16
        + integrity_factor * 0.16
        + freshness_factor * 0.10
    )
    score = min(0.92, max(0.25, score))
    return {
        "score": round(score, 4),
        "data_quality_factor": round(data_quality, 4),
        "sample_factor": round(sample_factor, 4),
        "metric_factor": round(metric_factor, 4),
        "integrity_factor": round(integrity_factor, 4),
        "odds_freshness_factor": round(freshness_factor, 4),
        "odds_age_minutes": age_minutes,
        "calibration_sample": int(sample),
    }


def evaluate_selection_value(
    selection: dict[str, Any],
    *,
    calibrated_probability: Any,
    policy: ValuePolicy | dict[str, Any] | None = None,
    enforce: bool = True,
) -> dict[str, Any]:
    """Calculate edge, raw EV and reliability-shrunk conservative EV.

    Market probability is expected to be the provider's no-vig probability.
    When it is unavailable, break-even probability is used and the result is
    explicitly marked as a fallback so it cannot masquerade as a no-vig edge.
    """
    market = str(selection.get("market") or "moneyline").lower()
    resolved_policy = policy if isinstance(policy, ValuePolicy) else ValuePolicy.from_mapping(policy)
    calibrated = _probability(calibrated_probability)
    decimal = _decimal_odds(selection)
    implied = _probability(selection.get("implied_probability"))
    source = "no_vig_market"
    if implied is None and decimal is not None:
        implied = 1.0 / decimal
        source = "break_even_fallback"

    source_data = selection.get("odds_source") or {}
    real_odds = bool(
        selection.get("market_basis") == "real_odds"
        and source_data.get("type") == "real_bookmaker"
        and decimal is not None
    )
    available = bool(market in SUPPORTED_MARKETS and calibrated is not None and decimal is not None and implied is not None)
    if not available:
        return {
            "available": False,
            "enforced": False,
            "market": market,
            "real_odds": real_odds,
            "decision": "unavailable",
            "reason": "missing_probability_or_odds",
            "policy": asdict(resolved_policy),
        }

    reliability = reliability_score(selection, selection.get("calibration") or {})
    coefficient = float(reliability["score"])
    conservative = implied + coefficient * (calibrated - implied)
    conservative = min(1.0 - EPS, max(EPS, conservative))
    break_even = 1.0 / decimal
    raw_ev = calibrated * decimal - 1.0
    conservative_ev = conservative * decimal - 1.0
    edge_points = (calibrated - implied) * 100.0
    conservative_edge_points = (conservative - implied) * 100.0
    fair_odds = 1.0 / calibrated
    conservative_fair_odds = 1.0 / conservative
    data_quality = _float(selection.get("data_quality"))
    if data_quality is None:
        data_quality = _float(selection.get("projection_quality"))
    data_quality = float(data_quality or 0.0)

    reasons: list[str] = []
    if not real_odds:
        reasons.append("real_odds_required")
    if conservative_ev * 100.0 < 0:
        reasons.append("negative_ev")
    if conservative_ev * 100.0 < resolved_policy.minimum_ev_percent:
        reasons.append("ev_below_threshold")
    if conservative_edge_points < resolved_policy.minimum_edge_points:
        reasons.append("edge_below_threshold")
    if data_quality < resolved_policy.minimum_data_quality:
        reasons.append("data_quality_below_threshold")
    if coefficient < resolved_policy.minimum_reliability:
        reasons.append("reliability_below_threshold")

    anomaly = bool(
        conservative_ev * 100.0 >= resolved_policy.anomaly_ev_percent
        or abs(edge_points) >= resolved_policy.anomaly_edge_points
    )
    if anomaly:
        reasons.append("anomaly_manual_review")

    qualified = bool(real_odds and not reasons)
    if anomaly:
        decision = "manual_review"
    elif conservative_ev < 0:
        decision = "blocked_negative_ev"
    elif qualified and conservative_ev * 100.0 >= resolved_policy.high_value_ev_percent:
        decision = "high_value"
    elif qualified:
        decision = "candidate"
    else:
        decision = "watchlist"

    return {
        "available": True,
        "enforced": bool(enforce and real_odds),
        "market": market,
        "real_odds": real_odds,
        "market_probability_source": source,
        "market_fair_probability": round(implied * 100.0, 2),
        "break_even_probability": round(break_even * 100.0, 2),
        "calibrated_probability": round(calibrated * 100.0, 2),
        "conservative_probability": round(conservative * 100.0, 2),
        "fair_odds": round(fair_odds, 3),
        "conservative_fair_odds": round(conservative_fair_odds, 3),
        "decimal_odds": round(decimal, 3),
        "edge_points": round(edge_points, 2),
        "conservative_edge_points": round(conservative_edge_points, 2),
        "raw_ev_percent": round(raw_ev * 100.0, 2),
        "conservative_ev_percent": round(conservative_ev * 100.0, 2),
        "reliability": reliability,
        "qualified": qualified,
        "decision": decision,
        "manual_review_required": anomaly,
        "reasons": reasons,
        "policy": asdict(resolved_policy),
    }
