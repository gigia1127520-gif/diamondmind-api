from __future__ import annotations

import asyncio
import html
import math
import re
from dataclasses import dataclass
from datetime import date, datetime, time, timedelta
from html.parser import HTMLParser
from typing import Any
from zoneinfo import ZoneInfo

import httpx

from .cache import AsyncTTLCache
from .config import Settings

TAIPEI = ZoneInfo("Asia/Taipei")
SEOUL = ZoneInfo("Asia/Seoul")


class AsianBaseballUpstreamError(RuntimeError):
    pass


@dataclass(frozen=True)
class TeamInfo:
    key: str
    name: str
    zh: str
    abbr: str
    aliases: tuple[str, ...]


KBO_TEAMS: dict[str, TeamInfo] = {
    "LG": TeamInfo("LG", "LG Twins", "LG雙子", "LG", ("LG", "LG TWINS", "엘지")),
    "HANWHA": TeamInfo("HANWHA", "Hanwha Eagles", "韓華鷹", "HAN", ("HANWHA", "한화")),
    "SSG": TeamInfo("SSG", "SSG Landers", "SSG登陸者", "SSG", ("SSG",)),
    "SAMSUNG": TeamInfo("SAMSUNG", "Samsung Lions", "三星獅", "SAM", ("SAMSUNG", "삼성")),
    "NC": TeamInfo("NC", "NC Dinos", "NC恐龍", "NC", ("NC",)),
    "KT": TeamInfo("KT", "KT Wiz", "KT巫師", "KT", ("KT",)),
    "LOTTE": TeamInfo("LOTTE", "Lotte Giants", "樂天巨人", "LOT", ("LOTTE", "롯데")),
    "KIA": TeamInfo("KIA", "KIA Tigers", "KIA虎", "KIA", ("KIA",)),
    "DOOSAN": TeamInfo("DOOSAN", "Doosan Bears", "斗山熊", "DOO", ("DOOSAN", "두산")),
    "KIWOOM": TeamInfo("KIWOOM", "Kiwoom Heroes", "培證英雄", "KIW", ("KIWOOM", "키움")),
}

CPBL_TEAMS: dict[str, TeamInfo] = {
    "LIONS": TeamInfo("LIONS", "Uni-President 7-Eleven Lions", "統一7-ELEVEn獅", "UL", ("統一7-ELEVEn獅", "統一獅", "UNI-LIONS")),
    "MONKEYS": TeamInfo("MONKEYS", "Rakuten Monkeys", "樂天桃猿", "RM", ("樂天桃猿", "RAKUTEN MONKEYS")),
    "BROTHERS": TeamInfo("BROTHERS", "CTBC Brothers", "中信兄弟", "CTB", ("中信兄弟", "CTBC BROTHERS")),
    "HAWKS": TeamInfo("HAWKS", "TSG Hawks", "台鋼雄鷹", "TSG", ("台鋼雄鷹", "TSG HAWKS")),
    "DRAGONS": TeamInfo("DRAGONS", "Wei Chuan Dragons", "味全龍", "WCD", ("味全龍", "WEI CHUAN DRAGONS")),
    "GUARDIANS": TeamInfo("GUARDIANS", "Fubon Guardians", "富邦悍將", "FG", ("富邦悍將", "FUBON GUARDIANS")),
}

VENUE_ALIASES = {
    "JAMSIL": "蠶室",
    "GOCHEOKSKY": "高尺天空巨蛋",
    "GWANGJU": "光州",
    "CHANGWON": "昌原",
    "DAEJEON": "大田",
    "MUNHAK": "文鶴",
    "SUWON": "水原",
    "SAJIK": "社稷",
    "POHANG": "浦項",
    "ULSAN": "蔚山",
}

KBO_DATE_RE = re.compile(r"(?P<month>\d{1,2})[./](?P<day>\d{1,2})(?:\([A-Z가-힣]+\))?", re.I)
TIME_RE = re.compile(r"^(?P<h>\d{1,2}):(?P<m>\d{2})$")
SCORE_RE = re.compile(r"^(?P<a>\d{1,2})\s*[:：-]\s*(?P<h>\d{1,2})$")
CPBL_DATE_RE = re.compile(r"(?P<month>\d{1,2})月(?P<day>\d{1,2})日")
CPBL_DAILY_DATE_RE = re.compile(r"^(?P<month>\d{1,2})/(?P<day>\d{1,2})(?:\s*(?:週|星期)[一二三四五六日天])?$")
CPBL_GAME_RE = re.compile(r"GAME\s*(?P<game>\d+)\s*(?P<status>已結束|未開始|延賽|比賽中|進行中|取消)?", re.I)
CPBL_GAME_STATUS_RE = re.compile(r"^(已結束|未開始|延賽|比賽中|進行中|取消)$")
CPBL_GAME_NUMBER_STATUS_RE = re.compile(r"^(?P<game>\d+)\s*(?P<status>已結束|未開始|延賽|比賽中|進行中|取消)?$")
CPBL_COUNT_RE = re.compile(r"共\s*(?P<count>\d+)\s*場")
RECORD_RE = re.compile(r"^\d{1,3}-\d{1,3}-\d{1,3}$")


class _TableParser(HTMLParser):
    def __init__(self, table_id: str | None = None) -> None:
        super().__init__(convert_charrefs=True)
        self.table_id = table_id
        self.rows: list[list[str]] = []
        self._table_depth = 0
        self._wanted = table_id is None
        self._row: list[str] | None = None
        self._cell: list[str] | None = None

    @staticmethod
    def clean(value: str) -> str:
        return re.sub(r"\s+", " ", html.unescape(value or "")).strip()

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        tag = tag.lower()
        attr = dict(attrs)
        if tag == "table":
            if self._table_depth > 0:
                self._table_depth += 1
            elif self.table_id is None or attr.get("id", "").lower() == self.table_id.lower():
                self._wanted = True
                self._table_depth = 1
        elif self._wanted and self._table_depth and tag == "tr":
            self._row = []
        elif self._row is not None and tag in {"td", "th"}:
            self._cell = []
        elif self._cell is not None and tag == "br":
            self._cell.append(" ")

    def handle_data(self, data: str) -> None:
        if self._cell is not None:
            value = self.clean(data)
            if value:
                self._cell.append(value)

    def handle_endtag(self, tag: str) -> None:
        tag = tag.lower()
        if tag in {"td", "th"} and self._cell is not None and self._row is not None:
            self._row.append(self.clean(" ".join(self._cell)))
            self._cell = None
        elif tag == "tr" and self._row is not None:
            if any(self._row):
                self.rows.append(self._row)
            self._row = None
        elif tag == "table" and self._wanted and self._table_depth:
            self._table_depth -= 1
            if self._table_depth == 0 and self.table_id is not None:
                self._wanted = False


class _TokenParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.tokens: list[str] = []

    @staticmethod
    def clean(value: str) -> str:
        return re.sub(r"\s+", " ", html.unescape(value or "")).strip()

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag.lower() == "img":
            alt = self.clean(dict(attrs).get("alt") or "")
            if alt:
                self.tokens.append(alt)

    def handle_data(self, data: str) -> None:
        value = self.clean(data)
        if value:
            self.tokens.append(value)


def _team_from_token(token: str, teams: dict[str, TeamInfo]) -> str | None:
    cleaned = re.sub(r"\s+", " ", str(token or "")).strip()
    upper = cleaned.upper()
    for key, info in teams.items():
        if upper == key or any(upper == alias.upper() for alias in info.aliases):
            return key
    return None


def _team_payload(info: TeamInfo, score: int | None = None) -> dict[str, Any]:
    return {
        "id": info.key,
        "name": info.name,
        "short_name": info.key,
        "name_zh": info.zh,
        "abbr": info.abbr,
        "score": score,
        "probable_pitcher": {"id": None, "name": "尚未公布", "announced": False},
    }


def _status(value: str, score: tuple[int, int] | None, start: datetime | None, now: datetime | None = None) -> tuple[str, str]:
    text = str(value or "").strip().lower()
    if any(word in text for word in ("延賽", "postpon", "cancel", "rained")):
        return "postponed", "Postponed"
    if any(word in text for word in ("已結束", "final", "ended")) or score is not None:
        return "final", "Final"
    if any(word in text for word in ("比賽中", "進行中", "in progress", "live")):
        return "live", "In Progress"
    current = (now or datetime.now(TAIPEI)).astimezone(TAIPEI)
    if start and current >= start and current <= start + timedelta(hours=5):
        return "live", "In Progress"
    return "upcoming", "Scheduled"


def _game_payload(
    league: str,
    target_date: date,
    game_id: str,
    away_key: str,
    home_key: str,
    teams: dict[str, TeamInfo],
    *,
    local_time: str,
    local_tz: ZoneInfo,
    away_score: int | None = None,
    home_score: int | None = None,
    raw_status: str = "",
    venue: str = "",
    source_url: str = "",
) -> dict[str, Any]:
    tm = TIME_RE.match(local_time or "")
    start = datetime.combine(target_date, time(int(tm.group("h")), int(tm.group("m"))), tzinfo=local_tz) if tm else datetime.combine(target_date, time(18, 30), tzinfo=local_tz)
    taipei_start = start.astimezone(TAIPEI)
    score = (away_score, home_score) if away_score is not None and home_score is not None else None
    status, detailed = _status(raw_status, score, taipei_start)
    return {
        "league": league,
        "season": target_date.year,
        "game_pk": game_id,
        "external_game_id": game_id,
        "game_date": taipei_start.isoformat(),
        "date_taiwan": taipei_start.date().isoformat(),
        "time_taiwan": taipei_start.strftime("%H:%M"),
        "display_time_taiwan": f"台灣 {taipei_start:%H:%M}",
        "status": status,
        "detailed_status": detailed,
        "inning": None,
        "inning_state": "",
        "venue_id": None,
        "venue": VENUE_ALIASES.get(venue.upper(), venue),
        "game_type": "regular_season",
        "season_context": "regular_season",
        "event_label": f"{league} 例行賽" if league == "KBO" else "中華職棒例行賽",
        "is_special_event": False,
        "analysis_available": True,
        "analysis_status": "base_model",
        "away": _team_payload(teams[away_key], away_score),
        "home": _team_payload(teams[home_key], home_score),
        "source_url": source_url,
        "official_schedule_url": source_url,
    }


def parse_kbo_schedule(page_html: str, target_date: date, source_url: str) -> list[dict[str, Any]]:
    parser = _TableParser("tblScheduleList")
    parser.feed(page_html)
    rows = parser.rows
    if not rows:
        fallback = _TableParser()
        fallback.feed(page_html)
        rows = fallback.rows
    current_date: date | None = None
    games: list[dict[str, Any]] = []
    sequence = 0
    for cells in rows:
        values = [re.sub(r"\s+", " ", value).strip() for value in cells if value.strip()]
        if not values:
            continue
        for value in values[:2]:
            match = KBO_DATE_RE.search(value)
            if match:
                try:
                    current_date = date(target_date.year, int(match.group("month")), int(match.group("day")))
                except ValueError:
                    current_date = None
                break
        if current_date != target_date:
            continue
        time_value = next((value for value in values if TIME_RE.match(value)), None)
        team_positions = [(idx, _team_from_token(value, KBO_TEAMS)) for idx, value in enumerate(values)]
        team_positions = [(idx, key) for idx, key in team_positions if key]
        if not time_value or len(team_positions) < 2:
            continue
        away_key, home_key = team_positions[0][1], team_positions[1][1]
        if away_key == home_key:
            continue
        score_value = next((value for value in values if SCORE_RE.match(value) and not TIME_RE.match(value)), "")
        score_match = SCORE_RE.match(score_value)
        away_score = int(score_match.group("a")) if score_match else None
        home_score = int(score_match.group("h")) if score_match else None
        raw_status = "Final" if score_match else ""
        joined = " ".join(values)
        if any(word in joined.lower() for word in ("postpon", "cancel", "rained")):
            raw_status = "Postponed"
        last_team_index = team_positions[1][0]
        venue = ""
        for value in values[last_team_index + 1:]:
            if value in {"-", "REGULAR"} or TIME_RE.match(value) or SCORE_RE.match(value):
                continue
            if _team_from_token(value, KBO_TEAMS):
                continue
            if value.upper().endswith("T") or re.fullmatch(r"[A-Z]+-?\d*T", value.upper()):
                continue
            venue = value
            break
        sequence += 1
        game_id = f"kbo_{target_date:%Y%m%d}_{away_key}_{home_key}_{sequence}"
        games.append(_game_payload("KBO", target_date, game_id, away_key, home_key, KBO_TEAMS, local_time=time_value, local_tz=SEOUL, away_score=away_score, home_score=home_score, raw_status=raw_status, venue=venue, source_url=source_url))
    return games


def _cpbl_time(raw: str | None, target_date: date) -> str:
    match = TIME_RE.match(str(raw or ""))
    if match:
        h, m = int(match.group("h")), int(match.group("m"))
        # The advanced stats page currently serializes scheduled local times as UTC.
        if h <= 3:
            h = (h + 16) % 24
        return f"{h:02d}:{m:02d}"
    # Official CPBL defaults: weekday night games, weekend afternoon/evening.
    return "17:05" if target_date.weekday() >= 5 else "18:35"


def _normalise_cpbl_tokens(raw_tokens: list[str]) -> list[str]:
    """Normalise CPBL's responsive DOM into stable logical tokens.

    The official page may render a game marker as one text node (``GAME 211未開始``)
    or as three adjacent nodes (``GAME`` / ``211`` / ``未開始``).  The old parser
    only supported the first form, which could silently return an empty schedule
    after a harmless upstream markup change.
    """
    cleaned: list[str] = []
    for raw in raw_tokens:
        token = re.sub(r"\s+", " ", html.unescape(str(raw or "")).replace("\xa0", " ")).strip()
        if token and (not cleaned or cleaned[-1] != token):
            cleaned.append(token)

    tokens: list[str] = []
    i = 0
    while i < len(cleaned):
        token = cleaned[i]
        upper = token.upper()
        if upper == "GAME":
            if i + 1 < len(cleaned):
                number_status = CPBL_GAME_NUMBER_STATUS_RE.match(cleaned[i + 1])
                if number_status:
                    logical = f"GAME {number_status.group('game')}"
                    status = number_status.group("status") or ""
                    consumed = 2
                    if not status and i + 2 < len(cleaned) and CPBL_GAME_STATUS_RE.match(cleaned[i + 2]):
                        status = cleaned[i + 2]
                        consumed = 3
                    if status:
                        logical += f" {status}"
                    tokens.append(logical)
                    i += consumed
                    continue
        game_match = CPBL_GAME_RE.fullmatch(token)
        if game_match and not game_match.group("status") and i + 1 < len(cleaned) and CPBL_GAME_STATUS_RE.match(cleaned[i + 1]):
            tokens.append(f"{token} {cleaned[i + 1]}")
            i += 2
            continue
        tokens.append(token)
        i += 1
    return tokens


def _cpbl_daily_card_games(tokens: list[str], target_date: date, source_url: str) -> list[dict[str, Any]]:
    """Parse the compact current-day cards rendered above the monthly list.

    CPBL's page currently exposes two representations of the same schedule.
    The compact current-day section uses ``7/21 週二`` and places the GAME
    marker at the end of each card, while the monthly list uses ``7月22日``
    and places GAME first.  During the provider's UTC/local rollover those two
    labels can differ by one day.  The compact cards are authoritative for the
    displayed current day and must be parsed independently instead of forcing
    them through the monthly-list grammar.
    """

    header_index: int | None = None
    for index, token in enumerate(tokens):
        match = CPBL_DAILY_DATE_RE.fullmatch(token.strip())
        if not match:
            continue
        try:
            token_date = date(target_date.year, int(match.group("month")), int(match.group("day")))
        except ValueError:
            continue
        if token_date == target_date:
            header_index = index
            break
    if header_index is None:
        return []

    end_index = len(tokens)
    for index in range(header_index + 1, len(tokens)):
        if tokens[index].strip() == "賽程列表":
            end_index = index
            break

    window = tokens[header_index + 1:end_index]
    markers = [
        index for index, token in enumerate(window)
        if token.strip() in {"一軍例行賽", "一軍季後挑戰賽", "一軍總冠軍賽", "二軍例行賽", "二軍總冠軍賽"}
    ]
    games: list[dict[str, Any]] = []
    for position, start in enumerate(markers):
        competition = window[start].strip()
        stop = markers[position + 1] if position + 1 < len(markers) else len(window)
        block = window[start:stop]
        if not competition.startswith("一軍"):
            continue
        game_match = next((CPBL_GAME_RE.search(token) for token in block if CPBL_GAME_RE.search(token)), None)
        if not game_match:
            continue
        teams: list[str] = []
        for token in block:
            key = _team_from_token(token, CPBL_TEAMS)
            if key and (not teams or teams[-1] != key):
                teams.append(key)
        if len(teams) < 2:
            continue
        away_key, home_key = teams[0], teams[1]
        score_match = next((SCORE_RE.match(token) for token in block if SCORE_RE.match(token) and not TIME_RE.match(token)), None)
        away_score = int(score_match.group("a")) if score_match else None
        home_score = int(score_match.group("h")) if score_match else None
        time_value = next((token for token in block if TIME_RE.match(token)), None)
        ignored = {
            "vs", "成績看板", competition, CPBL_TEAMS[away_key].zh, CPBL_TEAMS[home_key].zh,
            CPBL_TEAMS[away_key].name, CPBL_TEAMS[home_key].name,
        }
        venue = ""
        for token in block:
            stripped = token.strip()
            if stripped in ignored or CPBL_GAME_RE.search(stripped) or TIME_RE.match(stripped) or (SCORE_RE.match(stripped) and not TIME_RE.match(stripped)) or RECORD_RE.match(stripped):
                continue
            if _team_from_token(stripped, CPBL_TEAMS):
                continue
            if stripped.startswith("Image:") or stripped.startswith("共 "):
                continue
            if stripped in {"未開始", "已結束", "延賽", "比賽中", "進行中", "取消"}:
                continue
            venue = stripped
        game_no = game_match.group("game")
        raw_status = game_match.group("status") or next((token for token in block if CPBL_GAME_STATUS_RE.fullmatch(token.strip())), "")
        game_id = f"cpbl_{target_date:%Y%m%d}_{game_no}"
        games.append(_game_payload(
            "CPBL", target_date, game_id, away_key, home_key, CPBL_TEAMS,
            local_time=_cpbl_time(time_value, target_date), local_tz=TAIPEI,
            away_score=away_score, home_score=home_score, raw_status=raw_status,
            venue=venue, source_url=source_url,
        ))
    return games


def cpbl_expected_game_count(page_html: str, target_date: date) -> int | None:
    parser = _TokenParser()
    parser.feed(page_html)
    tokens = _normalise_cpbl_tokens(parser.tokens)
    current_date: date | None = None
    for token in tokens:
        date_match = CPBL_DATE_RE.search(token)
        if date_match:
            try:
                current_date = date(target_date.year, int(date_match.group("month")), int(date_match.group("day")))
            except ValueError:
                current_date = None
            continue
        if current_date == target_date:
            count_match = CPBL_COUNT_RE.search(token)
            if count_match:
                return int(count_match.group("count"))
            if CPBL_DATE_RE.search(token):
                break
    daily_games = _cpbl_daily_card_games(tokens, target_date, "")
    return len(daily_games) if daily_games else None


def parse_cpbl_schedule(page_html: str, target_date: date, source_url: str) -> list[dict[str, Any]]:
    parser = _TokenParser()
    parser.feed(page_html)
    tokens = _normalise_cpbl_tokens(parser.tokens)
    current_date: date | None = None
    games: list[dict[str, Any]] = []
    i = 0
    while i < len(tokens):
        date_match = CPBL_DATE_RE.search(tokens[i])
        if date_match:
            try:
                current_date = date(target_date.year, int(date_match.group("month")), int(date_match.group("day")))
            except ValueError:
                current_date = None
            i += 1
            continue
        game_match = CPBL_GAME_RE.search(tokens[i])
        if not game_match:
            i += 1
            continue
        start = i
        end = i + 1
        while end < len(tokens) and not CPBL_GAME_RE.search(tokens[end]) and not CPBL_DATE_RE.search(tokens[end]):
            end += 1
        block = tokens[start:end]
        i = end
        if current_date != target_date:
            continue
        teams = []
        for token in block:
            key = _team_from_token(token, CPBL_TEAMS)
            if key and (not teams or teams[-1] != key):
                teams.append(key)
        if len(teams) < 2:
            continue
        away_key, home_key = teams[0], teams[1]
        score_match = next((SCORE_RE.match(token) for token in block if SCORE_RE.match(token) and not TIME_RE.match(token)), None)
        away_score = int(score_match.group("a")) if score_match else None
        home_score = int(score_match.group("h")) if score_match else None
        time_value = next((token for token in block if TIME_RE.match(token)), None)
        ignored = {"vs", "成績看板", "一軍例行賽", "二軍例行賽", CPBL_TEAMS[away_key].zh, CPBL_TEAMS[home_key].zh}
        venue = ""
        for token in block:
            if token in ignored or CPBL_GAME_RE.search(token) or TIME_RE.match(token) or (SCORE_RE.match(token) and not TIME_RE.match(token)) or RECORD_RE.match(token):
                continue
            if _team_from_token(token, CPBL_TEAMS):
                continue
            if token.startswith("Image:") or token.startswith("共 "):
                continue
            venue = token
        game_no = game_match.group("game")
        game_id = f"cpbl_{target_date:%Y%m%d}_{game_no}"
        games.append(_game_payload("CPBL", target_date, game_id, away_key, home_key, CPBL_TEAMS, local_time=_cpbl_time(time_value, target_date), local_tz=TAIPEI, away_score=away_score, home_score=home_score, raw_status=game_match.group("status") or "", venue=venue, source_url=source_url))
    if games:
        return games
    return _cpbl_daily_card_games(tokens, target_date, source_url)


def _team_form(team_key: str, games: list[dict[str, Any]], limit: int = 10) -> dict[str, Any]:
    relevant: list[dict[str, Any]] = []
    for game in games:
        if game.get("status") != "final":
            continue
        away = game.get("away") or {}
        home = game.get("home") or {}
        if str(away.get("id")) == team_key or str(home.get("id")) == team_key:
            relevant.append(game)
    relevant.sort(key=lambda item: str(item.get("game_date") or ""), reverse=True)
    relevant = relevant[:limit]
    wins = losses = ties = runs_for = runs_against = 0
    for game in relevant:
        away = game.get("away") or {}
        home = game.get("home") or {}
        is_away = str(away.get("id")) == team_key
        rf = away.get("score") if is_away else home.get("score")
        ra = home.get("score") if is_away else away.get("score")
        if rf is None or ra is None:
            continue
        runs_for += int(rf)
        runs_against += int(ra)
        if rf > ra:
            wins += 1
        elif rf < ra:
            losses += 1
        else:
            ties += 1
    decided = wins + losses
    pct = wins / decided if decided else 0.5
    return {
        "available": bool(relevant),
        "games": len(relevant),
        "wins": wins,
        "losses": losses,
        "ties": ties,
        "win_pct": round(pct, 3),
        "runs_for": runs_for,
        "runs_against": runs_against,
        "run_diff": runs_for - runs_against,
        "runs_per_game": round(runs_for / len(relevant), 2) if relevant else None,
        "runs_allowed_per_game": round(runs_against / len(relevant), 2) if relevant else None,
    }


def build_baseline_analysis(league: str, game: dict[str, Any], history: list[dict[str, Any]]) -> dict[str, Any]:
    away = game.get("away") or {}
    home = game.get("home") or {}
    away_form = _team_form(str(away.get("id")), history)
    home_form = _team_form(str(home.get("id")), history)
    away_strength = away_form.get("win_pct", 0.5) * 0.72 + max(-0.12, min(0.12, float(away_form.get("run_diff") or 0) / 80.0))
    home_strength = home_form.get("win_pct", 0.5) * 0.72 + max(-0.12, min(0.12, float(home_form.get("run_diff") or 0) / 80.0)) + 0.035
    delta = home_strength - away_strength
    home_probability = max(38.0, min(68.0, 50.0 + delta * 45.0))
    away_probability = 100.0 - home_probability
    side = "home" if home_probability >= away_probability else "away"
    confidence = max(home_probability, away_probability)
    history_ready = bool(away_form.get("available") and home_form.get("available"))
    data_quality = 0.56 if history_ready else 0.39
    avg_away = float(away_form.get("runs_per_game") or 4.1)
    avg_home = float(home_form.get("runs_per_game") or 4.2)
    allow_away = float(away_form.get("runs_allowed_per_game") or 4.2)
    allow_home = float(home_form.get("runs_allowed_per_game") or 4.1)
    projected_away = max(1.8, min(8.0, (avg_away + allow_home) / 2.0))
    projected_home = max(1.8, min(8.0, (avg_home + allow_away) / 2.0 + 0.18))
    picked = game.get(side) or {}
    groups = {
        "team": {"available": True, "quality": 0.62 if history_ready else 0.38, "away": away_form, "home": home_form, "metrics": ["近況勝率", "得失分差", "主場加成"]},
        "starter": {"available": False, "quality": 0.0, "both_starters_ready": False, "metrics": [], "message": "預告先發尚未完整，已降低模型信心。"},
        "offense": {"available": history_ready, "quality": 0.45 if history_ready else 0.2, "metrics": ["近況場均得分"] if history_ready else []},
        "bullpen": {"available": False, "quality": 0.0, "metrics": [], "message": "牛棚逐日用量來源待補強。"},
        "advanced": {"available": False, "quality": 0.0, "metrics": []},
        "environment": {"available": False, "quality": 0.0, "metrics": []},
    }
    return {
        "league": league,
        "model_version": f"dm-{league.lower()}-baseline-v1.0",
        "model_stage": "base",
        "status": "prediction_moneyline",
        "official_recommendation_enabled": True,
        "full_market_recommendation_enabled": False,
        "message": f"{league} 基礎模型已就緒；先發、打線或進階資料不足只降低信心，不阻擋免費推薦。",
        "data_basis": {
            "model_stage": "base",
            "base_modules_ready": True,
            "pick_direction_ready": True,
            "base_recommendation_ready": True,
            "full_market_ready": False,
            "starter_names_ready": False,
            "starter_stats_ready": False,
            "official_lineups_ready": False,
            "recommendation_ready": True,
            "used_modules": ["官方賽程", "官方近期賽果", "得失分差", "主場加成"],
            "missing_core": ["預告先發", "正式打線", "牛棚逐日用量"],
            "data_quality": round(data_quality, 2),
        },
        "model_weights": {"engine": {"team_strength": 0.72, "starter": 0.0, "lineup": 0.18, "bullpen": 0.0, "advanced": 0.0, "environment": 0.0, "home_advantage": 0.10}},
        "confidence_cap": 68.0,
        "pick": {"side": side, "team": picked.get("name"), "team_name_zh": picked.get("name_zh"), "label": f"{picked.get('name_zh') or picked.get('abbr')} 獨贏"},
        "home_probability": round(home_probability, 1),
        "away_probability": round(away_probability, 1),
        "confidence": round(confidence, 1),
        "data_quality": round(data_quality, 2),
        "projections": {"away_runs": round(projected_away, 2), "home_runs": round(projected_home, 2), "total_runs": round(projected_away + projected_home, 2), "home_margin": round(projected_home - projected_away, 2), "quality": round(data_quality, 2), "score": {"away": round(projected_away), "home": round(projected_home)}},
        "analysis_groups": groups,
        "lineups": {"away": {"official": False}, "home": {"official": False}},
        "bullpen_usage": {"away": {"available": False}, "home": {"available": False}},
        "roster_status": {"available": False},
        "environment": {"available": False},
        "team_profiles": {"away": {"form": away_form}, "home": {"form": home_form}},
    }


class AsianBaseballService:
    def __init__(self, settings: Settings, league: str, transport: httpx.AsyncBaseTransport | None = None) -> None:
        code = str(league).upper()
        if code not in {"KBO", "CPBL"}:
            raise ValueError("AsianBaseballService only supports KBO or CPBL")
        self.settings = settings
        self.league = code
        self.cache = AsyncTTLCache()
        self.client = httpx.AsyncClient(
            timeout=settings.request_timeout_seconds,
            follow_redirects=True,
            trust_env=False,
            transport=transport,
            headers={"Accept": "text/html,application/xhtml+xml", "Accept-Language": "zh-TW,ko-KR,en;q=0.8", "User-Agent": f"DiamondMind/{code}-official-adapter/1.0"},
        )

    @property
    def source_url(self) -> str:
        return self.settings.kbo_schedule_url if self.league == "KBO" else self.settings.cpbl_schedule_url

    async def aclose(self) -> None:
        await self.client.aclose()

    async def _get_html(self) -> str:
        key = f"{self.league}:{self.source_url}"
        cached = self.cache.get(key)
        if cached and cached.is_fresh:
            return str(cached.value)
        async with self.cache.lock(key):
            cached = self.cache.get(key)
            if cached and cached.is_fresh:
                return str(cached.value)
            try:
                response = await self.client.get(self.source_url)
                response.raise_for_status()
                body = response.text
                marker = "KBO" if self.league == "KBO" else "中華職棒"
                if marker not in body and (self.league != "CPBL" or "賽程" not in body):
                    raise ValueError(f"Unexpected {self.league} response")
                self.cache.set(key, body, self.settings.asian_baseball_cache_ttl_seconds, self.settings.asian_baseball_stale_ttl_seconds)
                return body
            except (httpx.HTTPError, ValueError) as exc:
                if cached and cached.can_serve_stale:
                    return str(cached.value)
                raise AsianBaseballUpstreamError(f"{self.league} 官方賽程目前暫時無法連線") from exc

    def parse_schedule(self, page_html: str, target_date: date) -> list[dict[str, Any]]:
        if self.league == "KBO":
            return parse_kbo_schedule(page_html, target_date, self.source_url)
        return parse_cpbl_schedule(page_html, target_date, self.source_url)

    async def games_for_date(self, target_date: date) -> dict[str, Any]:
        body = await self._get_html()
        items = self.parse_schedule(body, target_date)
        expected_count = cpbl_expected_game_count(body, target_date) if self.league == "CPBL" else None
        parser_status = "ok"
        if expected_count is not None and len(items) < expected_count:
            parser_status = "partial" if items else "failed"
        return {
            "league": self.league,
            "date": target_date.isoformat(),
            "timezone": "Asia/Taipei",
            "count": len(items),
            "items": items,
            "meta": {
                "source": f"{self.league} official schedule",
                "source_url": self.source_url,
                "updated_at": datetime.now(TAIPEI).isoformat(),
                "cache": "adapter_cache",
                "parser_status": parser_status,
                "expected_count": expected_count,
                "data_policy": "missing enrichment lowers confidence but does not block publication",
            },
        }

    async def _history(self, target_date: date, days: int = 28) -> list[dict[str, Any]]:
        body = await self._get_html()
        values: list[dict[str, Any]] = []
        # The official monthly pages contain the surrounding weeks. Parsing
        # every date locally avoids one upstream request per game/team.
        for offset in range(days, 0, -1):
            day = target_date - timedelta(days=offset)
            values.extend(self.parse_schedule(body, day))
        return values

    async def matchup_analysis(self, game_pk: str) -> dict[str, Any]:
        match = re.search(r"_(?P<date>\d{8})_", str(game_pk or ""))
        if not match:
            raise AsianBaseballUpstreamError(f"無效的 {self.league} 賽事編號")
        try:
            target_date = datetime.strptime(match.group("date"), "%Y%m%d").date()
        except ValueError as exc:
            raise AsianBaseballUpstreamError(f"無效的 {self.league} 賽事日期") from exc
        schedule, history = await asyncio.gather(self.games_for_date(target_date), self._history(target_date))
        game = next((item for item in schedule.get("items") or [] if str(item.get("game_pk")) == str(game_pk)), None)
        if not game:
            raise AsianBaseballUpstreamError(f"找不到指定的 {self.league} 賽事")
        analysis = build_baseline_analysis(self.league, game, history)
        return {"game": game, "analysis": analysis, "access": {"required_plan": "pro"}, "meta": {"source": f"{self.league} official schedule/results baseline", "updated_at": datetime.now(TAIPEI).isoformat(), "official_recommendation_enabled": True}}

    async def game_detail(self, game_pk: str) -> dict[str, Any]:
        return await self.matchup_analysis(game_pk)

    async def matchup_analyses(self, target_date: date, pitcher_limit: int | None = None) -> dict[str, Any]:
        schedule = await self.games_for_date(target_date)
        items: list[dict[str, Any]] = []
        for game in schedule.get("items") or []:
            if str(game.get("status") or "").lower() not in {"upcoming", "scheduled", "preview"}:
                continue
            try:
                items.append(await self.matchup_analysis(str(game.get("game_pk"))))
            except AsianBaseballUpstreamError:
                continue
        return {"league": self.league, "date": target_date.isoformat(), "count": len(items), "items": items, "meta": schedule.get("meta") or {}}

    async def game_result(self, game_pk: str) -> dict[str, Any]:
        match = re.search(r"_(?P<date>\d{8})_", str(game_pk or ""))
        if not match:
            raise AsianBaseballUpstreamError(f"無效的 {self.league} 賽事編號")
        target_date = datetime.strptime(match.group("date"), "%Y%m%d").date()
        payload = await self.games_for_date(target_date)
        game = next((item for item in payload.get("items") or [] if str(item.get("game_pk")) == str(game_pk)), None)
        if not game:
            raise AsianBaseballUpstreamError(f"找不到指定的 {self.league} 賽事結果")
        return game
