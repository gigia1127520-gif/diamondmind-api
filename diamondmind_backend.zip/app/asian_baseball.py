from __future__ import annotations

import asyncio
import html
import math
import re
from dataclasses import dataclass
from datetime import date, datetime, time, timedelta
from html.parser import HTMLParser
from typing import Any
from zoneinfo import ZoneInfo

import httpx

from .cache import AsyncTTLCache
from .config import Settings

TAIPEI = ZoneInfo("Asia/Taipei")
SEOUL = ZoneInfo("Asia/Seoul")


class AsianBaseballUpstreamError(RuntimeError):
    pass


class AsianBaseballSettlementLookupError(AsianBaseballUpstreamError):
    """A structured, non-fatal lookup failure used by settlement diagnostics."""

    def __init__(self, message: str, *, code: str, details: dict[str, Any] | None = None) -> None:
        super().__init__(message)
        self.code = code
        self.details = details or {}


@dataclass(frozen=True)
class TeamInfo:
    key: str
    name: str
    zh: str
    abbr: str
    aliases: tuple[str, ...]


KBO_TEAMS: dict[str, TeamInfo] = {
    "LG": TeamInfo("LG", "LG Twins", "LG雙子", "LG", ("LG", "LG TWINS", "엘지")),
    "HANWHA": TeamInfo("HANWHA", "Hanwha Eagles", "韓華鷹", "HAN", ("HANWHA", "한화")),
    "SSG": TeamInfo("SSG", "SSG Landers", "SSG登陸者", "SSG", ("SSG",)),
    "SAMSUNG": TeamInfo("SAMSUNG", "Samsung Lions", "三星獅", "SAM", ("SAMSUNG", "삼성")),
    "NC": TeamInfo("NC", "NC Dinos", "NC恐龍", "NC", ("NC",)),
    "KT": TeamInfo("KT", "KT Wiz", "KT巫師", "KT", ("KT",)),
    "LOTTE": TeamInfo("LOTTE", "Lotte Giants", "樂天巨人", "LOT", ("LOTTE", "롯데")),
    "KIA": TeamInfo("KIA", "KIA Tigers", "KIA虎", "KIA", ("KIA",)),
    "DOOSAN": TeamInfo("DOOSAN", "Doosan Bears", "斗山熊", "DOO", ("DOOSAN", "두산")),
    "KIWOOM": TeamInfo("KIWOOM", "Kiwoom Heroes", "培證英雄", "KIW", ("KIWOOM", "키움")),
}

CPBL_TEAMS: dict[str, TeamInfo] = {
    "LIONS": TeamInfo("LIONS", "Uni-President 7-Eleven Lions", "統一7-ELEVEn獅", "UL", ("統一7-ELEVEn獅", "統一獅", "UNI-LIONS")),
    "MONKEYS": TeamInfo("MONKEYS", "Rakuten Monkeys", "樂天桃猿", "RM", ("樂天桃猿", "RAKUTEN MONKEYS")),
    "BROTHERS": TeamInfo("BROTHERS", "CTBC Brothers", "中信兄弟", "CTB", ("中信兄弟", "CTBC BROTHERS")),
    "HAWKS": TeamInfo("HAWKS", "TSG Hawks", "台鋼雄鷹", "TSG", ("台鋼雄鷹", "TSG HAWKS")),
    "DRAGONS": TeamInfo("DRAGONS", "Wei Chuan Dragons", "味全龍", "WCD", ("味全龍", "WEI CHUAN DRAGONS")),
    "GUARDIANS": TeamInfo("GUARDIANS", "Fubon Guardians", "富邦悍將", "FG", ("富邦悍將", "FUBON GUARDIANS")),
}

VENUE_ALIASES = {
    "JAMSIL": "蠶室",
    "GOCHEOKSKY": "高尺天空巨蛋",
    "GWANGJU": "光州",
    "CHANGWON": "昌原",
    "DAEJEON": "大田",
    "MUNHAK": "文鶴",
    "SUWON": "水原",
    "SAJIK": "社稷",
    "POHANG": "浦項",
    "ULSAN": "蔚山",
}

KBO_DATE_RE = re.compile(r"(?P<month>\d{1,2})[./](?P<day>\d{1,2})(?:\([A-Z가-힣]+\))?", re.I)
TIME_RE = re.compile(r"^(?P<h>\d{1,2}):(?P<m>\d{2})$")
SCORE_RE = re.compile(r"^(?P<a>\d{1,2})\s*[:：-]\s*(?P<h>\d{1,2})$")
CPBL_DATE_RE = re.compile(r"(?P<month>\d{1,2})月(?P<day>\d{1,2})日")
CPBL_DAILY_DATE_RE = re.compile(r"^(?P<month>\d{1,2})/(?P<day>\d{1,2})(?:\s*(?:週|星期)[一二三四五六日天])?$")
CPBL_GAME_RE = re.compile(r"GAME\s*(?P<game>\d+)\s*(?P<status>已結束|未開始|延賽|比賽中|進行中|取消)?", re.I)
CPBL_GAME_STATUS_RE = re.compile(r"^(已結束|未開始|延賽|比賽中|進行中|取消)$")
CPBL_GAME_NUMBER_STATUS_RE = re.compile(r"^(?P<game>\d+)\s*(?P<status>已結束|未開始|延賽|比賽中|進行中|取消)?$")
CPBL_COUNT_RE = re.compile(r"共\s*(?P<count>\d+)\s*場")
RECORD_RE = re.compile(r"^\d{1,3}-\d{1,3}-\d{1,3}$")
INTEGER_SCORE_RE = re.compile(r"^\d{1,2}$")
IGNORED_HTML_TAGS = {"script", "style", "noscript", "template", "svg"}
CSS_NOISE_RE = re.compile(r"(?:\.css-|--chakra|@layer|background:|display:|font-size:|border-radius:|webkit-|\{.*\})", re.I)

# Official KBO/CPBL terminal weather/no-game markers. A rain delay remains
# live/pending; only an official cancellation, no-game or postponement of the
# original fixture is graded void for the published recommendation.
ASIAN_VOID_TERMS = (
    "cancelled", "canceled", "no contest", "no game", "no-game", "nogame",
    "forfeit", "forfeited", "우천취소", "경기취소", "취소", "노게임",
    "무효경기", "우천 노게임",
)
ASIAN_POSTPONED_TERMS = (
    "postponed", "postpone", "우천연기", "경기연기", "연기",
)


def _contains_any_status_term(value: Any, terms: tuple[str, ...]) -> bool:
    text = re.sub(r"\s+", " ", str(value or "")).strip().lower()
    compact = text.replace(" ", "").replace("-", "")
    return any(term.lower() in text or term.lower().replace(" ", "").replace("-", "") in compact for term in terms)



class _TableParser(HTMLParser):
    def __init__(self, table_id: str | None = None) -> None:
        super().__init__(convert_charrefs=True)
        self.table_id = table_id
        self.rows: list[list[str]] = []
        self._table_depth = 0
        self._wanted = table_id is None
        self._row: list[str] | None = None
        self._cell: list[str] | None = None
        self._ignored_depth = 0

    @staticmethod
    def clean(value: str) -> str:
        return re.sub(r"\s+", " ", html.unescape(value or "")).strip()

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        tag = tag.lower()
        if tag in IGNORED_HTML_TAGS:
            self._ignored_depth += 1
            return
        if self._ignored_depth:
            return
        attr = dict(attrs)
        if tag == "table":
            if self._table_depth > 0:
                self._table_depth += 1
            elif self.table_id is None or attr.get("id", "").lower() == self.table_id.lower():
                self._wanted = True
                self._table_depth = 1
        elif self._wanted and self._table_depth and tag == "tr":
            self._row = []
        elif self._row is not None and tag in {"td", "th"}:
            self._cell = []
        elif self._cell is not None and tag == "br":
            self._cell.append(" ")

    def handle_data(self, data: str) -> None:
        if self._ignored_depth:
            return
        if self._cell is not None:
            value = self.clean(data)
            if value:
                self._cell.append(value)

    def handle_endtag(self, tag: str) -> None:
        tag = tag.lower()
        if tag in IGNORED_HTML_TAGS and self._ignored_depth:
            self._ignored_depth -= 1
            return
        if self._ignored_depth:
            return
        if tag in {"td", "th"} and self._cell is not None and self._row is not None:
            self._row.append(self.clean(" ".join(self._cell)))
            self._cell = None
        elif tag == "tr" and self._row is not None:
            if any(self._row):
                self.rows.append(self._row)
            self._row = None
        elif tag == "table" and self._wanted and self._table_depth:
            self._table_depth -= 1
            if self._table_depth == 0 and self.table_id is not None:
                self._wanted = False


class _TokenParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.tokens: list[str] = []
        self._ignored_depth = 0

    @staticmethod
    def clean(value: str) -> str:
        return re.sub(r"\s+", " ", html.unescape(value or "")).strip()

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        tag = tag.lower()
        if tag in IGNORED_HTML_TAGS:
            self._ignored_depth += 1
            return
        if self._ignored_depth:
            return
        if tag == "img":
            alt = self.clean(dict(attrs).get("alt") or "")
            if alt:
                self.tokens.append(alt)

    def handle_endtag(self, tag: str) -> None:
        tag = tag.lower()
        if tag in IGNORED_HTML_TAGS and self._ignored_depth:
            self._ignored_depth -= 1

    def handle_data(self, data: str) -> None:
        if self._ignored_depth:
            return
        value = self.clean(data)
        if value:
            self.tokens.append(value)


def _is_noise_token(value: str) -> bool:
    token = re.sub(r"\s+", " ", str(value or "")).strip()
    if not token or len(token) > 64:
        return True
    if any(ch in token for ch in ("{", "}", ";")):
        return True
    return bool(CSS_NOISE_RE.search(token))


def _safe_venue_token(value: str) -> str:
    token = re.sub(r"\s+", " ", html.unescape(str(value or ""))).strip()
    return "" if _is_noise_token(token) else token[:48]


def _integer_score(value: Any) -> int | None:
    token = re.sub(r"\s+", " ", str(value or "")).strip()
    if not INTEGER_SCORE_RE.fullmatch(token):
        return None
    score = int(token)
    # A baseball team total above 30 is almost certainly a game number,
    # record component, date fragment, or another page-control token.
    return score if 0 <= score <= 30 else None


def _extract_split_score_pair(
    block: list[str],
    teams: dict[str, TeamInfo],
) -> tuple[int | None, int | None, str]:
    """Extract a final score even when the official page splits it into nodes.

    CPBL currently renders some completed cards as separate text nodes, e.g.
    ``台鋼雄鷹`` / ``9`` / ``中信兄弟`` / ``6`` rather than one ``9：6``
    token.  The legacy parser only handled the combined token, causing the
    status to become final while one or both team scores remained missing.

    The routine first accepts the unambiguous combined form, then looks for a
    small integer nearest each of the first two team tokens.  A conservative
    adjacent-pair fallback is used only when exactly two plausible score nodes
    exist in the game block.
    """
    for token in block:
        match = SCORE_RE.fullmatch(str(token or "").strip())
        if match and not TIME_RE.fullmatch(str(token or "").strip()):
            return int(match.group("a")), int(match.group("h")), "combined"

    team_positions: list[tuple[int, str]] = []
    for index, token in enumerate(block):
        key = _team_from_token(token, teams)
        if key and (not team_positions or team_positions[-1][1] != key):
            team_positions.append((index, key))
    if len(team_positions) >= 2:
        used: set[int] = set()
        resolved: list[int | None] = []
        for team_index, _ in team_positions[:2]:
            candidates: list[tuple[int, int, int]] = []
            for index, token in enumerate(block):
                if index in used:
                    continue
                value = _integer_score(token)
                if value is None:
                    continue
                # Ignore isolated integers attached to GAME/count controls.
                neighbours = " ".join(str(block[i]) for i in range(max(0, index - 1), min(len(block), index + 2)))
                if CPBL_COUNT_RE.search(neighbours):
                    continue
                distance = abs(index - team_index)
                if distance <= 4:
                    # Prefer a score after the team label, then the nearest one.
                    direction_penalty = 0 if index > team_index else 1
                    candidates.append((distance, direction_penalty, index))
            if candidates:
                candidates.sort()
                chosen = candidates[0][2]
                used.add(chosen)
                resolved.append(_integer_score(block[chosen]))
            else:
                resolved.append(None)
        if resolved[0] is not None and resolved[1] is not None:
            return resolved[0], resolved[1], "team_adjacent_nodes"

    plausible: list[int] = []
    for index, token in enumerate(block):
        value = _integer_score(token)
        if value is None:
            continue
        neighbours = " ".join(str(block[i]) for i in range(max(0, index - 1), min(len(block), index + 2)))
        if CPBL_COUNT_RE.search(neighbours):
            continue
        plausible.append(value)
    if len(plausible) == 2:
        return plausible[0], plausible[1], "adjacent_integer_pair"
    return None, None, "missing"


def parse_kbo_scoreboard_results(page_html: str) -> dict[tuple[str, str], dict[str, Any]]:
    """Extract terminal KBO scores from the official scoreboard page.

    The daily schedule is optimized for fixtures and can lag on individual
    results. The scoreboard exposes final cards as ``AWAY 3 FINAL 5 HOME``;
    parsing this independent source prevents a completed game from remaining
    "scheduled" and unblocks automatic settlement.
    """
    parser = _TokenParser()
    parser.feed(page_html)
    joined = " ".join(token for token in parser.tokens if not _is_noise_token(token))
    team_pattern = "|".join(sorted((re.escape(key) for key in KBO_TEAMS), key=len, reverse=True))
    pattern = re.compile(
        rf"\b(?P<away>{team_pattern})\s+(?P<away_score>\d{{1,2}})\s+FINAL\s+"
        rf"(?P<home_score>\d{{1,2}})\s+(?P<home>{team_pattern})\b",
        re.I,
    )
    results: dict[tuple[str, str], dict[str, Any]] = {}
    for match in pattern.finditer(joined):
        away = match.group("away").upper()
        home = match.group("home").upper()
        results[(away, home)] = {
            "away_score": int(match.group("away_score")),
            "home_score": int(match.group("home_score")),
            "status": "final",
            "detailed_status": "Final",
            "source": "KBO official scoreboard",
        }

    terminal_words = (
        "CANCELLED", "CANCELED", "NO GAME", "NO-GAME", "NOGAME",
        "POSTPONED", "우천취소", "경기취소", "취소", "노게임", "우천연기", "경기연기",
    )
    terminal_pattern = "|".join(re.escape(word) for word in terminal_words)
    cancellation_patterns = (
        re.compile(rf"\b(?P<away>{team_pattern})\s+(?P<state>{terminal_pattern})\s+(?P<home>{team_pattern})\b", re.I),
        re.compile(rf"\b(?P<away>{team_pattern})\s+(?:VS\s+)?(?P<home>{team_pattern})\s+(?P<state>{terminal_pattern})\b", re.I),
    )
    for cancellation_pattern in cancellation_patterns:
        for match in cancellation_pattern.finditer(joined):
            away = match.group("away").upper()
            home = match.group("home").upper()
            state = match.group("state")
            status = "cancelled" if _contains_any_status_term(state, ASIAN_VOID_TERMS) else "postponed"
            results[(away, home)] = {
                "away_score": None,
                "home_score": None,
                "status": status,
                "detailed_status": "No Game / Cancelled" if status == "cancelled" else "Postponed",
                "settlement_disposition": "void",
                "status_reason": state,
                "source": "KBO official scoreboard",
            }
    return results

def _compact_team_token(value: Any) -> str:
    text = str(value or "").strip().upper()
    return "".join(ch for ch in text if ch.isalnum())


def _team_from_token(token: str, teams: dict[str, TeamInfo]) -> str | None:
    cleaned = re.sub(r"\s+", " ", str(token or "")).strip()
    compact = _compact_team_token(cleaned)
    if not compact:
        return None
    for key, info in teams.items():
        identities = (key, info.name, info.zh, info.abbr, *info.aliases)
        if compact in {_compact_team_token(value) for value in identities}:
            return key
    return None


def _selection_team_key(
    selection: dict[str, Any] | None,
    side: str,
    teams: dict[str, TeamInfo],
) -> str | None:
    selection = selection or {}
    snapshot = selection.get("prediction_snapshot") if isinstance(selection.get("prediction_snapshot"), dict) else {}
    selection_game = selection.get("game") if isinstance(selection.get("game"), dict) else {}
    snapshot_game = snapshot.get("game") if isinstance(snapshot.get("game"), dict) else {}
    candidates: list[Any] = []
    for game in (selection_game, snapshot_game):
        team = game.get(side) if isinstance(game.get(side), dict) else {}
        candidates.extend(team.get(key) for key in ("id", "team_id", "name", "team_name", "name_zh", "abbr", "short_name"))
    prefix = f"{side}_team_"
    candidates.extend(selection.get(f"{prefix}{suffix}") for suffix in ("id", "name", "abbr"))
    for value in candidates:
        key = _team_from_token(str(value or ""), teams)
        if key:
            return key
    return None


def _game_pk_date(game_pk: str) -> date:
    match = re.search(r"_(?P<date>\d{8})_", str(game_pk or ""))
    if not match:
        raise AsianBaseballSettlementLookupError(
            "無效的亞洲棒球賽事編號", code="invalid_game_pk", details={"game_pk": str(game_pk or "")}
        )
    try:
        return datetime.strptime(match.group("date"), "%Y%m%d").date()
    except ValueError as exc:
        raise AsianBaseballSettlementLookupError(
            "無效的亞洲棒球賽事日期", code="invalid_game_date", details={"game_pk": str(game_pk or "")}
        ) from exc


def _game_pk_cpbl_number(game_pk: str) -> str | None:
    match = re.fullmatch(r"cpbl_\d{8}_(?P<number>\d+)", str(game_pk or ""), re.I)
    return match.group("number") if match else None


def _game_pk_kbo_teams(game_pk: str) -> tuple[str | None, str | None]:
    match = re.fullmatch(
        r"kbo_\d{8}_(?P<away>[A-Z0-9]+)_(?P<home>[A-Z0-9]+)_\d+",
        str(game_pk or ""), re.I,
    )
    if not match:
        return None, None
    return match.group("away").upper(), match.group("home").upper()


def _team_payload(info: TeamInfo, score: int | None = None) -> dict[str, Any]:
    return {
        "id": info.key,
        "name": info.name,
        "short_name": info.key,
        "name_zh": info.zh,
        "abbr": info.abbr,
        "score": score,
        "probable_pitcher": {"id": None, "name": "尚未公布", "announced": False},
    }


def _status(value: str, score: tuple[int, int] | None, start: datetime | None, now: datetime | None = None) -> tuple[str, str]:
    """Normalize an Asian baseball game state without treating live scores as final.

    CPBL exposes the current score while a game is still in progress.  The old
    implementation promoted *any* score pair to ``final`` before checking the
    official live marker, so the settlement scheduler could grade a game in the
    middle innings.  Terminal settlement now requires an explicit final marker,
    or a conservative elapsed-time fallback when the official marker is absent.
    """

    text = str(value or "").strip().lower()
    current = (now or datetime.now(TAIPEI)).astimezone(TAIPEI)
    local_start = start.astimezone(TAIPEI) if start is not None else None

    if _contains_any_status_term(text, ASIAN_VOID_TERMS):
        return "cancelled", "No Game / Cancelled"
    if _contains_any_status_term(text, ASIAN_POSTPONED_TERMS) or any(
        word in text for word in ("延賽", "rained out")
    ):
        return "postponed", "Postponed"

    # Official state always wins.  In particular, check live before considering
    # the presence of a score because CPBL publishes inning-by-inning scores.
    if any(word in text for word in ("已結束", "final", "ended", "完賽", "比賽結束")):
        return "final", "Final"
    if any(word in text for word in ("比賽中", "進行中", "in progress", "live")):
        return "live", "In Progress"
    if any(word in text for word in ("未開始", "未開賽", "scheduled", "preview", "即將開始")):
        return "upcoming", "Scheduled"

    if local_start is not None:
        if current < local_start:
            return "upcoming", "Scheduled"

        # Scores with no official terminal marker are considered live during a
        # generous baseball game window.  This prevents premature grading while
        # still allowing old completed fixtures with incomplete status text to
        # become final after the safety window expires.
        if score is not None:
            if current <= local_start + timedelta(hours=8):
                return "live", "In Progress"
            return "final", "Final (elapsed-time fallback)"

        if current <= local_start + timedelta(hours=8):
            return "live", "In Progress"
        return "result_pending", "Result Pending"

    # Without a trustworthy start time, a score alone is not enough to settle.
    # Waiting for the official final marker is safer than publishing a false
    # win/loss while the game is live.
    if score is not None:
        return "result_pending", "Result Pending"
    return "upcoming", "Scheduled"


def _game_payload(
    league: str,
    target_date: date,
    game_id: str,
    away_key: str,
    home_key: str,
    teams: dict[str, TeamInfo],
    *,
    local_time: str,
    local_tz: ZoneInfo,
    away_score: int | None = None,
    home_score: int | None = None,
    raw_status: str = "",
    venue: str = "",
    source_url: str = "",
) -> dict[str, Any]:
    tm = TIME_RE.match(local_time or "")
    start = datetime.combine(target_date, time(int(tm.group("h")), int(tm.group("m"))), tzinfo=local_tz) if tm else datetime.combine(target_date, time(18, 30), tzinfo=local_tz)
    taipei_start = start.astimezone(TAIPEI)
    score = (away_score, home_score) if away_score is not None and home_score is not None else None
    status, detailed = _status(raw_status, score, taipei_start)
    payload = {
        "league": league,
        "season": target_date.year,
        "game_pk": game_id,
        "external_game_id": game_id,
        "game_date": taipei_start.isoformat(),
        "date_taiwan": taipei_start.date().isoformat(),
        "time_taiwan": taipei_start.strftime("%H:%M"),
        "display_time_taiwan": f"台灣 {taipei_start:%H:%M}",
        "status": status,
        "detailed_status": detailed,
        "inning": None,
        "inning_state": "",
        "venue_id": None,
        "venue": VENUE_ALIASES.get(venue.upper(), venue),
        "game_type": "regular_season",
        "season_context": "regular_season",
        "event_label": f"{league} 例行賽" if league == "KBO" else "中華職棒例行賽",
        "is_special_event": False,
        "analysis_available": True,
        "analysis_status": "base_model",
        "away": _team_payload(teams[away_key], away_score),
        "home": _team_payload(teams[home_key], home_score),
        "source_url": source_url,
        "official_schedule_url": source_url,
    }
    # KBO/CPBL postponed or no-game fixtures are a new future event when
    # replayed. The original published market is therefore terminally void,
    # not an indefinitely pending recommendation.
    if league in {"KBO", "CPBL"} and status in {"cancelled", "postponed"}:
        payload["settlement_disposition"] = "void"
        payload["status_reason"] = str(raw_status or detailed)
        payload["away"]["score"] = None
        payload["home"]["score"] = None
    return payload


def parse_kbo_schedule(page_html: str, target_date: date, source_url: str) -> list[dict[str, Any]]:
    parser = _TableParser("tblScheduleList")
    parser.feed(page_html)
    rows = parser.rows
    if not rows:
        fallback = _TableParser()
        fallback.feed(page_html)
        rows = fallback.rows
    current_date: date | None = None
    games: list[dict[str, Any]] = []
    sequence = 0
    for cells in rows:
        values = [re.sub(r"\s+", " ", value).strip() for value in cells if value.strip()]
        if not values:
            continue
        for value in values[:2]:
            match = KBO_DATE_RE.search(value)
            if match:
                try:
                    current_date = date(target_date.year, int(match.group("month")), int(match.group("day")))
                except ValueError:
                    current_date = None
                break
        if current_date != target_date:
            continue
        time_value = next((value for value in values if TIME_RE.match(value)), None)
        team_positions = [(idx, _team_from_token(value, KBO_TEAMS)) for idx, value in enumerate(values)]
        team_positions = [(idx, key) for idx, key in team_positions if key]
        if not time_value or len(team_positions) < 2:
            continue
        away_key, home_key = team_positions[0][1], team_positions[1][1]
        if away_key == home_key:
            continue
        away_score, home_score, _score_source = _extract_split_score_pair(values, KBO_TEAMS)
        joined = " ".join(values)
        if _contains_any_status_term(joined, ASIAN_VOID_TERMS):
            raw_status = "No Game / Cancelled"
            away_score = home_score = None
        elif _contains_any_status_term(joined, ASIAN_POSTPONED_TERMS) or "rained out" in joined.lower():
            raw_status = "Postponed"
            away_score = home_score = None
        else:
            raw_status = "Final" if away_score is not None and home_score is not None else ""
        last_team_index = team_positions[1][0]
        venue = ""
        for value in values[last_team_index + 1:]:
            if value in {"-", "REGULAR", "FINAL"} or TIME_RE.match(value) or SCORE_RE.match(value) or _integer_score(value) is not None:
                continue
            if _team_from_token(value, KBO_TEAMS):
                continue
            if value.upper().endswith("T") or re.fullmatch(r"[A-Z]+-?\d*T", value.upper()):
                continue
            venue = _safe_venue_token(value)
            if venue:
                break
        sequence += 1
        game_id = f"kbo_{target_date:%Y%m%d}_{away_key}_{home_key}_{sequence}"
        games.append(_game_payload("KBO", target_date, game_id, away_key, home_key, KBO_TEAMS, local_time=time_value, local_tz=SEOUL, away_score=away_score, home_score=home_score, raw_status=raw_status, venue=venue, source_url=source_url))
    return games


def _cpbl_time(raw: str | None, target_date: date) -> str:
    match = TIME_RE.match(str(raw or ""))
    if match:
        h, m = int(match.group("h")), int(match.group("m"))
        # The advanced stats page currently serializes scheduled local times as UTC.
        if h <= 3:
            h = (h + 16) % 24
        return f"{h:02d}:{m:02d}"
    # Official CPBL defaults: weekday night games, weekend afternoon/evening.
    return "17:05" if target_date.weekday() >= 5 else "18:35"


def _normalise_cpbl_tokens(raw_tokens: list[str]) -> list[str]:
    """Normalise CPBL's responsive DOM into stable logical tokens.

    The official page may render a game marker as one text node (``GAME 211未開始``)
    or as three adjacent nodes (``GAME`` / ``211`` / ``未開始``).  The old parser
    only supported the first form, which could silently return an empty schedule
    after a harmless upstream markup change.
    """
    cleaned: list[str] = []
    for raw in raw_tokens:
        token = re.sub(r"\s+", " ", html.unescape(str(raw or "")).replace("\xa0", " ")).strip()
        if token and (not cleaned or cleaned[-1] != token):
            cleaned.append(token)

    tokens: list[str] = []
    i = 0
    while i < len(cleaned):
        token = cleaned[i]
        upper = token.upper()
        if upper == "GAME":
            if i + 1 < len(cleaned):
                number_status = CPBL_GAME_NUMBER_STATUS_RE.match(cleaned[i + 1])
                if number_status:
                    logical = f"GAME {number_status.group('game')}"
                    status = number_status.group("status") or ""
                    consumed = 2
                    if not status and i + 2 < len(cleaned) and CPBL_GAME_STATUS_RE.match(cleaned[i + 2]):
                        status = cleaned[i + 2]
                        consumed = 3
                    if status:
                        logical += f" {status}"
                    tokens.append(logical)
                    i += consumed
                    continue
        game_match = CPBL_GAME_RE.fullmatch(token)
        if game_match and not game_match.group("status") and i + 1 < len(cleaned) and CPBL_GAME_STATUS_RE.match(cleaned[i + 1]):
            tokens.append(f"{token} {cleaned[i + 1]}")
            i += 2
            continue
        tokens.append(token)
        i += 1
    return tokens


def _cpbl_daily_header_date(tokens: list[str], year: int) -> date | None:
    """Return the compact schedule header date shown above ``賽程列表``.

    The CPBL responsive page exposes a compact local-day schedule and a
    separate monthly list.  The monthly list has previously serialized dates
    one day ahead of the detail pages, so the compact header is used to detect
    the provider's current date alignment instead of hard-coding a shift.
    """

    for token in tokens:
        if token.strip() == "賽程列表":
            break
        match = CPBL_DAILY_DATE_RE.fullmatch(token.strip())
        if not match:
            continue
        try:
            return date(year, int(match.group("month")), int(match.group("day")))
        except ValueError:
            continue
    return None


def _cpbl_daily_card_games(tokens: list[str], target_date: date, source_url: str) -> list[dict[str, Any]]:
    """Parse the compact local-day cards rendered above the monthly list."""

    header_index: int | None = None
    for index, token in enumerate(tokens):
        match = CPBL_DAILY_DATE_RE.fullmatch(token.strip())
        if not match:
            continue
        try:
            token_date = date(target_date.year, int(match.group("month")), int(match.group("day")))
        except ValueError:
            continue
        if token_date == target_date:
            header_index = index
            break
    if header_index is None:
        return []

    end_index = len(tokens)
    for index in range(header_index + 1, len(tokens)):
        if tokens[index].strip() == "賽程列表":
            end_index = index
            break

    window = tokens[header_index + 1:end_index]
    markers = [
        index for index, token in enumerate(window)
        if token.strip() in {"一軍例行賽", "一軍季後挑戰賽", "一軍總冠軍賽", "二軍例行賽", "二軍總冠軍賽"}
    ]
    games: list[dict[str, Any]] = []
    for position, start in enumerate(markers):
        competition = window[start].strip()
        stop = markers[position + 1] if position + 1 < len(markers) else len(window)
        block = window[start:stop]
        if not competition.startswith("一軍"):
            continue
        game_match = next((CPBL_GAME_RE.search(token) for token in block if CPBL_GAME_RE.search(token)), None)
        if not game_match:
            continue
        teams: list[str] = []
        for token in block:
            key = _team_from_token(token, CPBL_TEAMS)
            if key and (not teams or teams[-1] != key):
                teams.append(key)
        if len(teams) < 2:
            continue
        away_key, home_key = teams[0], teams[1]
        away_score, home_score, _score_source = _extract_split_score_pair(block, CPBL_TEAMS)
        time_value = next((token for token in block if TIME_RE.match(token)), None)
        ignored = {
            "vs", "成績看板", competition, CPBL_TEAMS[away_key].zh, CPBL_TEAMS[home_key].zh,
            CPBL_TEAMS[away_key].name, CPBL_TEAMS[home_key].name,
        }
        venue = ""
        for token in block:
            stripped = token.strip()
            if stripped in ignored or CPBL_GAME_RE.search(stripped) or TIME_RE.match(stripped) or (SCORE_RE.match(stripped) and not TIME_RE.match(stripped)) or _integer_score(stripped) is not None or RECORD_RE.match(stripped):
                continue
            if _team_from_token(stripped, CPBL_TEAMS):
                continue
            if stripped.startswith("Image:") or stripped.startswith("共 "):
                continue
            if stripped in {"未開始", "已結束", "延賽", "比賽中", "進行中", "取消"}:
                continue
            if not venue:
                venue = _safe_venue_token(stripped)
        game_no = game_match.group("game")
        raw_status = game_match.group("status") or next((token for token in block if CPBL_GAME_STATUS_RE.fullmatch(token.strip())), "")
        game_id = f"cpbl_{target_date:%Y%m%d}_{game_no}"
        payload = _game_payload(
            "CPBL", target_date, game_id, away_key, home_key, CPBL_TEAMS,
            local_time=_cpbl_time(time_value, target_date), local_tz=TAIPEI,
            away_score=away_score, home_score=home_score, raw_status=raw_status,
            venue=venue, source_url=source_url,
        )
        payload["official_source_date"] = target_date.isoformat()
        payload["date_correction_days"] = 0
        payload["date_alignment"] = "compact_daily"
        games.append(payload)
    return games


def _cpbl_game_number(game: dict[str, Any]) -> str | None:
    match = re.search(r"_(\d+)$", str(game.get("game_pk") or ""))
    return match.group(1) if match else None


def _cpbl_monthly_date_correction(tokens: list[str], year: int) -> int:
    """Detect the monthly-list date correction using overlapping game numbers.

    Example observed on the live provider page: compact header ``7/21`` lists
    GAME 211/212, while the monthly table labels those same immutable game
    numbers as ``7月22日``.  The inferred correction is therefore ``-1`` and
    every monthly date is translated back one local day.  If the provider
    later fixes its markup, the overlap resolves to zero automatically.
    """

    daily_date = _cpbl_daily_header_date(tokens, year)
    if daily_date is None:
        return 0
    daily_games = _cpbl_daily_card_games(tokens, daily_date, "")
    daily_numbers = {number for game in daily_games if (number := _cpbl_game_number(game))}
    if not daily_numbers:
        return 0

    monthly_hits: dict[date, int] = {}
    current_date: date | None = None
    in_monthly_list = False
    for token in tokens:
        stripped = token.strip()
        if stripped == "賽程列表":
            in_monthly_list = True
            continue
        if not in_monthly_list:
            continue
        date_match = CPBL_DATE_RE.search(stripped)
        if date_match:
            try:
                current_date = date(year, int(date_match.group("month")), int(date_match.group("day")))
            except ValueError:
                current_date = None
            continue
        if current_date is None:
            continue
        game_match = CPBL_GAME_RE.search(stripped)
        if game_match and game_match.group("game") in daily_numbers:
            monthly_hits[current_date] = monthly_hits.get(current_date, 0) + 1

    if not monthly_hits:
        return 0
    matched_date, _ = max(monthly_hits.items(), key=lambda item: (item[1], -abs((item[0] - daily_date).days)))
    correction = (daily_date - matched_date).days
    return correction if correction in {-1, 0, 1} else 0


def _parse_cpbl_monthly_games(
    tokens: list[str],
    target_date: date,
    source_url: str,
    date_correction_days: int,
) -> list[dict[str, Any]]:
    current_source_date: date | None = None
    games: list[dict[str, Any]] = []
    i = 0
    while i < len(tokens):
        date_match = CPBL_DATE_RE.search(tokens[i])
        if date_match:
            try:
                current_source_date = date(target_date.year, int(date_match.group("month")), int(date_match.group("day")))
            except ValueError:
                current_source_date = None
            i += 1
            continue
        game_match = CPBL_GAME_RE.search(tokens[i])
        if not game_match:
            i += 1
            continue
        start = i
        end = i + 1
        while end < len(tokens) and not CPBL_GAME_RE.search(tokens[end]) and not CPBL_DATE_RE.search(tokens[end]):
            end += 1
        block = tokens[start:end]
        i = end
        if current_source_date is None:
            continue
        effective_date = current_source_date + timedelta(days=date_correction_days)
        if effective_date != target_date:
            continue
        teams: list[str] = []
        for token in block:
            key = _team_from_token(token, CPBL_TEAMS)
            if key and (not teams or teams[-1] != key):
                teams.append(key)
        if len(teams) < 2:
            continue
        away_key, home_key = teams[0], teams[1]
        away_score, home_score, _score_source = _extract_split_score_pair(block, CPBL_TEAMS)
        time_value = next((token for token in block if TIME_RE.match(token)), None)
        ignored = {"vs", "成績看板", "一軍例行賽", "二軍例行賽", CPBL_TEAMS[away_key].zh, CPBL_TEAMS[home_key].zh}
        venue = ""
        for token in block:
            if token in ignored or CPBL_GAME_RE.search(token) or TIME_RE.match(token) or (SCORE_RE.match(token) and not TIME_RE.match(token)) or _integer_score(token) is not None or RECORD_RE.match(token):
                continue
            if _team_from_token(token, CPBL_TEAMS):
                continue
            if token.startswith("Image:") or token.startswith("共 "):
                continue
            if not venue:
                venue = _safe_venue_token(token)
        game_no = game_match.group("game")
        game_id = f"cpbl_{target_date:%Y%m%d}_{game_no}"
        payload = _game_payload(
            "CPBL", target_date, game_id, away_key, home_key, CPBL_TEAMS,
            local_time=_cpbl_time(time_value, target_date), local_tz=TAIPEI,
            away_score=away_score, home_score=home_score,
            raw_status=game_match.group("status") or "", venue=venue, source_url=source_url,
        )
        payload["official_source_date"] = current_source_date.isoformat()
        payload["date_correction_days"] = date_correction_days
        payload["date_alignment"] = "monthly_overlap_inferred" if date_correction_days else "monthly_exact"
        games.append(payload)
    return games


def _merge_cpbl_games(primary: list[dict[str, Any]], secondary: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Merge duplicate CPBL cards by immutable GAME number, preferring scores."""

    merged: dict[str, dict[str, Any]] = {}
    order: list[str] = []
    for game in [*secondary, *primary]:
        key = _cpbl_game_number(game) or str(game.get("game_pk") or "")
        if key not in merged:
            order.append(key)
            merged[key] = game
            continue
        previous = merged[key]
        previous_complete = (previous.get("away") or {}).get("score") is not None and (previous.get("home") or {}).get("score") is not None
        current_complete = (game.get("away") or {}).get("score") is not None and (game.get("home") or {}).get("score") is not None
        if current_complete or not previous_complete:
            merged[key] = game
    return [merged[key] for key in order]


def cpbl_expected_game_count(page_html: str, target_date: date) -> int | None:
    parser = _TokenParser()
    parser.feed(page_html)
    tokens = _normalise_cpbl_tokens(parser.tokens)
    daily_games = _cpbl_daily_card_games(tokens, target_date, "")
    correction = _cpbl_monthly_date_correction(tokens, target_date.year)

    current_source_date: date | None = None
    for token in tokens:
        date_match = CPBL_DATE_RE.search(token)
        if date_match:
            try:
                current_source_date = date(target_date.year, int(date_match.group("month")), int(date_match.group("day")))
            except ValueError:
                current_source_date = None
            continue
        effective_date = current_source_date + timedelta(days=correction) if current_source_date else None
        if effective_date == target_date:
            count_match = CPBL_COUNT_RE.search(token)
            if count_match:
                return max(int(count_match.group("count")), len(daily_games))
    return len(daily_games) if daily_games else None


def parse_cpbl_schedule(page_html: str, target_date: date, source_url: str) -> list[dict[str, Any]]:
    parser = _TokenParser()
    parser.feed(page_html)
    tokens = _normalise_cpbl_tokens(parser.tokens)
    daily_games = _cpbl_daily_card_games(tokens, target_date, source_url)
    correction = _cpbl_monthly_date_correction(tokens, target_date.year)
    monthly_games = _parse_cpbl_monthly_games(tokens, target_date, source_url, correction)
    return _merge_cpbl_games(daily_games, monthly_games)

def _team_form(team_key: str, games: list[dict[str, Any]], limit: int = 10) -> dict[str, Any]:
    relevant: list[dict[str, Any]] = []
    for game in games:
        if game.get("status") != "final":
            continue
        away = game.get("away") or {}
        home = game.get("home") or {}
        if str(away.get("id")) == team_key or str(home.get("id")) == team_key:
            relevant.append(game)
    relevant.sort(key=lambda item: str(item.get("game_date") or ""), reverse=True)
    relevant = relevant[:limit]
    wins = losses = ties = runs_for = runs_against = 0
    for game in relevant:
        away = game.get("away") or {}
        home = game.get("home") or {}
        is_away = str(away.get("id")) == team_key
        rf = away.get("score") if is_away else home.get("score")
        ra = home.get("score") if is_away else away.get("score")
        if rf is None or ra is None:
            continue
        runs_for += int(rf)
        runs_against += int(ra)
        if rf > ra:
            wins += 1
        elif rf < ra:
            losses += 1
        else:
            ties += 1
    decided = wins + losses
    pct = wins / decided if decided else 0.5
    return {
        "available": bool(relevant),
        "games": len(relevant),
        "wins": wins,
        "losses": losses,
        "ties": ties,
        "win_pct": round(pct, 3),
        "runs_for": runs_for,
        "runs_against": runs_against,
        "run_diff": runs_for - runs_against,
        "runs_per_game": round(runs_for / len(relevant), 2) if relevant else None,
        "runs_allowed_per_game": round(runs_against / len(relevant), 2) if relevant else None,
    }


def build_baseline_analysis(league: str, game: dict[str, Any], history: list[dict[str, Any]]) -> dict[str, Any]:
    away = game.get("away") or {}
    home = game.get("home") or {}
    away_form = _team_form(str(away.get("id")), history)
    home_form = _team_form(str(home.get("id")), history)
    away_strength = away_form.get("win_pct", 0.5) * 0.72 + max(-0.12, min(0.12, float(away_form.get("run_diff") or 0) / 80.0))
    home_strength = home_form.get("win_pct", 0.5) * 0.72 + max(-0.12, min(0.12, float(home_form.get("run_diff") or 0) / 80.0)) + 0.035
    delta = home_strength - away_strength
    home_probability = max(38.0, min(68.0, 50.0 + delta * 45.0))
    away_probability = 100.0 - home_probability
    side = "home" if home_probability >= away_probability else "away"
    confidence = max(home_probability, away_probability)
    history_ready = bool(away_form.get("available") and home_form.get("available"))
    data_quality = 0.56 if history_ready else 0.39
    avg_away = float(away_form.get("runs_per_game") or 4.1)
    avg_home = float(home_form.get("runs_per_game") or 4.2)
    allow_away = float(away_form.get("runs_allowed_per_game") or 4.2)
    allow_home = float(home_form.get("runs_allowed_per_game") or 4.1)
    projected_away = max(1.8, min(8.0, (avg_away + allow_home) / 2.0))
    projected_home = max(1.8, min(8.0, (avg_home + allow_away) / 2.0 + 0.18))
    picked = game.get(side) or {}
    groups = {
        "team": {"available": True, "quality": 0.62 if history_ready else 0.38, "away": away_form, "home": home_form, "metrics": ["近況勝率", "得失分差", "主場加成"]},
        "starter": {"available": False, "quality": 0.0, "both_starters_ready": False, "metrics": [], "message": "預告先發尚未完整，已降低模型信心。"},
        "offense": {"available": history_ready, "quality": 0.45 if history_ready else 0.2, "metrics": ["近況場均得分"] if history_ready else []},
        "bullpen": {"available": False, "quality": 0.0, "metrics": [], "message": "牛棚逐日用量來源待補強。"},
        "advanced": {"available": False, "quality": 0.0, "metrics": []},
        "environment": {"available": False, "quality": 0.0, "metrics": []},
    }
    return {
        "league": league,
        "model_version": f"dm-{league.lower()}-baseline-v1.0",
        "model_stage": "base",
        "status": "prediction_moneyline",
        "official_recommendation_enabled": True,
        "full_market_recommendation_enabled": False,
        "message": f"{league} 基礎模型已就緒；先發、打線或進階資料不足只降低信心，不阻擋免費推薦。",
        "data_basis": {
            "model_stage": "base",
            "base_modules_ready": True,
            "pick_direction_ready": True,
            "base_recommendation_ready": True,
            "full_market_ready": False,
            "starter_names_ready": False,
            "starter_stats_ready": False,
            "official_lineups_ready": False,
            "recommendation_ready": True,
            "used_modules": ["官方賽程", "官方近期賽果", "得失分差", "主場加成"],
            "missing_core": ["預告先發", "正式打線", "牛棚逐日用量"],
            "data_quality": round(data_quality, 2),
        },
        "model_weights": {"engine": {"team_strength": 0.72, "starter": 0.0, "lineup": 0.18, "bullpen": 0.0, "advanced": 0.0, "environment": 0.0, "home_advantage": 0.10}},
        "confidence_cap": 68.0,
        "pick": {"side": side, "team": picked.get("name"), "team_name_zh": picked.get("name_zh"), "label": f"{picked.get('name_zh') or picked.get('abbr')} 獨贏"},
        "home_probability": round(home_probability, 1),
        "away_probability": round(away_probability, 1),
        "confidence": round(confidence, 1),
        "data_quality": round(data_quality, 2),
        "projections": {"away_runs": round(projected_away, 2), "home_runs": round(projected_home, 2), "total_runs": round(projected_away + projected_home, 2), "home_margin": round(projected_home - projected_away, 2), "quality": round(data_quality, 2), "score": {"away": round(projected_away), "home": round(projected_home)}},
        "analysis_groups": groups,
        "lineups": {"away": {"official": False}, "home": {"official": False}},
        "bullpen_usage": {"away": {"available": False}, "home": {"available": False}},
        "roster_status": {"available": False},
        "environment": {"available": False},
        "team_profiles": {"away": {"form": away_form}, "home": {"form": home_form}},
    }


def parse_game_start(game: dict[str, Any]) -> datetime:
    raw = str(game.get("game_date") or "")
    try:
        value = datetime.fromisoformat(raw.replace("Z", "+00:00"))
        if value.tzinfo is None:
            value = value.replace(tzinfo=TAIPEI)
        return value.astimezone(TAIPEI)
    except ValueError:
        return datetime.min.replace(tzinfo=TAIPEI)


class AsianBaseballService:
    def __init__(self, settings: Settings, league: str, transport: httpx.AsyncBaseTransport | None = None) -> None:
        code = str(league).upper()
        if code not in {"KBO", "CPBL"}:
            raise ValueError("AsianBaseballService only supports KBO or CPBL")
        self.settings = settings
        self.league = code
        self.cache = AsyncTTLCache()
        self.client = httpx.AsyncClient(
            timeout=settings.request_timeout_seconds,
            follow_redirects=True,
            trust_env=False,
            transport=transport,
            headers={"Accept": "text/html,application/xhtml+xml", "Accept-Language": "zh-TW,ko-KR,en;q=0.8", "User-Agent": f"DiamondMind/{code}-official-adapter/1.0"},
        )

    @property
    def source_url(self) -> str:
        return self.settings.kbo_schedule_url if self.league == "KBO" else self.settings.cpbl_schedule_url

    @property
    def scoreboard_url(self) -> str:
        if self.league != "KBO":
            return self.source_url
        return self.settings.kbo_scoreboard_url

    async def aclose(self) -> None:
        await self.client.aclose()

    async def _get_html(self) -> str:
        key = f"{self.league}:{self.source_url}"
        cached = self.cache.get(key)
        if cached and cached.is_fresh:
            return str(cached.value)
        async with self.cache.lock(key):
            cached = self.cache.get(key)
            if cached and cached.is_fresh:
                return str(cached.value)
            try:
                response = await self.client.get(self.source_url)
                response.raise_for_status()
                body = response.text
                marker = "KBO" if self.league == "KBO" else "中華職棒"
                if marker not in body and (self.league != "CPBL" or "賽程" not in body):
                    raise ValueError(f"Unexpected {self.league} response")
                self.cache.set(key, body, self.settings.asian_baseball_cache_ttl_seconds, self.settings.asian_baseball_stale_ttl_seconds)
                return body
            except (httpx.HTTPError, ValueError) as exc:
                if cached and cached.can_serve_stale:
                    return str(cached.value)
                raise AsianBaseballUpstreamError(f"{self.league} 官方賽程目前暫時無法連線") from exc


    async def _get_kbo_scoreboard_html(self, target_date: date) -> str:
        key = f"KBO:scoreboard:{target_date.isoformat()}"
        cached = self.cache.get(key)
        if cached and cached.is_fresh:
            return str(cached.value)
        async with self.cache.lock(key):
            cached = self.cache.get(key)
            if cached and cached.is_fresh:
                return str(cached.value)
            try:
                response = await self.client.get(
                    self.scoreboard_url, params={"searchDate": target_date.isoformat()}
                )
                response.raise_for_status()
                body = response.text
                if "Scoreboard" not in body and "FINAL" not in body.upper():
                    raise ValueError("Unexpected KBO scoreboard response")
                self.cache.set(
                    key, body, self.settings.kbo_scoreboard_cache_ttl_seconds,
                    self.settings.asian_baseball_stale_ttl_seconds,
                )
                return body
            except (httpx.HTTPError, ValueError) as exc:
                if cached and cached.can_serve_stale:
                    return str(cached.value)
                raise AsianBaseballUpstreamError("KBO 官方賽果目前暫時無法連線") from exc

    async def _merge_kbo_scoreboard(self, items: list[dict[str, Any]], target_date: date) -> list[dict[str, Any]]:
        now = datetime.now(TAIPEI)
        needs_result_check = target_date < now.date() or any(
            str(item.get("status") or "") not in {"final", "postponed"}
            and parse_game_start(item) <= now - timedelta(hours=2)
            for item in items
        )
        if not items or not needs_result_check:
            return items
        try:
            results = parse_kbo_scoreboard_results(await self._get_kbo_scoreboard_html(target_date))
        except AsianBaseballUpstreamError:
            return items
        for item in items:
            away = str((item.get("away") or {}).get("id") or "").upper()
            home = str((item.get("home") or {}).get("id") or "").upper()
            result = results.get((away, home))
            if not result:
                continue
            item["away"]["score"] = result.get("away_score")
            item["home"]["score"] = result.get("home_score")
            item["status"] = result.get("status") or "result_pending"
            item["detailed_status"] = result.get("detailed_status") or "Result Pending"
            item["result_source"] = result["source"]
            if result.get("settlement_disposition"):
                item["settlement_disposition"] = result["settlement_disposition"]
                item["status_reason"] = result.get("status_reason") or item["detailed_status"]
        return items

    def parse_schedule(self, page_html: str, target_date: date) -> list[dict[str, Any]]:
        if self.league == "KBO":
            return parse_kbo_schedule(page_html, target_date, self.source_url)
        return parse_cpbl_schedule(page_html, target_date, self.source_url)

    async def games_for_date(self, target_date: date) -> dict[str, Any]:
        body = await self._get_html()
        items = self.parse_schedule(body, target_date)
        if self.league == "KBO":
            items = await self._merge_kbo_scoreboard(items, target_date)
        expected_count = cpbl_expected_game_count(body, target_date) if self.league == "CPBL" else None
        parser_status = "ok"
        if expected_count is not None and len(items) < expected_count:
            parser_status = "partial" if items else "failed"
        cpbl_source_dates = sorted({
            str(item.get("official_source_date")) for item in items
            if item.get("official_source_date")
        }) if self.league == "CPBL" else []
        cpbl_corrections = sorted({
            int(item.get("date_correction_days") or 0) for item in items
        }) if self.league == "CPBL" else []
        return {
            "league": self.league,
            "date": target_date.isoformat(),
            "timezone": "Asia/Taipei",
            "count": len(items),
            "items": items,
            "meta": {
                "source": f"{self.league} official schedule",
                "source_url": self.source_url,
                "updated_at": datetime.now(TAIPEI).isoformat(),
                "cache": "adapter_cache",
                "parser_status": parser_status,
                "expected_count": expected_count,
                "official_source_dates": cpbl_source_dates,
                "date_correction_days": cpbl_corrections,
                "date_alignment_policy": "compact/monthly GAME overlap" if self.league == "CPBL" else None,
                "data_policy": "missing enrichment lowers confidence but does not block publication",
            },
        }

    async def _history(self, target_date: date, days: int = 28) -> list[dict[str, Any]]:
        body = await self._get_html()
        values: list[dict[str, Any]] = []
        # The official monthly pages contain the surrounding weeks. Parsing
        # every date locally avoids one upstream request per game/team.
        for offset in range(days, 0, -1):
            day = target_date - timedelta(days=offset)
            values.extend(self.parse_schedule(body, day))
        return values

    async def matchup_analysis(self, game_pk: str) -> dict[str, Any]:
        match = re.search(r"_(?P<date>\d{8})_", str(game_pk or ""))
        if not match:
            raise AsianBaseballUpstreamError(f"無效的 {self.league} 賽事編號")
        try:
            target_date = datetime.strptime(match.group("date"), "%Y%m%d").date()
        except ValueError as exc:
            raise AsianBaseballUpstreamError(f"無效的 {self.league} 賽事日期") from exc
        schedule, history = await asyncio.gather(self.games_for_date(target_date), self._history(target_date))
        game = next((item for item in schedule.get("items") or [] if str(item.get("game_pk")) == str(game_pk)), None)
        if not game:
            raise AsianBaseballUpstreamError(f"找不到指定的 {self.league} 賽事")
        analysis = build_baseline_analysis(self.league, game, history)
        return {"game": game, "analysis": analysis, "access": {"required_plan": "pro"}, "meta": {"source": f"{self.league} official schedule/results baseline", "updated_at": datetime.now(TAIPEI).isoformat(), "official_recommendation_enabled": True}}

    async def game_detail(self, game_pk: str) -> dict[str, Any]:
        return await self.matchup_analysis(game_pk)

    async def matchup_analyses(self, target_date: date, pitcher_limit: int | None = None) -> dict[str, Any]:
        schedule = await self.games_for_date(target_date)
        items: list[dict[str, Any]] = []
        for game in schedule.get("items") or []:
            if str(game.get("status") or "").lower() not in {"upcoming", "scheduled", "preview"}:
                continue
            try:
                items.append(await self.matchup_analysis(str(game.get("game_pk"))))
            except AsianBaseballUpstreamError:
                continue
        return {"league": self.league, "date": target_date.isoformat(), "count": len(items), "items": items, "meta": schedule.get("meta") or {}}

    async def game_result(
        self,
        game_pk: str,
        selection: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Resolve an official result without crossing the requested local date.

        KBO and CPBL frequently schedule the same matchup on consecutive days.
        Settlement must therefore remain on the date embedded in the published
        game id. Same-day regenerated ids are resolved by game number and/or
        normalized team identity, but yesterday or tomorrow are never accepted.
        """

        requested_pk = str(game_pk or "")
        target_date = _game_pk_date(requested_pk)
        teams = KBO_TEAMS if self.league == "KBO" else CPBL_TEAMS
        expected_away = _selection_team_key(selection, "away", teams)
        expected_home = _selection_team_key(selection, "home", teams)
        if self.league == "KBO":
            pk_away, pk_home = _game_pk_kbo_teams(requested_pk)
            expected_away = expected_away or pk_away
            expected_home = expected_home or pk_home
        requested_game_number = _game_pk_cpbl_number(requested_pk) if self.league == "CPBL" else None

        candidates: list[tuple[int, int, str, dict[str, Any]]] = []
        lookup_errors: list[dict[str, Any]] = []
        # Never cross the published local date. Both KBO and CPBL commonly use
        # the same matchup on consecutive days, and a completed adjacent-day
        # game must not settle today's recommendation. The CPBL parser already
        # normalizes provider display-date offsets into the requested date and
        # rebuilds game_pk with that requested date, so settlement does not need
        # a second ±1-day fallback.
        offsets = (0,)
        for offset in offsets:
            lookup_date = target_date + timedelta(days=offset)
            try:
                payload = await self.games_for_date(lookup_date)
            except AsianBaseballUpstreamError as exc:
                lookup_errors.append({"date": lookup_date.isoformat(), "error": type(exc).__name__})
                continue
            for game in payload.get("items") or []:
                current_pk = str(game.get("game_pk") or "")
                away_key = str((game.get("away") or {}).get("id") or "").upper()
                home_key = str((game.get("home") or {}).get("id") or "").upper()
                score = 0
                methods: list[str] = []
                if current_pk == requested_pk:
                    score += 140
                    methods.append("exact_game_pk")
                if requested_game_number and _game_pk_cpbl_number(current_pk) == requested_game_number:
                    score += 100
                    methods.append("cpbl_game_number")
                if expected_away and expected_home and away_key == expected_away and home_key == expected_home:
                    score += 120
                    methods.append("normalized_matchup")
                elif expected_away and expected_home and away_key == expected_home and home_key == expected_away:
                    # Orientation reversal is accepted only as a weaker fallback
                    # and remains visible in diagnostics.
                    score += 70
                    methods.append("reversed_matchup")
                if offset == 0:
                    score += 12
                elif abs(offset) == 1:
                    score += 5
                terminal = str(game.get("status") or "").lower() == "final"
                scores_ready = (game.get("away") or {}).get("score") is not None and (game.get("home") or {}).get("score") is not None
                if terminal:
                    score += 150
                if scores_ready:
                    score += 50
                if score > 0:
                    candidates.append((score, offset, "+".join(methods) or "date_candidate", game))

        if not candidates:
            raise AsianBaseballSettlementLookupError(
                f"找不到指定的 {self.league} 賽事結果",
                code="no_match",
                details={
                    "league": self.league,
                    "requested_game_pk": requested_pk,
                    "target_date": target_date.isoformat(),
                    "expected_away": expected_away,
                    "expected_home": expected_home,
                    "lookup_errors": lookup_errors,
                },
            )

        candidates.sort(key=lambda row: row[0], reverse=True)
        best_score, best_offset, best_method, best_game = candidates[0]
        tied = [row for row in candidates if row[0] == best_score]
        unique_ids = {str(row[3].get("game_pk") or "") for row in tied}
        if len(unique_ids) > 1:
            raise AsianBaseballSettlementLookupError(
                f"{self.league} 賽事配對結果不唯一，已安全略過",
                code="ambiguous_match",
                details={
                    "requested_game_pk": requested_pk,
                    "candidate_game_pks": sorted(unique_ids),
                    "score": best_score,
                },
            )
        if best_score < 90:
            raise AsianBaseballSettlementLookupError(
                f"{self.league} 賽事配對信心不足，已安全略過",
                code="low_confidence_match",
                details={
                    "requested_game_pk": requested_pk,
                    "resolved_game_pk": best_game.get("game_pk"),
                    "score": best_score,
                    "method": best_method,
                },
            )

        resolved = {**best_game}
        provider_date_offset_only = False
        resolved["settlement_match"] = {
            "requested_game_pk": requested_pk,
            "resolved_game_pk": str(best_game.get("game_pk") or ""),
            "method": best_method,
            "score": best_score,
            "date_offset_days": best_offset,
            "provider_date_offset_only": provider_date_offset_only,
            "expected_away": expected_away,
            "expected_home": expected_home,
        }
        return resolved
