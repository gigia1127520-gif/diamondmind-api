from __future__ import annotations

from copy import deepcopy
from datetime import date
from typing import Any


SCHEMA_VERSION = "1.0"
SUPPORTED_LEAGUES = ("MLB", "NPB", "KBO", "CPBL", "NBA", "EPL")
ACTIVE_LEAGUES = ("MLB", "NPB", "KBO", "CPBL")

SPORTS: dict[str, dict[str, Any]] = {
    "baseball": {
        "code": "baseball",
        "name": "Baseball",
        "name_zh": "棒球",
        "score_unit": "runs",
        "tie_possible": False,
        "leagues": ["MLB", "NPB", "KBO", "CPBL"],
        "market_types": ["moneyline", "run_line", "total"],
    },
    "basketball": {
        "code": "basketball",
        "name": "Basketball",
        "name_zh": "籃球",
        "score_unit": "points",
        "tie_possible": False,
        "leagues": ["NBA"],
        "market_types": ["moneyline", "spread", "total", "player_prop"],
    },
    "soccer": {
        "code": "soccer",
        "name": "Football / Soccer",
        "name_zh": "足球",
        "score_unit": "goals",
        "tie_possible": True,
        "leagues": ["EPL"],
        "market_types": [
            "three_way_moneyline",
            "asian_handicap",
            "total_goals",
            "both_teams_to_score",
            "correct_score",
        ],
    },
}

LEAGUES: dict[str, dict[str, Any]] = {
    "MLB": {
        "code": "MLB",
        "sport": "baseball",
        "name": "Major League Baseball",
        "name_zh": "美國職棒",
        "status": "active",
        "adapter": "mlb",
        "timezone": "America/New_York",
        "capabilities": [
            "schedule", "live_scores", "probable_pitchers", "analysis",
            "predictions", "real_odds", "settlement",
        ],
    },
    "NPB": {
        "code": "NPB",
        "sport": "baseball",
        "name": "Nippon Professional Baseball",
        "name_zh": "日本職棒",
        "status": "active",
        "adapter": "npb",
        "timezone": "Asia/Tokyo",
        "capabilities": [
            "schedule", "scores", "probable_pitchers", "standings", "team_form",
            "starter_stats", "analysis", "real_odds", "predictions", "parlays",
            "settlement",
        ],
    },
    "KBO": {
        "code": "KBO",
        "sport": "baseball",
        "name": "Korea Baseball Organization",
        "name_zh": "韓國職棒",
        "status": "active",
        "adapter": "kbo",
        "timezone": "Asia/Seoul",
        "capabilities": [
            "schedule", "scores", "team_form", "analysis", "real_odds",
            "predictions", "parlays", "settlement", "auto_publish",
        ],
        "planned_capabilities": ["probable_pitchers", "lineups", "bullpen_usage"],
    },
    "CPBL": {
        "code": "CPBL",
        "sport": "baseball",
        "name": "Chinese Professional Baseball League",
        "name_zh": "中華職棒",
        "status": "active",
        "adapter": "cpbl",
        "timezone": "Asia/Taipei",
        "capabilities": [
            "schedule", "scores", "team_form", "analysis", "predictions",
            "settlement", "auto_publish",
        ],
        "planned_capabilities": ["probable_pitchers", "lineups", "bullpen_usage", "real_odds", "parlays"],
    },
    "NBA": {
        "code": "NBA",
        "sport": "basketball",
        "name": "National Basketball Association",
        "name_zh": "美國職籃",
        "status": "adapter_pending",
        "adapter": None,
        "timezone": "America/New_York",
        "capabilities": [],
        "planned_capabilities": [
            "schedule", "live_scores", "lineups", "injuries", "team_form",
            "rest_days", "analysis", "real_odds", "predictions", "settlement",
        ],
    },
    "EPL": {
        "code": "EPL",
        "sport": "soccer",
        "name": "Premier League",
        "name_zh": "英格蘭超級足球聯賽",
        "status": "adapter_pending",
        "adapter": None,
        "timezone": "Europe/London",
        "capabilities": [],
        "planned_capabilities": [
            "schedule", "live_scores", "lineups", "injuries", "standings",
            "team_form", "xg", "analysis", "real_odds", "predictions", "settlement",
        ],
    },
}

MARKETS: dict[str, list[dict[str, Any]]] = {
    "baseball": [
        {
            "code": "moneyline",
            "name_zh": "獨贏",
            "selection_type": "team",
            "supports_draw": False,
            "line_required": False,
            "default_settlement": "includes_extra_innings",
        },
        {
            "code": "run_line",
            "name_zh": "讓分",
            "selection_type": "team",
            "supports_draw": False,
            "line_required": True,
            "default_settlement": "includes_extra_innings",
        },
        {
            "code": "total",
            "name_zh": "大小分",
            "selection_type": "over_under",
            "supports_draw": False,
            "line_required": True,
            "default_settlement": "includes_extra_innings",
        },
    ],
    "basketball": [
        {
            "code": "moneyline",
            "name_zh": "獨贏",
            "selection_type": "team",
            "supports_draw": False,
            "line_required": False,
            "default_settlement": "includes_overtime",
        },
        {
            "code": "spread",
            "name_zh": "讓分",
            "selection_type": "team",
            "supports_draw": False,
            "line_required": True,
            "default_settlement": "includes_overtime",
        },
        {
            "code": "total",
            "name_zh": "大小分",
            "selection_type": "over_under",
            "supports_draw": False,
            "line_required": True,
            "default_settlement": "includes_overtime",
        },
        {
            "code": "player_prop",
            "name_zh": "球員數據",
            "selection_type": "player",
            "supports_draw": False,
            "line_required": True,
            "default_settlement": "provider_rules",
        },
    ],
    "soccer": [
        {
            "code": "three_way_moneyline",
            "name_zh": "主和客",
            "selection_type": "home_draw_away",
            "supports_draw": True,
            "line_required": False,
            "default_settlement": "regulation_time_only",
        },
        {
            "code": "asian_handicap",
            "name_zh": "亞洲讓球",
            "selection_type": "team",
            "supports_draw": False,
            "line_required": True,
            "default_settlement": "regulation_time_only",
        },
        {
            "code": "total_goals",
            "name_zh": "大小球",
            "selection_type": "over_under",
            "supports_draw": False,
            "line_required": True,
            "default_settlement": "regulation_time_only",
        },
        {
            "code": "both_teams_to_score",
            "name_zh": "雙方進球",
            "selection_type": "yes_no",
            "supports_draw": False,
            "line_required": False,
            "default_settlement": "regulation_time_only",
        },
        {
            "code": "correct_score",
            "name_zh": "正確比分",
            "selection_type": "score",
            "supports_draw": True,
            "line_required": False,
            "default_settlement": "regulation_time_only",
        },
    ],
}


def normalize_league_code(value: Any) -> str:
    code = str(value or "").strip().upper()
    if code not in LEAGUES:
        raise ValueError(f"Unsupported league: {code or 'empty'}")
    return code


def sport_for_league(value: Any) -> str:
    return str(LEAGUES[normalize_league_code(value)]["sport"])


def event_key(league: Any, external_event_id: Any) -> str:
    code = normalize_league_code(league)
    external = str(external_event_id or "").strip()
    if not external:
        raise ValueError("external_event_id is required")
    return f"{code.lower()}:{external}"


def league_catalog() -> list[dict[str, Any]]:
    return [deepcopy(LEAGUES[code]) for code in SUPPORTED_LEAGUES]


def sports_catalog() -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    for sport_code, item in SPORTS.items():
        leagues = [deepcopy(LEAGUES[code]) for code in item["leagues"]]
        result.append({**deepcopy(item), "status": "active" if any(code in ACTIVE_LEAGUES for code in item["leagues"]) else "foundation_ready", "league_items": leagues})
    return result


def market_catalog(*, sport: str | None = None, league: str | None = None) -> dict[str, Any]:
    if league:
        league_code = normalize_league_code(league)
        sport_code = sport_for_league(league_code)
    else:
        sport_code = str(sport or "").strip().lower()
        if sport_code not in SPORTS:
            raise ValueError(f"Unsupported sport: {sport_code or 'empty'}")
        league_code = None
    return {
        "schema_version": SCHEMA_VERSION,
        "sport": sport_code,
        "league": league_code,
        "items": deepcopy(MARKETS[sport_code]),
    }


def _team_payload(value: Any) -> dict[str, Any]:
    value = value if isinstance(value, dict) else {}
    return {
        "id": str(value.get("id")) if value.get("id") is not None else None,
        "name": value.get("name") or "",
        "abbr": value.get("abbr") or value.get("abbreviation") or "",
        "score": value.get("score"),
    }


def normalize_event(game: dict[str, Any], league: str, target_date: date | None = None) -> dict[str, Any]:
    code = normalize_league_code(league)
    external_id = game.get("external_event_id") or game.get("game_pk") or game.get("id")
    away = _team_payload(game.get("away"))
    home = _team_payload(game.get("home"))
    return {
        "event_key": event_key(code, external_id),
        "external_event_id": str(external_id),
        "sport": sport_for_league(code),
        "league": code,
        "starts_at": game.get("game_date") or game.get("starts_at"),
        "date_taiwan": game.get("date_taiwan") or (target_date.isoformat() if target_date else None),
        "time_taiwan": game.get("time_taiwan") or "",
        "status": game.get("status") or "unknown",
        "detailed_status": game.get("detailed_status") or "",
        "home": home,
        "away": away,
        "venue": game.get("venue") or "",
        "period": {
            "number": game.get("inning") or game.get("period") or game.get("quarter"),
            "state": game.get("inning_state") or game.get("period_state") or "",
        },
        "source": {
            "url": game.get("source_url") or game.get("official_schedule_url"),
            "adapter": LEAGUES[code].get("adapter"),
        },
        "raw_game_pk": game.get("game_pk"),
    }
