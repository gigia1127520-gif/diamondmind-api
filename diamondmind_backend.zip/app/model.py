from __future__ import annotations

import math
from typing import Any


def clamp(value: float, minimum: float, maximum: float) -> float:
    return max(minimum, min(maximum, value))


def pythagorean_win_pct(runs_scored: int | float | None, runs_allowed: int | float | None) -> float | None:
    """Baseball Pythagorean expectation using the commonly used 1.83 exponent."""

    if runs_scored is None or runs_allowed is None:
        return None
    if runs_scored < 0 or runs_allowed < 0 or runs_scored + runs_allowed == 0:
        return None
    exponent = 1.83
    scored_power = float(runs_scored) ** exponent
    allowed_power = float(runs_allowed) ** exponent
    return round(scored_power / (scored_power + allowed_power), 4)


def _number(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _recent_pct(team: dict[str, Any]) -> float | None:
    recent = team.get("last_ten") or {}
    wins = _number(recent.get("wins"))
    losses = _number(recent.get("losses"))
    if wins is None or losses is None or wins + losses == 0:
        return None
    return wins / (wins + losses)


def _starter_edge(away_pitcher: dict[str, Any] | None, home_pitcher: dict[str, Any] | None) -> float | None:
    away_era = _number((away_pitcher or {}).get("era"))
    home_era = _number((home_pitcher or {}).get("era"))
    if away_era is None or home_era is None:
        return None
    # Positive values favor the home starter. One ERA run is a meaningful but not decisive edge.
    return clamp((away_era - home_era) / 5.0, -0.35, 0.35)


def _factor(label: str, edge_for_pick: float | None, available: bool) -> dict[str, Any]:
    if not available or edge_for_pick is None:
        return {"label": label, "value": 50, "edge": None, "available": False}
    value = round(clamp(50 + edge_for_pick * 180, 18, 92))
    return {
        "label": label,
        "value": value,
        "edge": round(edge_for_pick * 100, 1),
        "available": True,
    }


def analyze_matchup(
    game: dict[str, Any],
    away_team: dict[str, Any],
    home_team: dict[str, Any],
    away_pitcher: dict[str, Any] | None = None,
    home_pitcher: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Transparent matchup model. Positive component edges favor the home team."""

    away_pyth = _number(away_team.get("pythagorean_pct"))
    home_pyth = _number(home_team.get("pythagorean_pct"))
    away_actual = _number(away_team.get("winning_pct"))
    home_actual = _number(home_team.get("winning_pct"))
    away_recent = _recent_pct(away_team)
    home_recent = _recent_pct(home_team)
    starter_edge = _starter_edge(away_pitcher, home_pitcher)

    pyth_edge = home_pyth - away_pyth if home_pyth is not None and away_pyth is not None else None
    actual_edge = home_actual - away_actual if home_actual is not None and away_actual is not None else None
    recent_edge = home_recent - away_recent if home_recent is not None and away_recent is not None else None

    components = [
        (pyth_edge, 0.45),
        (actual_edge, 0.25),
        (recent_edge, 0.17),
        (starter_edge, 0.13),
    ]
    available_weight = sum(weight for value, weight in components if value is not None)
    weighted_edge = sum((value or 0.0) * weight for value, weight in components)
    if available_weight:
        weighted_edge /= available_weight

    # A small home-field term is included, then confidence is pulled toward 50 when data is incomplete.
    raw_home_probability = 1.0 / (1.0 + math.exp(-(weighted_edge * 4.2 + 0.10)))
    data_quality = round(available_weight, 2)
    home_probability = 0.5 + (raw_home_probability - 0.5) * (0.62 + data_quality * 0.38)
    home_probability = clamp(home_probability, 0.21, 0.79)
    away_probability = 1.0 - home_probability

    pick_home = home_probability >= away_probability
    pick_team = game["home"] if pick_home else game["away"]
    opponent = game["away"] if pick_home else game["home"]
    probability = home_probability if pick_home else away_probability
    direction = 1.0 if pick_home else -1.0

    factors = [
        _factor("畢氏預期勝率", (pyth_edge or 0.0) * direction, pyth_edge is not None),
        _factor("實際戰績", (actual_edge or 0.0) * direction, actual_edge is not None),
        _factor("近十場狀態", (recent_edge or 0.0) * direction, recent_edge is not None),
        _factor("先發投手", (starter_edge or 0.0) * direction, starter_edge is not None),
    ]

    available_labels = [factor["label"] for factor in factors if factor["available"]]
    reason = "、".join(available_labels) if available_labels else "主客場基礎資料"
    return {
        "game_pk": game["game_pk"],
        "matchup": f'{game["away"]["abbr"]} @ {game["home"]["abbr"]}',
        "game_date": game["game_date"],
        "time_taiwan": game["time_taiwan"],
        "pick": {
            "team_id": pick_team["id"],
            "team_name": pick_team["name"],
            "abbr": pick_team["abbr"],
            "market": "moneyline",
            "label": f'{pick_team["abbr"]} 獨贏',
        },
        "opponent": {"team_id": opponent["id"], "team_name": opponent["name"], "abbr": opponent["abbr"]},
        "confidence": round(probability * 100, 1),
        "home_probability": round(home_probability * 100, 1),
        "away_probability": round(away_probability * 100, 1),
        "data_quality": data_quality,
        "factors": factors,
        "summary": f"模型依據{reason}比較後，較偏向 {pick_team['name']}。",
        "model_version": "dm-transparent-v1.0",
    }
