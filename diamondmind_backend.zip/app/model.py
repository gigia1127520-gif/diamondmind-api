from __future__ import annotations

import math
from typing import Any


def clamp(value: float, minimum: float, maximum: float) -> float:
    return max(minimum, min(maximum, value))


def pythagorean_win_pct(runs_scored: int | float | None, runs_allowed: int | float | None) -> float | None:
    """Baseball Pythagorean expectation using the commonly used 1.83 exponent."""

    if runs_scored is None or runs_allowed is None:
        return None
    if runs_scored < 0 or runs_allowed < 0 or runs_scored + runs_allowed == 0:
        return None
    exponent = 1.83
    scored_power = float(runs_scored) ** exponent
    allowed_power = float(runs_allowed) ** exponent
    return round(scored_power / (scored_power + allowed_power), 4)


def _number(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _recent_pct(team: dict[str, Any]) -> float | None:
    recent = team.get("last_ten") or {}
    wins = _number(recent.get("wins"))
    losses = _number(recent.get("losses"))
    if wins is None or losses is None or wins + losses == 0:
        return None
    return wins / (wins + losses)


def _starter_edge(away_pitcher: dict[str, Any] | None, home_pitcher: dict[str, Any] | None) -> float | None:
    away_era = _number((away_pitcher or {}).get("era"))
    home_era = _number((home_pitcher or {}).get("era"))
    if away_era is None or home_era is None:
        return None
    # Positive values favor the home starter. One ERA run is a meaningful but not decisive edge.
    return clamp((away_era - home_era) / 5.0, -0.35, 0.35)


def _factor(label: str, edge_for_pick: float | None, available: bool) -> dict[str, Any]:
    if not available or edge_for_pick is None:
        return {"label": label, "value": 50, "edge": None, "available": False}
    value = round(clamp(50 + edge_for_pick * 180, 18, 92))
    return {
        "label": label,
        "value": value,
        "edge": round(edge_for_pick * 100, 1),
        "available": True,
    }


def _team_run_rates(team: dict[str, Any]) -> tuple[float | None, float | None]:
    wins = _number(team.get("wins"))
    losses = _number(team.get("losses"))
    runs_scored = _number(team.get("runs_scored"))
    runs_allowed = _number(team.get("runs_allowed"))
    games = (wins or 0.0) + (losses or 0.0)
    if games <= 0:
        return None, None
    scored_per_game = runs_scored / games if runs_scored is not None else None
    allowed_per_game = runs_allowed / games if runs_allowed is not None else None
    return scored_per_game, allowed_per_game


def _project_runs(
    away_team: dict[str, Any],
    home_team: dict[str, Any],
    away_pitcher: dict[str, Any] | None,
    home_pitcher: dict[str, Any] | None,
    home_probability: float,
) -> dict[str, Any]:
    """Conservative run projection used by spreads and totals.

    This is intentionally transparent: season scoring/allowing rates establish
    the baseline, announced starters make a capped adjustment, and the final
    margin is gently aligned with the independent win-probability model.
    """

    league_runs = 4.35
    league_era = 4.25
    away_scored, away_allowed = _team_run_rates(away_team)
    home_scored, home_allowed = _team_run_rates(home_team)

    away_expected = ((away_scored or league_runs) + (home_allowed or league_runs)) / 2.0
    home_expected = ((home_scored or league_runs) + (away_allowed or league_runs)) / 2.0 + 0.10

    away_starter_era = _number((away_pitcher or {}).get("era"))
    home_starter_era = _number((home_pitcher or {}).get("era"))
    if away_starter_era is not None:
        home_expected += clamp((away_starter_era - league_era) * 0.22, -0.65, 0.65)
    if home_starter_era is not None:
        away_expected += clamp((home_starter_era - league_era) * 0.22, -0.65, 0.65)

    projected_total = clamp(away_expected + home_expected, 5.5, 13.5)
    rate_margin = home_expected - away_expected
    safe_probability = clamp(home_probability, 0.02, 0.98)
    probability_margin = math.log(safe_probability / (1.0 - safe_probability)) * 1.5
    projected_margin = clamp(rate_margin * 0.55 + probability_margin * 0.45, -4.0, 4.0)
    projected_home = (projected_total + projected_margin) / 2.0
    projected_away = projected_total - projected_home

    rate_inputs = sum(
        value is not None
        for value in (away_scored, away_allowed, home_scored, home_allowed)
    )
    starter_inputs = sum(value is not None for value in (away_starter_era, home_starter_era))
    quality = clamp(rate_inputs / 4.0 * 0.72 + starter_inputs / 2.0 * 0.28, 0.0, 1.0)
    return {
        "away_runs": round(projected_away, 2),
        "home_runs": round(projected_home, 2),
        "total_runs": round(projected_total, 2),
        "home_margin": round(projected_margin, 2),
        "quality": round(quality, 2),
        "inputs": {
            "away_runs_scored_per_game": round(away_scored, 2) if away_scored is not None else None,
            "away_runs_allowed_per_game": round(away_allowed, 2) if away_allowed is not None else None,
            "home_runs_scored_per_game": round(home_scored, 2) if home_scored is not None else None,
            "home_runs_allowed_per_game": round(home_allowed, 2) if home_allowed is not None else None,
            "away_starter_era": away_starter_era,
            "home_starter_era": home_starter_era,
        },
    }


def analyze_matchup(
    game: dict[str, Any],
    away_team: dict[str, Any],
    home_team: dict[str, Any],
    away_pitcher: dict[str, Any] | None = None,
    home_pitcher: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Transparent matchup model. Positive component edges favor the home team."""

    away_pyth = _number(away_team.get("pythagorean_pct"))
    home_pyth = _number(home_team.get("pythagorean_pct"))
    away_actual = _number(away_team.get("winning_pct"))
    home_actual = _number(home_team.get("winning_pct"))
    away_recent = _recent_pct(away_team)
    home_recent = _recent_pct(home_team)
    starter_edge = _starter_edge(away_pitcher, home_pitcher)

    pyth_edge = home_pyth - away_pyth if home_pyth is not None and away_pyth is not None else None
    actual_edge = home_actual - away_actual if home_actual is not None and away_actual is not None else None
    recent_edge = home_recent - away_recent if home_recent is not None and away_recent is not None else None

    components = [
        (pyth_edge, 0.45),
        (actual_edge, 0.25),
        (recent_edge, 0.17),
        (starter_edge, 0.13),
    ]
    available_weight = sum(weight for value, weight in components if value is not None)
    weighted_edge = sum((value or 0.0) * weight for value, weight in components)
    if available_weight:
        weighted_edge /= available_weight

    # A small home-field term is included, then confidence is pulled toward 50 when data is incomplete.
    raw_home_probability = 1.0 / (1.0 + math.exp(-(weighted_edge * 4.2 + 0.10)))
    data_quality = round(available_weight, 2)
    home_probability = 0.5 + (raw_home_probability - 0.5) * (0.62 + data_quality * 0.38)
    home_probability = clamp(home_probability, 0.21, 0.79)
    away_probability = 1.0 - home_probability

    pick_home = home_probability >= away_probability
    pick_team = game["home"] if pick_home else game["away"]
    opponent = game["away"] if pick_home else game["home"]
    probability = home_probability if pick_home else away_probability
    direction = 1.0 if pick_home else -1.0

    factors = [
        _factor("畢氏預期勝率", (pyth_edge or 0.0) * direction, pyth_edge is not None),
        _factor("實際戰績", (actual_edge or 0.0) * direction, actual_edge is not None),
        _factor("近十場狀態", (recent_edge or 0.0) * direction, recent_edge is not None),
        _factor("先發投手", (starter_edge or 0.0) * direction, starter_edge is not None),
    ]

    available_labels = [factor["label"] for factor in factors if factor["available"]]
    reason = "、".join(available_labels) if available_labels else "主客場基礎資料"
    projections = _project_runs(
        away_team,
        home_team,
        away_pitcher,
        home_pitcher,
        home_probability,
    )
    return {
        "game_pk": game["game_pk"],
        "matchup": f'{game["away"]["abbr"]} @ {game["home"]["abbr"]}',
        "game_date": game["game_date"],
        "time_taiwan": game["time_taiwan"],
        "pick": {
            "team_id": pick_team["id"],
            "team_name": pick_team["name"],
            "abbr": pick_team["abbr"],
            "market": "moneyline",
            "label": f'{pick_team["abbr"]} 獨贏',
        },
        "opponent": {"team_id": opponent["id"], "team_name": opponent["name"], "abbr": opponent["abbr"]},
        "confidence": round(probability * 100, 1),
        "home_probability": round(home_probability * 100, 1),
        "away_probability": round(away_probability * 100, 1),
        "data_quality": data_quality,
        "projections": projections,
        "factors": factors,
        "summary": f"模型依據{reason}比較後，較偏向 {pick_team['name']}。",
        "model_version": "dm-transparent-v1.0",
    }
