from __future__ import annotations

import math
from typing import Any, Iterable


def clamp(value: float, minimum: float, maximum: float) -> float:
    return max(minimum, min(maximum, value))


def pythagorean_win_pct(
    runs_scored: int | float | None,
    runs_allowed: int | float | None,
) -> float | None:
    """Baseball Pythagorean expectation using the commonly used 1.83 exponent."""

    if runs_scored is None or runs_allowed is None:
        return None
    if runs_scored < 0 or runs_allowed < 0 or runs_scored + runs_allowed == 0:
        return None
    exponent = 1.83
    scored_power = float(runs_scored) ** exponent
    allowed_power = float(runs_allowed) ** exponent
    return round(scored_power / (scored_power + allowed_power), 4)


def _number(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _nested(data: dict[str, Any] | None, *keys: str) -> Any:
    current: Any = data or {}
    for key in keys:
        if not isinstance(current, dict):
            return None
        current = current.get(key)
    return current


def _recent_pct(team: dict[str, Any]) -> float | None:
    recent = team.get("last_ten") or {}
    wins = _number(recent.get("wins"))
    losses = _number(recent.get("losses"))
    if wins is None or losses is None or wins + losses == 0:
        return None
    return wins / (wins + losses)


def _weighted(values: Iterable[tuple[float | None, float]]) -> tuple[float | None, float]:
    rows = [(value, weight) for value, weight in values if value is not None and weight > 0]
    if not rows:
        return None, 0.0
    total = sum(weight for _, weight in rows)
    return sum(float(value) * weight for value, weight in rows) / total, total


def _edge_higher(home: Any, away: Any, scale: float, cap: float = 0.55) -> float | None:
    home_number = _number(home)
    away_number = _number(away)
    if home_number is None or away_number is None or scale <= 0:
        return None
    return clamp((home_number - away_number) / scale, -cap, cap)


def _edge_lower(home: Any, away: Any, scale: float, cap: float = 0.55) -> float | None:
    home_number = _number(home)
    away_number = _number(away)
    if home_number is None or away_number is None or scale <= 0:
        return None
    return clamp((away_number - home_number) / scale, -cap, cap)


def _metric(label: str, away: Any, home: Any, *, favors: str, scale: float) -> dict[str, Any]:
    edge = _edge_higher(home, away, scale) if favors == "higher" else _edge_lower(home, away, scale)
    return {
        "label": label,
        "away": away,
        "home": home,
        "edge_home": round(edge, 4) if edge is not None else None,
        "available": edge is not None,
    }


def _group(
    label: str,
    metrics: list[tuple[dict[str, Any], float]],
    *,
    note: str = "",
) -> dict[str, Any]:
    edge, used_weight = _weighted(
        (metric.get("edge_home"), weight)
        for metric, weight in metrics
        if metric.get("available")
    )
    total_weight = sum(weight for _, weight in metrics)
    quality = used_weight / total_weight if total_weight else 0.0
    return {
        "label": label,
        "edge_home": round(edge, 4) if edge is not None else None,
        "quality": round(clamp(quality, 0.0, 1.0), 2),
        "available": edge is not None,
        "metrics": [metric for metric, _ in metrics],
        "note": note,
    }


def _team_strength_group(away_team: dict[str, Any], home_team: dict[str, Any]) -> dict[str, Any]:
    away_recent = _recent_pct(away_team)
    home_recent = _recent_pct(home_team)
    metrics = [
        (
            _metric(
                "畢氏預期勝率",
                away_team.get("pythagorean_pct"),
                home_team.get("pythagorean_pct"),
                favors="higher",
                scale=0.18,
            ),
            0.45,
        ),
        (
            _metric(
                "實際勝率",
                away_team.get("winning_pct"),
                home_team.get("winning_pct"),
                favors="higher",
                scale=0.18,
            ),
            0.30,
        ),
        (
            _metric(
                "近十場勝率",
                away_recent,
                home_recent,
                favors="higher",
                scale=0.35,
            ),
            0.25,
        ),
    ]
    return _group("球隊實力", metrics, note="球季得失分、實際戰績與近十場狀態")


def _starter_group(
    away_pitcher: dict[str, Any] | None,
    home_pitcher: dict[str, Any] | None,
) -> dict[str, Any]:
    away = away_pitcher or {}
    home = home_pitcher or {}
    away_season = away.get("season") or away
    home_season = home.get("season") or home
    away_recent = away.get("recent_3") or {}
    home_recent = home.get("recent_3") or {}
    away_split = (away.get("splits") or {}).get("away") or {}
    home_split = (home.get("splits") or {}).get("home") or {}
    metrics = [
        (_metric("ERA", away_season.get("era"), home_season.get("era"), favors="lower", scale=3.0), 0.22),
        (_metric("WHIP", away_season.get("whip"), home_season.get("whip"), favors="lower", scale=0.65), 0.16),
        (_metric("K/BB", away_season.get("k_bb"), home_season.get("k_bb"), favors="higher", scale=3.5), 0.13),
        (
            _metric(
                "被打擊率",
                away_season.get("avg_against"),
                home_season.get("avg_against"),
                favors="lower",
                scale=0.09,
            ),
            0.10,
        ),
        (_metric("近三場 ERA", away_recent.get("era"), home_recent.get("era"), favors="lower", scale=4.0), 0.16),
        (_metric("近三場 WHIP", away_recent.get("whip"), home_recent.get("whip"), favors="lower", scale=0.85), 0.10),
        (_metric("客主場 ERA", away_split.get("era"), home_split.get("era"), favors="lower", scale=3.5), 0.13),
    ]
    return _group("先發投手", metrics, note="ERA、WHIP、K/BB、被打擊率、近三場與主客場差異")


def _lineup_group(
    away_lineup: dict[str, Any] | None,
    home_lineup: dict[str, Any] | None,
) -> dict[str, Any]:
    away = away_lineup or {}
    home = home_lineup or {}
    away_season = away.get("season") or {}
    home_season = home.get("season") or {}
    away_recent = away.get("recent_7") or {}
    home_recent = home.get("recent_7") or {}
    away_platoon = away.get("platoon") or {}
    home_platoon = home.get("platoon") or {}
    away_official = away.get("official_lineup") or {}
    home_official = home.get("official_lineup") or {}
    metrics = [
        (_metric("球季 OPS", away_season.get("ops"), home_season.get("ops"), favors="higher", scale=0.18), 0.20),
        (_metric("球季 OBP", away_season.get("obp"), home_season.get("obp"), favors="higher", scale=0.07), 0.11),
        (_metric("球季 SLG", away_season.get("slg"), home_season.get("slg"), favors="higher", scale=0.16), 0.11),
        (_metric("近七日 OPS", away_recent.get("ops"), home_recent.get("ops"), favors="higher", scale=0.25), 0.18),
        (_metric("對左右投 OPS", away_platoon.get("ops"), home_platoon.get("ops"), favors="higher", scale=0.22), 0.15),
        (_metric("正式打線 OPS", away_official.get("ops"), home_official.get("ops"), favors="higher", scale=0.22), 0.16),
        (
            _metric(
                "主力缺席影響",
                away_official.get("missing_core_impact"),
                home_official.get("missing_core_impact"),
                favors="lower",
                scale=0.22,
            ),
            0.09,
        ),
    ]
    note = "球季、近七日、左右投對戰與正式／預計核心打線"
    if not away_official.get("confirmed") or not home_official.get("confirmed"):
        note += "；至少一隊正式打線尚未公布，目前使用預計核心打者並降低權重"
    group = _group("打線強度", metrics, note=note)
    if not away_official.get("confirmed") or not home_official.get("confirmed"):
        group["quality"] = round(group["quality"] * 0.82, 2)
    return group


def _bullpen_group(
    away_bullpen: dict[str, Any] | None,
    home_bullpen: dict[str, Any] | None,
) -> dict[str, Any]:
    away = away_bullpen or {}
    home = home_bullpen or {}
    away_season = away.get("season") or {}
    home_season = home.get("season") or {}
    away_recent = away.get("recent_3_days") or {}
    home_recent = home.get("recent_3_days") or {}
    away_availability = away.get("availability") or {}
    home_availability = home.get("availability") or {}
    metrics = [
        (_metric("牛棚 ERA", away_season.get("era"), home_season.get("era"), favors="lower", scale=3.0), 0.27),
        (_metric("牛棚 WHIP", away_season.get("whip"), home_season.get("whip"), favors="lower", scale=0.65), 0.18),
        (_metric("牛棚 K/BB", away_season.get("k_bb"), home_season.get("k_bb"), favors="higher", scale=3.0), 0.12),
        (_metric("近三日 ERA", away_recent.get("era"), home_recent.get("era"), favors="lower", scale=4.0), 0.16),
        (
            _metric(
                "近期負荷",
                away_availability.get("freshness_score"),
                home_availability.get("freshness_score"),
                favors="higher",
                scale=0.65,
            ),
            0.17,
        ),
        (
            _metric(
                "終結者可用性",
                away_availability.get("closer_score"),
                home_availability.get("closer_score"),
                favors="higher",
                scale=0.75,
            ),
            0.10,
        ),
    ]
    return _group("牛棚狀態", metrics, note="牛棚 ERA、WHIP、近三日用量、連續出賽與終結者可用性")


def _advanced_group(
    away_pitcher: dict[str, Any] | None,
    home_pitcher: dict[str, Any] | None,
    away_lineup: dict[str, Any] | None,
    home_lineup: dict[str, Any] | None,
) -> dict[str, Any]:
    away_pitch = (away_pitcher or {}).get("advanced") or {}
    home_pitch = (home_pitcher or {}).get("advanced") or {}
    away_bat = ((away_lineup or {}).get("official_lineup") or {}).get("advanced") or {}
    home_bat = ((home_lineup or {}).get("official_lineup") or {}).get("advanced") or {}
    metrics = [
        (_metric("先發 xERA", away_pitch.get("xera"), home_pitch.get("xera"), favors="lower", scale=3.0), 0.24),
        (_metric("先發 xwOBA", away_pitch.get("xwoba"), home_pitch.get("xwoba"), favors="lower", scale=0.08), 0.18),
        (
            _metric(
                "先發 Hard Hit%",
                away_pitch.get("hard_hit_pct"),
                home_pitch.get("hard_hit_pct"),
                favors="lower",
                scale=18.0,
            ),
            0.12,
        ),
        (
            _metric(
                "先發 Barrel%",
                away_pitch.get("barrel_pct"),
                home_pitch.get("barrel_pct"),
                favors="lower",
                scale=8.0,
            ),
            0.10,
        ),
        (_metric("打線 xwOBA", away_bat.get("xwoba"), home_bat.get("xwoba"), favors="higher", scale=0.08), 0.18),
        (
            _metric(
                "打線 Hard Hit%",
                away_bat.get("hard_hit_pct"),
                home_bat.get("hard_hit_pct"),
                favors="higher",
                scale=18.0,
            ),
            0.10,
        ),
        (
            _metric(
                "打線 Barrel%",
                away_bat.get("barrel_pct"),
                home_bat.get("barrel_pct"),
                favors="higher",
                scale=8.0,
            ),
            0.08,
        ),
    ]
    group = _group("進階數據", metrics, note="Statcast xERA、xwOBA、Hard Hit% 與 Barrel%")
    projected = any(
        (((lineup or {}).get("official_lineup") or {}).get("advanced") or {}).get("basis") == "projected_core"
        for lineup in (away_lineup, home_lineup)
    )
    if projected:
        group["note"] += "；正式打線未公布時以預計核心打者估算並降低解讀強度"
        group["quality"] = round(group["quality"] * 0.88, 2)
    return group


def _environment_group(
    environment: dict[str, Any] | None,
    away_lineup: dict[str, Any] | None,
    home_lineup: dict[str, Any] | None,
) -> dict[str, Any]:
    env = environment or {}
    side_edge = _number(env.get("side_edge"))
    metric = {
        "label": "天氣與球場適配",
        "away": (away_lineup or {}).get("power_index"),
        "home": (home_lineup or {}).get("power_index"),
        "edge_home": round(clamp(side_edge, -0.35, 0.35), 4) if side_edge is not None else None,
        "available": side_edge is not None,
    }
    note_parts = list(env.get("reasons") or [])
    weather = env.get("weather") or {}
    if weather.get("available"):
        temp_c = weather.get("temperature_c")
        temp_f = weather.get("temperature_f")
        temperature = (
            f"{temp_c}°C / {temp_f}°F" if temp_c is not None and temp_f is not None
            else f"{temp_c}°C" if temp_c is not None
            else f"{temp_f}°F" if temp_f is not None
            else "溫度—"
        )
        note_parts.append(
            f"{temperature}、{weather.get('wind_speed_mph', '—')} mph {weather.get('wind_direction_text') or ''}".strip()
        )
    return _group("環境條件", [(metric, 1.0)], note="；".join(note_parts) or "天氣、風向、溫度與球場因子")


def _factor(label: str, group: dict[str, Any], direction: float) -> dict[str, Any]:
    edge_home = _number(group.get("edge_home"))
    if edge_home is None:
        return {
            "label": label,
            "value": 50,
            "edge": None,
            "available": False,
            "quality": group.get("quality", 0),
            "note": group.get("note") or "資料不足",
        }
    edge_for_pick = edge_home * direction
    value = round(clamp(50 + edge_for_pick * 72, 18, 92))
    return {
        "label": label,
        "value": value,
        "edge": round(edge_for_pick * 100, 1),
        "available": True,
        "quality": group.get("quality", 0),
        "note": group.get("note") or "",
    }


def _team_run_rates(team: dict[str, Any]) -> tuple[float | None, float | None]:
    wins = _number(team.get("wins"))
    losses = _number(team.get("losses"))
    runs_scored = _number(team.get("runs_scored"))
    runs_allowed = _number(team.get("runs_allowed"))
    games = (wins or 0.0) + (losses or 0.0)
    if games <= 0:
        return None, None
    scored_per_game = runs_scored / games if runs_scored is not None else None
    allowed_per_game = runs_allowed / games if runs_allowed is not None else None
    return scored_per_game, allowed_per_game


def _project_runs(
    away_team: dict[str, Any],
    home_team: dict[str, Any],
    away_pitcher: dict[str, Any] | None,
    home_pitcher: dict[str, Any] | None,
    away_lineup: dict[str, Any] | None,
    home_lineup: dict[str, Any] | None,
    away_bullpen: dict[str, Any] | None,
    home_bullpen: dict[str, Any] | None,
    environment: dict[str, Any] | None,
    home_probability: float,
) -> dict[str, Any]:
    """Transparent expected-run model used only for spreads and totals.

    It does not generate or display simulated exact-score outcomes.
    """

    league_runs = 4.35
    league_era = 4.25
    league_ops = 0.720
    away_scored, away_allowed = _team_run_rates(away_team)
    home_scored, home_allowed = _team_run_rates(home_team)
    away_expected = ((away_scored or league_runs) + (home_allowed or league_runs)) / 2.0
    home_expected = ((home_scored or league_runs) + (away_allowed or league_runs)) / 2.0 + 0.10

    away_starter = away_pitcher or {}
    home_starter = home_pitcher or {}
    away_starter_era = _number(_nested(away_starter, "season", "era")) or _number(away_starter.get("era"))
    home_starter_era = _number(_nested(home_starter, "season", "era")) or _number(home_starter.get("era"))
    away_xera = _number(_nested(away_starter, "advanced", "xera"))
    home_xera = _number(_nested(home_starter, "advanced", "xera"))
    away_effective_era = _weighted(((away_starter_era, 0.65), (away_xera, 0.35)))[0]
    home_effective_era = _weighted(((home_starter_era, 0.65), (home_xera, 0.35)))[0]
    if away_effective_era is not None:
        home_expected += clamp((away_effective_era - league_era) * 0.22, -0.75, 0.75)
    if home_effective_era is not None:
        away_expected += clamp((home_effective_era - league_era) * 0.22, -0.75, 0.75)

    away_ops = _number(_nested(away_lineup or {}, "official_lineup", "ops")) or _number(
        _nested(away_lineup or {}, "season", "ops")
    )
    home_ops = _number(_nested(home_lineup or {}, "official_lineup", "ops")) or _number(
        _nested(home_lineup or {}, "season", "ops")
    )
    if away_ops is not None:
        away_expected += clamp((away_ops - league_ops) * 4.6, -0.65, 0.65)
    if home_ops is not None:
        home_expected += clamp((home_ops - league_ops) * 4.6, -0.65, 0.65)

    away_bp_era = _number(_nested(away_bullpen or {}, "season", "era"))
    home_bp_era = _number(_nested(home_bullpen or {}, "season", "era"))
    if away_bp_era is not None:
        home_expected += clamp((away_bp_era - league_era) * 0.10, -0.35, 0.35)
    if home_bp_era is not None:
        away_expected += clamp((home_bp_era - league_era) * 0.10, -0.35, 0.35)

    env_adjustment = _number((environment or {}).get("run_adjustment")) or 0.0
    away_expected += env_adjustment / 2.0
    home_expected += env_adjustment / 2.0

    projected_total = clamp(away_expected + home_expected, 5.0, 14.5)
    rate_margin = home_expected - away_expected
    safe_probability = clamp(home_probability, 0.02, 0.98)
    probability_margin = math.log(safe_probability / (1.0 - safe_probability)) * 1.45
    projected_margin = clamp(rate_margin * 0.60 + probability_margin * 0.40, -4.5, 4.5)
    projected_home = (projected_total + projected_margin) / 2.0
    projected_away = projected_total - projected_home

    inputs = [
        away_scored,
        away_allowed,
        home_scored,
        home_allowed,
        away_effective_era,
        home_effective_era,
        away_ops,
        home_ops,
        away_bp_era,
        home_bp_era,
    ]
    quality = sum(value is not None for value in inputs) / len(inputs)
    environment_quality = _number((environment or {}).get("quality"))
    if environment_quality is not None:
        quality = quality * 0.92 + environment_quality * 0.08
    return {
        "away_runs": round(projected_away, 2),
        "home_runs": round(projected_home, 2),
        "total_runs": round(projected_total, 2),
        "home_margin": round(projected_margin, 2),
        "quality": round(clamp(quality, 0.0, 1.0), 2),
        "method": "expected-runs-no-score-simulation",
        "inputs": {
            "away_runs_scored_per_game": round(away_scored, 2) if away_scored is not None else None,
            "away_runs_allowed_per_game": round(away_allowed, 2) if away_allowed is not None else None,
            "home_runs_scored_per_game": round(home_scored, 2) if home_scored is not None else None,
            "home_runs_allowed_per_game": round(home_allowed, 2) if home_allowed is not None else None,
            "away_starter_effective_era": round(away_effective_era, 2) if away_effective_era is not None else None,
            "home_starter_effective_era": round(home_effective_era, 2) if home_effective_era is not None else None,
            "away_lineup_ops": away_ops,
            "home_lineup_ops": home_ops,
            "away_bullpen_era": away_bp_era,
            "home_bullpen_era": home_bp_era,
            "environment_run_adjustment": round(env_adjustment, 2),
        },
    }


def analyze_matchup(
    game: dict[str, Any],
    away_team: dict[str, Any],
    home_team: dict[str, Any],
    away_pitcher: dict[str, Any] | None = None,
    home_pitcher: dict[str, Any] | None = None,
    away_lineup: dict[str, Any] | None = None,
    home_lineup: dict[str, Any] | None = None,
    away_bullpen: dict[str, Any] | None = None,
    home_bullpen: dict[str, Any] | None = None,
    environment: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """DiamondMind explainable MLB matchup model.

    Positive component edges favor the home team. Missing groups are omitted
    and their weights are automatically redistributed rather than replaced by
    invented values.
    """

    groups = {
        "team_strength": _team_strength_group(away_team, home_team),
        "starter": _starter_group(away_pitcher, home_pitcher),
        "lineup": _lineup_group(away_lineup, home_lineup),
        "bullpen": _bullpen_group(away_bullpen, home_bullpen),
        "advanced": _advanced_group(away_pitcher, home_pitcher, away_lineup, home_lineup),
        "environment": _environment_group(environment, away_lineup, home_lineup),
    }
    weights = {
        "team_strength": 0.18,
        "starter": 0.26,
        "lineup": 0.23,
        "bullpen": 0.17,
        "advanced": 0.12,
        "environment": 0.04,
    }
    available = [
        (groups[key].get("edge_home"), weight * float(groups[key].get("quality") or 0.0))
        for key, weight in weights.items()
        if groups[key].get("available")
    ]
    weighted_edge, available_weight = _weighted(available)
    if weighted_edge is None:
        weighted_edge = 0.0

    # A modest, explicit home-field term remains after the data-driven groups.
    raw_home_probability = 1.0 / (1.0 + math.exp(-(weighted_edge * 3.15 + 0.085)))
    data_quality = clamp(available_weight / sum(weights.values()), 0.0, 1.0)
    home_probability = 0.5 + (raw_home_probability - 0.5) * (0.55 + data_quality * 0.45)
    home_probability = clamp(home_probability, 0.18, 0.82)
    away_probability = 1.0 - home_probability

    pick_home = home_probability >= away_probability
    pick_team = game["home"] if pick_home else game["away"]
    opponent = game["away"] if pick_home else game["home"]
    probability = home_probability if pick_home else away_probability
    direction = 1.0 if pick_home else -1.0

    factors = [
        _factor("先發投手", groups["starter"], direction),
        _factor("打線強度", groups["lineup"], direction),
        _factor("牛棚狀態", groups["bullpen"], direction),
        _factor("球隊實力", groups["team_strength"], direction),
        _factor("進階數據", groups["advanced"], direction),
        _factor("環境條件", groups["environment"], direction),
    ]
    available_labels = [factor["label"] for factor in factors if factor["available"]]
    reason = "、".join(available_labels) if available_labels else "主客場基礎資料"
    projections = _project_runs(
        away_team,
        home_team,
        away_pitcher,
        home_pitcher,
        away_lineup,
        home_lineup,
        away_bullpen,
        home_bullpen,
        environment,
        home_probability,
    )
    return {
        "game_pk": game["game_pk"],
        "matchup": f'{game["away"]["abbr"]} @ {game["home"]["abbr"]}',
        "game_date": game["game_date"],
        "time_taiwan": game["time_taiwan"],
        "pick": {
            "team_id": pick_team["id"],
            "team_name": pick_team["name"],
            "abbr": pick_team["abbr"],
            "market": "moneyline",
            "label": f'{pick_team["abbr"]} 獨贏',
        },
        "opponent": {
            "team_id": opponent["id"],
            "team_name": opponent["name"],
            "abbr": opponent["abbr"],
        },
        "confidence": round(probability * 100, 1),
        "home_probability": round(home_probability * 100, 1),
        "away_probability": round(away_probability * 100, 1),
        "data_quality": round(data_quality, 2),
        "projections": projections,
        "factors": factors,
        "analysis_groups": groups,
        "engine": {
            "weights": weights,
            "available_weight": round(available_weight, 3),
            "score_simulation": False,
            "five_engine_modules": [
                "starting_pitcher",
                "lineup",
                "bullpen",
                "environment",
                "statcast_advanced",
            ],
        },
        "summary": f"完整模型依據{reason}比較後，較偏向 {pick_team['name']}。",
        "model_version": "dm-complete-engine-v2.1",
    }
