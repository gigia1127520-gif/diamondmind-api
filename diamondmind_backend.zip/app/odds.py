from __future__ import annotations

import json
from datetime import date, datetime, timezone
from typing import Any
from urllib.parse import urlencode
from zoneinfo import ZoneInfo

import httpx

from .cache import AsyncTTLCache
from .config import Settings


TAIPEI = ZoneInfo("Asia/Taipei")


class OddsUpstreamError(RuntimeError):
    """Raised when the configured odds provider cannot return usable data."""


def _iso_utc(timestamp: float | None = None) -> str:
    dt = datetime.fromtimestamp(timestamp, tz=timezone.utc) if timestamp else datetime.now(timezone.utc)
    return dt.isoformat().replace("+00:00", "Z")


def _number(value: Any) -> float | int | None:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return int(number) if number.is_integer() else number


def _header_int(headers: httpx.Headers, name: str) -> int | None:
    try:
        value = headers.get(name)
        return int(value) if value is not None else None
    except (TypeError, ValueError):
        return None


def _parse_datetime(value: Any) -> datetime | None:
    if not isinstance(value, str) or not value:
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None


class OddsService:
    """Server-only adapter for real MLB and NPB sportsbook lines.

    The browser never receives the provider API key. Upstream responses are
    normalized to the three DiamondMind markets and cached per sport so
    repeated job calls do not unnecessarily consume the monthly quota.
    """

    def __init__(
        self,
        settings: Settings,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self.settings = settings
        self.enabled = settings.odds_enabled
        self.cache = AsyncTTLCache()
        self.client = httpx.AsyncClient(
            timeout=settings.request_timeout_seconds,
            follow_redirects=True,
            trust_env=False,
            transport=transport,
            headers={
                "Accept": "application/json",
                "User-Agent": "DiamondMind-Odds/1.0",
            },
        )

    async def aclose(self) -> None:
        await self.client.aclose()

    def status(self) -> dict[str, Any]:
        return {
            "configured": self.enabled,
            "provider": "The Odds API",
            "sport": self.settings.odds_sport_key,
            "sports": {"MLB": self.settings.odds_sport_key, "NPB": self.settings.npb_odds_sport_key},
            "markets": self.settings.odds_markets,
            "bookmakers": self.settings.odds_bookmakers,
            "bookmakers_by_league": {
                "MLB": self.settings.odds_bookmakers,
                "NPB": self.settings.npb_odds_bookmakers,
            },
            "cache_ttl_seconds": self.settings.odds_cache_ttl_seconds,
            "message": (
                "真實 MLB／NPB 盤口來源已設定。"
                if self.enabled
                else "尚未設定 ODDS_API_KEY；不會產生讓分或大小分推薦。"
            ),
        }

    async def _fetch_upcoming(
        self,
        sport_key: str | None = None,
    ) -> tuple[list[dict[str, Any]], dict[str, Any]]:
        if not self.enabled:
            raise OddsUpstreamError("Odds data source is not configured")

        active_sport_key = (sport_key or self.settings.odds_sport_key).strip()
        active_bookmakers = (
            self.settings.npb_odds_bookmakers
            if active_sport_key == self.settings.npb_odds_sport_key
            else self.settings.odds_bookmakers
        )
        params = {
            "apiKey": self.settings.odds_api_key,
            "bookmakers": ",".join(active_bookmakers),
            "markets": ",".join(self.settings.odds_markets),
            "oddsFormat": "american",
            "dateFormat": "iso",
        }
        # Exclude the API key from the cache identifier so secrets never appear
        # in cache inspection, diagnostics or exception messages.
        public_params = {key: value for key, value in params.items() if key != "apiKey"}
        cache_key = (
            f"odds:{active_sport_key}:"
            f"{urlencode(sorted((str(key), str(value)) for key, value in public_params.items()))}"
        )
        cached = self.cache.get(cache_key)
        if cached and cached.is_fresh:
            value = cached.value
            return value["items"], {
                **value["meta"],
                "cache": "hit",
                "updated_at": _iso_utc(cached.stored_at),
            }

        async with self.cache.lock(cache_key):
            cached = self.cache.get(cache_key)
            if cached and cached.is_fresh:
                value = cached.value
                return value["items"], {
                    **value["meta"],
                    "cache": "hit",
                    "updated_at": _iso_utc(cached.stored_at),
                }

            url = (
                f"{self.settings.odds_api_base}/sports/"
                f"{active_sport_key}/odds/"
            )
            try:
                response = await self.client.get(url, params=params)
                response.raise_for_status()
                data = response.json()
                if not isinstance(data, list):
                    raise ValueError("Unexpected odds response")
                items = [item for item in data if isinstance(item, dict)]
                meta = {
                    "provider": "The Odds API",
                    "sport_key": active_sport_key,
                    "quota": {
                        "remaining": _header_int(response.headers, "x-requests-remaining"),
                        "used": _header_int(response.headers, "x-requests-used"),
                        "last_cost": _header_int(response.headers, "x-requests-last"),
                    },
                }
                entry = self.cache.set(
                    cache_key,
                    {"items": items, "meta": meta},
                    self.settings.odds_cache_ttl_seconds,
                    self.settings.odds_stale_ttl_seconds,
                )
                return items, {
                    **meta,
                    "cache": "miss",
                    "updated_at": _iso_utc(entry.stored_at),
                }
            except (httpx.HTTPError, ValueError, json.JSONDecodeError) as exc:
                if cached and cached.can_serve_stale:
                    value = cached.value
                    return value["items"], {
                        **value["meta"],
                        "cache": "stale",
                        "updated_at": _iso_utc(cached.stored_at),
                    }
                raise OddsUpstreamError("Odds data source is temporarily unavailable") from exc

    def _ranked_bookmakers(self, event: dict[str, Any]) -> list[dict[str, Any]]:
        bookmakers = [item for item in event.get("bookmakers", []) if isinstance(item, dict)]
        rank = {key: index for index, key in enumerate(self.settings.odds_bookmakers)}
        return sorted(
            bookmakers,
            key=lambda item: rank.get(str(item.get("key") or ""), len(rank)),
        )

    def _first_market(
        self,
        event: dict[str, Any],
        market_key: str,
    ) -> tuple[dict[str, Any], dict[str, Any]] | None:
        for bookmaker in self._ranked_bookmakers(event):
            for market in bookmaker.get("markets", []):
                if isinstance(market, dict) and market.get("key") == market_key:
                    return bookmaker, market
        return None

    @staticmethod
    def _team_outcome(market: dict[str, Any], team_name: str) -> dict[str, Any] | None:
        for outcome in market.get("outcomes", []):
            if isinstance(outcome, dict) and outcome.get("name") == team_name:
                return outcome
        return None

    @staticmethod
    def _named_outcome(market: dict[str, Any], name: str) -> dict[str, Any] | None:
        wanted = name.lower()
        for outcome in market.get("outcomes", []):
            if isinstance(outcome, dict) and str(outcome.get("name") or "").lower() == wanted:
                return outcome
        return None

    @staticmethod
    def _market_source(bookmaker: dict[str, Any], market: dict[str, Any]) -> dict[str, Any]:
        return {
            "bookmaker_key": bookmaker.get("key"),
            "bookmaker": bookmaker.get("title"),
            "last_update": market.get("last_update") or bookmaker.get("last_update"),
        }

    def _normalize_event(self, event: dict[str, Any]) -> dict[str, Any] | None:
        commence = _parse_datetime(event.get("commence_time"))
        away_name = event.get("away_team")
        home_name = event.get("home_team")
        if commence is None or not away_name or not home_name:
            return None

        taipei_dt = commence.astimezone(TAIPEI)
        markets: dict[str, Any] = {}

        h2h = self._first_market(event, "h2h")
        if h2h:
            bookmaker, market = h2h
            away = self._team_outcome(market, str(away_name))
            home = self._team_outcome(market, str(home_name))
            if away and home:
                markets["moneyline"] = {
                    **self._market_source(bookmaker, market),
                    "away_price": _number(away.get("price")),
                    "home_price": _number(home.get("price")),
                }

        spreads = self._first_market(event, "spreads")
        if spreads:
            bookmaker, market = spreads
            away = self._team_outcome(market, str(away_name))
            home = self._team_outcome(market, str(home_name))
            if away and home:
                markets["run_line"] = {
                    **self._market_source(bookmaker, market),
                    "away": {
                        "point": _number(away.get("point")),
                        "price": _number(away.get("price")),
                    },
                    "home": {
                        "point": _number(home.get("point")),
                        "price": _number(home.get("price")),
                    },
                }

        totals = self._first_market(event, "totals")
        if totals:
            bookmaker, market = totals
            over = self._named_outcome(market, "over")
            under = self._named_outcome(market, "under")
            if over and under:
                total = _number(over.get("point"))
                if total is None:
                    total = _number(under.get("point"))
                markets["totals"] = {
                    **self._market_source(bookmaker, market),
                    "total": total,
                    "over_price": _number(over.get("price")),
                    "under_price": _number(under.get("price")),
                }

        return {
            "event_id": event.get("id"),
            "sport_key": event.get("sport_key"),
            "commence_time": event.get("commence_time"),
            "date_taiwan": taipei_dt.date().isoformat(),
            "time_taiwan": taipei_dt.strftime("%H:%M"),
            "away_team": away_name,
            "home_team": home_name,
            "markets": markets,
        }

    async def odds_for_date(
        self,
        taiwan_date: date,
        *,
        sport_key: str | None = None,
    ) -> dict[str, Any]:
        active_sport_key = (sport_key or self.settings.odds_sport_key).strip()
        raw_items, meta = await self._fetch_upcoming(active_sport_key)
        normalized = [self._normalize_event(item) for item in raw_items]
        items = [
            item
            for item in normalized
            if item is not None and item["date_taiwan"] == taiwan_date.isoformat()
        ]
        items.sort(key=lambda item: item["commence_time"])
        return {
            "date": taiwan_date.isoformat(),
            "timezone": "Asia/Taipei",
            "configured": True,
            "count": len(items),
            "items": items,
            "meta": {
                **meta,
                "fresh_for_model": meta.get("cache") != "stale",
                "markets": self.settings.odds_markets,
                "bookmakers": (
                    self.settings.npb_odds_bookmakers
                    if active_sport_key == self.settings.npb_odds_sport_key
                    else self.settings.odds_bookmakers
                ),
                "sport_key": active_sport_key,
            },
        }
