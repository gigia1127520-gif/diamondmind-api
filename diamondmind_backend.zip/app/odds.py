from __future__ import annotations

import json
import re
from datetime import date, datetime, timezone
from typing import Any
from urllib.parse import urlencode
from zoneinfo import ZoneInfo

import httpx

from .cache import AsyncTTLCache
from .config import Settings


TAIPEI = ZoneInfo("Asia/Taipei")


class OddsUpstreamError(RuntimeError):
    """Raised when the configured odds provider cannot return usable data."""

    def __init__(
        self,
        message: str,
        *,
        status_code: int | None = None,
        error_code: str | None = None,
        provider_detail: str | None = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.error_code = error_code
        self.provider_detail = provider_detail

    def diagnostic(self) -> dict[str, Any]:
        return {
            "message": str(self),
            "status_code": self.status_code,
            "error_code": self.error_code,
            "provider_detail": self.provider_detail,
        }


def _iso_utc(timestamp: float | None = None) -> str:
    dt = datetime.fromtimestamp(timestamp, tz=timezone.utc) if timestamp else datetime.now(timezone.utc)
    return dt.isoformat().replace("+00:00", "Z")


def _number(value: Any) -> float | int | None:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    return int(number) if number.is_integer() else number


def _header_int(headers: httpx.Headers, name: str) -> int | None:
    try:
        value = headers.get(name)
        return int(value) if value is not None else None
    except (TypeError, ValueError):
        return None


def _provider_error(response: httpx.Response) -> tuple[str | None, str | None]:
    """Return safe The Odds API error code/detail without exposing credentials."""

    try:
        payload = response.json()
    except (ValueError, json.JSONDecodeError):
        payload = {}
    error_code = None
    detail: Any = None
    if isinstance(payload, dict):
        error_code = payload.get("error_code") or payload.get("code")
        detail = payload.get("message") or payload.get("error") or payload.get("detail")
    if detail in (None, ""):
        detail = response.text.strip()
    text = str(detail or "").strip() or None
    if text:
        text = re.sub(r"apiKey=[^&\s]+", "apiKey=***", text, flags=re.I)[:600]
    return (
        str(error_code).strip()[:100] if error_code not in (None, "") else None,
        text,
    )


def _parse_datetime(value: Any) -> datetime | None:
    if not isinstance(value, str) or not value:
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None


class OddsService:
    """Server-only adapter for real MLB/NPB/KBO/CPBL sportsbook lines.

    The browser never receives the provider API key. Upstream responses are
    normalized to the three DiamondMind markets and cached per sport so
    repeated job calls do not unnecessarily consume the monthly quota.
    """

    def __init__(
        self,
        settings: Settings,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self.settings = settings
        self.enabled = settings.odds_enabled
        self.cache = AsyncTTLCache()
        self.last_checks: dict[str, dict[str, Any]] = {}
        self.client = httpx.AsyncClient(
            timeout=settings.request_timeout_seconds,
            follow_redirects=True,
            trust_env=False,
            transport=transport,
            headers={
                "Accept": "application/json",
                "User-Agent": "DiamondMind-Odds/1.0",
            },
        )

    async def aclose(self) -> None:
        await self.client.aclose()

    def _league_for_sport_key(self, sport_key: str) -> str:
        mapping = {
            self.settings.odds_sport_key: "MLB",
            self.settings.npb_odds_sport_key: "NPB",
            self.settings.kbo_odds_sport_key: "KBO",
            self.settings.cpbl_odds_sport_key: "CPBL",
        }
        return mapping.get(str(sport_key or "").strip(), "MLB")

    def _bookmakers_for_sport_key(self, sport_key: str) -> list[str]:
        league = self._league_for_sport_key(sport_key)
        return {
            "MLB": self.settings.odds_bookmakers,
            "NPB": self.settings.npb_odds_bookmakers,
            "KBO": self.settings.kbo_odds_bookmakers,
            "CPBL": self.settings.cpbl_odds_bookmakers,
        }.get(league, self.settings.odds_bookmakers)

    def status(self) -> dict[str, Any]:
        sports = {
            "MLB": self.settings.odds_sport_key,
            "NPB": self.settings.npb_odds_sport_key,
            "KBO": self.settings.kbo_odds_sport_key,
            "CPBL": self.settings.cpbl_odds_sport_key,
        }
        return {
            "configured": self.enabled,
            "provider": "The Odds API",
            "sport": self.settings.odds_sport_key,
            "sports": sports,
            "markets": self.settings.odds_markets,
            "bookmakers": self.settings.odds_bookmakers,
            "bookmakers_by_league": {code: self._bookmakers_for_sport_key(key) for code, key in sports.items()},
            "cache_ttl_seconds": self.settings.odds_cache_ttl_seconds,
            "last_checks": {key: dict(value) for key, value in self.last_checks.items()},
            "message": (
                "真實 MLB／NPB／KBO／CPBL 盤口接頭已設定；實際發布仍要求供應商當日有盤。"
                if self.enabled
                else "尚未設定 ODDS_API_KEY；不會產生讓分或大小分推薦。"
            ),
        }

    async def _fetch_upcoming(
        self,
        sport_key: str | None = None,
    ) -> tuple[list[dict[str, Any]], dict[str, Any]]:
        if not self.enabled:
            raise OddsUpstreamError("Odds data source is not configured")

        active_sport_key = (sport_key or self.settings.odds_sport_key).strip()
        active_bookmakers = self._bookmakers_for_sport_key(active_sport_key)
        params = {
            "apiKey": self.settings.odds_api_key,
            "bookmakers": ",".join(active_bookmakers),
            "markets": ",".join(self.settings.odds_markets),
            "oddsFormat": "american",
            "dateFormat": "iso",
        }
        # Exclude the API key from the cache identifier so secrets never appear
        # in cache inspection, diagnostics or exception messages.
        public_params = {key: value for key, value in params.items() if key != "apiKey"}
        cache_key = (
            f"odds:{active_sport_key}:"
            f"{urlencode(sorted((str(key), str(value)) for key, value in public_params.items()))}"
        )
        cached = self.cache.get(cache_key)
        if cached and cached.is_fresh:
            value = cached.value
            return value["items"], {
                **value["meta"],
                "cache": "hit",
                "updated_at": _iso_utc(cached.stored_at),
            }

        async with self.cache.lock(cache_key):
            cached = self.cache.get(cache_key)
            if cached and cached.is_fresh:
                value = cached.value
                return value["items"], {
                    **value["meta"],
                    "cache": "hit",
                    "updated_at": _iso_utc(cached.stored_at),
                }

            url = (
                f"{self.settings.odds_api_base}/sports/"
                f"{active_sport_key}/odds/"
            )
            try:
                response = await self.client.get(url, params=params)
                # Some plans/accounts reject a bookmaker-restricted request or
                # return no events even though regional MLB odds are available.
                # Retry once without the bookmaker filter before declaring the
                # feed unavailable. The retry is cached under the same key and
                # therefore does not repeat on every founder refresh.
                if response.status_code in {400, 404, 422}:
                    fallback_params = {
                        key: value for key, value in params.items() if key != "bookmakers"
                    }
                    fallback_params["regions"] = (
                        "us"
                        if self._league_for_sport_key(active_sport_key) == "MLB"
                        else "us,uk,eu,au"
                    )
                    response = await self.client.get(url, params=fallback_params)
                response.raise_for_status()
                data = response.json()
                if isinstance(data, list) and not data and active_bookmakers:
                    fallback_params = {
                        key: value for key, value in params.items() if key != "bookmakers"
                    }
                    fallback_params["regions"] = (
                        "us"
                        if self._league_for_sport_key(active_sport_key) == "MLB"
                        else "us,uk,eu,au"
                    )
                    fallback_response = await self.client.get(url, params=fallback_params)
                    fallback_response.raise_for_status()
                    fallback_data = fallback_response.json()
                    if isinstance(fallback_data, list) and fallback_data:
                        response = fallback_response
                        data = fallback_data
                if not isinstance(data, list):
                    raise ValueError("Unexpected odds response")
                items = [item for item in data if isinstance(item, dict)]
                meta = {
                    "provider": "The Odds API",
                    "sport_key": active_sport_key,
                    "request_mode": "bookmakers" if "bookmakers" in response.request.url.params else "regions_fallback",
                    "quota": {
                        "remaining": _header_int(response.headers, "x-requests-remaining"),
                        "used": _header_int(response.headers, "x-requests-used"),
                        "last_cost": _header_int(response.headers, "x-requests-last"),
                    },
                }
                entry = self.cache.set(
                    cache_key,
                    {"items": items, "meta": meta},
                    self.settings.odds_cache_ttl_seconds,
                    self.settings.odds_stale_ttl_seconds,
                )
                return items, {
                    **meta,
                    "cache": "miss",
                    "updated_at": _iso_utc(entry.stored_at),
                }
            except httpx.HTTPStatusError as exc:
                if cached and cached.can_serve_stale:
                    value = cached.value
                    return value["items"], {
                        **value["meta"],
                        "cache": "stale",
                        "updated_at": _iso_utc(cached.stored_at),
                    }
                error_code, provider_detail = _provider_error(exc.response)
                raise OddsUpstreamError(
                    "Odds data source is temporarily unavailable",
                    status_code=exc.response.status_code,
                    error_code=error_code,
                    provider_detail=provider_detail,
                ) from exc
            except (httpx.RequestError, ValueError, json.JSONDecodeError) as exc:
                if cached and cached.can_serve_stale:
                    value = cached.value
                    return value["items"], {
                        **value["meta"],
                        "cache": "stale",
                        "updated_at": _iso_utc(cached.stored_at),
                }
                raise OddsUpstreamError("Odds data source is temporarily unavailable") from exc

    def _ranked_bookmakers(self, event: dict[str, Any]) -> list[dict[str, Any]]:
        bookmakers = [item for item in event.get("bookmakers", []) if isinstance(item, dict)]
        sport_key = str(event.get("sport_key") or "").strip()
        preferred = self._bookmakers_for_sport_key(sport_key)
        rank = {key: index for index, key in enumerate(preferred)}
        return sorted(
            bookmakers,
            key=lambda item: rank.get(str(item.get("key") or ""), len(rank)),
        )

    def _market_options(
        self,
        event: dict[str, Any],
        market_key: str,
    ) -> list[tuple[dict[str, Any], dict[str, Any]]]:
        options: list[tuple[dict[str, Any], dict[str, Any]]] = []
        for bookmaker in self._ranked_bookmakers(event):
            for market in bookmaker.get("markets", []):
                if isinstance(market, dict) and market.get("key") == market_key:
                    options.append((bookmaker, market))
        return options

    @staticmethod
    def _team_outcome(market: dict[str, Any], team_name: str) -> dict[str, Any] | None:
        for outcome in market.get("outcomes", []):
            if isinstance(outcome, dict) and outcome.get("name") == team_name:
                return outcome
        return None

    @staticmethod
    def _named_outcome(market: dict[str, Any], name: str) -> dict[str, Any] | None:
        wanted = name.lower()
        for outcome in market.get("outcomes", []):
            if isinstance(outcome, dict) and str(outcome.get("name") or "").lower() == wanted:
                return outcome
        return None

    @staticmethod
    def _market_source(bookmaker: dict[str, Any], market: dict[str, Any]) -> dict[str, Any]:
        return {
            "type": "real_bookmaker",
            "provider": "The Odds API",
            "bookmaker_key": bookmaker.get("key"),
            "bookmaker": bookmaker.get("title"),
            "last_update": market.get("last_update") or bookmaker.get("last_update"),
        }

    def _normalize_event(self, event: dict[str, Any]) -> dict[str, Any] | None:
        commence = _parse_datetime(event.get("commence_time"))
        away_name = event.get("away_team")
        home_name = event.get("home_team")
        if commence is None or not away_name or not home_name:
            return None

        taipei_dt = commence.astimezone(TAIPEI)
        markets: dict[str, Any] = {}

        for bookmaker, market in self._market_options(event, "h2h"):
            away = self._team_outcome(market, str(away_name))
            home = self._team_outcome(market, str(home_name))
            away_price = _number(away.get("price")) if away else None
            home_price = _number(home.get("price")) if home else None
            if away_price not in {None, 0} and home_price not in {None, 0}:
                markets["moneyline"] = {
                    **self._market_source(bookmaker, market),
                    "away_price": away_price,
                    "home_price": home_price,
                }
                break

        for bookmaker, market in self._market_options(event, "spreads"):
            away = self._team_outcome(market, str(away_name))
            home = self._team_outcome(market, str(home_name))
            away_point = _number(away.get("point")) if away else None
            home_point = _number(home.get("point")) if home else None
            away_price = _number(away.get("price")) if away else None
            home_price = _number(home.get("price")) if home else None
            if (
                away_point is not None
                and home_point is not None
                and abs(float(away_point) + float(home_point)) <= 0.01
                and away_price not in {None, 0}
                and home_price not in {None, 0}
            ):
                markets["run_line"] = {
                    **self._market_source(bookmaker, market),
                    "away": {
                        "point": away_point,
                        "price": away_price,
                    },
                    "home": {
                        "point": home_point,
                        "price": home_price,
                    },
                }
                break

        for bookmaker, market in self._market_options(event, "totals"):
            over = self._named_outcome(market, "over")
            under = self._named_outcome(market, "under")
            if over and under:
                over_total = _number(over.get("point"))
                under_total = _number(under.get("point"))
                total = over_total if over_total is not None else under_total
                over_price = _number(over.get("price"))
                under_price = _number(under.get("price"))
                matching_total = (
                    over_total is None
                    or under_total is None
                    or abs(float(over_total) - float(under_total)) <= 0.01
                )
                if total is not None and matching_total and over_price not in {None, 0} and under_price not in {None, 0}:
                    markets["totals"] = {
                        **self._market_source(bookmaker, market),
                        "total": total,
                        "over_price": over_price,
                        "under_price": under_price,
                    }
                    break

        return {
            "event_id": event.get("id"),
            "sport_key": event.get("sport_key"),
            "commence_time": event.get("commence_time"),
            "date_taiwan": taipei_dt.date().isoformat(),
            "time_taiwan": taipei_dt.strftime("%H:%M"),
            "away_team": away_name,
            "home_team": home_name,
            "markets": markets,
        }

    async def odds_for_date(
        self,
        taiwan_date: date,
        *,
        sport_key: str | None = None,
    ) -> dict[str, Any]:
        active_sport_key = (sport_key or self.settings.odds_sport_key).strip()
        league = self._league_for_sport_key(active_sport_key)
        checked_at = _iso_utc()
        previous = self.last_checks.get(league) or {}
        try:
            raw_items, meta = await self._fetch_upcoming(active_sport_key)
        except OddsUpstreamError as exc:
            diagnostic = exc.diagnostic()
            self.last_checks[league] = {
                **previous,
                "league": league,
                "sport_key": active_sport_key,
                "date": taiwan_date.isoformat(),
                "checked_at": checked_at,
                "last_error": type(exc).__name__,
                "status_code": diagnostic.get("status_code"),
                "error_code": diagnostic.get("error_code"),
                "provider_detail": diagnostic.get("provider_detail"),
                "consecutive_failures": int(previous.get("consecutive_failures", 0) or 0) + 1,
            }
            raise

        normalized = [self._normalize_event(item) for item in raw_items]
        items = [
            item
            for item in normalized
            if item is not None and item["date_taiwan"] == taiwan_date.isoformat()
        ]
        items.sort(key=lambda item: item["commence_time"])
        fresh_for_model = meta.get("cache") != "stale"
        coverage = {
            "moneyline": sum(1 for item in items if "moneyline" in (item.get("markets") or {})),
            "run_line": sum(1 for item in items if "run_line" in (item.get("markets") or {})),
            "totals": sum(1 for item in items if "totals" in (item.get("markets") or {})),
        }
        self.last_checks[league] = {
            "league": league,
            "sport_key": active_sport_key,
            "date": taiwan_date.isoformat(),
            "checked_at": checked_at,
            "updated_at": meta.get("updated_at"),
            "cache": meta.get("cache"),
            "fresh_for_model": fresh_for_model,
            "count": len(items),
            "coverage": coverage,
            "quota": dict(meta.get("quota") or {}),
            "last_error": None,
            "consecutive_failures": 0,
        }
        return {
            "date": taiwan_date.isoformat(),
            "timezone": "Asia/Taipei",
            "configured": True,
            "count": len(items),
            "items": items,
            "meta": {
                **meta,
                "fresh_for_model": fresh_for_model,
                "markets": self.settings.odds_markets,
                "bookmakers": self._bookmakers_for_sport_key(active_sport_key),
                "sport_key": active_sport_key,
                "coverage": coverage,
            },
        }
