from __future__ import annotations

from collections import defaultdict
from datetime import date, datetime, timedelta, timezone
from typing import Any, Iterable
from uuid import uuid4

import httpx

from .config import Settings
from .calibration import (
    CalibrationRegistry,
    build_scope_candidates,
    calibration_metrics,
    clamp_probability,
)

UTC = timezone.utc

DEFAULT_MODEL_WEIGHTS: dict[str, float] = {
    "team_strength": 0.18,
    "starter": 0.26,
    "lineup": 0.23,
    "bullpen": 0.17,
    "advanced": 0.12,
    "environment": 0.04,
}
MODULE_LABELS = {
    "team_strength": "球隊實力",
    "starter": "先發投手",
    "lineup": "打線強度",
    "bullpen": "牛棚狀態",
    "advanced": "進階數據",
    "environment": "環境條件",
}
TERMINAL_STATUSES = {"won", "lost", "push", "void"}


class PerformanceStorageError(RuntimeError):
    pass


def iso_utc(value: datetime | None = None) -> str:
    return (value or datetime.now(UTC)).isoformat().replace("+00:00", "Z")


def _float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def decimal_odds_from_price(value: Any) -> float | None:
    """Convert American odds to decimal odds.

    DiamondMind stores sportsbook prices as American odds.  A small decimal
    fallback is accepted so imported historical rows remain measurable.
    """

    price = _float(value)
    if price is None or price == 0:
        return None
    if 1.0 < price < 20.0 and not float(price).is_integer():
        return round(price, 6)
    if price >= 100:
        return round(1.0 + price / 100.0, 6)
    if price <= -100:
        return round(1.0 + 100.0 / abs(price), 6)
    return None


def financial_result(status: Any, price: Any) -> dict[str, Any]:
    """Return one-unit settlement economics for a recommendation.

    ROI uses flat one-unit staking. Pushes count as one unit of turnover and
    return zero profit; void events are excluded from turnover.
    """

    normalized = str(status or "pending").lower()
    decimal_odds = decimal_odds_from_price(price)
    base = {
        "unit_basis": 1.0,
        "american_odds": _float(price),
        "decimal_odds": decimal_odds,
        "stake_units": 0.0,
        "return_units": 0.0,
        "profit_units": None,
        "roi_percent": None,
    }
    if normalized == "void":
        base.update({"profit_units": 0.0, "roi_percent": 0.0})
        return base
    if normalized not in {"won", "lost", "push"}:
        return base
    if decimal_odds is None:
        return base
    base["stake_units"] = 1.0
    if normalized == "won":
        profit = decimal_odds - 1.0
        base["return_units"] = decimal_odds
    elif normalized == "lost":
        profit = -1.0
        base["return_units"] = 0.0
    else:
        profit = 0.0
        base["return_units"] = 1.0
    base["profit_units"] = round(profit, 4)
    base["roi_percent"] = round(profit * 100.0, 2)
    return base


def row_financials(row: dict[str, Any]) -> dict[str, Any]:
    stored = (row.get("result") or {}).get("performance")
    if isinstance(stored, dict) and stored.get("profit_units") is not None:
        return stored
    return financial_result(row.get("status"), row.get("price"))


def normalize_weights(value: dict[str, Any] | None) -> dict[str, float]:
    raw = value or DEFAULT_MODEL_WEIGHTS
    cleaned = {
        key: max(0.0, float(raw.get(key, DEFAULT_MODEL_WEIGHTS[key])))
        for key in DEFAULT_MODEL_WEIGHTS
    }
    total = sum(cleaned.values())
    if total <= 0:
        return dict(DEFAULT_MODEL_WEIGHTS)
    return {key: round(weight / total, 6) for key, weight in cleaned.items()}


def confidence_band(value: Any) -> str:
    number = _float(value)
    if number is None:
        return "unknown"
    if number < 60:
        return "under_60"
    if number < 65:
        return "60_64"
    if number < 70:
        return "65_69"
    return "70_plus"


def _pick_direction(selection: dict[str, Any]) -> float:
    pick = selection.get("pick") or {}
    side = str(pick.get("side") or "").lower()
    if side == "home":
        return 1.0
    if side == "away":
        return -1.0
    game = selection.get("game") or {}
    team_id = pick.get("team_id")
    if team_id is not None:
        if team_id == (game.get("home") or {}).get("id"):
            return 1.0
        if team_id == (game.get("away") or {}).get("id"):
            return -1.0
    return 0.0


def module_snapshot(selection: dict[str, Any]) -> dict[str, Any]:
    groups = selection.get("analysis_groups") or {}
    direction = _pick_direction(selection)
    result: dict[str, Any] = {}
    factor_by_label = {
        str(item.get("label") or ""): item
        for item in (selection.get("factors") or [])
        if isinstance(item, dict)
    }
    for key, label in MODULE_LABELS.items():
        group = groups.get(key) or {}
        edge_home = _float(group.get("edge_home"))
        edge_for_pick = edge_home * direction if edge_home is not None and direction else None
        factor = factor_by_label.get(label) or {}
        factor_edge = _float(factor.get("edge"))
        if edge_for_pick is None and factor_edge is not None:
            edge_for_pick = factor_edge / 100.0
        result[key] = {
            "label": label,
            "edge_for_pick": round(edge_for_pick, 5) if edge_for_pick is not None else None,
            "edge_home": round(edge_home, 5) if edge_home is not None else None,
            "quality": _float(group.get("quality")) or 0.0,
            "available": bool(group.get("available") or factor.get("available")),
            "factor_value": factor.get("value"),
        }
    return result


def _selection_candidate_id(selection: dict[str, Any], fallback: str) -> str:
    candidate = str(selection.get("candidate_id") or "").strip()
    if candidate:
        return candidate
    pick = selection.get("pick") or {}
    game_pk = selection.get("game_pk") or (selection.get("game") or {}).get("game_pk") or "game"
    market = selection.get("market") or pick.get("market") or "moneyline"
    side = pick.get("side") or pick.get("team_id") or "pick"
    line = pick.get("line")
    return f"{market}:{game_pk}:{side}:{line if line is not None else ''}:{fallback}"


def snapshot_payload(
    *,
    source_type: str,
    source_record_id: str,
    recommendation_date: str,
    selection: dict[str, Any],
    fallback_id: str,
    is_test: bool = False,
    status: str = "pending",
    result: dict[str, Any] | None = None,
) -> dict[str, Any]:
    pick = selection.get("pick") or {}
    engine = selection.get("engine") or {}
    game = selection.get("game") or {}
    candidate_id = _selection_candidate_id(selection, fallback_id)
    weights = normalize_weights(engine.get("weights"))
    odds_snapshot = {
        "price": selection.get("price") if selection.get("price") is not None else pick.get("price"),
        "line": pick.get("line"),
        "implied_probability": selection.get("implied_probability"),
        "edge": selection.get("edge"),
        "source": selection.get("odds_source") or {},
    }
    publication_meta = selection.get("publication") or {}
    publication_mode = publication_meta.get("mode") or "ai_auto"
    publication_snapshot = {
        "published_at": selection.get("published_at") or iso_utc(),
        "locked_at": publication_meta.get("locked_at"),
        "timing": publication_meta.get("timing"),
        "mode": publication_mode,
        "origin_tier": publication_meta.get("origin_tier") or selection.get("candidate_tier") or "formal",
        "selection_tier": publication_meta.get("selection_tier") or selection.get("candidate_tier") or "formal",
        "promoted_from_watchlist": bool(publication_meta.get("promoted_from_watchlist")),
        "counts_as_ai_formal": bool(
            publication_meta.get(
                "counts_as_ai_formal",
                publication_mode != "founder_selected",
            )
        ),
        "roster_validation": selection.get("roster_validation") or {},
        "summary": selection.get("summary"),
    }
    return {
        "source_type": source_type,
        "source_record_id": str(source_record_id),
        "candidate_id": candidate_id,
        "recommendation_date": recommendation_date,
        "league": str(selection.get("league") or game.get("league") or "MLB").upper(),
        "game_pk": str(selection.get("game_pk") or game.get("game_pk") or ""),
        "market": selection.get("market") or pick.get("market") or "moneyline",
        "pick_label": pick.get("label") or selection.get("label") or selection.get("pick_label"),
        "pick_side": pick.get("side"),
        "pick_team_id": str(pick.get("team_id")) if pick.get("team_id") is not None else None,
        "line": pick.get("line"),
        "price": selection.get("price") if selection.get("price") is not None else pick.get("price"),
        "confidence": selection.get("confidence") or selection.get("model_probability"),
        "raw_model_probability": selection.get("raw_model_probability") or selection.get("confidence") or selection.get("model_probability"),
        "calibrated_probability": selection.get("model_probability") or selection.get("confidence"),
        "calibration_profile_id": (selection.get("calibration") or {}).get("profile_id"),
        "data_quality": selection.get("data_quality"),
        "data_integrity": selection.get("data_integrity") or {},
        "model_version": selection.get("model_version"),
        "weights": weights,
        "module_scores": module_snapshot(selection),
        "odds_snapshot": odds_snapshot,
        "publication_snapshot": publication_snapshot,
        "status": status,
        "result": result or {},
        "is_test": bool(is_test),
        "settled_at": iso_utc() if status in TERMINAL_STATUSES else None,
    }


def package_snapshot_payloads(
    recommendation_date: str,
    source_record_id: str,
    package: dict[str, Any],
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for group in ("moneylines", "run_lines", "totals"):
        for index, selection in enumerate(package.get(group) or []):
            rows.append(
                snapshot_payload(
                    source_type="pro",
                    source_record_id=source_record_id,
                    recommendation_date=recommendation_date,
                    selection=selection,
                    fallback_id=f"{group}-{index}",
                )
            )
    for group in ("two_leg", "three_leg"):
        for index, parlay in enumerate((package.get("parlays") or {}).get(group) or []):
            legs = [leg for leg in (parlay.get("legs") or []) if isinstance(leg, dict)]
            aggregate = dict(parlay)
            aggregate["market"] = group
            aggregate["pick"] = {"label": parlay.get("label") or ("二關串關" if group == "two_leg" else "三關串關")}
            aggregate["confidence"] = parlay.get("combined_model_probability")
            aggregate["price"] = parlay.get("combined_american_odds")
            aggregate["league"] = "+".join(sorted({str(leg.get("league") or "MLB").upper() for leg in legs})) or "MLB"
            aggregate["data_quality"] = min(
                [float(leg.get("data_quality") or 0) for leg in legs] or [0]
            )
            aggregate["engine"] = {"weights": normalize_weights((legs[0].get("engine") or {}).get("weights") if legs else None)}
            # Average module support over all legs so parlay rows remain auditable.
            combined_modules: dict[str, dict[str, Any]] = {}
            for key, label in MODULE_LABELS.items():
                samples = [module_snapshot(leg).get(key) or {} for leg in legs]
                edge_values = [_float(item.get("edge_for_pick")) for item in samples]
                edge_values = [value for value in edge_values if value is not None]
                qualities = [_float(item.get("quality")) for item in samples]
                qualities = [value for value in qualities if value is not None]
                combined_modules[key] = {
                    "label": label,
                    "edge_for_pick": round(sum(edge_values) / len(edge_values), 5) if edge_values else None,
                    "edge_home": None,
                    "quality": round(sum(qualities) / len(qualities), 3) if qualities else 0.0,
                    "available": bool(edge_values),
                    "factor_value": None,
                }
            payload = snapshot_payload(
                source_type="pro",
                source_record_id=source_record_id,
                recommendation_date=recommendation_date,
                selection=aggregate,
                fallback_id=f"{group}-{index}",
            )
            payload["module_scores"] = combined_modules
            payload["publication_snapshot"] = {
                **(payload.get("publication_snapshot") or {}),
                "legs": [
                    {
                        "candidate_id": leg.get("candidate_id"),
                        "game_pk": leg.get("game_pk"),
                        "market": leg.get("market"),
                        "pick_label": (leg.get("pick") or {}).get("label"),
                    }
                    for leg in legs
                ],
            }
            rows.append(payload)
    return rows


def summarize_rows(rows: Iterable[dict[str, Any]]) -> dict[str, Any]:
    items = list(rows)
    won = sum(str(item.get("status")) == "won" for item in items)
    lost = sum(str(item.get("status")) == "lost" for item in items)
    push = sum(str(item.get("status")) == "push" for item in items)
    void = sum(str(item.get("status")) == "void" for item in items)
    pending = sum(str(item.get("status")) == "pending" for item in items)
    decisions = won + lost
    financials = [row_financials(item) for item in items]
    priced = [item for item in financials if item.get("profit_units") is not None and float(item.get("stake_units") or 0) > 0]
    stake_units = round(sum(float(item.get("stake_units") or 0) for item in priced), 3)
    profit_units = round(sum(float(item.get("profit_units") or 0) for item in priced), 3)
    return {
        "total": len(items),
        "decisions": decisions,
        "won": won,
        "lost": lost,
        "push": push,
        "void": void,
        "pending": pending,
        "hit_rate": round(won / decisions * 100, 1) if decisions else None,
        "priced_settled": len(priced),
        "stake_units": stake_units,
        "profit_units": profit_units,
        "roi_percent": round(profit_units / stake_units * 100, 2) if stake_units else None,
    }


def profit_curve(rows: Iterable[dict[str, Any]]) -> list[dict[str, Any]]:
    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        grouped[str(row.get("recommendation_date") or "unknown")].append(row)
    cumulative_profit = 0.0
    cumulative_stake = 0.0
    curve: list[dict[str, Any]] = []
    for recommendation_date in sorted(grouped):
        day = summarize_rows(grouped[recommendation_date])
        cumulative_profit += float(day.get("profit_units") or 0)
        cumulative_stake += float(day.get("stake_units") or 0)
        curve.append({
            "date": recommendation_date,
            "daily_profit_units": day.get("profit_units"),
            "daily_stake_units": day.get("stake_units"),
            "daily_roi_percent": day.get("roi_percent"),
            "cumulative_profit_units": round(cumulative_profit, 3),
            "cumulative_stake_units": round(cumulative_stake, 3),
            "cumulative_roi_percent": round(cumulative_profit / cumulative_stake * 100, 2) if cumulative_stake else None,
        })
    return curve


def _bucket(rows: list[dict[str, Any]], key_fn) -> list[dict[str, Any]]:
    groups: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        groups[str(key_fn(row))].append(row)
    return [
        {"key": key, **summarize_rows(values)}
        for key, values in sorted(groups.items(), key=lambda item: item[0])
    ]


def calibration_suggestions(
    rows: list[dict[str, Any]],
    current_weights: dict[str, Any] | None,
) -> dict[str, Any]:
    current = normalize_weights(current_weights)
    decisive = [
        row for row in rows
        if row.get("status") in {"won", "lost"}
        and row.get("market") in {"moneyline", "run_line"}
        and not row.get("is_test")
    ]
    modules: list[dict[str, Any]] = []
    raw_scores: dict[str, float] = {}
    for key, weight in current.items():
        observations = []
        for row in decisive:
            module = (row.get("module_scores") or {}).get(key) or {}
            edge = _float(module.get("edge_for_pick"))
            quality = _float(module.get("quality")) or 0.0
            if edge is None or quality <= 0:
                continue
            success = 1.0 if row.get("status") == "won" else -1.0
            observations.append((edge, quality, success))
        sample = len(observations)
        if sample:
            aligned = sum(1 for edge, _quality, success in observations if edge * success > 0)
            support_accuracy = aligned / sample
            weighted_signal = sum(edge * success * quality for edge, quality, success in observations) / max(
                0.001, sum(quality for _edge, quality, _success in observations)
            )
        else:
            support_accuracy = None
            weighted_signal = 0.0
        # Strong shrinkage prevents small samples from causing unstable changes.
        reliability = min(1.0, sample / 80.0)
        adjustment = max(-0.035, min(0.035, weighted_signal * 0.10)) * reliability
        raw_scores[key] = max(0.01, weight + adjustment)
        modules.append({
            "key": key,
            "label": MODULE_LABELS[key],
            "current_weight": round(weight, 4),
            "sample": sample,
            "support_accuracy": round(support_accuracy * 100, 1) if support_accuracy is not None else None,
            "weighted_signal": round(weighted_signal, 4),
            "reliability": round(reliability, 3),
            "direction": "increase" if adjustment > 0.001 else "decrease" if adjustment < -0.001 else "hold",
        })
    recommended = normalize_weights(raw_scores)
    for module in modules:
        module["recommended_weight"] = recommended[module["key"]]
        module["change_points"] = round((recommended[module["key"]] - module["current_weight"]) * 100, 2)
    enough = len(decisive) >= 30
    return {
        "sample": len(decisive),
        "minimum_sample": 30,
        "ready": enough,
        "current_weights": current,
        "recommended_weights": recommended,
        "modules": modules,
        "message": (
            "樣本數已達校正門檻；建議仍需由創辦人確認後才套用。"
            if enough else
            f"目前只有 {len(decisive)} 筆可校正決策，至少累積 30 筆後才建議調整權重。"
        ),
    }


class PerformanceRepository:
    def __init__(self, settings: Settings, transport: httpx.AsyncBaseTransport | None = None) -> None:
        self.settings = settings
        self.enabled = settings.records_enabled
        key = settings.supabase_secret_key
        headers = {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "User-Agent": "DiamondMind-Performance/1.0",
        }
        if key:
            headers["apikey"] = key
            if not key.startswith("sb_secret_"):
                headers["Authorization"] = f"Bearer {key}"
        base_url = f"{settings.supabase_url}/rest/v1/" if settings.supabase_url else "https://performance.invalid/rest/v1/"
        self.client = httpx.AsyncClient(
            base_url=base_url,
            headers=headers,
            timeout=settings.request_timeout_seconds,
            follow_redirects=True,
            trust_env=False,
            transport=transport,
        )

    async def aclose(self) -> None:
        await self.client.aclose()

    def _require_enabled(self) -> None:
        if not self.enabled:
            raise PerformanceStorageError("Model performance database is not configured")

    async def _request(self, method: str, path: str, **kwargs: Any) -> Any:
        self._require_enabled()
        try:
            response = await self.client.request(method, path, **kwargs)
            if response.status_code >= 400:
                detail = response.text or ""
                if (
                    response.status_code in {404, 400}
                    and "system_retry_jobs" in detail
                ):
                    raise PerformanceStorageError(
                        "V22.2 Retry Queue 資料表尚未建立；請執行隨版本附上的 Supabase SQL。"
                    )
                missing_schema = response.status_code in {404, 400} and any(
                    token in detail
                    for token in (
                        "model_snapshots",
                        "model_weight_profiles",
                        "model_calibration_profiles",
                        "model_calibration_runs",
                        "system_retry_jobs",
                        "PGRST205",
                        "schema cache",
                    )
                )
                if missing_schema:
                    raise PerformanceStorageError(
                        "模型績效資料表尚未建立或 Supabase schema cache 尚未更新；請重新執行 V21 模型 SQL。"
                    )
                response.raise_for_status()
            if not response.content:
                return None
            return response.json()
        except PerformanceStorageError:
            raise
        except (httpx.HTTPError, ValueError) as exc:
            raise PerformanceStorageError("模型績效資料庫暫時無法連線") from exc

    async def enqueue_retry_job(
        self,
        *,
        job_type: str,
        worker_role: str,
        payload: dict[str, Any] | None,
        dedupe_key: str,
        last_error: str | None = None,
        max_attempts: int = 5,
    ) -> dict[str, Any] | None:
        data = await self._request(
            "POST",
            "system_retry_jobs",
            params={"on_conflict": "dedupe_key"},
            headers={"Prefer": "resolution=ignore-duplicates,return=representation"},
            json={
                "job_type": str(job_type),
                "worker_role": str(worker_role),
                "payload": payload or {},
                "status": "pending",
                "attempts": 0,
                "max_attempts": max(1, int(max_attempts)),
                "dedupe_key": str(dedupe_key),
                "last_error": (str(last_error)[:1000] if last_error else None),
                "next_attempt_at": iso_utc(),
            },
        )
        if data is None:
            return None
        if not isinstance(data, list):
            raise PerformanceStorageError("Retry Queue returned an invalid response")
        return data[0] if data else None

    async def claim_retry_job(
        self,
        *,
        worker_role: str,
        locked_by: str,
    ) -> dict[str, Any] | None:
        data = await self._request(
            "POST",
            "rpc/diamondmind_claim_retry_job",
            json={
                "p_worker_role": str(worker_role),
                "p_locked_by": str(locked_by),
            },
        )
        if isinstance(data, dict):
            return data
        if isinstance(data, list):
            return data[0] if data else None
        if data is None:
            return None
        raise PerformanceStorageError("Retry Queue claim returned an invalid response")

    async def complete_retry_job(self, job_id: str) -> None:
        await self._request(
            "PATCH",
            "system_retry_jobs",
            params={"id": f"eq.{job_id}"},
            headers={"Prefer": "return=minimal"},
            json={
                "status": "completed",
                "completed_at": iso_utc(),
                "last_error": None,
                "locked_at": None,
                "locked_by": None,
            },
        )

    async def fail_retry_job(
        self,
        *,
        job: dict[str, Any],
        error: str,
    ) -> str:
        attempts = int(job.get("attempts") or 0)
        maximum = max(1, int(job.get("max_attempts") or 1))
        terminal = attempts >= maximum
        delay_seconds = min(1800, 30 * (2 ** max(0, attempts - 1)))
        await self._request(
            "PATCH",
            "system_retry_jobs",
            params={"id": f"eq.{job.get('id')}"},
            headers={"Prefer": "return=minimal"},
            json={
                "status": "failed" if terminal else "pending",
                "last_error": str(error)[:1000],
                "next_attempt_at": iso_utc(
                    datetime.now(UTC) + timedelta(seconds=delay_seconds)
                ),
                "locked_at": None,
                "locked_by": None,
            },
        )
        return "failed" if terminal else "pending"

    async def retry_queue_snapshot(self, *, limit: int = 100) -> dict[str, Any]:
        data = await self._request(
            "GET",
            "system_retry_jobs",
            params={
                "select": (
                    "id,job_type,worker_role,status,attempts,max_attempts,"
                    "next_attempt_at,last_error,created_at,updated_at,completed_at"
                ),
                "order": "created_at.desc",
                "limit": min(max(1, int(limit)), 500),
            },
        )
        if not isinstance(data, list):
            raise PerformanceStorageError("Retry Queue returned an invalid response")
        counts: dict[str, int] = defaultdict(int)
        for row in data:
            counts[str(row.get("status") or "unknown")] += 1
        return {
            "enabled": True,
            "count": len(data),
            "counts": dict(counts),
            "items": data,
            "updated_at": iso_utc(),
        }

    async def insert_snapshots(self, rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
        if not rows:
            return []
        data = await self._request(
            "POST",
            "model_snapshots",
            params={"on_conflict": "source_type,source_record_id,candidate_id"},
            headers={"Prefer": "resolution=ignore-duplicates,return=representation"},
            json=rows,
        )
        if data is None:
            return []
        if not isinstance(data, list):
            raise PerformanceStorageError("Model snapshot database returned an invalid response")
        return data

    async def capture_public(self, recommendation_date: str, record_id: str, selection: dict[str, Any]) -> None:
        await self.insert_snapshots([
            snapshot_payload(
                source_type="public",
                source_record_id=record_id,
                recommendation_date=recommendation_date,
                selection=selection,
                fallback_id="public",
            )
        ])

    async def capture_package(self, recommendation_date: str, record_id: str, package: dict[str, Any]) -> None:
        await self.insert_snapshots(package_snapshot_payloads(recommendation_date, record_id, package))

    async def settle_candidate(
        self,
        *,
        source_type: str,
        source_record_id: str,
        candidate_id: str,
        result: dict[str, Any],
    ) -> None:
        status = str(result.get("status") or "pending")
        if status not in TERMINAL_STATUSES:
            return
        existing = await self._request(
            "GET",
            "model_snapshots",
            params={
                "select": "id,price,result,status",
                "source_type": f"eq.{source_type}",
                "source_record_id": f"eq.{source_record_id}",
                "candidate_id": f"eq.{candidate_id}",
                "limit": 1,
            },
        )
        row = existing[0] if isinstance(existing, list) and existing else {}
        enriched_result = dict(result)
        stored_performance = result.get("performance")
        if isinstance(stored_performance, dict):
            enriched_result["performance"] = stored_performance
        else:
            enriched_result["performance"] = financial_result(
                status,
                result.get("settlement_price") if result.get("settlement_price") is not None else row.get("price"),
            )
        await self._request(
            "PATCH",
            "model_snapshots",
            params={
                "source_type": f"eq.{source_type}",
                "source_record_id": f"eq.{source_record_id}",
                "candidate_id": f"eq.{candidate_id}",
                "status": "eq.pending",
            },
            headers={"Prefer": "return=minimal"},
            json={"status": status, "result": enriched_result, "settled_at": result.get("settled_at") or iso_utc()},
        )

    async def reconcile_candidate(
        self,
        *,
        source_type: str,
        source_record_id: str,
        candidate_id: str,
        result: dict[str, Any] | None,
    ) -> None:
        """Reopen or replace a terminal snapshot after an official reschedule."""

        existing = await self._request(
            "GET",
            "model_snapshots",
            params={
                "select": "id,price",
                "source_type": f"eq.{source_type}",
                "source_record_id": f"eq.{source_record_id}",
                "candidate_id": f"eq.{candidate_id}",
                "limit": 1,
            },
        )
        row = existing[0] if isinstance(existing, list) and existing else None
        if not row:
            return
        status = str((result or {}).get("status") or "pending")
        if status in TERMINAL_STATUSES:
            enriched = dict(result or {})
            if not isinstance(enriched.get("performance"), dict):
                enriched["performance"] = financial_result(
                    status,
                    enriched.get("settlement_price")
                    if enriched.get("settlement_price") is not None
                    else row.get("price"),
                )
            settled_at = enriched.get("settled_at") or iso_utc()
        else:
            enriched = {}
            settled_at = None
            status = "pending"
        await self._request(
            "PATCH",
            "model_snapshots",
            params={
                "source_type": f"eq.{source_type}",
                "source_record_id": f"eq.{source_record_id}",
                "candidate_id": f"eq.{candidate_id}",
            },
            headers={"Prefer": "return=minimal"},
            json={"status": status, "result": enriched, "settled_at": settled_at},
        )

    async def backfill_financial_metadata(self, rows: list[dict[str, Any]], limit: int = 300) -> int:
        updated = 0
        for row in rows:
            if updated >= limit:
                break
            status = str(row.get("status") or "pending")
            if status not in TERMINAL_STATUSES:
                continue
            result = dict(row.get("result") or {})
            if isinstance(result.get("performance"), dict):
                continue
            result["performance"] = financial_result(status, row.get("price"))
            row["result"] = result
            row_id = row.get("id")
            if not row_id:
                continue
            await self._request(
                "PATCH",
                "model_snapshots",
                params={"id": f"eq.{row_id}"},
                headers={"Prefer": "return=minimal"},
                json={"result": result},
            )
            updated += 1
        return updated

    async def settle_public(self, source_record_id: str, result: dict[str, Any]) -> None:
        data = await self._request(
            "GET",
            "model_snapshots",
            params={
                "select": "candidate_id",
                "source_type": "eq.public",
                "source_record_id": f"eq.{source_record_id}",
                "limit": 1,
            },
        )
        if isinstance(data, list) and data:
            await self.settle_candidate(
                source_type="public",
                source_record_id=source_record_id,
                candidate_id=str(data[0].get("candidate_id")),
                result=result,
            )

    async def reconcile_public(self, source_record_id: str, result: dict[str, Any] | None) -> None:
        data = await self._request(
            "GET",
            "model_snapshots",
            params={
                "select": "candidate_id",
                "source_type": "eq.public",
                "source_record_id": f"eq.{source_record_id}",
                "limit": 1,
            },
        )
        if isinstance(data, list) and data:
            await self.reconcile_candidate(
                source_type="public",
                source_record_id=source_record_id,
                candidate_id=str(data[0].get("candidate_id")),
                result=result,
            )

    async def settle_package(self, source_record_id: str, result_bundle: dict[str, Any]) -> None:
        for group, results in (result_bundle.get("results") or {}).items():
            for result in results or []:
                candidate_id = str(result.get("candidate_id") or "")
                if candidate_id:
                    await self.settle_candidate(
                        source_type="pro",
                        source_record_id=source_record_id,
                        candidate_id=candidate_id,
                        result={**result, "market_group": group},
                    )

    async def reconcile_package(
        self,
        source_record_id: str,
        candidate_ids: set[str],
        result_bundle: dict[str, Any],
    ) -> None:
        replacements: dict[str, dict[str, Any]] = {}
        for group, results in (result_bundle.get("results") or {}).items():
            for result in results or []:
                if not isinstance(result, dict):
                    continue
                candidate_id = str(result.get("candidate_id") or "")
                if candidate_id in candidate_ids:
                    replacements[candidate_id] = {**result, "market_group": group}
        for candidate_id in candidate_ids:
            await self.reconcile_candidate(
                source_type="pro",
                source_record_id=source_record_id,
                candidate_id=candidate_id,
                result=replacements.get(candidate_id),
            )

    async def list_snapshots(
        self,
        *,
        days: int | None = 30,
        include_test: bool = False,
        market: str = "all",
        source_type: str = "all",
        limit: int = 1000,
    ) -> list[dict[str, Any]]:
        params: dict[str, Any] = {
            "select": "*",
            "order": "recommendation_date.desc,created_at.desc",
            "limit": min(max(limit, 1), 5000),
        }
        if days is not None:
            start = (datetime.now(UTC).date() - timedelta(days=max(0, days - 1))).isoformat()
            params["recommendation_date"] = f"gte.{start}"
        if not include_test:
            params["is_test"] = "eq.false"
        if market != "all":
            params["market"] = f"eq.{market}"
        if source_type != "all":
            params["source_type"] = f"eq.{source_type}"
        data = await self._request("GET", "model_snapshots", params=params)
        if not isinstance(data, list):
            raise PerformanceStorageError("Model snapshot database returned an invalid response")
        return data

    async def performance_dashboard(
        self,
        *,
        days: int | None,
        market: str,
        source_type: str,
    ) -> dict[str, Any]:
        rows = await self.list_snapshots(days=days, market=market, source_type=source_type, limit=5000)
        # Dashboard reads must never perform sequential PATCH backfills.
        # row_financials() calculates legacy rows in memory, while a separate
        # background migration may persist metadata later.
        try:
            current = await self.active_weights()
        except PerformanceStorageError:
            current = dict(DEFAULT_MODEL_WEIGHTS)
        return {
            "range_days": days,
            "market": market,
            "source_type": source_type,
            "summary": summarize_rows(rows),
            "by_market": _bucket(rows, lambda row: row.get("market") or "unknown"),
            "by_confidence": _bucket(rows, lambda row: confidence_band(row.get("confidence"))),
            "by_source": _bucket(rows, lambda row: row.get("source_type") or "unknown"),
            "by_league": _bucket(rows, lambda row: row.get("league") or "unknown"),
            "by_model_version": _bucket(
                rows,
                lambda row: row.get("model_version") or "unknown",
            ),
            "profit_curve": profit_curve(rows),
            "by_publication_mode": _bucket(
                rows,
                lambda row: (
                    (row.get("publication_snapshot") or {}).get("mode")
                    or "ai_auto"
                ),
            ),
            "calibration": calibration_suggestions(rows, current),
            "active_weights": normalize_weights(current),
            "updated_at": iso_utc(),
        }

    async def records_performance(self, *, days: int | None = None) -> dict[str, Any]:
        rows = await self.list_snapshots(days=days, market="all", source_type="pro", limit=5000)
        return {
            "unit_basis": "flat_1_unit",
            "summary": summarize_rows(rows),
            "by_market": _bucket(rows, lambda row: row.get("market") or "unknown"),
            "by_league": _bucket(rows, lambda row: row.get("league") or "unknown"),
            "profit_curve": profit_curve(rows),
            "updated_at": iso_utc(),
        }

    async def active_profile(self) -> dict[str, Any] | None:
        data = await self._request(
            "GET",
            "model_weight_profiles",
            params={"select": "*", "status": "eq.active", "order": "activated_at.desc", "limit": 1},
        )
        if not isinstance(data, list):
            raise PerformanceStorageError("Weight profile database returned an invalid response")
        return data[0] if data else None

    async def active_weights(self) -> dict[str, float]:
        profile = await self.active_profile()
        return normalize_weights((profile or {}).get("weights"))

    async def activate_weights(self, *, weights: dict[str, Any], actor_id: str, note: str | None) -> dict[str, Any]:
        normalized = normalize_weights(weights)
        now = iso_utc()
        await self._request(
            "PATCH",
            "model_weight_profiles",
            params={"status": "eq.active"},
            headers={"Prefer": "return=minimal"},
            json={"status": "superseded"},
        )
        data = await self._request(
            "POST",
            "model_weight_profiles",
            headers={"Prefer": "return=representation"},
            json={
                "weights": normalized,
                "status": "active",
                "note": note,
                "created_by": actor_id,
                "activated_at": now,
            },
        )
        if not isinstance(data, list) or not data:
            raise PerformanceStorageError("New weight profile could not be activated")
        return data[0]

    async def create_weight_challenger(
        self,
        *,
        weights: dict[str, Any],
        actor_id: str,
        note: str | None,
        calibration: dict[str, Any],
    ) -> dict[str, Any]:
        """Persist a founder-requested weight change as a TEST-only run.

        Weight candidates share the durable calibration-run audit trail, but
        they never modify the active runtime profile until the separate Deploy
        endpoint records an explicit founder promotion.
        """

        started_at = iso_utc()
        normalized = normalize_weights(weights)
        current = normalize_weights(calibration.get("current_weights"))
        candidate = {
            "kind": "weight_profile",
            "league": "GLOBAL",
            "market": "weights",
            "version": (
                "dm-weights-test-"
                f"{datetime.now(UTC).strftime('%Y%m%d%H%M%S')}-{uuid4().hex[:6]}"
            ),
            "weights": normalized,
            "current_weights": current,
            "sample": int(calibration.get("sample") or 0),
            "train_sample": int(calibration.get("sample") or 0),
            "validation_sample": int(calibration.get("sample") or 0),
            "modules": calibration.get("modules") or [],
            "ready": bool(calibration.get("ready")),
            "promote": bool(calibration.get("ready")),
            "reason": "historical_module_support_validation",
            "note": note,
            "created_by": actor_id,
            "created_at": started_at,
            "baseline_metrics": {"weights": current},
            "candidate_metrics": {"weights": normalized},
            "improvement": {
                "absolute_weight_change": round(
                    sum(
                        abs(normalized[key] - current[key])
                        for key in DEFAULT_MODEL_WEIGHTS
                    ),
                    6,
                ),
            },
        }
        run = await self._record_calibration_run({
            "started_at": started_at,
            "completed_at": started_at,
            "status": "completed",
            "rows_scanned": candidate["sample"],
            "candidates": [candidate],
            "promoted": [],
        })
        if not run:
            raise PerformanceStorageError("Weight TEST Challenger could not be created")
        return {"run": run, "candidate": candidate}

    async def record_weight_promotion(
        self,
        *,
        run_id: str,
        profile: dict[str, Any],
        weights: dict[str, Any],
    ) -> None:
        run = await self.get_calibration_run(run_id)
        if not run:
            return
        promoted = [
            item
            for item in (run.get("promoted") or [])
            if isinstance(item, dict)
        ]
        if any(
            str(item.get("kind") or "") == "weight_profile"
            for item in promoted
        ):
            return
        promoted.append({
            "id": profile.get("id"),
            "kind": "weight_profile",
            "league": "GLOBAL",
            "market": "weights",
            "weights": normalize_weights(weights),
            "manual": True,
            "promoted_at": iso_utc(),
        })
        await self._update_calibration_run(run_id, {"promoted": promoted})

    async def create_test_snapshot(self, payload: dict[str, Any]) -> dict[str, Any]:
        selection = {
            "candidate_id": f"test:{uuid4().hex}",
            "game_pk": payload.get("game_pk") or 0,
            "market": payload.get("market"),
            "pick": {
                "market": payload.get("market"),
                "side": payload.get("pick_side"),
                "line": payload.get("line"),
                "team_id": 1 if payload.get("pick_side") == "away" else 2 if payload.get("pick_side") == "home" else None,
                "label": payload.get("pick_label") or "測試推薦",
            },
            "confidence": payload.get("confidence"),
            "data_quality": payload.get("data_quality"),
            "model_version": "dm-test-settlement-v1",
            "engine": {"weights": payload.get("weights") or DEFAULT_MODEL_WEIGHTS},
            "analysis_groups": payload.get("analysis_groups") or {},
            "factors": payload.get("factors") or [],
            "game": {
                "game_pk": payload.get("game_pk") or 0,
                "away": {"id": 1, "abbr": "AWY"},
                "home": {"id": 2, "abbr": "HME"},
            },
        }
        result = payload.get("result") or {}
        row = snapshot_payload(
            source_type="test",
            source_record_id=f"test-{uuid4().hex}",
            recommendation_date=str(payload.get("recommendation_date") or date.today().isoformat()),
            selection=selection,
            fallback_id="test",
            is_test=True,
            status=str(result.get("status") or "pending"),
            result=result,
        )
        inserted = await self.insert_snapshots([row])
        return inserted[0] if inserted else row


    async def list_calibration_profiles(self, *, active_only: bool = False) -> list[dict[str, Any]]:
        params: dict[str, Any] = {
            "select": "*",
            "order": "league.asc,market.asc,activated_at.desc.nullslast,created_at.desc",
            "limit": 500,
        }
        if active_only:
            params["status"] = "eq.active"
        data = await self._request("GET", "model_calibration_profiles", params=params)
        if not isinstance(data, list):
            raise PerformanceStorageError("Calibration profile database returned an invalid response")
        return data

    async def list_calibration_runs(self, *, limit: int = 20) -> list[dict[str, Any]]:
        data = await self._request(
            "GET",
            "model_calibration_runs",
            params={
                "select": "*",
                "order": "started_at.desc",
                "limit": min(max(int(limit), 1), 100),
            },
        )
        if not isinstance(data, list):
            raise PerformanceStorageError("Calibration run database returned an invalid response")
        return data

    async def get_calibration_run(self, run_id: str) -> dict[str, Any] | None:
        data = await self._request(
            "GET",
            "model_calibration_runs",
            params={"select": "*", "id": f"eq.{run_id}", "limit": 1},
        )
        if not isinstance(data, list):
            raise PerformanceStorageError("Calibration run database returned an invalid response")
        return data[0] if data else None

    async def get_calibration_profile(self, profile_id: str) -> dict[str, Any] | None:
        data = await self._request(
            "GET",
            "model_calibration_profiles",
            params={"select": "*", "id": f"eq.{profile_id}", "limit": 1},
        )
        if not isinstance(data, list):
            raise PerformanceStorageError("Calibration profile database returned an invalid response")
        return data[0] if data else None

    async def calibration_registry(self) -> CalibrationRegistry:
        rows = await self.list_calibration_profiles(active_only=True)
        return CalibrationRegistry.from_rows(rows)

    async def _record_calibration_run(self, payload: dict[str, Any]) -> dict[str, Any] | None:
        data = await self._request(
            "POST",
            "model_calibration_runs",
            headers={"Prefer": "return=representation"},
            json=payload,
        )
        if isinstance(data, list) and data:
            return data[0]
        return None

    async def _update_calibration_run(self, run_id: str, payload: dict[str, Any]) -> None:
        await self._request(
            "PATCH",
            "model_calibration_runs",
            params={"id": f"eq.{run_id}"},
            headers={"Prefer": "return=minimal"},
            json=payload,
        )

    async def activate_calibration_profile(
        self,
        *,
        candidate: dict[str, Any],
        actor_id: str,
        auto_promoted: bool,
    ) -> dict[str, Any]:
        league = str(candidate.get("league") or "GLOBAL").upper()
        market = str(candidate.get("market") or "all").lower()
        now = iso_utc()
        await self._request(
            "PATCH",
            "model_calibration_profiles",
            params={"league": f"eq.{league}", "market": f"eq.{market}", "status": "eq.active"},
            headers={"Prefer": "return=minimal"},
            json={"status": "superseded"},
        )
        version = (
            f"dm-cal-{league.lower()}-{market}-"
            f"{datetime.now(UTC).strftime('%Y%m%d%H%M%S')}-{uuid4().hex[:6]}"
        )
        data = await self._request(
            "POST",
            "model_calibration_profiles",
            headers={"Prefer": "return=representation"},
            json={
                "league": league,
                "market": market,
                "slope": candidate.get("slope"),
                "intercept": candidate.get("intercept"),
                "sample": candidate.get("sample"),
                "train_sample": candidate.get("train_sample"),
                "validation_sample": candidate.get("validation_sample"),
                "baseline_metrics": candidate.get("baseline_metrics") or {},
                "validation_metrics": candidate.get("candidate_metrics") or {},
                "improvement": candidate.get("improvement") or {},
                "status": "active",
                "promotion_reason": candidate.get("reason"),
                "version": version,
                "created_by": actor_id,
                "auto_promoted": bool(auto_promoted),
                "activated_at": now,
            },
        )
        if not isinstance(data, list) or not data:
            raise PerformanceStorageError("Calibration profile could not be activated")
        return data[0]

    async def record_calibration_promotion(
        self,
        *,
        run_id: str,
        profile: dict[str, Any],
    ) -> None:
        run = await self.get_calibration_run(run_id)
        if not run:
            return
        promoted = [
            item
            for item in (run.get("promoted") or [])
            if isinstance(item, dict)
        ]
        scope = (
            str(profile.get("league") or "GLOBAL").upper(),
            str(profile.get("market") or "all").lower(),
        )
        if any(
            (
                str(item.get("league") or "GLOBAL").upper(),
                str(item.get("market") or "all").lower(),
            ) == scope
            for item in promoted
        ):
            return
        promoted.append({
            "id": profile.get("id"),
            "league": profile.get("league"),
            "market": profile.get("market"),
            "version": profile.get("version"),
            "manual": True,
            "promoted_at": iso_utc(),
        })
        await self._update_calibration_run(run_id, {"promoted": promoted})

    async def restore_calibration_profile(
        self,
        *,
        profile_id: str,
        actor_id: str,
    ) -> dict[str, Any] | None:
        source = await self.get_calibration_profile(profile_id)
        if not source:
            return None
        return await self.activate_calibration_profile(
            candidate={
                "league": source.get("league"),
                "market": source.get("market"),
                "slope": source.get("slope"),
                "intercept": source.get("intercept"),
                "sample": source.get("sample"),
                "train_sample": source.get("train_sample"),
                "validation_sample": source.get("validation_sample"),
                "baseline_metrics": source.get("baseline_metrics") or {},
                "candidate_metrics": (
                    source.get("validation_metrics")
                    or source.get("candidate_metrics")
                    or {}
                ),
                "improvement": source.get("improvement") or {},
                "reason": f"rollback_from:{source.get('version') or profile_id}",
            },
            actor_id=actor_id,
            auto_promoted=False,
        )

    async def auto_calibrate(
        self,
        *,
        actor_id: str = "system:auto-calibration",
        days: int | None = 365,
        minimum_sample: int = 60,
        minimum_validation_sample: int = 18,
        promote: bool = False,
    ) -> dict[str, Any]:
        started_at = iso_utc()
        run = await self._record_calibration_run({
            "started_at": started_at,
            "status": "running",
            "rows_scanned": 0,
            "candidates": [],
            "promoted": [],
        })
        run_id = str((run or {}).get("id") or "")
        try:
            rows = await self.list_snapshots(days=days, include_test=False, market="all", source_type="all", limit=5000)
            candidates = build_scope_candidates(
                rows,
                minimum_sample=minimum_sample,
                minimum_validation_sample=minimum_validation_sample,
            )
            promoted: list[dict[str, Any]] = []
            for candidate in candidates:
                if promote and candidate.get("promote"):
                    profile = await self.activate_calibration_profile(
                        candidate=candidate,
                        actor_id=actor_id,
                        auto_promoted=False,
                    )
                    promoted.append({
                        "id": profile.get("id"),
                        "league": profile.get("league"),
                        "market": profile.get("market"),
                        "version": profile.get("version"),
                    })
            result = {
                "ok": True,
                "status": "completed",
                "run_id": run_id or None,
                "started_at": started_at,
                "completed_at": iso_utc(),
                "rows_scanned": len(rows),
                "candidates": candidates,
                "promoted": promoted,
                "promoted_count": len(promoted),
            }
            if run_id:
                await self._update_calibration_run(run_id, {
                    "completed_at": result["completed_at"],
                    "status": "completed",
                    "rows_scanned": len(rows),
                    "candidates": candidates,
                    "promoted": promoted,
                })
            return result
        except Exception as exc:
            if run_id:
                try:
                    await self._update_calibration_run(run_id, {
                        "completed_at": iso_utc(),
                        "status": "failed",
                        "error": f"{type(exc).__name__}: {exc}",
                    })
                except Exception:
                    pass
            if isinstance(exc, PerformanceStorageError):
                raise
            raise PerformanceStorageError("Automatic calibration failed") from exc

    async def performance_v21_dashboard(
        self,
        *,
        days: int | None = 365,
        league: str = "all",
        market: str = "all",
    ) -> dict[str, Any]:
        rows = await self.list_snapshots(days=days, include_test=False, market=market, source_type="all", limit=5000)
        if league != "all":
            code = str(league).upper()
            rows = [row for row in rows if str(row.get("league") or "").upper() == code]
        await self.backfill_financial_metadata(rows)
        decisive = [row for row in rows if str(row.get("status")) in {"won", "lost"}]
        raw_probabilities = [clamp_probability(row.get("raw_model_probability") or row.get("confidence")) for row in decisive]
        calibrated_probabilities = [clamp_probability(row.get("calibrated_probability") or row.get("confidence")) for row in decisive]
        labels = [1 if str(row.get("status")) == "won" else 0 for row in decisive]
        profiles = await self.list_calibration_profiles(active_only=True)
        return {
            "range_days": days,
            "league": league,
            "market": market,
            "summary": summarize_rows(rows),
            "probability_quality": {
                "raw": calibration_metrics(raw_probabilities, labels),
                "calibrated": calibration_metrics(calibrated_probabilities, labels),
            },
            "by_market": _bucket(rows, lambda row: row.get("market") or "unknown"),
            "by_league": _bucket(rows, lambda row: row.get("league") or "unknown"),
            "by_confidence": _bucket(rows, lambda row: confidence_band(row.get("calibrated_probability") or row.get("confidence"))),
            "by_publication_mode": _bucket(rows, lambda row: (row.get("publication_snapshot") or {}).get("mode") or "ai_auto"),
            "profit_curve": profit_curve(rows),
            "active_calibration_profiles": profiles,
            "data_quality": {
                "settled_rows": len(decisive),
                "pending_rows": sum(str(row.get("status")) == "pending" for row in rows),
                "missing_price": sum(row.get("price") is None for row in decisive),
                "missing_raw_probability": sum(row.get("raw_model_probability") is None and row.get("confidence") is None for row in decisive),
                "missing_calibrated_probability": sum(row.get("calibrated_probability") is None for row in decisive),
            },
            "updated_at": iso_utc(),
        }
