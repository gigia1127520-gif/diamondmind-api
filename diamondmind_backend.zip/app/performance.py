from __future__ import annotations

from collections import defaultdict
from datetime import date, datetime, timedelta, timezone
from typing import Any, Iterable
from uuid import uuid4

import httpx

from .config import Settings

UTC = timezone.utc

DEFAULT_MODEL_WEIGHTS: dict[str, float] = {
    "team_strength": 0.18,
    "starter": 0.26,
    "lineup": 0.23,
    "bullpen": 0.17,
    "advanced": 0.12,
    "environment": 0.04,
}
MODULE_LABELS = {
    "team_strength": "球隊實力",
    "starter": "先發投手",
    "lineup": "打線強度",
    "bullpen": "牛棚狀態",
    "advanced": "進階數據",
    "environment": "環境條件",
}
TERMINAL_STATUSES = {"won", "lost", "push", "void"}


class PerformanceStorageError(RuntimeError):
    pass


def iso_utc(value: datetime | None = None) -> str:
    return (value or datetime.now(UTC)).isoformat().replace("+00:00", "Z")


def _float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def normalize_weights(value: dict[str, Any] | None) -> dict[str, float]:
    raw = value or DEFAULT_MODEL_WEIGHTS
    cleaned = {
        key: max(0.0, float(raw.get(key, DEFAULT_MODEL_WEIGHTS[key])))
        for key in DEFAULT_MODEL_WEIGHTS
    }
    total = sum(cleaned.values())
    if total <= 0:
        return dict(DEFAULT_MODEL_WEIGHTS)
    return {key: round(weight / total, 6) for key, weight in cleaned.items()}


def confidence_band(value: Any) -> str:
    number = _float(value)
    if number is None:
        return "unknown"
    if number < 60:
        return "under_60"
    if number < 65:
        return "60_64"
    if number < 70:
        return "65_69"
    return "70_plus"


def _pick_direction(selection: dict[str, Any]) -> float:
    pick = selection.get("pick") or {}
    side = str(pick.get("side") or "").lower()
    if side == "home":
        return 1.0
    if side == "away":
        return -1.0
    game = selection.get("game") or {}
    team_id = pick.get("team_id")
    if team_id is not None:
        if team_id == (game.get("home") or {}).get("id"):
            return 1.0
        if team_id == (game.get("away") or {}).get("id"):
            return -1.0
    return 0.0


def module_snapshot(selection: dict[str, Any]) -> dict[str, Any]:
    groups = selection.get("analysis_groups") or {}
    direction = _pick_direction(selection)
    result: dict[str, Any] = {}
    factor_by_label = {
        str(item.get("label") or ""): item
        for item in (selection.get("factors") or [])
        if isinstance(item, dict)
    }
    for key, label in MODULE_LABELS.items():
        group = groups.get(key) or {}
        edge_home = _float(group.get("edge_home"))
        edge_for_pick = edge_home * direction if edge_home is not None and direction else None
        factor = factor_by_label.get(label) or {}
        factor_edge = _float(factor.get("edge"))
        if edge_for_pick is None and factor_edge is not None:
            edge_for_pick = factor_edge / 100.0
        result[key] = {
            "label": label,
            "edge_for_pick": round(edge_for_pick, 5) if edge_for_pick is not None else None,
            "edge_home": round(edge_home, 5) if edge_home is not None else None,
            "quality": _float(group.get("quality")) or 0.0,
            "available": bool(group.get("available") or factor.get("available")),
            "factor_value": factor.get("value"),
        }
    return result


def _selection_candidate_id(selection: dict[str, Any], fallback: str) -> str:
    candidate = str(selection.get("candidate_id") or "").strip()
    if candidate:
        return candidate
    pick = selection.get("pick") or {}
    game_pk = selection.get("game_pk") or (selection.get("game") or {}).get("game_pk") or "game"
    market = selection.get("market") or pick.get("market") or "moneyline"
    side = pick.get("side") or pick.get("team_id") or "pick"
    line = pick.get("line")
    return f"{market}:{game_pk}:{side}:{line if line is not None else ''}:{fallback}"


def snapshot_payload(
    *,
    source_type: str,
    source_record_id: str,
    recommendation_date: str,
    selection: dict[str, Any],
    fallback_id: str,
    is_test: bool = False,
    status: str = "pending",
    result: dict[str, Any] | None = None,
) -> dict[str, Any]:
    pick = selection.get("pick") or {}
    engine = selection.get("engine") or {}
    game = selection.get("game") or {}
    candidate_id = _selection_candidate_id(selection, fallback_id)
    weights = normalize_weights(engine.get("weights"))
    odds_snapshot = {
        "price": selection.get("price") if selection.get("price") is not None else pick.get("price"),
        "line": pick.get("line"),
        "implied_probability": selection.get("implied_probability"),
        "edge": selection.get("edge"),
        "source": selection.get("odds_source") or {},
    }
    publication_meta = selection.get("publication") or {}
    publication_mode = publication_meta.get("mode") or "ai_auto"
    publication_snapshot = {
        "published_at": selection.get("published_at") or iso_utc(),
        "locked_at": publication_meta.get("locked_at"),
        "timing": publication_meta.get("timing"),
        "mode": publication_mode,
        "origin_tier": publication_meta.get("origin_tier") or selection.get("candidate_tier") or "formal",
        "selection_tier": publication_meta.get("selection_tier") or selection.get("candidate_tier") or "formal",
        "promoted_from_watchlist": bool(publication_meta.get("promoted_from_watchlist")),
        "counts_as_ai_formal": bool(
            publication_meta.get(
                "counts_as_ai_formal",
                publication_mode != "founder_selected",
            )
        ),
        "roster_validation": selection.get("roster_validation") or {},
        "summary": selection.get("summary"),
    }
    return {
        "source_type": source_type,
        "source_record_id": str(source_record_id),
        "candidate_id": candidate_id,
        "recommendation_date": recommendation_date,
        "game_pk": selection.get("game_pk") or game.get("game_pk"),
        "market": selection.get("market") or pick.get("market") or "moneyline",
        "pick_label": pick.get("label") or selection.get("label") or selection.get("pick_label"),
        "pick_side": pick.get("side"),
        "pick_team_id": pick.get("team_id"),
        "line": pick.get("line"),
        "price": selection.get("price") if selection.get("price") is not None else pick.get("price"),
        "confidence": selection.get("confidence") or selection.get("model_probability"),
        "data_quality": selection.get("data_quality"),
        "model_version": selection.get("model_version"),
        "weights": weights,
        "module_scores": module_snapshot(selection),
        "odds_snapshot": odds_snapshot,
        "publication_snapshot": publication_snapshot,
        "status": status,
        "result": result or {},
        "is_test": bool(is_test),
        "settled_at": iso_utc() if status in TERMINAL_STATUSES else None,
    }


def package_snapshot_payloads(
    recommendation_date: str,
    source_record_id: str,
    package: dict[str, Any],
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for group in ("moneylines", "run_lines", "totals"):
        for index, selection in enumerate(package.get(group) or []):
            rows.append(
                snapshot_payload(
                    source_type="pro",
                    source_record_id=source_record_id,
                    recommendation_date=recommendation_date,
                    selection=selection,
                    fallback_id=f"{group}-{index}",
                )
            )
    for group in ("two_leg", "three_leg"):
        for index, parlay in enumerate((package.get("parlays") or {}).get(group) or []):
            legs = [leg for leg in (parlay.get("legs") or []) if isinstance(leg, dict)]
            aggregate = dict(parlay)
            aggregate["market"] = group
            aggregate["pick"] = {"label": parlay.get("label") or ("二關串關" if group == "two_leg" else "三關串關")}
            aggregate["confidence"] = parlay.get("combined_model_probability")
            aggregate["data_quality"] = min(
                [float(leg.get("data_quality") or 0) for leg in legs] or [0]
            )
            aggregate["engine"] = {"weights": normalize_weights((legs[0].get("engine") or {}).get("weights") if legs else None)}
            # Average module support over all legs so parlay rows remain auditable.
            combined_modules: dict[str, dict[str, Any]] = {}
            for key, label in MODULE_LABELS.items():
                samples = [module_snapshot(leg).get(key) or {} for leg in legs]
                edge_values = [_float(item.get("edge_for_pick")) for item in samples]
                edge_values = [value for value in edge_values if value is not None]
                qualities = [_float(item.get("quality")) for item in samples]
                qualities = [value for value in qualities if value is not None]
                combined_modules[key] = {
                    "label": label,
                    "edge_for_pick": round(sum(edge_values) / len(edge_values), 5) if edge_values else None,
                    "edge_home": None,
                    "quality": round(sum(qualities) / len(qualities), 3) if qualities else 0.0,
                    "available": bool(edge_values),
                    "factor_value": None,
                }
            payload = snapshot_payload(
                source_type="pro",
                source_record_id=source_record_id,
                recommendation_date=recommendation_date,
                selection=aggregate,
                fallback_id=f"{group}-{index}",
            )
            payload["module_scores"] = combined_modules
            payload["publication_snapshot"] = {
                **(payload.get("publication_snapshot") or {}),
                "legs": [
                    {
                        "candidate_id": leg.get("candidate_id"),
                        "game_pk": leg.get("game_pk"),
                        "market": leg.get("market"),
                        "pick_label": (leg.get("pick") or {}).get("label"),
                    }
                    for leg in legs
                ],
            }
            rows.append(payload)
    return rows


def summarize_rows(rows: Iterable[dict[str, Any]]) -> dict[str, Any]:
    items = list(rows)
    won = sum(str(item.get("status")) == "won" for item in items)
    lost = sum(str(item.get("status")) == "lost" for item in items)
    push = sum(str(item.get("status")) == "push" for item in items)
    void = sum(str(item.get("status")) == "void" for item in items)
    pending = sum(str(item.get("status")) == "pending" for item in items)
    decisions = won + lost
    return {
        "total": len(items),
        "decisions": decisions,
        "won": won,
        "lost": lost,
        "push": push,
        "void": void,
        "pending": pending,
        "hit_rate": round(won / decisions * 100, 1) if decisions else None,
    }


def _bucket(rows: list[dict[str, Any]], key_fn) -> list[dict[str, Any]]:
    groups: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        groups[str(key_fn(row))].append(row)
    return [
        {"key": key, **summarize_rows(values)}
        for key, values in sorted(groups.items(), key=lambda item: item[0])
    ]


def calibration_suggestions(
    rows: list[dict[str, Any]],
    current_weights: dict[str, Any] | None,
) -> dict[str, Any]:
    current = normalize_weights(current_weights)
    decisive = [
        row for row in rows
        if row.get("status") in {"won", "lost"}
        and row.get("market") in {"moneyline", "run_line"}
        and not row.get("is_test")
    ]
    modules: list[dict[str, Any]] = []
    raw_scores: dict[str, float] = {}
    for key, weight in current.items():
        observations = []
        for row in decisive:
            module = (row.get("module_scores") or {}).get(key) or {}
            edge = _float(module.get("edge_for_pick"))
            quality = _float(module.get("quality")) or 0.0
            if edge is None or quality <= 0:
                continue
            success = 1.0 if row.get("status") == "won" else -1.0
            observations.append((edge, quality, success))
        sample = len(observations)
        if sample:
            aligned = sum(1 for edge, _quality, success in observations if edge * success > 0)
            support_accuracy = aligned / sample
            weighted_signal = sum(edge * success * quality for edge, quality, success in observations) / max(
                0.001, sum(quality for _edge, quality, _success in observations)
            )
        else:
            support_accuracy = None
            weighted_signal = 0.0
        # Strong shrinkage prevents small samples from causing unstable changes.
        reliability = min(1.0, sample / 80.0)
        adjustment = max(-0.035, min(0.035, weighted_signal * 0.10)) * reliability
        raw_scores[key] = max(0.01, weight + adjustment)
        modules.append({
            "key": key,
            "label": MODULE_LABELS[key],
            "current_weight": round(weight, 4),
            "sample": sample,
            "support_accuracy": round(support_accuracy * 100, 1) if support_accuracy is not None else None,
            "weighted_signal": round(weighted_signal, 4),
            "reliability": round(reliability, 3),
            "direction": "increase" if adjustment > 0.001 else "decrease" if adjustment < -0.001 else "hold",
        })
    recommended = normalize_weights(raw_scores)
    for module in modules:
        module["recommended_weight"] = recommended[module["key"]]
        module["change_points"] = round((recommended[module["key"]] - module["current_weight"]) * 100, 2)
    enough = len(decisive) >= 30
    return {
        "sample": len(decisive),
        "minimum_sample": 30,
        "ready": enough,
        "current_weights": current,
        "recommended_weights": recommended,
        "modules": modules,
        "message": (
            "樣本數已達校正門檻；建議仍需由創辦人確認後才套用。"
            if enough else
            f"目前只有 {len(decisive)} 筆可校正決策，至少累積 30 筆後才建議調整權重。"
        ),
    }


class PerformanceRepository:
    def __init__(self, settings: Settings, transport: httpx.AsyncBaseTransport | None = None) -> None:
        self.settings = settings
        self.enabled = settings.records_enabled
        key = settings.supabase_secret_key
        headers = {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "User-Agent": "DiamondMind-Performance/1.0",
        }
        if key:
            headers["apikey"] = key
            if not key.startswith("sb_secret_"):
                headers["Authorization"] = f"Bearer {key}"
        base_url = f"{settings.supabase_url}/rest/v1/" if settings.supabase_url else "https://performance.invalid/rest/v1/"
        self.client = httpx.AsyncClient(
            base_url=base_url,
            headers=headers,
            timeout=settings.request_timeout_seconds,
            follow_redirects=True,
            trust_env=False,
            transport=transport,
        )

    async def aclose(self) -> None:
        await self.client.aclose()

    def _require_enabled(self) -> None:
        if not self.enabled:
            raise PerformanceStorageError("Model performance database is not configured")

    async def _request(self, method: str, path: str, **kwargs: Any) -> Any:
        self._require_enabled()
        try:
            response = await self.client.request(method, path, **kwargs)
            response.raise_for_status()
            if not response.content:
                return None
            return response.json()
        except (httpx.HTTPError, ValueError) as exc:
            raise PerformanceStorageError("Model performance database is temporarily unavailable") from exc

    async def insert_snapshots(self, rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
        if not rows:
            return []
        data = await self._request(
            "POST",
            "model_snapshots",
            params={"on_conflict": "source_type,source_record_id,candidate_id"},
            headers={"Prefer": "resolution=ignore-duplicates,return=representation"},
            json=rows,
        )
        if data is None:
            return []
        if not isinstance(data, list):
            raise PerformanceStorageError("Model snapshot database returned an invalid response")
        return data

    async def capture_public(self, recommendation_date: str, record_id: str, selection: dict[str, Any]) -> None:
        await self.insert_snapshots([
            snapshot_payload(
                source_type="public",
                source_record_id=record_id,
                recommendation_date=recommendation_date,
                selection=selection,
                fallback_id="public",
            )
        ])

    async def capture_package(self, recommendation_date: str, record_id: str, package: dict[str, Any]) -> None:
        await self.insert_snapshots(package_snapshot_payloads(recommendation_date, record_id, package))

    async def settle_candidate(
        self,
        *,
        source_type: str,
        source_record_id: str,
        candidate_id: str,
        result: dict[str, Any],
    ) -> None:
        status = str(result.get("status") or "pending")
        if status not in TERMINAL_STATUSES:
            return
        await self._request(
            "PATCH",
            "model_snapshots",
            params={
                "source_type": f"eq.{source_type}",
                "source_record_id": f"eq.{source_record_id}",
                "candidate_id": f"eq.{candidate_id}",
                "status": "eq.pending",
            },
            headers={"Prefer": "return=minimal"},
            json={"status": status, "result": result, "settled_at": result.get("settled_at") or iso_utc()},
        )

    async def settle_public(self, source_record_id: str, result: dict[str, Any]) -> None:
        data = await self._request(
            "GET",
            "model_snapshots",
            params={
                "select": "candidate_id",
                "source_type": "eq.public",
                "source_record_id": f"eq.{source_record_id}",
                "limit": 1,
            },
        )
        if isinstance(data, list) and data:
            await self.settle_candidate(
                source_type="public",
                source_record_id=source_record_id,
                candidate_id=str(data[0].get("candidate_id")),
                result=result,
            )

    async def settle_package(self, source_record_id: str, result_bundle: dict[str, Any]) -> None:
        for group, results in (result_bundle.get("results") or {}).items():
            for result in results or []:
                candidate_id = str(result.get("candidate_id") or "")
                if candidate_id:
                    await self.settle_candidate(
                        source_type="pro",
                        source_record_id=source_record_id,
                        candidate_id=candidate_id,
                        result={**result, "market_group": group},
                    )

    async def list_snapshots(
        self,
        *,
        days: int | None = 30,
        include_test: bool = False,
        market: str = "all",
        source_type: str = "all",
        limit: int = 1000,
    ) -> list[dict[str, Any]]:
        params: dict[str, Any] = {
            "select": "*",
            "order": "recommendation_date.desc,created_at.desc",
            "limit": min(max(limit, 1), 5000),
        }
        if days is not None:
            start = (datetime.now(UTC).date() - timedelta(days=max(0, days - 1))).isoformat()
            params["recommendation_date"] = f"gte.{start}"
        if not include_test:
            params["is_test"] = "eq.false"
        if market != "all":
            params["market"] = f"eq.{market}"
        if source_type != "all":
            params["source_type"] = f"eq.{source_type}"
        data = await self._request("GET", "model_snapshots", params=params)
        if not isinstance(data, list):
            raise PerformanceStorageError("Model snapshot database returned an invalid response")
        return data

    async def performance_dashboard(
        self,
        *,
        days: int | None,
        market: str,
        source_type: str,
    ) -> dict[str, Any]:
        rows = await self.list_snapshots(days=days, market=market, source_type=source_type, limit=5000)
        current = await self.active_weights()
        return {
            "range_days": days,
            "market": market,
            "source_type": source_type,
            "summary": summarize_rows(rows),
            "by_market": _bucket(rows, lambda row: row.get("market") or "unknown"),
            "by_confidence": _bucket(rows, lambda row: confidence_band(row.get("confidence"))),
            "by_source": _bucket(rows, lambda row: row.get("source_type") or "unknown"),
            "by_publication_mode": _bucket(
                rows,
                lambda row: (
                    (row.get("publication_snapshot") or {}).get("mode")
                    or "ai_auto"
                ),
            ),
            "calibration": calibration_suggestions(rows, current),
            "active_weights": normalize_weights(current),
            "updated_at": iso_utc(),
        }

    async def active_profile(self) -> dict[str, Any] | None:
        data = await self._request(
            "GET",
            "model_weight_profiles",
            params={"select": "*", "status": "eq.active", "order": "activated_at.desc", "limit": 1},
        )
        if not isinstance(data, list):
            raise PerformanceStorageError("Weight profile database returned an invalid response")
        return data[0] if data else None

    async def active_weights(self) -> dict[str, float]:
        profile = await self.active_profile()
        return normalize_weights((profile or {}).get("weights"))

    async def activate_weights(self, *, weights: dict[str, Any], actor_id: str, note: str | None) -> dict[str, Any]:
        normalized = normalize_weights(weights)
        now = iso_utc()
        await self._request(
            "PATCH",
            "model_weight_profiles",
            params={"status": "eq.active"},
            headers={"Prefer": "return=minimal"},
            json={"status": "superseded"},
        )
        data = await self._request(
            "POST",
            "model_weight_profiles",
            headers={"Prefer": "return=representation"},
            json={
                "weights": normalized,
                "status": "active",
                "note": note,
                "created_by": actor_id,
                "activated_at": now,
            },
        )
        if not isinstance(data, list) or not data:
            raise PerformanceStorageError("New weight profile could not be activated")
        return data[0]

    async def create_test_snapshot(self, payload: dict[str, Any]) -> dict[str, Any]:
        selection = {
            "candidate_id": f"test:{uuid4().hex}",
            "game_pk": payload.get("game_pk") or 0,
            "market": payload.get("market"),
            "pick": {
                "market": payload.get("market"),
                "side": payload.get("pick_side"),
                "line": payload.get("line"),
                "team_id": 1 if payload.get("pick_side") == "away" else 2 if payload.get("pick_side") == "home" else None,
                "label": payload.get("pick_label") or "測試推薦",
            },
            "confidence": payload.get("confidence"),
            "data_quality": payload.get("data_quality"),
            "model_version": "dm-test-settlement-v1",
            "engine": {"weights": payload.get("weights") or DEFAULT_MODEL_WEIGHTS},
            "analysis_groups": payload.get("analysis_groups") or {},
            "factors": payload.get("factors") or [],
            "game": {
                "game_pk": payload.get("game_pk") or 0,
                "away": {"id": 1, "abbr": "AWY"},
                "home": {"id": 2, "abbr": "HME"},
            },
        }
        result = payload.get("result") or {}
        row = snapshot_payload(
            source_type="test",
            source_record_id=f"test-{uuid4().hex}",
            recommendation_date=str(payload.get("recommendation_date") or date.today().isoformat()),
            selection=selection,
            fallback_id="test",
            is_test=True,
            status=str(result.get("status") or "pending"),
            result=result,
        )
        inserted = await self.insert_snapshots([row])
        return inserted[0] if inserted else row
