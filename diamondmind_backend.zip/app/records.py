from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

import httpx

from .config import Settings


class RecordsStorageError(RuntimeError):
    """Raised when the private records store cannot complete an operation."""


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def build_record_payload(recommendation_date: str, selection: dict[str, Any]) -> dict[str, Any]:
    game = selection.get("game") or {}
    away = game.get("away") or {}
    home = game.get("home") or {}
    pick = selection.get("pick") or {}
    opponent = selection.get("opponent") or {}

    required = {
        "game_pk": selection.get("game_pk"),
        "game_datetime": selection.get("game_date"),
        "away_team_id": away.get("id"),
        "away_team_name": away.get("name"),
        "away_team_abbr": away.get("abbr"),
        "home_team_id": home.get("id"),
        "home_team_name": home.get("name"),
        "home_team_abbr": home.get("abbr"),
        "pick_team_id": pick.get("team_id"),
        "pick_team_name": pick.get("team_name"),
        "pick_team_abbr": pick.get("abbr"),
        "pick_label": pick.get("label"),
    }
    missing = [name for name, value in required.items() if value is None or value == ""]
    if missing:
        raise RecordsStorageError("Prediction is missing fields required for storage")

    return {
        "recommendation_date": recommendation_date,
        **required,
        "time_taiwan": selection.get("time_taiwan"),
        "matchup": selection.get("matchup") or f'{away.get("abbr")} @ {home.get("abbr")}',
        "venue": game.get("venue"),
        "opponent_team_id": opponent.get("team_id"),
        "opponent_team_name": opponent.get("team_name"),
        "opponent_team_abbr": opponent.get("abbr"),
        "market": pick.get("market") or "moneyline",
        "confidence": selection.get("confidence"),
        "home_probability": selection.get("home_probability"),
        "away_probability": selection.get("away_probability"),
        "data_quality": selection.get("data_quality"),
        "factors": selection.get("factors") or [],
        "summary": selection.get("summary"),
        "model_version": selection.get("model_version"),
        "prediction_snapshot": selection,
        "is_public": True,
    }


def settlement_for(record: dict[str, Any], game: dict[str, Any]) -> dict[str, Any] | None:
    if game.get("status") != "final":
        return None

    away = game.get("away") or {}
    home = game.get("home") or {}
    away_score = away.get("score")
    home_score = home.get("score")
    pick_team_id = record.get("pick_team_id")
    if away_score is None or home_score is None or pick_team_id not in {away.get("id"), home.get("id")}:
        return None

    if away_score == home_score:
        status = "push"
        note = "終場平手，推薦結果走水。"
    else:
        winner_id = away.get("id") if away_score > home_score else home.get("id")
        status = "won" if pick_team_id == winner_id else "lost"
        note = "推薦命中。" if status == "won" else "推薦未中。"

    return {
        "status": status,
        "away_score": away_score,
        "home_score": home_score,
        "result_note": note,
        "settled_at": _utc_now(),
    }


def summarize_records(items: list[dict[str, Any]]) -> dict[str, Any]:
    won = sum(item.get("status") == "won" for item in items)
    lost = sum(item.get("status") == "lost" for item in items)
    push = sum(item.get("status") == "push" for item in items)
    void = sum(item.get("status") == "void" for item in items)
    pending = sum(item.get("status") == "pending" for item in items)
    decisions = won + lost
    return {
        "total": len(items),
        "settled": len(items) - pending,
        "won": won,
        "lost": lost,
        "push": push,
        "void": void,
        "pending": pending,
        "hit_rate": round(won / decisions * 100, 1) if decisions else None,
    }


def _snapshot_items(value: Any) -> list[dict[str, Any]]:
    if not value:
        return []
    if isinstance(value, list):
        return [item for item in value if isinstance(item, dict)]
    if isinstance(value, dict):
        items = value.get("items")
        if isinstance(items, list):
            return [item for item in items if isinstance(item, dict)]
        return [value]
    return []


def _snapshot_public(value: Any) -> dict[str, Any] | None:
    if isinstance(value, dict) and "items" in value:
        public = value.get("public")
        return public if isinstance(public, dict) else None
    if isinstance(value, dict):
        # V14 stored the public moneyline directly in this column.
        return value
    return None


def _snapshot_wrapper(items: list[dict[str, Any]], **extra: Any) -> dict[str, Any]:
    return {"schema_version": 2, "items": items, **extra}


def build_package_payload(recommendation_date: str, package: dict[str, Any]) -> dict[str, Any]:
    parlays = package.get("parlays") or {}
    return {
        "recommendation_date": recommendation_date,
        # Existing JSONB columns are reused, so V15 requires no SQL migration.
        "moneyline_snapshot": _snapshot_wrapper(
            list(package.get("moneylines") or []),
            public=package.get("moneyline"),
        ),
        "run_line_snapshot": _snapshot_wrapper(list(package.get("run_lines") or [])),
        "totals_snapshot": _snapshot_wrapper(list(package.get("totals") or [])),
        "two_leg_snapshot": _snapshot_wrapper(list(parlays.get("two_leg") or [])),
        "three_leg_snapshot": _snapshot_wrapper(list(parlays.get("three_leg") or [])),
        "candidate_counts": package.get("candidate_counts") or {},
        "thresholds": {
            **(package.get("thresholds") or {}),
            "limits": package.get("limits") or {},
            "publication": package.get("publication") or {},
        },
        "model_version": package.get("model_version") or "dm-markets-v2.0",
        "generated_at": package.get("generated_at") or _utc_now(),
        "is_locked": True,
        "settled": False,
        "results": {},
    }


def package_from_record(record: dict[str, Any]) -> dict[str, Any]:
    moneyline_raw = record.get("moneyline_snapshot")
    run_line_raw = record.get("run_line_snapshot")
    totals_raw = record.get("totals_snapshot")
    two_leg_raw = record.get("two_leg_snapshot")
    three_leg_raw = record.get("three_leg_snapshot")
    threshold_payload = record.get("thresholds") or {}
    publication = threshold_payload.get("publication") if isinstance(threshold_payload, dict) else {}
    limits = threshold_payload.get("limits") if isinstance(threshold_payload, dict) else {}
    thresholds = {
        key: value
        for key, value in threshold_payload.items()
        if key not in {"publication", "limits"}
    } if isinstance(threshold_payload, dict) else {}

    moneylines = _snapshot_items(moneyline_raw) if isinstance(moneyline_raw, dict) and "items" in moneyline_raw else []
    run_lines = _snapshot_items(run_line_raw)
    totals = _snapshot_items(totals_raw)
    two_leg = _snapshot_items(two_leg_raw)
    three_leg = _snapshot_items(three_leg_raw)
    return {
        "date": record.get("recommendation_date"),
        "published": True,
        "locked": True,
        "generated_at": record.get("generated_at"),
        "locked_at": record.get("locked_at"),
        "moneyline": _snapshot_public(moneyline_raw),
        "moneylines": moneylines,
        "run_lines": run_lines,
        "totals": totals,
        "parlays": {"two_leg": two_leg, "three_leg": three_leg},
        # Singular aliases keep V14 clients readable while the front end updates.
        "run_line": run_lines[0] if run_lines else None,
        "total": totals[0] if totals else None,
        "candidate_counts": record.get("candidate_counts") or {},
        "thresholds": thresholds,
        "limits": limits or {"moneylines": 3, "run_lines": 3, "totals": 3, "two_leg": 2, "three_leg": 1},
        "publication": publication or {},
        "model_version": record.get("model_version"),
        "settled": bool(record.get("settled")),
        "results": record.get("results") or {},
        "record_id": record.get("id"),
        "message": "正式玩法已鎖定，後續盤口更新不會替換公開推薦。",
    }


def settle_market_selection(
    selection: dict[str, Any] | None,
    game: dict[str, Any] | None,
) -> dict[str, Any] | None:
    if not selection or not game or game.get("status") != "final":
        return None

    away = game.get("away") or {}
    home = game.get("home") or {}
    away_score = away.get("score")
    home_score = home.get("score")
    if away_score is None or home_score is None:
        return None

    market = selection.get("market") or (selection.get("pick") or {}).get("market")
    pick = selection.get("pick") or {}
    status: str
    note: str
    if market == "moneyline":
        pick_team_id = pick.get("team_id")
        if pick_team_id not in {away.get("id"), home.get("id")}:
            return None
        if away_score == home_score:
            status, note = "push", "終場平手，獨贏推薦走水。"
        else:
            winner_id = away.get("id") if away_score > home_score else home.get("id")
            status = "won" if pick_team_id == winner_id else "lost"
            note = "推薦命中。" if status == "won" else "推薦未中。"
    elif market == "run_line":
        pick_team_id = pick.get("team_id")
        line = _safe_float(pick.get("line"))
        if line is None:
            return None
        if pick_team_id == away.get("id"):
            adjusted_pick, opponent_score = float(away_score) + line, float(home_score)
        elif pick_team_id == home.get("id"):
            adjusted_pick, opponent_score = float(home_score) + line, float(away_score)
        else:
            return None
        if adjusted_pick == opponent_score:
            status, note = "push", "讓分後同分，推薦走水。"
        else:
            status = "won" if adjusted_pick > opponent_score else "lost"
            note = "讓分推薦命中。" if status == "won" else "讓分推薦未中。"
    elif market == "totals":
        line = _safe_float(pick.get("line"))
        side = str(pick.get("side") or "").lower()
        if line is None or side not in {"over", "under"}:
            return None
        actual_total = float(away_score) + float(home_score)
        if actual_total == line:
            status, note = "push", "終場總分等於盤口，推薦走水。"
        else:
            over_won = actual_total > line
            status = "won" if (side == "over") == over_won else "lost"
            note = "大小分推薦命中。" if status == "won" else "大小分推薦未中。"
    else:
        return None

    return {
        "candidate_id": selection.get("candidate_id"),
        "status": status,
        "away_score": away_score,
        "home_score": home_score,
        "result_note": note,
        "settled_at": _utc_now(),
    }


def _safe_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _parlay_result(
    parlay: dict[str, Any] | None,
    games: dict[int, dict[str, Any]],
) -> dict[str, Any] | None:
    if not parlay:
        return None
    leg_results = []
    for leg in parlay.get("legs") or []:
        try:
            game = games.get(int(leg.get("game_pk")))
        except (TypeError, ValueError):
            game = None
        result = settle_market_selection(leg, game)
        if result is None:
            return None
        leg_results.append({"game_pk": leg.get("game_pk"), "market": leg.get("market"), **result})

    statuses = [item["status"] for item in leg_results]
    if "lost" in statuses:
        status = "lost"
    elif "won" in statuses:
        status = "won"
    else:
        status = "push"
    return {
        "candidate_id": parlay.get("candidate_id"),
        "status": status,
        "legs": leg_results,
        "settled_at": _utc_now(),
    }


def settle_prediction_package(
    record: dict[str, Any],
    games: dict[int, dict[str, Any]],
) -> dict[str, Any] | None:
    package = package_from_record(record)
    products = {
        "moneylines": package.get("moneylines") or [],
        "run_lines": package.get("run_lines") or [],
        "totals": package.get("totals") or [],
    }
    results: dict[str, Any] = {}
    for key, selections in products.items():
        group_results = []
        for selection in selections:
            try:
                game = games.get(int(selection.get("game_pk")))
            except (TypeError, ValueError):
                game = None
            result = settle_market_selection(selection, game)
            if result is None:
                return None
            group_results.append(result)
        if group_results:
            results[key] = group_results

    for key in ("two_leg", "three_leg"):
        group_results = []
        for parlay in (package.get("parlays") or {}).get(key) or []:
            result = _parlay_result(parlay, games)
            if result is None:
                return None
            group_results.append(result)
        if group_results:
            results[key] = group_results

    if not results:
        return None
    return {"settled": True, "results": results, "settled_at": _utc_now()}


class SupabaseRecordsRepository:
    def __init__(
        self,
        settings: Settings,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self.settings = settings
        self.enabled = settings.records_enabled
        key = settings.supabase_secret_key
        headers = {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "User-Agent": "DiamondMind-Server/10.1",
        }
        if key:
            headers["apikey"] = key
            # Legacy service_role keys are JWTs and still require a Bearer header.
            # New sb_secret_ keys are deliberately sent only through apikey.
            if not key.startswith("sb_secret_"):
                headers["Authorization"] = f"Bearer {key}"

        base_url = (
            f"{settings.supabase_url}/rest/v1/"
            if settings.supabase_url
            else "https://records.invalid/rest/v1/"
        )
        self.client = httpx.AsyncClient(
            base_url=base_url,
            headers=headers,
            timeout=settings.request_timeout_seconds,
            follow_redirects=True,
            trust_env=False,
            transport=transport,
        )

    async def aclose(self) -> None:
        await self.client.aclose()

    def _require_enabled(self) -> None:
        if not self.enabled:
            raise RecordsStorageError("Recommendation database is not configured")

    async def _request(self, method: str, path: str, **kwargs: Any) -> Any:
        self._require_enabled()
        try:
            response = await self.client.request(method, path, **kwargs)
            response.raise_for_status()
            if not response.content:
                return None
            return response.json()
        except (httpx.HTTPError, ValueError) as exc:
            raise RecordsStorageError("Recommendation database is temporarily unavailable") from exc

    async def get_record_for_date(
        self,
        recommendation_date: str,
    ) -> dict[str, Any] | None:
        data = await self._request(
            "GET",
            "recommendations",
            params={
                "select": "*",
                "recommendation_date": f"eq.{recommendation_date}",
                "limit": 1,
            },
        )
        if not isinstance(data, list):
            raise RecordsStorageError("Recommendation database returned an invalid response")
        return data[0] if data else None

    async def get_prediction_package_for_date(
        self,
        recommendation_date: str,
    ) -> dict[str, Any] | None:
        data = await self._request(
            "GET",
            "prediction_packages",
            params={
                "select": "*",
                "recommendation_date": f"eq.{recommendation_date}",
                "limit": 1,
            },
        )
        if not isinstance(data, list):
            raise RecordsStorageError("Prediction package database returned an invalid response")
        return data[0] if data else None

    async def publish_prediction_package_once(
        self,
        recommendation_date: str,
        package: dict[str, Any],
    ) -> tuple[dict[str, Any], bool]:
        payload = build_package_payload(recommendation_date, package)
        data = await self._request(
            "POST",
            "prediction_packages",
            params={"on_conflict": "recommendation_date"},
            headers={"Prefer": "resolution=ignore-duplicates,return=representation"},
            json=payload,
        )
        if not isinstance(data, list):
            raise RecordsStorageError("Prediction package database returned an invalid response")
        if data:
            return data[0], True
        existing = await self.get_prediction_package_for_date(recommendation_date)
        if not existing:
            raise RecordsStorageError("Locked prediction package could not be loaded")
        return existing, False

    async def list_pending_prediction_packages(self) -> list[dict[str, Any]]:
        data = await self._request(
            "GET",
            "prediction_packages",
            params={"select": "*", "settled": "eq.false", "order": "recommendation_date.asc"},
        )
        if not isinstance(data, list):
            raise RecordsStorageError("Prediction package database returned an invalid response")
        return data

    async def list_settled_prediction_packages(
        self,
        *,
        limit: int | None = None,
    ) -> list[dict[str, Any]]:
        """Load only completed packages that are safe for the public history.

        Current or future paid selections must never be exposed by the public
        records endpoint. Requiring ``settled=true`` at the database query is
        the primary guard; the API performs the same check again before
        serializing a row.
        """

        data = await self._request(
            "GET",
            "prediction_packages",
            params={
                "select": "*",
                "settled": "eq.true",
                "order": "recommendation_date.desc,generated_at.desc",
                "limit": limit or self.settings.records_limit,
            },
        )
        if not isinstance(data, list):
            raise RecordsStorageError("Prediction package database returned an invalid response")
        return [item for item in data if item.get("settled") is True]

    async def settle_prediction_package(
        self,
        package_id: str,
        result: dict[str, Any],
    ) -> dict[str, Any] | None:
        data = await self._request(
            "PATCH",
            "prediction_packages",
            params={"id": f"eq.{package_id}", "settled": "eq.false"},
            headers={"Prefer": "return=representation"},
            json=result,
        )
        if isinstance(data, list) and data:
            return data[0]
        return None

    async def publish_prediction_once(
        self,
        recommendation_date: str,
        selection: dict[str, Any],
    ) -> tuple[dict[str, Any], bool]:
        """Insert the first public pick for a date and never overwrite it.

        Supabase's unique recommendation_date constraint makes this atomic.
        A simultaneous later request receives the already-published record,
        preserving a verifiable public history.
        """

        payload = build_record_payload(recommendation_date, selection)
        data = await self._request(
            "POST",
            "recommendations",
            params={"on_conflict": "recommendation_date"},
            headers={"Prefer": "resolution=ignore-duplicates,return=representation"},
            json=payload,
        )
        if not isinstance(data, list):
            raise RecordsStorageError("Recommendation database returned an invalid response")
        if data:
            return data[0], True

        existing = await self.get_record_for_date(recommendation_date)
        if not existing:
            raise RecordsStorageError("Published recommendation could not be loaded")
        return existing, False

    async def upsert_prediction(
        self,
        recommendation_date: str,
        selection: dict[str, Any],
    ) -> dict[str, Any]:
        """Compatibility wrapper; public recommendations are now immutable."""

        record, _ = await self.publish_prediction_once(recommendation_date, selection)
        return record

    async def list_records(
        self,
        *,
        status: str | None = None,
        limit: int | None = None,
    ) -> list[dict[str, Any]]:
        params: dict[str, Any] = {
            "select": "*",
            "order": "recommendation_date.desc,published_at.desc",
            "limit": limit or self.settings.records_limit,
        }
        if status:
            params["status"] = f"eq.{status}"
        data = await self._request("GET", "recommendations", params=params)
        if not isinstance(data, list):
            raise RecordsStorageError("Recommendation database returned an invalid response")
        return data

    async def settle(self, game_pk: int, result: dict[str, Any]) -> dict[str, Any] | None:
        data = await self._request(
            "PATCH",
            "recommendations",
            params={"game_pk": f"eq.{game_pk}", "status": "eq.pending"},
            headers={"Prefer": "return=representation"},
            json=result,
        )
        if isinstance(data, list) and data:
            return data[0]
        return None
