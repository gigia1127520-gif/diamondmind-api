from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

import httpx

from .config import Settings


class RecordsStorageError(RuntimeError):
    """Raised when the private records store cannot complete an operation."""


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def build_record_payload(recommendation_date: str, selection: dict[str, Any]) -> dict[str, Any]:
    game = selection.get("game") or {}
    away = game.get("away") or {}
    home = game.get("home") or {}
    pick = selection.get("pick") or {}
    opponent = selection.get("opponent") or {}

    required = {
        "game_pk": selection.get("game_pk"),
        "game_datetime": selection.get("game_date"),
        "away_team_id": away.get("id"),
        "away_team_name": away.get("name"),
        "away_team_abbr": away.get("abbr"),
        "home_team_id": home.get("id"),
        "home_team_name": home.get("name"),
        "home_team_abbr": home.get("abbr"),
        "pick_team_id": pick.get("team_id"),
        "pick_team_name": pick.get("team_name"),
        "pick_team_abbr": pick.get("abbr"),
        "pick_label": pick.get("label"),
    }
    missing = [name for name, value in required.items() if value is None or value == ""]
    if missing:
        raise RecordsStorageError("Prediction is missing fields required for storage")

    return {
        "recommendation_date": recommendation_date,
        **required,
        "time_taiwan": selection.get("time_taiwan"),
        "matchup": selection.get("matchup") or f'{away.get("abbr")} @ {home.get("abbr")}',
        "venue": game.get("venue"),
        "opponent_team_id": opponent.get("team_id"),
        "opponent_team_name": opponent.get("team_name"),
        "opponent_team_abbr": opponent.get("abbr"),
        "market": pick.get("market") or "moneyline",
        "confidence": selection.get("confidence"),
        "home_probability": selection.get("home_probability"),
        "away_probability": selection.get("away_probability"),
        "data_quality": selection.get("data_quality"),
        "factors": selection.get("factors") or [],
        "summary": selection.get("summary"),
        "model_version": selection.get("model_version"),
        "prediction_snapshot": selection,
        "is_public": True,
    }


def settlement_for(record: dict[str, Any], game: dict[str, Any]) -> dict[str, Any] | None:
    if game.get("status") != "final":
        return None

    away = game.get("away") or {}
    home = game.get("home") or {}
    away_score = away.get("score")
    home_score = home.get("score")
    pick_team_id = record.get("pick_team_id")
    if away_score is None or home_score is None or pick_team_id not in {away.get("id"), home.get("id")}:
        return None

    if away_score == home_score:
        status = "push"
        note = "終場平手，推薦結果走水。"
    else:
        winner_id = away.get("id") if away_score > home_score else home.get("id")
        status = "won" if pick_team_id == winner_id else "lost"
        note = "推薦命中。" if status == "won" else "推薦未中。"

    return {
        "status": status,
        "away_score": away_score,
        "home_score": home_score,
        "result_note": note,
        "settled_at": _utc_now(),
    }


def summarize_records(items: list[dict[str, Any]]) -> dict[str, Any]:
    won = sum(item.get("status") == "won" for item in items)
    lost = sum(item.get("status") == "lost" for item in items)
    push = sum(item.get("status") == "push" for item in items)
    void = sum(item.get("status") == "void" for item in items)
    pending = sum(item.get("status") == "pending" for item in items)
    decisions = won + lost
    return {
        "total": len(items),
        "settled": len(items) - pending,
        "won": won,
        "lost": lost,
        "push": push,
        "void": void,
        "pending": pending,
        "hit_rate": round(won / decisions * 100, 1) if decisions else None,
    }


class SupabaseRecordsRepository:
    def __init__(
        self,
        settings: Settings,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self.settings = settings
        self.enabled = settings.records_enabled
        key = settings.supabase_secret_key
        headers = {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "User-Agent": "DiamondMind-Server/10.1",
        }
        if key:
            headers["apikey"] = key
            # Legacy service_role keys are JWTs and still require a Bearer header.
            # New sb_secret_ keys are deliberately sent only through apikey.
            if not key.startswith("sb_secret_"):
                headers["Authorization"] = f"Bearer {key}"

        base_url = (
            f"{settings.supabase_url}/rest/v1/"
            if settings.supabase_url
            else "https://records.invalid/rest/v1/"
        )
        self.client = httpx.AsyncClient(
            base_url=base_url,
            headers=headers,
            timeout=settings.request_timeout_seconds,
            follow_redirects=True,
            trust_env=False,
            transport=transport,
        )

    async def aclose(self) -> None:
        await self.client.aclose()

    def _require_enabled(self) -> None:
        if not self.enabled:
            raise RecordsStorageError("Recommendation database is not configured")

    async def _request(self, method: str, path: str, **kwargs: Any) -> Any:
        self._require_enabled()
        try:
            response = await self.client.request(method, path, **kwargs)
            response.raise_for_status()
            if not response.content:
                return None
            return response.json()
        except (httpx.HTTPError, ValueError) as exc:
            raise RecordsStorageError("Recommendation database is temporarily unavailable") from exc

    async def upsert_prediction(
        self,
        recommendation_date: str,
        selection: dict[str, Any],
    ) -> dict[str, Any]:
        payload = build_record_payload(recommendation_date, selection)
        data = await self._request(
            "POST",
            "recommendations",
            params={"on_conflict": "recommendation_date"},
            headers={"Prefer": "resolution=merge-duplicates,return=representation"},
            json=payload,
        )
        if not isinstance(data, list) or not data:
            raise RecordsStorageError("Recommendation database returned an invalid response")
        return data[0]

    async def list_records(
        self,
        *,
        status: str | None = None,
        limit: int | None = None,
    ) -> list[dict[str, Any]]:
        params: dict[str, Any] = {
            "select": "*",
            "order": "recommendation_date.desc,published_at.desc",
            "limit": limit or self.settings.records_limit,
        }
        if status:
            params["status"] = f"eq.{status}"
        data = await self._request("GET", "recommendations", params=params)
        if not isinstance(data, list):
            raise RecordsStorageError("Recommendation database returned an invalid response")
        return data

    async def settle(self, game_pk: int, result: dict[str, Any]) -> dict[str, Any] | None:
        data = await self._request(
            "PATCH",
            "recommendations",
            params={"game_pk": f"eq.{game_pk}", "status": "eq.pending"},
            headers={"Prefer": "return=representation"},
            json=result,
        )
        if isinstance(data, list) and data:
            return data[0]
        return None
