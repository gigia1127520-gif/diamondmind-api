from __future__ import annotations

from copy import deepcopy
from datetime import datetime, timedelta, timezone
from typing import Any

import httpx

from .config import Settings


class RecordsStorageError(RuntimeError):
    """Raised when the private records store cannot complete an operation."""


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")

def _game_key(value: Any) -> str:
    return str(value) if value is not None else ""


def recommendation_league(value: dict[str, Any] | None) -> str:
    """Return the storage league for one public recommendation."""

    value = value or {}
    game = value.get("game") or {}
    publication = value.get("publication") or {}
    league = str(
        value.get("league")
        or publication.get("league")
        or game.get("league")
        or "MLB"
    ).upper()
    return league if league in {"MLB", "NPB"} else "MLB"


_VOID_GAME_TERMS = (
    "cancelled", "canceled", "no contest", "forfeit", "forfeited",
)
_PENDING_GAME_TERMS = (
    "postponed", "suspended", "delayed", "rainout", "warmup", "pre-game", "scheduled",
)
_TERMINAL_RESULT_STATUSES = {"won", "lost", "push", "void"}
_RESCHEDULED_GAME_THRESHOLD = timedelta(hours=12)


def _settlement_datetime(value: Any) -> datetime | None:
    """Parse a stored/API game time into an aware UTC datetime."""

    if isinstance(value, datetime):
        parsed = value
    else:
        text = str(value or "").strip()
        if not text:
            return None
        try:
            parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
        except ValueError:
            return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def _original_game_datetime(selection: dict[str, Any] | None) -> datetime | None:
    """Return the immutable start time saved when the recommendation published."""

    selection = selection or {}
    snapshot = selection.get("prediction_snapshot") or {}
    nested_game = selection.get("game") or {}
    snapshot_game = snapshot.get("game") or {} if isinstance(snapshot, dict) else {}
    for value in (
        selection.get("game_datetime"),
        selection.get("game_date"),
        snapshot.get("game_datetime") if isinstance(snapshot, dict) else None,
        snapshot.get("game_date") if isinstance(snapshot, dict) else None,
        nested_game.get("game_date") if isinstance(nested_game, dict) else None,
        snapshot_game.get("game_date") if isinstance(snapshot_game, dict) else None,
    ):
        parsed = _settlement_datetime(value)
        if parsed is not None:
            return parsed
    return None


def game_disposition(game: dict[str, Any] | None) -> str:
    """Return final, void or pending for settlement purposes.

    MLB's abstract state alone is not enough: postponed games can be reported
    as Final before MLB attaches their replacement start time.  Postponed,
    rain-delayed and suspended games therefore remain pending; only an explicit
    cancellation, no-contest or forfeit can void a recommendation.
    """

    game = game or {}
    override = str(game.get("settlement_disposition") or "").strip().lower()
    if override in {"final", "void", "pending"}:
        return override
    status = str(game.get("status") or "").lower()
    detailed = str(game.get("detailed_status") or "").strip().lower()
    reason = str(game.get("status_reason") or "").strip().lower()
    official_state = f"{detailed} {reason}".strip()
    # An explicit cancellation/no-contest/forfeit is terminal even when its
    # reason also mentions rain.  Otherwise rainouts and postponements stay
    # open until MLB publishes a replacement or a genuinely terminal state.
    if any(term in official_state for term in _VOID_GAME_TERMS):
        return "void"
    if any(term in official_state for term in _PENDING_GAME_TERMS):
        return "pending"
    if status == "final":
        return "final"
    return "pending"


def settlement_game_disposition(
    selection: dict[str, Any] | None,
    game: dict[str, Any] | None,
) -> str:
    """Return the disposition for the exact event that was published.

    MLB can retain one ``gamePk`` after moving a postponed game to the next
    day.  Looking up only that id then returns the makeup game's final score and
    silently applies it to bets published for the original start time.  The
    publication snapshot is immutable, so a final whose official start moved
    by at least 12 hours is a different settlement event and the original
    market is void.  Short same-day delays remain attached to the original
    event.
    """

    disposition = game_disposition(game)
    if disposition != "final":
        return disposition
    original_start = _original_game_datetime(selection)
    result_start = _settlement_datetime((game or {}).get("game_date"))
    if (
        original_start is not None
        and result_start is not None
        and result_start - original_start >= _RESCHEDULED_GAME_THRESHOLD
    ):
        return "void"
    return disposition


def result_status_matches_disposition(result_status: Any, disposition: str) -> bool:
    """Return whether a stored terminal result agrees with official state."""

    status = str(result_status or "pending").lower()
    if disposition == "pending":
        return status == "pending"
    if disposition == "void":
        return status == "void"
    if disposition == "final":
        return status in {"won", "lost", "push"}
    return status == "pending"


def _void_result(*, candidate_id: Any = None, detailed_status: str = "") -> dict[str, Any]:
    note = "賽事已正式取消或裁定無效，推薦作廢。"
    if detailed_status:
        note = f"賽事正式狀態：{detailed_status}，推薦作廢。"
    return {
        "candidate_id": candidate_id,
        "status": "void",
        "away_score": None,
        "home_score": None,
        "result_note": note,
        "settled_at": _utc_now(),
    }


def _void_status_detail(
    selection: dict[str, Any] | None,
    game: dict[str, Any] | None,
) -> str:
    if (
        game_disposition(game) == "final"
        and settlement_game_disposition(selection, game) == "void"
    ):
        return "原場延期並改期，不套用補賽結果"
    return str((game or {}).get("detailed_status") or "")


def build_record_payload(recommendation_date: str, selection: dict[str, Any]) -> dict[str, Any]:
    game = selection.get("game") or {}
    away = game.get("away") or {}
    home = game.get("home") or {}
    pick = selection.get("pick") or {}
    opponent = selection.get("opponent") or {}

    required = {
        "game_pk": selection.get("game_pk"),
        "game_datetime": selection.get("game_date"),
        "away_team_id": away.get("id"),
        "away_team_name": away.get("name"),
        "away_team_abbr": away.get("abbr"),
        "home_team_id": home.get("id"),
        "home_team_name": home.get("name"),
        "home_team_abbr": home.get("abbr"),
        "pick_team_id": pick.get("team_id"),
        "pick_team_name": pick.get("team_name"),
        "pick_team_abbr": pick.get("abbr"),
        "pick_label": pick.get("label"),
    }
    missing = [name for name, value in required.items() if value is None or value == ""]
    if missing:
        raise RecordsStorageError("Prediction is missing fields required for storage")

    return {
        "recommendation_date": recommendation_date,
        "league": recommendation_league(selection),
        **required,
        "time_taiwan": selection.get("time_taiwan"),
        "matchup": selection.get("matchup") or f'{away.get("abbr")} @ {home.get("abbr")}',
        "venue": game.get("venue"),
        "opponent_team_id": opponent.get("team_id"),
        "opponent_team_name": opponent.get("team_name"),
        "opponent_team_abbr": opponent.get("abbr"),
        "market": pick.get("market") or "moneyline",
        "confidence": selection.get("confidence"),
        "home_probability": selection.get("home_probability"),
        "away_probability": selection.get("away_probability"),
        "data_quality": selection.get("data_quality"),
        "factors": selection.get("factors") or [],
        "summary": selection.get("summary"),
        "model_version": selection.get("model_version"),
        "prediction_snapshot": selection,
        "is_public": True,
    }


def settlement_for(record: dict[str, Any], game: dict[str, Any]) -> dict[str, Any] | None:
    disposition = settlement_game_disposition(record, game)
    if disposition == "pending":
        return None
    if disposition == "void":
        result = _void_result(detailed_status=_void_status_detail(record, game))
        result.pop("candidate_id", None)
        return result

    away = game.get("away") or {}
    home = game.get("home") or {}
    away_score = away.get("score")
    home_score = home.get("score")
    pick_team_id = record.get("pick_team_id")
    if away_score is None or home_score is None or pick_team_id not in {away.get("id"), home.get("id")}:
        return None

    if away_score == home_score:
        status = "push"
        note = "終場平手，推薦結果走水。"
    else:
        winner_id = away.get("id") if away_score > home_score else home.get("id")
        status = "won" if pick_team_id == winner_id else "lost"
        note = "推薦命中。" if status == "won" else "推薦未中。"

    return {
        "status": status,
        "away_score": away_score,
        "home_score": home_score,
        "result_note": note,
        "settled_at": _utc_now(),
    }


def summarize_records(items: list[dict[str, Any]]) -> dict[str, Any]:
    won = sum(item.get("status") == "won" for item in items)
    lost = sum(item.get("status") == "lost" for item in items)
    push = sum(item.get("status") == "push" for item in items)
    void = sum(item.get("status") == "void" for item in items)
    pending = sum(item.get("status") == "pending" for item in items)
    decisions = won + lost
    return {
        "total": len(items),
        "settled": len(items) - pending,
        "won": won,
        "lost": lost,
        "push": push,
        "void": void,
        "pending": pending,
        "hit_rate": round(won / decisions * 100, 1) if decisions else None,
    }


def _snapshot_items(value: Any) -> list[dict[str, Any]]:
    if not value:
        return []
    if isinstance(value, list):
        return [item for item in value if isinstance(item, dict)]
    if isinstance(value, dict):
        items = value.get("items")
        if isinstance(items, list):
            return [item for item in items if isinstance(item, dict)]
        return [value]
    return []


def _snapshot_public(value: Any) -> dict[str, Any] | None:
    if isinstance(value, dict) and "items" in value:
        public = value.get("public")
        return public if isinstance(public, dict) else None
    if isinstance(value, dict):
        # V14 stored the public moneyline directly in this column.
        return value
    return None


def _snapshot_wrapper(items: list[dict[str, Any]], **extra: Any) -> dict[str, Any]:
    return {"schema_version": 2, "items": items, **extra}


def build_package_payload(recommendation_date: str, package: dict[str, Any]) -> dict[str, Any]:
    parlays = package.get("parlays") or {}
    generated_at = package.get("generated_at") or _utc_now()
    publication = {
        **(package.get("publication") or {}),
    }
    publication.setdefault("target_date", recommendation_date)
    publication.setdefault("published_at", generated_at)
    publication.setdefault("status", "published")
    publication.setdefault("is_active", True)
    publication.setdefault("recommendation_type", "pro")
    return {
        "recommendation_date": recommendation_date,
        # Existing JSONB columns are reused, so V15 requires no SQL migration.
        "moneyline_snapshot": _snapshot_wrapper(
            list(package.get("moneylines") or []),
            public=package.get("moneyline"),
        ),
        "run_line_snapshot": _snapshot_wrapper(list(package.get("run_lines") or [])),
        "totals_snapshot": _snapshot_wrapper(list(package.get("totals") or [])),
        "two_leg_snapshot": _snapshot_wrapper(list(parlays.get("two_leg") or [])),
        "three_leg_snapshot": _snapshot_wrapper(list(parlays.get("three_leg") or [])),
        "candidate_counts": package.get("candidate_counts") or {},
        "thresholds": {
            **(package.get("thresholds") or {}),
            "limits": package.get("limits") or {},
            "publication": publication,
            "watchlist": package.get("watchlist") or {},
            "recommendation_status": package.get("recommendation_status") or "formal_published",
        },
        "model_version": package.get("model_version") or "dm-markets-v3.1",
        "generated_at": generated_at,
        "is_locked": True,
        "settled": False,
        "results": {},
    }


def package_from_record(record: dict[str, Any]) -> dict[str, Any]:
    moneyline_raw = record.get("moneyline_snapshot")
    run_line_raw = record.get("run_line_snapshot")
    totals_raw = record.get("totals_snapshot")
    two_leg_raw = record.get("two_leg_snapshot")
    three_leg_raw = record.get("three_leg_snapshot")
    threshold_payload = record.get("thresholds") or {}
    publication = threshold_payload.get("publication") if isinstance(threshold_payload, dict) else {}
    limits = threshold_payload.get("limits") if isinstance(threshold_payload, dict) else {}
    watchlist = threshold_payload.get("watchlist") if isinstance(threshold_payload, dict) else {}
    recommendation_status = (
        threshold_payload.get("recommendation_status")
        if isinstance(threshold_payload, dict)
        else "formal_published"
    )
    thresholds = {
        key: value
        for key, value in threshold_payload.items()
        if key not in {"publication", "limits", "watchlist", "recommendation_status"}
    } if isinstance(threshold_payload, dict) else {}

    moneylines = _snapshot_items(moneyline_raw) if isinstance(moneyline_raw, dict) and "items" in moneyline_raw else []
    run_lines = _snapshot_items(run_line_raw)
    totals = _snapshot_items(totals_raw)
    two_leg = _snapshot_items(two_leg_raw)
    three_leg = _snapshot_items(three_leg_raw)
    return {
        "date": record.get("recommendation_date"),
        "target_date": publication.get("target_date") or record.get("recommendation_date"),
        "published": True,
        "locked": True,
        "generated_at": record.get("generated_at"),
        "published_at": publication.get("published_at") or record.get("generated_at"),
        "locked_at": record.get("locked_at"),
        "moneyline": _snapshot_public(moneyline_raw),
        "moneylines": moneylines,
        "run_lines": run_lines,
        "totals": totals,
        "parlays": {"two_leg": two_leg, "three_leg": three_leg},
        "watchlist": watchlist if isinstance(watchlist, dict) else {},
        "recommendation_status": recommendation_status or "formal_published",
        # Singular aliases keep V14 clients readable while the front end updates.
        "run_line": run_lines[0] if run_lines else None,
        "total": totals[0] if totals else None,
        "candidate_counts": record.get("candidate_counts") or {},
        "thresholds": thresholds,
        "limits": limits or {"moneylines": 3, "run_lines": 3, "totals": 3, "two_leg": 2, "three_leg": 1},
        "publication": publication or {},
        "model_version": record.get("model_version"),
        "settled": bool(record.get("settled")),
        "settled_at": record.get("settled_at"),
        "results": record.get("results") or {},
        "record_id": record.get("id"),
        "message": (
            "正式玩法已鎖定；觀察名單不計入正式戰績。"
            if (recommendation_status or "formal_published") == "formal_published"
            else "今日沒有正式推薦；創辦人觀察名單僅供內部審核。"
        ),
    }


def settle_market_selection(
    selection: dict[str, Any] | None,
    game: dict[str, Any] | None,
) -> dict[str, Any] | None:
    if not selection or not game:
        return None
    disposition = settlement_game_disposition(selection, game)
    if disposition == "pending":
        return None
    if disposition == "void":
        result = _void_result(
            candidate_id=selection.get("candidate_id"),
            detailed_status=_void_status_detail(selection, game),
        )
        result["performance"] = _settlement_performance("void", selection.get("price"))
        return result

    away = game.get("away") or {}
    home = game.get("home") or {}
    away_score = away.get("score")
    home_score = home.get("score")
    if away_score is None or home_score is None:
        return None

    market = selection.get("market") or (selection.get("pick") or {}).get("market")
    pick = selection.get("pick") or {}
    status: str
    note: str
    if market == "moneyline":
        pick_team_id = pick.get("team_id")
        if pick_team_id not in {away.get("id"), home.get("id")}:
            return None
        if away_score == home_score:
            status, note = "push", "終場平手，獨贏推薦走水。"
        else:
            winner_id = away.get("id") if away_score > home_score else home.get("id")
            status = "won" if pick_team_id == winner_id else "lost"
            note = "推薦命中。" if status == "won" else "推薦未中。"
    elif market == "run_line":
        pick_team_id = pick.get("team_id")
        line = _safe_float(pick.get("line"))
        if line is None:
            return None
        if pick_team_id == away.get("id"):
            adjusted_pick, opponent_score = float(away_score) + line, float(home_score)
        elif pick_team_id == home.get("id"):
            adjusted_pick, opponent_score = float(home_score) + line, float(away_score)
        else:
            return None
        if adjusted_pick == opponent_score:
            status, note = "push", "讓分後同分，推薦走水。"
        else:
            status = "won" if adjusted_pick > opponent_score else "lost"
            note = "讓分推薦命中。" if status == "won" else "讓分推薦未中。"
    elif market == "totals":
        line = _safe_float(pick.get("line"))
        side = str(pick.get("side") or "").lower()
        if line is None or side not in {"over", "under"}:
            return None
        actual_total = float(away_score) + float(home_score)
        if actual_total == line:
            status, note = "push", "終場總分等於盤口，推薦走水。"
        else:
            over_won = actual_total > line
            status = "won" if (side == "over") == over_won else "lost"
            note = "大小分推薦命中。" if status == "won" else "大小分推薦未中。"
    else:
        return None

    return {
        "candidate_id": selection.get("candidate_id"),
        "status": status,
        "away_score": away_score,
        "home_score": home_score,
        "result_note": note,
        "settled_at": _utc_now(),
        "performance": _settlement_performance(status, selection.get("price")),
    }


def _safe_float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _decimal_odds(value: Any) -> float | None:
    price = _safe_float(value)
    if price is None or price == 0:
        return None
    if 1.0 < price < 20.0 and not float(price).is_integer():
        return price
    if price >= 100:
        return 1.0 + price / 100.0
    if price <= -100:
        return 1.0 + 100.0 / abs(price)
    return None


def _american_odds(decimal_odds: float | None) -> float | None:
    if decimal_odds is None or decimal_odds <= 1:
        return None
    if decimal_odds >= 2:
        return round((decimal_odds - 1) * 100, 2)
    return round(-100 / (decimal_odds - 1), 2)


def _settlement_performance(status: str, price: Any) -> dict[str, Any]:
    decimal = _decimal_odds(price)
    payload = {
        "unit_basis": 1.0,
        "american_odds": _safe_float(price),
        "decimal_odds": round(decimal, 6) if decimal is not None else None,
        "stake_units": 0.0,
        "return_units": 0.0,
        "profit_units": None,
        "roi_percent": None,
    }
    if status == "void":
        payload.update({"profit_units": 0.0, "roi_percent": 0.0})
        return payload
    if status not in {"won", "lost", "push"} or decimal is None:
        return payload
    payload["stake_units"] = 1.0
    if status == "won":
        profit = decimal - 1
        payload["return_units"] = decimal
    elif status == "lost":
        profit = -1.0
    else:
        profit = 0.0
        payload["return_units"] = 1.0
    payload["profit_units"] = round(profit, 4)
    payload["roi_percent"] = round(profit * 100, 2)
    return payload


def _parlay_result(
    parlay: dict[str, Any] | None,
    games: dict[str, dict[str, Any]],
) -> dict[str, Any] | None:
    if not parlay:
        return None
    leg_results: list[dict[str, Any]] = []
    pending_exists = False
    for leg in parlay.get("legs") or []:
        game = games.get(_game_key(leg.get("game_pk")))
        result = settle_market_selection(leg, game)
        if result is None:
            pending_exists = True
            leg_results.append({
                "candidate_id": leg.get("candidate_id"),
                "game_pk": leg.get("game_pk"),
                "market": leg.get("market"),
                "status": "pending",
            })
            continue
        leg_results.append({"game_pk": leg.get("game_pk"), "market": leg.get("market"), **result})

    statuses = [item["status"] for item in leg_results]
    if "lost" in statuses:
        # A parlay is already lost as soon as any effective leg loses.  This is
        # true even when another leg is postponed or has not started, and must
        # not depend on which leg happens to appear first in the stored array.
        status = "lost"
        note = "串關至少一腿未中，已判定未中。"
    elif pending_exists:
        # A won leg plus a postponed/rescheduled leg is still open.  If the
        # latter is later cancelled it becomes void and the remaining winning
        # legs determine the reduced parlay result.
        return None
    elif "won" in statuses:
        # Push/void legs are removed; remaining winning legs keep the parlay alive.
        status = "won"
        note = "串關其餘有效腿全部命中。"
    elif statuses and all(value == "void" for value in statuses):
        status = "void"
        note = "串關所有腿均作廢。"
    else:
        status = "push"
        note = "串關有效腿全部走水或作廢。"
    settlement_price: Any = parlay.get("combined_american_odds")
    if status == "won":
        effective_decimal = 1.0
        valid_prices = True
        for leg, result in zip(parlay.get("legs") or [], leg_results):
            if result.get("status") != "won":
                continue
            decimal = _decimal_odds(leg.get("price"))
            if decimal is None:
                valid_prices = False
                break
            effective_decimal *= decimal
        if valid_prices and effective_decimal > 1:
            settlement_price = _american_odds(effective_decimal)
    return {
        "candidate_id": parlay.get("candidate_id"),
        "status": status,
        "legs": leg_results,
        "result_note": note,
        "settled_at": _utc_now(),
        "settlement_price": settlement_price,
        "performance": _settlement_performance(status, settlement_price),
    }


def settle_prediction_package(
    record: dict[str, Any],
    games: dict[str, dict[str, Any]],
) -> dict[str, Any] | None:
    """Settle every completed formal selection without waiting for the whole day.

    A package may contain MLB and NPB games at different start times.  Earlier
    versions withheld the entire package history until the last game finished,
    which made completed MLB picks look unrecorded while a later NPB game was
    still pending.  Results are now persisted incrementally; ``settled`` turns
    true only after every published single and parlay has reached a terminal
    state.
    """

    package = package_from_record(record)
    existing_results = record.get("results") or {}
    results: dict[str, Any] = {
        key: list(value) if isinstance(value, list) else value
        for key, value in existing_results.items()
    }
    pending_exists = False
    expected_count = 0
    resolved_count = 0

    products = {
        "moneylines": package.get("moneylines") or [],
        "run_lines": package.get("run_lines") or [],
        "totals": package.get("totals") or [],
    }
    for key, selections in products.items():
        group_results: list[dict[str, Any]] = []
        previous = {
            str(item.get("candidate_id")): item
            for item in (existing_results.get(key) or [])
            if isinstance(item, dict) and item.get("candidate_id") is not None
        }
        for selection in selections:
            expected_count += 1
            candidate_id = str(selection.get("candidate_id"))
            game = games.get(_game_key(selection.get("game_pk")))
            result = settle_market_selection(selection, game)
            if result is None:
                stored = previous.get(candidate_id)
                if stored and str(stored.get("status")) in {"won", "lost", "push", "void"}:
                    group_results.append(stored)
                    resolved_count += 1
                else:
                    pending_exists = True
                continue
            group_results.append(result)
            resolved_count += 1
        if group_results:
            results[key] = group_results

    for key in ("two_leg", "three_leg"):
        group_results: list[dict[str, Any]] = []
        previous = {
            str(item.get("candidate_id")): item
            for item in (existing_results.get(key) or [])
            if isinstance(item, dict) and item.get("candidate_id") is not None
        }
        for parlay in (package.get("parlays") or {}).get(key) or []:
            expected_count += 1
            candidate_id = str(parlay.get("candidate_id"))
            result = _parlay_result(parlay, games)
            if result is None:
                stored = previous.get(candidate_id)
                if stored and str(stored.get("status")) in {"won", "lost", "push", "void"}:
                    group_results.append(stored)
                    resolved_count += 1
                else:
                    pending_exists = True
                continue
            group_results.append(result)
            resolved_count += 1
        if group_results:
            results[key] = group_results

    if expected_count == 0:
        return None

    fully_settled = not pending_exists and resolved_count == expected_count
    payload: dict[str, Any] = {
        "settled": fully_settled,
        "results": results,
    }
    if fully_settled:
        payload["settled_at"] = _utc_now()
    return payload


def reopen_rescheduled_package_results(
    record: dict[str, Any],
    games: dict[str, dict[str, Any]],
) -> tuple[dict[str, Any], set[str]]:
    """Remove terminal results that conflict with the current official state.

    This repairs both old voids and old wins/losses accidentally created from a
    postponed shell.  A missing upstream game never causes a reopen.  The
    returned candidate ids let the performance snapshot table be reconciled
    with the package row.
    """

    package = package_from_record(record)
    results = deepcopy(record.get("results") or {})
    reopened: set[str] = set()

    def remember(selection: dict[str, Any] | None, result: dict[str, Any]) -> None:
        for value in (
            (selection or {}).get("candidate_id"),
            result.get("candidate_id"),
        ):
            if value is not None and str(value):
                reopened.add(str(value))

    for group in ("moneylines", "run_lines", "totals"):
        selections = [item for item in package.get(group) or [] if isinstance(item, dict)]
        by_id = {
            str(item.get("candidate_id")): item
            for item in selections
            if item.get("candidate_id") is not None
        }
        kept: list[dict[str, Any]] = []
        for index, result in enumerate(results.get(group) or []):
            if not isinstance(result, dict):
                continue
            result_candidate_id = result.get("candidate_id")
            selection = by_id.get(str(result_candidate_id)) if result_candidate_id is not None else None
            if selection is None and result_candidate_id is None and index < len(selections):
                selection = selections[index]
            game = games.get(_game_key((selection or {}).get("game_pk"))) if selection else None
            stored_status = str(result.get("status") or "pending").lower()
            should_reopen = bool(
                game is not None
                and stored_status in _TERMINAL_RESULT_STATUSES
                and not result_status_matches_disposition(
                    stored_status,
                    settlement_game_disposition(selection, game),
                )
            )
            if should_reopen:
                remember(selection, result)
                continue
            kept.append(result)
        if kept:
            results[group] = kept
        else:
            results.pop(group, None)

    for group in ("two_leg", "three_leg"):
        selections = [
            item
            for item in (package.get("parlays") or {}).get(group) or []
            if isinstance(item, dict)
        ]
        by_id = {
            str(item.get("candidate_id")): item
            for item in selections
            if item.get("candidate_id") is not None
        }
        kept: list[dict[str, Any]] = []
        for index, result in enumerate(results.get(group) or []):
            if not isinstance(result, dict):
                continue
            result_candidate_id = result.get("candidate_id")
            selection = by_id.get(str(result_candidate_id)) if result_candidate_id is not None else None
            if selection is None and result_candidate_id is None and index < len(selections):
                selection = selections[index]
            stored_status = str(result.get("status") or "pending").lower()
            current_leg_results: list[dict[str, Any]] = []
            pending_leg_exists = False
            missing_game_exists = False
            for leg in (selection or {}).get("legs") or []:
                if not isinstance(leg, dict):
                    continue
                game = games.get(_game_key(leg.get("game_pk")))
                if game is None:
                    missing_game_exists = True
                    continue
                current = settle_market_selection(leg, game)
                if current is None:
                    pending_leg_exists = True
                else:
                    current_leg_results.append(current)

            should_reopen = False
            if stored_status in _TERMINAL_RESULT_STATUSES:
                losing_leg_exists = any(
                    str(item.get("status") or "") == "lost"
                    for item in current_leg_results
                )
                if losing_leg_exists:
                    # A confirmed losing leg determines the parlay even when
                    # another official game is missing, postponed or pending.
                    should_reopen = stored_status != "lost"
                elif missing_game_exists:
                    # Do not rewrite a terminal result from incomplete source
                    # data unless a loss is already independently conclusive.
                    should_reopen = False
                elif pending_leg_exists:
                    # Without a losing leg, won + postponed/pending must stay
                    # open and every old terminal status is invalid.
                    should_reopen = True
                else:
                    current_result = _parlay_result(selection, games)
                    should_reopen = bool(
                        current_result
                        and str(current_result.get("status") or "pending") != stored_status
                    )
            if should_reopen:
                remember(selection, result)
                continue
            kept.append(result)
        if kept:
            results[group] = kept
        else:
            results.pop(group, None)

    if not reopened:
        return record, reopened
    reconciled = {**record, "results": results, "settled": False, "settled_at": None}
    return reconciled, reopened


def _selection_preview(
    selection: dict[str, Any],
    game: dict[str, Any] | None,
) -> dict[str, Any]:
    game = game or {}
    result = settle_market_selection(selection, game)
    if result is not None:
        return {
            **result,
            "game_pk": selection.get("game_pk"),
            "market": selection.get("market") or (selection.get("pick") or {}).get("market"),
            "pick_label": (selection.get("pick") or {}).get("label"),
            "matchup": selection.get("matchup"),
            "game_status": game.get("status"),
            "detailed_status": game.get("detailed_status"),
        }
    return {
        "candidate_id": selection.get("candidate_id"),
        "game_pk": selection.get("game_pk"),
        "market": selection.get("market") or (selection.get("pick") or {}).get("market"),
        "pick_label": (selection.get("pick") or {}).get("label"),
        "matchup": selection.get("matchup"),
        "status": "pending",
        "away_score": (game.get("away") or {}).get("score"),
        "home_score": (game.get("home") or {}).get("score"),
        "game_status": game.get("status") or "unknown",
        "detailed_status": game.get("detailed_status") or "尚未取得賽事狀態",
        "result_note": "等待比賽完成或官方終止狀態。",
    }


def preview_public_record(record: dict[str, Any] | None, game: dict[str, Any] | None) -> dict[str, Any] | None:
    if not record:
        return None
    stored_status = str(record.get("status") or "pending")
    snapshot = record.get("prediction_snapshot") or {}
    return {
        "record_id": record.get("id"),
        "recommendation_date": record.get("recommendation_date"),
        "league": str(record.get("league") or recommendation_league(snapshot)),
        "game_pk": record.get("game_pk"),
        "matchup": record.get("matchup"),
        "pick_label": record.get("pick_label"),
        "published_at": record.get("published_at"),
        "locked": True,
        "stored_status": stored_status,
        "preview": (
            {
                "status": stored_status,
                "away_score": record.get("away_score"),
                "home_score": record.get("home_score"),
                "result_note": record.get("result_note"),
                "settled_at": record.get("settled_at"),
            }
            if stored_status != "pending"
            else _selection_preview(snapshot, game)
        ),
    }


def preview_prediction_package(
    record: dict[str, Any] | None,
    games: dict[str, dict[str, Any]],
) -> dict[str, Any] | None:
    if not record:
        return None
    package = package_from_record(record)
    groups: dict[str, list[dict[str, Any]]] = {}
    for key in ("moneylines", "run_lines", "totals"):
        groups[key] = []
        stored_group = (record.get("results") or {}).get(key) or []
        stored_by_id = {str(item.get("candidate_id")): item for item in stored_group}
        for selection in package.get(key) or []:
            stored = stored_by_id.get(str(selection.get("candidate_id")))
            if stored:
                groups[key].append({
                    **stored,
                    "game_pk": selection.get("game_pk"),
                    "market": selection.get("market") or (selection.get("pick") or {}).get("market"),
                    "pick_label": (selection.get("pick") or {}).get("label"),
                    "matchup": selection.get("matchup"),
                })
                continue
            game = games.get(_game_key(selection.get("game_pk")))
            groups[key].append(_selection_preview(selection, game))

    for key in ("two_leg", "three_leg"):
        groups[key] = []
        stored_group = (record.get("results") or {}).get(key) or []
        stored_by_id = {str(item.get("candidate_id")): item for item in stored_group}
        for parlay in (package.get("parlays") or {}).get(key) or []:
            stored = stored_by_id.get(str(parlay.get("candidate_id")))
            if stored:
                groups[key].append({**stored, "label": parlay.get("label") or parlay.get("pick_label")})
                continue
            legs = []
            for leg in parlay.get("legs") or []:
                game = games.get(_game_key(leg.get("game_pk")))
                preview = _selection_preview(leg, game)
                legs.append(preview)
            result = _parlay_result(parlay, games)
            if result is None:
                result = {"candidate_id": parlay.get("candidate_id"), "status": "pending", "legs": legs, "result_note": "等待所有串關腿完成。"}
            groups[key].append({**result, "label": parlay.get("label") or parlay.get("pick_label")})

    flat = [item for values in groups.values() for item in values]
    statuses = [str(item.get("status") or "pending") for item in flat]
    summary = {
        "total": len(flat),
        "pending": statuses.count("pending"),
        "won": statuses.count("won"),
        "lost": statuses.count("lost"),
        "push": statuses.count("push"),
        "void": statuses.count("void"),
    }
    summary["settled"] = summary["total"] - summary["pending"]
    return {
        "record_id": record.get("id"),
        "recommendation_date": record.get("recommendation_date"),
        "published_at": record.get("generated_at"),
        "locked": bool(record.get("is_locked", True)),
        "settled": bool(record.get("settled")),
        "settled_at": record.get("settled_at"),
        "groups": groups,
        "summary": summary,
    }


class SupabaseRecordsRepository:
    def __init__(
        self,
        settings: Settings,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self.settings = settings
        self.enabled = settings.records_enabled
        key = settings.supabase_secret_key
        headers = {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "User-Agent": "DiamondMind-Server/10.1",
        }
        if key:
            headers["apikey"] = key
            # Legacy service_role keys are JWTs and still require a Bearer header.
            # New sb_secret_ keys are deliberately sent only through apikey.
            if not key.startswith("sb_secret_"):
                headers["Authorization"] = f"Bearer {key}"

        base_url = (
            f"{settings.supabase_url}/rest/v1/"
            if settings.supabase_url
            else "https://records.invalid/rest/v1/"
        )
        self.client = httpx.AsyncClient(
            base_url=base_url,
            headers=headers,
            timeout=settings.request_timeout_seconds,
            follow_redirects=True,
            trust_env=False,
            transport=transport,
        )

    async def aclose(self) -> None:
        await self.client.aclose()

    def _require_enabled(self) -> None:
        if not self.enabled:
            raise RecordsStorageError("Recommendation database is not configured")

    async def _request(self, method: str, path: str, **kwargs: Any) -> Any:
        self._require_enabled()
        try:
            response = await self.client.request(method, path, **kwargs)
            response.raise_for_status()
            if not response.content:
                return None
            return response.json()
        except (httpx.HTTPError, ValueError) as exc:
            raise RecordsStorageError("Recommendation database is temporarily unavailable") from exc

    async def get_record_for_date(
        self,
        recommendation_date: str,
        league: str | None = None,
    ) -> dict[str, Any] | None:
        params: dict[str, Any] = {
            "select": "*",
            "recommendation_date": f"eq.{recommendation_date}",
            "order": "league.asc,published_at.desc",
            "limit": 1,
        }
        if league:
            params["league"] = f"eq.{str(league).upper()}"
        data = await self._request(
            "GET",
            "recommendations",
            params=params,
        )
        if not isinstance(data, list):
            raise RecordsStorageError("Recommendation database returned an invalid response")
        return data[0] if data else None

    async def list_records_for_date(
        self,
        recommendation_date: str,
    ) -> list[dict[str, Any]]:
        data = await self._request(
            "GET",
            "recommendations",
            params={
                "select": "*",
                "recommendation_date": f"eq.{recommendation_date}",
                "order": "league.asc,published_at.asc",
            },
        )
        if not isinstance(data, list):
            raise RecordsStorageError("Recommendation database returned an invalid response")
        return data

    async def get_prediction_package_for_date(
        self,
        recommendation_date: str,
    ) -> dict[str, Any] | None:
        data = await self._request(
            "GET",
            "prediction_packages",
            params={
                "select": "*",
                "recommendation_date": f"eq.{recommendation_date}",
                "limit": 1,
            },
        )
        if not isinstance(data, list):
            raise RecordsStorageError("Prediction package database returned an invalid response")
        return data[0] if data else None

    async def publish_prediction_package_once(
        self,
        recommendation_date: str,
        package: dict[str, Any],
    ) -> tuple[dict[str, Any], bool]:
        payload = build_package_payload(recommendation_date, package)
        data = await self._request(
            "POST",
            "prediction_packages",
            params={"on_conflict": "recommendation_date"},
            headers={"Prefer": "resolution=ignore-duplicates,return=representation"},
            json=payload,
        )
        if not isinstance(data, list):
            raise RecordsStorageError("Prediction package database returned an invalid response")
        if data:
            return data[0], True
        existing = await self.get_prediction_package_for_date(recommendation_date)
        if not existing:
            raise RecordsStorageError("Locked prediction package could not be loaded")
        return existing, False

    async def replace_prediction_package(
        self,
        recommendation_date: str,
        package: dict[str, Any],
        *,
        preserve_results: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Replace or extend the locked package for a date.

        League-specific publishing can add NPB after MLB (or vice versa). When
        ``preserve_results`` is supplied, already-settled selections remain in
        the row while the newly added league starts pending.
        """

        payload = build_package_payload(recommendation_date, package)
        if preserve_results is not None:
            payload["results"] = preserve_results
            payload["settled"] = False
            payload["settled_at"] = None
        data = await self._request(
            "PATCH",
            "prediction_packages",
            params={"recommendation_date": f"eq.{recommendation_date}"},
            headers={"Prefer": "return=representation"},
            json=payload,
        )
        if not isinstance(data, list) or not data:
            raise RecordsStorageError("Prediction package replacement did not return a row")
        return data[0]

    async def list_pending_prediction_packages(self) -> list[dict[str, Any]]:
        data = await self._request(
            "GET",
            "prediction_packages",
            params={"select": "*", "settled": "eq.false", "order": "recommendation_date.asc"},
        )
        if not isinstance(data, list):
            raise RecordsStorageError("Prediction package database returned an invalid response")
        return data

    async def list_prediction_packages(
        self,
        *,
        limit: int | None = None,
    ) -> list[dict[str, Any]]:
        """Load every locked formal package, including partially settled days."""

        data = await self._request(
            "GET",
            "prediction_packages",
            params={
                "select": "*",
                "order": "recommendation_date.desc,generated_at.desc",
                "limit": limit or self.settings.records_limit,
            },
        )
        if not isinstance(data, list):
            raise RecordsStorageError("Prediction package database returned an invalid response")
        return data

    async def list_settled_prediction_packages(
        self,
        *,
        limit: int | None = None,
    ) -> list[dict[str, Any]]:
        """Load only completed packages that are safe for the public history.

        Current or future paid selections must never be exposed by the public
        records endpoint. Requiring ``settled=true`` at the database query is
        the primary guard; the API performs the same check again before
        serializing a row.
        """

        data = await self._request(
            "GET",
            "prediction_packages",
            params={
                "select": "*",
                "settled": "eq.true",
                "order": "recommendation_date.desc,generated_at.desc",
                "limit": limit or self.settings.records_limit,
            },
        )
        if not isinstance(data, list):
            raise RecordsStorageError("Prediction package database returned an invalid response")
        return [item for item in data if item.get("settled") is True]

    async def settle_prediction_package(
        self,
        package_id: str,
        result: dict[str, Any],
    ) -> dict[str, Any] | None:
        data = await self._request(
            "PATCH",
            "prediction_packages",
            params={"id": f"eq.{package_id}", "settled": "eq.false"},
            headers={"Prefer": "return=representation"},
            json=result,
        )
        if isinstance(data, list) and data:
            return data[0]
        return None

    async def reconcile_prediction_package(
        self,
        package_id: str,
        result: dict[str, Any],
    ) -> dict[str, Any] | None:
        """Rewrite a package only after a stored void is proven non-terminal."""

        data = await self._request(
            "PATCH",
            "prediction_packages",
            params={"id": f"eq.{package_id}"},
            headers={"Prefer": "return=representation"},
            json=result,
        )
        if isinstance(data, list) and data:
            return data[0]
        return None

    async def publish_prediction_once(
        self,
        recommendation_date: str,
        selection: dict[str, Any],
    ) -> tuple[dict[str, Any], bool]:
        """Insert one immutable public pick per date and league.

        Supabase's ``(recommendation_date, league)`` constraint makes this
        atomic. MLB and NPB can therefore each publish one free pick for the
        same Taiwan date without overwriting one another.
        """

        payload = build_record_payload(recommendation_date, selection)
        league = str(payload.get("league") or "MLB")
        data = await self._request(
            "POST",
            "recommendations",
            params={"on_conflict": "recommendation_date,league"},
            headers={"Prefer": "resolution=ignore-duplicates,return=representation"},
            json=payload,
        )
        if not isinstance(data, list):
            raise RecordsStorageError("Recommendation database returned an invalid response")
        if data:
            return data[0], True

        existing = await self.get_record_for_date(recommendation_date, league)
        if not existing:
            raise RecordsStorageError("Published recommendation could not be loaded")
        return existing, False

    async def upsert_prediction(
        self,
        recommendation_date: str,
        selection: dict[str, Any],
    ) -> dict[str, Any]:
        """Compatibility wrapper; public recommendations are now immutable."""

        record, _ = await self.publish_prediction_once(recommendation_date, selection)
        return record

    async def list_records(
        self,
        *,
        status: str | None = None,
        limit: int | None = None,
    ) -> list[dict[str, Any]]:
        params: dict[str, Any] = {
            "select": "*",
            "order": "recommendation_date.desc,published_at.desc",
            "limit": limit or self.settings.records_limit,
        }
        if status:
            params["status"] = f"eq.{status}"
        data = await self._request("GET", "recommendations", params=params)
        if not isinstance(data, list):
            raise RecordsStorageError("Recommendation database returned an invalid response")
        return data

    async def settle(self, game_pk: Any, result: dict[str, Any]) -> dict[str, Any] | None:
        data = await self._request(
            "PATCH",
            "recommendations",
            params={"game_pk": f"eq.{game_pk}", "status": "eq.pending"},
            headers={"Prefer": "return=representation"},
            json=result,
        )
        if isinstance(data, list) and data:
            return data[0]
        return None

    async def reconcile_void_prediction(
        self,
        game_pk: Any,
        result: dict[str, Any],
    ) -> dict[str, Any] | None:
        """Replace an erroneous void after the official game is rescheduled."""

        data = await self._request(
            "PATCH",
            "recommendations",
            params={"game_pk": f"eq.{game_pk}", "status": "eq.void"},
            headers={"Prefer": "return=representation"},
            json=result,
        )
        if isinstance(data, list) and data:
            return data[0]
        return None

    async def reconcile_prediction(
        self,
        record_id: Any,
        result: dict[str, Any],
    ) -> dict[str, Any] | None:
        """Replace any terminal result proven inconsistent with official data."""

        data = await self._request(
            "PATCH",
            "recommendations",
            params={"id": f"eq.{record_id}"},
            headers={"Prefer": "return=representation"},
            json=result,
        )
        if isinstance(data, list) and data:
            return data[0]
        return None

    async def update_prediction_snapshot(
        self,
        game_pk: Any,
        snapshot: dict[str, Any],
    ) -> dict[str, Any] | None:
        """Persist publication lifecycle metadata without changing the result status."""

        data = await self._request(
            "PATCH",
            "recommendations",
            params={"game_pk": f"eq.{game_pk}", "status": "eq.pending"},
            headers={"Prefer": "return=representation"},
            json={"prediction_snapshot": snapshot},
        )
        if isinstance(data, list) and data:
            return data[0]
        return None
