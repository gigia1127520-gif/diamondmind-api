from __future__ import annotations

import re
from datetime import date
from typing import Any, Iterable

BAD_TEXT_PATTERNS = (
    re.compile(r"--chakra", re.I),
    re.compile(r"@layer", re.I),
    re.compile(r"\.css-[a-z0-9]", re.I),
    re.compile(r"display:\s*(?:-webkit-)?flex", re.I),
    re.compile(r"<\/?(?:style|script|svg)", re.I),
)
FINAL_STATUSES = {"final", "finished", "ended", "completed", "game over", "已結束", "終了"}
LIVE_STATUSES = {"live", "in_progress", "in progress", "進行中"}


def _text(value: Any) -> str:
    return str(value or "").strip()


def _score(value: Any) -> int | None:
    if value is None or value == "":
        return None
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return None


def _team(game: dict[str, Any], side: str) -> dict[str, Any]:
    value = game.get(side) or {}
    return value if isinstance(value, dict) else {}


def _status(game: dict[str, Any]) -> str:
    return _text(game.get("status") or game.get("status_code") or game.get("state")).lower()


def _has_bad_text(value: Any) -> bool:
    text = _text(value)
    return bool(text and any(pattern.search(text) for pattern in BAD_TEXT_PATTERNS))


def audit_game(game: dict[str, Any], *, expected_date: str | None = None) -> dict[str, Any]:
    away = _team(game, "away")
    home = _team(game, "home")
    status = _status(game)
    final = status in FINAL_STATUSES or bool(game.get("is_final"))
    away_score = _score(game.get("away_score") if game.get("away_score") is not None else away.get("score"))
    home_score = _score(game.get("home_score") if game.get("home_score") is not None else home.get("score"))
    game_id = game.get("game_pk") or game.get("external_game_id") or game.get("id")
    actual_date = _text(game.get("date_taiwan") or game.get("official_date") or game.get("date"))[:10]
    checks = {
        "official_game_id": bool(game_id),
        "away_team": bool(away.get("id") or away.get("name") or away.get("abbr")),
        "home_team": bool(home.get("id") or home.get("name") or home.get("abbr")),
        "distinct_teams": _text(away.get("name") or away.get("abbr")) != _text(home.get("name") or home.get("abbr")),
        "date_aligned": not expected_date or not actual_date or actual_date == expected_date,
        "score_complete_if_final": not final or (away_score is not None and home_score is not None),
        "clean_venue": not _has_bad_text(game.get("venue")),
        "clean_labels": not any(_has_bad_text(value) for value in (
            away.get("name"), home.get("name"), game.get("game_label"), game.get("venue")
        )),
    }
    failed = [key for key, passed in checks.items() if not passed]
    warnings: list[str] = []
    if status in LIVE_STATUSES and away_score is None and home_score is None:
        warnings.append("live_score_not_available")
    if not final and away_score is not None and home_score is not None:
        warnings.append("score_present_before_final_status")
    score = sum(1 for passed in checks.values() if passed) / max(1, len(checks))
    return {
        "game_pk": str(game_id or ""),
        "matchup": f"{_text(away.get('name') or away.get('abbr'))} @ {_text(home.get('name') or home.get('abbr'))}",
        "status": status or "unknown",
        "expected_date": expected_date,
        "actual_date": actual_date or None,
        "checks": checks,
        "failed": failed,
        "warnings": warnings,
        "quality_score": round(score, 3),
        "publish_safe": not failed,
        "settlement_safe": bool(final and away_score is not None and home_score is not None and not failed),
    }


def audit_games(items: Iterable[dict[str, Any]], *, league: str, expected_date: date | str | None = None) -> dict[str, Any]:
    expected = expected_date.isoformat() if isinstance(expected_date, date) else str(expected_date or "") or None
    rows = [audit_game(item, expected_date=expected) for item in items if isinstance(item, dict)]
    failed = [row for row in rows if not row["publish_safe"]]
    final_rows = [row for row in rows if row["status"] in FINAL_STATUSES]
    settlement_ready = [row for row in final_rows if row["settlement_safe"]]
    return {
        "league": str(league).upper(),
        "date": expected,
        "games": len(rows),
        "publish_safe_games": sum(row["publish_safe"] for row in rows),
        "final_games": len(final_rows),
        "settlement_safe_games": len(settlement_ready),
        "failed_games": len(failed),
        "quality_score": round(sum(row["quality_score"] for row in rows) / len(rows), 3) if rows else None,
        "status": "pass" if rows and not failed else "warning" if rows else "empty",
        "items": rows,
    }


def audit_snapshot(row: dict[str, Any]) -> dict[str, Any]:
    status = _text(row.get("status") or "pending").lower()
    market = _text(row.get("market")).lower()
    probability = row.get("calibrated_probability") if row.get("calibrated_probability") is not None else row.get("confidence")
    checks = {
        "source_record_id": bool(row.get("source_record_id")),
        "candidate_id": bool(row.get("candidate_id")),
        "official_game_id": bool(row.get("game_pk")),
        "league": bool(row.get("league")),
        "market": market in {"moneyline", "run_line", "totals", "two_leg", "three_leg", "2_leg", "3_leg"},
        "probability": probability is not None,
        "result_if_settled": status == "pending" or bool(row.get("result")),
    }
    failed = [key for key, value in checks.items() if not value]
    return {
        "id": row.get("id"),
        "league": row.get("league"),
        "market": market,
        "status": status,
        "checks": checks,
        "failed": failed,
        "quality_score": round(sum(checks.values()) / max(1, len(checks)), 3),
    }


def audit_snapshots(rows: Iterable[dict[str, Any]]) -> dict[str, Any]:
    items = [audit_snapshot(row) for row in rows if isinstance(row, dict)]
    return {
        "snapshots": len(items),
        "valid_snapshots": sum(not row["failed"] for row in items),
        "invalid_snapshots": sum(bool(row["failed"]) for row in items),
        "quality_score": round(sum(row["quality_score"] for row in items) / len(items), 3) if items else None,
        "items": items,
    }
