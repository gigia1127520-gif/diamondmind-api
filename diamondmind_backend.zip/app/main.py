from __future__ import annotations

from contextlib import asynccontextmanager
from datetime import date, datetime
from zoneinfo import ZoneInfo

from fastapi import FastAPI, HTTPException, Query, Request
from fastapi.middleware.cors import CORSMiddleware

from .config import settings
from .mlb import MLBService, MLBUpstreamError


TAIPEI = ZoneInfo("Asia/Taipei")


@asynccontextmanager
async def lifespan(app: FastAPI):
    service = MLBService(settings)
    app.state.mlb = service
    yield
    await service.aclose()


app = FastAPI(
    title="DiamondMind API",
    version="10.0.0",
    description="MLB schedule, statistics, Pythagorean expectation and transparent prediction API.",
    lifespan=lifespan,
)

allow_all = "*" in settings.cors_origins
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"] if allow_all else settings.cors_origins,
    allow_credentials=not allow_all,
    allow_methods=["GET", "OPTIONS"],
    allow_headers=["*"],
)


def service(request: Request) -> MLBService:
    return request.app.state.mlb


def requested_date(value: date | None) -> date:
    return value or datetime.now(TAIPEI).date()


@app.get("/")
async def root() -> dict:
    return {
        "name": settings.app_name,
        "version": "10.0.0",
        "status": "online",
        "docs": "/docs",
        "health": f"{settings.api_prefix}/health",
    }


@app.get(f"{settings.api_prefix}/health")
async def health() -> dict:
    return {
        "ok": True,
        "service": settings.app_name,
        "environment": settings.app_env,
        "time_taiwan": datetime.now(TAIPEI).isoformat(),
    }


@app.get(f"{settings.api_prefix}/mlb/games")
async def mlb_games(
    request: Request,
    game_date: date | None = Query(default=None, alias="date", description="Taiwan date, YYYY-MM-DD"),
) -> dict:
    try:
        return await service(request).games_for_date(requested_date(game_date))
    except MLBUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@app.get(f"{settings.api_prefix}/mlb/games/{{game_pk}}")
async def mlb_game_detail(request: Request, game_pk: int) -> dict:
    try:
        return await service(request).game_detail(game_pk)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail="Game not found") from exc
    except MLBUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@app.get(f"{settings.api_prefix}/predictions/top")
async def top_prediction(
    request: Request,
    prediction_date: date | None = Query(default=None, alias="date", description="Taiwan date, YYYY-MM-DD"),
) -> dict:
    try:
        return await service(request).top_prediction(requested_date(prediction_date))
    except MLBUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@app.get(f"{settings.api_prefix}/records")
async def recommendation_records() -> dict:
    return {
        "items": [],
        "count": 0,
        "message": "推薦紀錄資料庫將於 V10 第二階段啟用。",
        "is_demo": False,
    }

