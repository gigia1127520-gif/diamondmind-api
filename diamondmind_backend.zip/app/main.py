from __future__ import annotations

from contextlib import asynccontextmanager
from datetime import date, datetime
from zoneinfo import ZoneInfo

from fastapi import FastAPI, HTTPException, Query, Request
from fastapi.middleware.cors import CORSMiddleware

from .config import settings
from .mlb import MLBService, MLBUpstreamError
from .records import (
    RecordsStorageError,
    SupabaseRecordsRepository,
    settlement_for,
    summarize_records,
)


TAIPEI = ZoneInfo("Asia/Taipei")


@asynccontextmanager
async def lifespan(app: FastAPI):
    service = MLBService(settings)
    records = SupabaseRecordsRepository(settings)
    app.state.mlb = service
    app.state.records = records
    yield
    await service.aclose()
    await records.aclose()


app = FastAPI(
    title="DiamondMind API",
    version="10.1.0",
    description="MLB schedule, statistics, Pythagorean expectation and transparent prediction API.",
    lifespan=lifespan,
)

allow_all = "*" in settings.cors_origins
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"] if allow_all else settings.cors_origins,
    allow_credentials=not allow_all,
    allow_methods=["GET", "OPTIONS"],
    allow_headers=["*"],
)


def service(request: Request) -> MLBService:
    return request.app.state.mlb


def records_repository(request: Request) -> SupabaseRecordsRepository:
    return request.app.state.records


def requested_date(value: date | None) -> date:
    return value or datetime.now(TAIPEI).date()


@app.get("/")
async def root() -> dict:
    return {
        "name": settings.app_name,
        "version": "10.1.0",
        "status": "online",
        "docs": "/docs",
        "health": f"{settings.api_prefix}/health",
    }


@app.get(f"{settings.api_prefix}/health")
async def health() -> dict:
    return {
        "ok": True,
        "service": settings.app_name,
        "environment": settings.app_env,
        "records_database": "configured" if settings.records_enabled else "not_configured",
        "time_taiwan": datetime.now(TAIPEI).isoformat(),
    }


@app.get(f"{settings.api_prefix}/mlb/games")
async def mlb_games(
    request: Request,
    game_date: date | None = Query(default=None, alias="date", description="Taiwan date, YYYY-MM-DD"),
) -> dict:
    try:
        return await service(request).games_for_date(requested_date(game_date))
    except MLBUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@app.get(f"{settings.api_prefix}/mlb/games/{{game_pk}}")
async def mlb_game_detail(request: Request, game_pk: int) -> dict:
    try:
        return await service(request).game_detail(game_pk)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail="Game not found") from exc
    except MLBUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@app.get(f"{settings.api_prefix}/predictions/top")
async def top_prediction(
    request: Request,
    prediction_date: date | None = Query(default=None, alias="date", description="Taiwan date, YYYY-MM-DD"),
) -> dict:
    try:
        result = await service(request).top_prediction(requested_date(prediction_date))
    except MLBUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc

    repository = records_repository(request)
    persistence = {"enabled": repository.enabled, "stored": False}
    if result.get("published") and repository.enabled:
        try:
            stored = await repository.upsert_prediction(result["date"], result["selection"])
            persistence.update({"stored": True, "record_id": stored.get("id")})
        except RecordsStorageError:
            # Prediction remains available even if the records database has a
            # temporary incident. It can be requested again to retry the upsert.
            persistence["message"] = "推薦已產生，但紀錄資料庫暫時無法寫入。"
    result["persistence"] = persistence
    return result


@app.get(f"{settings.api_prefix}/records")
async def recommendation_records(request: Request) -> dict:
    repository = records_repository(request)
    if not repository.enabled:
        return {
            "items": [],
            "count": 0,
            "stats": summarize_records([]),
            "message": "推薦紀錄資料庫尚未設定。",
            "is_demo": False,
            "database": "not_configured",
        }

    try:
        pending = await repository.list_records(status="pending")
        settled_now = 0
        for record in pending:
            try:
                game = await service(request).game_result(int(record["game_pk"]))
            except (KeyError, MLBUpstreamError, TypeError, ValueError):
                continue
            result = settlement_for(record, game)
            if result and await repository.settle(int(record["game_pk"]), result):
                settled_now += 1

        items = await repository.list_records()
    except RecordsStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc

    return {
        "items": items,
        "count": len(items),
        "stats": summarize_records(items),
        "message": "尚無正式推薦紀錄。" if not items else "正式推薦紀錄已載入。",
        "is_demo": False,
        "database": "connected",
        "settled_now": settled_now,
    }
