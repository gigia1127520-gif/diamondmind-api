from __future__ import annotations

import asyncio
import csv
from copy import deepcopy
import io
import math
import re
from contextlib import asynccontextmanager, suppress
from datetime import date, datetime, timedelta
from secrets import compare_digest
from zoneinfo import ZoneInfo

from fastapi import FastAPI, Header, HTTPException, Query, Request
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, PlainTextResponse, Response
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from .config import settings
from .billing import BillingError, BillingRepository, ECPayBillingService, parse_form_body
from .admin import AdminMemberCommand, AdminMembershipError, AdminMembershipService
from .announcements import AnnouncementError, AnnouncementRepository, AnnouncementService
from .auth import MemberAccessError, SupabaseMemberAuth
from .trials import NewMemberTrialError, NewMemberTrialService
from .markets import (
    build_daily_market_candidates,
    build_daily_market_package,
    build_selected_market_package,
    is_asian_baseball_pro_selection,
    is_npb_pro_selection,
    is_real_odds_selection,
    match_odds_event,
    merge_market_candidates,
    model_only_moneyline_candidate,
    moneyline_candidate,
    run_line_candidate,
    totals_candidate,
)
from .mlb import MLBService, MLBUpstreamError
from .npb import NPBService, NPBUpstreamError
from .asian_baseball import AsianBaseballService, AsianBaseballUpstreamError
from .odds import OddsService, OddsUpstreamError
from .odds_api_io import OddsApiIoService, OddsApiIoUpstreamError
from .operations import build_operations_report, probe_league_sources
from .sports import (
    ACTIVE_LEAGUES,
    LEAGUES,
    SCHEMA_VERSION as SPORTS_SCHEMA_VERSION,
    league_catalog as registered_league_catalog,
    market_catalog as registered_market_catalog,
    normalize_event,
    normalize_league_code,
    sport_for_league,
    sports_catalog as registered_sports_catalog,
)
from .validation import game_timing, iso_utc, parse_game_datetime
from .records import (
    RecordsStorageError,
    SupabaseRecordsRepository,
    package_from_record,
    preview_prediction_package,
    preview_public_record,
    result_status_matches_disposition,
    settlement_game_disposition,
    settlement_for,
    reopen_rescheduled_package_results,
    settle_market_selection,
    settle_prediction_package,
    summarize_records,
)
from .performance import (
    DEFAULT_MODEL_WEIGHTS,
    PerformanceRepository,
    PerformanceStorageError,
    calibration_suggestions,
    normalize_weights,
)
from .social import (
    DiamondMindSocialService,
    SocialAssetSpec,
    SocialReelSpec,
    SocialPublishingError,
    TERMINAL_STATUSES as SOCIAL_TERMINAL_STATUSES,
    compact_pick_label,
    decimal_price,
    display_team,
    event_key as social_event_key,
    normalize_market_label,
    status_label,
    utc_now as social_utc_now,
)


TAIPEI = ZoneInfo("Asia/Taipei")
APP_VERSION = "20.2"


@asynccontextmanager
async def lifespan(app: FastAPI):
    service = MLBService(settings)
    npb = NPBService(settings)
    kbo = AsianBaseballService(settings, "KBO")
    cpbl = AsianBaseballService(settings, "CPBL")
    odds = OddsService(settings)
    odds_api_io = OddsApiIoService(settings)
    records = SupabaseRecordsRepository(settings)
    member_auth = SupabaseMemberAuth(settings)
    billing_repository = BillingRepository(settings)
    billing = ECPayBillingService(settings, billing_repository)
    membership_admin = AdminMembershipService(billing_repository)
    member_trial = NewMemberTrialService(settings, billing_repository)
    announcement_repository = AnnouncementRepository(settings)
    announcements = AnnouncementService(announcement_repository)
    performance = PerformanceRepository(settings)
    social = DiamondMindSocialService(settings)
    try:
        service.model_weights = await performance.active_weights() if performance.enabled else dict(DEFAULT_MODEL_WEIGHTS)
    except PerformanceStorageError:
        service.model_weights = dict(DEFAULT_MODEL_WEIGHTS)
    app.state.mlb = service
    app.state.npb = npb
    app.state.kbo = kbo
    app.state.cpbl = cpbl
    app.state.odds = odds
    app.state.odds_api_io = odds_api_io
    app.state.records = records
    app.state.member_auth = member_auth
    app.state.billing_repository = billing_repository
    app.state.billing = billing
    app.state.membership_admin = membership_admin
    app.state.member_trial = member_trial
    app.state.announcements = announcements
    app.state.performance = performance
    app.state.social = social
    app.state.started_at = datetime.now(TAIPEI).isoformat()
    app.state.pregame_status = {"running": True, "last_run": None, "last_error": None}
    app.state.settlement_status = {
        "running": True,
        "last_run": None,
        "last_error": None,
        "free_settled_now": 0,
        "packages_settled_now": 0,
    }
    app.state.operations_monitor_status = {
        "ok": True,
        "status": "starting",
        "checked_at": None,
        "checks": [],
        "critical_issues": [],
        "warnings": [],
    }
    app.state.operations_monitor_failures = {}
    # External cron requests have a hard 30-second response limit.  The
    # settlement endpoint therefore acknowledges immediately and performs the
    # heavier settlement/social/monitoring workflow in this in-process task.
    app.state.external_settlement_task = None
    app.state.external_settlement_lock = asyncio.Lock()
    app.state.social_status = {
        "running": True,
        "last_run": None,
        "last_error": None,
        "published_now": 0,
    }
    monitor_task = asyncio.create_task(_pregame_refresh_loop(app), name="diamondmind-pregame-refresh")
    app.state.pregame_task = monitor_task
    yield
    monitor_task.cancel()
    with suppress(asyncio.CancelledError):
        await monitor_task
    external_settlement_task = getattr(app.state, "external_settlement_task", None)
    if external_settlement_task is not None and not external_settlement_task.done():
        external_settlement_task.cancel()
        with suppress(asyncio.CancelledError):
            await external_settlement_task
    await service.aclose()
    await npb.aclose()
    await kbo.aclose()
    await cpbl.aclose()
    await odds.aclose()
    await odds_api_io.aclose()
    await records.aclose()
    await member_auth.aclose()
    await billing.aclose()
    await billing_repository.aclose()
    await announcement_repository.aclose()
    await performance.aclose()
    await social.aclose()


app = FastAPI(
    title="DiamondMind API",
    version=APP_VERSION,
    description="DiamondMind multi-sport platform. MLB, NPB, KBO and CPBL schedules, predictions, auto-publishing and settlement are active; NBA and EPL remain prepared for later adapters.",
    lifespan=lifespan,
)

allow_all = "*" in settings.cors_origins
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"] if allow_all else settings.cors_origins,
    allow_credentials=not allow_all,
    allow_methods=["GET", "POST", "PATCH", "DELETE", "OPTIONS"],
    allow_headers=["*"],
)


def service(request: Request) -> MLBService:
    return request.app.state.mlb


def npb_service(request: Request) -> NPBService:
    return request.app.state.npb

def kbo_service(request: Request) -> AsianBaseballService:
    return request.app.state.kbo


def cpbl_service(request: Request) -> AsianBaseballService:
    return request.app.state.cpbl


def baseball_service(request: Request, league: str):
    code = str(league or "MLB").upper()
    if code == "MLB":
        return service(request)
    if code == "NPB":
        return npb_service(request)
    if code == "KBO":
        return kbo_service(request)
    if code == "CPBL":
        return cpbl_service(request)
    raise ValueError(f"Unsupported baseball league: {code}")


def records_repository(request: Request) -> SupabaseRecordsRepository:
    return request.app.state.records


def membership_admin_service(request: Request) -> AdminMembershipService:
    return request.app.state.membership_admin


def member_trial_service(request: Request) -> NewMemberTrialService:
    return request.app.state.member_trial


def announcement_service(request: Request) -> AnnouncementService:
    return request.app.state.announcements


def performance_repository(request: Request) -> PerformanceRepository:
    return request.app.state.performance


def social_service(request: Request) -> DiamondMindSocialService:
    return request.app.state.social


def odds_service(request: Request) -> OddsService:
    return request.app.state.odds


def odds_api_io_service(request: Request) -> OddsApiIoService:
    return request.app.state.odds_api_io


def member_auth_service(request: Request) -> SupabaseMemberAuth:
    return request.app.state.member_auth


def billing_service(request: Request) -> ECPayBillingService:
    return request.app.state.billing


def _official_settlement_verification_check(records: list[dict]) -> dict:
    """Build the launch-check result from persisted public recommendations.

    A completed real cycle means that a recommendation was publicly published,
    retained in the records database and later received a terminal settlement.
    Current games may still be pending without invalidating an earlier verified
    end-to-end cycle.
    """

    published = [
        record
        for record in records
        if record.get("is_public") is True and record.get("published_at")
    ]
    verified = [
        record
        for record in published
        if str(record.get("status") or "").lower() in {"won", "lost", "push", "void"}
        and record.get("settled_at")
    ]

    if verified:
        leagues = sorted({str(record.get("league") or "MLB").upper() for record in verified})
        league_text = "／".join(leagues)
        return {
            "key": "official_settlement_verification",
            "label": "真實推薦與結算驗收",
            "status": "pass",
            "detail": f"已驗收 {len(verified)} 筆 {league_text} 真實正式推薦；發布紀錄保留與自動結算正常",
            "blocking": False,
            "manual": False,
        }

    if published:
        detail = f"已發布 {len(published)} 筆真實正式推薦，等待至少一筆完成賽後自動結算"
    else:
        detail = "尚無同時具備正式公開發布與賽後結算結果的真實推薦"
    return {
        "key": "official_settlement_verification",
        "label": "真實推薦與結算驗收",
        "status": "pending",
        "detail": detail,
        "blocking": False,
        "manual": False,
    }


def _csv_safe(value: object) -> str:
    if value is None:
        return ""
    text = str(value)
    if text.startswith(("=", "+", "-", "@")):
        return "'" + text
    return text


def _csv_response(filename: str, fieldnames: list[str], rows: list[dict[str, object]]) -> Response:
    buffer = io.StringIO(newline="")
    writer = csv.DictWriter(buffer, fieldnames=fieldnames, extrasaction="ignore")
    writer.writeheader()
    for row in rows:
        writer.writerow({key: _csv_safe(row.get(key)) for key in fieldnames})
    content = ("\ufeff" + buffer.getvalue()).encode("utf-8")
    return Response(
        content=content,
        media_type="text/csv; charset=utf-8",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


def bearer_token(authorization: str | None) -> str | None:
    if authorization and authorization.lower().startswith("bearer "):
        return authorization[7:].strip()
    return None


async def authenticated_member(request: Request, authorization: str | None) -> dict:
    try:
        return await member_auth_service(request).member(bearer_token(authorization))
    except MemberAccessError as exc:
        raise HTTPException(status_code=401, detail=str(exc)) from exc


async def optional_member(request: Request, authorization: str | None) -> dict:
    """Return guest access when no bearer token is supplied.

    An invalid or expired token is still rejected so the browser can clear the
    stale session instead of silently treating it as a valid free account.
    """

    token = bearer_token(authorization)
    if not token:
        return {"id": None, "email": None, "role": "guest", "has_pro_access": False}
    try:
        return await member_auth_service(request).member(token)
    except MemberAccessError as exc:
        raise HTTPException(status_code=401, detail=str(exc)) from exc


def _public_team_snapshot(team: dict | None) -> dict:
    team = team or {}
    pitcher = team.get("probable_pitcher") or {}
    return {
        "id": team.get("id"),
        "name": team.get("name"),
        "abbr": team.get("abbr"),
        "score": team.get("score"),
        "probable_pitcher": {
            "id": pitcher.get("id"),
            "name": pitcher.get("name") or "尚未公布",
        },
    }


def locked_game_detail(detail: dict, member: dict) -> dict:
    """Whitelist the only matchup fields available without Pro access.

    Never return the analysis object and then rely on CSS to hide it. This
    response deliberately omits lineups, bullpen, weather, Statcast, model pick,
    confidence, completeness, sources and every five-engine metric.
    """

    game = detail.get("game") or {}
    public_game = {
        key: game.get(key)
        for key in (
            "game_pk", "game_date", "date_taiwan", "time_taiwan", "status",
            "detailed_status", "inning", "inning_state", "venue_id", "venue",
            "game_type", "season_context", "event_label", "is_special_event",
            "doubleheader_code", "is_doubleheader", "game_number", "game_label",
            "display_time_taiwan",
        )
        if key in game
    }
    public_game["away"] = _public_team_snapshot(game.get("away"))
    public_game["home"] = _public_team_snapshot(game.get("home"))
    return {
        "game": public_game,
        "analysis_locked": True,
        "access": {
            "role": member.get("role") or "guest",
            "has_pro_access": False,
            "required_plan": "pro",
        },
        "locked_modules": [
            "starter", "lineup", "bullpen", "environment", "advanced",
        ],
        "message": "升級 Pro 解鎖完整賽事情報。",
        "meta": {
            "source": "MLB Stats API",
            "updated_at": (detail.get("meta") or {}).get("updated_at"),
            "analysis_payload_returned": False,
        },
    }


async def admin_member(request: Request, authorization: str | None) -> dict:
    member = await authenticated_member(request, authorization)
    if member.get("role") != "admin":
        raise HTTPException(status_code=403, detail="Founder access is required")
    return member


def requested_date(value: date | None) -> date:
    return value or datetime.now(TAIPEI).date()


def cron_secret_matches(provided: str | None, configured: str) -> bool:
    """Constant-time comparison for the server-to-server scheduler secret."""

    if not provided or not configured:
        return False
    return compare_digest(provided.encode("utf-8"), configured.encode("utf-8"))



def publication_policy(analysis: dict, *, automatic: bool = False, now: datetime | None = None) -> dict:
    game = analysis.get("game") or {}
    context = str(game.get("season_context") or "unsupported")
    confidence = float(analysis.get("confidence") or 0)
    data_quality = float(analysis.get("data_quality") or 0)
    timing = analysis.get("timing") or game_timing(
        game,
        now=now,
        lineup_watch_minutes=settings.pregame_lineup_watch_minutes,
        final_lock_minutes=settings.pregame_final_lock_minutes,
    )
    validation = analysis.get("roster_validation") or {}
    validation_overall = validation.get("overall") or {}
    lineups = validation.get("lineups") or {}
    lineup_rates = [
        float((lineups.get(side) or {}).get("validation_rate") or 0)
        for side in ("away", "home")
    ]
    lineup_rate = min(lineup_rates) if lineup_rates else 0.0
    starter_group = ((analysis.get("analysis_groups") or {}).get("starter") or {})
    blockers: list[str] = []
    warnings: list[str] = []

    if str(game.get("status") or "upcoming") != "upcoming" or timing.get("stage") == "started":
        blockers.append("比賽已開始或不再接受賽前發布。")
    if context not in {"regular_season", "postseason"}:
        blockers.append(f"{game.get('event_label') or '特殊賽事'}專用模型尚未啟用，不能套用一般模型正式發布。")
    if data_quality < settings.minimum_publish_data_quality:
        blockers.append(f"整體資料完整度不足 {settings.minimum_publish_data_quality * 100:.0f}%。")
    if starter_group.get("both_starters_ready") is not True:
        blockers.append("兩隊先發投手、投手數據或名單驗證尚未達正式發布標準。")
    if validation_overall.get("status") == "mismatch":
        blockers.append("球員與球隊身分驗證發現不一致，需重新整理後再確認。")
    if lineup_rate < settings.minimum_lineup_validation_rate:
        blockers.append(f"打線名單驗證率不足 {settings.minimum_lineup_validation_rate * 100:.0f}%。")
    if confidence < settings.min_confidence:
        message = f"模型信心 {confidence:.1f}% 低於門檻 {settings.min_confidence:.1f}%。"
        if automatic:
            blockers.append(message)
        else:
            warnings.append(message)
    if timing.get("stage") == "preview":
        warnings.append("目前仍是賽前預覽階段；先發、打線或盤口後續可能變動。")
    elif timing.get("stage") == "lineup_watch":
        warnings.append("已進入開賽前 90 分鐘監控階段；系統會持續重新分析正式打線。")
    if context == "postseason":
        warnings.append("季後賽請再確認輪值、休息天數與系列賽狀況。")

    can_publish = not blockers
    auto_ready = can_publish and timing.get("stage") == "final_lock" and confidence >= settings.min_confidence
    return {
        "can_publish": can_publish,
        "auto_publish_ready": auto_ready,
        "requires_confirmation": bool(warnings),
        "blockers": blockers,
        "warnings": warnings,
        "timing": timing,
        "lineup_validation_rate": round(lineup_rate, 3),
        "roster_validation": validation_overall,
        "checklist": {
            "game_not_started": timing.get("stage") != "started",
            "supported_event": context in {"regular_season", "postseason"},
            "both_starters_confirmed": starter_group.get("both_starters_ready") is True,
            "data_quality_passed": data_quality >= settings.minimum_publish_data_quality,
            "lineup_validation_passed": lineup_rate >= settings.minimum_lineup_validation_rate,
            "roster_validation_passed": validation_overall.get("status") != "mismatch",
            "confidence_passed": confidence >= settings.min_confidence,
            "final_lock_window": timing.get("stage") == "final_lock",
        },
    }


def _npb_auto_publish_window(
    games: list[dict],
    *,
    now: datetime | None = None,
    lead_minutes: int = 60,
    grace_minutes: int = 15,
) -> dict:
    """Return the NPB fallback trigger state for the next unstarted game.

    The preferred trigger remains one hour before the day's earliest game.  If
    an external scheduler is delayed or the first game has already started,
    the fallback moves to the next unstarted game instead of abandoning the
    entire NPB slate.  A small grace period absorbs normal GitHub Actions queue
    delays without ever publishing after first pitch.
    """

    current = now or datetime.now(TAIPEI)
    if current.tzinfo is None:
        current = current.replace(tzinfo=TAIPEI)
    current = current.astimezone(TAIPEI)
    valid_games: list[tuple[datetime, dict]] = []
    future_games: list[tuple[datetime, dict]] = []
    ignored_statuses = {"cancelled", "canceled", "postponed", "void", "no_game"}
    started_statuses = {"final", "completed", "live", "in_progress", "in progress"}
    for game in games:
        status = str(game.get("status") or "upcoming").strip().lower()
        if status in ignored_statuses:
            continue
        # The NPB adapter supplies a noon fallback when the official page has
        # no start time.  Never use that placeholder to trigger publication.
        if not (game.get("time_taiwan") or game.get("time_japan")):
            continue
        game_time = parse_game_datetime(game.get("game_date"))
        if game_time is None:
            continue
        if game_time.tzinfo is None:
            game_time = game_time.replace(tzinfo=TAIPEI)
        normalized_time = game_time.astimezone(TAIPEI)
        valid_games.append((normalized_time, game))
        if normalized_time > current and status not in started_statuses:
            future_games.append((normalized_time, game))

    if not valid_games:
        return {
            "due": False,
            "state": "schedule_unavailable",
            "message": "尚未取得今日 NPB 最早開賽時間。",
            "earliest_game": None,
            "minutes_to_start": None,
        }

    if not future_games:
        game_time, earliest = min(valid_games, key=lambda item: item[0])
        return {
            "due": False,
            "state": "window_closed",
            "message": "今日 NPB 已無尚未開賽場次，不會產生賽後推薦。",
            "lead_minutes": max(1, int(lead_minutes)),
            "grace_minutes": max(0, int(grace_minutes)),
            "minutes_to_start": round((game_time - current).total_seconds() / 60.0, 1),
            "earliest_game": {
                "game_pk": earliest.get("game_pk") or earliest.get("external_game_id"),
                "matchup": f'{(earliest.get("away") or {}).get("abbr") or (earliest.get("away") or {}).get("name")} @ {(earliest.get("home") or {}).get("abbr") or (earliest.get("home") or {}).get("name")}',
                "game_time_taipei": game_time.isoformat(),
                "time_taiwan": earliest.get("time_taiwan"),
            },
        }

    game_time, earliest = min(future_games, key=lambda item: item[0])
    minutes_to_start = (game_time - current).total_seconds() / 60.0
    safe_lead = max(1, int(lead_minutes))
    safe_grace = max(0, int(grace_minutes))
    effective_lead = safe_lead + safe_grace
    skipped_started_games = any(game_start <= current for game_start, _game in valid_games)
    if minutes_to_start <= effective_lead:
        state = "due"
        if skipped_started_games:
            message = f"較早場次已開賽，已改用下一場尚未開賽 NPB 的開賽前 {safe_lead} 分鐘自動發布窗。"
        else:
            message = f"已進入最早一場 NPB 開賽前 {safe_lead} 分鐘自動發布窗。"
        due = True
    else:
        state = "waiting"
        message = f"尚未進入最早一場 NPB 開賽前 {safe_lead} 分鐘自動發布窗。"
        due = False
    return {
        "due": due,
        "state": state,
        "message": message,
        "lead_minutes": safe_lead,
        "grace_minutes": safe_grace,
        "scheduler_tolerance_minutes": effective_lead,
        "recovered_after_earlier_game": skipped_started_games,
        "minutes_to_start": round(minutes_to_start, 1),
        "earliest_game": {
            "game_pk": earliest.get("game_pk") or earliest.get("external_game_id"),
            "matchup": f'{(earliest.get("away") or {}).get("abbr") or (earliest.get("away") or {}).get("name")} @ {(earliest.get("home") or {}).get("abbr") or (earliest.get("home") or {}).get("name")}',
            "game_time_taipei": game_time.isoformat(),
            "time_taiwan": earliest.get("time_taiwan"),
        },
    }


async def _pregame_refresh_loop(app: FastAPI) -> None:
    """Refresh analyses, settle records and run Asian-baseball auto fallbacks.

    MLB remains manual-only. NPB, KBO and CPBL are checked independently so an
    upstream outage in one league never prevents the others from publishing.
    """

    await asyncio.sleep(20)
    while True:
        try:
            now = datetime.now(TAIPEI)
            background_request = type("BackgroundRequest", (), {"app": app})()
            summaries = []
            for target_date in (now.date(), (now + timedelta(days=1)).date()):
                analyses = await app.state.mlb.matchup_analyses(target_date, pitcher_limit=None)
                items = analyses.get("items") or []
                summaries.append({"date": target_date.isoformat(), "games": len(items)})
                # The compact founder card stays synchronized with the settled public record.
                # The background loop refreshes MLB analyses and settlement only;
                # it must not lock an MLB pick before the later NPB slate has
                # announced starters and lineups.
            asian_auto_publish: dict[str, dict] = {}
            if app.state.records.enabled:
                for code in ("NPB", "KBO", "CPBL"):
                    policy = _asian_auto_settings(code)
                    if not (policy["free"] or policy["pro"]):
                        asian_auto_publish[code] = {
                            "free": {"published": False, "state": "disabled", "league": code},
                            "pro": {"published": False, "state": "disabled", "league": code},
                        }
                        continue
                    try:
                        free_result = await auto_publish_asian_free_pick(background_request, now.date(), code, now=now)
                        pro_result = await auto_publish_asian_pro_package(background_request, now.date(), code, now=now)
                        asian_auto_publish[code] = {"free": free_result, "pro": pro_result}
                    except (RecordsStorageError, NPBUpstreamError, AsianBaseballUpstreamError) as exc:
                        asian_auto_publish[code] = {
                            "free": {"published": False, "state": "error", "league": code, "message": type(exc).__name__},
                            "pro": {"published": False, "state": "error", "league": code, "message": type(exc).__name__},
                        }
            settlement_run = {"free_settled_now": 0, "packages_settled_now": 0}
            if app.state.records.enabled:
                settlement_run["free_settled_now"] = await _settle_pending_records_with(app.state.records, app.state.mlb, app.state.npb, app.state.kbo, app.state.cpbl, app.state.performance)
                settlement_run["packages_settled_now"] = await _settle_pending_prediction_packages_with(app.state.records, app.state.mlb, app.state.npb, app.state.kbo, app.state.cpbl, app.state.performance)
            social_run = await sync_social_publications(background_request)
            app.state.settlement_status = {
                "running": True,
                "last_run": iso_utc(),
                "last_error": None,
                **settlement_run,
            }
            app.state.pregame_status = {
                "running": True,
                "last_run": iso_utc(),
                "last_error": None,
                "interval_seconds": settings.pregame_refresh_interval_seconds,
                "dates": summaries,
                "settlement": settlement_run,
                "asian_auto_publish": asian_auto_publish,
                "npb_auto_publish": asian_auto_publish.get("NPB", {}),
                "instagram": social_run,
            }
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # background loop must never stop the API
            app.state.pregame_status = {
                "running": True,
                "last_run": iso_utc(),
                "last_error": type(exc).__name__,
                "interval_seconds": settings.pregame_refresh_interval_seconds,
            }
            app.state.settlement_status = {
                "running": True,
                "last_run": iso_utc(),
                "last_error": type(exc).__name__,
                "free_settled_now": 0,
                "packages_settled_now": 0,
            }
        await asyncio.sleep(max(300, settings.pregame_refresh_interval_seconds))


_INTERNAL_MEMBER_COPY = re.compile(
    r"(創辦人|觀察名單|觀察候選|內部審核|不(?:計入|記錄|列入|計)[^。！？]{0,16}戰績)"
)


def _member_visible_summary(value: object) -> str:
    text = str(value or "").strip()
    if not text:
        return "此推薦已正式發布並鎖定。"
    sentences = re.findall(r"[^。！？]+[。！？]?", text) or [text]
    visible = "".join(
        sentence for sentence in sentences
        if not _INTERNAL_MEMBER_COPY.search(sentence)
    ).strip()
    return visible or "此推薦已正式發布並鎖定。"


def _selection_for_member(selection: dict | None, *, founder: bool = False) -> dict | None:
    if not isinstance(selection, dict):
        return None
    result = deepcopy(selection)
    if founder:
        return result

    result["summary"] = _member_visible_summary(result.get("summary"))
    result.pop("watchlist_reasons", None)
    if result.get("candidate_tier") in {"watchlist", "founder_selected"}:
        result["candidate_tier"] = "formal"

    publication = result.get("publication")
    if isinstance(publication, dict):
        publication = deepcopy(publication)
        for key in (
            "origin_tier",
            "selection_tier",
            "promoted_from_watchlist",
            "counts_as_ai_formal",
        ):
            publication.pop(key, None)
        if publication.get("mode") == "founder_selected":
            publication["mode"] = "published"
        result["publication"] = publication

    legs = result.get("legs")
    if isinstance(legs, list):
        result["legs"] = [
            _selection_for_member(leg, founder=False) or {}
            for leg in legs
            if isinstance(leg, dict)
        ]
    return result


_MEMBER_FINANCIAL_KEYS = {
    "performance",
    "profit_units",
    "roi_percent",
    "stake_units",
    "returned_units",
    "effective_decimal_odds",
    "cumulative_profit_units",
    "daily_profit_units",
}


def _strip_member_financials(value: object) -> object:
    """Remove founder-only financial metrics from member-facing payloads."""
    if isinstance(value, dict):
        return {
            key: _strip_member_financials(item)
            for key, item in value.items()
            if key not in _MEMBER_FINANCIAL_KEYS
        }
    if isinstance(value, list):
        return [_strip_member_financials(item) for item in value]
    return value


def _free_pick_for_member(
    selection: dict | None,
    *,
    founder: bool = False,
) -> dict | None:
    """Return the compact daily-pick card payload.

    Founder/admin requests preserve the publication source marker so the UI
    can show that the locked daily pick was explicitly selected by the
    founder. Member requests still receive the same public card without
    internal publication metadata.
    """

    result = _selection_for_member(selection, founder=founder)
    if not result:
        return result
    for key in (
        "factors",
        "analysis_groups",
        "engine",
        "starting_pitchers",
        "lineups",
        "bullpen",
        "environment",
        "advanced",
        "data_sources",
        "source_status",
        "model_inputs",
    ):
        result.pop(key, None)
    game = result.get("game")
    if isinstance(game, dict):
        result["game"] = {
            key: game.get(key)
            for key in ("event_label", "season_context", "status", "detailed_status")
            if game.get(key) is not None
        }
    return result


def _public_prediction_response(payload: dict) -> dict:
    result = deepcopy(payload)
    if isinstance(result.get("selection"), dict):
        result["selection"] = _free_pick_for_member(result["selection"])
    # Unpublished candidates and publication policy are internal model review data.
    result.pop("candidate", None)
    result.pop("publication_policy", None)
    return result


def locked_prediction_from_record(
    prediction_date: date,
    record: dict,
) -> dict | None:
    snapshot = record.get("prediction_snapshot")
    if not isinstance(snapshot, dict) or not snapshot:
        return None
    snapshot = deepcopy(snapshot)
    snapshot["result"] = {
        "status": str(record.get("status") or "pending"),
        "away_score": record.get("away_score"),
        "home_score": record.get("home_score"),
        "result_note": record.get("result_note"),
        "settled_at": record.get("settled_at"),
    }
    return {
        "date": prediction_date.isoformat(),
        "published": True,
        "locked": True,
        "selection": snapshot,
        "message": "此賽事日的正式推薦已鎖定，後續更新不會更換推薦內容。",
        "meta": {
            "locked": True,
            "record_id": record.get("id"),
            "published_at": record.get("published_at"),
            "model_version": snapshot.get("model_version"),
        },
        "persistence": {
            "enabled": True,
            "stored": True,
            "created": False,
            "locked": True,
            "record_id": record.get("id"),
        },
    }


async def prediction_with_persistence(
    request: Request,
    prediction_date: date,
    *,
    publish_if_eligible: bool = True,
) -> dict:
    repository = records_repository(request)
    lookup_message = None
    if repository.enabled:
        try:
            existing = await repository.get_record_for_date(prediction_date.isoformat(), "MLB")
            if existing:
                snapshot = existing.get("prediction_snapshot")
                if isinstance(snapshot, dict):
                    try:
                        await performance_repository(request).capture_public(prediction_date.isoformat(), str(existing.get("id")), snapshot)
                    except PerformanceStorageError:
                        pass
                locked = locked_prediction_from_record(prediction_date, existing)
                if locked:
                    return locked
        except RecordsStorageError:
            # The model can still provide a result during a temporary database
            # incident, but it is clearly marked as not durably locked.
            lookup_message = "紀錄資料庫暫時無法確認今日鎖單。"

    result = await service(request).top_prediction(prediction_date)
    if result.get("published") and result.get("selection"):
        policy = publication_policy(result["selection"], automatic=True)
        if not policy["auto_publish_ready"]:
            result = {
                **result, "published": False, "selection": None,
                "candidate": result.get("selection"),
                "message": "模型已完成預覽；MLB 維持創辦人手動正式發布，不會由排程自動鎖定。",
                "publication_policy": policy,
            }
    persistence = {"enabled": repository.enabled, "stored": False}
    if lookup_message:
        persistence["message"] = lookup_message
    if result.get("published") and not publish_if_eligible:
        # A normal page view must never become the action that locks the
        # official pick. Only the protected scheduler or the founder publish
        # endpoint is allowed to create the immutable public record.
        return {
            "date": prediction_date.isoformat(),
            "published": False,
            "locked": False,
            "selection": None,
            "message": "此賽事日的 MLB 免費精選尚未發布；請由創辦人從 MLB 候選中指定後正式鎖定。",
            "meta": {
                **(result.get("meta") or {}),
                "publication_status": "pending",
            },
            "persistence": persistence,
        }
    if result.get("published") and repository.enabled:
        try:
            stored, created = await repository.publish_prediction_once(
                result["date"], result["selection"]
            )
            persistence.update(
                {
                    "stored": True,
                    "created": created,
                    "locked": True,
                    "record_id": stored.get("id"),
                }
            )
            try:
                await performance_repository(request).capture_public(result["date"], str(stored.get("id")), result["selection"])
            except PerformanceStorageError:
                persistence["snapshot_message"] = "模型快照資料表暫時無法寫入。"
            if not created:
                locked = locked_prediction_from_record(prediction_date, stored)
                if locked:
                    return locked
        except RecordsStorageError:
            # Prediction remains available even if the records database has a
            # temporary incident. It can be requested again to retry the upsert.
            persistence["message"] = "推薦已產生，但紀錄資料庫暫時無法寫入。"
    result["persistence"] = persistence
    return result


async def _settle_pending_records_with(
    repository: SupabaseRecordsRepository,
    mlb_service: MLBService,
    npb_adapter: NPBService,
    kbo_adapter: AsianBaseballService,
    cpbl_adapter: AsianBaseballService,
    performance: PerformanceRepository | None = None,
) -> int:
    if not repository.enabled:
        return 0
    records = await repository.list_records(limit=max(settings.records_limit, 100))
    pending = [
        record
        for record in records
        if str(record.get("status") or "pending") in {"pending", "void"}
        or _recent_reconciliation_candidate(record)
    ]
    settled_now = 0
    for record in pending:
        snapshot = record.get("prediction_snapshot") or {}
        league = _selection_league(snapshot if isinstance(snapshot, dict) else record)
        try:
            game = await _game_result_for_ref(mlb_service, npb_adapter, kbo_adapter, cpbl_adapter, league, str(record["game_pk"]))
        except (KeyError, MLBUpstreamError, NPBUpstreamError, AsianBaseballUpstreamError, TypeError, ValueError):
            continue
        stored_status = str(record.get("status") or "pending")
        disposition = settlement_game_disposition(record, game)
        result = settlement_for(record, game)
        settlement_payload = None
        if result:
            settlement_payload = deepcopy(result)
            stored_snapshot = record.get("prediction_snapshot")
            if isinstance(stored_snapshot, dict):
                snapshot = deepcopy(stored_snapshot)
                publication = deepcopy(snapshot.get("publication") or {})
                snapshot["status"] = "settled"
                snapshot["is_active"] = False
                publication["status"] = "settled"
                publication["is_active"] = False
                publication["settled_at"] = result.get("settled_at")
                snapshot["publication"] = publication
                settlement_payload["prediction_snapshot"] = snapshot
        else:
            stored_snapshot = record.get("prediction_snapshot")
            if isinstance(stored_snapshot, dict):
                start = _selection_start_datetime(stored_snapshot)
                lifecycle = _lifecycle_status(["pending"], [start] if start else [])
                publication = stored_snapshot.get("publication") or {}
                previous = str(stored_snapshot.get("status") or publication.get("status") or "published")
                if lifecycle == "live" and previous != "live":
                    snapshot = deepcopy(stored_snapshot)
                    updated_publication = deepcopy(publication)
                    snapshot["status"] = "live"
                    snapshot["is_active"] = True
                    updated_publication["status"] = "live"
                    updated_publication["is_active"] = True
                    snapshot["publication"] = updated_publication
                    if stored_status == "pending":
                        await repository.update_prediction_snapshot(record["game_pk"], snapshot)

        needs_reconciliation = (
            stored_status in {"won", "lost", "push", "void"}
            and not result_status_matches_disposition(stored_status, disposition)
        )
        if needs_reconciliation:
            if settlement_payload is None:
                stored_snapshot = record.get("prediction_snapshot")
                pending_snapshot = deepcopy(stored_snapshot) if isinstance(stored_snapshot, dict) else None
                if pending_snapshot is not None:
                    publication = deepcopy(pending_snapshot.get("publication") or {})
                    start = _selection_start_datetime(pending_snapshot)
                    lifecycle = _lifecycle_status(["pending"], [start] if start else [])
                    pending_snapshot["status"] = lifecycle
                    pending_snapshot["is_active"] = True
                    publication["status"] = lifecycle
                    publication["is_active"] = True
                    publication.pop("settled_at", None)
                    pending_snapshot["publication"] = publication
                settlement_payload = {
                    "status": "pending",
                    "away_score": None,
                    "home_score": None,
                    "result_note": "賽事延期或重新排程，等待官方完成後結算。",
                    "settled_at": None,
                }
                if pending_snapshot is not None:
                    settlement_payload["prediction_snapshot"] = pending_snapshot
            settled_record = await repository.reconcile_prediction(record["id"], settlement_payload)
            if settled_record and performance is not None and record.get("id") is not None:
                try:
                    await performance.reconcile_public(
                        str(record.get("id")),
                        result if result and str(result.get("status")) != "void" else None,
                    )
                except PerformanceStorageError:
                    pass
        elif stored_status == "pending":
            settled_record = await repository.settle(record["game_pk"], settlement_payload) if settlement_payload else None
        else:
            settled_record = None
        if result and settled_record:
            if str(result.get("status")) != "void" or stored_status != "void":
                settled_now += 1
            if performance is not None and stored_status != "void":
                try:
                    await performance.settle_public(str(record.get("id")), result)
                except PerformanceStorageError:
                    pass
    return settled_now


async def settle_pending_records(request: Request) -> int:
    return await _settle_pending_records_with(
        records_repository(request), service(request), npb_service(request), kbo_service(request), cpbl_service(request), performance_repository(request)
    )


def _selection_league(selection: dict) -> str:
    return str(selection.get("league") or (selection.get("game") or {}).get("league") or "MLB").upper()


def _prediction_league(value: str | None) -> str:
    league = str(value or "MLB").upper()
    if league not in {"MLB", "NPB", "KBO", "CPBL"}:
        raise HTTPException(status_code=422, detail="league must be MLB, NPB, KBO or CPBL")
    return league


def _selection_matches_league(selection: dict | None, league: str) -> bool:
    if not isinstance(selection, dict):
        return False
    legs = selection.get("legs")
    if isinstance(legs, list) and legs:
        return all(_selection_league(leg) == league for leg in legs if isinstance(leg, dict))
    return _selection_league(selection) == league


def _filter_results_for_package(results: dict | None, package: dict) -> dict:
    results = results or {}
    filtered: dict[str, list[dict]] = {}
    for group in ("moneylines", "run_lines", "totals"):
        ids = {str(item.get("candidate_id")) for item in package.get(group) or []}
        values = [item for item in results.get(group) or [] if str(item.get("candidate_id")) in ids]
        if values:
            filtered[group] = values
    for group in ("two_leg", "three_leg"):
        ids = {str(item.get("candidate_id")) for item in (package.get("parlays") or {}).get(group) or []}
        values = [item for item in results.get(group) or [] if str(item.get("candidate_id")) in ids]
        if values:
            filtered[group] = values
    return filtered


def _package_for_league(package: dict | None, league: str) -> dict | None:
    if not isinstance(package, dict):
        return None
    result = deepcopy(package)
    for group in ("moneylines", "run_lines", "totals"):
        result[group] = [item for item in package.get(group) or [] if _selection_matches_league(item, league)]
    parlays = package.get("parlays") or {}
    result["parlays"] = {
        group: [item for item in parlays.get(group) or [] if _selection_matches_league(item, league)]
        for group in ("two_leg", "three_leg")
    }
    watchlist = package.get("watchlist") or {}
    result["watchlist"] = {
        group: [item for item in watchlist.get(group) or [] if _selection_matches_league(item, league)]
        for group in ("moneylines", "run_lines", "totals")
    }
    public = package.get("moneyline")
    result["moneyline"] = public if _selection_matches_league(public, league) else None
    result["run_line"] = (result["run_lines"] or [None])[0]
    result["total"] = (result["totals"] or [None])[0]
    result["results"] = _filter_results_for_package(package.get("results") or {}, result)
    result["selected_league"] = league
    return result


def _package_has_league(package: dict | None, league: str) -> bool:
    filtered = _package_for_league(package, league)
    if not filtered:
        return False
    return any(filtered.get(group) for group in ("moneylines", "run_lines", "totals")) or any(
        (filtered.get("parlays") or {}).get(group) for group in ("two_leg", "three_leg")
    )


def _package_game_ids(package: dict | None, league: str) -> list[str]:
    """Return the immutable game references contained in one league batch."""

    filtered = _package_for_league(package, league) or {}
    game_ids: set[str] = set()
    for group in ("moneylines", "run_lines", "totals"):
        for selection in filtered.get(group) or []:
            game_pk = selection.get("game_pk")
            if game_pk is not None:
                game_ids.add(str(game_pk))
    for group in ("two_leg", "three_leg"):
        for parlay in (filtered.get("parlays") or {}).get(group) or []:
            for leg in parlay.get("legs") or []:
                game_pk = leg.get("game_pk")
                if game_pk is not None:
                    game_ids.add(str(game_pk))
    return sorted(game_ids)


def _asian_pro_package_errors(package: dict, league: str) -> list[str]:
    """Defense-in-depth validation before Asian baseball Pro persistence."""

    errors: list[str] = []
    for group in ("moneylines", "run_lines", "totals"):
        for selection in package.get(group) or []:
            if isinstance(selection, dict) and not is_asian_baseball_pro_selection(selection, league):
                errors.append(f"{group}:{selection.get('candidate_id') or selection.get('game_pk') or 'unknown'}")
    for group in ("two_leg", "three_leg"):
        for selection in (package.get("parlays") or {}).get(group) or []:
            if isinstance(selection, dict) and not is_asian_baseball_pro_selection(selection, league):
                errors.append(f"{group}:{selection.get('candidate_id') or 'unknown'}")
    return errors


def _npb_pro_package_errors(package: dict) -> list[str]:
    return _asian_pro_package_errors(package, "NPB")


def _stamp_published_package(
    package: dict,
    *,
    league: str,
    target_date: date,
    published_at: str,
) -> dict:
    """Stamp a founder-approved batch with its real publication identity.

    The database still stores one package row per target date for backwards
    compatibility, while ``league_batches`` preserves MLB and NPB as two
    independent releases.  There is deliberately no draft state: a batch is
    added only after the founder presses the formal publish button.
    """

    stamped = deepcopy(package)
    target = target_date.isoformat()
    common = {
        "target_date": target,
        "published_at": published_at,
        "status": "published",
        "is_active": True,
        "recommendation_type": "pro",
    }
    for group in ("moneylines", "run_lines", "totals"):
        stamped[group] = [
            {
                **selection,
                **common,
                "league": _selection_league(selection),
                "game_id": selection.get("game_pk"),
            }
            for selection in stamped.get(group) or []
            if isinstance(selection, dict)
        ]
    parlays = stamped.get("parlays") or {}
    for group in ("two_leg", "three_leg"):
        values: list[dict] = []
        for selection in parlays.get(group) or []:
            if not isinstance(selection, dict):
                continue
            game_ids = [
                str(leg.get("game_pk"))
                for leg in selection.get("legs") or []
                if isinstance(leg, dict) and leg.get("game_pk") is not None
            ]
            values.append({**selection, **common, "league": league, "game_ids": game_ids})
        parlays[group] = values
    stamped["parlays"] = parlays
    stamped["generated_at"] = published_at
    publication = deepcopy(stamped.get("publication") or {})
    batches = deepcopy(publication.get("league_batches") or {})
    batches[league] = {
        "league": league,
        **common,
        "game_ids": _package_game_ids(stamped, league),
    }
    publication.update(
        {
            "league": league,
            "target_date": target,
            "published_at": published_at,
            "status": "published",
            "is_active": True,
            "recommendation_type": "pro",
            "league_batches": batches,
        }
    )
    stamped["publication"] = publication
    return stamped


def _merge_league_package(existing: dict, incoming: dict, league: str) -> dict:
    # Preserve every already-published league batch except the one currently
    # being replaced. This removes the old MLB/NPB-only opposite-league rule
    # and is safe for future KBO, CPBL, NBA and EPL batches.
    merged = deepcopy(incoming)
    for group in ("moneylines", "run_lines", "totals"):
        existing_other = [
            item for item in existing.get(group) or []
            if isinstance(item, dict) and not _selection_matches_league(item, league)
        ]
        merged[group] = [*existing_other, *(incoming.get(group) or [])]
    merged["parlays"] = {
        group: [
            *[
                item for item in ((existing.get("parlays") or {}).get(group) or [])
                if isinstance(item, dict) and not _selection_matches_league(item, league)
            ],
            *((incoming.get("parlays") or {}).get(group) or []),
        ]
        for group in ("two_leg", "three_leg")
    }
    merged["watchlist"] = {
        group: [
            *[
                item for item in ((existing.get("watchlist") or {}).get(group) or [])
                if isinstance(item, dict) and not _selection_matches_league(item, league)
            ],
            *((incoming.get("watchlist") or {}).get(group) or []),
        ]
        for group in ("moneylines", "run_lines", "totals")
    }
    existing_public = existing.get("moneyline")
    merged["moneyline"] = existing_public or incoming.get("moneyline")
    merged["run_line"] = (merged["run_lines"] or [None])[0]
    merged["total"] = (merged["totals"] or [None])[0]
    publication = {**(existing.get("publication") or {}), **(incoming.get("publication") or {})}
    publication["league_batches"] = {
        **((existing.get("publication") or {}).get("league_batches") or {}),
        **((incoming.get("publication") or {}).get("league_batches") or {}),
    }
    locks = {**((existing.get("publication") or {}).get("league_locks") or {})}
    locks[league] = True
    publication["league_locks"] = locks
    publication["last_published_league"] = league
    publication["selected_counts"] = {
        "moneylines": len(merged["moneylines"]),
        "run_lines": len(merged["run_lines"]),
        "totals": len(merged["totals"]),
        "two_leg": len(merged["parlays"]["two_leg"]),
        "three_leg": len(merged["parlays"]["three_leg"]),
    }
    merged["publication"] = publication
    merged["published"] = True
    merged["locked"] = True
    merged["recommendation_status"] = "formal_published"
    merged["results"] = existing.get("results") or {}
    return merged


def _package_game_refs(record: dict) -> set[tuple[str, str]]:
    refs: set[tuple[str, str]] = set()
    package = package_from_record(record)
    for key in ("moneylines", "run_lines", "totals"):
        for selection in package.get(key) or []:
            game_pk = selection.get("game_pk")
            if game_pk is not None:
                refs.add((_selection_league(selection), str(game_pk)))
    for key in ("two_leg", "three_leg"):
        for parlay in (package.get("parlays") or {}).get(key) or []:
            for leg in parlay.get("legs") or []:
                game_pk = leg.get("game_pk")
                if game_pk is not None:
                    refs.add((_selection_league(leg), str(game_pk)))
    return refs


async def _game_result_for_ref(
    mlb_service: MLBService,
    npb_adapter: NPBService,
    kbo_adapter: AsianBaseballService,
    cpbl_adapter: AsianBaseballService,
    league: str,
    game_pk: str,
) -> dict:
    if league == "NPB":
        return await npb_adapter.game_result(game_pk)
    if league == "KBO":
        return await kbo_adapter.game_result(game_pk)
    if league == "CPBL":
        return await cpbl_adapter.game_result(game_pk)
    if league == "MLB":
        return await mlb_service.game_result(int(game_pk))
    raise ValueError(f"Settlement adapter is not enabled for {league}")


def _package_settlement_payload(record: dict, result: dict) -> dict:
    """Persist Published -> Live -> Settled metadata beside result details."""

    payload = deepcopy(result)
    if result.get("settled") is not True:
        payload["settled_at"] = None
    resolved_settled_at = result.get("settled_at") if "settled_at" in result else record.get("settled_at")
    resolved_results = result.get("results") if "results" in result else record.get("results") or {}
    updated_record = {
        **record,
        "results": resolved_results,
        "settled": bool(result.get("settled")),
        "settled_at": resolved_settled_at,
    }
    package = package_from_record(updated_record)
    thresholds = deepcopy(record.get("thresholds") or {})
    publication = deepcopy(thresholds.get("publication") or {})
    batches = deepcopy(publication.get("league_batches") or {})
    for league in LEAGUES:
        metadata = _package_publication_metadata(package, league)
        if metadata is None:
            continue
        batches[league] = {
            **(batches.get(league) or {}),
            **metadata,
        }
    if batches:
        statuses = [str(item.get("status") or "published") for item in batches.values() if isinstance(item, dict)]
        overall_status = (
            "settled"
            if statuses and all(status == "settled" for status in statuses)
            else "live"
            if any(status == "live" for status in statuses)
            else "published"
        )
        publication["league_batches"] = batches
        publication["status"] = overall_status
        publication["is_active"] = overall_status != "settled"
        if overall_status == "settled":
            publication["settled_at"] = result.get("settled_at") or iso_utc()
        else:
            publication.pop("settled_at", None)
        thresholds["publication"] = publication
        payload["thresholds"] = thresholds
    return payload


def _contains_void_result(value: object) -> bool:
    if isinstance(value, dict):
        if str(value.get("status") or "") == "void":
            return True
        return any(_contains_void_result(item) for item in value.values())
    if isinstance(value, list):
        return any(_contains_void_result(item) for item in value)
    return False


def _recent_reconciliation_candidate(record: dict, lookback_days: int = 3) -> bool:
    """Recheck recent terminal rows so old false losses can self-heal."""

    try:
        target = date.fromisoformat(str(record.get("recommendation_date") or ""))
    except ValueError:
        return False
    return target >= datetime.now(TAIPEI).date() - timedelta(days=max(1, lookback_days))


async def _settle_pending_prediction_packages_with(
    repository: SupabaseRecordsRepository,
    mlb_service: MLBService,
    npb_adapter: NPBService,
    kbo_adapter: AsianBaseballService,
    cpbl_adapter: AsianBaseballService,
    performance: PerformanceRepository | None = None,
) -> int:
    if not repository.enabled:
        return 0
    packages = await repository.list_prediction_packages(limit=max(settings.records_limit, 100))
    pending = [
        record
        for record in packages
        if record.get("settled") is not True
        or _contains_void_result(record.get("results") or {})
        or _recent_reconciliation_candidate(record)
    ]
    settled_now = 0
    for record in pending:
        package = package_from_record(record)
        publication_mode = str((package.get("publication") or {}).get("mode") or "")
        if publication_mode == "ai_auto":
            # Scheduler placeholders were never founder-approved formal picks.
            # Do not settle them or include them in model performance.
            continue
        games: dict[str, dict] = {}
        for league, game_pk in _package_game_refs(record):
            try:
                games[game_pk] = await _game_result_for_ref(mlb_service, npb_adapter, kbo_adapter, cpbl_adapter, league, game_pk)
            except (KeyError, MLBUpstreamError, NPBUpstreamError, AsianBaseballUpstreamError, TypeError, ValueError):
                continue
        reconciled_record, reopened_candidate_ids = reopen_rescheduled_package_results(record, games)
        if record.get("settled") is True and not reopened_candidate_ids:
            continue
        result = settle_prediction_package(reconciled_record, games)
        settlement_payload = _package_settlement_payload(record, result) if result else None
        if settlement_payload and reopened_candidate_ids:
            settled_package = await repository.reconcile_prediction_package(str(record["id"]), settlement_payload)
        else:
            settled_package = await repository.settle_prediction_package(str(record["id"]), settlement_payload) if settlement_payload else None
        if result and settled_package and result.get("settled") is True:
            settled_now += 1
        if result and settled_package and performance is not None:
            try:
                # Results are persisted incrementally: one postponed game must
                # not leave every other completed selection in this package as
                # a pending model snapshot.  settle_package is idempotent and
                # only advances snapshots that are still pending.
                await performance.settle_package(str(record.get("id")), result)
                if reopened_candidate_ids:
                    await performance.reconcile_package(
                        str(record.get("id")),
                        reopened_candidate_ids,
                        result,
                    )
            except PerformanceStorageError:
                pass
    return settled_now


async def settle_pending_prediction_packages(request: Request) -> int:
    return await _settle_pending_prediction_packages_with(
        records_repository(request), service(request), npb_service(request), kbo_service(request), cpbl_service(request), performance_repository(request)
    )


async def _game_results_for_refs(
    mlb_service: MLBService,
    npb_adapter: NPBService,
    kbo_adapter: AsianBaseballService,
    cpbl_adapter: AsianBaseballService,
    refs: set[tuple[str, str]],
) -> tuple[dict[str, dict], list[dict]]:
    games: dict[str, dict] = {}
    errors: list[dict] = []
    for league, game_pk in sorted(refs):
        try:
            games[game_pk] = await _game_result_for_ref(mlb_service, npb_adapter, kbo_adapter, cpbl_adapter, league, game_pk)
        except (KeyError, MLBUpstreamError, NPBUpstreamError, AsianBaseballUpstreamError, TypeError, ValueError) as exc:
            errors.append({"league": league, "game_pk": game_pk, "error": type(exc).__name__})
    return games, errors


async def settlement_dashboard(
    repository: SupabaseRecordsRepository,
    mlb_service: MLBService,
    npb_adapter: NPBService,
    kbo_adapter: AsianBaseballService,
    cpbl_adapter: AsianBaseballService,
    target_date: date,
) -> dict:
    if not repository.enabled:
        return {
            "date": target_date.isoformat(),
            "database": "not_configured",
            "public": None,
            "public_items": [],
            "package": None,
            "summary": {"total": 0, "pending": 0, "settled": 0, "won": 0, "lost": 0, "push": 0, "void": 0},
            "errors": [],
        }
    public_records = await repository.list_records_for_date(target_date.isoformat())
    package_record = await repository.get_prediction_package_for_date(target_date.isoformat())
    refs: set[tuple[str, str]] = set()
    for public_record in public_records:
        if public_record.get("game_pk") is None:
            continue
        snapshot = public_record.get("prediction_snapshot") or {}
        league = str(
            public_record.get("league")
            or (_selection_league(snapshot) if isinstance(snapshot, dict) else "MLB")
        ).upper()
        refs.add((league if league in {"MLB", "NPB", "KBO", "CPBL"} else "MLB", str(public_record.get("game_pk"))))
    if package_record:
        refs.update(_package_game_refs(package_record))
    games, errors = await _game_results_for_refs(mlb_service, npb_adapter, kbo_adapter, cpbl_adapter, refs)
    public_previews = [
        preview
        for public_record in public_records
        if (
            preview := preview_public_record(
                public_record,
                games.get(str(public_record.get("game_pk"))) if public_record.get("game_pk") is not None else None,
            )
        ) is not None
    ]
    package_preview = preview_prediction_package(package_record, games)
    statuses: list[str] = []
    statuses.extend(
        str((public_preview.get("preview") or {}).get("status") or "pending")
        for public_preview in public_previews
    )
    if package_preview:
        for values in (package_preview.get("groups") or {}).values():
            statuses.extend(str(item.get("status") or "pending") for item in values)
    summary = {
        "total": len(statuses),
        "pending": statuses.count("pending"),
        "won": statuses.count("won"),
        "lost": statuses.count("lost"),
        "push": statuses.count("push"),
        "void": statuses.count("void"),
    }
    summary["settled"] = summary["total"] - summary["pending"]
    return {
        "date": target_date.isoformat(),
        "database": "connected",
        # Keep the singular alias for older front ends; current clients render
        # both league-specific free recommendations from public_items.
        "public": public_previews[0] if public_previews else None,
        "public_items": public_previews,
        "package": package_preview,
        "summary": summary,
        "games": games,
        "errors": errors,
        "updated_at": iso_utc(),
    }


async def locked_or_generated_market_package(
    request: Request,
    target_date: date,
    public_prediction: dict,
    odds_feed: dict,
    *,
    persist: bool = True,
) -> dict:
    repository = records_repository(request)
    if repository.enabled:
        try:
            existing = await repository.get_prediction_package_for_date(target_date.isoformat())
            if existing:
                existing_package = package_from_record(existing)
                try:
                    await performance_repository(request).capture_package(target_date.isoformat(), str(existing.get("id")), existing_package)
                except PerformanceStorageError:
                    pass
                return existing_package
        except RecordsStorageError:
            existing = None

    analyses = await service(request).matchup_analyses(target_date, pitcher_limit=None)
    eligible_analyses = [
        item
        for item in analyses["items"]
        if (item.get("game") or {}).get("auto_recommendation_eligible") is True
        and publication_policy(item, automatic=False)["can_publish"]
        and (((item.get("analysis_groups") or {}).get("starter") or {}).get("both_starters_ready") is True)
    ]
    bundle = build_daily_market_candidates(
        target_date.isoformat(),
        eligible_analyses,
        odds_feed.get("items") or [],
        public_prediction.get("selection") if public_prediction.get("published") else None,
        minimum_probability=settings.min_market_probability,
        minimum_edge=settings.min_market_edge,
        minimum_projection_quality=settings.min_projection_quality,
        minimum_parlay_probability=settings.min_parlay_leg_probability,
    )
    npb_feed = {"items": [], "meta": {"fresh_for_model": False, "status": "unavailable"}}
    if odds_service(request).enabled:
        try:
            fetched_npb_feed = await odds_service(request).odds_for_date(
                target_date,
                sport_key=settings.npb_odds_sport_key,
            )
            npb_feed = fetched_npb_feed
        except OddsUpstreamError:
            pass
    npb_candidates = await npb_market_candidates_for_date(
        request,
        target_date,
        (npb_feed.get("items") or [])
        if (npb_feed.get("meta") or {}).get("fresh_for_model")
        else [],
        pro_only=True,
    )
    bundle = merge_market_candidates(
        bundle,
        npb_candidates,
        minimum_parlay_probability=settings.min_parlay_leg_probability,
    )
    bundle.setdefault("odds_feeds", {})["NPB"] = {
        "sport_key": settings.npb_odds_sport_key,
        "count": int(npb_feed.get("count") or 0),
        "fresh_for_model": bool((npb_feed.get("meta") or {}).get("fresh_for_model")),
        "cache": (npb_feed.get("meta") or {}).get("cache"),
    }
    package = build_selected_market_package(bundle, publication_mode="ai_auto")
    package["persistence"] = {"enabled": repository.enabled, "stored": False}
    if package["published"] and repository.enabled and persist:
        try:
            stored, created = await repository.publish_prediction_package_once(
                target_date.isoformat(), package
            )
            locked = package_from_record(stored)
            locked["persistence"] = {
                "enabled": True,
                "stored": True,
                "created": created,
                "record_id": stored.get("id"),
            }
            try:
                await performance_repository(request).capture_package(target_date.isoformat(), str(stored.get("id")), package)
            except PerformanceStorageError:
                locked["persistence"]["snapshot_message"] = "模型快照資料表暫時無法寫入。"
            return locked
        except RecordsStorageError:
            package["persistence"]["message"] = "會員玩法已產生，但資料表尚未完成設定或暫時無法寫入。"
    elif package["published"] and not persist:
        package["persistence"] = {
            "enabled": repository.enabled,
            "stored": False,
            "mode": "founder_approval_required",
        }
        package["message"] = "候選已產生，等待創辦人正式發布；排程不會自動建立 Pro 紀錄。"
    return package


@app.get("/")
async def root() -> dict:
    return {
        "name": settings.app_name,
        "version": APP_VERSION,
        "status": "online",
        "sports_schema_version": SPORTS_SCHEMA_VERSION,
        "docs": "/docs",
        "health": f"{settings.api_prefix}/health",
    }


@app.get(f"{settings.api_prefix}/health")
async def health() -> dict:
    return {
        "ok": True,
        "service": settings.app_name,
        "version": APP_VERSION,
        "environment": settings.app_env,
        "records_database": "configured" if settings.records_enabled else "not_configured",
        "odds_feed": "configured" if settings.odds_enabled else "not_configured",
        "daily_scheduler": "configured" if settings.scheduler_enabled else "not_configured",
        "pregame_refresh": "running",
        "settlement_monitor": "running",
        "operations_monitor": getattr(app.state, "operations_monitor_status", {}).get("status", "starting"),
        "billing": "configured" if settings.billing_enabled else "not_configured",
        "billing_mode": settings.ecpay_mode if settings.billing_enabled else None,
        "announcements": "configured" if settings.records_enabled else "not_configured",
        "model_performance": "configured" if settings.records_enabled else "not_configured",
        "new_member_trial": "enabled" if settings.new_member_trial_enabled else "disabled",
        "new_member_trial_hours": settings.new_member_trial_hours if settings.new_member_trial_enabled else 0,
        "npb_auto_publish": "enabled" if settings.npb_auto_publish_enabled else "disabled",
        "npb_pro_auto_publish": "enabled" if settings.npb_pro_auto_publish_enabled else "disabled",
        "npb_auto_publish_lead_minutes": settings.npb_auto_publish_lead_minutes,
        "npb_auto_publish_scheduler_grace_minutes": settings.npb_auto_publish_scheduler_grace_minutes,
        "kbo_auto_publish": "enabled" if settings.kbo_auto_publish_enabled else "disabled",
        "kbo_pro_auto_publish": "enabled" if settings.kbo_pro_auto_publish_enabled else "disabled",
        "kbo_auto_publish_lead_minutes": settings.kbo_auto_publish_lead_minutes,
        "cpbl_auto_publish": "enabled" if settings.cpbl_auto_publish_enabled else "disabled",
        "cpbl_pro_auto_publish": "enabled" if settings.cpbl_pro_auto_publish_enabled else "disabled",
        "cpbl_auto_publish_lead_minutes": settings.cpbl_auto_publish_lead_minutes,
        "mlb_auto_publish": "disabled",
        "instagram_auto_publish": "enabled" if getattr(app.state, "social", None) and app.state.social.enabled else "awaiting_configuration" if settings.instagram_auto_publish_enabled else "disabled",
        "instagram_graph_version": settings.instagram_graph_version,
        "sports_schema_version": SPORTS_SCHEMA_VERSION,
        "sports": {code: item["status"] for code, item in ((value["code"], value) for value in registered_sports_catalog())},
        "leagues": {code: LEAGUES[code]["status"] for code in LEAGUES},
        "active_leagues": list(ACTIVE_LEAGUES),
        "time_taiwan": datetime.now(TAIPEI).isoformat(),
    }

@app.get(f"{settings.api_prefix}/admin/operations/status")
async def admin_operations_status(
    request: Request,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    """Founder-only launch readiness and runtime monitor.

    The endpoint is intentionally read-only and does not alter predictions,
    settlements, memberships or payment state.
    """

    await admin_member(request, authorization)
    pregame = dict(getattr(request.app.state, "pregame_status", {}) or {})
    settlement = dict(getattr(request.app.state, "settlement_status", {}) or {})
    operations = dict(getattr(request.app.state, "operations_monitor_status", {}) or {})
    social_monitor = dict(getattr(request.app.state, "social_status", {}) or {})
    social_config = social_service(request).status()
    odds = odds_service(request).status()
    billing = billing_service(request)

    official_settlement_check = _official_settlement_verification_check([])
    if settings.records_enabled:
        try:
            official_records = await records_repository(request).list_records(
                limit=max(settings.records_limit, 100)
            )
            official_settlement_check = _official_settlement_verification_check(official_records)
        except RecordsStorageError:
            official_settlement_check.update({
                "status": "warning",
                "detail": "暫時無法讀取正式推薦紀錄，請重新整理後再檢查",
            })

    checks = [
        {
            "key": "records_database",
            "label": "Supabase 資料庫",
            "status": "pass" if settings.records_enabled else "fail",
            "detail": "推薦、會員、公告與模型資料庫已設定" if settings.records_enabled else "缺少 Supabase 連線設定",
            "blocking": True,
        },
        {
            "key": "odds_feed",
            "label": "真實盤口來源",
            "status": "pass" if settings.odds_enabled else "warning",
            "detail": "Odds API 已設定" if settings.odds_enabled else "未設定 Odds API，正式 Pro 玩法會被阻擋",
            "blocking": True,
        },
        {
            "key": "scheduler",
            "label": "排程密鑰",
            "status": "pass" if settings.scheduler_enabled else "warning",
            "detail": "伺服器排程驗證已設定" if settings.scheduler_enabled else "缺少 CRON_SECRET，外部排程無法安全觸發",
            "blocking": True,
        },
        {
            "key": "billing",
            "label": "付款服務",
            "status": "pass" if billing.enabled else "fail",
            "detail": f"綠界 {settings.ecpay_mode} 模式已設定" if billing.enabled else "付款服務設定不完整",
            "blocking": True,
        },
        {
            "key": "payment_live",
            "label": "正式收款模式",
            "status": "pass" if settings.ecpay_mode == "production" and billing.enabled else "pending",
            "detail": "已切換綠界正式環境" if settings.ecpay_mode == "production" and billing.enabled else "目前維持測試環境，正式收費前再切換",
            "blocking": False,
        },
        {
            "key": "support_channel",
            "label": "客服聯絡管道",
            "status": "pass" if settings.support_email else "pending",
            "detail": settings.support_email or "尚未設定 SUPPORT_EMAIL",
            "blocking": False,
        },
        {
            "key": "instagram_auto_publish",
            "label": "Instagram 全自動發佈",
            "status": "pass" if social_config["enabled"] else "pending",
            "detail": "貼文與限時動態已啟用全自動發佈" if social_config["enabled"] else "程式已就緒，等待在 Render 設定 Meta 帳號編號與權杖",
            "blocking": False,
        },
        official_settlement_check,
    ]
    blocking_failures = [item for item in checks if item.get("blocking") and item.get("status") != "pass"]
    monitor_errors = [value for value in (pregame.get("last_error"), settlement.get("last_error")) if value]
    monitor_errors.extend(
        str(item.get("detail") or item.get("label") or "operations_monitor")
        for item in (operations.get("critical_issues") or [])
    )
    overall = "attention" if blocking_failures or monitor_errors else "stage_ready"
    return {
        "ok": not bool(blocking_failures),
        "overall": overall,
        "version": APP_VERSION,
        "environment": settings.app_env,
        "generated_at": datetime.now(TAIPEI).isoformat(),
        "runtime_started_at": getattr(request.app.state, "started_at", None),
        "services": {
            "records_database": settings.records_enabled,
            "odds_feed": settings.odds_enabled,
            "scheduler": settings.scheduler_enabled,
            "billing": billing.enabled,
            "billing_mode": settings.ecpay_mode,
            "billing_live": settings.ecpay_mode == "production" and billing.enabled,
            "support_email": settings.support_email or None,
            "public_api_base": settings.public_api_base,
            "frontend_base_url": settings.frontend_base_url,
            "odds_status": odds,
            "instagram": social_config,
        },
        "monitors": {
            "pregame": pregame,
            "settlement": settlement,
            "operations": operations,
            "instagram": social_monitor,
        },
        "checks": checks,
        "blocking_failures": len(blocking_failures),
        "monitor_errors": monitor_errors,
    }


class AnnouncementPayload(BaseModel):
    title: str = Field(min_length=1, max_length=120)
    body: str = Field(min_length=1, max_length=6000)
    summary: str | None = Field(default=None, max_length=320)
    severity: str = Field(default="general", pattern="^(general|important|emergency)$")
    audience: str = Field(default="all", pattern="^(all|free|pro)$")
    show_home: bool = True
    show_login_modal: bool = True
    dismissible_today: bool = True
    action_label: str | None = Field(default=None, max_length=40)
    action_page: str | None = Field(default=None, pattern="^(|homePage|gamesPage|predictionPage|recordsPage|membershipPage|morePage)$")
    starts_at: datetime | None = None
    ends_at: datetime | None = None
    is_active: bool = True
    priority: int | None = Field(default=None, ge=0, le=999)


@app.get(f"{settings.api_prefix}/announcements/active")
async def active_announcements(
    request: Request,
    placement: str = Query(default="home", pattern="^(home|login)$"),
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    member = await optional_member(request, authorization)
    try:
        items = await announcement_service(request).active(role=str(member.get("role") or "guest"), placement=placement)
        return {"items": items, "placement": placement, "role": member.get("role"), "updated_at": iso_utc()}
    except AnnouncementError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


@app.get(f"{settings.api_prefix}/admin/announcements")
async def admin_announcements(
    request: Request,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    await admin_member(request, authorization)
    try:
        return {"items": await announcement_service(request).admin_list(), "updated_at": iso_utc()}
    except AnnouncementError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


@app.post(f"{settings.api_prefix}/admin/announcements")
async def admin_create_announcement(
    request: Request,
    payload: AnnouncementPayload,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    actor = await admin_member(request, authorization)
    try:
        return {"ok": True, "announcement": await announcement_service(request).create(payload.model_dump(), actor)}
    except AnnouncementError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc


@app.patch(f"{settings.api_prefix}/admin/announcements/{{announcement_id}}")
async def admin_update_announcement(
    request: Request,
    announcement_id: str,
    payload: AnnouncementPayload,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    actor = await admin_member(request, authorization)
    try:
        return {"ok": True, "announcement": await announcement_service(request).update(announcement_id, payload.model_dump(), actor)}
    except AnnouncementError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc


@app.delete(f"{settings.api_prefix}/admin/announcements/{{announcement_id}}")
async def admin_delete_announcement(
    request: Request,
    announcement_id: str,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    await admin_member(request, authorization)
    try:
        await announcement_service(request).delete(announcement_id)
        return {"ok": True, "deleted": announcement_id}
    except AnnouncementError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc


class BillingCheckout(BaseModel):
    plan: str = Field(pattern="^(monthly|quarterly|annual)$")


@app.get(f"{settings.api_prefix}/billing/config", response_class=JSONResponse)
async def billing_config(request: Request) -> JSONResponse:
    # Keep an explicit UTF-8 charset for mobile browsers and use ASCII-only
    # gateway item names so the ECPay page cannot display mojibake.
    return JSONResponse(
        content=billing_service(request).public_config(),
        media_type="application/json; charset=utf-8",
    )


@app.get(f"{settings.api_prefix}/billing/status")
async def billing_member_status(
    request: Request,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    member = await authenticated_member(request, authorization)
    if member.get("role") == "admin":
        return {
            "active": True,
            "status": "founder",
            "plan": "founder",
            "auto_renew": False,
            "current_period_end": None,
            "mode": settings.ecpay_mode,
        }
    try:
        return await billing_service(request).member_status(member)
    except BillingError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


@app.post(f"{settings.api_prefix}/billing/checkout")
async def billing_checkout(
    request: Request,
    command: BillingCheckout,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    member = await authenticated_member(request, authorization)
    try:
        return await billing_service(request).create_checkout(member, command.plan)
    except BillingError as exc:
        message = str(exc)
        status = 409 if "already exists" in message.lower() else 403 if "restricted" in message.lower() else 503
        raise HTTPException(status_code=status, detail=message) from exc


@app.post(f"{settings.api_prefix}/billing/cancel")
async def billing_cancel(
    request: Request,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    member = await authenticated_member(request, authorization)
    try:
        return await billing_service(request).cancel(member)
    except BillingError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc


@app.post(f"{settings.api_prefix}/billing/ecpay/return", response_class=PlainTextResponse)
async def billing_ecpay_return(request: Request) -> PlainTextResponse:
    payload = parse_form_body(await request.body())
    try:
        await billing_service(request).process_callback(payload, event_type="initial_payment")
        return PlainTextResponse("1|OK")
    except BillingError as exc:
        return PlainTextResponse(f"0|{str(exc)[:120]}")


@app.post(f"{settings.api_prefix}/billing/ecpay/result", response_class=HTMLResponse)
async def billing_ecpay_result(request: Request) -> HTMLResponse:
    payload = parse_form_body(await request.body())
    return HTMLResponse(billing_service(request).result_redirect_html(payload))


@app.post(f"{settings.api_prefix}/membership/trial/claim")
async def membership_trial_claim(
    request: Request,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    member = await authenticated_member(request, authorization)
    try:
        return await member_trial_service(request).claim(member)
    except NewMemberTrialError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    except BillingError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


class AdminMembershipCommandPayload(BaseModel):
    action: str = Field(pattern="^(grant|extend|cancel)$")
    plan: str | None = Field(default=None, pattern="^(trial_1d|gift_3d|gift_7d|monthly|quarterly|annual|custom)$")
    note: str | None = Field(default=None, max_length=300)
    custom_expires_at: str | None = Field(default=None, max_length=64)


@app.get(f"{settings.api_prefix}/admin/members")
async def admin_members(
    request: Request,
    query: str = Query(default="", max_length=120),
    role: str = Query(default="all", pattern="^(all|free|pro|admin)$"),
    status: str = Query(default="all", pattern="^(all|free|active|pending|expired|canceled|payment_failed|refunded|founder)$"),
    limit: int = Query(default=50, ge=1, le=200),
    offset: int = Query(default=0, ge=0),
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    await admin_member(request, authorization)
    try:
        return await membership_admin_service(request).overview(
            query=query, role=role, status=status, limit=limit, offset=offset
        )
    except (BillingError, AdminMembershipError) as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


@app.get(f"{settings.api_prefix}/admin/members/{{user_id}}")
async def admin_member_detail(
    request: Request,
    user_id: str,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    await admin_member(request, authorization)
    try:
        return await membership_admin_service(request).member_detail(user_id)
    except (BillingError, AdminMembershipError) as exc:
        raise HTTPException(status_code=404 if "invalid member" in str(exc).lower() else 503, detail=str(exc)) from exc


@app.post(f"{settings.api_prefix}/admin/members/{{user_id}}/membership")
async def admin_member_membership(
    request: Request,
    user_id: str,
    payload: AdminMembershipCommandPayload,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    actor = await admin_member(request, authorization)
    try:
        return await membership_admin_service(request).apply_command(
            actor=actor,
            target_user_id=user_id,
            command=AdminMemberCommand(action=payload.action, plan=payload.plan, note=payload.note, custom_expires_at=payload.custom_expires_at),
        )
    except AdminMembershipError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    except BillingError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


@app.get(f"{settings.api_prefix}/admin/transactions")
async def admin_transactions(
    request: Request,
    query: str = Query(default="", max_length=120),
    result: str = Query(default="all", pattern="^(all|success|failed)$"),
    limit: int = Query(default=100, ge=1, le=200),
    offset: int = Query(default=0, ge=0),
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    await admin_member(request, authorization)
    try:
        return await membership_admin_service(request).transactions(
            query=query, result=result, limit=limit, offset=offset
        )
    except (BillingError, AdminMembershipError) as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


@app.get(f"{settings.api_prefix}/admin/export/members.csv")
async def admin_export_members_csv(
    request: Request,
    query: str = Query(default="", max_length=120),
    role: str = Query(default="all", pattern="^(all|free|pro|admin)$"),
    status: str = Query(default="all", pattern="^(all|free|active|pending|expired|canceled|payment_failed|refunded|founder)$"),
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> Response:
    await admin_member(request, authorization)
    try:
        members = await membership_admin_service(request).export_members(
            query=query, role=role, status=status
        )
    except (BillingError, AdminMembershipError) as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    rows = [
        {
            "會員ID": item.get("id"),
            "Email": item.get("email"),
            "暱稱": item.get("name"),
            "角色": item.get("role"),
            "狀態": item.get("status"),
            "方案": item.get("plan"),
            "到期日": item.get("pro_expires_at") or item.get("current_period_end"),
            "註冊時間": item.get("created_at"),
            "最後登入": item.get("last_sign_in_at"),
            "付款來源": item.get("provider"),
            "最近交易編號": item.get("merchant_trade_no"),
        }
        for item in members
    ]
    fields = ["會員ID", "Email", "暱稱", "角色", "狀態", "方案", "到期日", "註冊時間", "最後登入", "付款來源", "最近交易編號"]
    return _csv_response("diamondmind_members.csv", fields, rows)


@app.get(f"{settings.api_prefix}/admin/export/transactions.csv")
async def admin_export_transactions_csv(
    request: Request,
    query: str = Query(default="", max_length=120),
    result: str = Query(default="all", pattern="^(all|success|failed)$"),
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> Response:
    await admin_member(request, authorization)
    try:
        transactions = await membership_admin_service(request).export_transactions(
            query=query, result=result
        )
    except (BillingError, AdminMembershipError) as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    rows = [
        {
            "時間": item.get("created_at"),
            "Email": item.get("email"),
            "結果": "成功" if item.get("success") else "失敗",
            "金額TWD": item.get("amount"),
            "平台": item.get("provider"),
            "商店交易編號": item.get("merchant_trade_no"),
            "金流交易編號": item.get("provider_trade_no"),
            "付款方式": item.get("payment_type"),
            "事件類型": item.get("event_type"),
            "訊息": item.get("rtn_msg"),
        }
        for item in transactions
    ]
    fields = ["時間", "Email", "結果", "金額TWD", "平台", "商店交易編號", "金流交易編號", "付款方式", "事件類型", "訊息"]
    return _csv_response("diamondmind_transactions.csv", fields, rows)


@app.get(f"{settings.api_prefix}/odds/status")
async def odds_status(request: Request) -> dict:
    # These status payloads never expose either provider key.
    primary = odds_service(request).status()
    return {**primary, "cpbl_fallback": odds_api_io_service(request).status()}


@app.get(f"{settings.api_prefix}/odds/cpbl/diagnostics")
async def cpbl_odds_diagnostics(
    request: Request,
    target_date: date | None = Query(default=None, alias="date"),
) -> dict:
    """Probe CPBL coverage without exposing the API key.

    Results are cached by the provider adapter, so repeated browser refreshes do
    not repeatedly consume the free quota.
    """
    target = requested_date(target_date)
    adapter = odds_api_io_service(request)
    if not adapter.enabled:
        return {"ok": False, "date": target.isoformat(), **adapter.status()}
    try:
        feed = await adapter.odds_for_cpbl_date(target)
    except OddsApiIoUpstreamError as exc:
        return {"ok": False, "date": target.isoformat(), **adapter.status(), "error": str(exc)}
    meta = feed.get("meta") or {}
    return {
        "ok": True,
        "date": target.isoformat(),
        "status": adapter.status(),
        "count": feed.get("count", 0),
        "coverage_status": meta.get("coverage_status"),
        "coverage": meta.get("coverage") or {},
        "bookmakers": meta.get("bookmaker_results") or [],
        "batches": meta.get("batch_results") or [],
        "cache": meta.get("cache_diagnostics") or {},
        "meta": meta,
        "events": [
            {
                "event_id": item.get("event_id"),
                "away_team": item.get("away_team"),
                "home_team": item.get("home_team"),
                "time_taiwan": item.get("time_taiwan"),
                "markets": sorted((item.get("markets") or {}).keys()),
            }
            for item in feed.get("items") or []
        ],
    }


@app.get(f"{settings.api_prefix}/advanced/status")
async def advanced_status(
    request: Request,
    season: int = Query(default=datetime.now(TAIPEI).year, ge=2015, le=2100),
) -> dict:
    """Public, non-sensitive Statcast source diagnostic."""
    return await service(request).statcast.diagnostics(season)


@app.get(f"{settings.api_prefix}/pregame/status")
async def pregame_status(request: Request) -> dict:
    return {
        **(getattr(request.app.state, "pregame_status", {}) or {}),
        "lineup_watch_minutes": settings.pregame_lineup_watch_minutes,
        "final_lock_minutes": settings.pregame_final_lock_minutes,
        "minimum_publish_data_quality": settings.minimum_publish_data_quality,
        "minimum_lineup_validation_rate": settings.minimum_lineup_validation_rate,
        "settlement_monitor": getattr(request.app.state, "settlement_status", {}) or {},
    }


@app.get(f"{settings.api_prefix}/admin/settlement/status")
async def admin_settlement_status(
    request: Request,
    target_date: date | None = Query(default=None, alias="date"),
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    await admin_member(request, authorization)
    try:
        dashboard = await settlement_dashboard(
            records_repository(request), service(request), npb_service(request), kbo_service(request), cpbl_service(request), requested_date(target_date)
        )
    except RecordsStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    dashboard["monitor"] = getattr(request.app.state, "settlement_status", {}) or {}
    return dashboard


@app.post(f"{settings.api_prefix}/admin/settlement/run")
async def admin_run_settlement(
    request: Request,
    target_date: date | None = Query(default=None, alias="date"),
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    actor = await admin_member(request, authorization)
    try:
        free_count = await settle_pending_records(request)
        package_count = await settle_pending_prediction_packages(request)
        social = await sync_social_publications(request)
        dashboard = await settlement_dashboard(
            records_repository(request), service(request), npb_service(request), kbo_service(request), cpbl_service(request), requested_date(target_date)
        )
    except RecordsStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    request.app.state.settlement_status = {
        "running": True,
        "last_run": iso_utc(),
        "last_error": None,
        "free_settled_now": free_count,
        "packages_settled_now": package_count,
        "social": social,
        "manual_by": actor.get("email"),
    }
    return {
        "ok": True,
        "free_settled_now": free_count,
        "packages_settled_now": package_count,
        "social": social,
        "dashboard": dashboard,
        "message": "已重新向 MLB／NPB／KBO／CPBL 官方資料檢查所有待結算推薦。",
    }




async def sync_existing_model_snapshots(request: Request) -> dict:
    """Idempotently backfill snapshots for recommendations published before this release."""

    records = records_repository(request)
    performance = performance_repository(request)
    if not records.enabled or not performance.enabled:
        return {"public": 0, "packages": 0}
    public_count = 0
    package_count = 0
    try:
        public_rows = await records.list_records(limit=1000)
        pending_packages = await records.list_pending_prediction_packages()
        settled_packages = await records.list_settled_prediction_packages(limit=1000)
    except RecordsStorageError:
        return {"public": 0, "packages": 0}
    seen_packages: dict[str, dict] = {}
    for item in [*pending_packages, *settled_packages]:
        if item.get("id") is not None:
            seen_packages[str(item.get("id"))] = item
    for record in public_rows:
        selection = record.get("prediction_snapshot")
        if not isinstance(selection, dict) or not record.get("id"):
            continue
        try:
            await performance.capture_public(str(record.get("recommendation_date")), str(record.get("id")), selection)
            if str(record.get("status")) in {"won", "lost", "push", "void"}:
                await performance.settle_public(str(record.get("id")), {
                    "status": record.get("status"),
                    "away_score": record.get("away_score"),
                    "home_score": record.get("home_score"),
                    "result_note": record.get("result_note"),
                    "settled_at": record.get("settled_at") or iso_utc(),
                })
            public_count += 1
        except PerformanceStorageError:
            break
    for record_id, record in seen_packages.items():
        try:
            package = package_from_record(record)
            publication_mode = str((package.get("publication") or {}).get("mode") or "")
            if publication_mode == "ai_auto":
                continue
            await performance.capture_package(str(record.get("recommendation_date")), record_id, package)
            # Backfill every result already present in a partially settled
            # package.  Waiting for record.settled=True kept all snapshots
            # pending whenever one postponed selection remained open.
            await performance.settle_package(record_id, {"results": record.get("results") or {}})
            package_count += 1
        except PerformanceStorageError:
            break
    return {"public": public_count, "packages": package_count}


class ModelWeightCommand(BaseModel):
    weights: dict[str, float]
    note: str | None = Field(default=None, max_length=500)
    confirm: bool = False


class ModelTestSettlementCommand(BaseModel):
    recommendation_date: date
    market: str = Field(pattern="^(moneyline|run_line|totals)$")
    pick_side: str = Field(pattern="^(home|away|over|under)$")
    line: float | None = None
    away_score: int = Field(ge=0, le=99)
    home_score: int = Field(ge=0, le=99)
    confidence: float = Field(default=65.0, ge=50, le=99.9)
    data_quality: float = Field(default=0.75, ge=0, le=1)
    module_edges: dict[str, float] = Field(default_factory=dict)


def _performance_range_days(value: str) -> int | None:
    return {"7d": 7, "30d": 30, "season": None}.get(value, 30)


@app.get(f"{settings.api_prefix}/admin/model/performance")
async def admin_model_performance(
    request: Request,
    range_value: str = Query(default="30d", alias="range", pattern="^(7d|30d|season)$"),
    market: str = Query(default="all", pattern="^(all|moneyline|run_line|totals|two_leg|three_leg)$"),
    source_type: str = Query(default="all", pattern="^(all|public|pro)$"),
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    await admin_member(request, authorization)
    backfill = await sync_existing_model_snapshots(request)
    try:
        dashboard = await performance_repository(request).performance_dashboard(
            days=_performance_range_days(range_value), market=market, source_type=source_type
        )
    except PerformanceStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    dashboard["range"] = range_value
    dashboard["backfill"] = backfill
    dashboard["model_runtime_weights"] = normalize_weights(service(request).model_weights)
    return dashboard


@app.get(f"{settings.api_prefix}/admin/model/snapshots")
async def admin_model_snapshots(
    request: Request,
    range_value: str = Query(default="30d", alias="range", pattern="^(7d|30d|season)$"),
    market: str = Query(default="all", pattern="^(all|moneyline|run_line|totals|two_leg|three_leg)$"),
    source_type: str = Query(default="all", pattern="^(all|public|pro|test)$"),
    include_test: bool = Query(default=False),
    limit: int = Query(default=250, ge=1, le=2000),
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    await admin_member(request, authorization)
    await sync_existing_model_snapshots(request)
    try:
        items = await performance_repository(request).list_snapshots(
            days=_performance_range_days(range_value),
            include_test=include_test,
            market=market,
            source_type=source_type,
            limit=limit,
        )
    except PerformanceStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    return {"items": items, "count": len(items), "range": range_value, "updated_at": iso_utc()}


@app.post(f"{settings.api_prefix}/admin/model/calibration/apply")
async def admin_apply_model_calibration(
    request: Request,
    command: ModelWeightCommand,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    actor = await admin_member(request, authorization)
    if not command.confirm:
        raise HTTPException(status_code=409, detail="套用模型權重前必須再次確認。")
    unknown = sorted(set(command.weights) - set(DEFAULT_MODEL_WEIGHTS))
    if unknown:
        raise HTTPException(status_code=422, detail=f"未知模型模組：{', '.join(unknown)}")
    normalized = normalize_weights(command.weights)
    try:
        profile = await performance_repository(request).activate_weights(
            weights=normalized,
            actor_id=str(actor.get("id")),
            note=command.note,
        )
    except PerformanceStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    service(request).model_weights = normalized
    return {
        "ok": True,
        "weights": normalized,
        "profile": profile,
        "message": "新模型權重已啟用；後續新分析會使用這組權重，已發布推薦不會被改寫。",
    }


@app.post(f"{settings.api_prefix}/admin/model/test-settlement")
async def admin_model_test_settlement(
    request: Request,
    command: ModelTestSettlementCommand,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    actor = await admin_member(request, authorization)
    if command.market in {"moneyline", "run_line"} and command.pick_side not in {"away", "home"}:
        raise HTTPException(status_code=422, detail="獨贏與讓分測試必須選擇客隊或主隊。")
    if command.market == "totals" and command.pick_side not in {"over", "under"}:
        raise HTTPException(status_code=422, detail="大小分測試必須選擇大分或小分。")
    if command.market in {"run_line", "totals"} and command.line is None:
        raise HTTPException(status_code=422, detail="讓分與大小分測試必須輸入盤口。")

    pick_team_id = 1 if command.pick_side == "away" else 2 if command.pick_side == "home" else None
    side_zh = {"away": "客隊", "home": "主隊", "over": "大", "under": "小"}[command.pick_side]
    selection = {
        "candidate_id": f"test:{command.market}:{command.recommendation_date.isoformat()}:{iso_utc()}",
        "game_pk": 0,
        "market": command.market,
        "pick": {
            "market": command.market,
            "side": command.pick_side,
            "team_id": pick_team_id,
            "line": command.line,
            "label": f"{side_zh}{'' if command.line is None else f' {command.line:g}'}",
        },
    }
    game = {
        "status": "Final",
        "detailed_status": "Final",
        "away": {"id": 1, "score": command.away_score},
        "home": {"id": 2, "score": command.home_score},
    }
    result = settle_market_selection(selection, game)
    if not result:
        raise HTTPException(status_code=422, detail="測試條件無法產生結算結果。")
    analysis_groups = {
        key: {
            "edge_home": float(command.module_edges.get(key, 0.0)),
            "quality": 1.0,
            "available": True,
        }
        for key in DEFAULT_MODEL_WEIGHTS
    }
    try:
        snapshot = await performance_repository(request).create_test_snapshot({
            "recommendation_date": command.recommendation_date.isoformat(),
            "market": command.market,
            "pick_side": command.pick_side,
            "pick_label": selection["pick"]["label"],
            "line": command.line,
            "confidence": command.confidence,
            "data_quality": command.data_quality,
            "weights": service(request).model_weights or DEFAULT_MODEL_WEIGHTS,
            "analysis_groups": analysis_groups,
            "result": result,
        })
    except PerformanceStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    return {
        "ok": True,
        "test": True,
        "result": result,
        "snapshot": snapshot,
        "created_by": actor.get("email"),
        "message": "測試推薦已完成發布、鎖定、結算與快照紀錄；不會出現在公開紀錄或真實績效。",
    }


@app.get(f"{settings.api_prefix}/admin/model/export/snapshots.csv")
async def admin_export_model_snapshots(
    request: Request,
    range_value: str = Query(default="season", alias="range", pattern="^(7d|30d|season)$"),
    include_test: bool = Query(default=False),
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> Response:
    await admin_member(request, authorization)
    try:
        rows = await performance_repository(request).list_snapshots(
            days=_performance_range_days(range_value), include_test=include_test, limit=5000
        )
    except PerformanceStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    output = []
    for item in rows:
        modules = item.get("module_scores") or {}
        output.append({
            "日期": item.get("recommendation_date"),
            "來源": item.get("source_type"),
            "玩法": item.get("market"),
            "推薦": item.get("pick_label"),
            "信心": item.get("confidence"),
            "資料完整度": item.get("data_quality"),
            "盤口": item.get("line"),
            "價格": item.get("price"),
            "結果": item.get("status"),
            "單位盈虧": ((item.get("result") or {}).get("performance") or {}).get("profit_units"),
            "單筆ROI": ((item.get("result") or {}).get("performance") or {}).get("roi_percent"),
            "測試資料": item.get("is_test"),
            "先發分數": (modules.get("starter") or {}).get("edge_for_pick"),
            "打線分數": (modules.get("lineup") or {}).get("edge_for_pick"),
            "牛棚分數": (modules.get("bullpen") or {}).get("edge_for_pick"),
            "球隊實力分數": (modules.get("team_strength") or {}).get("edge_for_pick"),
            "進階數據分數": (modules.get("advanced") or {}).get("edge_for_pick"),
            "環境分數": (modules.get("environment") or {}).get("edge_for_pick"),
            "模型版本": item.get("model_version"),
            "發布時間": item.get("created_at"),
            "結算時間": item.get("settled_at"),
        })
    fields = ["日期", "來源", "玩法", "推薦", "信心", "資料完整度", "盤口", "價格", "結果", "單位盈虧", "單筆ROI", "測試資料", "先發分數", "打線分數", "牛棚分數", "球隊實力分數", "進階數據分數", "環境分數", "模型版本", "發布時間", "結算時間"]
    return _csv_response("diamondmind_model_snapshots.csv", fields, output)


@app.get(f"{settings.api_prefix}/admin/model/export/performance.csv")
async def admin_export_model_performance(
    request: Request,
    range_value: str = Query(default="season", alias="range", pattern="^(7d|30d|season)$"),
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> Response:
    await admin_member(request, authorization)
    try:
        dashboard = await performance_repository(request).performance_dashboard(
            days=_performance_range_days(range_value), market="all", source_type="all"
        )
    except PerformanceStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    rows = []
    for group_name, items in (("玩法", dashboard.get("by_market") or []), ("聯盟", dashboard.get("by_league") or []), ("信心區間", dashboard.get("by_confidence") or []), ("來源", dashboard.get("by_source") or [])):
        for item in items:
            rows.append({
                "分類": group_name,
                "項目": item.get("key"),
                "總數": item.get("total"),
                "有效決策": item.get("decisions"),
                "命中": item.get("won"),
                "未中": item.get("lost"),
                "走水": item.get("push"),
                "作廢": item.get("void"),
                "等待": item.get("pending"),
                "命中率": item.get("hit_rate"),
                "有效投注單位": item.get("stake_units"),
                "累計盈虧單位": item.get("profit_units"),
                "ROI": item.get("roi_percent"),
            })
    fields = ["分類", "項目", "總數", "有效決策", "命中", "未中", "走水", "作廢", "等待", "命中率", "有效投注單位", "累計盈虧單位", "ROI"]
    return _csv_response("diamondmind_model_performance.csv", fields, rows)


@app.get(f"{settings.api_prefix}/sports")
async def sports_catalog() -> dict:
    return {
        "schema_version": SPORTS_SCHEMA_VERSION,
        "default_sport": "baseball",
        "items": registered_sports_catalog(),
    }


@app.get(f"{settings.api_prefix}/markets/catalog")
async def market_catalog(
    sport: str | None = Query(default=None),
    league: str | None = Query(default=None),
) -> dict:
    if not sport and not league:
        raise HTTPException(status_code=422, detail="sport or league is required")
    try:
        return registered_market_catalog(sport=sport, league=league)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.get(f"{settings.api_prefix}/leagues")
async def league_catalog() -> dict:
    return {
        "schema_version": SPORTS_SCHEMA_VERSION,
        "default": "MLB",
        "active": list(ACTIVE_LEAGUES),
        "items": registered_league_catalog(),
    }


@app.get(f"{settings.api_prefix}/leagues/{{league}}/capabilities")
async def league_capabilities(league: str) -> dict:
    try:
        code = normalize_league_code(league)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    item = dict(LEAGUES[code])
    item["market_catalog"] = registered_market_catalog(league=code)["items"]
    item["foundation_ready"] = True
    item["adapter_enabled"] = code in ACTIVE_LEAGUES
    return item


@app.get(f"{settings.api_prefix}/leagues/summary")
async def league_summary(
    request: Request,
    response: Response,
    game_date: date | None = Query(default=None, alias="date", description="Taiwan date, YYYY-MM-DD"),
) -> dict:
    response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
    response.headers["Pragma"] = "no-cache"
    response.headers["Expires"] = "0"
    target_date = requested_date(game_date)
    mlb_result, npb_result = await asyncio.gather(
        service(request).games_for_date(target_date),
        npb_service(request).games_for_date(target_date),
        return_exceptions=True,
    )

    def summarize(code: str, payload: object, status: str) -> dict:
        if isinstance(payload, Exception):
            return {"code": code, "status": status, "available": False, "count": None, "upcoming": 0, "live": 0, "final": 0}
        data = payload if isinstance(payload, dict) else {}
        items = data.get("items") or data.get("dates") or []
        if code == "MLB" and data.get("dates"):
            games = []
            for day in data.get("dates") or []:
                games.extend(day.get("games") or [])
            items = games
        normalized = [item for item in items if isinstance(item, dict)]
        def state(item: dict) -> str:
            value = str(item.get("status") or (item.get("status") or {}).get("abstractGameState") or "").lower()
            detailed = str(item.get("detailed_status") or (item.get("status") or {}).get("detailedState") or "").lower()
            if "final" in value or "final" in detailed or "game over" in detailed:
                return "final"
            if value in {"live", "in progress"} or "progress" in detailed:
                return "live"
            return "upcoming"
        states = [state(item) for item in normalized]
        return {
            "code": code,
            "status": status,
            "available": True,
            "count": len(normalized),
            "upcoming": states.count("upcoming"),
            "live": states.count("live"),
            "final": states.count("final"),
        }

    return {
        "date": target_date.isoformat(),
        "items": [
            summarize("MLB", mlb_result, LEAGUES["MLB"]["status"]),
            summarize("NPB", npb_result, LEAGUES["NPB"]["status"]),
            *[
                {
                    "code": code,
                    "sport": sport_for_league(code),
                    "status": LEAGUES[code]["status"],
                    "available": False,
                    "count": None,
                    "upcoming": 0,
                    "live": 0,
                    "final": 0,
                }
                for code in ("KBO", "CPBL", "NBA", "EPL")
            ],
        ],
    }


@app.get(f"{settings.api_prefix}/games")
async def multi_league_games(
    request: Request,
    league: str = Query(default="MLB", min_length=3, max_length=4),
    game_date: date | None = Query(default=None, alias="date", description="Taiwan date, YYYY-MM-DD"),
) -> dict:
    code = league.strip().upper()
    target_date = requested_date(game_date)
    try:
        if code == "MLB":
            payload = await service(request).games_for_date(target_date)
            return {**payload, "league": "MLB"}
        if code == "NPB":
            return await npb_service(request).games_for_date(target_date)
        if code == "KBO":
            return await kbo_service(request).games_for_date(target_date)
        if code == "CPBL":
            return await cpbl_service(request).games_for_date(target_date)
        if code in {"NBA", "EPL"}:
            raise HTTPException(
                status_code=501,
                detail={
                    "message": f"{code} adapter is not enabled yet",
                    "sport": sport_for_league(code),
                    "foundation_ready": True,
                    "status": LEAGUES[code]["status"],
                },
            )
        raise HTTPException(status_code=400, detail="Unsupported league")
    except MLBUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    except (NPBUpstreamError, AsianBaseballUpstreamError) as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    except AsianBaseballUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@app.get(f"{settings.api_prefix}/events")
async def generic_events(
    request: Request,
    league: str = Query(default="MLB", min_length=3, max_length=4),
    game_date: date | None = Query(default=None, alias="date", description="Taiwan date, YYYY-MM-DD"),
) -> dict:
    try:
        code = normalize_league_code(league)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    if code not in ACTIVE_LEAGUES:
        raise HTTPException(
            status_code=501,
            detail={
                "message": f"{code} event adapter is pending",
                "sport": sport_for_league(code),
                "foundation_ready": True,
            },
        )
    target_date = requested_date(game_date)
    try:
        if code == "MLB":
            payload = await service(request).games_for_date(target_date)
        elif code == "NPB":
            payload = await npb_service(request).games_for_date(target_date)
        elif code == "KBO":
            payload = await kbo_service(request).games_for_date(target_date)
        else:
            payload = await cpbl_service(request).games_for_date(target_date)
    except (MLBUpstreamError, NPBUpstreamError, AsianBaseballUpstreamError) as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    source_items = [item for item in payload.get("items") or [] if isinstance(item, dict)]
    return {
        "schema_version": SPORTS_SCHEMA_VERSION,
        "sport": sport_for_league(code),
        "league": code,
        "date": target_date.isoformat(),
        "count": len(source_items),
        "items": [normalize_event(item, code, target_date) for item in source_items],
        "meta": payload.get("meta") or {},
    }


@app.get(f"{settings.api_prefix}/npb/standings")
async def npb_standings(
    request: Request,
    season: int = Query(default=datetime.now(TAIPEI).year, ge=1936, le=2100),
) -> dict:
    try:
        return await npb_service(request).standings_for_season(season)
    except NPBUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@app.get(f"{settings.api_prefix}/npb/games")
async def npb_games(
    request: Request,
    game_date: date | None = Query(default=None, alias="date", description="Taiwan date, YYYY-MM-DD"),
) -> dict:
    try:
        return await npb_service(request).games_for_date(requested_date(game_date))
    except NPBUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@app.get(f"{settings.api_prefix}/npb/games/{{game_pk}}")
async def npb_game_detail(
    request: Request,
    game_pk: str,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    member = await optional_member(request, authorization)
    try:
        detail = await npb_service(request).game_detail(game_pk)
        if not member.get("has_pro_access"):
            locked = locked_game_detail(detail, member)
            locked["meta"] = {
                "source": "NPB.jp official data",
                "updated_at": (detail.get("meta") or {}).get("updated_at"),
                "analysis_payload_returned": False,
            }
            return locked
        detail["access"] = {
            "role": member.get("role") or "pro",
            "has_pro_access": True,
            "required_plan": "pro",
        }
        return detail
    except NPBUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@app.get(f"{settings.api_prefix}/kbo/games")
async def kbo_games(
    request: Request,
    game_date: date | None = Query(default=None, alias="date", description="Taiwan date, YYYY-MM-DD"),
) -> dict:
    try:
        return await kbo_service(request).games_for_date(requested_date(game_date))
    except AsianBaseballUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@app.get(f"{settings.api_prefix}/kbo/games/{{game_pk}}")
async def kbo_game_detail(
    request: Request,
    game_pk: str,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    member = await optional_member(request, authorization)
    try:
        detail = await kbo_service(request).game_detail(game_pk)
        if not member.get("has_pro_access"):
            return locked_game_detail(detail, member)
        return {**detail, "analysis_locked": False, "access": {"role": member.get("role"), "has_pro_access": True, "required_plan": "pro"}}
    except AsianBaseballUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@app.get(f"{settings.api_prefix}/cpbl/games")
async def cpbl_games(
    request: Request,
    game_date: date | None = Query(default=None, alias="date", description="Taiwan date, YYYY-MM-DD"),
) -> dict:
    try:
        return await cpbl_service(request).games_for_date(requested_date(game_date))
    except AsianBaseballUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@app.get(f"{settings.api_prefix}/cpbl/games/{{game_pk}}")
async def cpbl_game_detail(
    request: Request,
    game_pk: str,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    member = await optional_member(request, authorization)
    try:
        detail = await cpbl_service(request).game_detail(game_pk)
        if not member.get("has_pro_access"):
            return locked_game_detail(detail, member)
        return {**detail, "analysis_locked": False, "access": {"role": member.get("role"), "has_pro_access": True, "required_plan": "pro"}}
    except AsianBaseballUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@app.get(f"{settings.api_prefix}/mlb/games")
async def mlb_games(
    request: Request,
    game_date: date | None = Query(default=None, alias="date", description="Taiwan date, YYYY-MM-DD"),
) -> dict:
    try:
        return await service(request).games_for_date(requested_date(game_date))
    except MLBUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@app.get(f"{settings.api_prefix}/mlb/games/{{game_pk}}")
async def mlb_game_detail(
    request: Request,
    game_pk: int,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    member = await optional_member(request, authorization)
    try:
        detail = await service(request).game_detail(game_pk)
        if not member.get("has_pro_access"):
            return locked_game_detail(detail, member)
        return {
            **detail,
            "analysis_locked": False,
            "access": {
                "role": member.get("role"),
                "has_pro_access": True,
                "required_plan": "pro",
            },
        }
    except KeyError as exc:
        raise HTTPException(status_code=404, detail="Game not found") from exc
    except MLBUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


_TERMINAL_RECOMMENDATION_RESULTS = {"won", "lost", "push", "void"}


def _publication_datetime(value: object) -> datetime | None:
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(str(value).strip().replace("Z", "+00:00"))
    except (TypeError, ValueError):
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=TAIPEI)
    return parsed.astimezone(TAIPEI)


def _selection_start_datetime(selection: dict | None) -> datetime | None:
    if not isinstance(selection, dict):
        return None
    legs = selection.get("legs")
    if isinstance(legs, list) and legs:
        starts = [
            value
            for value in (_selection_start_datetime(leg) for leg in legs if isinstance(leg, dict))
            if value is not None
        ]
        return min(starts) if starts else None
    game = selection.get("game") or {}
    for value in (
        selection.get("game_date"),
        selection.get("start_at"),
        game.get("game_date"),
        game.get("start_at"),
    ):
        parsed = _publication_datetime(value)
        if parsed is not None:
            return parsed
    return None


def _selection_schedule_metadata(selection: dict | None) -> dict:
    if not isinstance(selection, dict):
        return {
            "time_taiwan": None,
            "display_time_taiwan": None,
            "game_label": "",
            "game_number": None,
            "is_doubleheader": False,
        }
    game = selection.get("game") or {}
    time_taiwan = selection.get("time_taiwan") or game.get("time_taiwan")
    return {
        "time_taiwan": time_taiwan,
        "display_time_taiwan": selection.get("display_time_taiwan")
        or game.get("display_time_taiwan")
        or (f"台灣 {time_taiwan}" if time_taiwan else None),
        "game_label": selection.get("game_label") or game.get("game_label") or "",
        "game_number": selection.get("game_number")
        if selection.get("game_number") is not None
        else game.get("game_number"),
        "is_doubleheader": bool(selection.get("is_doubleheader") or game.get("is_doubleheader")),
    }


def _lifecycle_status(
    result_statuses: list[str],
    starts: list[datetime],
    *,
    now: datetime | None = None,
) -> str:
    statuses = [str(value or "pending").lower() for value in result_statuses]
    if statuses and all(value in _TERMINAL_RECOMMENDATION_RESULTS for value in statuses):
        return "settled"
    current = now or datetime.now(TAIPEI)
    if any(value <= current for value in starts):
        return "live"
    return "published"


def _record_publication_metadata(record: dict, league: str) -> dict | None:
    snapshot = record.get("prediction_snapshot")
    if not isinstance(snapshot, dict) or not _selection_matches_league(snapshot, league):
        return None
    publication = snapshot.get("publication") or {}
    target_date = str(
        snapshot.get("target_date")
        or publication.get("target_date")
        or record.get("recommendation_date")
        or ""
    )
    published_at = str(
        snapshot.get("published_at")
        or publication.get("published_at")
        or record.get("published_at")
        or ""
    )
    result_status = str(record.get("status") or "pending").lower()
    start = _selection_start_datetime(snapshot)
    status = _lifecycle_status([result_status], [start] if start else [])
    return {
        "league": league,
        "target_date": target_date,
        "published_at": published_at,
        "status": status,
        "is_active": status != "settled",
        "game_id": str(record.get("game_pk") or snapshot.get("game_pk") or ""),
        "game_ids": [str(record.get("game_pk") or snapshot.get("game_pk") or "")],
        "recommendation_type": "free_pick",
        "result_status": result_status,
    }


def _package_result_for_selection(
    package: dict,
    group: str,
    selection: dict,
    index: int,
) -> dict:
    values = ((package.get("results") or {}).get(group) or [])
    candidate_id = str(selection.get("candidate_id") or "")
    if candidate_id:
        matched = next(
            (
                item
                for item in values
                if isinstance(item, dict) and str(item.get("candidate_id") or "") == candidate_id
            ),
            None,
        )
        if matched:
            return matched
        # Formal results are sparse while games finish at different times.
        # Never borrow another selection's result by array position when this
        # selection has its own stable candidate id.
        return {"status": "pending"}
    return values[index] if index < len(values) and isinstance(values[index], dict) else {"status": "pending"}


def _package_entries(package: dict, league: str) -> list[tuple[str, dict, dict]]:
    filtered = _package_for_league(package, league) or {}
    entries: list[tuple[str, dict, dict]] = []
    for group in ("moneylines", "run_lines", "totals"):
        for index, selection in enumerate(filtered.get(group) or []):
            if isinstance(selection, dict):
                entries.append((group, selection, _package_result_for_selection(filtered, group, selection, index)))
    for group in ("two_leg", "three_leg"):
        for index, selection in enumerate((filtered.get("parlays") or {}).get(group) or []):
            if isinstance(selection, dict):
                entries.append((group, selection, _package_result_for_selection(filtered, group, selection, index)))
    return entries


def _package_publication_metadata(package: dict, league: str) -> dict | None:
    entries = _package_entries(package, league)
    if not entries:
        return None
    publication = package.get("publication") or {}
    batches = publication.get("league_batches") or {}
    stored = batches.get(league) if isinstance(batches, dict) else {}
    stored = stored if isinstance(stored, dict) else {}
    target_date = str(stored.get("target_date") or package.get("target_date") or package.get("date") or "")
    published_at = str(
        stored.get("published_at")
        or publication.get("published_at")
        or package.get("published_at")
        or package.get("generated_at")
        or ""
    )
    statuses = [str(result.get("status") or "pending") for _group, _selection, result in entries]
    starts = [
        value
        for value in (_selection_start_datetime(selection) for _group, selection, _result in entries)
        if value is not None
    ]
    status = _lifecycle_status(statuses, starts)
    return {
        "league": league,
        "target_date": target_date,
        "published_at": published_at,
        "status": status,
        "is_active": status != "settled",
        "game_ids": _package_game_ids(package, league),
        "recommendation_type": "pro",
    }


def _published_sort_key(metadata: dict | None) -> tuple[datetime, str]:
    metadata = metadata or {}
    parsed = _publication_datetime(metadata.get("published_at"))
    return parsed or datetime.min.replace(tzinfo=TAIPEI), str(metadata.get("target_date") or "")


def _latest_record_for_league(records: list[dict], league: str) -> tuple[dict | None, dict | None]:
    candidates = [
        (record, metadata)
        for record in records
        if (metadata := _record_publication_metadata(record, league)) is not None
    ]
    return max(candidates, key=lambda item: _published_sort_key(item[1])) if candidates else (None, None)


def _latest_package_for_league(records: list[dict], league: str) -> tuple[dict | None, dict | None, dict | None]:
    candidates: list[tuple[dict, dict, dict]] = []
    for record in records:
        package = package_from_record(record)
        if str((package.get("publication") or {}).get("mode") or "") == "ai_auto":
            continue
        metadata = _package_publication_metadata(package, league)
        if metadata is not None:
            candidates.append((record, package, metadata))
    return max(candidates, key=lambda item: _published_sort_key(item[2])) if candidates else (None, None, None)


def _free_feed_row(record: dict, league: str) -> dict | None:
    metadata = _record_publication_metadata(record, league)
    snapshot = record.get("prediction_snapshot")
    if metadata is None or not isinstance(snapshot, dict):
        return None
    result = _record_result_payload(record) or {"status": "pending"}
    return {
        **metadata,
        **_selection_schedule_metadata(snapshot),
        "matchup": record.get("matchup") or snapshot.get("matchup"),
        "pick_label": record.get("pick_label") or (snapshot.get("pick") or {}).get("label"),
        "market": record.get("market") or (snapshot.get("pick") or {}).get("market") or "moneyline",
        "confidence": record.get("confidence") if record.get("confidence") is not None else snapshot.get("confidence"),
        "start_at": (_selection_start_datetime(snapshot) or "").isoformat() if _selection_start_datetime(snapshot) else None,
        "result": result,
        "result_status": str(result.get("status") or "pending"),
    }


def _package_feed_rows(package: dict, league: str) -> list[dict]:
    metadata = _package_publication_metadata(package, league)
    if metadata is None:
        return []
    rows: list[dict] = []
    for group, selection, result in _package_entries(package, league):
        legs = [leg for leg in selection.get("legs") or [] if isinstance(leg, dict)]
        matchup = selection.get("matchup") or " ＋ ".join(str(leg.get("matchup") or "") for leg in legs if leg.get("matchup"))
        pick_label = (selection.get("pick") or {}).get("label") or selection.get("label")
        if not pick_label and legs:
            pick_label = " ＋ ".join(str((leg.get("pick") or {}).get("label") or "") for leg in legs)
        result_status = str(result.get("status") or "pending").lower()
        start = _selection_start_datetime(selection)
        item_status = _lifecycle_status([result_status], [start] if start else [])
        game_ids = [
            str(leg.get("game_pk"))
            for leg in legs
            if leg.get("game_pk") is not None
        ] or ([str(selection.get("game_pk"))] if selection.get("game_pk") is not None else [])
        if legs:
            leg_schedule = [
                value
                for value in (
                    _selection_schedule_metadata(leg).get("display_time_taiwan")
                    for leg in legs
                )
                if value
            ]
            schedule_metadata = {
                "time_taiwan": None,
                "display_time_taiwan": " / ".join(leg_schedule) if leg_schedule else None,
                "game_label": "",
                "game_number": None,
                "is_doubleheader": any(_selection_schedule_metadata(leg).get("is_doubleheader") for leg in legs),
            }
        else:
            schedule_metadata = _selection_schedule_metadata(selection)
        rows.append(
            {
                **metadata,
                **schedule_metadata,
                "status": item_status,
                "is_active": item_status != "settled",
                "recommendation_type": f"pro_{group}",
                "game_id": game_ids[0] if len(game_ids) == 1 else None,
                "game_ids": game_ids,
                "matchup": matchup,
                "pick_label": pick_label,
                "market": group,
                "confidence": selection.get("model_probability") if selection.get("model_probability") is not None else selection.get("confidence"),
                "price": selection.get("price") if selection.get("price") is not None else selection.get("combined_american_odds"),
                "start_at": start.isoformat() if start else None,
                "result": result,
                "result_status": result_status,
            }
        )
    return rows


def _social_free_payload(record: dict) -> dict:
    snapshot = record.get("prediction_snapshot") or {}
    game = snapshot.get("game") or {}
    pick = snapshot.get("pick") or {}
    away = game.get("away") or {}
    home = game.get("home") or {}
    away_name = display_team(
        away.get("name") or record.get("away_team_name"),
        away.get("abbr") or record.get("away_team_abbr"),
    )
    home_name = display_team(
        home.get("name") or record.get("home_team_name"),
        home.get("abbr") or record.get("home_team_abbr"),
    )
    pick_name = display_team(
        pick.get("team_name") or record.get("pick_team_name"),
        pick.get("abbr") or record.get("pick_team_abbr"),
    )
    away_score = record.get("away_score")
    home_score = record.get("home_score")
    score = None
    if away_score is not None and home_score is not None:
        score = f"{away_name} {away_score}：{home_score} {home_name}"
    raw_price = (
        pick.get("decimal_odds")
        or snapshot.get("decimal_odds")
        or pick.get("price")
        or snapshot.get("price")
    )
    return {
        "matchup": f"{away_name} vs {home_name}",
        "away_name": away_name,
        "home_name": home_name,
        "pick_team_name": pick_name,
        "pick_team_abbr": pick.get("abbr") or record.get("pick_team_abbr"),
        "pick_label": pick.get("label") or record.get("pick_label"),
        "market": pick.get("market") or record.get("market") or "moneyline",
        "line": pick.get("line") if pick.get("line") is not None else snapshot.get("line"),
        "side": pick.get("side") or snapshot.get("side"),
        "confidence": record.get("confidence") if record.get("confidence") is not None else snapshot.get("confidence"),
        "price": raw_price,
        "status": str(record.get("status") or "pending").lower(),
        "score": score,
        "time_label": snapshot.get("display_time_taiwan") or snapshot.get("time_taiwan"),
        "venue": record.get("venue") or game.get("venue"),
    }


def _social_selection_label(selection: dict, market: str) -> str:
    legs = [item for item in selection.get("legs") or [] if isinstance(item, dict)]
    if legs:
        values = [_social_selection_label(item, str((item.get("pick") or {}).get("market") or "moneyline")) for item in legs]
        return " ＋ ".join(value for value in values if value)
    pick = selection.get("pick") or {}
    payload = {
        "pick_label": pick.get("label") or selection.get("label"),
        "market": pick.get("market") or selection.get("market") or market,
        "pick_team_name": pick.get("team_name") or pick.get("team"),
        "pick_team_abbr": pick.get("abbr"),
        "line": pick.get("line") if pick.get("line") is not None else selection.get("line"),
        "side": pick.get("side") or selection.get("side"),
    }
    return compact_pick_label(payload)


def _social_selection_game_payload(selection: dict) -> dict | None:
    if not isinstance(selection, dict) or selection.get("legs"):
        return None
    game = selection.get("game") or {}
    away = game.get("away") or selection.get("away") or {}
    home = game.get("home") or selection.get("home") or {}
    away_name = display_team(
        away.get("name") or selection.get("away_team_name"),
        away.get("abbr") or selection.get("away_team_abbr"),
    )
    home_name = display_team(
        home.get("name") or selection.get("home_team_name"),
        home.get("abbr") or selection.get("home_team_abbr"),
    )
    matchup = str(selection.get("matchup") or game.get("matchup") or "").strip()
    if not matchup or matchup == "待確認 vs 待確認":
        matchup = f"{away_name} vs {home_name}"
    schedule = _selection_schedule_metadata(selection)
    confidence = (
        selection.get("model_probability")
        if selection.get("model_probability") is not None
        else selection.get("confidence")
    )
    game_id = selection.get("game_pk") or game.get("game_pk") or game.get("id")
    return {
        "game_id": str(game_id) if game_id is not None else None,
        "matchup": matchup,
        "time_label": schedule.get("display_time_taiwan") or schedule.get("time_taiwan"),
        "confidence": confidence,
        "start_at": (_selection_start_datetime(selection).isoformat() if _selection_start_datetime(selection) else None),
    }


def _social_pro_games(package: dict, league: str) -> list[dict]:
    selected = _package_for_league(package, league) or {}
    games: dict[str, dict] = {}
    order: list[str] = []
    selections: list[dict] = []
    for group in ("moneylines", "run_lines", "totals"):
        selections.extend(item for item in selected.get(group) or [] if isinstance(item, dict))
    for group in ("two_leg", "three_leg"):
        for parlay in (selected.get("parlays") or {}).get(group) or []:
            selections.extend(item for item in parlay.get("legs") or [] if isinstance(item, dict))
    for selection in selections:
        item = _social_selection_game_payload(selection)
        if not item:
            continue
        key = item.get("game_id") or item.get("matchup") or f"row-{len(order)}"
        if key not in games:
            games[key] = item
            order.append(key)
            continue
        existing = games[key]
        try:
            new_conf = float(item.get("confidence"))
        except (TypeError, ValueError):
            new_conf = -1.0
        try:
            old_conf = float(existing.get("confidence"))
        except (TypeError, ValueError):
            old_conf = -1.0
        if new_conf > old_conf:
            existing["confidence"] = item.get("confidence")
        if not existing.get("time_label") and item.get("time_label"):
            existing["time_label"] = item.get("time_label")
        if not existing.get("start_at") and item.get("start_at"):
            existing["start_at"] = item.get("start_at")
    values = [games[key] for key in order]
    values.sort(key=lambda item: str(item.get("start_at") or "9999"))
    return values


def _social_pro_page_count(package: dict, league: str, batch_size: int = 5) -> int:
    count = len(_social_pro_games(package, league))
    return max(1, math.ceil(count / max(1, batch_size))) if count else 0


def _social_category_summary(package: dict, league: str) -> tuple[dict, dict, dict]:
    categories = {
        "moneylines": {"won": 0, "lost": 0, "neutral": 0, "pending": 0},
        "run_lines": {"won": 0, "lost": 0, "neutral": 0, "pending": 0},
        "totals": {"won": 0, "lost": 0, "neutral": 0, "pending": 0},
        "parlays": {"won": 0, "lost": 0, "neutral": 0, "pending": 0},
    }
    overall = {"won": 0, "lost": 0, "neutral": 0, "pending": 0}
    parlay = {"won": 0, "lost": 0, "neutral": 0, "two_leg_odds": None, "three_leg_odds": None}
    odds_values: dict[str, list[float]] = {"two_leg": [], "three_leg": []}
    for group, selection, settlement in _package_entries(package, league):
        category = "parlays" if group in {"two_leg", "three_leg"} else group
        status = str(settlement.get("status") or "pending").lower()
        bucket = "neutral" if status in {"push", "void"} else status if status in {"won", "lost"} else "pending"
        categories[category][bucket] += 1
        overall[bucket] += 1
        if category == "parlays":
            parlay[bucket if bucket in {"won", "lost", "neutral"} else "neutral"] += 1 if bucket != "pending" else 0
            raw_odds = (
                selection.get("combined_decimal_odds")
                or selection.get("decimal_odds")
                or selection.get("combined_american_odds")
                or selection.get("price")
            )
            converted = decimal_price(raw_odds)
            if converted:
                odds_values[group].append(converted)
    for item in categories.values():
        decided = int(item["won"]) + int(item["lost"])
        item["hit_rate"] = round(int(item["won"]) / decided * 100, 1) if decided else None
    if odds_values["two_leg"]:
        parlay["two_leg_odds"] = f"{max(odds_values['two_leg']):.2f}"
    if odds_values["three_leg"]:
        parlay["three_leg_odds"] = f"{max(odds_values['three_leg']):.2f}"
    return categories, overall, parlay


def _social_score_text(selection: dict, settlement: dict) -> str:
    for value in (
        settlement.get("score"),
        settlement.get("final_score"),
        (settlement.get("result") or {}).get("score") if isinstance(settlement.get("result"), dict) else None,
    ):
        if value:
            return str(value)

    game = selection.get("game") or {}
    settled_game = settlement.get("game") or {}
    away = game.get("away") or selection.get("away") or {}
    home = game.get("home") or selection.get("home") or {}
    away_name = display_team(
        away.get("name") or selection.get("away_team_name"),
        away.get("abbr") or selection.get("away_team_abbr"),
    )
    home_name = display_team(
        home.get("name") or selection.get("home_team_name"),
        home.get("abbr") or selection.get("home_team_abbr"),
    )
    away_score = next(
        (
            value
            for value in (
                settlement.get("away_score"),
                settled_game.get("away_score"),
                ((settlement.get("linescore") or {}).get("away") if isinstance(settlement.get("linescore"), dict) else None),
                game.get("away_score"),
            )
            if value is not None
        ),
        None,
    )
    home_score = next(
        (
            value
            for value in (
                settlement.get("home_score"),
                settled_game.get("home_score"),
                ((settlement.get("linescore") or {}).get("home") if isinstance(settlement.get("linescore"), dict) else None),
                game.get("home_score"),
            )
            if value is not None
        ),
        None,
    )
    if away_score is not None and home_score is not None:
        return f"{away_name} {away_score}：{home_score} {home_name}"
    if selection.get("legs"):
        return "串關依各腿最終賽果完成結算"
    return "官方最終賽果已完成結算"


def _social_free_result_payload(record: dict | None) -> dict:
    if not record:
        return {}
    status = str(record.get("status") or "pending").lower()
    payload = _social_free_payload(record)
    return {
        "label": f"{payload.get('matchup') or '每日免費推薦'}｜{compact_pick_label(payload)}",
        "status": status,
        "status_label": status_label(status),
    }


def _social_free_result_item(record: dict | None) -> dict | None:
    if not record:
        return None
    status = str(record.get("status") or "pending").lower()
    if status not in SOCIAL_TERMINAL_STATUSES:
        return None
    payload = _social_free_payload(record)
    snapshot = record.get("prediction_snapshot") or {}
    return {
        "source": "free",
        "candidate_id": f"free:{record.get('id') or record.get('game_pk') or payload.get('matchup')}",
        "market": payload.get("market") or "moneyline",
        "label": compact_pick_label(payload),
        "matchup": payload.get("matchup") or "每日免費推薦",
        "score": payload.get("score") or _social_score_text(snapshot, record),
        "status": status,
        "status_label": status_label(status),
        "confidence": payload.get("confidence"),
        "time_label": payload.get("time_label"),
        "price": payload.get("price"),
    }


def _social_result_items(package: dict, league: str, free_record: dict | None = None) -> list[dict]:
    items: list[dict] = []
    seen: set[tuple[str, str]] = set()
    free_item = _social_free_result_item(free_record)
    if free_item:
        items.append(free_item)
        seen.add((str(free_item.get("matchup") or ""), str(free_item.get("label") or "")))

    for group, selection, settlement in _package_entries(package, league):
        status = str(settlement.get("status") or "pending").lower()
        if status not in SOCIAL_TERMINAL_STATUSES:
            continue
        legs = [leg for leg in selection.get("legs") or [] if isinstance(leg, dict)]
        if legs:
            matchup = " ＋ ".join(str(leg.get("matchup") or "") for leg in legs if leg.get("matchup"))
            if not matchup:
                matchup = "多場串關"
        else:
            game_payload = _social_selection_game_payload(selection) or {}
            matchup = str(selection.get("matchup") or game_payload.get("matchup") or "賽事對戰")
        label = _social_selection_label(selection, group)
        identity = (matchup, label)
        if identity in seen:
            continue
        seen.add(identity)
        items.append(
            {
                "source": "pro",
                "candidate_id": str(selection.get("candidate_id") or f"{group}:{len(items)}"),
                "market": group,
                "label": label,
                "matchup": matchup,
                "score": _social_score_text(selection, settlement),
                "status": status,
                "status_label": status_label(status),
            }
        )
    return items


def _social_league_settled(package: dict, league: str) -> bool:
    entries = _package_entries(package, league)
    return bool(entries) and all(
        str(settlement.get("status") or "pending").lower() in SOCIAL_TERMINAL_STATUSES
        for _group, _selection, settlement in entries
    )


def _social_reel_ready(package: dict, league: str, free_record: dict | None = None) -> bool:
    if not _social_league_settled(package, league):
        return False
    if free_record and str(free_record.get("status") or "pending").lower() not in SOCIAL_TERMINAL_STATUSES:
        return False
    return True


def _social_pro_payload(
    package: dict,
    league: str,
    *,
    result: bool = False,
    page: int = 1,
    batch_size: int = 5,
    free_record: dict | None = None,
) -> dict:
    if not result:
        games = _social_pro_games(package, league)
        batch_size = max(1, int(batch_size))
        total_pages = max(1, math.ceil(len(games) / batch_size)) if games else 1
        page = max(1, min(int(page), total_pages))
        start = (page - 1) * batch_size
        return {
            "items": games[start:start + batch_size],
            "page": page,
            "total_pages": total_pages,
            "total_games": len(games),
            "batch_size": batch_size,
        }
    _package_categories, _package_overall, parlay = _social_category_summary(package, league)
    items = _social_result_items(package, league, free_record)

    # V19.1.2: summary statistics must match the actual Reel cards. This counts
    # the separate free pick exactly once and avoids double-counting when that
    # same matchup/direction also exists in the Pro package.
    categories = {
        "moneylines": {"won": 0, "lost": 0, "neutral": 0, "pending": 0},
        "run_lines": {"won": 0, "lost": 0, "neutral": 0, "pending": 0},
        "totals": {"won": 0, "lost": 0, "neutral": 0, "pending": 0},
        "parlays": {"won": 0, "lost": 0, "neutral": 0, "pending": 0},
    }
    overall = {"won": 0, "lost": 0, "neutral": 0, "pending": 0}
    for item in items:
        status = str(item.get("status") or "pending").lower()
        bucket = "neutral" if status in {"push", "void"} else status if status in {"won", "lost"} else "pending"
        market = str(item.get("market") or "").lower()
        if market in {"moneyline", "moneylines"}:
            category = "moneylines"
        elif market in {"run_line", "run_lines"}:
            category = "run_lines"
        elif market == "totals":
            category = "totals"
        else:
            category = "parlays"
        categories[category][bucket] += 1
        overall[bucket] += 1

    for stat in categories.values():
        decided = int(stat.get("won") or 0) + int(stat.get("lost") or 0)
        stat["hit_rate"] = round(int(stat.get("won") or 0) / decided * 100.0, 1) if decided else None
    decided = int(overall.get("won") or 0) + int(overall.get("lost") or 0)
    overall["hit_rate"] = round(int(overall.get("won") or 0) / decided * 100.0, 1) if decided else None
    parlay["won"] = int(categories["parlays"].get("won") or 0)
    parlay["lost"] = int(categories["parlays"].get("lost") or 0)
    parlay["neutral"] = int(categories["parlays"].get("neutral") or 0)
    return {
        "categories": categories,
        "overall": overall,
        "parlay": parlay,
        "free_result": _social_free_result_payload(free_record),
        "items": items,
        "max_cards": max(1, int(getattr(settings, "instagram_reel_max_cards", 30))),
        "card_seconds": max(1.4, float(getattr(settings, "instagram_reel_card_seconds", 2.2))),
        "batch_seconds": max(2.4, float(getattr(settings, "instagram_reel_batch_seconds", 3.2))),
        "result_batch_size": max(1, min(int(getattr(settings, "instagram_pro_batch_size", 5)), 5)),
        "summary_seconds": max(3.0, float(getattr(settings, "instagram_reel_summary_seconds", 4.5))),
        "transition_seconds": max(0.08, float(getattr(settings, "instagram_reel_transition_seconds", 0.24))),
        "audio_enabled": bool(getattr(settings, "instagram_reel_audio_enabled", True)),
    }


def _instagram_league_enabled(league: str) -> bool:
    code = str(league or "").upper()
    return bool({
        "MLB": getattr(settings, "instagram_auto_mlb_enabled", True),
        "NPB": getattr(settings, "instagram_auto_npb_enabled", True),
        "KBO": getattr(settings, "instagram_auto_kbo_enabled", True),
        "CPBL": getattr(settings, "instagram_auto_cpbl_enabled", True),
    }.get(code, False))


def _social_free_marker(record: dict, key: str) -> dict:
    snapshot = record.get("prediction_snapshot") or {}
    publication = snapshot.get("publication") or {}
    social = publication.get("social") or {}
    marker = social.get(key) if isinstance(social, dict) else None
    return marker if isinstance(marker, dict) else {}


def _social_package_marker(record: dict, key: str) -> dict:
    thresholds = record.get("thresholds") or {}
    publication = thresholds.get("publication") or {}
    social = publication.get("social") or {}
    marker = social.get(key) if isinstance(social, dict) else None
    return marker if isinstance(marker, dict) else {}


def _social_marker_busy(marker: dict) -> bool:
    if str(marker.get("status") or "") != "publishing":
        return False
    started = _publication_datetime(marker.get("started_at"))
    if started is None:
        return False
    return datetime.now(TAIPEI) - started.astimezone(TAIPEI) < timedelta(minutes=20)


async def _save_free_social_marker(
    request: Request,
    recommendation_date: str,
    league: str,
    key: str,
    marker: dict,
) -> dict | None:
    repository = records_repository(request)
    current = await repository.get_record_for_date(recommendation_date, league)
    if not current or current.get("id") is None:
        return None
    snapshot = deepcopy(current.get("prediction_snapshot") or {})
    publication = deepcopy(snapshot.get("publication") or {})
    social = deepcopy(publication.get("social") or {})
    social[key] = marker
    publication["social"] = social
    snapshot["publication"] = publication
    return await repository.update_prediction_snapshot_by_id(current["id"], snapshot)


async def _save_package_social_marker(
    request: Request,
    recommendation_date: str,
    key: str,
    marker: dict,
) -> dict | None:
    repository = records_repository(request)
    current = await repository.get_prediction_package_for_date(recommendation_date)
    if not current or current.get("id") is None:
        return None
    thresholds = deepcopy(current.get("thresholds") or {})
    publication = deepcopy(thresholds.get("publication") or {})
    social = deepcopy(publication.get("social") or {})
    social[key] = marker
    publication["social"] = social
    thresholds["publication"] = publication
    return await repository.update_prediction_package_thresholds(current["id"], thresholds)


async def _publish_free_social(
    request: Request,
    record: dict,
    phase: str,
) -> dict:
    social = social_service(request)
    if not social.enabled:
        return {"status": "disabled", "reason": "instagram_not_enabled"}
    league = str(record.get("league") or _selection_league(record.get("prediction_snapshot") or {})).upper()
    recommendation_date = str(record.get("recommendation_date") or "")
    if not recommendation_date:
        return {"status": "failed", "error": "推薦日期遺失"}
    if not _instagram_league_enabled(league):
        return {"status": "disabled", "reason": "league_policy"}
    if phase != "pregame":
        return {"status": "disabled", "reason": "free_result_is_in_reel"}
    if phase == "pregame" and not settings.instagram_post_free_pregame:
        return {"status": "disabled", "reason": "policy"}
    key = social_event_key("free", phase, league)
    current = await records_repository(request).get_record_for_date(recommendation_date, league)
    if not current:
        return {"status": "failed", "error": "找不到已發布免費推薦"}
    marker = _social_free_marker(current, key)
    if str(marker.get("status") or "") == "published":
        return {"status": "already_published", "event": key, "destinations": marker.get("destinations") or {}}
    if _social_marker_busy(marker):
        return {"status": "publishing", "event": key}

    attempt = {
        **marker,
        "status": "publishing",
        "event": key,
        "started_at": social_utc_now(),
        "attempts": int(marker.get("attempts") or 0) + 1,
        "destinations": deepcopy(marker.get("destinations") or {}),
    }
    if not await _save_free_social_marker(request, recommendation_date, league, key, attempt):
        return {"status": "failed", "event": key, "error": "無法先保存 Instagram 發佈狀態"}
    latest = await records_repository(request).get_record_for_date(recommendation_date, league)
    payload = _social_free_payload(latest or current)
    spec = SocialAssetSpec("free", phase, "feed", recommendation_date, league)
    result = await social.publish_pair(
        spec,
        payload,
        existing_destinations=attempt.get("destinations") or {},
    )
    completed = {**attempt, **result, "finished_at": social_utc_now()}
    await _save_free_social_marker(request, recommendation_date, league, key, completed)
    return completed


async def _publish_pro_social(
    request: Request,
    record: dict,
    phase: str,
    league: str,
) -> dict:
    social = social_service(request)
    if not social.enabled:
        return {"status": "disabled", "reason": "instagram_not_enabled"}
    league = league.upper()
    recommendation_date = str(record.get("recommendation_date") or "")
    if not recommendation_date:
        return {"status": "failed", "error": "推薦日期遺失"}
    if not _instagram_league_enabled(league):
        return {"status": "disabled", "reason": "league_policy"}
    package = package_from_record(record)
    if phase == "teaser" and not settings.instagram_post_pro_teaser:
        return {"status": "disabled", "reason": "policy"}
    if phase == "result" and not settings.instagram_post_pro_result:
        return {"status": "disabled", "reason": "policy"}
    if phase == "teaser" and not _package_has_league(package, league):
        return {"status": "pending", "reason": "league_not_published"}
    repository = records_repository(request)
    if phase == "result":
        free_for_readiness = await repository.get_record_for_date(recommendation_date, league)
        if not _social_reel_ready(package, league, free_for_readiness):
            return {"status": "pending", "reason": "league_settlement_not_terminal"}

    current = await repository.get_prediction_package_for_date(recommendation_date)
    if not current:
        return {"status": "failed", "error": "找不到已發布 Pro 推薦"}
    current_package = package_from_record(current)
    batch_size = max(1, int(getattr(settings, "instagram_pro_batch_size", 5)))
    page_count = _social_pro_page_count(current_package, league, batch_size) if phase == "teaser" else 1
    if phase == "teaser" and page_count < 1:
        return {"status": "pending", "reason": "no_games_to_publish"}

    outcomes: list[dict] = []
    for page in range(1, page_count + 1):
        key = social_event_key("pro", phase, league, page)
        latest_record = await repository.get_prediction_package_for_date(recommendation_date)
        if not latest_record:
            outcomes.append({"status": "failed", "event": key, "error": "找不到已發布 Pro 推薦"})
            continue
        marker = _social_package_marker(latest_record, key)
        if str(marker.get("status") or "") == "published":
            outcomes.append({"status": "already_published", "event": key, "page": page, "destinations": marker.get("destinations") or {}})
            continue
        if _social_marker_busy(marker):
            outcomes.append({"status": "publishing", "event": key, "page": page})
            continue

        attempt = {
            **marker,
            "status": "publishing",
            "event": key,
            "page": page,
            "total_pages": page_count,
            "started_at": social_utc_now(),
            "attempts": int(marker.get("attempts") or 0) + 1,
            "destinations": deepcopy(marker.get("destinations") or {}),
        }
        if not await _save_package_social_marker(request, recommendation_date, key, attempt):
            outcomes.append({"status": "failed", "event": key, "page": page, "error": "無法先保存 Instagram 發佈狀態"})
            continue

        newest = await repository.get_prediction_package_for_date(recommendation_date)
        newest_package = package_from_record(newest or latest_record)
        free_record = None
        if phase == "result":
            free_record = await repository.get_record_for_date(recommendation_date, league)
        payload = _social_pro_payload(
            newest_package,
            league,
            result=phase == "result",
            page=page,
            batch_size=batch_size,
            free_record=free_record,
        )
        spec = SocialAssetSpec("pro", phase, "feed", recommendation_date, league, page)
        result_payload = await social.publish_pair(
            spec,
            payload,
            existing_destinations=attempt.get("destinations") or {},
        )
        completed = {**attempt, **result_payload, "finished_at": social_utc_now()}
        await _save_package_social_marker(request, recommendation_date, key, completed)
        outcomes.append(completed)

    statuses = {str(item.get("status") or "") for item in outcomes}
    published_like = {"published", "already_published"}
    if outcomes and all(status in published_like for status in statuses):
        final_status = "published" if "published" in statuses else "already_published"
    elif any(status in published_like for status in statuses):
        final_status = "partial"
    elif "publishing" in statuses:
        final_status = "publishing"
    elif "failed" in statuses:
        final_status = "failed"
    else:
        final_status = next(iter(statuses), "pending")
    errors = [str(item.get("error")) for item in outcomes if item.get("error")]
    return {
        "status": final_status,
        "event": f"pro_{phase}_{league}",
        "league": league,
        "pages": outcomes,
        "published_pages": sum(1 for item in outcomes if item.get("status") == "published"),
        "total_pages": page_count,
        "error": " / ".join(errors[:3]) if errors else None,
        "finished_at": social_utc_now(),
    }

def _social_preview_urls(social: DiamondMindSocialService, spec: SocialAssetSpec) -> dict:
    if not social.asset_secret:
        return {"feed": None, "story": None, "reel": None}
    try:
        preview = {
            "feed": social.asset_url(
                SocialAssetSpec(spec.source, spec.phase, "feed", spec.recommendation_date, spec.league, spec.page),
                lifetime_seconds=3600,
            ),
            "story": social.asset_url(
                SocialAssetSpec(spec.source, spec.phase, "story", spec.recommendation_date, spec.league, spec.page),
                lifetime_seconds=3600,
            ),
            "reel": None,
        }
        if spec.source == "pro" and spec.phase == "result" and spec.league in {"MLB", "NPB"}:
            preview["reel"] = social.reel_url(
                SocialReelSpec(spec.recommendation_date, spec.league),
                lifetime_seconds=3600,
            )
        return preview
    except (TypeError, ValueError):
        return {"feed": None, "story": None, "reel": None}


async def _social_recent_events(request: Request, limit: int = 30) -> list[dict]:
    repository = records_repository(request)
    if not repository.enabled:
        return []
    free_records, package_records = await asyncio.gather(
        repository.list_records(limit=max(20, limit)),
        repository.list_prediction_packages(limit=max(20, limit)),
    )
    social = social_service(request)
    events: list[dict] = []
    free_lookup = {
        (str(record.get("recommendation_date") or ""), str(record.get("league") or "MLB").upper()): record
        for record in free_records
    }
    for record in free_records:
        recommendation_date = str(record.get("recommendation_date") or "")
        league = str(record.get("league") or "MLB").upper()
        if not _instagram_league_enabled(league):
            continue
        key = social_event_key("free", "pregame", league)
        marker = _social_free_marker(record, key)
        spec = SocialAssetSpec("free", "pregame", "feed", recommendation_date, league)
        events.append({
            "event": key,
            "source": "free",
            "phase": "pregame",
            "league": league,
            "date": recommendation_date,
            "template": "daily_free_card",
            "status": marker.get("status") or "waiting",
            "attempts": int(marker.get("attempts") or 0),
            "destinations": marker.get("destinations") or {},
            "errors": marker.get("errors") or [],
            "preview": _social_preview_urls(social, spec),
        })
    batch_size = max(1, int(getattr(settings, "instagram_pro_batch_size", 5)))
    for record in package_records:
        recommendation_date = str(record.get("recommendation_date") or "")
        package = package_from_record(record)
        for league in ("MLB", "NPB"):
            if not _instagram_league_enabled(league) or not _package_has_league(package, league):
                continue
            page_count = _social_pro_page_count(package, league, batch_size)
            for page in range(1, page_count + 1):
                key = social_event_key("pro", "teaser", league, page)
                marker = _social_package_marker(record, key)
                spec = SocialAssetSpec("pro", "teaser", "feed", recommendation_date, league, page)
                events.append({
                    "event": key,
                    "source": "pro",
                    "phase": "teaser",
                    "league": league,
                    "date": recommendation_date,
                    "page": page,
                    "total_pages": page_count,
                    "template": "five_game_batch",
                    "status": marker.get("status") or "waiting",
                    "attempts": int(marker.get("attempts") or 0),
                    "destinations": marker.get("destinations") or {},
                    "errors": marker.get("errors") or [],
                    "preview": _social_preview_urls(social, spec),
                })
            free_record = free_lookup.get((recommendation_date, league))
            if _social_reel_ready(package, league, free_record):
                key = social_event_key("pro", "result", league)
                marker = _social_package_marker(record, key)
                spec = SocialAssetSpec("pro", "result", "feed", recommendation_date, league)
                events.append({
                    "event": key,
                    "source": "pro",
                    "phase": "result",
                    "league": league,
                    "date": recommendation_date,
                    "template": "settlement_summary",
                    "status": marker.get("status") or "waiting",
                    "attempts": int(marker.get("attempts") or 0),
                    "destinations": marker.get("destinations") or {},
                    "errors": marker.get("errors") or [],
                    "preview": _social_preview_urls(social, spec),
                })
    events.sort(
        key=lambda item: (
            item.get("date") or "",
            item.get("phase") == "result",
            int(item.get("page") or 0),
        ),
        reverse=True,
    )
    return events[:limit]

async def sync_social_publications(request: Request, *, max_events: int | None = None) -> dict:
    social = social_service(request)
    if not social.enabled:
        result = {
            "ok": True,
            "status": "disabled",
            "last_run": social_utc_now(),
            "published_now": 0,
            "configuration": social.status(),
        }
        request.app.state.social_status = result
        return result
    repository = records_repository(request)
    if not repository.enabled:
        result = {
            "ok": False,
            "status": "failed",
            "last_run": social_utc_now(),
            "last_error": "records_not_configured",
            "published_now": 0,
        }
        request.app.state.social_status = result
        return result

    cap = max(1, min(int(max_events or settings.instagram_max_events_per_sync), 12))
    lookback = max(1, min(settings.instagram_retry_lookback_days, 7))
    now = datetime.now(TAIPEI)
    cutoff = now.date() - timedelta(days=lookback)
    upper = now.date() + timedelta(days=1)
    free_records, packages = await asyncio.gather(
        repository.list_records(limit=max(settings.records_limit, 100)),
        repository.list_prediction_packages(limit=max(settings.records_limit, 100)),
    )
    actions: list[dict] = []
    lead_seconds = max(0, int(getattr(settings, "instagram_story_lead_minutes", 60))) * 60
    free_lookup = {
        (str(record.get("recommendation_date") or ""), str(record.get("league") or "MLB").upper()): record
        for record in free_records
    }

    # Free picks are independent Story cards and show the full public direction.
    for record in free_records:
        try:
            target = date.fromisoformat(str(record.get("recommendation_date") or ""))
        except ValueError:
            continue
        status = str(record.get("status") or "pending").lower()
        league = str(record.get("league") or "MLB").upper()
        if not _instagram_league_enabled(league):
            continue
        marker = _social_free_marker(record, social_event_key("free", "pregame", league))
        if status == "pending" and now.date() <= target <= upper and marker.get("status") != "published":
            start_at = _selection_start_datetime(record.get("prediction_snapshot") or {})
            if start_at is not None:
                remaining = (start_at.astimezone(TAIPEI) - now).total_seconds()
                if 0 < remaining <= lead_seconds:
                    actions.append({"kind": "free", "phase": "pregame", "league": league, "record": record})

    batch_size = max(1, int(getattr(settings, "instagram_pro_batch_size", 5)))
    for record in packages:
        try:
            target = date.fromisoformat(str(record.get("recommendation_date") or ""))
        except ValueError:
            continue
        package = package_from_record(record)
        recommendation_date = str(record.get("recommendation_date") or "")
        for league in ("MLB", "NPB"):
            if not _instagram_league_enabled(league):
                continue
            entries = _package_entries(package, league)
            if not entries:
                continue
            free_record = free_lookup.get((recommendation_date, league))
            if cutoff <= target <= now.date() and _social_reel_ready(package, league, free_record):
                result_marker = _social_package_marker(record, social_event_key("pro", "result", league))
                if result_marker.get("status") != "published":
                    actions.append({"kind": "pro", "phase": "result", "league": league, "record": record})
            if now.date() <= target <= upper:
                starts = [_selection_start_datetime(selection) for _group, selection, _result in entries]
                future_starts = [value.astimezone(TAIPEI) for value in starts if value is not None]
                page_count = _social_pro_page_count(package, league, batch_size)
                pending_page = any(
                    _social_package_marker(record, social_event_key("pro", "teaser", league, page)).get("status") != "published"
                    for page in range(1, page_count + 1)
                )
                if page_count and future_starts and pending_page:
                    remaining = (min(future_starts) - now).total_seconds()
                    if 0 < remaining <= lead_seconds:
                        actions.append({"kind": "pro", "phase": "teaser", "league": league, "record": record})

    actions.sort(
        key=lambda item: (
            str((item.get("record") or {}).get("recommendation_date") or ""),
            item.get("phase") == "result",
        ),
        reverse=True,
    )
    processed: list[dict] = []
    published_now = 0
    failures: list[str] = []
    for action in actions:
        if len(processed) >= cap:
            break
        try:
            if action["kind"] == "free":
                outcome = await _publish_free_social(request, action["record"], "pregame")
            else:
                outcome = await _publish_pro_social(request, action["record"], action["phase"], action["league"])
        except (RecordsStorageError, SocialPublishingError) as exc:
            outcome = {"status": "failed", "error": str(exc)}
        processed.append({
            "event": outcome.get("event"),
            "kind": action["kind"],
            "phase": action["phase"],
            "league": action.get("league") or action["record"].get("league"),
            "status": outcome.get("status"),
            "published_pages": int(outcome.get("published_pages") or (1 if outcome.get("status") == "published" else 0)),
        })
        published_now += int(outcome.get("published_pages") or (1 if outcome.get("status") == "published" else 0))
        if outcome.get("status") == "failed":
            failures.append(str(outcome.get("error") or "Instagram publish failed"))
    result = {
        "ok": not failures,
        "status": "running" if not failures else "warning",
        "last_run": social_utc_now(),
        "last_error": " / ".join(failures[:3]) if failures else None,
        "published_now": published_now,
        "processed": processed,
    }
    request.app.state.social_status = result
    return result

async def social_dashboard(request: Request) -> dict:
    recent = await _social_recent_events(request)
    waiting = sum(1 for item in recent if item.get("status") in {"waiting", "failed", "partial"})
    failed = sum(1 for item in recent if item.get("status") in {"failed", "partial"})
    return {
        "configuration": social_service(request).status(),
        "monitor": request.app.state.social_status,
        "summary": {
            "events": len(recent),
            "published": sum(1 for item in recent if item.get("status") == "published"),
            "waiting": waiting,
            "failed": failed,
        },
        "rules": {
            "free_pregame": "每日免費推薦獨立一則限動，公開完整方向",
            "pro_pregame": "Pro 每 5 場一則限動，只顯示對戰、時間與信心，不公開方向",
            "results": "MLB、NPB 各自在全數結算後產生單場卡＋總結卡 Reel，並同步顯示於貼文牆",
            "formats": ["1080x1920 story", "1080x1920 H.264 reel"],
        },
        "events": recent,
    }


@app.get(f"{settings.api_prefix}/social/assets/{{source}}/{{recommendation_date}}/{{league}}/{{phase}}/{{size}}.jpg")
async def social_asset(
    request: Request,
    source: str,
    recommendation_date: str,
    league: str,
    phase: str,
    size: str,
    page: int = Query(default=1, ge=1, le=99),
    expires: int = Query(...),
    signature: str = Query(..., min_length=32, max_length=128),
) -> Response:
    try:
        spec = SocialAssetSpec(source, phase, size, recommendation_date, league, page).validated()
    except (TypeError, ValueError) as exc:
        raise HTTPException(status_code=404, detail="Social image was not found") from exc
    social = social_service(request)
    if not social.verify_asset(spec, expires, signature):
        raise HTTPException(status_code=403, detail="Social image link is invalid or expired")
    repository = records_repository(request)
    if spec.source == "free":
        if spec.phase != "pregame" or spec.league == "ALL" or spec.page != 1:
            raise HTTPException(status_code=404, detail="Social image was not found")
        record = await repository.get_record_for_date(spec.recommendation_date, spec.league)
        if not record:
            raise HTTPException(status_code=404, detail="Published recommendation was not found")
        payload = _social_free_payload(record)
    else:
        if spec.phase not in {"teaser", "result"} or spec.league not in {"MLB", "NPB"}:
            raise HTTPException(status_code=404, detail="Social image was not found")
        record = await repository.get_prediction_package_for_date(spec.recommendation_date)
        if not record:
            raise HTTPException(status_code=404, detail="Published Pro package was not found")
        package = package_from_record(record)
        if spec.phase == "teaser":
            if not _package_has_league(package, spec.league):
                raise HTTPException(status_code=404, detail="Published Pro league was not found")
            batch_size = max(1, int(getattr(settings, "instagram_pro_batch_size", 5)))
            page_count = _social_pro_page_count(package, spec.league, batch_size)
            if spec.page > page_count:
                raise HTTPException(status_code=404, detail="Published Pro batch was not found")
            payload = _social_pro_payload(
                package, spec.league, page=spec.page, batch_size=batch_size
            )
        else:
            free_record = await repository.get_record_for_date(spec.recommendation_date, spec.league)
            if spec.page != 1 or not _social_reel_ready(package, spec.league, free_record):
                raise HTTPException(status_code=409, detail="League package has not reached a final result")
            payload = _social_pro_payload(
                package, spec.league, result=True, free_record=free_record
            )
    try:
        content = social.render(spec, payload)
    except (OSError, ValueError) as exc:
        raise HTTPException(status_code=500, detail="Social image rendering failed") from exc
    return Response(
        content=content,
        media_type="image/jpeg",
        headers={
            "Cache-Control": "public, max-age=300",
            "Content-Disposition": f'inline; filename="diamondmind-{spec.source}-{spec.phase}-{spec.league}-p{spec.page}-{spec.size}.jpg"',
        },
    )


@app.get(f"{settings.api_prefix}/social/reels/{{recommendation_date}}/{{league}}.mp4")
async def social_reel(
    request: Request,
    recommendation_date: str,
    league: str,
    expires: int = Query(...),
    signature: str = Query(..., min_length=32, max_length=128),
) -> FileResponse:
    try:
        spec = SocialReelSpec(recommendation_date, league).validated()
    except (TypeError, ValueError) as exc:
        raise HTTPException(status_code=404, detail="Social Reel was not found") from exc
    social = social_service(request)
    if not social.verify_reel(spec, expires, signature):
        raise HTTPException(status_code=403, detail="Social Reel link is invalid or expired")
    repository = records_repository(request)
    record = await repository.get_prediction_package_for_date(spec.recommendation_date)
    if not record:
        raise HTTPException(status_code=404, detail="Published Pro package was not found")
    package = package_from_record(record)
    free_record = await repository.get_record_for_date(spec.recommendation_date, spec.league)
    if not _social_reel_ready(package, spec.league, free_record):
        raise HTTPException(status_code=409, detail="League package has not reached a final result")
    payload = _social_pro_payload(package, spec.league, result=True, free_record=free_record)
    try:
        path = await asyncio.to_thread(social.render_reel_file, spec, payload)
    except (OSError, ValueError, SocialPublishingError) as exc:
        raise HTTPException(status_code=500, detail=f"Social Reel rendering failed: {exc}") from exc
    return FileResponse(
        path=str(path),
        media_type="video/mp4",
        filename=f"diamondmind-{spec.recommendation_date}-{spec.league}-results.mp4",
        headers={"Cache-Control": "public, max-age=300"},
    )


@app.get(f"{settings.api_prefix}/admin/social/status")
async def admin_social_status(
    request: Request,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    await admin_member(request, authorization)
    try:
        return await social_dashboard(request)
    except RecordsStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


@app.post(f"{settings.api_prefix}/admin/social/sync")
async def admin_social_sync(
    request: Request,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    await admin_member(request, authorization)
    try:
        sync = await sync_social_publications(request)
        return {
            "ok": bool(sync.get("ok")),
            "sync": sync,
            "dashboard": await social_dashboard(request),
            "message": "Instagram 自動發佈同步完成。" if sync.get("ok") else "同步完成，但仍有項目等待重試。",
        }
    except RecordsStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


@app.get(f"{settings.api_prefix}/predictions/top")
async def top_prediction(
    request: Request,
    prediction_date: date | None = Query(default=None, alias="date", description="Taiwan date, YYYY-MM-DD"),
    league: str = Query(default="MLB", pattern="^(MLB|NPB|KBO|CPBL)$"),
    latest: bool = Query(default=False, description="Return the latest formally published pick, regardless of target date"),
) -> dict:
    league = _prediction_league(league)
    if latest:
        repository = records_repository(request)
        if repository.enabled:
            try:
                records = await repository.list_records(limit=max(settings.records_limit, 100))
            except RecordsStorageError as exc:
                raise HTTPException(status_code=503, detail=str(exc)) from exc
            record, metadata = _latest_record_for_league(records, league)
            if record and metadata:
                snapshot = deepcopy(record.get("prediction_snapshot") or {})
                snapshot["result"] = _record_result_payload(record) or {"status": "pending"}
                return {
                    "date": metadata["target_date"],
                    "target_date": metadata["target_date"],
                    "published_at": metadata["published_at"],
                    "status": metadata["status"],
                    "league": league,
                    "published": True,
                    "selection": _free_pick_for_member(snapshot),
                    "message": f"已載入 {league} 最近一次正式發布的免費精選。",
                }
        return {
            "date": None,
            "target_date": None,
            "published_at": None,
            "status": None,
            "league": league,
            "published": False,
            "selection": None,
            "message": f"{league} 尚無已正式發布的免費精選。",
        }
    target_date = requested_date(prediction_date)
    if league in {"NPB", "KBO", "CPBL"}:
        repository = records_repository(request)
        selection = None
        if repository.enabled:
            try:
                record = await repository.get_record_for_date(target_date.isoformat(), league)
            except RecordsStorageError as exc:
                raise HTTPException(status_code=503, detail=str(exc)) from exc
            snapshot = record.get("prediction_snapshot") if isinstance(record, dict) else None
            if isinstance(snapshot, dict) and _selection_matches_league(snapshot, league):
                selection = deepcopy(snapshot)
                selection["result"] = _record_result_payload(record) or {"status": "pending"}
        return {
            "date": target_date.isoformat(),
            "league": league,
            "published": bool(selection),
            "selection": _free_pick_for_member(selection) if selection else None,
            "message": f"今日 {league} 每日免費精選尚未正式發布。" if not selection else f"今日 {league} 每日免費精選已正式發布。",
        }
    try:
        payload = await prediction_with_persistence(request, target_date, publish_if_eligible=False)
        return {**_public_prediction_response(payload), "league": league}
    except MLBUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


def _record_result_payload(record: dict | None) -> dict | None:
    if not isinstance(record, dict):
        return None
    status = str(record.get("status") or "pending")
    return {
        "status": status,
        "away_score": record.get("away_score"),
        "home_score": record.get("home_score"),
        "result_note": record.get("result_note"),
        "settled_at": record.get("settled_at"),
    }


@app.get(f"{settings.api_prefix}/predictions/daily")
async def daily_predictions_for_member(
    request: Request,
    prediction_date: date | None = Query(default=None, alias="date", description="Taiwan date, YYYY-MM-DD"),
    league: str = Query(default="MLB", pattern="^(MLB|NPB|KBO|CPBL)$"),
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    member = await authenticated_member(request, authorization)
    league = _prediction_league(league)

    target_date = requested_date(prediction_date)
    repository = records_repository(request)
    if repository.enabled and target_date <= datetime.now(TAIPEI).date():
        try:
            await settle_pending_records(request)
            await settle_pending_prediction_packages(request)
        except (RecordsStorageError, MLBUpstreamError, NPBUpstreamError, AsianBaseballUpstreamError):
            # Results already stored remain readable even if a live settlement
            # refresh temporarily fails.
            pass
    try:
        stored = await repository.get_prediction_package_for_date(target_date.isoformat())
        public_record = await repository.get_record_for_date(target_date.isoformat(), league)
    except RecordsStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc

    # The selected league's public daily record is the source of truth for the
    # large free-pick card. It may have been selected by the founder and must never
    # be replaced by the convenience ``moneyline`` snapshot embedded in a Pro
    # package. The package snapshot is only a fallback for legacy dates.
    public_snapshot = (
        public_record.get("prediction_snapshot")
        if public_record and isinstance(public_record.get("prediction_snapshot"), dict)
        else None
    )
    if public_snapshot and not _selection_matches_league(public_snapshot, league):
        public_snapshot = None

    moneyline = public_snapshot
    if stored:
        raw_package = package_from_record(stored)
        package = _package_for_league(raw_package, league)
        if not _package_has_league(raw_package, league):
            package = None
        publication_mode = str((package.get("publication") or {}).get("mode") or "") if package else ""
        if publication_mode == "ai_auto":
            # Older schedulers could create a paid package before the founder
            # approved it. Treat that row as an internal placeholder only.
            package = None
    else:
        package = None

    is_founder = member.get("role") == "admin"
    watchlist: dict[str, list[dict]] = {
        "moneylines": [],
        "run_lines": [],
        "totals": [],
    }
    watchlist_message = None
    if is_founder and package and isinstance(package.get("watchlist"), dict):
        watchlist = package.get("watchlist") or watchlist
    elif is_founder:
        # Observation candidates are founder-only internal review data. They
        # are never returned to free or Pro members, even though Pro members
        # may access the formally published recommendation package.
        try:
            live_bundle = await founder_market_candidate_bundle(request, target_date, league)
            watchlist = live_bundle.get("watchlist") or watchlist
        except HTTPException as exc:
            detail = exc.detail
            watchlist_message = (
                detail.get("message")
                if isinstance(detail, dict)
                else str(detail or "觀察名單暫時無法更新。")
            )

    formal_groups = {
        "moneylines": package.get("moneylines") if package else [],
        "run_lines": package.get("run_lines") if package else [],
        "totals": package.get("totals") if package else [],
        "two_leg": ((package.get("parlays") or {}).get("two_leg") if package else []),
        "three_leg": ((package.get("parlays") or {}).get("three_leg") if package else []),
    }
    formal_count = sum(len(items or []) for items in formal_groups.values())
    if not is_founder:
        formal_groups = {
            key: [
                _selection_for_member(item, founder=False)
                for item in (items or [])
                if isinstance(item, dict)
            ]
            for key, items in formal_groups.items()
        }
    moneyline = _free_pick_for_member(moneyline, founder=is_founder)
    if isinstance(moneyline, dict) and public_record:
        moneyline["result"] = _record_result_payload(public_record)
    watchlist_count = sum(len(items or []) for items in watchlist.values()) if is_founder else 0
    recommendation_status = (
        "formal_published"
        if formal_count
        else "founder_watchlist_only"
        if is_founder and watchlist_count
        else "no_recommendation"
    )
    if formal_count:
        message = f"今日 {league} 正式 Pro 推薦已載入。"
    elif is_founder and watchlist_count:
        message = f"今日 {league} 無正式 Pro 推薦；目前有創辦人內部觀察候選。"
    else:
        message = f"今日 {league} 沒有玩法通過正式發布門檻。"
        if is_founder and watchlist_message:
            message = watchlist_message

    candidate_counts = package.get("candidate_counts") if package else {}
    if not is_founder and isinstance(candidate_counts, dict):
        candidate_counts = {
            key: value
            for key, value in candidate_counts.items()
            if not str(key).startswith("watch_")
        }

    response = {
        "date": target_date.isoformat(),
        "league": league,
        "published": bool(package or moneyline),
        "locked": bool(package),
        "member": {"role": member["role"], "has_pro_access": member["has_pro_access"]},
        "moneyline": moneyline,
        "pro_access": "granted" if member["has_pro_access"] else "locked",
        "recommendation_status": recommendation_status,
        "formal_recommendation_count": formal_count,
        "watchlist_count": watchlist_count,
        "message": message,
    }
    if member["has_pro_access"]:
        response.update(
            {
                "moneylines": formal_groups["moneylines"],
                "run_lines": formal_groups["run_lines"],
                "totals": formal_groups["totals"],
                "parlays": {
                    "two_leg": formal_groups["two_leg"],
                    "three_leg": formal_groups["three_leg"],
                },
                # V14-compatible aliases during the transition.
                "run_line": (formal_groups["run_lines"] or [None])[0],
                "total": (formal_groups["totals"] or [None])[0],
                "candidate_counts": candidate_counts,
                "thresholds": package.get("thresholds") if package else {},
                "limits": package.get("limits") if package else {},
                "publication": package.get("publication") if package else {},
                "settled": package.get("settled") if package else False,
                "results": package.get("results") if package else {},
            }
        )
        if is_founder:
            response["watchlist"] = watchlist
            response["watchlist_message"] = watchlist_message
    return response


@app.get(f"{settings.api_prefix}/predictions/latest")
async def latest_predictions_for_member(
    request: Request,
    league: str = Query(default="MLB", pattern="^(MLB|NPB|KBO|CPBL)$"),
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    """Return the latest founder-published batch without a calendar-day gate.

    ``target_date`` remains the game date, while ``published_at`` controls what
    members see first.  Publishing tomorrow's MLB slate tonight therefore
    updates the MLB tab immediately and does not replace an independently
    published NPB batch.
    """

    member = await authenticated_member(request, authorization)
    league = _prediction_league(league)
    repository = records_repository(request)
    if not repository.enabled:
        raise HTTPException(status_code=503, detail="Recommendation database is not configured")

    try:
        await settle_pending_records(request)
        await settle_pending_prediction_packages(request)
    except (RecordsStorageError, MLBUpstreamError, NPBUpstreamError, AsianBaseballUpstreamError):
        # Previously stored outcomes remain readable when an upstream score
        # source is temporarily unavailable.
        pass

    try:
        records = await repository.list_records(limit=max(settings.records_limit, 100))
        package_records = await repository.list_prediction_packages(limit=max(settings.records_limit, 100))
    except RecordsStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc

    public_record, free_batch = _latest_record_for_league(records, league)
    _package_record, raw_package, pro_batch = _latest_package_for_league(package_records, league)
    package = _package_for_league(raw_package, league) if raw_package else None

    is_founder = member.get("role") == "admin"
    public_snapshot = (
        deepcopy(public_record.get("prediction_snapshot"))
        if public_record and isinstance(public_record.get("prediction_snapshot"), dict)
        else None
    )
    if public_snapshot and public_record:
        public_snapshot["result"] = _record_result_payload(public_record) or {"status": "pending"}
    moneyline = _free_pick_for_member(public_snapshot, founder=is_founder)

    formal_groups = {
        "moneylines": list(package.get("moneylines") or []) if package else [],
        "run_lines": list(package.get("run_lines") or []) if package else [],
        "totals": list(package.get("totals") or []) if package else [],
        "two_leg": list((package.get("parlays") or {}).get("two_leg") or []) if package else [],
        "three_leg": list((package.get("parlays") or {}).get("three_leg") or []) if package else [],
    }
    formal_count = sum(len(values) for values in formal_groups.values())
    if not is_founder:
        formal_groups = {
            key: [
                _selection_for_member(selection, founder=False)
                for selection in values
                if isinstance(selection, dict)
            ]
            for key, values in formal_groups.items()
        }

    feed_rows = [
        row
        for record in records
        if (row := _free_feed_row(record, league)) is not None
    ]
    if member.get("has_pro_access"):
        for package_record in package_records:
            candidate = package_from_record(package_record)
            if str((candidate.get("publication") or {}).get("mode") or "") == "ai_auto":
                continue
            feed_rows.extend(_package_feed_rows(candidate, league))

    today = datetime.now(TAIPEI).date().isoformat()
    current = [
        row
        for row in feed_rows
        if row.get("target_date") == today and row.get("status") in {"published", "live"}
    ]
    current.sort(
        key=lambda row: _publication_datetime(row.get("start_at"))
        or _publication_datetime(row.get("published_at"))
        or datetime.max.replace(tzinfo=TAIPEI)
    )
    history = [row for row in feed_rows if row.get("status") == "settled"]
    history.sort(
        key=lambda row: _publication_datetime((row.get("result") or {}).get("settled_at"))
        or _publication_datetime(row.get("published_at"))
        or datetime.min.replace(tzinfo=TAIPEI),
        reverse=True,
    )
    history = history[:10]

    visible_batches = [metadata for metadata in (free_batch, pro_batch if member.get("has_pro_access") else None) if metadata]
    latest_batch = max(visible_batches, key=_published_sort_key) if visible_batches else None
    visible_formal_count = formal_count if member.get("has_pro_access") else 0
    target_date = (
        ((pro_batch or {}).get("target_date") if member.get("has_pro_access") else None)
        or (free_batch or {}).get("target_date")
    )
    published_at = (
        (latest_batch or {}).get("published_at")
        if latest_batch
        else None
    )
    if visible_formal_count:
        message = f"已載入 {league} 最近一次正式發布的 Pro 推薦。"
    elif moneyline:
        message = f"已載入 {league} 最近一次正式發布的免費精選。"
    else:
        message = f"{league} 尚無已正式發布的推薦。"

    response = {
        "date": target_date,
        "target_date": target_date,
        "published_at": published_at,
        "status": (latest_batch or {}).get("status"),
        "league": league,
        "published": bool(moneyline or visible_formal_count),
        "locked": bool(visible_formal_count),
        "member": {"role": member["role"], "has_pro_access": member["has_pro_access"]},
        "moneyline": moneyline,
        "free_batch": free_batch,
        "pro_access": "granted" if member["has_pro_access"] else "locked",
        "recommendation_status": "formal_published" if visible_formal_count else "no_recommendation",
        "formal_recommendation_count": visible_formal_count,
        "message": message,
        "feed": {
            "league": league,
            "latest": latest_batch,
            "current": current,
            "history": history,
        },
    }
    if member["has_pro_access"]:
        response.update(
            {
                "pro_batch": pro_batch,
                "moneylines": formal_groups["moneylines"],
                "run_lines": formal_groups["run_lines"],
                "totals": formal_groups["totals"],
                "parlays": {
                    "two_leg": formal_groups["two_leg"],
                    "three_leg": formal_groups["three_leg"],
                },
                "run_line": (formal_groups["run_lines"] or [None])[0],
                "total": (formal_groups["totals"] or [None])[0],
                "candidate_counts": package.get("candidate_counts") if package else {},
                "thresholds": package.get("thresholds") if package else {},
                "limits": package.get("limits") if package else {},
                "publication": package.get("publication") if package else {},
                "settled": (pro_batch or {}).get("status") == "settled",
                "results": package.get("results") if package else {},
            }
        )
        if is_founder and package:
            response["watchlist"] = package.get("watchlist") or {}
    if not is_founder:
        response = _strip_member_financials(response)
    return response


class FounderPredictionPublish(BaseModel):
    date: date
    game_pk: str | int
    league: str = "MLB"
    confirm_warning: bool = False


def founder_candidate(analysis: dict) -> dict:
    """Return the founder-facing publication policy for one matchup."""

    game = analysis.get("game") or {}
    context = str(game.get("season_context") or "unsupported")
    confidence = float(analysis.get("confidence") or 0)
    data_quality = float(analysis.get("data_quality") or 0)
    policy = publication_policy(analysis, automatic=False)
    return {
        "game_pk": analysis.get("game_pk"),
        "league": _selection_league(analysis),
        "matchup": analysis.get("matchup"),
        "time_taiwan": analysis.get("time_taiwan"),
        "display_time_taiwan": analysis.get("display_time_taiwan") or game.get("display_time_taiwan"),
        "game_label": analysis.get("game_label") or game.get("game_label") or "",
        "game_number": analysis.get("game_number") if analysis.get("game_number") is not None else game.get("game_number"),
        "is_doubleheader": bool(analysis.get("is_doubleheader") or game.get("is_doubleheader")),
        "venue": game.get("venue"),
        "event": {
            "game_type": game.get("game_type"),
            "context": context,
            "label": game.get("event_label") or "例行賽",
            "special": bool(game.get("special_event")),
        },
        "pick": analysis.get("pick"),
        "confidence": confidence,
        "data_quality": data_quality,
        "warnings": policy["warnings"],
        "blockers": policy["blockers"],
        "can_publish": policy["can_publish"],
        "auto_publish_ready": policy["auto_publish_ready"],
        "requires_confirmation": policy["requires_confirmation"],
        "timing": policy["timing"],
        "checklist": policy["checklist"],
        "roster_validation": policy["roster_validation"],
        "lineup_validation_rate": policy["lineup_validation_rate"],
        "updated_at": (analysis.get("data_freshness") or {}).get("generated_at"),
    }


def founder_asian_candidate(selection: dict, league: str | None = None) -> dict:
    game = selection.get("game") or {}
    code = str(league or selection.get("league") or game.get("league") or "NPB").upper()
    starters = ((selection.get("analysis_groups") or {}).get("starter") or {})
    pick = selection.get("pick") or {}
    confidence = float(selection.get("confidence") or selection.get("model_probability") or 0)
    data_quality = float(selection.get("data_quality") or 0)
    model_stage = str(selection.get("model_stage") or "").lower()
    if model_stage not in {"base", "full"}:
        model_stage = "full" if starters.get("both_starters_ready") is True else "base"
    advisory_confidence = 54.0 if model_stage == "base" else 56.0
    advisory_data_quality = 0.55 if model_stage == "base" else 0.65
    status = str(game.get("status") or "upcoming").lower()
    game_id = selection.get("game_pk") or game.get("game_pk") or game.get("external_game_id")
    pick_side = str(pick.get("side") or "").lower()
    blockers: list[str] = []
    warnings: list[str] = []
    if status not in {"upcoming", "scheduled", "preview"}:
        blockers.append("比賽已開打或結束，不能發布為新的每日免費精選。")
    if not game_id:
        blockers.append("賽事識別碼缺失，無法安全建立發布紀錄。")
    if pick_side not in {"away", "home"}:
        blockers.append("模型尚未產生有效的主隊或客隊推薦方向。")
    if starters.get("both_starters_ready") is not True:
        warnings.append("兩隊預告先發或投手數據尚未完整；已降低模型信心，不阻擋發布。")
    if data_quality < advisory_data_quality:
        warnings.append(f"{code} 資料完整度目前為 {data_quality * 100:.0f}%；僅供風險提示，不阻擋發布。")
    if confidence < advisory_confidence:
        warnings.append(f"模型信心 {confidence:.1f}% 低於原建議值 {advisory_confidence:.0f}%；仍可發布。")
    if not ((game.get("away") or {}).get("probable_pitcher") or {}).get("announced"):
        warnings.append("客隊預告先發來源仍在更新。")
    if not ((game.get("home") or {}).get("probable_pitcher") or {}).get("announced"):
        warnings.append("主隊預告先發來源仍在更新。")
    return {
        "game_pk": game_id, "league": code, "matchup": selection.get("matchup"),
        "time_taiwan": selection.get("time_taiwan"), "display_time_taiwan": selection.get("display_time_taiwan") or game.get("display_time_taiwan"),
        "game_label": selection.get("game_label") or game.get("game_label") or "", "game_number": selection.get("game_number") if selection.get("game_number") is not None else game.get("game_number"),
        "is_doubleheader": bool(selection.get("is_doubleheader") or game.get("is_doubleheader")), "venue": game.get("venue"),
        "event": {"game_type": "R", "context": "regular", "label": game.get("event_label") or "例行賽", "special": False},
        "pick": selection.get("pick"), "confidence": confidence, "data_quality": data_quality,
        "warnings": warnings, "blockers": blockers, "can_publish": not blockers, "auto_publish_ready": not blockers,
        "requires_confirmation": False, "timing": {"stage": f"{code.lower()}_advisory_release"},
        "checklist": {"model_stage": model_stage, "valid_game_id": bool(game_id), "valid_pick_direction": pick_side in {"away", "home"}, "both_starters_ready": starters.get("both_starters_ready") is True, "data_quality_advisory_passed": data_quality >= advisory_data_quality, "confidence_advisory_passed": confidence >= advisory_confidence, "moneyline_only": True},
        "roster_validation": {}, "lineup_validation_rate": 1.0 if ((selection.get("analysis_groups") or {}).get("lineup") or {}).get("official_lineups_ready") else 0.0,
        "updated_at": selection.get("generated_at") or selection.get("updated_at"),
    }


def founder_npb_candidate(selection: dict) -> dict:
    return founder_asian_candidate(selection, "NPB")


async def _founder_free_candidates(request: Request, target_date: date, league: str) -> tuple[list[dict], list[dict], str]:
    if league in {"NPB", "KBO", "CPBL"}:
        selections = await asian_market_candidates_for_date(request, target_date, league, [])
        selections = [item for item in selections if item.get("market") == "moneyline"]
        candidates = [founder_asian_candidate(item, league) for item in selections]
        candidates.sort(key=lambda item: item["confidence"], reverse=True)
        return candidates, selections, f"{league} 所有未開賽場次都會排序顯示；資料完整度、先發與打線僅作風險提示，不阻擋手動或自動發布。"
    try:
        analyses = await service(request).matchup_analyses(target_date, pitcher_limit=None)
    except MLBUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    selections = list(analyses.get("items") or [])
    candidates = [founder_candidate(item) for item in selections]
    candidates.sort(key=lambda item: item["confidence"], reverse=True)
    return candidates, selections, analyses.get("message") or "MLB 候選場次已載入。"


async def auto_publish_npb_free_pick(
    request: Request,
    target_date: date,
    *,
    now: datetime | None = None,
) -> dict:
    """Publish one NPB free pick as a founder-authorized one-hour fallback.

    The trigger is based on the earliest valid NPB game of the day.  It never
    publishes MLB or Pro packages, never replaces a manual NPB publication and
    requires only an unstarted game and a valid recommendation direction;
    missing enrichment data is advisory and lowers confidence instead of blocking.
    """

    if not settings.npb_auto_publish_enabled:
        return {
            "published": False,
            "state": "disabled",
            "league": "NPB",
            "message": "NPB 自動發布未啟用。",
        }
    repository = records_repository(request)
    if not repository.enabled:
        raise RecordsStorageError("Recommendation records database is not configured")

    existing = await repository.get_record_for_date(target_date.isoformat(), "NPB")
    if existing:
        return {
            "published": False,
            "state": "already_published",
            "league": "NPB",
            "record_id": existing.get("id"),
            "published_at": existing.get("published_at"),
            "message": "今日 NPB 已由創辦人或自動備援正式發布，不再更換。",
        }

    schedule = await npb_service(request).games_for_date(target_date)
    window = _npb_auto_publish_window(
        list(schedule.get("items") or []),
        now=now,
        lead_minutes=settings.npb_auto_publish_lead_minutes,
        grace_minutes=settings.npb_auto_publish_scheduler_grace_minutes,
    )
    if not window["due"]:
        return {
            "published": False,
            "league": "NPB",
            **window,
        }

    current = now or datetime.now(TAIPEI)
    if current.tzinfo is None:
        current = current.replace(tzinfo=TAIPEI)
    current = current.astimezone(TAIPEI)
    future_game_ids = {
        str(game.get("game_pk") or game.get("external_game_id"))
        for game in schedule.get("items") or []
        if (start := parse_game_datetime(game.get("game_date"))) is not None
        and (start if start.tzinfo else start.replace(tzinfo=TAIPEI)).astimezone(TAIPEI) > current
        and str(game.get("status") or "upcoming").strip().lower()
        not in {"cancelled", "canceled", "postponed", "void", "no_game", "final", "completed", "live", "in_progress", "in progress"}
    }
    candidates, selections, _message = await _founder_free_candidates(request, target_date, "NPB")
    eligible = sorted(
        (
            item for item in candidates
            if item.get("can_publish") is True
            and str(item.get("game_pk")) in future_game_ids
        ),
        key=lambda item: float(item.get("confidence") or 0),
        reverse=True,
    )
    if not eligible:
        return {
            "published": False,
            "state": "no_eligible_candidate",
            "league": "NPB",
            "message": "已進入自動發布時間，但目前沒有具備有效賽事與推薦方向的 NPB 候選；稍後會再次檢查。",
            **{key: value for key, value in window.items() if key not in {"due", "state", "message"}},
        }

    policy = eligible[0]
    selected_key = str(policy.get("game_pk"))
    selection = next(
        (item for item in selections if str(item.get("game_pk")) == selected_key),
        None,
    )
    if selection is None:
        return {
            "published": False,
            "state": "candidate_changed",
            "league": "NPB",
            "message": "NPB 候選在鎖定前已更新，下一次排程會重新選擇。",
        }

    # Recheck immediately before the immutable insert so a founder click wins
    # cleanly if it races with the scheduled fallback.
    existing = await repository.get_record_for_date(target_date.isoformat(), "NPB")
    if existing:
        return {
            "published": False,
            "state": "already_published",
            "league": "NPB",
            "record_id": existing.get("id"),
            "published_at": existing.get("published_at"),
            "message": "創辦人已先完成 NPB 正式發布，自動備援未更換內容。",
        }

    published_at = iso_utc()
    selection = {
        **selection,
        "league": "NPB",
        "target_date": target_date.isoformat(),
        "published_at": published_at,
        "status": "published",
        "is_active": True,
        "game_id": selection.get("game_pk"),
        "recommendation_type": "free_pick",
        "publication": {
            **(selection.get("publication") or {}),
            "mode": "npb_auto_fallback",
            "automatic": True,
            "league": "NPB",
            "target_date": target_date.isoformat(),
            "published_at": published_at,
            "status": "published",
            "is_active": True,
            "game_id": selection.get("game_pk"),
            "recommendation_type": "free_pick",
            "trigger": "earliest_npb_game_minus_60_minutes",
            "trigger_game": window.get("earliest_game"),
            "lead_minutes": settings.npb_auto_publish_lead_minutes,
            "special_event": bool((policy.get("event") or {}).get("special")),
            "event_label": (policy.get("event") or {}).get("label") or "NPB 例行賽",
            "warnings_confirmed": bool(policy.get("warnings")),
            "founder_authorized_fallback": True,
        },
    }
    stored, created = await repository.publish_prediction_once(target_date.isoformat(), selection)
    if not created:
        return {
            "published": False,
            "state": "already_published",
            "league": "NPB",
            "record_id": stored.get("id"),
            "published_at": stored.get("published_at"),
            "message": "另一個發布動作已先鎖定今日 NPB，自動備援未覆蓋。",
        }
    try:
        await performance_repository(request).capture_public(
            target_date.isoformat(), str(stored.get("id")), selection
        )
    except PerformanceStorageError:
        pass
    try:
        social = await _publish_free_social(request, stored, "pregame")
    except (RecordsStorageError, SocialPublishingError) as exc:
        social = {"status": "failed", "error": str(exc)}
    return {
        "published": True,
        "state": "published",
        "league": "NPB",
        "record_id": stored.get("id"),
        "published_at": published_at,
        "selection": stored.get("prediction_snapshot") or selection,
        "social": social,
        "earliest_game": window.get("earliest_game"),
        "message": "創辦人尚未手動發布；系統已在今日最早 NPB 開賽前一小時，自動發布最高合格免費精選。",
    }


async def auto_publish_npb_pro_package(
    request: Request,
    target_date: date,
    *,
    now: datetime | None = None,
) -> dict:
    """Auto-publish NPB Pro when valid real-odds candidates exist.

    Model completeness remains visible as advisory metadata but is not a release
    gate because NPB starters and lineups are often unavailable until late.
    """

    if not settings.npb_pro_auto_publish_enabled:
        return {
            "published": False,
            "state": "disabled",
            "league": "NPB",
            "message": "NPB Pro 自動發布未啟用。",
        }
    repository = records_repository(request)
    if not repository.enabled:
        raise RecordsStorageError("Recommendation records database is not configured")

    existing_record = await repository.get_prediction_package_for_date(target_date.isoformat())
    existing_package = package_from_record(existing_record) if existing_record else None
    if existing_package and _package_has_league(existing_package, "NPB"):
        return {
            "published": False,
            "state": "already_published",
            "league": "NPB",
            "record_id": existing_record.get("id") if existing_record else None,
            "published_at": ((existing_package.get("publication") or {}).get("league_batches") or {}).get("NPB", {}).get("published_at"),
            "message": "今日 NPB Pro 已由創辦人或自動備援正式發布，不再更換。",
        }

    schedule = await npb_service(request).games_for_date(target_date)
    window = _npb_auto_publish_window(
        list(schedule.get("items") or []),
        now=now,
        lead_minutes=settings.npb_auto_publish_lead_minutes,
        grace_minutes=settings.npb_auto_publish_scheduler_grace_minutes,
    )
    if not window["due"]:
        return {"published": False, "league": "NPB", **window}

    bundle = await founder_market_candidate_bundle(request, target_date, "NPB")
    candidates = bundle.get("candidates") or {}
    parlays = candidates.get("parlays") or {}
    current = now or datetime.now(TAIPEI)
    if current.tzinfo is None:
        current = current.replace(tzinfo=TAIPEI)
    current = current.astimezone(TAIPEI)

    def unstarted(items: list[dict] | None) -> list[dict]:
        result: list[dict] = []
        for item in items or []:
            start = _selection_start_datetime(item)
            if start is not None and start > current:
                result.append(item)
        return result

    # The public NPB moneyline may also be the only qualified real-odds Pro
    # play.  Auto publication therefore uses every formal NPB candidate rather
    # than the UI convenience list that normally hides the free-pick duplicate.
    selected = {
        "moneylines": [item.get("candidate_id") for item in unstarted(candidates.get("moneylines"))],
        "run_lines": [item.get("candidate_id") for item in unstarted(candidates.get("run_lines"))],
        "totals": [item.get("candidate_id") for item in unstarted(candidates.get("totals"))],
        "two_leg": [item.get("candidate_id") for item in unstarted(parlays.get("two_leg"))[:2]],
        "three_leg": [item.get("candidate_id") for item in unstarted(parlays.get("three_leg"))[:1]],
    }
    league_package = build_selected_market_package(
        bundle,
        selected,
        publication_mode="npb_auto_fallback",
    )
    readiness = ((bundle.get("readiness") or {}).get("NPB") or {})
    if not league_package.get("published"):
        return {
            "published": False,
            "state": readiness.get("status") or "no_eligible_candidate",
            "league": "NPB",
            "readiness": readiness,
            "message": readiness.get("message") or "目前沒有具備有效推薦方向與真實盤口的 NPB Pro 候選；稍後會再次檢查。",
            **{key: value for key, value in window.items() if key not in {"due", "state", "message"}},
        }
    invalid = _npb_pro_package_errors(league_package)
    if invalid:
        return {
            "published": False,
            "state": "safety_gate_failed",
            "league": "NPB",
            "invalid_candidates": invalid,
            "message": "NPB Pro 安全驗證未通過；未發布任何模擬盤口或無效推薦方向。",
        }

    # Re-read immediately before persistence so a manual publish always wins.
    current_record = await repository.get_prediction_package_for_date(target_date.isoformat())
    current_package = package_from_record(current_record) if current_record else None
    if current_package and _package_has_league(current_package, "NPB"):
        return {
            "published": False,
            "state": "already_published",
            "league": "NPB",
            "record_id": current_record.get("id") if current_record else None,
            "message": "創辦人已先完成 NPB Pro 正式發布，自動備援未更換內容。",
        }

    published_at = iso_utc()
    league_package = _stamp_published_package(
        league_package,
        league="NPB",
        target_date=target_date,
        published_at=published_at,
    )
    publication = league_package.setdefault("publication", {})
    publication.update({
        "mode": "npb_auto_fallback",
        "automatic": True,
        "founder_authorized_fallback": True,
        "trigger": "earliest_npb_game_minus_60_minutes",
        "trigger_game": window.get("earliest_game"),
        "lead_minutes": settings.npb_auto_publish_lead_minutes,
        "league_locks": {"NPB": True},
        "last_published_league": "NPB",
    })

    if current_record and current_package:
        package = _merge_league_package(current_package, league_package, "NPB")
        stored = await repository.replace_prediction_package(
            target_date.isoformat(),
            package,
            preserve_results=current_record.get("results") or {},
        )
    else:
        package = league_package
        stored, created = await repository.publish_prediction_package_once(
            target_date.isoformat(), package
        )
        if not created:
            raced_package = package_from_record(stored)
            if _package_has_league(raced_package, "NPB"):
                return {
                    "published": False,
                    "state": "already_published",
                    "league": "NPB",
                    "record_id": stored.get("id"),
                    "message": "另一個發布動作已先鎖定今日 NPB Pro，自動備援未覆蓋。",
                }
            package = _merge_league_package(raced_package, league_package, "NPB")
            stored = await repository.replace_prediction_package(
                target_date.isoformat(),
                package,
                preserve_results=stored.get("results") or {},
            )
    try:
        await performance_repository(request).capture_package(
            target_date.isoformat(), str(stored.get("id")), package
        )
    except PerformanceStorageError:
        pass
    try:
        social = await _publish_pro_social(request, stored, "teaser", "NPB")
    except (RecordsStorageError, SocialPublishingError) as exc:
        social = {"status": "failed", "error": str(exc)}
    selected_counts = (league_package.get("publication") or {}).get("selected_counts") or {}
    return {
        "published": True,
        "state": "published",
        "league": "NPB",
        "record_id": stored.get("id"),
        "published_at": published_at,
        "selected_counts": selected_counts,
        "social": social,
        "readiness": readiness,
        "earliest_game": window.get("earliest_game"),
        "message": "創辦人尚未手動發布；系統已在最早 NPB 開賽前一小時，自動發布具有效推薦方向與真實盤口的 Pro 推薦。",
    }


def _asian_auto_settings(league: str) -> dict:
    code = str(league).upper()
    if code == "NPB":
        return {"free": settings.npb_auto_publish_enabled, "pro": settings.npb_pro_auto_publish_enabled, "lead": settings.npb_auto_publish_lead_minutes, "grace": settings.npb_auto_publish_scheduler_grace_minutes, "odds_key": settings.npb_odds_sport_key}
    if code == "KBO":
        return {"free": settings.kbo_auto_publish_enabled, "pro": settings.kbo_pro_auto_publish_enabled, "lead": settings.kbo_auto_publish_lead_minutes, "grace": settings.kbo_auto_publish_scheduler_grace_minutes, "odds_key": settings.kbo_odds_sport_key}
    if code == "CPBL":
        return {"free": settings.cpbl_auto_publish_enabled, "pro": settings.cpbl_pro_auto_publish_enabled, "lead": settings.cpbl_auto_publish_lead_minutes, "grace": settings.cpbl_auto_publish_scheduler_grace_minutes, "odds_key": settings.cpbl_odds_sport_key}
    raise ValueError(f"Unsupported auto-publish league: {code}")


async def auto_publish_asian_free_pick(request: Request, target_date: date, league: str, *, now: datetime | None = None) -> dict:
    code = _prediction_league(league)
    if code == "MLB":
        return {"published": False, "state": "manual_only", "league": code, "message": "MLB 維持創辦人手動發布。"}
    policy = _asian_auto_settings(code)
    if not policy["free"]:
        return {"published": False, "state": "disabled", "league": code, "message": f"{code} 自動發布未啟用。"}
    repository = records_repository(request)
    if not repository.enabled:
        raise RecordsStorageError("Recommendation records database is not configured")
    existing = await repository.get_record_for_date(target_date.isoformat(), code)
    if existing:
        return {"published": False, "state": "already_published", "league": code, "record_id": existing.get("id"), "published_at": existing.get("published_at"), "message": f"今日 {code} 已正式發布，不再更換。"}
    schedule = await baseball_service(request, code).games_for_date(target_date)
    window = _npb_auto_publish_window(list(schedule.get("items") or []), now=now, lead_minutes=policy["lead"], grace_minutes=policy["grace"])
    if not window["due"]:
        return {"published": False, "league": code, **window}
    current = now or datetime.now(TAIPEI)
    if current.tzinfo is None:
        current = current.replace(tzinfo=TAIPEI)
    current = current.astimezone(TAIPEI)
    future_ids = {
        str(game.get("game_pk") or game.get("external_game_id"))
        for game in schedule.get("items") or []
        if (start := parse_game_datetime(game.get("game_date"))) is not None
        and (start if start.tzinfo else start.replace(tzinfo=TAIPEI)).astimezone(TAIPEI) > current
        and str(game.get("status") or "upcoming").lower() in {"upcoming", "scheduled", "preview"}
    }
    candidates, selections, _ = await _founder_free_candidates(request, target_date, code)
    eligible = sorted((item for item in candidates if item.get("can_publish") is True and str(item.get("game_pk")) in future_ids), key=lambda item: float(item.get("confidence") or 0), reverse=True)
    if not eligible:
        return {"published": False, "state": "no_eligible_candidate", "league": code, "message": f"已進入自動發布時間，但目前沒有有效 {code} 候選；稍後會再次檢查。", **{k: v for k, v in window.items() if k not in {"due", "state", "message"}}}
    chosen = eligible[0]
    selection = next((item for item in selections if str(item.get("game_pk")) == str(chosen.get("game_pk"))), None)
    if not selection:
        return {"published": False, "state": "candidate_changed", "league": code, "message": f"{code} 候選在鎖定前已更新。"}
    existing = await repository.get_record_for_date(target_date.isoformat(), code)
    if existing:
        return {"published": False, "state": "already_published", "league": code, "record_id": existing.get("id"), "message": f"創辦人已先完成 {code} 正式發布。"}
    published_at = iso_utc()
    selection = {**selection, "league": code, "target_date": target_date.isoformat(), "published_at": published_at, "status": "published", "is_active": True, "game_id": selection.get("game_pk"), "recommendation_type": "free_pick", "publication": {**(selection.get("publication") or {}), "mode": f"{code.lower()}_auto_fallback", "automatic": True, "league": code, "target_date": target_date.isoformat(), "published_at": published_at, "status": "published", "is_active": True, "game_id": selection.get("game_pk"), "recommendation_type": "free_pick", "trigger": f"earliest_{code.lower()}_game_minus_{policy['lead']}_minutes", "trigger_game": window.get("earliest_game"), "lead_minutes": policy["lead"], "warnings_confirmed": bool(chosen.get("warnings")), "founder_authorized_fallback": True}}
    stored, created = await repository.publish_prediction_once(target_date.isoformat(), selection)
    if not created:
        return {"published": False, "state": "already_published", "league": code, "record_id": stored.get("id"), "message": f"另一個發布動作已先鎖定今日 {code}。"}
    try:
        await performance_repository(request).capture_public(target_date.isoformat(), str(stored.get("id")), selection)
    except PerformanceStorageError:
        pass
    try:
        social = await _publish_free_social(request, stored, "pregame")
    except (RecordsStorageError, SocialPublishingError) as exc:
        social = {"status": "failed", "error": str(exc)}
    return {"published": True, "state": "published", "league": code, "record_id": stored.get("id"), "published_at": published_at, "selection": stored.get("prediction_snapshot") or selection, "social": social, "earliest_game": window.get("earliest_game"), "message": f"系統已在今日最早 {code} 開賽前一小時，自動發布最高合格免費精選。"}


async def auto_publish_asian_pro_package(request: Request, target_date: date, league: str, *, now: datetime | None = None) -> dict:
    code = _prediction_league(league)
    if code == "MLB":
        return {"published": False, "state": "manual_only", "league": code, "message": "MLB Pro 維持創辦人手動發布。"}
    policy = _asian_auto_settings(code)
    if not policy["pro"]:
        return {"published": False, "state": "disabled", "league": code, "message": f"{code} Pro 自動發布未啟用。"}
    repository = records_repository(request)
    if not repository.enabled:
        raise RecordsStorageError("Recommendation records database is not configured")
    existing_record = await repository.get_prediction_package_for_date(target_date.isoformat())
    existing_package = package_from_record(existing_record) if existing_record else None
    if existing_package and _package_has_league(existing_package, code):
        return {"published": False, "state": "already_published", "league": code, "record_id": existing_record.get("id") if existing_record else None, "message": f"今日 {code} Pro 已正式發布。"}
    schedule = await baseball_service(request, code).games_for_date(target_date)
    window = _npb_auto_publish_window(list(schedule.get("items") or []), now=now, lead_minutes=policy["lead"], grace_minutes=policy["grace"])
    if not window["due"]:
        return {"published": False, "league": code, **window}
    bundle = await founder_market_candidate_bundle(request, target_date, code)
    candidates = bundle.get("candidates") or {}
    parlays = candidates.get("parlays") or {}
    current = now or datetime.now(TAIPEI)
    if current.tzinfo is None:
        current = current.replace(tzinfo=TAIPEI)
    current = current.astimezone(TAIPEI)
    def unstarted(items):
        return [item for item in (items or []) if (start := _selection_start_datetime(item)) is not None and start > current]
    selected = {"moneylines": [item.get("candidate_id") for item in unstarted(candidates.get("moneylines"))], "run_lines": [item.get("candidate_id") for item in unstarted(candidates.get("run_lines"))], "totals": [item.get("candidate_id") for item in unstarted(candidates.get("totals"))], "two_leg": [item.get("candidate_id") for item in unstarted(parlays.get("two_leg"))[:2]], "three_leg": [item.get("candidate_id") for item in unstarted(parlays.get("three_leg"))[:1]]}
    league_package = build_selected_market_package(bundle, selected, publication_mode=f"{code.lower()}_auto_fallback")
    readiness = ((bundle.get("readiness") or {}).get(code) or {})
    if not league_package.get("published"):
        return {"published": False, "state": readiness.get("status") or "no_eligible_candidate", "league": code, "readiness": readiness, "message": readiness.get("message") or f"目前沒有具備有效方向與真實盤口的 {code} Pro 候選。", **{k: v for k, v in window.items() if k not in {"due", "state", "message"}}}
    invalid = _asian_pro_package_errors(league_package, code)
    if invalid:
        return {"published": False, "state": "safety_gate_failed", "league": code, "invalid_candidates": invalid, "message": f"{code} Pro 安全驗證未通過；未發布模擬盤口。"}
    current_record = await repository.get_prediction_package_for_date(target_date.isoformat())
    current_package = package_from_record(current_record) if current_record else None
    if current_package and _package_has_league(current_package, code):
        return {"published": False, "state": "already_published", "league": code, "record_id": current_record.get("id") if current_record else None, "message": f"創辦人已先完成 {code} Pro 發布。"}
    published_at = iso_utc()
    league_package = _stamp_published_package(league_package, league=code, target_date=target_date, published_at=published_at)
    publication = league_package.setdefault("publication", {})
    publication.update({"mode": f"{code.lower()}_auto_fallback", "automatic": True, "founder_authorized_fallback": True, "trigger": f"earliest_{code.lower()}_game_minus_{policy['lead']}_minutes", "trigger_game": window.get("earliest_game"), "lead_minutes": policy["lead"], "league_locks": {code: True}, "last_published_league": code})
    if current_record and current_package:
        package = _merge_league_package(current_package, league_package, code)
        stored = await repository.replace_prediction_package(target_date.isoformat(), package, preserve_results=current_record.get("results") or {})
    else:
        package = league_package
        stored, created = await repository.publish_prediction_package_once(target_date.isoformat(), package)
        if not created:
            raced = package_from_record(stored)
            if _package_has_league(raced, code):
                return {"published": False, "state": "already_published", "league": code, "record_id": stored.get("id"), "message": f"另一個發布動作已先鎖定今日 {code} Pro。"}
            package = _merge_league_package(raced, league_package, code)
            stored = await repository.replace_prediction_package(target_date.isoformat(), package, preserve_results=stored.get("results") or {})
    try:
        await performance_repository(request).capture_package(target_date.isoformat(), str(stored.get("id")), package)
    except PerformanceStorageError:
        pass
    try:
        social = await _publish_pro_social(request, stored, "teaser", code)
    except (RecordsStorageError, SocialPublishingError) as exc:
        social = {"status": "failed", "error": str(exc)}
    return {"published": True, "state": "published", "league": code, "record_id": stored.get("id"), "published_at": published_at, "selected_counts": (league_package.get("publication") or {}).get("selected_counts") or {}, "social": social, "readiness": readiness, "earliest_game": window.get("earliest_game"), "message": f"系統已在最早 {code} 開賽前一小時，自動發布具有效方向與真實盤口的 Pro 推薦。"}


@app.get(f"{settings.api_prefix}/admin/predictions/candidates")
async def founder_prediction_candidates(
    request: Request,
    prediction_date: date | None = Query(default=None, alias="date"),
    league: str = Query(default="MLB", pattern="^(MLB|NPB|KBO|CPBL)$"),
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    await admin_member(request, authorization)
    league = _prediction_league(league)
    target_date = requested_date(prediction_date)
    repository = records_repository(request)
    if not repository.enabled:
        raise HTTPException(status_code=503, detail="Recommendation database is not configured")
    try:
        existing = await repository.get_record_for_date(target_date.isoformat(), league)
    except RecordsStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    if existing:
        snapshot = existing.get("prediction_snapshot")
        selection = deepcopy(snapshot) if isinstance(snapshot, dict) else {}
        # The founder control card must use the same settled record as the
        # public record page.  The immutable prediction snapshot itself does
        # not change after publication, so the settlement result has to be
        # merged from the record row every time this endpoint is read.
        selection["result"] = _record_result_payload(existing) or {"status": "pending"}
        return {
            "date": target_date.isoformat(),
            "league": _selection_league(selection or {}),
            "requested_league": league,
            "locked": True,
            "selection": selection,
            "items": [],
            "message": f"此賽事日的 {league} 免費精選已鎖定；MLB、NPB、KBO、CPBL 每天都可各自發布一場。",
        }

    items, _selections, message = await _founder_free_candidates(request, target_date, league)
    return {
        "date": target_date.isoformat(),
        "league": league,
        "locked": False,
        "items": items,
        "count": len(items),
        "message": message,
    }


@app.post(f"{settings.api_prefix}/admin/predictions/publish")
async def founder_publish_prediction(
    request: Request,
    command: FounderPredictionPublish,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    await admin_member(request, authorization)
    league = _prediction_league(command.league)
    repository = records_repository(request)
    if not repository.enabled:
        raise HTTPException(status_code=503, detail="Recommendation database is not configured")
    try:
        existing = await repository.get_record_for_date(command.date.isoformat(), league)
    except RecordsStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    if existing:
        existing_snapshot = existing.get("prediction_snapshot") if isinstance(existing.get("prediction_snapshot"), dict) else {}
        existing_game_pk = existing.get("game_pk") or existing_snapshot.get("game_pk") or existing_snapshot.get("game_id")
        if str(existing_game_pk or "") == str(command.game_pk):
            return {
                "ok": True,
                "date": command.date.isoformat(),
                "league": league,
                "locked": True,
                "created": False,
                "idempotent": True,
                "target_date": command.date.isoformat(),
                "published_at": existing.get("published_at") or existing_snapshot.get("published_at"),
                "status": "published",
                "selection": existing_snapshot,
                "social": {"status": "unchanged"},
                "message": f"{league} 每日免費精選先前已成功寫入；本次視為發布成功。",
            }
        raise HTTPException(status_code=409, detail=f"此賽事日的 {league} 免費精選已鎖定，不能再更換場次。")

    candidates, selections, _message = await _founder_free_candidates(request, command.date, league)
    key = str(command.game_pk)
    selection = next((item for item in selections if str(item.get("game_pk")) == key), None)
    policy = next((item for item in candidates if str(item.get("game_pk")) == key), None)
    if selection is None or policy is None:
        raise HTTPException(status_code=404, detail="找不到這場尚未開賽的候選賽事。")
    if not policy["can_publish"]:
        raise HTTPException(status_code=422, detail={"message": "這場比賽目前不可正式發布。", "blockers": policy["blockers"]})
    if policy["requires_confirmation"] and not command.confirm_warning:
        raise HTTPException(status_code=409, detail={"message": "這場比賽需要創辦人再次確認。", "warnings": policy["warnings"]})

    published_at = iso_utc()
    selection = {
        **selection,
        "league": league,
        "target_date": command.date.isoformat(),
        "published_at": published_at,
        "status": "published",
        "is_active": True,
        "game_id": selection.get("game_pk"),
        "recommendation_type": "free_pick",
        "publication": {
            **(selection.get("publication") or {}),
            "mode": "founder_selected",
            "league": league,
            "target_date": command.date.isoformat(),
            "published_at": published_at,
            "status": "published",
            "is_active": True,
            "game_id": selection.get("game_pk"),
            "recommendation_type": "free_pick",
            "special_event": policy["event"]["special"],
            "event_label": policy["event"]["label"],
            "warnings_confirmed": bool(policy["warnings"]),
        },
    }
    try:
        stored, created = await repository.publish_prediction_once(command.date.isoformat(), selection)
    except RecordsStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    if not created:
        stored_snapshot = stored.get("prediction_snapshot") if isinstance(stored.get("prediction_snapshot"), dict) else {}
        stored_game_pk = stored.get("game_pk") or stored_snapshot.get("game_pk") or stored_snapshot.get("game_id")
        if str(stored_game_pk or "") != str(command.game_pk):
            raise HTTPException(status_code=409, detail=f"另一筆 {league} 免費精選已先完成鎖定。")
        # A previous insert may have succeeded even when its HTTP response was
        # lost. Treat the read-back row as success and let the regular social
        # synchronization job publish any missing Instagram asset once.
        return {
            "ok": True,
            "date": command.date.isoformat(),
            "league": league,
            "locked": True,
            "created": False,
            "idempotent": True,
            "target_date": command.date.isoformat(),
            "published_at": stored.get("published_at") or stored_snapshot.get("published_at") or published_at,
            "status": "published",
            "selection": stored_snapshot or selection,
            "social": {"status": "pending_sync"},
            "message": f"{league} 每日免費精選已寫入；系統已確認鎖定成功。",
        }
    try:
        await performance_repository(request).capture_public(command.date.isoformat(), str(stored.get("id")), selection)
    except PerformanceStorageError:
        pass
    try:
        social = await _publish_free_social(request, stored, "pregame")
    except (RecordsStorageError, SocialPublishingError) as exc:
        social = {"status": "failed", "error": str(exc)}
    return {
        "ok": True,
        "date": command.date.isoformat(),
        "league": league,
        "locked": True,
        "created": True,
        "target_date": command.date.isoformat(),
        "published_at": published_at,
        "status": "published",
        "selection": stored.get("prediction_snapshot") or selection,
        "social": social,
        "message": f"{league} 每日免費精選已正式發布；會員現在重新整理即可看見。",
    }


class FounderMarketPublish(BaseModel):
    date: date
    league: str = "MLB"
    moneylines: list[str] = Field(default_factory=list)
    run_lines: list[str] = Field(default_factory=list)
    totals: list[str] = Field(default_factory=list)
    two_leg: list[str] = Field(default_factory=list)
    three_leg: list[str] = Field(default_factory=list)


def _asian_analysis_for_markets(game: dict, analysis: dict, league: str) -> dict:
    groups = analysis.get("analysis_groups") or {}
    normalized_groups = {
        "team_strength": groups.get("team") or {},
        "starter": groups.get("starter") or {},
        "lineup": groups.get("offense") or {},
        "bullpen": groups.get("bullpen") or {},
        "advanced": groups.get("advanced") or {"available": False, "quality": 0.0, "metrics": []},
        "environment": groups.get("environment") or {"available": False, "quality": 0.0, "metrics": []},
    }
    away = game.get("away") or {}
    home = game.get("home") or {}
    return {
        "league": league,
        "game": game,
        "game_pk": str(game.get("game_pk") or game.get("external_game_id") or ""),
        "matchup": f'{away.get("abbr") or away.get("name")} @ {home.get("abbr") or home.get("name")}',
        "game_date": game.get("game_date") or game.get("date"),
        "time_taiwan": game.get("time_taiwan"),
        "display_time_taiwan": game.get("display_time_taiwan") or (f'台灣 {game.get("time_taiwan")}' if game.get("time_taiwan") else None),
        "game_label": game.get("game_label") or "",
        "game_number": game.get("game_number"),
        "is_doubleheader": bool(game.get("is_doubleheader")),
        "home_probability": analysis.get("home_probability"),
        "away_probability": analysis.get("away_probability"),
        "confidence": analysis.get("confidence"),
        "data_quality": analysis.get("data_quality"),
        "model_stage": analysis.get("model_stage") or (analysis.get("data_basis") or {}).get("model_stage"),
        "data_basis": analysis.get("data_basis") or {},
        "projections": analysis.get("projections") or {},
        "analysis_groups": normalized_groups,
        "engine": {"weights": (analysis.get("model_weights") or {}).get("engine") or {}},
        "factors": [],
        "model_version": analysis.get("model_version") or f"dm-{league.lower()}-markets-v1.0",
    }


async def asian_market_candidates_for_date(
    request: Request,
    target_date: date,
    league: str,
    odds_items: list[dict] | None = None,
    *,
    pro_only: bool = False,
    diagnostics: dict | None = None,
) -> list[dict]:
    league = _prediction_league(league)
    if league not in {"NPB", "KBO", "CPBL"}:
        return []
    adapter = baseball_service(request, league)
    try:
        schedule = await adapter.games_for_date(target_date)
    except (NPBUpstreamError, AsianBaseballUpstreamError) as exc:
        if diagnostics is not None:
            diagnostics.update({
                "date": target_date.isoformat(), "policy": "valid_direction_plus_real_odds" if pro_only else "data_advisory",
                "status": "schedule_unavailable", "schedule_games": 0, "games": [],
                "message": f"{league} 官方賽程暫時無法載入，不會發布推薦。", "error": type(exc).__name__,
            })
        return []
    games = [item for item in schedule.get("items") or [] if str(item.get("status") or "").lower() in {"upcoming", "scheduled", "preview"}]
    available_odds = odds_items or []

    async def build(game: dict) -> dict:
        game_pk = str(game.get("game_pk") or game.get("external_game_id") or "")
        matchup = f'{(game.get("away") or {}).get("abbr") or (game.get("away") or {}).get("name")} @ {(game.get("home") or {}).get("abbr") or (game.get("home") or {}).get("name")}'
        summary = {"game_pk": game_pk, "matchup": matchup, "time_taiwan": game.get("time_taiwan"), "display_time_taiwan": game.get("display_time_taiwan"), "model_stage": "unavailable", "full_model_ready": False, "official_lineups_ready": False, "odds_matched": False, "markets": [], "candidate_count": 0, "formal_count": 0, "blockers": [], "advisories": []}
        try:
            detail = await adapter.game_detail(game_pk)
        except (NPBUpstreamError, AsianBaseballUpstreamError) as exc:
            summary["blockers"] = ["基礎模型資料暫時無法載入"]
            summary["error"] = type(exc).__name__
            return {"selections": [], "diagnostic": summary, "event_id": None}
        detail_game = detail.get("game") or game
        analysis = detail.get("analysis") or {}
        data_basis = analysis.get("data_basis") or {}
        starter_group = (analysis.get("analysis_groups") or {}).get("starter") or {}
        data_quality = float(analysis.get("data_quality") or 0.0)
        model_stage = str(analysis.get("model_stage") or data_basis.get("model_stage") or "base").lower()
        full_model = model_stage == "full"
        full_market_ready = bool(data_basis.get("full_market_ready") or (full_model and starter_group.get("both_starters_ready") is True))
        summary.update({"model_stage": "full" if full_model else "base", "full_model_ready": full_market_ready, "official_lineups_ready": bool(data_basis.get("official_lineups_ready")), "data_quality": round(data_quality, 2)})
        market_analysis = _asian_analysis_for_markets(detail_game, analysis, league)
        event = match_odds_event(market_analysis, available_odds)
        summary["odds_matched"] = bool(event)
        summary["markets"] = list((event.get("markets") or {}).keys()) if event else []
        selections: list[dict] = []
        real_moneyline = None
        if event:
            real_moneyline = moneyline_candidate(market_analysis, event, minimum_probability=0.0, minimum_edge=-100.0)
            run_line = run_line_candidate(market_analysis, event, minimum_probability=0.0, minimum_edge=-100.0, minimum_projection_quality=0.0)
            total = totals_candidate(market_analysis, event, minimum_probability=0.0, minimum_edge=-100.0, minimum_projection_quality=0.0)
            for candidate in (real_moneyline, run_line, total):
                if not candidate:
                    continue
                candidate["league"] = league
                candidate["model_stage"] = "full" if full_model else "base"
                candidate["recommendation_stage"] = "full_markets" if full_model else "advisory_markets"
                candidate["full_market_ready"] = full_market_ready
                candidate["requires_confirmation"] = False
                candidate["data_advisory"] = not full_market_ready or data_quality < 0.55
                candidate["meets_threshold"] = is_asian_baseball_pro_selection(candidate, league)
                candidate["candidate_tier"] = "formal" if candidate["meets_threshold"] else "unclassified"
                candidate.setdefault("qualification_thresholds", {})["minimum_projection_quality"] = 0.0
                selections.append(candidate)
        if real_moneyline is None and not pro_only:
            model_candidate = model_only_moneyline_candidate(detail_game, analysis, minimum_probability=0.0, minimum_data_quality=0.0)
            if model_candidate:
                model_candidate["league"] = league
                model_candidate["requires_confirmation"] = False
                model_candidate["meets_threshold"] = True
                model_candidate["candidate_tier"] = "formal"
                selections.append(model_candidate)
        if starter_group.get("both_starters_ready") is not True:
            summary["advisories"].append("預告先發未完整；已降低模型信心，不阻擋免費推薦。")
        if data_quality < 0.55:
            summary["advisories"].append(f"資料完整度 {data_quality * 100:.0f}%，僅作風險提示。")
        summary["candidate_count"] = len(selections)
        summary["formal_count"] = sum(1 for item in selections if item.get("meets_threshold"))
        return {"selections": selections, "diagnostic": summary, "event_id": event.get("event_id") if event else None}

    results = await asyncio.gather(*(build(game) for game in games), return_exceptions=True)
    valid = [item for item in results if isinstance(item, dict)]
    selections = [selection for item in valid for selection in item.get("selections") or [] if isinstance(selection, dict)]
    if diagnostics is not None:
        rows = [item["diagnostic"] for item in valid]
        matched = sum(1 for row in rows if row.get("odds_matched"))
        formal = sum(1 for item in selections if item.get("meets_threshold"))
        if formal:
            state, message = "ready", f"{league} 有效推薦方向＋真實盤口已驗證，現有 {formal} 個正式 Pro 候選。"
        elif not available_odds:
            state, message = "waiting_real_odds", f"盤口商目前尚未提供 {league} 真實盤口；系統不會建立模擬盤口或自動發布 Pro。"
        elif not matched:
            state, message = "odds_unmatched", f"{league} 真實盤口已載入，但尚未和官方賽程安全配對。"
        else:
            state, message = "waiting_valid_selection", f"{league} 盤口已就緒，但目前沒有可驗證的推薦方向。"
        diagnostics.update({"date": target_date.isoformat(), "policy": "valid_direction_plus_real_odds" if pro_only else "data_advisory", "status": state, "schedule_games": len(games), "analyzed_games": len(rows), "full_model_ready_games": sum(1 for row in rows if row.get("full_model_ready")), "odds_events": len(available_odds), "matched_games": matched, "market_coverage": {"moneyline": sum(1 for row in rows if "moneyline" in row.get("markets", [])), "run_line": sum(1 for row in rows if "run_line" in row.get("markets", [])), "totals": sum(1 for row in rows if "totals" in row.get("markets", []))}, "pro_eligible_candidates": len(selections), "formal_candidates": formal, "games": rows, "message": message})
    return selections


async def npb_market_candidates_for_date(request: Request, target_date: date, odds_items: list[dict] | None = None, *, pro_only: bool = False, diagnostics: dict | None = None) -> list[dict]:
    return await asian_market_candidates_for_date(request, target_date, "NPB", odds_items, pro_only=pro_only, diagnostics=diagnostics)


async def npb_moneyline_candidates_for_date(request: Request, target_date: date) -> list[dict]:
    """Compatibility wrapper for integrations still requesting NPB moneylines only."""

    candidates = await npb_market_candidates_for_date(request, target_date, [])
    return [item for item in candidates if item.get("market") == "moneyline"]


async def asian_odds_feed_for_date(request: Request, target_date: date, league: str) -> dict:
    """Return a fresh real-odds feed for an Asian baseball league.

    CPBL first preserves the existing The Odds API path and falls back to
    Odds-API.io only when the primary feed is unavailable or empty.
    """
    code = _prediction_league(league)
    policy = _asian_auto_settings(code)
    empty = {
        "date": target_date.isoformat(),
        "configured": False,
        "count": 0,
        "items": [],
        "meta": {"fresh_for_model": False, "coverage": {}, "quota": {}},
    }
    primary = None
    if odds_service(request).enabled and policy.get("odds_key"):
        try:
            primary = await odds_service(request).odds_for_date(target_date, sport_key=policy["odds_key"])
            if (primary.get("meta") or {}).get("fresh_for_model") and int(primary.get("count") or 0) > 0:
                return primary
        except OddsUpstreamError:
            primary = None
    if code == "CPBL" and odds_api_io_service(request).enabled:
        try:
            fallback = await odds_api_io_service(request).odds_for_cpbl_date(target_date)
            if (fallback.get("meta") or {}).get("fresh_for_model"):
                return fallback
        except OddsApiIoUpstreamError:
            pass
    return primary or empty


async def founder_market_candidate_bundle(request: Request, target_date: date, league: str = "MLB") -> dict:
    league = _prediction_league(league)
    repository = records_repository(request)
    try:
        public_record = await repository.get_record_for_date(target_date.isoformat(), league)
    except RecordsStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    public_selection = None
    if public_record and isinstance(public_record.get("prediction_snapshot"), dict):
        candidate = public_record["prediction_snapshot"]
        if _selection_matches_league(candidate, league):
            public_selection = candidate

    if league == "MLB":
        if not odds_service(request).enabled:
            raise HTTPException(status_code=503, detail="真實盤口來源尚未設定，不能建立正式會員玩法。")
        try:
            feed = await odds_service(request).odds_for_date(target_date)
        except OddsUpstreamError as exc:
            raise HTTPException(status_code=502, detail=str(exc)) from exc
        if not (feed.get("meta") or {}).get("fresh_for_model"):
            raise HTTPException(status_code=409, detail="MLB 目前只有過期備援盤口，不能發布新的正式會員玩法。")
        try:
            analyses = await service(request).matchup_analyses(target_date, pitcher_limit=None)
        except MLBUpstreamError as exc:
            raise HTTPException(status_code=502, detail=str(exc)) from exc
        eligible = [
            item
            for item in analyses.get("items") or []
            if (item.get("game") or {}).get("auto_recommendation_eligible") is True
            and publication_policy(item, automatic=False)["can_publish"]
            and (((item.get("analysis_groups") or {}).get("starter") or {}).get("both_starters_ready") is True)
        ]
        bundle = build_daily_market_candidates(
            target_date.isoformat(),
            eligible,
            feed.get("items") or [],
            public_selection,
            minimum_probability=settings.min_market_probability,
            minimum_edge=settings.min_market_edge,
            minimum_projection_quality=settings.min_projection_quality,
            minimum_parlay_probability=settings.min_parlay_leg_probability,
        )
        bundle["odds_feeds"] = {
            "MLB": {
                "count": int(feed.get("count") or 0),
                "fresh_for_model": True,
                "cache": (feed.get("meta") or {}).get("cache"),
            }
        }
    else:
        league_policy = _asian_auto_settings(league)
        feed = await asian_odds_feed_for_date(request, target_date, league)
        bundle = build_daily_market_candidates(
            target_date.isoformat(), [], [], public_selection,
            minimum_probability=settings.min_market_probability,
            minimum_edge=settings.min_market_edge,
            minimum_projection_quality=settings.min_projection_quality,
            minimum_parlay_probability=settings.min_parlay_leg_probability,
        )
        readiness: dict = {}
        asian_candidates = await asian_market_candidates_for_date(
            request, target_date, league,
            (feed.get("items") or []) if (feed.get("meta") or {}).get("fresh_for_model") else [],
            pro_only=True, diagnostics=readiness,
        )
        bundle = merge_market_candidates(bundle, asian_candidates, minimum_parlay_probability=settings.min_parlay_leg_probability)
        bundle["odds_feeds"] = {
            league: {
                "sport_key": league_policy.get("odds_key"),
                "count": int(feed.get("count") or 0),
                "fresh_for_model": bool((feed.get("meta") or {}).get("fresh_for_model")),
                "cache": (feed.get("meta") or {}).get("cache"),
                "coverage": (feed.get("meta") or {}).get("coverage") or {},
                "quota": (feed.get("meta") or {}).get("quota") or {},
                "provider": (feed.get("meta") or {}).get("provider") or "The Odds API",
                "provider_league": (feed.get("meta") or {}).get("provider_league"),
                "coverage_status": (feed.get("meta") or {}).get("coverage_status"),
            }
        }
        readiness["odds_feed"] = bundle["odds_feeds"][league]
        bundle["readiness"] = {league: readiness}


    counts = (bundle.get("candidate_counts") or {}).get("by_league") or {}
    league_counts = counts.get(league) or {}
    bundle["selected_league"] = league
    bundle["league_status"] = {
        league: {
            "enabled": True,
            "formal": int(league_counts.get("total") or 0),
            "markets": league_counts,
            "real_odds": bool(
                ((bundle.get("odds_feeds") or {}).get(league) or {}).get("fresh_for_model")
                and int(((bundle.get("odds_feeds") or {}).get(league) or {}).get("count") or 0) > 0
            ),
        }
    }
    readiness = ((bundle.get("readiness") or {}).get(league) or {})
    bundle["message"] = readiness.get("message") or (
        f"{league} 候選已獨立載入；缺少先發或打線只會降低信心，不會阻擋免費推薦。"
    )
    return bundle


@app.get(f"{settings.api_prefix}/admin/markets/candidates")
async def founder_market_candidates(
    request: Request,
    prediction_date: date | None = Query(default=None, alias="date"),
    league: str = Query(default="MLB", pattern="^(MLB|NPB|KBO|CPBL)$"),
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    await admin_member(request, authorization)
    league = _prediction_league(league)
    target_date = requested_date(prediction_date)
    repository = records_repository(request)
    if not repository.enabled:
        raise HTTPException(status_code=503, detail="Recommendation database is not configured")
    try:
        existing = await repository.get_prediction_package_for_date(target_date.isoformat())
    except RecordsStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    if existing:
        existing_package = package_from_record(existing)
        locks = (existing_package.get("publication") or {}).get("league_locks") or {}
        if locks.get(league) or _package_has_league(existing_package, league):
            return {
                "date": target_date.isoformat(),
                "league": league,
                "locked": True,
                "package": _package_for_league(existing_package, league),
                "message": f"此賽事日的 {league} 會員玩法已鎖定；另一聯盟仍可稍後獨立發布。",
            }
    bundle = await founder_market_candidate_bundle(request, target_date, league)
    return {
        **bundle,
        "league": league,
        "locked": False,
        "message": bundle.get("message") or f"{league} 候選已載入；只會發布此聯盟的獨贏、讓分、大小分與同聯盟串關。",
    }


@app.post(f"{settings.api_prefix}/admin/markets/publish")
async def founder_publish_markets(
    request: Request,
    command: FounderMarketPublish,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    await admin_member(request, authorization)
    league = _prediction_league(command.league)
    repository = records_repository(request)
    if not repository.enabled:
        raise HTTPException(status_code=503, detail="Recommendation database is not configured")
    try:
        existing_record = await repository.get_prediction_package_for_date(command.date.isoformat())
    except RecordsStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    existing_package = package_from_record(existing_record) if existing_record else None
    if existing_package:
        locks = (existing_package.get("publication") or {}).get("league_locks") or {}
        if locks.get(league) or _package_has_league(existing_package, league):
            raise HTTPException(status_code=409, detail=f"此賽事日的 {league} 會員玩法已鎖定，不能再更換。")

    bundle = await founder_market_candidate_bundle(request, command.date, league)
    selected = {
        "moneylines": command.moneylines,
        "run_lines": command.run_lines,
        "totals": command.totals,
        "two_leg": command.two_leg,
        "three_leg": command.three_leg,
    }
    try:
        league_package = build_selected_market_package(bundle, selected, publication_mode="founder_selected")
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    if not league_package.get("published"):
        raise HTTPException(status_code=422, detail=f"至少選擇一個具備有效推薦方向的 {league} 會員玩法後才能發布。")
    if league in {"NPB", "KBO", "CPBL"}:
        invalid = _asian_pro_package_errors(league_package, league)
        if invalid:
            raise HTTPException(
                status_code=422,
                detail={
                    "message": f"{league} Pro 只允許發布具備有效推薦方向＋真實盤口的候選；資料完整度僅作提示。",
                    "invalid_candidates": invalid,
                },
            )
    published_at = iso_utc()
    league_package = _stamp_published_package(
        league_package,
        league=league,
        target_date=command.date,
        published_at=published_at,
    )
    publication = league_package.setdefault("publication", {})
    publication["league_locks"] = {league: True}
    publication["last_published_league"] = league

    try:
        if existing_record and existing_package:
            package = _merge_league_package(existing_package, league_package, league)
            stored = await repository.replace_prediction_package(
                command.date.isoformat(),
                package,
                preserve_results=existing_record.get("results") or {},
            )
            created = True
        else:
            package = league_package
            stored, created = await repository.publish_prediction_package_once(command.date.isoformat(), package)
    except RecordsStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    if not created:
        raise HTTPException(status_code=409, detail=f"另一筆 {league} 會員玩法已先完成鎖定。")
    try:
        await performance_repository(request).capture_package(command.date.isoformat(), str(stored.get("id")), package)
    except PerformanceStorageError:
        pass
    try:
        social = await _publish_pro_social(request, stored, "teaser", league)
    except (RecordsStorageError, SocialPublishingError) as exc:
        social = {"status": "failed", "error": str(exc)}
    locked = package_from_record(stored)
    return {
        "ok": True,
        "date": command.date.isoformat(),
        "target_date": command.date.isoformat(),
        "published_at": published_at,
        "status": "published",
        "league": league,
        "locked": True,
        "package": _package_for_league(locked, league),
        "social": social,
        "message": f"{league} 付費會員推薦已正式發布，會員現在即可看見；另一聯盟可稍後獨立發布。",
    }


async def _run_external_settlement_job(app: FastAPI) -> None:
    """Run the long settlement workflow after the cron response is sent.

    cron-job.org currently allows at most 30 seconds per request, while a full
    DiamondMind settlement can include multiple official-source lookups,
    Supabase writes, social synchronization and source monitoring.  Keeping the
    work in a tracked app task prevents false cron timeouts without skipping any
    of those duties.
    """
    async with app.state.external_settlement_lock:
        started_at = iso_utc()
        app.state.settlement_status = {
            "running": True,
            "queued": False,
            "source": "external_settlement_job",
            "started_at": started_at,
            "last_run": app.state.settlement_status.get("last_run"),
            "last_error": None,
            "free_settled_now": 0,
            "packages_settled_now": 0,
        }
        background_request = type("BackgroundRequest", (), {"app": app})()
        source_probe_task = asyncio.create_task(
            probe_league_sources(app.state.mlb, app.state.npb, datetime.now(TAIPEI).date(), app.state.kbo, app.state.cpbl),
            name="diamondmind-operations-source-probe",
        )
        try:
            free_count = await _settle_pending_records_with(
                app.state.records, app.state.mlb, app.state.npb, app.state.kbo, app.state.cpbl, app.state.performance
            )
            package_count = await _settle_pending_prediction_packages_with(
                app.state.records, app.state.mlb, app.state.npb, app.state.kbo, app.state.cpbl, app.state.performance
            )
            social = await sync_social_publications(background_request)

            try:
                source_probes = await asyncio.wait_for(
                    source_probe_task,
                    timeout=max(15.0, settings.request_timeout_seconds * 2.0),
                )
            except TimeoutError:
                source_probes = {
                    "MLB": {"ok": False, "error": "MonitorTimeout", "detail": "MLB official source probe timed out"},
                    "NPB": {"ok": False, "error": "MonitorTimeout", "detail": "NPB official source probe timed out"},
                    "KBO": {"ok": False, "error": "MonitorTimeout", "detail": "KBO official source probe timed out"},
                    "CPBL": {"ok": False, "error": "MonitorTimeout", "detail": "CPBL official source probe timed out"},
                }

            try:
                monitor = await build_operations_report(
                    repository=app.state.records,
                    odds=app.state.odds,
                    source_probes=source_probes,
                    failure_counters=app.state.operations_monitor_failures,
                    settings=settings,
                    now=datetime.now(TAIPEI),
                )
            except Exception as exc:
                monitor = {
                    "ok": False,
                    "status": "critical",
                    "checked_at": datetime.now(TAIPEI).isoformat(),
                    "checks": [],
                    "warnings": [],
                    "critical_issues": [{
                        "key": "monitor_runtime",
                        "label": "異常監控程式",
                        "status": "critical",
                        "detail": f"監控執行失敗：{type(exc).__name__}",
                    }],
                }

            result = {
                "ok": True,
                "running": False,
                "queued": False,
                "settlement_ok": True,
                "monitor_ok": bool(monitor.get("ok")),
                "time_taiwan": datetime.now(TAIPEI).isoformat(),
                "started_at": started_at,
                "last_run": iso_utc(),
                "free_settled_now": free_count,
                "packages_settled_now": package_count,
                "settled_now": free_count + package_count,
                "odds_refreshed": False,
                "recommendations_published": False,
                "instagram": social,
                "monitor": monitor,
                "source": "external_settlement_job",
                "last_error": None,
            }
            app.state.settlement_status = result
            app.state.operations_monitor_status = monitor
        except asyncio.CancelledError:
            source_probe_task.cancel()
            with suppress(asyncio.CancelledError):
                await source_probe_task
            app.state.settlement_status = {
                **dict(app.state.settlement_status or {}),
                "running": False,
                "queued": False,
                "last_run": iso_utc(),
                "last_error": "CancelledError",
            }
            raise
        except Exception as exc:
            source_probe_task.cancel()
            with suppress(asyncio.CancelledError):
                await source_probe_task
            app.state.settlement_status = {
                **dict(app.state.settlement_status or {}),
                "running": False,
                "queued": False,
                "last_run": iso_utc(),
                "last_error": type(exc).__name__,
                "error_detail": str(exc)[:500],
            }


@app.post(f"{settings.api_prefix}/jobs/settlement")
async def settlement_job(
    request: Request,
    cron_secret: str | None = Header(default=None, alias="X-DiamondMind-Cron"),
) -> Response:
    """Acknowledge the cron request immediately and queue settlement.

    The response is intentionally returned before official-source and Supabase
    work begins, so cron-job.org's 30-second cap cannot falsely mark a healthy
    settlement run as timed out.  A second request while the job is still active
    is accepted but does not start a duplicate run.
    """
    if not settings.scheduler_enabled:
        raise HTTPException(status_code=503, detail="Settlement scheduler secret is not configured")
    if not cron_secret_matches(cron_secret, settings.cron_secret):
        raise HTTPException(status_code=401, detail="Invalid scheduler credentials")
    if not settings.records_enabled:
        raise HTTPException(status_code=503, detail="Recommendation records database is not configured")

    current_task = getattr(request.app.state, "external_settlement_task", None)
    if current_task is not None and not current_task.done():
        status = dict(getattr(request.app.state, "settlement_status", {}) or {})
        return JSONResponse(
            status_code=202,
            content={
                "ok": True,
                "accepted": True,
                "already_running": True,
                "message": "Settlement is already running; duplicate execution was skipped.",
                "status": status,
            },
        )

    queued_at = iso_utc()
    request.app.state.settlement_status = {
        **dict(getattr(request.app.state, "settlement_status", {}) or {}),
        "running": True,
        "queued": True,
        "queued_at": queued_at,
        "source": "external_settlement_job",
        "last_error": None,
    }
    task = asyncio.create_task(
        _run_external_settlement_job(request.app),
        name="diamondmind-external-settlement",
    )
    request.app.state.external_settlement_task = task
    return JSONResponse(
        status_code=202,
        content={
            "ok": True,
            "accepted": True,
            "already_running": False,
            "queued_at": queued_at,
            "message": "Settlement was queued and will continue in the backend.",
        },
    )


@app.post(f"{settings.api_prefix}/jobs/asian-auto-publish")
async def asian_auto_publish_job(
    request: Request,
    job_date: date | None = Query(default=None, alias="date", description="Taiwan date, YYYY-MM-DD"),
    cron_secret: str | None = Header(default=None, alias="X-DiamondMind-Cron"),
) -> dict:
    if not settings.scheduler_enabled:
        raise HTTPException(status_code=503, detail="Asian baseball auto-publish scheduler secret is not configured")
    if not cron_secret_matches(cron_secret, settings.cron_secret):
        raise HTTPException(status_code=401, detail="Invalid scheduler credentials")
    if not settings.records_enabled:
        raise HTTPException(status_code=503, detail="Recommendation records database is not configured")

    target_date = requested_date(job_date)
    results: dict[str, dict] = {}
    for code in ("NPB", "KBO", "CPBL"):
        try:
            results[code] = {
                "free": await auto_publish_asian_free_pick(request, target_date, code),
                "pro": await auto_publish_asian_pro_package(request, target_date, code),
                "lead_minutes": _asian_auto_settings(code)["lead"],
            }
        except (RecordsStorageError, NPBUpstreamError, AsianBaseballUpstreamError) as exc:
            results[code] = {
                "free": {"published": False, "state": "error", "league": code},
                "pro": {"published": False, "state": "error", "league": code},
                "error": type(exc).__name__,
                "message": str(exc),
            }
    social = await sync_social_publications(request)
    return {
        "ok": not any(item.get("error") for item in results.values()),
        "date": target_date.isoformat(),
        "time_taiwan": datetime.now(TAIPEI).isoformat(),
        "asian_auto_publish": results,
        "instagram": social,
        "mlb_auto_publish": {
            "free": False,
            "pro": False,
            "message": "MLB 免費與 Pro 都維持創辦人手動發布。",
        },
    }


@app.post(f"{settings.api_prefix}/jobs/npb-auto-publish")
async def npb_auto_publish_job(
    request: Request,
    job_date: date | None = Query(default=None, alias="date", description="Taiwan date, YYYY-MM-DD"),
    cron_secret: str | None = Header(default=None, alias="X-DiamondMind-Cron"),
) -> dict:
    """Backward-compatible cron route that now covers NPB, KBO and CPBL.

    Existing cron-job.org configurations do not need their URL changed.
    """
    payload = await asian_auto_publish_job(request, job_date, cron_secret)
    payload["npb_auto_publish"] = (payload.get("asian_auto_publish") or {}).get("NPB") or {}
    payload["legacy_route"] = True
    payload["message"] = "既有 NPB 排程網址已升級為亞洲職棒自動發布，會獨立檢查 NPB、KBO、CPBL。"
    return payload


@app.post(f"{settings.api_prefix}/jobs/daily")
async def daily_job(
    request: Request,
    job_date: date | None = Query(default=None, alias="date", description="Taiwan date, YYYY-MM-DD"),
    cron_secret: str | None = Header(default=None, alias="X-DiamondMind-Cron"),
) -> dict:
    if not settings.scheduler_enabled:
        raise HTTPException(status_code=503, detail="Daily scheduler secret is not configured")
    if not cron_secret_matches(cron_secret, settings.cron_secret):
        raise HTTPException(status_code=401, detail="Invalid scheduler credentials")

    target_date = requested_date(job_date)
    try:
        prediction = await prediction_with_persistence(request, target_date, publish_if_eligible=False)
    except MLBUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc

    settlement = {"enabled": settings.records_enabled, "settled_now": 0}
    social = {"status": "disabled", "published_now": 0}
    if settings.records_enabled:
        try:
            settlement["settled_now"] = await settle_pending_records(request)
            settlement["packages_settled_now"] = await settle_pending_prediction_packages(request)
            social = await sync_social_publications(request)
        except RecordsStorageError:
            settlement["message"] = "紀錄資料庫暫時無法執行結算。"

    odds = odds_service(request).status()
    market_package = {
        "date": target_date.isoformat(),
        "published": False,
        "message": "真實盤口尚未提供，會員玩法不會使用猜測資料。",
    }
    if odds_service(request).enabled:
        try:
            feed = await odds_service(request).odds_for_date(target_date)
            odds.update(
                {
                    "available": True,
                    "count": feed["count"],
                    "cache": feed["meta"]["cache"],
                    "fresh_for_model": feed["meta"]["fresh_for_model"],
                    "quota": feed["meta"]["quota"],
                }
            )
            if feed["meta"]["fresh_for_model"]:
                market_package = await locked_or_generated_market_package(
                    request, target_date, prediction, feed, persist=False
                )
            else:
                market_package["message"] = "目前只有過期備援盤口，不發布新的正式玩法。"
        except OddsUpstreamError:
            # A temporary odds incident must not prevent the independent
            # moneyline model or record settlement from completing.
            odds.update({"available": False, "message": "真實盤口來源暫時無法使用。"})
    else:
        odds["available"] = False

    return {
        "ok": True,
        "date": target_date.isoformat(),
        "time_taiwan": datetime.now(TAIPEI).isoformat(),
        "prediction": prediction,
        "market_package": market_package,
        "settlement": settlement,
        "instagram": social,
        "odds": odds,
    }


@app.get(f"{settings.api_prefix}/records")
async def recommendation_records(
    request: Request,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    member = await optional_member(request, authorization)
    repository = records_repository(request)
    if not repository.enabled:
        return {
            "items": [],
            "market_packages": [],
            "count": 0,
            "stats": summarize_records([]),
            "message": "推薦紀錄資料庫尚未設定。",
            "is_demo": False,
            "database": "not_configured",
            "member": {"role": member["role"], "has_pro_access": member["has_pro_access"]},
            "pro_history_locked": not member["has_pro_access"],
            "performance_access": member.get("role") == "admin",
        }

    try:
        settled_now = await settle_pending_records(request)
        packages_settled_now = await settle_pending_prediction_packages(request)
        items = await repository.list_records()
        prediction_packages = await repository.list_prediction_packages()
    except RecordsStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc

    # Pro history is membership content. Free visitors receive only the
    # public daily free-pick record. Paid members receive every locked formal
    # package immediately, with each completed selection settling independently.
    today_taiwan = datetime.now(TAIPEI).date().isoformat()
    visible_prediction_packages: list[dict] = []
    for item in prediction_packages:
        recommendation_date = str(item.get("recommendation_date") or "")
        if recommendation_date and recommendation_date > today_taiwan:
            # The records page is history, never a preview of a future slate.
            continue
        package = package_from_record(item)
        publication_mode = str((package.get("publication") or {}).get("mode") or "")
        if publication_mode == "ai_auto":
            # V18.7 and earlier could persist scheduler candidates without
            # founder approval. Those placeholders are not formal records.
            continue
        visible_prediction_packages.append(package)

    market_packages = visible_prediction_packages if member.get("has_pro_access") else []
    if member.get("role") != "admin":
        # Public free-pick history never exposes the five-engine snapshot.
        items = [
            _strip_member_financials(deepcopy(item))
            for item in items
        ]
        for item in items:
            if isinstance(item.get("prediction_snapshot"), dict):
                item["prediction_snapshot"] = _free_pick_for_member(item["prediction_snapshot"])

        market_packages = [
            _strip_member_financials(package)
            for package in market_packages
        ]

        # Historical Pro packages may persist founder watchlist snapshots in
        # the database. Strip them at the API boundary so paid members cannot
        # recover internal candidates or internal publication notes through
        # browser developer tools.
        for package in market_packages:
            package.pop("watchlist", None)
            for group in ("moneylines", "run_lines", "totals"):
                package[group] = [
                    _selection_for_member(selection, founder=False)
                    for selection in (package.get(group) or [])
                    if isinstance(selection, dict)
                ]
            parlays = package.get("parlays") or {}
            package["parlays"] = {
                "two_leg": [
                    _selection_for_member(selection, founder=False)
                    for selection in (parlays.get("two_leg") or [])
                    if isinstance(selection, dict)
                ],
                "three_leg": [
                    _selection_for_member(selection, founder=False)
                    for selection in (parlays.get("three_leg") or [])
                    if isinstance(selection, dict)
                ],
            }
            if isinstance(package.get("moneyline"), dict):
                package["moneyline"] = _free_pick_for_member(package["moneyline"])
            counts = package.get("candidate_counts")
            if isinstance(counts, dict):
                package["candidate_counts"] = {
                    key: value
                    for key, value in counts.items()
                    if not str(key).startswith("watch_")
                }
            if package.get("recommendation_status") in {
                "watchlist_only", "founder_watchlist_only"
            }:
                package["recommendation_status"] = "no_recommendation"
            formal_total = sum(
                len(items or [])
                for items in (
                    package.get("moneylines"),
                    package.get("run_lines"),
                    package.get("totals"),
                    (package.get("parlays") or {}).get("two_leg"),
                    (package.get("parlays") or {}).get("three_leg"),
                )
            )
            package["message"] = (
                "正式玩法已鎖定。"
                if formal_total
                else "此日期沒有正式 Pro 推薦。"
            )

    pro_performance = None
    if member.get("role") == "admin":
        try:
            pro_performance = await performance_repository(request).records_performance(days=None)
        except PerformanceStorageError:
            # Recommendation history remains available even when the auxiliary
            # performance snapshot store is temporarily unavailable.
            pro_performance = None

    return {
        "items": items,
        "market_packages": market_packages,
        "pro_performance": pro_performance,
        "count": len(items),
        "stats": summarize_records(items),
        "message": "尚無正式推薦紀錄。" if not items else "正式推薦紀錄已載入。",
        "is_demo": False,
        "database": "connected",
        "settled_now": settled_now,
        "packages_settled_now": packages_settled_now,
        "member": {"role": member["role"], "has_pro_access": member["has_pro_access"]},
        "pro_history_locked": not member["has_pro_access"],
        "performance_access": member.get("role") == "admin",
    }
