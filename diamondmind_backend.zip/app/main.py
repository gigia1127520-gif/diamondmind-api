from __future__ import annotations

from contextlib import asynccontextmanager
from datetime import date, datetime
from secrets import compare_digest
from zoneinfo import ZoneInfo

from fastapi import FastAPI, Header, HTTPException, Query, Request
from fastapi.middleware.cors import CORSMiddleware

from .config import settings
from .auth import MemberAccessError, SupabaseMemberAuth
from .markets import build_daily_market_package
from .mlb import MLBService, MLBUpstreamError
from .odds import OddsService, OddsUpstreamError
from .records import (
    RecordsStorageError,
    SupabaseRecordsRepository,
    package_from_record,
    settlement_for,
    settle_prediction_package,
    summarize_records,
)


TAIPEI = ZoneInfo("Asia/Taipei")


@asynccontextmanager
async def lifespan(app: FastAPI):
    service = MLBService(settings)
    odds = OddsService(settings)
    records = SupabaseRecordsRepository(settings)
    member_auth = SupabaseMemberAuth(settings)
    app.state.mlb = service
    app.state.odds = odds
    app.state.records = records
    app.state.member_auth = member_auth
    yield
    await service.aclose()
    await odds.aclose()
    await records.aclose()
    await member_auth.aclose()


app = FastAPI(
    title="DiamondMind API",
    version="13.0.0",
    description="MLB schedule, statistics, Pythagorean expectation and transparent prediction API.",
    lifespan=lifespan,
)

allow_all = "*" in settings.cors_origins
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"] if allow_all else settings.cors_origins,
    allow_credentials=not allow_all,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["*"],
)


def service(request: Request) -> MLBService:
    return request.app.state.mlb


def records_repository(request: Request) -> SupabaseRecordsRepository:
    return request.app.state.records


def odds_service(request: Request) -> OddsService:
    return request.app.state.odds


def member_auth_service(request: Request) -> SupabaseMemberAuth:
    return request.app.state.member_auth


def requested_date(value: date | None) -> date:
    return value or datetime.now(TAIPEI).date()


def cron_secret_matches(provided: str | None, configured: str) -> bool:
    """Constant-time comparison for the server-to-server scheduler secret."""

    if not provided or not configured:
        return False
    return compare_digest(provided.encode("utf-8"), configured.encode("utf-8"))


def locked_prediction_from_record(
    prediction_date: date,
    record: dict,
) -> dict | None:
    snapshot = record.get("prediction_snapshot")
    if not isinstance(snapshot, dict) or not snapshot:
        return None
    return {
        "date": prediction_date.isoformat(),
        "published": True,
        "locked": True,
        "selection": snapshot,
        "message": "今日正式推薦已鎖定，後續更新不會更換推薦內容。",
        "meta": {
            "locked": True,
            "record_id": record.get("id"),
            "published_at": record.get("published_at"),
            "model_version": snapshot.get("model_version"),
        },
        "persistence": {
            "enabled": True,
            "stored": True,
            "created": False,
            "locked": True,
            "record_id": record.get("id"),
        },
    }


async def prediction_with_persistence(request: Request, prediction_date: date) -> dict:
    repository = records_repository(request)
    lookup_message = None
    if repository.enabled:
        try:
            existing = await repository.get_record_for_date(prediction_date.isoformat())
            if existing:
                locked = locked_prediction_from_record(prediction_date, existing)
                if locked:
                    return locked
        except RecordsStorageError:
            # The model can still provide a result during a temporary database
            # incident, but it is clearly marked as not durably locked.
            lookup_message = "紀錄資料庫暫時無法確認今日鎖單。"

    result = await service(request).top_prediction(prediction_date)
    persistence = {"enabled": repository.enabled, "stored": False}
    if lookup_message:
        persistence["message"] = lookup_message
    if result.get("published") and repository.enabled:
        try:
            stored, created = await repository.publish_prediction_once(
                result["date"], result["selection"]
            )
            persistence.update(
                {
                    "stored": True,
                    "created": created,
                    "locked": True,
                    "record_id": stored.get("id"),
                }
            )
            if not created:
                locked = locked_prediction_from_record(prediction_date, stored)
                if locked:
                    return locked
        except RecordsStorageError:
            # Prediction remains available even if the records database has a
            # temporary incident. It can be requested again to retry the upsert.
            persistence["message"] = "推薦已產生，但紀錄資料庫暫時無法寫入。"
    result["persistence"] = persistence
    return result


async def settle_pending_records(request: Request) -> int:
    repository = records_repository(request)
    if not repository.enabled:
        return 0

    pending = await repository.list_records(status="pending")
    settled_now = 0
    for record in pending:
        try:
            game = await service(request).game_result(int(record["game_pk"]))
        except (KeyError, MLBUpstreamError, TypeError, ValueError):
            continue
        result = settlement_for(record, game)
        if result and await repository.settle(int(record["game_pk"]), result):
            settled_now += 1
    return settled_now


def _package_game_ids(record: dict) -> set[int]:
    ids: set[int] = set()
    for key in ("moneyline_snapshot", "run_line_snapshot", "totals_snapshot"):
        selection = record.get(key)
        if isinstance(selection, dict):
            try:
                ids.add(int(selection.get("game_pk")))
            except (TypeError, ValueError):
                pass
    for key in ("two_leg_snapshot", "three_leg_snapshot"):
        parlay = record.get(key)
        if not isinstance(parlay, dict):
            continue
        for leg in parlay.get("legs") or []:
            try:
                ids.add(int(leg.get("game_pk")))
            except (TypeError, ValueError):
                pass
    return ids


async def settle_pending_prediction_packages(request: Request) -> int:
    repository = records_repository(request)
    if not repository.enabled:
        return 0
    pending = await repository.list_pending_prediction_packages()
    settled_now = 0
    for record in pending:
        games: dict[int, dict] = {}
        for game_pk in _package_game_ids(record):
            try:
                games[game_pk] = await service(request).game_result(game_pk)
            except (KeyError, MLBUpstreamError):
                continue
        result = settle_prediction_package(record, games)
        if result and await repository.settle_prediction_package(str(record["id"]), result):
            settled_now += 1
    return settled_now


async def locked_or_generated_market_package(
    request: Request,
    target_date: date,
    public_prediction: dict,
    odds_feed: dict,
) -> dict:
    repository = records_repository(request)
    if repository.enabled:
        try:
            existing = await repository.get_prediction_package_for_date(target_date.isoformat())
            if existing:
                return package_from_record(existing)
        except RecordsStorageError:
            existing = None

    analyses = await service(request).matchup_analyses(target_date, pitcher_limit=None)
    package = build_daily_market_package(
        target_date.isoformat(),
        analyses["items"],
        odds_feed.get("items") or [],
        public_prediction.get("selection") if public_prediction.get("published") else None,
        minimum_probability=settings.min_market_probability,
        minimum_edge=settings.min_market_edge,
        minimum_projection_quality=settings.min_projection_quality,
        minimum_parlay_probability=settings.min_parlay_leg_probability,
    )
    package["persistence"] = {"enabled": repository.enabled, "stored": False}
    if package["published"] and repository.enabled:
        try:
            stored, created = await repository.publish_prediction_package_once(
                target_date.isoformat(), package
            )
            locked = package_from_record(stored)
            locked["persistence"] = {
                "enabled": True,
                "stored": True,
                "created": created,
                "record_id": stored.get("id"),
            }
            return locked
        except RecordsStorageError:
            package["persistence"]["message"] = "會員玩法已產生，但資料表尚未完成設定或暫時無法寫入。"
    return package


@app.get("/")
async def root() -> dict:
    return {
        "name": settings.app_name,
        "version": "13.0.0",
        "status": "online",
        "docs": "/docs",
        "health": f"{settings.api_prefix}/health",
    }


@app.get(f"{settings.api_prefix}/health")
async def health() -> dict:
    return {
        "ok": True,
        "service": settings.app_name,
        "environment": settings.app_env,
        "records_database": "configured" if settings.records_enabled else "not_configured",
        "odds_feed": "configured" if settings.odds_enabled else "not_configured",
        "daily_scheduler": "configured" if settings.scheduler_enabled else "not_configured",
        "time_taiwan": datetime.now(TAIPEI).isoformat(),
    }


@app.get(f"{settings.api_prefix}/odds/status")
async def odds_status(request: Request) -> dict:
    # This endpoint never calls the paid upstream service and never exposes its key.
    return odds_service(request).status()


@app.get(f"{settings.api_prefix}/mlb/games")
async def mlb_games(
    request: Request,
    game_date: date | None = Query(default=None, alias="date", description="Taiwan date, YYYY-MM-DD"),
) -> dict:
    try:
        return await service(request).games_for_date(requested_date(game_date))
    except MLBUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@app.get(f"{settings.api_prefix}/mlb/games/{{game_pk}}")
async def mlb_game_detail(request: Request, game_pk: int) -> dict:
    try:
        return await service(request).game_detail(game_pk)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail="Game not found") from exc
    except MLBUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@app.get(f"{settings.api_prefix}/predictions/top")
async def top_prediction(
    request: Request,
    prediction_date: date | None = Query(default=None, alias="date", description="Taiwan date, YYYY-MM-DD"),
) -> dict:
    try:
        return await prediction_with_persistence(request, requested_date(prediction_date))
    except MLBUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@app.get(f"{settings.api_prefix}/predictions/daily")
async def daily_predictions_for_member(
    request: Request,
    prediction_date: date | None = Query(default=None, alias="date", description="Taiwan date, YYYY-MM-DD"),
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    token = None
    if authorization and authorization.lower().startswith("bearer "):
        token = authorization[7:].strip()
    try:
        member = await member_auth_service(request).member(token)
    except MemberAccessError as exc:
        raise HTTPException(status_code=401, detail=str(exc)) from exc

    target_date = requested_date(prediction_date)
    repository = records_repository(request)
    try:
        stored = await repository.get_prediction_package_for_date(target_date.isoformat())
        public_record = await repository.get_record_for_date(target_date.isoformat())
    except RecordsStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc

    moneyline = None
    if stored:
        package = package_from_record(stored)
        moneyline = package.get("moneyline")
    else:
        package = None
        if public_record and isinstance(public_record.get("prediction_snapshot"), dict):
            moneyline = public_record["prediction_snapshot"]

    response = {
        "date": target_date.isoformat(),
        "published": bool(package or moneyline),
        "locked": bool(package),
        "member": {"role": member["role"], "has_pro_access": member["has_pro_access"]},
        "moneyline": moneyline,
        "pro_access": "granted" if member["has_pro_access"] else "locked",
        "message": (
            "今日正式推薦已載入。"
            if package or moneyline
            else "今日尚未發布通過門檻的正式推薦。"
        ),
    }
    if member["has_pro_access"]:
        response.update(
            {
                "run_line": package.get("run_line") if package else None,
                "totals": package.get("totals") if package else None,
                "parlays": package.get("parlays") if package else {"two_leg": None, "three_leg": None},
                "candidate_counts": package.get("candidate_counts") if package else {},
                "thresholds": package.get("thresholds") if package else {},
                "settled": package.get("settled") if package else False,
                "results": package.get("results") if package else {},
            }
        )
    return response


@app.post(f"{settings.api_prefix}/jobs/daily")
async def daily_job(
    request: Request,
    job_date: date | None = Query(default=None, alias="date", description="Taiwan date, YYYY-MM-DD"),
    cron_secret: str | None = Header(default=None, alias="X-DiamondMind-Cron"),
) -> dict:
    if not settings.scheduler_enabled:
        raise HTTPException(status_code=503, detail="Daily scheduler secret is not configured")
    if not cron_secret_matches(cron_secret, settings.cron_secret):
        raise HTTPException(status_code=401, detail="Invalid scheduler credentials")

    target_date = requested_date(job_date)
    try:
        prediction = await prediction_with_persistence(request, target_date)
    except MLBUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc

    settlement = {"enabled": settings.records_enabled, "settled_now": 0}
    if settings.records_enabled:
        try:
            settlement["settled_now"] = await settle_pending_records(request)
            settlement["packages_settled_now"] = await settle_pending_prediction_packages(request)
        except RecordsStorageError:
            settlement["message"] = "紀錄資料庫暫時無法執行結算。"

    odds = odds_service(request).status()
    market_package = {
        "date": target_date.isoformat(),
        "published": False,
        "message": "真實盤口尚未提供，會員玩法不會使用猜測資料。",
    }
    if odds_service(request).enabled:
        try:
            feed = await odds_service(request).odds_for_date(target_date)
            odds.update(
                {
                    "available": True,
                    "count": feed["count"],
                    "cache": feed["meta"]["cache"],
                    "fresh_for_model": feed["meta"]["fresh_for_model"],
                    "quota": feed["meta"]["quota"],
                }
            )
            if feed["meta"]["fresh_for_model"]:
                market_package = await locked_or_generated_market_package(
                    request, target_date, prediction, feed
                )
            else:
                market_package["message"] = "目前只有過期備援盤口，不發布新的正式玩法。"
        except OddsUpstreamError:
            # A temporary odds incident must not prevent the independent
            # moneyline model or record settlement from completing.
            odds.update({"available": False, "message": "真實盤口來源暫時無法使用。"})
    else:
        odds["available"] = False

    return {
        "ok": True,
        "date": target_date.isoformat(),
        "time_taiwan": datetime.now(TAIPEI).isoformat(),
        "prediction": prediction,
        "market_package": market_package,
        "settlement": settlement,
        "odds": odds,
    }


@app.get(f"{settings.api_prefix}/records")
async def recommendation_records(request: Request) -> dict:
    repository = records_repository(request)
    if not repository.enabled:
        return {
            "items": [],
            "market_packages": [],
            "count": 0,
            "stats": summarize_records([]),
            "message": "推薦紀錄資料庫尚未設定。",
            "is_demo": False,
            "database": "not_configured",
        }

    try:
        settled_now = await settle_pending_records(request)
        packages_settled_now = await settle_pending_prediction_packages(request)
        items = await repository.list_records()
        settled_packages = await repository.list_settled_prediction_packages()
    except RecordsStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc

    # Defence in depth: never serialize a paid package through this public
    # endpoint unless every included product has already been settled.
    market_packages = [
        package_from_record(item)
        for item in settled_packages
        if item.get("settled") is True
    ]

    return {
        "items": items,
        "market_packages": market_packages,
        "count": len(items),
        "stats": summarize_records(items),
        "message": "尚無正式推薦紀錄。" if not items else "正式推薦紀錄已載入。",
        "is_demo": False,
        "database": "connected",
        "settled_now": settled_now,
        "packages_settled_now": packages_settled_now,
    }
