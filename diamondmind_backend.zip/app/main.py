from __future__ import annotations

from contextlib import asynccontextmanager
from datetime import date, datetime
from secrets import compare_digest
from zoneinfo import ZoneInfo

from fastapi import FastAPI, Header, HTTPException, Query, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from .config import settings
from .auth import MemberAccessError, SupabaseMemberAuth
from .markets import (
    build_daily_market_candidates,
    build_daily_market_package,
    build_selected_market_package,
)
from .mlb import MLBService, MLBUpstreamError
from .odds import OddsService, OddsUpstreamError
from .records import (
    RecordsStorageError,
    SupabaseRecordsRepository,
    package_from_record,
    settlement_for,
    settle_prediction_package,
    summarize_records,
)


TAIPEI = ZoneInfo("Asia/Taipei")


@asynccontextmanager
async def lifespan(app: FastAPI):
    service = MLBService(settings)
    odds = OddsService(settings)
    records = SupabaseRecordsRepository(settings)
    member_auth = SupabaseMemberAuth(settings)
    app.state.mlb = service
    app.state.odds = odds
    app.state.records = records
    app.state.member_auth = member_auth
    yield
    await service.aclose()
    await odds.aclose()
    await records.aclose()
    await member_auth.aclose()


app = FastAPI(
    title="DiamondMind API",
    version="16.2.0",
    description="MLB schedule plus a transparent five-module analysis engine for starters, lineups, bullpens, environment and Statcast metrics.",
    lifespan=lifespan,
)

allow_all = "*" in settings.cors_origins
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"] if allow_all else settings.cors_origins,
    allow_credentials=not allow_all,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["*"],
)


def service(request: Request) -> MLBService:
    return request.app.state.mlb


def records_repository(request: Request) -> SupabaseRecordsRepository:
    return request.app.state.records


def odds_service(request: Request) -> OddsService:
    return request.app.state.odds


def member_auth_service(request: Request) -> SupabaseMemberAuth:
    return request.app.state.member_auth


def bearer_token(authorization: str | None) -> str | None:
    if authorization and authorization.lower().startswith("bearer "):
        return authorization[7:].strip()
    return None


async def authenticated_member(request: Request, authorization: str | None) -> dict:
    try:
        return await member_auth_service(request).member(bearer_token(authorization))
    except MemberAccessError as exc:
        raise HTTPException(status_code=401, detail=str(exc)) from exc


async def admin_member(request: Request, authorization: str | None) -> dict:
    member = await authenticated_member(request, authorization)
    if member.get("role") != "admin":
        raise HTTPException(status_code=403, detail="Founder access is required")
    return member


def requested_date(value: date | None) -> date:
    return value or datetime.now(TAIPEI).date()


def cron_secret_matches(provided: str | None, configured: str) -> bool:
    """Constant-time comparison for the server-to-server scheduler secret."""

    if not provided or not configured:
        return False
    return compare_digest(provided.encode("utf-8"), configured.encode("utf-8"))


def locked_prediction_from_record(
    prediction_date: date,
    record: dict,
) -> dict | None:
    snapshot = record.get("prediction_snapshot")
    if not isinstance(snapshot, dict) or not snapshot:
        return None
    return {
        "date": prediction_date.isoformat(),
        "published": True,
        "locked": True,
        "selection": snapshot,
        "message": "今日正式推薦已鎖定，後續更新不會更換推薦內容。",
        "meta": {
            "locked": True,
            "record_id": record.get("id"),
            "published_at": record.get("published_at"),
            "model_version": snapshot.get("model_version"),
        },
        "persistence": {
            "enabled": True,
            "stored": True,
            "created": False,
            "locked": True,
            "record_id": record.get("id"),
        },
    }


async def prediction_with_persistence(
    request: Request,
    prediction_date: date,
    *,
    publish_if_eligible: bool = True,
) -> dict:
    repository = records_repository(request)
    lookup_message = None
    if repository.enabled:
        try:
            existing = await repository.get_record_for_date(prediction_date.isoformat())
            if existing:
                locked = locked_prediction_from_record(prediction_date, existing)
                if locked:
                    return locked
        except RecordsStorageError:
            # The model can still provide a result during a temporary database
            # incident, but it is clearly marked as not durably locked.
            lookup_message = "紀錄資料庫暫時無法確認今日鎖單。"

    result = await service(request).top_prediction(prediction_date)
    persistence = {"enabled": repository.enabled, "stored": False}
    if lookup_message:
        persistence["message"] = lookup_message
    if result.get("published") and not publish_if_eligible:
        # A normal page view must never become the action that locks the
        # official pick. Only the protected scheduler or the founder publish
        # endpoint is allowed to create the immutable public record.
        return {
            "date": prediction_date.isoformat(),
            "published": False,
            "locked": False,
            "selection": None,
            "message": "今日正式推薦尚未發布；將由固定排程自動發布，或由創辦人提前指定。",
            "meta": {
                **(result.get("meta") or {}),
                "publication_status": "pending",
            },
            "persistence": persistence,
        }
    if result.get("published") and repository.enabled:
        try:
            stored, created = await repository.publish_prediction_once(
                result["date"], result["selection"]
            )
            persistence.update(
                {
                    "stored": True,
                    "created": created,
                    "locked": True,
                    "record_id": stored.get("id"),
                }
            )
            if not created:
                locked = locked_prediction_from_record(prediction_date, stored)
                if locked:
                    return locked
        except RecordsStorageError:
            # Prediction remains available even if the records database has a
            # temporary incident. It can be requested again to retry the upsert.
            persistence["message"] = "推薦已產生，但紀錄資料庫暫時無法寫入。"
    result["persistence"] = persistence
    return result


async def settle_pending_records(request: Request) -> int:
    repository = records_repository(request)
    if not repository.enabled:
        return 0

    pending = await repository.list_records(status="pending")
    settled_now = 0
    for record in pending:
        try:
            game = await service(request).game_result(int(record["game_pk"]))
        except (KeyError, MLBUpstreamError, TypeError, ValueError):
            continue
        result = settlement_for(record, game)
        if result and await repository.settle(int(record["game_pk"]), result):
            settled_now += 1
    return settled_now


def _package_game_ids(record: dict) -> set[int]:
    ids: set[int] = set()
    package = package_from_record(record)
    for key in ("moneylines", "run_lines", "totals"):
        for selection in package.get(key) or []:
            try:
                ids.add(int(selection.get("game_pk")))
            except (TypeError, ValueError):
                pass
    for key in ("two_leg", "three_leg"):
        for parlay in (package.get("parlays") or {}).get(key) or []:
            for leg in parlay.get("legs") or []:
                try:
                    ids.add(int(leg.get("game_pk")))
                except (TypeError, ValueError):
                    pass
    return ids


async def settle_pending_prediction_packages(request: Request) -> int:
    repository = records_repository(request)
    if not repository.enabled:
        return 0
    pending = await repository.list_pending_prediction_packages()
    settled_now = 0
    for record in pending:
        games: dict[int, dict] = {}
        for game_pk in _package_game_ids(record):
            try:
                games[game_pk] = await service(request).game_result(game_pk)
            except (KeyError, MLBUpstreamError):
                continue
        result = settle_prediction_package(record, games)
        if result and await repository.settle_prediction_package(str(record["id"]), result):
            settled_now += 1
    return settled_now


async def locked_or_generated_market_package(
    request: Request,
    target_date: date,
    public_prediction: dict,
    odds_feed: dict,
) -> dict:
    repository = records_repository(request)
    if repository.enabled:
        try:
            existing = await repository.get_prediction_package_for_date(target_date.isoformat())
            if existing:
                return package_from_record(existing)
        except RecordsStorageError:
            existing = None

    analyses = await service(request).matchup_analyses(target_date, pitcher_limit=None)
    eligible_analyses = [
        item
        for item in analyses["items"]
        if (item.get("game") or {}).get("auto_recommendation_eligible") is True
        and (((item.get("analysis_groups") or {}).get("starter") or {}).get("both_starters_ready") is True)
    ]
    package = build_daily_market_package(
        target_date.isoformat(),
        eligible_analyses,
        odds_feed.get("items") or [],
        public_prediction.get("selection") if public_prediction.get("published") else None,
        minimum_probability=settings.min_market_probability,
        minimum_edge=settings.min_market_edge,
        minimum_projection_quality=settings.min_projection_quality,
        minimum_parlay_probability=settings.min_parlay_leg_probability,
    )
    package["persistence"] = {"enabled": repository.enabled, "stored": False}
    if package["published"] and repository.enabled:
        try:
            stored, created = await repository.publish_prediction_package_once(
                target_date.isoformat(), package
            )
            locked = package_from_record(stored)
            locked["persistence"] = {
                "enabled": True,
                "stored": True,
                "created": created,
                "record_id": stored.get("id"),
            }
            return locked
        except RecordsStorageError:
            package["persistence"]["message"] = "會員玩法已產生，但資料表尚未完成設定或暫時無法寫入。"
    return package


@app.get("/")
async def root() -> dict:
    return {
        "name": settings.app_name,
        "version": "16.2.0",
        "status": "online",
        "docs": "/docs",
        "health": f"{settings.api_prefix}/health",
    }


@app.get(f"{settings.api_prefix}/health")
async def health() -> dict:
    return {
        "ok": True,
        "service": settings.app_name,
        "version": "16.2.0",
        "environment": settings.app_env,
        "records_database": "configured" if settings.records_enabled else "not_configured",
        "odds_feed": "configured" if settings.odds_enabled else "not_configured",
        "daily_scheduler": "configured" if settings.scheduler_enabled else "not_configured",
        "time_taiwan": datetime.now(TAIPEI).isoformat(),
    }


@app.get(f"{settings.api_prefix}/odds/status")
async def odds_status(request: Request) -> dict:
    # This endpoint never calls the paid upstream service and never exposes its key.
    return odds_service(request).status()


@app.get(f"{settings.api_prefix}/mlb/games")
async def mlb_games(
    request: Request,
    game_date: date | None = Query(default=None, alias="date", description="Taiwan date, YYYY-MM-DD"),
) -> dict:
    try:
        return await service(request).games_for_date(requested_date(game_date))
    except MLBUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@app.get(f"{settings.api_prefix}/mlb/games/{{game_pk}}")
async def mlb_game_detail(request: Request, game_pk: int) -> dict:
    try:
        return await service(request).game_detail(game_pk)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail="Game not found") from exc
    except MLBUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@app.get(f"{settings.api_prefix}/predictions/top")
async def top_prediction(
    request: Request,
    prediction_date: date | None = Query(default=None, alias="date", description="Taiwan date, YYYY-MM-DD"),
) -> dict:
    try:
        return await prediction_with_persistence(
            request,
            requested_date(prediction_date),
            publish_if_eligible=False,
        )
    except MLBUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@app.get(f"{settings.api_prefix}/predictions/daily")
async def daily_predictions_for_member(
    request: Request,
    prediction_date: date | None = Query(default=None, alias="date", description="Taiwan date, YYYY-MM-DD"),
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    member = await authenticated_member(request, authorization)

    target_date = requested_date(prediction_date)
    repository = records_repository(request)
    try:
        stored = await repository.get_prediction_package_for_date(target_date.isoformat())
        public_record = await repository.get_record_for_date(target_date.isoformat())
    except RecordsStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc

    moneyline = None
    if stored:
        package = package_from_record(stored)
        moneyline = package.get("moneyline")
        if moneyline is None and public_record and isinstance(public_record.get("prediction_snapshot"), dict):
            moneyline = public_record["prediction_snapshot"]
    else:
        package = None
        if public_record and isinstance(public_record.get("prediction_snapshot"), dict):
            moneyline = public_record["prediction_snapshot"]

    response = {
        "date": target_date.isoformat(),
        "published": bool(package or moneyline),
        "locked": bool(package),
        "member": {"role": member["role"], "has_pro_access": member["has_pro_access"]},
        "moneyline": moneyline,
        "pro_access": "granted" if member["has_pro_access"] else "locked",
        "message": (
            "今日正式推薦已載入。"
            if package or moneyline
            else "今日尚未發布通過門檻的正式推薦。"
        ),
    }
    if member["has_pro_access"]:
        response.update(
            {
                "moneylines": package.get("moneylines") if package else [],
                "run_lines": package.get("run_lines") if package else [],
                "totals": package.get("totals") if package else [],
                "parlays": package.get("parlays") if package else {"two_leg": [], "three_leg": []},
                # V14-compatible aliases during the transition.
                "run_line": (package.get("run_lines") or [None])[0] if package else None,
                "total": (package.get("totals") or [None])[0] if package else None,
                "candidate_counts": package.get("candidate_counts") if package else {},
                "thresholds": package.get("thresholds") if package else {},
                "limits": package.get("limits") if package else {},
                "publication": package.get("publication") if package else {},
                "settled": package.get("settled") if package else False,
                "results": package.get("results") if package else {},
            }
        )
    return response


class FounderPredictionPublish(BaseModel):
    date: date
    game_pk: int
    confirm_warning: bool = False


def founder_candidate(analysis: dict) -> dict:
    """Return the founder-facing publication policy for one matchup."""

    game = analysis.get("game") or {}
    context = str(game.get("season_context") or "unsupported")
    confidence = float(analysis.get("confidence") or 0)
    data_quality = float(analysis.get("data_quality") or 0)
    blockers: list[str] = []
    warnings: list[str] = []

    if context not in {"regular_season", "postseason"}:
        blockers.append(
            f"{game.get('event_label') or '特殊賽事'}專用模型尚未啟用，不能套用一般球隊模型正式發布。"
        )
    if data_quality < 0.45:
        blockers.append("賽事資料完整度不足 45%，目前不可正式發布。")
    starter_group = ((analysis.get("analysis_groups") or {}).get("starter") or {})
    if starter_group.get("both_starters_ready") is not True:
        blockers.append("兩隊先發投手資料尚未達正式發布標準；目前只能預覽，不能發布免費或 Pro 推薦。")
    if confidence < settings.min_confidence:
        warnings.append(
            f"模型信心 {confidence:.1f}% 低於自動發布門檻 {settings.min_confidence:.1f}%。"
        )
    if context == "postseason":
        warnings.append("這是季後賽特殊賽事；請再確認輪值、休息天數與系列賽狀況。")

    return {
        "game_pk": analysis.get("game_pk"),
        "matchup": analysis.get("matchup"),
        "time_taiwan": analysis.get("time_taiwan"),
        "venue": game.get("venue"),
        "event": {
            "game_type": game.get("game_type"),
            "context": context,
            "label": game.get("event_label") or "例行賽",
            "special": bool(game.get("special_event")),
        },
        "pick": analysis.get("pick"),
        "confidence": confidence,
        "data_quality": data_quality,
        "warnings": warnings,
        "blockers": blockers,
        "can_publish": not blockers,
        "requires_confirmation": bool(warnings),
    }


@app.get(f"{settings.api_prefix}/admin/predictions/candidates")
async def founder_prediction_candidates(
    request: Request,
    prediction_date: date | None = Query(default=None, alias="date"),
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    await admin_member(request, authorization)
    target_date = requested_date(prediction_date)
    repository = records_repository(request)
    if not repository.enabled:
        raise HTTPException(status_code=503, detail="Recommendation database is not configured")
    try:
        existing = await repository.get_record_for_date(target_date.isoformat())
    except RecordsStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    if existing:
        return {
            "date": target_date.isoformat(),
            "locked": True,
            "selection": existing.get("prediction_snapshot"),
            "items": [],
            "message": "今日正式推薦已鎖定，不能再更換場次。",
        }

    try:
        analyses = await service(request).matchup_analyses(target_date, pitcher_limit=None)
    except MLBUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    items = [founder_candidate(item) for item in analyses.get("items") or []]
    items.sort(key=lambda item: item["confidence"], reverse=True)
    return {
        "date": target_date.isoformat(),
        "locked": False,
        "items": items,
        "count": len(items),
        "message": analyses.get("message") or "候選場次已載入。",
    }


@app.post(f"{settings.api_prefix}/admin/predictions/publish")
async def founder_publish_prediction(
    request: Request,
    command: FounderPredictionPublish,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    await admin_member(request, authorization)
    repository = records_repository(request)
    if not repository.enabled:
        raise HTTPException(status_code=503, detail="Recommendation database is not configured")
    try:
        existing = await repository.get_record_for_date(command.date.isoformat())
    except RecordsStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    if existing:
        raise HTTPException(status_code=409, detail="今日正式推薦已鎖定，不能再更換場次。")

    try:
        analyses = await service(request).matchup_analyses(command.date, pitcher_limit=None)
    except MLBUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    selection = next(
        (item for item in analyses.get("items") or [] if item.get("game_pk") == command.game_pk),
        None,
    )
    if selection is None:
        raise HTTPException(status_code=404, detail="找不到這場尚未開賽的候選賽事。")

    policy = founder_candidate(selection)
    if not policy["can_publish"]:
        raise HTTPException(
            status_code=422,
            detail={"message": "這場比賽目前不可正式發布。", "blockers": policy["blockers"]},
        )
    if policy["requires_confirmation"] and not command.confirm_warning:
        raise HTTPException(
            status_code=409,
            detail={"message": "這場比賽需要創辦人再次確認。", "warnings": policy["warnings"]},
        )

    selection = {
        **selection,
        "publication": {
            "mode": "founder_selected",
            "special_event": policy["event"]["special"],
            "event_label": policy["event"]["label"],
            "warnings_confirmed": bool(policy["warnings"]),
        },
    }
    try:
        stored, created = await repository.publish_prediction_once(
            command.date.isoformat(), selection
        )
    except RecordsStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    if not created:
        raise HTTPException(status_code=409, detail="另一筆正式推薦已先完成鎖定。")
    return {
        "ok": True,
        "date": command.date.isoformat(),
        "locked": True,
        "created": True,
        "selection": stored.get("prediction_snapshot") or selection,
        "message": "創辦人指定場次已正式發布並鎖定。",
    }


class FounderMarketPublish(BaseModel):
    date: date
    moneylines: list[str] = Field(default_factory=list)
    run_lines: list[str] = Field(default_factory=list)
    totals: list[str] = Field(default_factory=list)
    two_leg: list[str] = Field(default_factory=list)
    three_leg: list[str] = Field(default_factory=list)


async def founder_market_candidate_bundle(request: Request, target_date: date) -> dict:
    repository = records_repository(request)
    try:
        public_record = await repository.get_record_for_date(target_date.isoformat())
    except RecordsStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    public_selection = None
    if public_record and isinstance(public_record.get("prediction_snapshot"), dict):
        public_selection = public_record["prediction_snapshot"]

    if not odds_service(request).enabled:
        raise HTTPException(status_code=503, detail="真實盤口來源尚未設定，不能建立正式會員玩法。")
    try:
        feed = await odds_service(request).odds_for_date(target_date)
    except OddsUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    if not (feed.get("meta") or {}).get("fresh_for_model"):
        raise HTTPException(status_code=409, detail="目前只有過期備援盤口，不能發布新的正式會員玩法。")

    try:
        analyses = await service(request).matchup_analyses(target_date, pitcher_limit=None)
    except MLBUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    eligible = [
        item
        for item in analyses.get("items") or []
        if (item.get("game") or {}).get("auto_recommendation_eligible") is True
        and (((item.get("analysis_groups") or {}).get("starter") or {}).get("both_starters_ready") is True)
    ]
    return build_daily_market_candidates(
        target_date.isoformat(),
        eligible,
        feed.get("items") or [],
        public_selection,
        minimum_probability=settings.min_market_probability,
        minimum_edge=settings.min_market_edge,
        minimum_projection_quality=settings.min_projection_quality,
        minimum_parlay_probability=settings.min_parlay_leg_probability,
    )


@app.get(f"{settings.api_prefix}/admin/markets/candidates")
async def founder_market_candidates(
    request: Request,
    prediction_date: date | None = Query(default=None, alias="date"),
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    await admin_member(request, authorization)
    target_date = requested_date(prediction_date)
    repository = records_repository(request)
    if not repository.enabled:
        raise HTTPException(status_code=503, detail="Recommendation database is not configured")
    try:
        existing = await repository.get_prediction_package_for_date(target_date.isoformat())
    except RecordsStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    if existing:
        return {
            "date": target_date.isoformat(),
            "locked": True,
            "package": package_from_record(existing),
            "message": "今日會員玩法已鎖定，不能再更換。",
        }
    bundle = await founder_market_candidate_bundle(request, target_date)
    return {
        **bundle,
        "locked": False,
        "message": "會員玩法候選已載入；可採用 AI 建議，或自行勾選通過門檻的內容。",
    }


@app.post(f"{settings.api_prefix}/admin/markets/publish")
async def founder_publish_markets(
    request: Request,
    command: FounderMarketPublish,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    await admin_member(request, authorization)
    repository = records_repository(request)
    if not repository.enabled:
        raise HTTPException(status_code=503, detail="Recommendation database is not configured")
    try:
        existing = await repository.get_prediction_package_for_date(command.date.isoformat())
    except RecordsStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    if existing:
        raise HTTPException(status_code=409, detail="今日會員玩法已鎖定，不能再更換。")

    bundle = await founder_market_candidate_bundle(request, command.date)
    selected = {
        "moneylines": command.moneylines,
        "run_lines": command.run_lines,
        "totals": command.totals,
        "two_leg": command.two_leg,
        "three_leg": command.three_leg,
    }
    try:
        package = build_selected_market_package(
            bundle,
            selected,
            publication_mode="founder_selected",
        )
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    if not package.get("published"):
        raise HTTPException(status_code=422, detail="至少選擇一個通過門檻的會員玩法後才能發布。")
    try:
        stored, created = await repository.publish_prediction_package_once(
            command.date.isoformat(), package
        )
    except RecordsStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    if not created:
        raise HTTPException(status_code=409, detail="另一筆會員玩法已先完成鎖定。")
    locked = package_from_record(stored)
    return {
        "ok": True,
        "date": command.date.isoformat(),
        "locked": True,
        "package": locked,
        "message": "創辦人選擇的會員玩法已正式發布並永久鎖定。",
    }


@app.post(f"{settings.api_prefix}/jobs/daily")
async def daily_job(
    request: Request,
    job_date: date | None = Query(default=None, alias="date", description="Taiwan date, YYYY-MM-DD"),
    cron_secret: str | None = Header(default=None, alias="X-DiamondMind-Cron"),
) -> dict:
    if not settings.scheduler_enabled:
        raise HTTPException(status_code=503, detail="Daily scheduler secret is not configured")
    if not cron_secret_matches(cron_secret, settings.cron_secret):
        raise HTTPException(status_code=401, detail="Invalid scheduler credentials")

    target_date = requested_date(job_date)
    try:
        prediction = await prediction_with_persistence(request, target_date)
    except MLBUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc

    settlement = {"enabled": settings.records_enabled, "settled_now": 0}
    if settings.records_enabled:
        try:
            settlement["settled_now"] = await settle_pending_records(request)
            settlement["packages_settled_now"] = await settle_pending_prediction_packages(request)
        except RecordsStorageError:
            settlement["message"] = "紀錄資料庫暫時無法執行結算。"

    odds = odds_service(request).status()
    market_package = {
        "date": target_date.isoformat(),
        "published": False,
        "message": "真實盤口尚未提供，會員玩法不會使用猜測資料。",
    }
    if odds_service(request).enabled:
        try:
            feed = await odds_service(request).odds_for_date(target_date)
            odds.update(
                {
                    "available": True,
                    "count": feed["count"],
                    "cache": feed["meta"]["cache"],
                    "fresh_for_model": feed["meta"]["fresh_for_model"],
                    "quota": feed["meta"]["quota"],
                }
            )
            if feed["meta"]["fresh_for_model"]:
                market_package = await locked_or_generated_market_package(
                    request, target_date, prediction, feed
                )
            else:
                market_package["message"] = "目前只有過期備援盤口，不發布新的正式玩法。"
        except OddsUpstreamError:
            # A temporary odds incident must not prevent the independent
            # moneyline model or record settlement from completing.
            odds.update({"available": False, "message": "真實盤口來源暫時無法使用。"})
    else:
        odds["available"] = False

    return {
        "ok": True,
        "date": target_date.isoformat(),
        "time_taiwan": datetime.now(TAIPEI).isoformat(),
        "prediction": prediction,
        "market_package": market_package,
        "settlement": settlement,
        "odds": odds,
    }


@app.get(f"{settings.api_prefix}/records")
async def recommendation_records(request: Request) -> dict:
    repository = records_repository(request)
    if not repository.enabled:
        return {
            "items": [],
            "market_packages": [],
            "count": 0,
            "stats": summarize_records([]),
            "message": "推薦紀錄資料庫尚未設定。",
            "is_demo": False,
            "database": "not_configured",
        }

    try:
        settled_now = await settle_pending_records(request)
        packages_settled_now = await settle_pending_prediction_packages(request)
        items = await repository.list_records()
        settled_packages = await repository.list_settled_prediction_packages()
    except RecordsStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc

    # Defence in depth: never serialize a paid package through this public
    # endpoint unless every included product has already been settled.
    market_packages = [
        package_from_record(item)
        for item in settled_packages
        if item.get("settled") is True
    ]

    return {
        "items": items,
        "market_packages": market_packages,
        "count": len(items),
        "stats": summarize_records(items),
        "message": "尚無正式推薦紀錄。" if not items else "正式推薦紀錄已載入。",
        "is_demo": False,
        "database": "connected",
        "settled_now": settled_now,
        "packages_settled_now": packages_settled_now,
    }
