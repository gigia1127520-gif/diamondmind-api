from __future__ import annotations

from contextlib import asynccontextmanager
from datetime import date, datetime
from secrets import compare_digest
from zoneinfo import ZoneInfo

from fastapi import FastAPI, Header, HTTPException, Query, Request
from fastapi.middleware.cors import CORSMiddleware

from .config import settings
from .mlb import MLBService, MLBUpstreamError
from .odds import OddsService, OddsUpstreamError
from .records import (
    RecordsStorageError,
    SupabaseRecordsRepository,
    settlement_for,
    summarize_records,
)


TAIPEI = ZoneInfo("Asia/Taipei")


@asynccontextmanager
async def lifespan(app: FastAPI):
    service = MLBService(settings)
    odds = OddsService(settings)
    records = SupabaseRecordsRepository(settings)
    app.state.mlb = service
    app.state.odds = odds
    app.state.records = records
    yield
    await service.aclose()
    await odds.aclose()
    await records.aclose()


app = FastAPI(
    title="DiamondMind API",
    version="10.2.0",
    description="MLB schedule, statistics, Pythagorean expectation and transparent prediction API.",
    lifespan=lifespan,
)

allow_all = "*" in settings.cors_origins
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"] if allow_all else settings.cors_origins,
    allow_credentials=not allow_all,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["*"],
)


def service(request: Request) -> MLBService:
    return request.app.state.mlb


def records_repository(request: Request) -> SupabaseRecordsRepository:
    return request.app.state.records


def odds_service(request: Request) -> OddsService:
    return request.app.state.odds


def requested_date(value: date | None) -> date:
    return value or datetime.now(TAIPEI).date()


def cron_secret_matches(provided: str | None, configured: str) -> bool:
    """Constant-time comparison for the server-to-server scheduler secret."""

    if not provided or not configured:
        return False
    return compare_digest(provided.encode("utf-8"), configured.encode("utf-8"))


def locked_prediction_from_record(
    prediction_date: date,
    record: dict,
) -> dict | None:
    snapshot = record.get("prediction_snapshot")
    if not isinstance(snapshot, dict) or not snapshot:
        return None
    return {
        "date": prediction_date.isoformat(),
        "published": True,
        "locked": True,
        "selection": snapshot,
        "message": "今日正式推薦已鎖定，後續更新不會更換推薦內容。",
        "meta": {
            "locked": True,
            "record_id": record.get("id"),
            "published_at": record.get("published_at"),
            "model_version": snapshot.get("model_version"),
        },
        "persistence": {
            "enabled": True,
            "stored": True,
            "created": False,
            "locked": True,
            "record_id": record.get("id"),
        },
    }


async def prediction_with_persistence(request: Request, prediction_date: date) -> dict:
    repository = records_repository(request)
    lookup_message = None
    if repository.enabled:
        try:
            existing = await repository.get_record_for_date(prediction_date.isoformat())
            if existing:
                locked = locked_prediction_from_record(prediction_date, existing)
                if locked:
                    return locked
        except RecordsStorageError:
            # The model can still provide a result during a temporary database
            # incident, but it is clearly marked as not durably locked.
            lookup_message = "紀錄資料庫暫時無法確認今日鎖單。"

    result = await service(request).top_prediction(prediction_date)
    persistence = {"enabled": repository.enabled, "stored": False}
    if lookup_message:
        persistence["message"] = lookup_message
    if result.get("published") and repository.enabled:
        try:
            stored, created = await repository.publish_prediction_once(
                result["date"], result["selection"]
            )
            persistence.update(
                {
                    "stored": True,
                    "created": created,
                    "locked": True,
                    "record_id": stored.get("id"),
                }
            )
            if not created:
                locked = locked_prediction_from_record(prediction_date, stored)
                if locked:
                    return locked
        except RecordsStorageError:
            # Prediction remains available even if the records database has a
            # temporary incident. It can be requested again to retry the upsert.
            persistence["message"] = "推薦已產生，但紀錄資料庫暫時無法寫入。"
    result["persistence"] = persistence
    return result


async def settle_pending_records(request: Request) -> int:
    repository = records_repository(request)
    if not repository.enabled:
        return 0

    pending = await repository.list_records(status="pending")
    settled_now = 0
    for record in pending:
        try:
            game = await service(request).game_result(int(record["game_pk"]))
        except (KeyError, MLBUpstreamError, TypeError, ValueError):
            continue
        result = settlement_for(record, game)
        if result and await repository.settle(int(record["game_pk"]), result):
            settled_now += 1
    return settled_now


@app.get("/")
async def root() -> dict:
    return {
        "name": settings.app_name,
        "version": "10.2.0",
        "status": "online",
        "docs": "/docs",
        "health": f"{settings.api_prefix}/health",
    }


@app.get(f"{settings.api_prefix}/health")
async def health() -> dict:
    return {
        "ok": True,
        "service": settings.app_name,
        "environment": settings.app_env,
        "records_database": "configured" if settings.records_enabled else "not_configured",
        "odds_feed": "configured" if settings.odds_enabled else "not_configured",
        "daily_scheduler": "configured" if settings.scheduler_enabled else "not_configured",
        "time_taiwan": datetime.now(TAIPEI).isoformat(),
    }


@app.get(f"{settings.api_prefix}/odds/status")
async def odds_status(request: Request) -> dict:
    # This endpoint never calls the paid upstream service and never exposes its key.
    return odds_service(request).status()


@app.get(f"{settings.api_prefix}/mlb/games")
async def mlb_games(
    request: Request,
    game_date: date | None = Query(default=None, alias="date", description="Taiwan date, YYYY-MM-DD"),
) -> dict:
    try:
        return await service(request).games_for_date(requested_date(game_date))
    except MLBUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@app.get(f"{settings.api_prefix}/mlb/games/{{game_pk}}")
async def mlb_game_detail(request: Request, game_pk: int) -> dict:
    try:
        return await service(request).game_detail(game_pk)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail="Game not found") from exc
    except MLBUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@app.get(f"{settings.api_prefix}/predictions/top")
async def top_prediction(
    request: Request,
    prediction_date: date | None = Query(default=None, alias="date", description="Taiwan date, YYYY-MM-DD"),
) -> dict:
    try:
        return await prediction_with_persistence(request, requested_date(prediction_date))
    except MLBUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@app.post(f"{settings.api_prefix}/jobs/daily")
async def daily_job(
    request: Request,
    job_date: date | None = Query(default=None, alias="date", description="Taiwan date, YYYY-MM-DD"),
    cron_secret: str | None = Header(default=None, alias="X-DiamondMind-Cron"),
) -> dict:
    if not settings.scheduler_enabled:
        raise HTTPException(status_code=503, detail="Daily scheduler secret is not configured")
    if not cron_secret_matches(cron_secret, settings.cron_secret):
        raise HTTPException(status_code=401, detail="Invalid scheduler credentials")

    target_date = requested_date(job_date)
    try:
        prediction = await prediction_with_persistence(request, target_date)
    except MLBUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc

    settlement = {"enabled": settings.records_enabled, "settled_now": 0}
    if settings.records_enabled:
        try:
            settlement["settled_now"] = await settle_pending_records(request)
        except RecordsStorageError:
            settlement["message"] = "紀錄資料庫暫時無法執行結算。"

    odds = odds_service(request).status()
    if odds_service(request).enabled:
        try:
            feed = await odds_service(request).odds_for_date(target_date)
            odds.update(
                {
                    "available": True,
                    "count": feed["count"],
                    "cache": feed["meta"]["cache"],
                    "fresh_for_model": feed["meta"]["fresh_for_model"],
                    "quota": feed["meta"]["quota"],
                }
            )
        except OddsUpstreamError:
            # A temporary odds incident must not prevent the independent
            # moneyline model or record settlement from completing.
            odds.update({"available": False, "message": "真實盤口來源暫時無法使用。"})
    else:
        odds["available"] = False

    return {
        "ok": True,
        "date": target_date.isoformat(),
        "time_taiwan": datetime.now(TAIPEI).isoformat(),
        "prediction": prediction,
        "settlement": settlement,
        "odds": odds,
    }


@app.get(f"{settings.api_prefix}/records")
async def recommendation_records(request: Request) -> dict:
    repository = records_repository(request)
    if not repository.enabled:
        return {
            "items": [],
            "count": 0,
            "stats": summarize_records([]),
            "message": "推薦紀錄資料庫尚未設定。",
            "is_demo": False,
            "database": "not_configured",
        }

    try:
        settled_now = await settle_pending_records(request)
        items = await repository.list_records()
    except RecordsStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc

    return {
        "items": items,
        "count": len(items),
        "stats": summarize_records(items),
        "message": "尚無正式推薦紀錄。" if not items else "正式推薦紀錄已載入。",
        "is_demo": False,
        "database": "connected",
        "settled_now": settled_now,
    }
