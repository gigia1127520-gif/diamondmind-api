from __future__ import annotations

import asyncio
import csv
from copy import deepcopy
import io
import math
import re
from contextlib import asynccontextmanager, suppress
from datetime import date, datetime, timedelta, timezone
from secrets import compare_digest
from time import monotonic
from zoneinfo import ZoneInfo

from fastapi import FastAPI, Header, HTTPException, Query, Request
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, PlainTextResponse, Response
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from .config import settings
from .billing import BillingError, BillingRepository, ECPayBillingService, parse_form_body
from .admin import AdminMemberCommand, AdminMembershipError, AdminMembershipService
from .announcements import AnnouncementError, AnnouncementRepository, AnnouncementService
from .auth import MemberAccessError, SupabaseMemberAuth
from .passwords import PasswordSecurityError, PasswordSecurityService
from .trials import NewMemberTrialError, NewMemberTrialService
from .line_messaging import LineMessagingError, LineMessagingService
from .markets import (
    build_daily_market_candidates,
    build_daily_market_package,
    build_selected_market_package,
    is_asian_baseball_pro_selection,
    is_model_only_asian_moneyline,
    is_npb_pro_selection,
    is_real_odds_selection,
    match_odds_event,
    merge_market_candidates,
    model_only_moneyline_candidate,
    moneyline_candidate,
    run_line_candidate,
    totals_candidate,
)
from .mlb import MLBService, MLBUpstreamError
from .npb import NPBService, NPBUpstreamError
from .asian_baseball import (
    AsianBaseballService,
    AsianBaseballSettlementLookupError,
    AsianBaseballUpstreamError,
)
from .odds import OddsService, OddsUpstreamError
from .odds_api_io import OddsApiIoService, OddsApiIoUpstreamError
from .operations import build_operations_report, probe_league_sources
from .runtime import RequestMetrics, WorkerRegistry
from .sports import (
    ACTIVE_LEAGUES,
    LEAGUES,
    SCHEMA_VERSION as SPORTS_SCHEMA_VERSION,
    league_catalog as registered_league_catalog,
    market_catalog as registered_market_catalog,
    normalize_event,
    normalize_league_code,
    sport_for_league,
    sports_catalog as registered_sports_catalog,
)
from .validation import game_timing, iso_utc, parse_game_datetime
from .data_quality import audit_games, audit_snapshots
from .records import (
    RecordsStorageError,
    SupabaseRecordsRepository,
    package_from_record,
    preview_prediction_package,
    preview_public_record,
    result_status_matches_disposition,
    settlement_game_disposition,
    settlement_for,
    reopen_rescheduled_package_results,
    settle_market_selection,
    settle_prediction_package,
    summarize_records,
)
from .calibration import CalibrationRegistry, apply_registry_to_bundle, apply_registry_to_selection
from .performance import (
    DEFAULT_MODEL_WEIGHTS,
    PerformanceRepository,
    PerformanceStorageError,
    calibration_suggestions,
    normalize_weights,
)
from .social import (
    DiamondMindSocialService,
    SocialAssetSpec,
    SocialReelSpec,
    SocialPublishingError,
    TERMINAL_STATUSES as SOCIAL_TERMINAL_STATUSES,
    compact_pick_label,
    decimal_price,
    display_team,
    event_key as social_event_key,
    normalize_market_label,
    status_label,
    utc_now as social_utc_now,
)


TAIPEI = ZoneInfo("Asia/Taipei")
APP_VERSION = "22.4.5"
ASIAN_MODEL_ONLY_FALLBACK_LEAGUES = {"NPB", "KBO"}

PROCESS_ROLE_WORKERS: dict[str, set[str]] = {
    "all": {"publish", "settlement", "model", "retry"},
    "api": set(),
    "publish": {"publish", "retry"},
    "settlement": {"settlement", "retry"},
    "model": {"model", "retry"},
    "monitor": {"retry"},
}


def _normalized_process_role() -> str:
    role = str(settings.process_role or "all").lower()
    return role if role in PROCESS_ROLE_WORKERS else "all"


def _role_runs(worker: str) -> bool:
    return worker in PROCESS_ROLE_WORKERS[_normalized_process_role()]


@asynccontextmanager
async def lifespan(app: FastAPI):
    service = MLBService(settings)
    npb = NPBService(settings)
    kbo = AsianBaseballService(settings, "KBO")
    cpbl = AsianBaseballService(settings, "CPBL")
    odds = OddsService(settings)
    odds_api_io = OddsApiIoService(settings)
    records = SupabaseRecordsRepository(settings)
    member_auth = SupabaseMemberAuth(settings)
    billing_repository = BillingRepository(settings)
    billing = ECPayBillingService(settings, billing_repository)
    membership_admin = AdminMembershipService(billing_repository)
    password_security = PasswordSecurityService(billing_repository)
    member_trial = NewMemberTrialService(settings, billing_repository)
    announcement_repository = AnnouncementRepository(settings)
    announcements = AnnouncementService(announcement_repository)
    performance = PerformanceRepository(settings)
    social = DiamondMindSocialService(settings)
    line = LineMessagingService(settings)
    try:
        service.model_weights = await performance.active_weights() if performance.enabled else dict(DEFAULT_MODEL_WEIGHTS)
    except PerformanceStorageError:
        service.model_weights = dict(DEFAULT_MODEL_WEIGHTS)
    try:
        calibration_registry = await performance.calibration_registry() if performance.enabled and settings.model_calibration_enabled else CalibrationRegistry.empty()
        calibration_schema = "ready" if calibration_registry.profiles else "ready_no_active_profiles"
    except PerformanceStorageError:
        calibration_registry = CalibrationRegistry.empty()
        calibration_schema = "migration_required"
    app.state.mlb = service
    app.state.npb = npb
    app.state.kbo = kbo
    app.state.cpbl = cpbl
    app.state.odds = odds
    app.state.odds_api_io = odds_api_io
    app.state.odds_fetch_state = {}
    app.state.odds_feed_snapshots = {}
    app.state.odds_snapshot_status = {
        "enabled": bool(settings.odds_snapshot_enabled and records.enabled),
        "schema": "unchecked",
        "last_error": None,
    }
    app.state.records = records
    app.state.member_auth = member_auth
    app.state.billing_repository = billing_repository
    app.state.billing = billing
    app.state.membership_admin = membership_admin
    app.state.password_security = password_security
    app.state.member_trial = member_trial
    app.state.announcements = announcements
    app.state.performance = performance
    app.state.process_role = _normalized_process_role()
    app.state.request_metrics = RequestMetrics()
    app.state.calibration_registry = calibration_registry
    app.state.calibration_lock = asyncio.Lock()
    app.state.calibration_status = {
        "enabled": bool(settings.model_calibration_enabled),
        "schema": calibration_schema,
        "running": False,
        "last_run": None,
        "last_error": None,
        "profiles_loaded": len(calibration_registry.profiles),
        "registry_loaded_at": calibration_registry.loaded_at,
        "interval_seconds": settings.model_calibration_interval_seconds,
        "mode": "test_candidates_only",
        "auto_promote": False,
        "founder_confirmation_required": True,
    }
    app.state.social = social
    app.state.line = line
    app.state.model_backfill_lock = asyncio.Lock()
    app.state.model_backfill_task = None
    app.state.model_backfill_status = {
        "running": False,
        "last_started_at": None,
        "last_completed_at": None,
        "last_error": None,
        "public": 0,
        "packages": 0,
        "cooldown_seconds": 21600,
        "last_completed_monotonic": 0.0,
    }
    app.state.started_at = datetime.now(TAIPEI).isoformat()
    app.state.worker_registry = WorkerRegistry(restart_delay_seconds=5.0)
    app.state.pregame_status = {
        "running": _role_runs("publish"),
        "status": "starting" if _role_runs("publish") else "assigned_to_other_process",
        "last_run": None,
        "last_error": None,
    }
    app.state.settlement_status = {
        "enabled": bool(settings.records_enabled and (settings.settlement_internal_scheduler_enabled or settings.scheduler_enabled)),
        "state": "idle" if settings.records_enabled else "disabled",
        "running": False,
        "queued": False,
        "last_run": None,
        "last_error": None,
        "free_settled_now": 0,
        "packages_settled_now": 0,
        "mode": "background_only",
        "scheduler": "internal_fallback" if settings.settlement_internal_scheduler_enabled else "external_only",
        "scheduler_interval_seconds": settings.settlement_internal_interval_seconds,
    }
    app.state.operations_monitor_status = {
        "ok": True,
        "status": "starting",
        "checked_at": None,
        "checks": [],
        "critical_issues": [],
        "warnings": [],
    }
    app.state.operations_monitor_failures = {}
    # External cron requests have a hard 30-second response limit.  The
    # settlement endpoint therefore acknowledges immediately and performs the
    # heavier settlement/social/monitoring workflow in this in-process task.
    app.state.external_settlement_task = None
    app.state.external_settlement_lock = asyncio.Lock()
    app.state.external_publish_task = None
    app.state.external_publish_lock = asyncio.Lock()
    app.state.last_publish_completed_monotonic = 0.0
    app.state.publishing_status = {
        "enabled": bool(settings.records_enabled),
        "state": "idle" if settings.records_enabled else "disabled",
        "running": False,
        "queued": False,
        "last_run": None,
        "last_error": None,
        "source": None,
        "target_date": None,
        "mode": "background_only",
    }
    app.state.background_work_lock = asyncio.Lock()
    app.state.last_settlement_completed_monotonic = 0.0
    app.state.last_settlement_notification_key = None
    app.state.social_task = None
    app.state.social_lock = asyncio.Lock()
    app.state.last_social_sync_monotonic = 0.0
    app.state.social_status = {
        "running": True,
        "last_run": None,
        "last_error": None,
        "published_now": 0,
    }
    app.state.line_task = None
    app.state.line_lock = asyncio.Lock()
    app.state.line_resync_requested = False
    app.state.last_line_sync_monotonic = 0.0
    app.state.line_status = {
        "enabled": bool(line.enabled),
        "running": False,
        "status": "idle" if line.enabled else "disabled",
        "last_run": None,
        "last_error": None,
        "sent_now": 0,
        "configuration": line.status(),
    }
    app.state.retry_queue_status = {
        "enabled": bool(settings.retry_queue_enabled and performance.enabled),
        "status": "starting" if _role_runs("retry") else "assigned_to_other_process",
        "process_role": app.state.process_role,
        "last_check": None,
        "last_error": None,
        "processed": 0,
        "failed": 0,
    }
    managed_tasks: list[asyncio.Task] = []
    monitor_task = None
    if _role_runs("publish"):
        monitor_task = app.state.worker_registry.start(
            "pregame_refresh", lambda: _pregame_refresh_loop(app)
        )
        managed_tasks.append(monitor_task)
    app.state.pregame_task = monitor_task
    settlement_scheduler_task = None
    if _role_runs("settlement") and settings.settlement_internal_scheduler_enabled:
        settlement_scheduler_task = app.state.worker_registry.start(
            "settlement_scheduler", lambda: _settlement_scheduler_loop(app)
        )
        managed_tasks.append(settlement_scheduler_task)
    app.state.settlement_scheduler_task = settlement_scheduler_task
    calibration_scheduler_task = None
    if _role_runs("model") and settings.model_calibration_enabled and performance.enabled:
        calibration_scheduler_task = app.state.worker_registry.start(
            "model_calibration", lambda: _calibration_scheduler_loop(app)
        )
        managed_tasks.append(calibration_scheduler_task)
    app.state.calibration_scheduler_task = calibration_scheduler_task
    retry_queue_task = None
    if _role_runs("retry") and settings.retry_queue_enabled and performance.enabled:
        retry_queue_task = app.state.worker_registry.start(
            "retry_queue", lambda: _retry_queue_loop(app)
        )
        managed_tasks.append(retry_queue_task)
    app.state.retry_queue_task = retry_queue_task
    yield
    for task in managed_tasks:
        task.cancel()
    for task in managed_tasks:
        with suppress(asyncio.CancelledError):
            await task
    external_settlement_task = getattr(app.state, "external_settlement_task", None)
    if external_settlement_task is not None and not external_settlement_task.done():
        external_settlement_task.cancel()
        with suppress(asyncio.CancelledError):
            await external_settlement_task
    social_task = getattr(app.state, "social_task", None)
    if social_task is not None and not social_task.done():
        social_task.cancel()
        with suppress(asyncio.CancelledError):
            await social_task
    line_task = getattr(app.state, "line_task", None)
    if line_task is not None and not line_task.done():
        line_task.cancel()
        with suppress(asyncio.CancelledError):
            await line_task
    model_backfill_task = getattr(app.state, "model_backfill_task", None)
    if model_backfill_task is not None and not model_backfill_task.done():
        model_backfill_task.cancel()
        with suppress(asyncio.CancelledError):
            await model_backfill_task
    await service.aclose()
    await npb.aclose()
    await kbo.aclose()
    await cpbl.aclose()
    await odds.aclose()
    await app.state.worker_registry.close()
    await odds_api_io.aclose()
    await records.aclose()
    await member_auth.aclose()
    await billing.aclose()
    await billing_repository.aclose()
    await announcement_repository.aclose()
    await performance.aclose()
    await social.aclose()
    await line.aclose()


app = FastAPI(
    title="DiamondMind API",
    version=APP_VERSION,
    description="DiamondMind multi-sport platform. MLB, NPB, KBO and CPBL schedules, predictions, auto-publishing and settlement are active; NBA and EPL remain prepared for later adapters.",
    lifespan=lifespan,
)

allow_all = "*" in settings.cors_origins
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"] if allow_all else settings.cors_origins,
    allow_credentials=not allow_all,
    allow_methods=["GET", "POST", "PATCH", "DELETE", "OPTIONS"],
    allow_headers=["*"],
)


@app.middleware("http")
async def collect_request_metrics(request: Request, call_next):
    """Collect secret-free request counts and latency for the founder console."""
    started = monotonic()
    status_code = 500
    try:
        response = await call_next(request)
        status_code = int(response.status_code)
        return response
    finally:
        metrics = getattr(request.app.state, "request_metrics", None)
        if metrics is not None:
            route = request.scope.get("route")
            metrics.record(
                method=request.method,
                route=getattr(route, "path", request.url.path),
                status_code=status_code,
                duration_ms=(monotonic() - started) * 1000.0,
            )


def service(request: Request) -> MLBService:
    return request.app.state.mlb


def npb_service(request: Request) -> NPBService:
    return request.app.state.npb

def kbo_service(request: Request) -> AsianBaseballService:
    return request.app.state.kbo


def cpbl_service(request: Request) -> AsianBaseballService:
    return request.app.state.cpbl


def baseball_service(request: Request, league: str):
    code = str(league or "MLB").upper()
    if code == "MLB":
        return service(request)
    if code == "NPB":
        return npb_service(request)
    if code == "KBO":
        return kbo_service(request)
    if code == "CPBL":
        return cpbl_service(request)
    raise ValueError(f"Unsupported baseball league: {code}")


def records_repository(request: Request) -> SupabaseRecordsRepository:
    return request.app.state.records


def membership_admin_service(request: Request) -> AdminMembershipService:
    return request.app.state.membership_admin


def password_security_service(request: Request) -> PasswordSecurityService:
    return request.app.state.password_security


def member_trial_service(request: Request) -> NewMemberTrialService:
    return request.app.state.member_trial


def announcement_service(request: Request) -> AnnouncementService:
    return request.app.state.announcements


def performance_repository(request: Request) -> PerformanceRepository:
    return request.app.state.performance


def calibration_registry(request: Request) -> CalibrationRegistry:
    return getattr(request.app.state, "calibration_registry", CalibrationRegistry.empty())


def calibrate_selection(request: Request, selection: dict[str, Any], *, thresholds: bool = True) -> dict[str, Any]:
    return apply_registry_to_selection(
        selection,
        calibration_registry(request),
        minimum_probability=settings.min_market_probability if thresholds else None,
        minimum_edge=settings.min_market_edge if thresholds else None,
    )


def calibrate_bundle(request: Request, bundle: dict[str, Any]) -> dict[str, Any]:
    return apply_registry_to_bundle(
        bundle,
        calibration_registry(request),
        minimum_probability=settings.min_market_probability,
        minimum_edge=settings.min_market_edge,
    )


def social_service(request: Request) -> DiamondMindSocialService:
    return request.app.state.social


def line_service(request: Request) -> LineMessagingService:
    return request.app.state.line


def odds_service(request: Request) -> OddsService:
    return request.app.state.odds


def odds_api_io_service(request: Request) -> OddsApiIoService:
    return request.app.state.odds_api_io


def member_auth_service(request: Request) -> SupabaseMemberAuth:
    return request.app.state.member_auth


def billing_service(request: Request) -> ECPayBillingService:
    return request.app.state.billing


def _official_settlement_verification_check(records: list[dict]) -> dict:
    """Build the launch-check result from persisted public recommendations.

    A completed real cycle means that a recommendation was publicly published,
    retained in the records database and later received a terminal settlement.
    Current games may still be pending without invalidating an earlier verified
    end-to-end cycle.
    """

    published = [
        record
        for record in records
        if record.get("is_public") is True and record.get("published_at")
    ]
    verified = [
        record
        for record in published
        if str(record.get("status") or "").lower() in {"won", "lost", "push", "void"}
        and record.get("settled_at")
    ]

    if verified:
        leagues = sorted({str(record.get("league") or "MLB").upper() for record in verified})
        league_text = "／".join(leagues)
        return {
            "key": "official_settlement_verification",
            "label": "真實推薦與結算驗收",
            "status": "pass",
            "detail": f"已驗收 {len(verified)} 筆 {league_text} 真實正式推薦；發布紀錄保留與自動結算正常",
            "blocking": False,
            "manual": False,
        }

    if published:
        detail = f"已發布 {len(published)} 筆真實正式推薦，等待至少一筆完成賽後自動結算"
    else:
        detail = "尚無同時具備正式公開發布與賽後結算結果的真實推薦"
    return {
        "key": "official_settlement_verification",
        "label": "真實推薦與結算驗收",
        "status": "pending",
        "detail": detail,
        "blocking": False,
        "manual": False,
    }


def _csv_safe(value: object) -> str:
    if value is None:
        return ""
    text = str(value)
    if text.startswith(("=", "+", "-", "@")):
        return "'" + text
    return text


def _csv_response(filename: str, fieldnames: list[str], rows: list[dict[str, object]]) -> Response:
    buffer = io.StringIO(newline="")
    writer = csv.DictWriter(buffer, fieldnames=fieldnames, extrasaction="ignore")
    writer.writeheader()
    for row in rows:
        writer.writerow({key: _csv_safe(row.get(key)) for key in fieldnames})
    content = ("\ufeff" + buffer.getvalue()).encode("utf-8")
    return Response(
        content=content,
        media_type="text/csv; charset=utf-8",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


def bearer_token(authorization: str | None) -> str | None:
    if authorization and authorization.lower().startswith("bearer "):
        return authorization[7:].strip()
    return None


async def authenticated_member(request: Request, authorization: str | None) -> dict:
    try:
        return await member_auth_service(request).member(bearer_token(authorization))
    except MemberAccessError as exc:
        raise HTTPException(status_code=401, detail=str(exc)) from exc


async def optional_member(request: Request, authorization: str | None) -> dict:
    """Return guest access when no bearer token is supplied.

    An invalid or expired token is still rejected so the browser can clear the
    stale session instead of silently treating it as a valid free account.
    """

    token = bearer_token(authorization)
    if not token:
        return {"id": None, "email": None, "role": "guest", "has_pro_access": False}
    try:
        return await member_auth_service(request).member(token)
    except MemberAccessError as exc:
        raise HTTPException(status_code=401, detail=str(exc)) from exc


def _public_team_snapshot(team: dict | None) -> dict:
    team = team or {}
    pitcher = team.get("probable_pitcher") or {}
    return {
        "id": team.get("id"),
        "name": team.get("name"),
        "abbr": team.get("abbr"),
        "score": team.get("score"),
        "probable_pitcher": {
            "id": pitcher.get("id"),
            "name": pitcher.get("name") or "尚未公布",
        },
    }


def locked_game_detail(detail: dict, member: dict) -> dict:
    """Whitelist the only matchup fields available without Pro access.

    Never return the analysis object and then rely on CSS to hide it. This
    response deliberately omits lineups, bullpen, weather, Statcast, model pick,
    confidence, completeness, sources and every five-engine metric.
    """

    game = detail.get("game") or {}
    public_game = {
        key: game.get(key)
        for key in (
            "game_pk", "game_date", "date_taiwan", "time_taiwan", "status",
            "detailed_status", "inning", "inning_state", "venue_id", "venue",
            "game_type", "season_context", "event_label", "is_special_event",
            "doubleheader_code", "is_doubleheader", "game_number", "game_label",
            "display_time_taiwan",
        )
        if key in game
    }
    public_game["away"] = _public_team_snapshot(game.get("away"))
    public_game["home"] = _public_team_snapshot(game.get("home"))
    return {
        "game": public_game,
        "analysis_locked": True,
        "access": {
            "role": member.get("role") or "guest",
            "has_pro_access": False,
            "required_plan": "pro",
        },
        "locked_modules": [
            "starter", "lineup", "bullpen", "environment", "advanced",
        ],
        "message": "升級 Pro 解鎖完整賽事情報。",
        "meta": {
            "source": "MLB Stats API",
            "updated_at": (detail.get("meta") or {}).get("updated_at"),
            "analysis_payload_returned": False,
        },
    }


async def admin_member(request: Request, authorization: str | None) -> dict:
    member = await authenticated_member(request, authorization)
    if member.get("role") != "admin":
        raise HTTPException(status_code=403, detail="Founder access is required")
    return member


def requested_date(value: date | None) -> date:
    return value or datetime.now(TAIPEI).date()


def _asian_game_matches_target_date(game: dict, target_date: date) -> bool:
    """Reject stale adjacent-day games before candidate or auto-publication use."""

    game_pk = str(game.get("game_pk") or game.get("external_game_id") or "")
    match = re.search(r"_(\d{8})(?:_|$)", game_pk)
    if match:
        try:
            if datetime.strptime(match.group(1), "%Y%m%d").date() != target_date:
                return False
        except ValueError:
            return False

    start = parse_game_datetime(game.get("game_date"))
    if start is not None:
        if start.tzinfo is None:
            start = start.replace(tzinfo=TAIPEI)
        if start.astimezone(TAIPEI).date() != target_date:
            return False

    status = str(game.get("status") or "").lower()
    if status not in {"upcoming", "scheduled", "preview"}:
        return False
    away_score = (game.get("away") or {}).get("score")
    home_score = (game.get("home") or {}).get("score")
    if away_score is not None or home_score is not None:
        return False
    return True


def cron_secret_matches(provided: str | None, configured: str) -> bool:
    """Constant-time comparison for the server-to-server scheduler secret."""

    if not provided or not configured:
        return False
    return compare_digest(provided.encode("utf-8"), configured.encode("utf-8"))



def publication_policy(analysis: dict, *, automatic: bool = False, now: datetime | None = None) -> dict:
    game = analysis.get("game") or {}
    context = str(game.get("season_context") or "unsupported")
    confidence = float(analysis.get("confidence") or 0)
    data_quality = float(analysis.get("data_quality") or 0)
    timing = analysis.get("timing") or game_timing(
        game,
        now=now,
        lineup_watch_minutes=settings.pregame_lineup_watch_minutes,
        final_lock_minutes=settings.pregame_final_lock_minutes,
    )
    validation = analysis.get("roster_validation") or {}
    validation_overall = validation.get("overall") or {}
    lineups = validation.get("lineups") or {}
    lineup_rates = [
        float((lineups.get(side) or {}).get("validation_rate") or 0)
        for side in ("away", "home")
    ]
    lineup_rate = min(lineup_rates) if lineup_rates else 0.0
    starter_group = ((analysis.get("analysis_groups") or {}).get("starter") or {})
    blockers: list[str] = []
    warnings: list[str] = []

    if str(game.get("status") or "upcoming") != "upcoming" or timing.get("stage") == "started":
        blockers.append("比賽已開始或不再接受賽前發布。")
    if context not in {"regular_season", "postseason"}:
        blockers.append(f"{game.get('event_label') or '特殊賽事'}專用模型尚未啟用，不能套用一般模型正式發布。")
    if data_quality < settings.minimum_publish_data_quality:
        blockers.append(f"整體資料完整度不足 {settings.minimum_publish_data_quality * 100:.0f}%。")
    if starter_group.get("both_starters_ready") is not True:
        blockers.append("兩隊先發投手、投手數據或名單驗證尚未達正式發布標準。")
    if validation_overall.get("status") == "mismatch":
        blockers.append("球員與球隊身分驗證發現不一致，需重新整理後再確認。")
    if lineup_rate < settings.minimum_lineup_validation_rate:
        blockers.append(f"打線名單驗證率不足 {settings.minimum_lineup_validation_rate * 100:.0f}%。")
    if confidence < settings.min_confidence:
        message = f"模型信心 {confidence:.1f}% 低於門檻 {settings.min_confidence:.1f}%。"
        if automatic:
            blockers.append(message)
        else:
            warnings.append(message)
    if timing.get("stage") == "preview":
        warnings.append("目前仍是賽前預覽階段；先發、打線或盤口後續可能變動。")
    elif timing.get("stage") == "lineup_watch":
        warnings.append("已進入開賽前 90 分鐘監控階段；系統會持續重新分析正式打線。")
    if context == "postseason":
        warnings.append("季後賽請再確認輪值、休息天數與系列賽狀況。")

    can_publish = not blockers
    auto_ready = can_publish and timing.get("stage") == "final_lock" and confidence >= settings.min_confidence
    return {
        "can_publish": can_publish,
        "auto_publish_ready": auto_ready,
        "requires_confirmation": bool(warnings),
        "blockers": blockers,
        "warnings": warnings,
        "timing": timing,
        "lineup_validation_rate": round(lineup_rate, 3),
        "roster_validation": validation_overall,
        "checklist": {
            "game_not_started": timing.get("stage") != "started",
            "supported_event": context in {"regular_season", "postseason"},
            "both_starters_confirmed": starter_group.get("both_starters_ready") is True,
            "data_quality_passed": data_quality >= settings.minimum_publish_data_quality,
            "lineup_validation_passed": lineup_rate >= settings.minimum_lineup_validation_rate,
            "roster_validation_passed": validation_overall.get("status") != "mismatch",
            "confidence_passed": confidence >= settings.min_confidence,
            "final_lock_window": timing.get("stage") == "final_lock",
        },
    }


def _npb_auto_publish_window(
    games: list[dict],
    *,
    now: datetime | None = None,
    lead_minutes: int = 60,
    grace_minutes: int = 0,
    league: str = "NPB",
) -> dict:
    """Return the Asian fallback trigger state for the next unstarted game.

    The release window may begin well before first pitch. If an external
    scheduler is delayed or an earlier game has already started, the fallback
    moves to the next unstarted game instead of abandoning the entire slate.
    """

    code = str(league or "NPB").upper()
    current = now or datetime.now(TAIPEI)
    if current.tzinfo is None:
        current = current.replace(tzinfo=TAIPEI)
    current = current.astimezone(TAIPEI)
    valid_games: list[tuple[datetime, dict]] = []
    future_games: list[tuple[datetime, dict]] = []
    ignored_statuses = {"cancelled", "canceled", "postponed", "void", "no_game"}
    started_statuses = {"final", "completed", "live", "in_progress", "in progress"}
    for game in games:
        status = str(game.get("status") or "upcoming").strip().lower()
        if status in ignored_statuses:
            continue
        # The NPB adapter supplies a noon fallback when the official page has
        # no start time.  Never use that placeholder to trigger publication.
        if not (game.get("time_taiwan") or game.get("time_japan")):
            continue
        game_time = parse_game_datetime(game.get("game_date"))
        if game_time is None:
            continue
        if game_time.tzinfo is None:
            game_time = game_time.replace(tzinfo=TAIPEI)
        normalized_time = game_time.astimezone(TAIPEI)
        valid_games.append((normalized_time, game))
        if normalized_time > current and status not in started_statuses:
            future_games.append((normalized_time, game))

    if not valid_games:
        return {
            "due": False,
            "state": "schedule_unavailable",
            "message": f"尚未取得今日 {code} 最早開賽時間。",
            "earliest_game": None,
            "minutes_to_start": None,
        }

    if not future_games:
        game_time, earliest = min(valid_games, key=lambda item: item[0])
        return {
            "due": False,
            "state": "window_closed",
            "message": f"今日 {code} 已無尚未開賽場次，不會產生賽後推薦。",
            "lead_minutes": max(1, int(lead_minutes)),
            "grace_minutes": max(0, int(grace_minutes)),
            "minutes_to_start": round((game_time - current).total_seconds() / 60.0, 1),
            "earliest_game": {
                "game_pk": earliest.get("game_pk") or earliest.get("external_game_id"),
                "matchup": f'{(earliest.get("away") or {}).get("abbr") or (earliest.get("away") or {}).get("name")} @ {(earliest.get("home") or {}).get("abbr") or (earliest.get("home") or {}).get("name")}',
                "game_time_taipei": game_time.isoformat(),
                "time_taiwan": earliest.get("time_taiwan"),
            },
        }

    game_time, earliest = min(future_games, key=lambda item: item[0])
    minutes_to_start = (game_time - current).total_seconds() / 60.0
    safe_lead = max(1, int(lead_minutes))
    safe_grace = max(0, int(grace_minutes))
    effective_lead = safe_lead + safe_grace
    skipped_started_games = any(game_start <= current for game_start, _game in valid_games)
    if minutes_to_start <= effective_lead:
        state = "due"
        if skipped_started_games:
            message = f"較早場次已開賽，已改用下一場尚未開賽 {code} 的開賽前 {safe_lead} 分鐘自動發布窗。"
        else:
            message = f"已進入最早一場 {code} 開賽前 {safe_lead} 分鐘自動發布窗。"
        due = True
    else:
        state = "waiting"
        message = f"尚未進入最早一場 {code} 開賽前 {safe_lead} 分鐘自動發布窗。"
        due = False
    return {
        "due": due,
        "state": state,
        "message": message,
        "lead_minutes": safe_lead,
        "grace_minutes": safe_grace,
        "scheduler_tolerance_minutes": effective_lead,
        "recovered_after_earlier_game": skipped_started_games,
        "minutes_to_start": round(minutes_to_start, 1),
        "earliest_game": {
            "game_pk": earliest.get("game_pk") or earliest.get("external_game_id"),
            "matchup": f'{(earliest.get("away") or {}).get("abbr") or (earliest.get("away") or {}).get("name")} @ {(earliest.get("home") or {}).get("abbr") or (earliest.get("home") or {}).get("name")}',
            "game_time_taipei": game_time.isoformat(),
            "time_taiwan": earliest.get("time_taiwan"),
        },
    }


async def _run_social_sync_task(app: FastAPI, reason: str, *, force: bool = False) -> None:
    """Run Instagram synchronization outside request and settlement paths.

    Card/Reel rendering and Meta processing can take minutes. Keeping it in a
    tracked task prevents a successful settlement or member API request from
    being held open and avoids Render health-check alerts.
    """

    async with app.state.social_lock:
        now_mono = monotonic()
        elapsed = now_mono - float(getattr(app.state, "last_social_sync_monotonic", 0.0) or 0.0)
        if not force and elapsed < settings.social_sync_min_interval_seconds:
            app.state.social_status = {
                **dict(getattr(app.state, "social_status", {}) or {}),
                "running": False,
                "status": "cooldown",
                "reason": reason,
                "retry_after_seconds": max(0, int(settings.social_sync_min_interval_seconds - elapsed)),
                "last_error": None,
            }
            return
        request = type("BackgroundRequest", (), {"app": app})()
        app.state.social_status = {
            **dict(getattr(app.state, "social_status", {}) or {}),
            "running": True,
            "status": "running",
            "reason": reason,
            "started_at": iso_utc(),
            "last_error": None,
        }
        try:
            result = await sync_social_publications(request)
            app.state.last_social_sync_monotonic = monotonic()
            app.state.social_status = {**result, "running": False, "reason": reason}
        except asyncio.CancelledError:
            app.state.social_status = {
                **dict(getattr(app.state, "social_status", {}) or {}),
                "running": False,
                "status": "cancelled",
                "last_error": "CancelledError",
            }
            raise
        except Exception as exc:
            app.state.last_social_sync_monotonic = monotonic()
            app.state.social_status = {
                **dict(getattr(app.state, "social_status", {}) or {}),
                "running": False,
                "status": "warning",
                "last_run": iso_utc(),
                "last_error": type(exc).__name__,
                "error_detail": str(exc)[:300],
                "reason": reason,
            }


def _queue_social_sync(app: FastAPI, reason: str, *, force: bool = False) -> dict:
    current = getattr(app.state, "social_task", None)
    if current is not None and not current.done():
        return {"queued": False, "already_running": True, "reason": reason}
    task = asyncio.create_task(
        _run_social_sync_task(app, reason, force=force),
        name="diamondmind-social-sync",
    )
    app.state.social_task = task
    return {"queued": True, "already_running": False, "reason": reason}


async def _run_line_sync_task(app: FastAPI, reason: str, *, force: bool = False) -> None:
    """Synchronize pending LINE broadcasts outside request paths."""

    async with app.state.line_lock:
        now_mono = monotonic()
        elapsed = now_mono - float(getattr(app.state, "last_line_sync_monotonic", 0.0) or 0.0)
        if not force and elapsed < settings.line_sync_min_interval_seconds:
            app.state.line_status = {
                **dict(getattr(app.state, "line_status", {}) or {}),
                "running": False,
                "status": "cooldown",
                "reason": reason,
                "retry_after_seconds": max(0, int(settings.line_sync_min_interval_seconds - elapsed)),
                "last_error": None,
            }
            return
        request = type("BackgroundRequest", (), {"app": app})()
        app.state.line_status = {
            **dict(getattr(app.state, "line_status", {}) or {}),
            "enabled": bool(app.state.line.enabled),
            "running": True,
            "status": "running",
            "reason": reason,
            "started_at": iso_utc(),
            "last_error": None,
            "configuration": app.state.line.status(),
        }
        try:
            result = await sync_line_notifications(request)
            if bool(getattr(app.state, "line_resync_requested", False)):
                app.state.line_resync_requested = False
                follow_up = await sync_line_notifications(request)
                result = {
                    **follow_up,
                    "sent_now": int(result.get("sent_now") or 0) + int(follow_up.get("sent_now") or 0),
                    "failed_now": int(result.get("failed_now") or 0) + int(follow_up.get("failed_now") or 0),
                    "events": [*(result.get("events") or []), *(follow_up.get("events") or [])],
                }
            app.state.last_line_sync_monotonic = monotonic()
            app.state.line_status = {**result, "running": False, "reason": reason}
            if int(result.get("failed_now") or 0) > 0 and reason != "retry_queue":
                await _enqueue_retry_job_safely(
                    app,
                    job_type="line_sync",
                    worker_role="monitor",
                    payload={"reason": reason},
                    error=str(result.get("last_error") or "LINE delivery failed"),
                )
        except asyncio.CancelledError:
            app.state.line_status = {
                **dict(getattr(app.state, "line_status", {}) or {}),
                "running": False,
                "status": "cancelled",
                "last_error": "CancelledError",
            }
            raise
        except Exception as exc:
            app.state.last_line_sync_monotonic = monotonic()
            app.state.line_status = {
                **dict(getattr(app.state, "line_status", {}) or {}),
                "running": False,
                "status": "warning",
                "last_run": iso_utc(),
                "last_error": type(exc).__name__,
                "error_detail": str(exc)[:300],
                "reason": reason,
                "configuration": app.state.line.status(),
            }
            if reason != "retry_queue":
                await _enqueue_retry_job_safely(
                    app,
                    job_type="line_sync",
                    worker_role="monitor",
                    payload={"reason": reason},
                    error=f"{type(exc).__name__}: {str(exc)[:300]}",
                )


def _queue_line_sync(app: FastAPI, reason: str, *, force: bool = False) -> dict:
    if not getattr(app.state, "line", None) or not app.state.line.enabled:
        return {"queued": False, "reason": "line_not_configured"}
    current = getattr(app.state, "line_task", None)
    if current is not None and not current.done():
        app.state.line_resync_requested = True
        return {"queued": False, "already_running": True, "resync_requested": True, "reason": reason}
    task = asyncio.create_task(
        _run_line_sync_task(app, reason, force=force),
        name="diamondmind-line-sync",
    )
    app.state.line_task = task
    return {"queued": True, "already_running": False, "reason": reason}


def _auto_publish_created(result: dict[str, dict]) -> bool:
    for league_result in result.values():
        for key in ("free", "pro"):
            payload = league_result.get(key) if isinstance(league_result, dict) else None
            if isinstance(payload, dict) and payload.get("published") is True:
                return True
    return False


async def _settlement_scheduler_loop(app: FastAPI) -> None:
    """Queue lightweight settlement passes without blocking health checks.

    This is an in-process fallback for Render deployments where the existing
    auto-publish cron is present but a dedicated settlement cron was never
    configured. The queue respects the same cooldown and lock as external jobs.
    """

    await asyncio.sleep(settings.settlement_internal_startup_delay_seconds)
    while True:
        app.state.worker_registry.heartbeat("settlement_scheduler", phase="checking")
        try:
            if app.state.records.enabled:
                queued = _queue_settlement_background(
                    app, "internal_settlement_scheduler", respect_cooldown=True
                )
                current = dict(getattr(app.state, "settlement_status", {}) or {})
                current.update({
                    "scheduler": "internal_fallback",
                    "scheduler_interval_seconds": settings.settlement_internal_interval_seconds,
                    "scheduler_last_check": iso_utc(),
                    "scheduler_queue_result": {
                        key: queued.get(key)
                        for key in ("accepted", "already_running", "cooldown", "retry_after_seconds")
                        if key in queued
                    },
                })
                app.state.settlement_status = current
            else:
                current = dict(getattr(app.state, "settlement_status", {}) or {})
                current.update({
                    "scheduler": "disabled_no_database",
                    "scheduler_last_check": iso_utc(),
                })
                app.state.settlement_status = current
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            current = dict(getattr(app.state, "settlement_status", {}) or {})
            current.update({
                "scheduler": "internal_fallback",
                "scheduler_last_check": iso_utc(),
                "scheduler_error": type(exc).__name__,
            })
            app.state.settlement_status = current
        await asyncio.sleep(settings.settlement_internal_interval_seconds)


async def _run_auto_calibration(
    app: FastAPI,
    *,
    reason: str,
    force: bool = False,
    promote_override: bool | None = None,
) -> dict[str, Any]:
    status = dict(getattr(app.state, "calibration_status", {}) or {})
    if not settings.model_calibration_enabled or not app.state.performance.enabled:
        status.update({"running": False, "status": "disabled", "last_error": None})
        app.state.calibration_status = status
        return status
    if app.state.calibration_lock.locked():
        return {"ok": True, "accepted": False, "already_running": True}
    async with app.state.calibration_lock:
        started_at = iso_utc()
        status.update({
            "running": True,
            "status": "running",
            "reason": reason,
            "started_at": started_at,
            "last_error": None,
        })
        app.state.calibration_status = status
        try:
            result = await app.state.performance.auto_calibrate(
                actor_id=f"system:{reason}",
                days=settings.model_calibration_lookback_days,
                minimum_sample=settings.model_calibration_minimum_sample,
                minimum_validation_sample=settings.model_calibration_minimum_validation_sample,
                # V22.2 safety rule: force means "run now", never "deploy".
                # Only a founder-confirmed request may pass promote_override.
                promote=bool(promote_override),
            )
            registry = await app.state.performance.calibration_registry()
            app.state.calibration_registry = registry
            status.update({
                "running": False,
                "status": "completed",
                "last_run": result.get("completed_at") or iso_utc(),
                "last_error": None,
                "rows_scanned": result.get("rows_scanned"),
                "candidate_count": len(result.get("candidates") or []),
                "deployable_candidate_count": sum(
                    bool(item.get("promote"))
                    for item in (result.get("candidates") or [])
                    if isinstance(item, dict)
                ),
                "promoted_count": result.get("promoted_count"),
                "promoted": result.get("promoted") or [],
                "profiles_loaded": len(registry.profiles),
                "registry_loaded_at": registry.loaded_at,
                "schema": "ready",
            })
            app.state.calibration_status = status
            return {"ok": True, **result, "profiles_loaded": len(registry.profiles)}
        except PerformanceStorageError as exc:
            message = str(exc)
            status.update({
                "running": False,
                "status": "migration_required" if "unavailable" in message.lower() else "failed",
                "last_run": iso_utc(),
                "last_error": message,
                "schema": "migration_required" if "unavailable" in message.lower() else status.get("schema"),
            })
            app.state.calibration_status = status
            if reason != "retry_queue":
                await _enqueue_retry_job_safely(
                    app,
                    job_type="model_calibration",
                    worker_role="model",
                    payload={"reason": reason},
                    error=message,
                )
            return {"ok": False, "error": message, "status": status.get("status")}
        except Exception as exc:
            status.update({
                "running": False,
                "status": "failed",
                "last_run": iso_utc(),
                "last_error": f"{type(exc).__name__}: {str(exc)[:240]}",
            })
            app.state.calibration_status = status
            if reason != "retry_queue":
                await _enqueue_retry_job_safely(
                    app,
                    job_type="model_calibration",
                    worker_role="model",
                    payload={"reason": reason},
                    error=status["last_error"],
                )
            return {"ok": False, "error": status["last_error"]}


async def _calibration_scheduler_loop(app: FastAPI) -> None:
    await asyncio.sleep(settings.model_calibration_startup_delay_seconds)
    while True:
        app.state.worker_registry.heartbeat("model_calibration", phase="checking")
        try:
            await _run_auto_calibration(
                app,
                reason="scheduled_calibration",
                promote_override=False,
            )
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            current = dict(getattr(app.state, "calibration_status", {}) or {})
            current.update({
                "running": False,
                "status": "failed",
                "last_run": iso_utc(),
                "last_error": f"{type(exc).__name__}: {str(exc)[:240]}",
            })
            app.state.calibration_status = current
        await asyncio.sleep(settings.model_calibration_interval_seconds)


async def _enqueue_retry_job_safely(
    app: FastAPI,
    *,
    job_type: str,
    worker_role: str,
    payload: dict | None,
    error: str,
) -> None:
    repository = getattr(app.state, "performance", None)
    if (
        not settings.retry_queue_enabled
        or repository is None
        or not repository.enabled
    ):
        return
    bucket = datetime.now(TAIPEI).strftime("%Y%m%d%H%M")
    reason = str((payload or {}).get("reason") or "background_failure")
    try:
        await repository.enqueue_retry_job(
            job_type=job_type,
            worker_role=worker_role,
            payload=payload or {},
            dedupe_key=f"{worker_role}:{job_type}:{reason}:{bucket}",
            last_error=error,
            max_attempts=settings.retry_queue_max_attempts,
        )
    except PerformanceStorageError as exc:
        current = dict(getattr(app.state, "retry_queue_status", {}) or {})
        current.update({
            "status": (
                "migration_required"
                if "Retry Queue" in str(exc)
                else "degraded"
            ),
            "last_check": iso_utc(),
            "last_error": str(exc)[:300],
        })
        app.state.retry_queue_status = current


def _retry_roles_for_process() -> list[str]:
    role = _normalized_process_role()
    if role == "all":
        return ["publish", "settlement", "model", "monitor"]
    return [role] if role in {"publish", "settlement", "model", "monitor"} else []


async def _process_retry_job(app: FastAPI, job: dict) -> None:
    job_type = str(job.get("job_type") or "")
    if job_type == "publish_refresh":
        status = await _run_pregame_refresh_cycle(app)
        if status.get("status") == "skipped_busy":
            raise RuntimeError("publish_worker_busy")
        return
    if job_type == "settlement":
        result = _queue_settlement_background(
            app,
            "retry_queue",
            respect_cooldown=False,
        )
        if not result.get("accepted"):
            raise RuntimeError("settlement_retry_not_accepted")
        return
    if job_type == "model_calibration":
        result = await _run_auto_calibration(
            app,
            reason="retry_queue",
            force=True,
            promote_override=False,
        )
        if not result.get("ok"):
            raise RuntimeError(str(result.get("error") or "model_retry_failed"))
        return
    if job_type == "line_sync":
        await _run_line_sync_task(app, "retry_queue", force=True)
        state = dict(getattr(app.state, "line_status", {}) or {})
        if state.get("status") in {"warning", "failed"} or int(state.get("failed_now") or 0) > 0:
            raise RuntimeError(str(state.get("last_error") or "line_sync_failed"))
        return
    raise RuntimeError(f"unsupported_retry_job:{job_type or 'unknown'}")


async def _retry_queue_loop(app: FastAPI) -> None:
    await asyncio.sleep(10)
    roles = _retry_roles_for_process()
    locked_by = (
        settings.render_instance_id
        or f"{_normalized_process_role()}:{getattr(app.state, 'started_at', 'runtime')}"
    )
    while True:
        app.state.worker_registry.heartbeat(
            "retry_queue",
            phase="checking",
            roles=roles,
        )
        current = dict(getattr(app.state, "retry_queue_status", {}) or {})
        try:
            processed_now = 0
            for role in roles:
                job = await app.state.performance.claim_retry_job(
                    worker_role=role,
                    locked_by=locked_by,
                )
                if not job:
                    continue
                try:
                    await _process_retry_job(app, job)
                    await app.state.performance.complete_retry_job(
                        str(job.get("id"))
                    )
                    processed_now += 1
                    current["processed"] = int(current.get("processed") or 0) + 1
                except asyncio.CancelledError:
                    raise
                except Exception as exc:
                    await app.state.performance.fail_retry_job(
                        job=job,
                        error=f"{type(exc).__name__}: {str(exc)[:500]}",
                    )
                    current["failed"] = int(current.get("failed") or 0) + 1
            snapshot = await app.state.performance.retry_queue_snapshot(limit=100)
            current.update({
                **snapshot,
                "status": "running",
                "process_role": _normalized_process_role(),
                "roles": roles,
                "processed_now": processed_now,
                "last_check": iso_utc(),
                "last_error": None,
            })
        except asyncio.CancelledError:
            raise
        except PerformanceStorageError as exc:
            current.update({
                "status": (
                    "migration_required"
                    if "Retry Queue" in str(exc)
                    else "degraded"
                ),
                "last_check": iso_utc(),
                "last_error": str(exc)[:300],
            })
        except Exception as exc:
            current.update({
                "status": "degraded",
                "last_check": iso_utc(),
                "last_error": f"{type(exc).__name__}: {str(exc)[:300]}",
            })
        app.state.retry_queue_status = current
        await asyncio.sleep(settings.retry_queue_poll_seconds)


async def _run_pregame_refresh_cycle(app: FastAPI) -> dict:
    """Run one bounded refresh/publish cycle so Retry Queue can replay it."""
    now = datetime.now(TAIPEI)
    if (
        app.state.background_work_lock.locked()
        or app.state.external_publish_lock.locked()
    ):
        status = {
            "running": True,
            "status": "skipped_busy",
            "last_run": iso_utc(),
            "last_error": None,
            "interval_seconds": settings.pregame_refresh_interval_seconds,
            "message": "A settlement or publishing job is active; this refresh cycle was skipped.",
        }
        app.state.pregame_status = status
        return status

    async with app.state.external_publish_lock, app.state.background_work_lock:
        background_request = type("BackgroundRequest", (), {"app": app})()
        summaries: list[dict] = []
        for target_date in (now.date(), (now + timedelta(days=1)).date()):
            try:
                analyses = await asyncio.wait_for(
                    app.state.mlb.matchup_analyses(target_date, pitcher_limit=None),
                    timeout=max(20.0, settings.request_timeout_seconds * 3.0),
                )
                summaries.append({
                    "date": target_date.isoformat(),
                    "games": len(analyses.get("items") or []),
                    "ok": True,
                })
            except (TimeoutError, MLBUpstreamError):
                summaries.append({
                    "date": target_date.isoformat(),
                    "games": 0,
                    "ok": False,
                    "error": "MLBRefreshTimeout",
                })
            await asyncio.sleep(0)

        asian_odds_refresh: dict[str, dict] = {}
        asian_auto_publish: dict[str, dict] = {}
        if app.state.records.enabled:
            for code in ("NPB", "KBO", "CPBL"):
                policy = _asian_auto_settings(code)
                if not (policy["free"] or policy["pro"]):
                    asian_odds_refresh[code] = {
                        "refreshed": False,
                        "state": "disabled",
                        "league": code,
                    }
                    asian_auto_publish[code] = {
                        "free": {"published": False, "state": "disabled", "league": code},
                        "pro": {"published": False, "state": "disabled", "league": code},
                    }
                    continue
                try:
                    asian_odds_refresh[code] = await asyncio.wait_for(
                        refresh_asian_odds_snapshot(
                            background_request,
                            now.date(),
                            code,
                            now=now,
                        ),
                        timeout=max(
                            25.0,
                            settings.request_timeout_seconds * 4.0,
                        ),
                    )
                except (
                    TimeoutError,
                    RecordsStorageError,
                    NPBUpstreamError,
                    AsianBaseballUpstreamError,
                    OddsUpstreamError,
                    OddsApiIoUpstreamError,
                ) as exc:
                    asian_odds_refresh[code] = {
                        "refreshed": False,
                        "state": "error",
                        "league": code,
                        "error": type(exc).__name__,
                    }
                try:
                    free_result = await asyncio.wait_for(
                        auto_publish_asian_free_pick(
                            background_request, now.date(), code, now=now
                        ),
                        timeout=max(25.0, settings.request_timeout_seconds * 4.0),
                    )
                    pro_result = await asyncio.wait_for(
                        auto_publish_asian_pro_package(
                            background_request, now.date(), code, now=now
                        ),
                        timeout=max(35.0, settings.request_timeout_seconds * 5.0),
                    )
                    asian_auto_publish[code] = {
                        "free": free_result,
                        "pro": pro_result,
                    }
                except (
                    TimeoutError,
                    RecordsStorageError,
                    NPBUpstreamError,
                    AsianBaseballUpstreamError,
                ) as exc:
                    asian_auto_publish[code] = {
                        "free": {"published": False, "state": "error", "league": code},
                        "pro": {"published": False, "state": "error", "league": code},
                        "error": type(exc).__name__,
                    }
                await asyncio.sleep(0)

        social_queue = {"queued": False, "reason": "nothing_published"}
        line_queue = {"queued": False, "reason": "nothing_published"}
        if _auto_publish_created(asian_auto_publish):
            social_queue = _queue_social_sync(app, "asian_auto_publish")
            line_queue = _queue_line_sync(app, "asian_auto_publish", force=True)
        status = {
            "running": True,
            "status": "idle",
            "last_run": iso_utc(),
            "last_error": None,
            "interval_seconds": settings.pregame_refresh_interval_seconds,
            "dates": summaries,
            "settlement": {
                "mode": "background_only",
                "trigger": "/api/v1/jobs/settlement",
            },
            "asian_odds_refresh": asian_odds_refresh,
            "asian_auto_publish": asian_auto_publish,
            "npb_auto_publish": asian_auto_publish.get("NPB", {}),
            "instagram": social_queue,
            "line": line_queue,
        }
        app.state.pregame_status = status
        return status


async def _pregame_refresh_loop(app: FastAPI) -> None:
    """Refresh model inputs and Asian auto-publishing without settlement."""
    await asyncio.sleep(30)
    while True:
        app.state.worker_registry.heartbeat("pregame_refresh", phase="checking")
        try:
            await _run_pregame_refresh_cycle(app)
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # background loop must never stop the API
            app.state.pregame_status = {
                "running": True,
                "status": "warning",
                "last_run": iso_utc(),
                "last_error": type(exc).__name__,
                "interval_seconds": settings.pregame_refresh_interval_seconds,
            }
            await _enqueue_retry_job_safely(
                app,
                job_type="publish_refresh",
                worker_role="publish",
                payload={"reason": "pregame_refresh_failure"},
                error=f"{type(exc).__name__}: {str(exc)[:500]}",
            )
        await asyncio.sleep(max(300, settings.pregame_refresh_interval_seconds))


_INTERNAL_MEMBER_COPY = re.compile(
    r"(創辦人|觀察名單|觀察候選|內部審核|不(?:計入|記錄|列入|計)[^。！？]{0,16}戰績)"
)


def _member_visible_summary(value: object) -> str:
    text = str(value or "").strip()
    if not text:
        return "此推薦已正式發布並鎖定。"
    sentences = re.findall(r"[^。！？]+[。！？]?", text) or [text]
    visible = "".join(
        sentence for sentence in sentences
        if not _INTERNAL_MEMBER_COPY.search(sentence)
    ).strip()
    return visible or "此推薦已正式發布並鎖定。"


def _selection_for_member(selection: dict | None, *, founder: bool = False) -> dict | None:
    if not isinstance(selection, dict):
        return None
    result = deepcopy(selection)
    if founder:
        return result

    result["summary"] = _member_visible_summary(result.get("summary"))
    result.pop("watchlist_reasons", None)
    if result.get("candidate_tier") in {"watchlist", "founder_selected"}:
        result["candidate_tier"] = "formal"

    publication = result.get("publication")
    if isinstance(publication, dict):
        publication = deepcopy(publication)
        for key in (
            "origin_tier",
            "selection_tier",
            "promoted_from_watchlist",
            "counts_as_ai_formal",
        ):
            publication.pop(key, None)
        if publication.get("mode") == "founder_selected":
            publication["mode"] = "published"
        result["publication"] = publication

    legs = result.get("legs")
    if isinstance(legs, list):
        result["legs"] = [
            _selection_for_member(leg, founder=False) or {}
            for leg in legs
            if isinstance(leg, dict)
        ]
    return result


_MEMBER_FINANCIAL_KEYS = {
    "performance",
    "profit_units",
    "roi_percent",
    "stake_units",
    "returned_units",
    "effective_decimal_odds",
    "cumulative_profit_units",
    "daily_profit_units",
}


def _strip_member_financials(value: object) -> object:
    """Remove founder-only financial metrics from member-facing payloads."""
    if isinstance(value, dict):
        return {
            key: _strip_member_financials(item)
            for key, item in value.items()
            if key not in _MEMBER_FINANCIAL_KEYS
        }
    if isinstance(value, list):
        return [_strip_member_financials(item) for item in value]
    return value


def _free_pick_for_member(
    selection: dict | None,
    *,
    founder: bool = False,
) -> dict | None:
    """Return the compact daily-pick card payload.

    Founder/admin requests preserve the publication source marker so the UI
    can show that the locked daily pick was explicitly selected by the
    founder. Member requests still receive the same public card without
    internal publication metadata.
    """

    result = _selection_for_member(selection, founder=founder)
    if not result:
        return result
    for key in (
        "factors",
        "analysis_groups",
        "engine",
        "starting_pitchers",
        "lineups",
        "bullpen",
        "environment",
        "advanced",
        "data_sources",
        "source_status",
        "model_inputs",
    ):
        result.pop(key, None)
    game = result.get("game")
    if isinstance(game, dict):
        result["game"] = {
            key: game.get(key)
            for key in ("event_label", "season_context", "status", "detailed_status")
            if game.get(key) is not None
        }
    return result


def _public_prediction_response(payload: dict) -> dict:
    result = deepcopy(payload)
    if isinstance(result.get("selection"), dict):
        result["selection"] = _free_pick_for_member(result["selection"])
    # Unpublished candidates and publication policy are internal model review data.
    result.pop("candidate", None)
    result.pop("publication_policy", None)
    return result


def locked_prediction_from_record(
    prediction_date: date,
    record: dict,
) -> dict | None:
    snapshot = record.get("prediction_snapshot")
    if not isinstance(snapshot, dict) or not snapshot:
        return None
    snapshot = deepcopy(snapshot)
    snapshot["result"] = {
        "status": str(record.get("status") or "pending"),
        "away_score": record.get("away_score"),
        "home_score": record.get("home_score"),
        "result_note": record.get("result_note"),
        "settled_at": record.get("settled_at"),
    }
    return {
        "date": prediction_date.isoformat(),
        "published": True,
        "locked": True,
        "selection": snapshot,
        "message": "此賽事日的正式推薦已鎖定，後續更新不會更換推薦內容。",
        "meta": {
            "locked": True,
            "record_id": record.get("id"),
            "published_at": record.get("published_at"),
            "model_version": snapshot.get("model_version"),
        },
        "persistence": {
            "enabled": True,
            "stored": True,
            "created": False,
            "locked": True,
            "record_id": record.get("id"),
        },
    }


async def prediction_with_persistence(
    request: Request,
    prediction_date: date,
    *,
    publish_if_eligible: bool = True,
) -> dict:
    repository = records_repository(request)
    lookup_message = None
    if repository.enabled:
        try:
            existing = await repository.get_record_for_date(prediction_date.isoformat(), "MLB")
            if existing:
                snapshot = existing.get("prediction_snapshot")
                if isinstance(snapshot, dict):
                    try:
                        await performance_repository(request).capture_public(prediction_date.isoformat(), str(existing.get("id")), snapshot)
                    except PerformanceStorageError:
                        pass
                locked = locked_prediction_from_record(prediction_date, existing)
                if locked:
                    return locked
        except RecordsStorageError:
            # The model can still provide a result during a temporary database
            # incident, but it is clearly marked as not durably locked.
            lookup_message = "紀錄資料庫暫時無法確認今日鎖單。"

    result = await service(request).top_prediction(prediction_date)
    if isinstance(result.get("selection"), dict):
        selection = dict(result["selection"])
        selection.setdefault("league", "MLB")
        selection.setdefault("market", "moneyline")
        result["selection"] = calibrate_selection(request, selection, thresholds=False)
    if result.get("published") and result.get("selection"):
        policy = publication_policy(result["selection"], automatic=True)
        if not policy["auto_publish_ready"]:
            result = {
                **result, "published": False, "selection": None,
                "candidate": result.get("selection"),
                "message": "模型已完成預覽；MLB 維持創辦人手動正式發布，不會由排程自動鎖定。",
                "publication_policy": policy,
            }
    persistence = {"enabled": repository.enabled, "stored": False}
    if lookup_message:
        persistence["message"] = lookup_message
    if result.get("published") and not publish_if_eligible:
        # A normal page view must never become the action that locks the
        # official pick. Only the protected scheduler or the founder publish
        # endpoint is allowed to create the immutable public record.
        return {
            "date": prediction_date.isoformat(),
            "published": False,
            "locked": False,
            "selection": None,
            "message": "此賽事日的 MLB 免費精選尚未發布；請由創辦人從 MLB 候選中指定後正式鎖定。",
            "meta": {
                **(result.get("meta") or {}),
                "publication_status": "pending",
            },
            "persistence": persistence,
        }
    if result.get("published") and repository.enabled:
        try:
            stored, created = await repository.publish_prediction_once(
                result["date"], result["selection"]
            )
            persistence.update(
                {
                    "stored": True,
                    "created": created,
                    "locked": True,
                    "record_id": stored.get("id"),
                }
            )
            try:
                await performance_repository(request).capture_public(result["date"], str(stored.get("id")), result["selection"])
            except PerformanceStorageError:
                persistence["snapshot_message"] = "模型快照資料表暫時無法寫入。"
            if not created:
                locked = locked_prediction_from_record(prediction_date, stored)
                if locked:
                    return locked
        except RecordsStorageError:
            # Prediction remains available even if the records database has a
            # temporary incident. It can be requested again to retry the upsert.
            persistence["message"] = "推薦已產生，但紀錄資料庫暫時無法寫入。"
    result["persistence"] = persistence
    return result


async def _settlement_game_result_cached(
    mlb_service: MLBService,
    npb_adapter: NPBService,
    kbo_adapter: AsianBaseballService,
    cpbl_adapter: AsianBaseballService,
    league: str,
    game_pk: str,
    cache: dict[tuple[str, str], dict | None],
    selection: dict | None = None,
) -> dict:
    key = (str(league or "MLB").upper(), str(game_pk))
    if key in cache:
        cached = cache[key]
        if cached is None:
            raise KeyError(game_pk)
        return deepcopy(cached)
    try:
        result = await _game_result_for_ref(
            mlb_service, npb_adapter, kbo_adapter, cpbl_adapter, key[0], key[1], selection
        )
    except Exception:
        cache[key] = None
        raise
    cache[key] = deepcopy(result)
    resolved_pk = str((result.get("settlement_match") or {}).get("resolved_game_pk") or result.get("game_pk") or "")
    if resolved_pk:
        cache[(key[0], resolved_pk)] = deepcopy(result)
    await asyncio.sleep(0)
    return result


def _settlement_diagnostic(
    *,
    scope: str,
    league: str,
    game_pk: str,
    status: str,
    reason: str,
    record_id: object = None,
    candidate_id: object = None,
    matchup: object = None,
    game: dict | None = None,
    error: Exception | None = None,
) -> dict:
    payload = {
        "scope": scope,
        "league": str(league or "MLB").upper(),
        "game_pk": str(game_pk or ""),
        "status": status,
        "reason": reason,
    }
    if record_id is not None:
        payload["record_id"] = str(record_id)
    if candidate_id is not None:
        payload["candidate_id"] = str(candidate_id)
    if matchup:
        payload["matchup"] = str(matchup)
    if game:
        payload["official_status"] = game.get("status")
        payload["detailed_status"] = game.get("detailed_status")
        payload["away_score"] = (game.get("away") or {}).get("score")
        payload["home_score"] = (game.get("home") or {}).get("score")
        if game.get("settlement_match"):
            payload["match"] = deepcopy(game.get("settlement_match"))
    if error is not None:
        payload["error_type"] = type(error).__name__
        payload["error"] = str(error)[:300]
        if isinstance(error, AsianBaseballSettlementLookupError):
            payload["lookup_code"] = error.code
            payload["lookup_details"] = deepcopy(error.details)
    return payload


def _unsettled_reason(selection: dict, game: dict | None) -> str:
    if not game:
        return "official_game_missing"
    disposition = settlement_game_disposition(selection, game)
    if disposition == "pending":
        return "official_result_not_final"
    if (game.get("away") or {}).get("score") is None or (game.get("home") or {}).get("score") is None:
        return "official_score_missing"
    market = str(selection.get("market") or (selection.get("pick") or {}).get("market") or "moneyline")
    pick = selection.get("pick") or {}
    if market in {"moneyline", "run_line"} and not any(
        pick.get(key) for key in ("team_id", "team_name", "name", "abbr")
    ):
        return "pick_team_identity_missing"
    if market in {"run_line", "totals"} and pick.get("line") is None:
        return "market_line_missing"
    if market == "totals" and str(pick.get("side") or "").lower() not in {"over", "under"}:
        return "total_side_missing"
    return "selection_identity_or_market_mismatch"


async def _settle_pending_records_with(
    repository: SupabaseRecordsRepository,
    mlb_service: MLBService,
    npb_adapter: NPBService,
    kbo_adapter: AsianBaseballService,
    cpbl_adapter: AsianBaseballService,
    performance: PerformanceRepository | None = None,
    game_cache: dict[tuple[str, str], dict | None] | None = None,
    diagnostics: list[dict] | None = None,
    settled_ids: list[str] | None = None,
) -> int:
    if not repository.enabled:
        return 0
    game_cache = game_cache if game_cache is not None else {}
    records = await repository.list_records(limit=max(settings.records_limit, 100))
    pending = [
        record
        for record in records
        if str(record.get("status") or "pending") in {"pending", "void"}
        or _recent_reconciliation_candidate(record)
    ]
    settled_now = 0
    for record in pending:
        snapshot = record.get("prediction_snapshot") or {}
        league = _selection_league(snapshot if isinstance(snapshot, dict) else record)
        try:
            game = await _settlement_game_result_cached(
                mlb_service, npb_adapter, kbo_adapter, cpbl_adapter,
                league, str(record["game_pk"]), game_cache, record,
            )
        except (KeyError, MLBUpstreamError, NPBUpstreamError, AsianBaseballUpstreamError, TypeError, ValueError) as exc:
            if diagnostics is not None and len(diagnostics) < 200:
                diagnostics.append(_settlement_diagnostic(
                    scope="free", league=league, game_pk=str(record.get("game_pk") or ""),
                    status="skipped", reason="official_lookup_failed", record_id=record.get("id"),
                    matchup=record.get("matchup"), error=exc,
                ))
            continue
        stored_status = str(record.get("status") or "pending")
        disposition = settlement_game_disposition(record, game)
        result = settlement_for(record, game)
        settlement_payload = None
        if result:
            settlement_payload = deepcopy(result)
            stored_snapshot = record.get("prediction_snapshot")
            if isinstance(stored_snapshot, dict):
                snapshot = deepcopy(stored_snapshot)
                publication = deepcopy(snapshot.get("publication") or {})
                snapshot["status"] = "settled"
                snapshot["is_active"] = False
                publication["status"] = "settled"
                publication["is_active"] = False
                publication["settled_at"] = result.get("settled_at")
                snapshot["publication"] = publication
                settlement_payload["prediction_snapshot"] = snapshot
        else:
            stored_snapshot = record.get("prediction_snapshot")
            if isinstance(stored_snapshot, dict):
                start = _selection_start_datetime(stored_snapshot)
                lifecycle = _lifecycle_status(["pending"], [start] if start else [])
                publication = stored_snapshot.get("publication") or {}
                previous = str(stored_snapshot.get("status") or publication.get("status") or "published")
                if lifecycle == "live" and previous != "live":
                    snapshot = deepcopy(stored_snapshot)
                    updated_publication = deepcopy(publication)
                    snapshot["status"] = "live"
                    snapshot["is_active"] = True
                    updated_publication["status"] = "live"
                    updated_publication["is_active"] = True
                    snapshot["publication"] = updated_publication
                    if stored_status == "pending":
                        await repository.update_prediction_snapshot(record["game_pk"], snapshot)

        if result is None and diagnostics is not None and len(diagnostics) < 200:
            diagnostics.append(_settlement_diagnostic(
                scope="free", league=league, game_pk=str(record.get("game_pk") or ""),
                status="pending", reason=_unsettled_reason(record, game),
                record_id=record.get("id"), matchup=record.get("matchup"), game=game,
            ))

        needs_reconciliation = (
            stored_status in {"won", "lost", "push", "void"}
            and not result_status_matches_disposition(stored_status, disposition)
        )
        if needs_reconciliation:
            if settlement_payload is None:
                stored_snapshot = record.get("prediction_snapshot")
                pending_snapshot = deepcopy(stored_snapshot) if isinstance(stored_snapshot, dict) else None
                if pending_snapshot is not None:
                    publication = deepcopy(pending_snapshot.get("publication") or {})
                    start = _selection_start_datetime(pending_snapshot)
                    lifecycle = _lifecycle_status(["pending"], [start] if start else [])
                    pending_snapshot["status"] = lifecycle
                    pending_snapshot["is_active"] = True
                    publication["status"] = lifecycle
                    publication["is_active"] = True
                    publication.pop("settled_at", None)
                    pending_snapshot["publication"] = publication
                settlement_payload = {
                    "status": "pending",
                    "away_score": None,
                    "home_score": None,
                    "result_note": "賽事延期或重新排程，等待官方完成後結算。",
                    "settled_at": None,
                }
                if pending_snapshot is not None:
                    settlement_payload["prediction_snapshot"] = pending_snapshot
            settled_record = await repository.reconcile_prediction(record["id"], settlement_payload)
            if settled_record and performance is not None and record.get("id") is not None:
                try:
                    await performance.reconcile_public(
                        str(record.get("id")),
                        result if result and str(result.get("status")) != "void" else None,
                    )
                except PerformanceStorageError:
                    pass
        elif stored_status == "pending":
            settled_record = await repository.settle(record["game_pk"], settlement_payload) if settlement_payload else None
        else:
            settled_record = None
        if result and settled_record:
            if str(result.get("status")) != "void" or stored_status != "void":
                settled_now += 1
                if settled_ids is not None and record.get("id") is not None:
                    settled_ids.append(f"free:{record.get('id')}:{result.get('status')}")
            if diagnostics is not None and len(diagnostics) < 200:
                diagnostics.append(_settlement_diagnostic(
                    scope="free", league=league, game_pk=str(record.get("game_pk") or ""),
                    status="settled", reason=str(result.get("status") or "settled"),
                    record_id=record.get("id"), matchup=record.get("matchup"), game=game,
                ))
            if performance is not None and stored_status != "void":
                try:
                    await performance.settle_public(str(record.get("id")), result)
                except PerformanceStorageError:
                    pass
    return settled_now


async def _run_settlement_pass(app: FastAPI) -> tuple[int, int, int, dict]:
    """Settle all leagues once, sharing official game lookups and diagnostics."""

    game_cache: dict[tuple[str, str], dict | None] = {}
    diagnostics: list[dict] = []
    settled_ids: list[str] = []
    free_count = await _settle_pending_records_with(
        app.state.records, app.state.mlb, app.state.npb, app.state.kbo,
        app.state.cpbl, app.state.performance, game_cache, diagnostics, settled_ids,
    )
    await asyncio.sleep(0)
    package_count = await _settle_pending_prediction_packages_with(
        app.state.records, app.state.mlb, app.state.npb, app.state.kbo,
        app.state.cpbl, app.state.performance, game_cache, diagnostics, settled_ids,
    )
    if free_count + package_count > 0:
        app.state.records.invalidate_read_cache()
    reason_counts: dict[str, int] = {}
    for item in diagnostics:
        reason = str(item.get("reason") or "unknown")
        reason_counts[reason] = reason_counts.get(reason, 0) + 1
    summary = {
        "settled_ids": sorted(set(settled_ids)),
        "settled_count": free_count + package_count,
        "diagnostic_count": len(diagnostics),
        "reason_counts": reason_counts,
        "fallback_matches": sum(
            1 for item in diagnostics
            if isinstance(item.get("match"), dict)
            and "exact_game_pk" not in str((item.get("match") or {}).get("method") or "")
        ),
        "items": diagnostics,
    }
    return free_count, package_count, len(game_cache), summary


async def settle_pending_records(request: Request) -> int:
    return await _settle_pending_records_with(
        records_repository(request), service(request), npb_service(request), kbo_service(request), cpbl_service(request), performance_repository(request)
    )


def _selection_league(selection: dict) -> str:
    return str(selection.get("league") or (selection.get("game") or {}).get("league") or "MLB").upper()


def _prediction_league(value: str | None) -> str:
    league = str(value or "MLB").upper()
    if league not in {"MLB", "NPB", "KBO", "CPBL"}:
        raise HTTPException(status_code=422, detail="league must be MLB, NPB, KBO or CPBL")
    return league


def _selection_matches_league(selection: dict | None, league: str) -> bool:
    if not isinstance(selection, dict):
        return False
    legs = selection.get("legs")
    if isinstance(legs, list) and legs:
        return all(_selection_league(leg) == league for leg in legs if isinstance(leg, dict))
    return _selection_league(selection) == league


def _filter_results_for_package(results: dict | None, package: dict) -> dict:
    results = results or {}
    filtered: dict[str, list[dict]] = {}
    for group in ("moneylines", "run_lines", "totals"):
        ids = {str(item.get("candidate_id")) for item in package.get(group) or []}
        values = [item for item in results.get(group) or [] if str(item.get("candidate_id")) in ids]
        if values:
            filtered[group] = values
    for group in ("two_leg", "three_leg"):
        ids = {str(item.get("candidate_id")) for item in (package.get("parlays") or {}).get(group) or []}
        values = [item for item in results.get(group) or [] if str(item.get("candidate_id")) in ids]
        if values:
            filtered[group] = values
    return filtered


def _package_for_league(package: dict | None, league: str) -> dict | None:
    if not isinstance(package, dict):
        return None
    result = deepcopy(package)
    for group in ("moneylines", "run_lines", "totals"):
        result[group] = [item for item in package.get(group) or [] if _selection_matches_league(item, league)]
    parlays = package.get("parlays") or {}
    result["parlays"] = {
        group: [item for item in parlays.get(group) or [] if _selection_matches_league(item, league)]
        for group in ("two_leg", "three_leg")
    }
    watchlist = package.get("watchlist") or {}
    result["watchlist"] = {
        group: [item for item in watchlist.get(group) or [] if _selection_matches_league(item, league)]
        for group in ("moneylines", "run_lines", "totals")
    }
    public = package.get("moneyline")
    result["moneyline"] = public if _selection_matches_league(public, league) else None
    result["run_line"] = (result["run_lines"] or [None])[0]
    result["total"] = (result["totals"] or [None])[0]
    result["results"] = _filter_results_for_package(package.get("results") or {}, result)
    result["selected_league"] = league
    return result


def _package_has_league(package: dict | None, league: str) -> bool:
    filtered = _package_for_league(package, league)
    if not filtered:
        return False
    return any(filtered.get(group) for group in ("moneylines", "run_lines", "totals")) or any(
        (filtered.get("parlays") or {}).get(group) for group in ("two_leg", "three_leg")
    )


def _package_game_ids(package: dict | None, league: str) -> list[str]:
    """Return the immutable game references contained in one league batch."""

    filtered = _package_for_league(package, league) or {}
    game_ids: set[str] = set()
    for group in ("moneylines", "run_lines", "totals"):
        for selection in filtered.get(group) or []:
            game_pk = selection.get("game_pk")
            if game_pk is not None:
                game_ids.add(str(game_pk))
    for group in ("two_leg", "three_leg"):
        for parlay in (filtered.get("parlays") or {}).get(group) or []:
            for leg in parlay.get("legs") or []:
                game_pk = leg.get("game_pk")
                if game_pk is not None:
                    game_ids.add(str(game_pk))
    return sorted(game_ids)


def _selection_analysis_mode(selection: dict | None) -> str:
    if not isinstance(selection, dict):
        return "unavailable"
    if is_real_odds_selection(selection):
        return "real_odds"
    if is_model_only_asian_moneyline(selection):
        return "model_only"
    return "unavailable"


def _package_analysis_mode(package: dict | None, league: str) -> str:
    filtered = _package_for_league(package, league) or {}
    selections = [
        item
        for group in ("moneylines", "run_lines", "totals")
        for item in filtered.get(group) or []
        if isinstance(item, dict)
    ]
    real_odds = any(is_real_odds_selection(item) for item in selections)
    model_only = any(is_model_only_asian_moneyline(item, league) for item in selections)
    if real_odds and model_only:
        return "mixed"
    if real_odds:
        return "real_odds"
    if model_only:
        return "model_only"
    return "unavailable"


def _analysis_mode_metadata(mode: str) -> dict[str, object]:
    normalized = str(mode or "unavailable")
    return {
        "analysis_mode": normalized,
        "odds_analysis_included": normalized in {"real_odds", "mixed"},
        "model_only_fallback_included": normalized in {"model_only", "mixed"},
    }


def _asian_pro_package_errors(package: dict, league: str) -> list[str]:
    """Defense-in-depth validation before Asian baseball Pro persistence.

    NPB/KBO may contain model-only moneyline singles. Everything else must
    carry a verified real bookmaker line.
    """

    errors: list[str] = []
    for group in ("moneylines", "run_lines", "totals"):
        for selection in package.get(group) or []:
            if isinstance(selection, dict) and not is_asian_baseball_pro_selection(selection, league):
                errors.append(f"{group}:{selection.get('candidate_id') or selection.get('game_pk') or 'unknown'}")
    for group in ("two_leg", "three_leg"):
        for selection in (package.get("parlays") or {}).get(group) or []:
            if isinstance(selection, dict) and not is_asian_baseball_pro_selection(selection, league):
                errors.append(f"{group}:{selection.get('candidate_id') or 'unknown'}")
    return errors


def _npb_pro_package_errors(package: dict) -> list[str]:
    return _asian_pro_package_errors(package, "NPB")


def _stamp_free_selection(
    selection: dict,
    *,
    league: str,
    target_date: date,
    published_at: str,
    mode: str,
    automatic: bool,
    publication_extra: dict | None = None,
) -> dict:
    """Build one immutable public-channel snapshot.

    Free and Pro data intentionally use different persistence paths. This
    helper also makes the access contract explicit inside every new snapshot,
    so later API refactors cannot accidentally treat a Pro market as a public
    pick.
    """

    market = str(
        ((selection.get("pick") or {}).get("market"))
        or selection.get("market")
        or "moneyline"
    ).lower()
    if market != "moneyline":
        raise ValueError("Free publication channel only accepts moneyline selections")
    target = target_date.isoformat()
    publication = {
        **(selection.get("publication") or {}),
        "mode": mode,
        "automatic": bool(automatic),
        "channel": "free",
        "access_level": "free",
        "visibility": "public",
        "league": league,
        "target_date": target,
        "published_at": published_at,
        "status": "published",
        "is_active": True,
        "game_id": selection.get("game_pk"),
        "recommendation_type": "free_pick",
        **(publication_extra or {}),
    }
    return {
        **selection,
        "league": league,
        "target_date": target,
        "published_at": published_at,
        "status": "published",
        "is_active": True,
        "game_id": selection.get("game_pk"),
        "recommendation_type": "free_pick",
        "access_level": "free",
        "visibility": "public",
        "publication": publication,
    }


def _stamp_published_package(
    package: dict,
    *,
    league: str,
    target_date: date,
    published_at: str,
) -> dict:
    """Stamp a founder-approved batch with its real publication identity.

    The database still stores one package row per target date for backwards
    compatibility, while ``league_batches`` preserves MLB and NPB as two
    independent releases.  There is deliberately no draft state: a batch is
    added only after the founder presses the formal publish button.
    """

    stamped = deepcopy(package)
    target = target_date.isoformat()
    common = {
        "target_date": target,
        "published_at": published_at,
        "status": "published",
        "is_active": True,
        "recommendation_type": "pro",
        "channel": "pro",
        "access_level": "pro",
        "visibility": "members_only",
    }
    for group in ("moneylines", "run_lines", "totals"):
        stamped[group] = [
            {
                **selection,
                **common,
                "league": _selection_league(selection),
                "game_id": selection.get("game_pk"),
            }
            for selection in stamped.get(group) or []
            if isinstance(selection, dict)
        ]
    parlays = stamped.get("parlays") or {}
    for group in ("two_leg", "three_leg"):
        values: list[dict] = []
        for selection in parlays.get(group) or []:
            if not isinstance(selection, dict):
                continue
            game_ids = [
                str(leg.get("game_pk"))
                for leg in selection.get("legs") or []
                if isinstance(leg, dict) and leg.get("game_pk") is not None
            ]
            values.append({**selection, **common, "league": league, "game_ids": game_ids})
        parlays[group] = values
    stamped["parlays"] = parlays
    stamped["generated_at"] = published_at
    analysis_mode = _package_analysis_mode(stamped, league)
    publication = deepcopy(stamped.get("publication") or {})
    batches = deepcopy(publication.get("league_batches") or {})
    batches[league] = {
        "league": league,
        **common,
        **_analysis_mode_metadata(analysis_mode),
        "game_ids": _package_game_ids(stamped, league),
    }
    publication.update(
        {
            "league": league,
            "target_date": target,
            "published_at": published_at,
            "status": "published",
            "is_active": True,
            "recommendation_type": "pro",
            "channel": "pro",
            "access_level": "pro",
            "visibility": "members_only",
            "league_batches": batches,
            **_analysis_mode_metadata(analysis_mode),
        }
    )
    stamped["publication"] = publication
    return stamped


def _merge_league_package(existing: dict, incoming: dict, league: str) -> dict:
    # Preserve every already-published league batch except the one currently
    # being replaced. This removes the old MLB/NPB-only opposite-league rule
    # and is safe for future KBO, CPBL, NBA and EPL batches.
    merged = deepcopy(incoming)
    for group in ("moneylines", "run_lines", "totals"):
        existing_other = [
            item for item in existing.get(group) or []
            if isinstance(item, dict) and not _selection_matches_league(item, league)
        ]
        merged[group] = [*existing_other, *(incoming.get(group) or [])]
    merged["parlays"] = {
        group: [
            *[
                item for item in ((existing.get("parlays") or {}).get(group) or [])
                if isinstance(item, dict) and not _selection_matches_league(item, league)
            ],
            *((incoming.get("parlays") or {}).get(group) or []),
        ]
        for group in ("two_leg", "three_leg")
    }
    merged["watchlist"] = {
        group: [
            *[
                item for item in ((existing.get("watchlist") or {}).get(group) or [])
                if isinstance(item, dict) and not _selection_matches_league(item, league)
            ],
            *((incoming.get("watchlist") or {}).get(group) or []),
        ]
        for group in ("moneylines", "run_lines", "totals")
    }
    existing_public = existing.get("moneyline")
    merged["moneyline"] = existing_public or incoming.get("moneyline")
    merged["run_line"] = (merged["run_lines"] or [None])[0]
    merged["total"] = (merged["totals"] or [None])[0]
    publication = {**(existing.get("publication") or {}), **(incoming.get("publication") or {})}
    publication["league_batches"] = {
        **((existing.get("publication") or {}).get("league_batches") or {}),
        **((incoming.get("publication") or {}).get("league_batches") or {}),
    }
    locks = {**((existing.get("publication") or {}).get("league_locks") or {})}
    locks[league] = True
    publication["league_locks"] = locks
    publication["last_published_league"] = league
    publication["selected_counts"] = {
        "moneylines": len(merged["moneylines"]),
        "run_lines": len(merged["run_lines"]),
        "totals": len(merged["totals"]),
        "two_leg": len(merged["parlays"]["two_leg"]),
        "three_leg": len(merged["parlays"]["three_leg"]),
    }
    merged["publication"] = publication
    merged["published"] = True
    merged["locked"] = True
    merged["recommendation_status"] = "formal_published"
    merged["results"] = existing.get("results") or {}
    return merged


def _package_game_refs(record: dict) -> set[tuple[str, str]]:
    refs: set[tuple[str, str]] = set()
    package = package_from_record(record)
    for key in ("moneylines", "run_lines", "totals"):
        for selection in package.get(key) or []:
            game_pk = selection.get("game_pk")
            if game_pk is not None:
                refs.add((_selection_league(selection), str(game_pk)))
    for key in ("two_leg", "three_leg"):
        for parlay in (package.get("parlays") or {}).get(key) or []:
            for leg in parlay.get("legs") or []:
                game_pk = leg.get("game_pk")
                if game_pk is not None:
                    refs.add((_selection_league(leg), str(game_pk)))
    return refs


def _package_game_contexts(record: dict) -> dict[tuple[str, str], dict]:
    contexts: dict[tuple[str, str], dict] = {}
    package = package_from_record(record)
    for key in ("moneylines", "run_lines", "totals"):
        for selection in package.get(key) or []:
            game_pk = selection.get("game_pk")
            if game_pk is not None:
                contexts.setdefault((_selection_league(selection), str(game_pk)), selection)
    for key in ("two_leg", "three_leg"):
        for parlay in (package.get("parlays") or {}).get(key) or []:
            for leg in parlay.get("legs") or []:
                game_pk = leg.get("game_pk")
                if game_pk is not None:
                    contexts.setdefault((_selection_league(leg), str(game_pk)), leg)
    return contexts


async def _game_result_for_ref(
    mlb_service: MLBService,
    npb_adapter: NPBService,
    kbo_adapter: AsianBaseballService,
    cpbl_adapter: AsianBaseballService,
    league: str,
    game_pk: str,
    selection: dict | None = None,
) -> dict:
    if league == "NPB":
        return await npb_adapter.game_result(game_pk)
    if league == "KBO":
        return await kbo_adapter.game_result(game_pk, selection)
    if league == "CPBL":
        return await cpbl_adapter.game_result(game_pk, selection)
    if league == "MLB":
        return await mlb_service.game_result(int(game_pk))
    raise ValueError(f"Settlement adapter is not enabled for {league}")


def _package_settlement_payload(record: dict, result: dict) -> dict:
    """Persist Published -> Live -> Settled metadata beside result details."""

    payload = deepcopy(result)
    if result.get("settled") is not True:
        payload["settled_at"] = None
    resolved_settled_at = result.get("settled_at") if "settled_at" in result else record.get("settled_at")
    resolved_results = result.get("results") if "results" in result else record.get("results") or {}
    updated_record = {
        **record,
        "results": resolved_results,
        "settled": bool(result.get("settled")),
        "settled_at": resolved_settled_at,
    }
    package = package_from_record(updated_record)
    thresholds = deepcopy(record.get("thresholds") or {})
    publication = deepcopy(thresholds.get("publication") or {})
    batches = deepcopy(publication.get("league_batches") or {})
    for league in LEAGUES:
        metadata = _package_publication_metadata(package, league)
        if metadata is None:
            continue
        batches[league] = {
            **(batches.get(league) or {}),
            **metadata,
        }
    if batches:
        statuses = [str(item.get("status") or "published") for item in batches.values() if isinstance(item, dict)]
        overall_status = (
            "settled"
            if statuses and all(status == "settled" for status in statuses)
            else "live"
            if any(status == "live" for status in statuses)
            else "published"
        )
        publication["league_batches"] = batches
        publication["status"] = overall_status
        publication["is_active"] = overall_status != "settled"
        if overall_status == "settled":
            publication["settled_at"] = result.get("settled_at") or iso_utc()
        else:
            publication.pop("settled_at", None)
        thresholds["publication"] = publication
        payload["thresholds"] = thresholds
    return payload


def _contains_void_result(value: object) -> bool:
    if isinstance(value, dict):
        if str(value.get("status") or "") == "void":
            return True
        return any(_contains_void_result(item) for item in value.values())
    if isinstance(value, list):
        return any(_contains_void_result(item) for item in value)
    return False


def _recent_reconciliation_candidate(record: dict, lookback_days: int = 3) -> bool:
    """Recheck recent terminal rows so old false losses can self-heal."""

    try:
        target = date.fromisoformat(str(record.get("recommendation_date") or ""))
    except ValueError:
        return False
    return target >= datetime.now(TAIPEI).date() - timedelta(days=max(1, lookback_days))


async def _settle_pending_prediction_packages_with(
    repository: SupabaseRecordsRepository,
    mlb_service: MLBService,
    npb_adapter: NPBService,
    kbo_adapter: AsianBaseballService,
    cpbl_adapter: AsianBaseballService,
    performance: PerformanceRepository | None = None,
    game_cache: dict[tuple[str, str], dict | None] | None = None,
    diagnostics: list[dict] | None = None,
    settled_ids: list[str] | None = None,
) -> int:
    if not repository.enabled:
        return 0
    game_cache = game_cache if game_cache is not None else {}
    packages = await repository.list_prediction_packages(limit=max(settings.records_limit, 100))
    pending = [
        record
        for record in packages
        if record.get("settled") is not True
        or _contains_void_result(record.get("results") or {})
        or _recent_reconciliation_candidate(record)
    ]
    settled_now = 0
    for record in pending:
        package = package_from_record(record)
        games: dict[str, dict] = {}
        contexts = _package_game_contexts(record)
        for (league, game_pk), selection in contexts.items():
            try:
                games[game_pk] = await _settlement_game_result_cached(
                    mlb_service, npb_adapter, kbo_adapter, cpbl_adapter,
                    league, game_pk, game_cache, selection,
                )
            except (KeyError, MLBUpstreamError, NPBUpstreamError, AsianBaseballUpstreamError, TypeError, ValueError) as exc:
                if diagnostics is not None and len(diagnostics) < 200:
                    diagnostics.append(_settlement_diagnostic(
                        scope="pro", league=league, game_pk=game_pk, status="skipped",
                        reason="official_lookup_failed", record_id=record.get("id"),
                        candidate_id=selection.get("candidate_id"), matchup=selection.get("matchup"), error=exc,
                    ))
                continue
        reconciled_record, reopened_candidate_ids = reopen_rescheduled_package_results(record, games)
        if record.get("settled") is True and not reopened_candidate_ids:
            continue
        if diagnostics is not None:
            for (league, game_pk), selection in contexts.items():
                game = games.get(game_pk)
                selection_result = settle_market_selection(selection, game)
                if selection_result is None and len(diagnostics) < 200:
                    diagnostics.append(_settlement_diagnostic(
                        scope="pro", league=league, game_pk=game_pk, status="pending",
                        reason=_unsettled_reason(selection, game), record_id=record.get("id"),
                        candidate_id=selection.get("candidate_id"), matchup=selection.get("matchup"), game=game,
                    ))
        result = settle_prediction_package(reconciled_record, games)
        settlement_payload = _package_settlement_payload(record, result) if result else None
        if settlement_payload and reopened_candidate_ids:
            settled_package = await repository.reconcile_prediction_package(str(record["id"]), settlement_payload)
        else:
            settled_package = await repository.settle_prediction_package(str(record["id"]), settlement_payload) if settlement_payload else None
        if result and settled_package and result.get("settled") is True:
            settled_now += 1
            if settled_ids is not None and record.get("id") is not None:
                settled_ids.append(f"pro:{record.get('id')}:settled")
            if diagnostics is not None and len(diagnostics) < 200:
                diagnostics.append({
                    "scope": "pro", "record_id": str(record.get("id")),
                    "status": "settled", "reason": "package_settled",
                })
        if result and settled_package and performance is not None:
            try:
                # Results are persisted incrementally: one postponed game must
                # not leave every other completed selection in this package as
                # a pending model snapshot.  settle_package is idempotent and
                # only advances snapshots that are still pending.
                await performance.settle_package(str(record.get("id")), result)
                if reopened_candidate_ids:
                    await performance.reconcile_package(
                        str(record.get("id")),
                        reopened_candidate_ids,
                        result,
                    )
            except PerformanceStorageError:
                pass
    return settled_now


async def settle_pending_prediction_packages(request: Request) -> int:
    return await _settle_pending_prediction_packages_with(
        records_repository(request), service(request), npb_service(request), kbo_service(request), cpbl_service(request), performance_repository(request)
    )


async def _game_results_for_refs(
    mlb_service: MLBService,
    npb_adapter: NPBService,
    kbo_adapter: AsianBaseballService,
    cpbl_adapter: AsianBaseballService,
    refs: set[tuple[str, str]],
) -> tuple[dict[str, dict], list[dict]]:
    games: dict[str, dict] = {}
    errors: list[dict] = []
    for league, game_pk in sorted(refs):
        try:
            games[game_pk] = await _game_result_for_ref(mlb_service, npb_adapter, kbo_adapter, cpbl_adapter, league, game_pk)
        except (KeyError, MLBUpstreamError, NPBUpstreamError, AsianBaseballUpstreamError, TypeError, ValueError) as exc:
            errors.append({"league": league, "game_pk": game_pk, "error": type(exc).__name__})
    return games, errors


async def settlement_dashboard(
    repository: SupabaseRecordsRepository,
    mlb_service: MLBService,
    npb_adapter: NPBService,
    kbo_adapter: AsianBaseballService,
    cpbl_adapter: AsianBaseballService,
    target_date: date,
) -> dict:
    if not repository.enabled:
        return {
            "date": target_date.isoformat(),
            "database": "not_configured",
            "public": None,
            "public_items": [],
            "package": None,
            "summary": {"total": 0, "pending": 0, "settled": 0, "won": 0, "lost": 0, "push": 0, "void": 0},
            "errors": [],
        }
    public_records = await repository.list_records_for_date(target_date.isoformat())
    package_record = await repository.get_prediction_package_for_date(target_date.isoformat())
    refs: set[tuple[str, str]] = set()
    for public_record in public_records:
        if public_record.get("game_pk") is None:
            continue
        snapshot = public_record.get("prediction_snapshot") or {}
        league = str(
            public_record.get("league")
            or (_selection_league(snapshot) if isinstance(snapshot, dict) else "MLB")
        ).upper()
        refs.add((league if league in {"MLB", "NPB", "KBO", "CPBL"} else "MLB", str(public_record.get("game_pk"))))
    if package_record:
        refs.update(_package_game_refs(package_record))
    games, errors = await _game_results_for_refs(mlb_service, npb_adapter, kbo_adapter, cpbl_adapter, refs)
    public_previews = [
        preview
        for public_record in public_records
        if (
            preview := preview_public_record(
                public_record,
                games.get(str(public_record.get("game_pk"))) if public_record.get("game_pk") is not None else None,
            )
        ) is not None
    ]
    package_preview = preview_prediction_package(package_record, games)
    statuses: list[str] = []
    statuses.extend(
        str((public_preview.get("preview") or {}).get("status") or "pending")
        for public_preview in public_previews
    )
    if package_preview:
        for values in (package_preview.get("groups") or {}).values():
            statuses.extend(str(item.get("status") or "pending") for item in values)
    summary = {
        "total": len(statuses),
        "pending": statuses.count("pending"),
        "won": statuses.count("won"),
        "lost": statuses.count("lost"),
        "push": statuses.count("push"),
        "void": statuses.count("void"),
    }
    summary["settled"] = summary["total"] - summary["pending"]
    return {
        "date": target_date.isoformat(),
        "database": "connected",
        # Keep the singular alias for older front ends; current clients render
        # both league-specific free recommendations from public_items.
        "public": public_previews[0] if public_previews else None,
        "public_items": public_previews,
        "package": package_preview,
        "summary": summary,
        "games": games,
        "errors": errors,
        "updated_at": iso_utc(),
    }


async def locked_or_generated_market_package(
    request: Request,
    target_date: date,
    public_prediction: dict,
    odds_feed: dict,
    *,
    persist: bool = True,
) -> dict:
    repository = records_repository(request)
    if repository.enabled:
        try:
            existing = await repository.get_prediction_package_for_date(target_date.isoformat())
            if existing:
                existing_package = package_from_record(existing)
                try:
                    await performance_repository(request).capture_package(target_date.isoformat(), str(existing.get("id")), existing_package)
                except PerformanceStorageError:
                    pass
                return existing_package
        except RecordsStorageError:
            existing = None

    analyses = await service(request).matchup_analyses(target_date, pitcher_limit=None)
    eligible_analyses = [
        item
        for item in analyses["items"]
        if (item.get("game") or {}).get("auto_recommendation_eligible") is True
        and publication_policy(item, automatic=False)["can_publish"]
        and (((item.get("analysis_groups") or {}).get("starter") or {}).get("both_starters_ready") is True)
    ]
    bundle = build_daily_market_candidates(
        target_date.isoformat(),
        eligible_analyses,
        odds_feed.get("items") or [],
        public_prediction.get("selection") if public_prediction.get("published") else None,
        minimum_probability=settings.min_market_probability,
        minimum_edge=settings.min_market_edge,
        minimum_projection_quality=settings.min_projection_quality,
        minimum_parlay_probability=settings.min_parlay_leg_probability,
    )
    npb_feed = {"items": [], "meta": {"fresh_for_model": False, "status": "unavailable"}}
    if odds_service(request).enabled:
        try:
            fetched_npb_feed = await odds_service(request).odds_for_date(
                target_date,
                sport_key=settings.npb_odds_sport_key,
            )
            npb_feed = fetched_npb_feed
        except OddsUpstreamError:
            pass
    npb_candidates = await npb_market_candidates_for_date(
        request,
        target_date,
        (npb_feed.get("items") or [])
        if (npb_feed.get("meta") or {}).get("fresh_for_model")
        else [],
        pro_only=True,
    )
    bundle = merge_market_candidates(
        bundle,
        npb_candidates,
        minimum_parlay_probability=settings.min_parlay_leg_probability,
    )
    bundle.setdefault("odds_feeds", {})["NPB"] = {
        "sport_key": settings.npb_odds_sport_key,
        "count": int(npb_feed.get("count") or 0),
        "fresh_for_model": bool((npb_feed.get("meta") or {}).get("fresh_for_model")),
        "cache": (npb_feed.get("meta") or {}).get("cache"),
    }
    bundle = calibrate_bundle(request, bundle)
    package = build_selected_market_package(bundle, publication_mode="ai_auto")
    package["persistence"] = {"enabled": repository.enabled, "stored": False}
    if package["published"] and repository.enabled and persist:
        try:
            stored, created = await repository.publish_prediction_package_once(
                target_date.isoformat(), package
            )
            locked = package_from_record(stored)
            locked["persistence"] = {
                "enabled": True,
                "stored": True,
                "created": created,
                "record_id": stored.get("id"),
            }
            try:
                await performance_repository(request).capture_package(target_date.isoformat(), str(stored.get("id")), package)
            except PerformanceStorageError:
                locked["persistence"]["snapshot_message"] = "模型快照資料表暫時無法寫入。"
            return locked
        except RecordsStorageError:
            package["persistence"]["message"] = "會員玩法已產生，但資料表尚未完成設定或暫時無法寫入。"
    elif package["published"] and not persist:
        package["persistence"] = {
            "enabled": repository.enabled,
            "stored": False,
            "mode": "founder_approval_required",
        }
        package["message"] = "候選已產生，等待創辦人正式發布；排程不會自動建立 Pro 紀錄。"
    return package


@app.get("/healthz", include_in_schema=False)
def platform_healthz() -> dict:
    """Render health check: intentionally no external I/O and no heavy state."""
    return {"ok": True, "service": settings.app_name, "version": APP_VERSION}


@app.get(f"{settings.api_prefix}/ready", include_in_schema=False)
def readiness() -> dict:
    workers = getattr(app.state, "worker_registry", None)
    snapshot = workers.snapshot() if workers else {}
    failed = [name for name, item in snapshot.items() if item.get("state") == "restarting"]
    return {
        "ok": not failed,
        "service": settings.app_name,
        "version": APP_VERSION,
        "process_role": getattr(app.state, "process_role", _normalized_process_role()),
        "started_at": getattr(app.state, "started_at", None),
        "workers": snapshot,
        "degraded_workers": failed,
    }


@app.get("/")
async def root() -> dict:
    return {
        "name": settings.app_name,
        "version": APP_VERSION,
        "status": "online",
        "sports_schema_version": SPORTS_SCHEMA_VERSION,
        "docs": "/docs",
        "health": f"{settings.api_prefix}/health",
    }


@app.get(f"{settings.api_prefix}/health")
async def health() -> dict:
    return {
        "ok": True,
        "service": settings.app_name,
        "version": APP_VERSION,
        "environment": settings.app_env,
        "process_role": getattr(app.state, "process_role", _normalized_process_role()),
        "records_database": "configured" if settings.records_enabled else "not_configured",
        "odds_feed": "configured" if settings.odds_enabled else "not_configured",
        "daily_scheduler": "configured" if settings.scheduler_enabled else "not_configured",
        "pregame_refresh": str((getattr(app.state, "pregame_status", {}) or {}).get("status") or "starting"),
        "settlement_monitor": "running" if (getattr(app.state, "settlement_status", {}) or {}).get("running") else "idle",
        "settlement_mode": "background_only",
        "settlement_cooldown_seconds": settings.settlement_min_interval_seconds,
        "settlement_scheduler": str((getattr(app.state, "settlement_status", {}) or {}).get("scheduler") or ("internal_fallback" if settings.settlement_internal_scheduler_enabled else "external_only")),
        "settlement_scheduler_interval_seconds": settings.settlement_internal_interval_seconds,
        "settlement_scheduler_last_check": (getattr(app.state, "settlement_status", {}) or {}).get("scheduler_last_check"),
        "settlement_last_run": (getattr(app.state, "settlement_status", {}) or {}).get("last_run"),
        "settlement_last_error": (getattr(app.state, "settlement_status", {}) or {}).get("last_error"),
        "publishing_worker": str((getattr(app.state, "publishing_status", {}) or {}).get("state") or "starting"),
        "publishing_mode": "background_only",
        "publishing_last_run": (getattr(app.state, "publishing_status", {}) or {}).get("last_run"),
        "publishing_last_error": (getattr(app.state, "publishing_status", {}) or {}).get("last_error"),
        "read_api_cache": app.state.records.cache_status() if getattr(app.state, "records", None) else {},
        "background_work_busy": bool(getattr(app.state, "background_work_lock", None) and app.state.background_work_lock.locked()),
        "workers": getattr(app.state, "worker_registry", None).snapshot() if getattr(app.state, "worker_registry", None) else {},
        "retry_queue": {
            key: value
            for key, value in dict(
                getattr(app.state, "retry_queue_status", {}) or {}
            ).items()
            if key != "items"
        },
        "operations_monitor": getattr(app.state, "operations_monitor_status", {}).get("status", "starting"),
        "billing": "configured" if settings.billing_enabled else "not_configured",
        "billing_mode": settings.ecpay_mode if settings.billing_enabled else None,
        "announcements": "configured" if settings.records_enabled else "not_configured",
        "model_performance": "configured" if settings.records_enabled else "not_configured",
        "model_calibration": {
            "enabled": bool(settings.model_calibration_enabled),
            "status": str((getattr(app.state, "calibration_status", {}) or {}).get("status") or "starting"),
            "schema": str((getattr(app.state, "calibration_status", {}) or {}).get("schema") or "unknown"),
            "running": bool((getattr(app.state, "calibration_status", {}) or {}).get("running")),
            "last_run": (getattr(app.state, "calibration_status", {}) or {}).get("last_run"),
            "last_error": (getattr(app.state, "calibration_status", {}) or {}).get("last_error"),
            "profiles_loaded": int((getattr(app.state, "calibration_status", {}) or {}).get("profiles_loaded") or 0),
            "interval_seconds": settings.model_calibration_interval_seconds,
            "policy": "chronological_validation_with_champion_challenger",
            "mode": "test_candidates_only",
            "auto_promote": False,
            "founder_confirmation_required": True,
        },
        "new_member_trial": "enabled" if settings.new_member_trial_enabled else "disabled",
        "new_member_trial_hours": settings.new_member_trial_hours if settings.new_member_trial_enabled else 0,
        "npb_auto_publish": "enabled" if settings.npb_auto_publish_enabled else "disabled",
        "npb_pro_auto_publish": "enabled" if settings.npb_pro_auto_publish_enabled else "disabled",
        "npb_odds_refresh_lead_minutes": settings.npb_odds_refresh_lead_minutes,
        "npb_auto_publish_lead_minutes": settings.npb_auto_publish_lead_minutes,
        "npb_auto_publish_scheduler_grace_minutes": settings.npb_auto_publish_scheduler_grace_minutes,
        "kbo_auto_publish": "enabled" if settings.kbo_auto_publish_enabled else "disabled",
        "kbo_pro_auto_publish": "enabled" if settings.kbo_pro_auto_publish_enabled else "disabled",
        "kbo_odds_refresh_lead_minutes": settings.kbo_odds_refresh_lead_minutes,
        "kbo_auto_publish_lead_minutes": settings.kbo_auto_publish_lead_minutes,
        "cpbl_auto_publish": "enabled" if settings.cpbl_auto_publish_enabled else "disabled",
        "cpbl_pro_auto_publish": "enabled" if settings.cpbl_pro_auto_publish_enabled else "disabled",
        "cpbl_odds_refresh_lead_minutes": settings.cpbl_odds_refresh_lead_minutes,
        "cpbl_auto_publish_lead_minutes": settings.cpbl_auto_publish_lead_minutes,
        "mlb_auto_publish": "disabled",
        "instagram_auto_publish": "enabled" if getattr(app.state, "social", None) and app.state.social.enabled else "awaiting_configuration" if settings.instagram_auto_publish_enabled else "disabled",
        "instagram_graph_version": settings.instagram_graph_version,
        "line_messaging": "enabled" if getattr(app.state, "line", None) and app.state.line.enabled else "awaiting_configuration" if settings.line_messaging_enabled_raw else "disabled",
        "line_runtime": {
            key: value for key, value in dict(getattr(app.state, "line_status", {}) or {}).items()
            if key not in {"events"}
        },
        "sports_schema_version": SPORTS_SCHEMA_VERSION,
        "sports": {code: item["status"] for code, item in ((value["code"], value) for value in registered_sports_catalog())},
        "leagues": {code: LEAGUES[code]["status"] for code in LEAGUES},
        "active_leagues": list(ACTIVE_LEAGUES),
        "time_taiwan": datetime.now(TAIPEI).isoformat(),
    }


@app.get(f"{settings.api_prefix}/model/status")
async def public_model_status(request: Request) -> dict:
    registry = calibration_registry(request)
    status = dict(getattr(request.app.state, "calibration_status", {}) or {})
    scopes = [
        {
            "league": league,
            "market": market,
            "version": profile.get("version"),
            "sample": profile.get("sample"),
            "activated_at": profile.get("activated_at"),
        }
        for (league, market), profile in sorted(registry.profiles.items())
    ]
    return {
        "ok": True,
        "model_version": APP_VERSION,
        "calibration_enabled": bool(settings.model_calibration_enabled),
        "status": status.get("status") or "starting",
        "schema": status.get("schema") or "unknown",
        "last_run": status.get("last_run"),
        "profiles_loaded": len(registry.profiles),
        "active_scopes": scopes,
        "policy": {
            "method": "regularized_platt_scaling",
            "validation": "chronological_holdout",
            "hierarchy": ["league_market", "league", "global_market", "global_identity"],
            "auto_promote": False,
            "new_models_start_in_test": True,
            "founder_confirmation_required": True,
            "minimum_sample": settings.model_calibration_minimum_sample,
        },
        "note": "校準改善機率可信度與選場門檻，不保證固定命中率。",
        "updated_at": iso_utc(),
    }


@app.get(f"{settings.api_prefix}/system/data-quality")
async def system_data_quality(
    request: Request,
    league: str = Query(default="MLB", pattern="^(MLB|NPB|KBO|CPBL)$"),
    game_date: date | None = Query(default=None, alias="date"),
) -> dict:
    target_date = requested_date(game_date)
    code = _prediction_league(league)
    try:
        payload = await baseball_service(request, code).games_for_date(target_date)
    except (MLBUpstreamError, NPBUpstreamError, AsianBaseballUpstreamError) as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    report = audit_games(payload.get("items") or [], league=code, expected_date=target_date)
    report["source_meta"] = payload.get("meta") or {}
    report["updated_at"] = iso_utc()
    return report


class AutoCalibrationCommand(BaseModel):
    promote: bool = False
    force: bool = False
    confirm: bool = False


@app.get(f"{settings.api_prefix}/admin/model/v21/performance")
async def admin_model_v21_performance(
    request: Request,
    range_value: str = Query(default="365", alias="range", pattern="^(30|90|180|365|all)$"),
    league: str = Query(default="all", pattern="^(all|MLB|NPB|KBO|CPBL)$"),
    market: str = Query(default="all", pattern="^(all|moneyline|run_line|totals)$"),
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    await admin_member(request, authorization)
    try:
        days = None if range_value == "all" else int(range_value)
        dashboard = await performance_repository(request).performance_v21_dashboard(
            days=days, league=league, market=market
        )
        dashboard["calibration_status"] = dict(getattr(request.app.state, "calibration_status", {}) or {})
        return dashboard
    except PerformanceStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


@app.get(f"{settings.api_prefix}/admin/model/v21/calibration/profiles")
async def admin_model_v21_calibration_profiles(
    request: Request,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    await admin_member(request, authorization)
    try:
        rows = await performance_repository(request).list_calibration_profiles(active_only=False)
        return {
            "ok": True,
            "count": len(rows),
            "active_count": sum(str(row.get("status")) == "active" for row in rows),
            "items": rows,
            "status": dict(getattr(request.app.state, "calibration_status", {}) or {}),
        }
    except PerformanceStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


@app.post(f"{settings.api_prefix}/admin/model/v21/calibration/run")
async def admin_model_v21_calibration_run(
    request: Request,
    command: AutoCalibrationCommand,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    actor = await admin_member(request, authorization)
    if command.promote and not command.confirm:
        raise HTTPException(
            status_code=409,
            detail="Challenger 升為 Production 前必須由創辦人再次確認。",
        )
    if request.app.state.calibration_lock.locked():
        return {"ok": True, "accepted": False, "already_running": True}
    result = await _run_auto_calibration(
        request.app,
        reason=f"founder:{actor.get('id') or 'admin'}",
        force=bool(command.force),
        promote_override=bool(command.promote),
    )
    if not result.get("ok"):
        raise HTTPException(status_code=503, detail=result.get("error") or "Automatic calibration failed")
    return result


class ModelOptimizationCommand(BaseModel):
    force: bool = False


class ModelChallengerDeployCommand(BaseModel):
    run_id: str = Field(min_length=1, max_length=100)
    league: str = Field(pattern="^(GLOBAL|MLB|NPB|KBO|CPBL)$")
    market: str = Field(pattern="^(all|moneyline|run_line|totals)$")
    confirm: bool = False


class ModelRollbackCommand(BaseModel):
    profile_id: str = Field(min_length=1, max_length=100)
    confirm: bool = False


def _calibration_scope_key(league: Any, market: Any) -> tuple[str, str]:
    return (
        str(league or "GLOBAL").upper(),
        str(market or "all").lower(),
    )


def _calibration_scope_was_promoted(
    run: dict[str, Any],
    league: Any,
    market: Any,
) -> bool:
    scope = _calibration_scope_key(league, market)
    return any(
        _calibration_scope_key(item.get("league"), item.get("market")) == scope
        for item in (run.get("promoted") or [])
        if isinstance(item, dict)
    )


def _calibration_candidate_matches_profile(
    candidate: dict[str, Any],
    profile: dict[str, Any],
) -> bool:
    if _calibration_scope_key(
        candidate.get("league"),
        candidate.get("market"),
    ) != _calibration_scope_key(profile.get("league"), profile.get("market")):
        return False
    try:
        slope_matches = abs(
            float(candidate.get("slope")) - float(profile.get("slope"))
        ) <= 0.00000001
        intercept_matches = abs(
            float(candidate.get("intercept")) - float(profile.get("intercept"))
        ) <= 0.00000001
    except (TypeError, ValueError):
        return False
    samples_match = all(
        int(candidate.get(key) or 0) == int(profile.get(key) or 0)
        for key in ("sample", "train_sample", "validation_sample")
    )
    return slope_matches and intercept_matches and samples_match


def _calibration_candidate_was_deployed(
    run: dict[str, Any],
    candidate: dict[str, Any],
    profiles: list[dict[str, Any]],
) -> bool:
    if _calibration_scope_was_promoted(
        run,
        candidate.get("league"),
        candidate.get("market"),
    ):
        return True
    return any(
        _calibration_candidate_matches_profile(candidate, profile)
        for profile in profiles
        if isinstance(profile, dict)
    )


def _weight_candidate_was_deployed(
    run: dict[str, Any],
    candidate: dict[str, Any],
    active_weight_profile: dict[str, Any] | None,
) -> bool:
    if _calibration_scope_was_promoted(run, "GLOBAL", "weights"):
        return True
    if not active_weight_profile:
        return False
    return normalize_weights(candidate.get("weights")) == normalize_weights(
        active_weight_profile.get("weights")
    )


def _calibration_run_for_lifecycle(
    run: dict[str, Any],
    profiles: list[dict[str, Any]],
    active_weight_profile: dict[str, Any] | None = None,
) -> dict[str, Any]:
    candidates: list[dict[str, Any]] = []
    for item in (run.get("candidates") or []):
        if not isinstance(item, dict):
            continue
        if str(item.get("kind") or "") == "weight_profile":
            deployed = _weight_candidate_was_deployed(
                run,
                item,
                active_weight_profile,
            )
        else:
            deployed = _calibration_candidate_was_deployed(
                run,
                item,
                profiles,
            )
        candidates.append({
            **item,
            "deployed": deployed,
        })
    return {**run, "candidates": candidates}


@app.get(f"{settings.api_prefix}/admin/model/lifecycle")
async def admin_model_lifecycle(
    request: Request,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    """Return Champion, TEST Challengers and immutable version history."""
    await admin_member(request, authorization)
    repository = performance_repository(request)
    try:
        profiles, runs, active_weight_profile = await asyncio.gather(
            repository.list_calibration_profiles(active_only=False),
            repository.list_calibration_runs(limit=20),
            repository.active_profile(),
        )
    except PerformanceStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    completed_runs = [
        _calibration_run_for_lifecycle(run, profiles, active_weight_profile)
        for run in runs
        if str(run.get("status") or "") == "completed"
    ]
    latest_run = next(
        (
            run
            for run in completed_runs
            if any(
                str(item.get("kind") or "") != "weight_profile"
                for item in (run.get("candidates") or [])
                if isinstance(item, dict)
            )
        ),
        None,
    )
    latest_weight_run = next(
        (
            run
            for run in completed_runs
            if any(
                str(item.get("kind") or "") == "weight_profile"
                for item in (run.get("candidates") or [])
                if isinstance(item, dict)
            )
        ),
        None,
    )
    return {
        "ok": True,
        "mode": "production_test",
        "policy": {
            "continuous_optimization": bool(settings.model_calibration_enabled),
            "scheduled_interval_seconds": settings.model_calibration_interval_seconds,
            "new_models_start_in_test": True,
            "automatic_deploy": False,
            "founder_confirmation_required": True,
            "member_ui_unchanged": True,
        },
        "production_profiles": [
            row for row in profiles if str(row.get("status") or "") == "active"
        ],
        "history_profiles": profiles,
        "latest_test_run": latest_run,
        "latest_weight_test_run": latest_weight_run,
        "production_weight_profile": active_weight_profile,
        "test_runs": completed_runs,
        "status": dict(getattr(request.app.state, "calibration_status", {}) or {}),
        "updated_at": iso_utc(),
    }


@app.post(f"{settings.api_prefix}/admin/model/challenger/run")
async def admin_model_challenger_run(
    request: Request,
    command: ModelOptimizationCommand,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    """Generate TEST challengers now; never deploy them automatically."""
    actor = await admin_member(request, authorization)
    if request.app.state.calibration_lock.locked():
        return {"ok": True, "accepted": False, "already_running": True}
    result = await _run_auto_calibration(
        request.app,
        reason=f"founder_test:{actor.get('id') or 'admin'}",
        force=bool(command.force),
        promote_override=False,
    )
    if not result.get("ok"):
        raise HTTPException(
            status_code=503,
            detail=result.get("error") or "Challenger 測試失敗",
        )
    return {
        **result,
        "mode": "test",
        "deployed": False,
        "message": "Challenger 測試已完成；結果只進入 TEST，尚未影響會員端。",
    }


@app.post(f"{settings.api_prefix}/admin/model/challenger/deploy")
async def admin_model_challenger_deploy(
    request: Request,
    command: ModelChallengerDeployCommand,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    """Promote one validated Challenger after explicit founder confirmation."""
    actor = await admin_member(request, authorization)
    if not command.confirm:
        raise HTTPException(
            status_code=409,
            detail="Deploy 前必須由創辦人再次確認。",
        )
    repository = performance_repository(request)
    try:
        run = await repository.get_calibration_run(command.run_id)
        if not run:
            raise HTTPException(status_code=404, detail="找不到指定的 TEST 執行紀錄。")
        candidate = next(
            (
                item
                for item in (run.get("candidates") or [])
                if isinstance(item, dict)
                and str(item.get("league") or "").upper() == command.league
                and str(item.get("market") or "").lower() == command.market
            ),
            None,
        )
        if not candidate:
            raise HTTPException(status_code=404, detail="找不到指定的 Challenger。")
        profiles = await repository.list_calibration_profiles(active_only=False)
        if _calibration_candidate_was_deployed(run, candidate, profiles):
            raise HTTPException(
                status_code=409,
                detail="此 Challenger 已部署到 Production，不能重複部署。",
            )
        if not candidate.get("ready") or not candidate.get("promote"):
            raise HTTPException(
                status_code=409,
                detail="此 Challenger 尚未通過樣本與驗證改善門檻，不能部署到 Production。",
            )
        profile = await repository.activate_calibration_profile(
            candidate=candidate,
            actor_id=str(actor.get("id") or actor.get("email") or "founder"),
            auto_promoted=False,
        )
        await repository.record_calibration_promotion(
            run_id=command.run_id,
            profile=profile,
        )
        registry = await repository.calibration_registry()
    except HTTPException:
        raise
    except PerformanceStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    request.app.state.calibration_registry = registry
    request.app.state.calibration_status = {
        **dict(getattr(request.app.state, "calibration_status", {}) or {}),
        "status": "production_deployed",
        "last_deploy": iso_utc(),
        "profiles_loaded": len(registry.profiles),
        "registry_loaded_at": registry.loaded_at,
        "last_error": None,
        "auto_promote": False,
    }
    return {
        "ok": True,
        "mode": "production",
        "profile": profile,
        "message": "Challenger 已由創辦人確認升為 Production；會員端介面不變。",
    }


@app.post(f"{settings.api_prefix}/admin/model/rollback")
async def admin_model_rollback(
    request: Request,
    command: ModelRollbackCommand,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    """Restore one historical model profile as a new audited production version."""
    actor = await admin_member(request, authorization)
    if not command.confirm:
        raise HTTPException(status_code=409, detail="回滾前必須由創辦人再次確認。")
    repository = performance_repository(request)
    try:
        profile = await repository.restore_calibration_profile(
            profile_id=command.profile_id,
            actor_id=str(actor.get("id") or actor.get("email") or "founder"),
        )
        if not profile:
            raise HTTPException(status_code=404, detail="找不到指定的歷史模型版本。")
        registry = await repository.calibration_registry()
    except HTTPException:
        raise
    except PerformanceStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    request.app.state.calibration_registry = registry
    request.app.state.calibration_status = {
        **dict(getattr(request.app.state, "calibration_status", {}) or {}),
        "status": "production_rollback",
        "last_run": iso_utc(),
        "profiles_loaded": len(registry.profiles),
        "registry_loaded_at": registry.loaded_at,
        "last_error": None,
        "auto_promote": False,
    }
    return {
        "ok": True,
        "mode": "production",
        "profile": profile,
        "message": "模型已回滾並建立新的稽核版本；已發布推薦不會被改寫。",
    }


@app.get(f"{settings.api_prefix}/admin/model/v21/data-quality")
async def admin_model_v21_data_quality(
    request: Request,
    range_value: str = Query(default="90", alias="range", pattern="^(30|90|180|365|all)$"),
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    await admin_member(request, authorization)
    try:
        days = None if range_value == "all" else int(range_value)
        rows = await performance_repository(request).list_snapshots(
            days=days, include_test=False, market="all", source_type="all", limit=5000
        )
        report = audit_snapshots(rows)
        report["range_days"] = days
        report["updated_at"] = iso_utc()
        return report
    except PerformanceStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


class ApiMonitorTestCommand(BaseModel):
    league: str = Field(default="MLB", pattern="^(MLB|NPB|KBO|CPBL)$")
    target_date: date | None = None


def _monitor_safe_error(exc: Exception) -> dict:
    message = re.sub(
        r"((?:apiKey|api_key|key|token)=?)[^&\s]*",
        r"\1***",
        str(exc or ""),
        flags=re.I,
    ).strip()
    return {
        "type": type(exc).__name__,
        "message": (message or "upstream unavailable")[:400],
    }


def _monitor_effective_mlb_status(
    primary_status: dict,
    fallback_status: dict,
) -> dict:
    primary_check = (primary_status.get("last_checks") or {}).get("MLB") or {}
    fallback_check = (fallback_status.get("last_checks") or {}).get("MLB") or {}
    providers = [
        {
            "provider": "The Odds API",
            "configured": bool(primary_status.get("configured")),
            "usable": bool(
                primary_status.get("configured")
                and not primary_check.get("last_error")
                and primary_check.get("fresh_for_model", True)
                and int(primary_check.get("count") or 0) > 0
            ),
            **dict(primary_check),
        },
        {
            "provider": "Odds-API.io",
            "configured": bool(fallback_status.get("configured")),
            "usable": bool(
                fallback_status.get("configured")
                and fallback_check.get("fresh_for_model", True)
                and int(fallback_check.get("count") or 0) > 0
            ),
            **dict(fallback_check),
        },
    ]
    successful = [
        item
        for item in providers
        if item.get("usable")
    ]
    effective = max(
        successful,
        key=lambda item: str(item.get("checked_at") or ""),
        default=None,
    )
    return {
        "available": effective is not None,
        "provider": effective.get("provider") if effective else None,
        "checked_at": effective.get("checked_at") if effective else None,
        "count": int(effective.get("count") or 0) if effective else 0,
        "coverage": dict(effective.get("coverage") or {}) if effective else {},
        "quota": dict(effective.get("quota") or {}) if effective else {},
        "cache": effective.get("cache") if effective else None,
        "providers": providers,
    }


@app.get(f"{settings.api_prefix}/admin/api-monitor")
async def admin_api_monitor(
    request: Request,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    """Founder-only API diagnostics without exposing any secret values."""
    await admin_member(request, authorization)
    odds_status = odds_service(request).status()
    odds_io_status = odds_api_io_service(request).status()
    registry = getattr(request.app.state, "worker_registry", None)
    runtime = (
        registry.snapshot()
        if registry is not None
        else dict(getattr(request.app.state, "worker_supervisor_status", {}) or {})
    )
    metrics = getattr(request.app.state, "request_metrics", None)
    history = list(getattr(request.app.state, "api_monitor_history", []) or [])
    return {
        "version": APP_VERSION,
        "generated_at": iso_utc(),
        "process": {
            "environment": settings.app_env,
            "role": getattr(request.app.state, "process_role", _normalized_process_role()),
            "started_at": getattr(request.app.state, "started_at", None),
            "render": {
                "service_name": settings.render_service_name or None,
                "service_id": settings.render_service_id or None,
                "instance_id": settings.render_instance_id or None,
                "git_commit": settings.render_git_commit or None,
                "available": bool(
                    settings.render_service_name
                    or settings.render_service_id
                    or settings.render_instance_id
                    or settings.render_git_commit
                ),
            },
        },
        "requests": metrics.snapshot() if metrics is not None else {
            "scope": "render_process_local",
            "requests": 0,
            "errors": 0,
            "average_ms": None,
            "p95_ms": None,
            "top_routes": [],
        },
        "services": {
            "records": {"configured": settings.records_enabled},
            "odds_snapshots": dict(
                getattr(request.app.state, "odds_snapshot_status", {}) or {}
            ),
            "the_odds_api": {
                "configured": settings.odds_enabled,
                "provider": "The Odds API",
                "last_checks": odds_status.get("last_checks") or {},
                "markets": odds_status.get("markets") or [],
                "bookmakers_by_league": odds_status.get("bookmakers_by_league") or {},
            },
            "odds_api_io": odds_io_status,
            "mlb_effective": _monitor_effective_mlb_status(
                odds_status,
                odds_io_status,
            ),
        },
        "last_test": history[0] if history else None,
        "test_history": history[:10],
        "workers": runtime,
        "retry_queue": dict(
            getattr(request.app.state, "retry_queue_status", {}) or {}
        ),
    }


@app.post(f"{settings.api_prefix}/admin/api-monitor/test")
async def admin_api_monitor_test(
    request: Request,
    command: ApiMonitorTestCommand,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    """Run one explicit founder API test for a selected baseball league/date."""

    await admin_member(request, authorization)
    started = monotonic()
    league = _prediction_league(command.league)
    target = requested_date(command.target_date)
    schedule_result = {
        "ok": False,
        "count": 0,
        "upcoming": 0,
        "live": 0,
        "final": 0,
    }
    odds_result = {
        "ok": False,
        "count": 0,
        "fresh_for_model": False,
        "provider": None,
        "coverage": {},
    }

    try:
        schedule = await asyncio.wait_for(
            baseball_service(request, league).games_for_date(target),
            timeout=35.0,
        )
        games = [
            item
            for item in schedule.get("items") or []
            if isinstance(item, dict)
        ]
        schedule_result.update({
            "ok": True,
            "count": len(games),
            "upcoming": sum(1 for item in games if item.get("status") == "upcoming"),
            "live": sum(1 for item in games if item.get("status") == "live"),
            "final": sum(1 for item in games if item.get("status") == "final"),
            "cache": (schedule.get("meta") or {}).get("cache"),
            "updated_at": (schedule.get("meta") or {}).get("updated_at"),
        })
    except Exception as exc:
        schedule_result["error"] = _monitor_safe_error(exc)

    try:
        if league == "MLB":
            feed = await asyncio.wait_for(
                mlb_odds_feed_for_date(request, target, priority=True),
                timeout=50.0,
            )
        else:
            feed = await asyncio.wait_for(
                asian_odds_feed_for_date(
                    request,
                    target,
                    league,
                    priority=True,
                ),
                timeout=50.0,
            )
        meta = feed.get("meta") or {}
        odds_result.update({
            "ok": True,
            "count": int(feed.get("count") or 0),
            "fresh_for_model": bool(meta.get("fresh_for_model")),
            "provider": meta.get("provider"),
            "provider_chain": meta.get("provider_chain") or [],
            "fallback_activated": bool(meta.get("fallback_activated")),
            "coverage": meta.get("coverage") or {},
            "coverage_status": meta.get("coverage_status"),
            "cache": meta.get("cache"),
            "quota": meta.get("quota") or {},
            "persistent_snapshot": bool(meta.get("persistent_snapshot")),
            "snapshot_captured_at": meta.get("snapshot_captured_at"),
            "snapshot_age_minutes": meta.get("snapshot_age_minutes"),
            "availability_reason": meta.get("availability_reason"),
            "provider_skips": meta.get("provider_skips") or [],
        })
    except Exception as exc:
        odds_result["error"] = _monitor_safe_error(exc)

    payload = {
        "ok": bool(schedule_result["ok"] and odds_result["ok"]),
        "ready": bool(
            schedule_result["ok"]
            and int(schedule_result.get("upcoming") or 0) > 0
            and odds_result["ok"]
            and odds_result["fresh_for_model"]
            and int(odds_result.get("count") or 0) > 0
        ),
        "league": league,
        "date": target.isoformat(),
        "schedule": schedule_result,
        "odds": odds_result,
        "tested_at": datetime.now(TAIPEI).isoformat(),
        "duration_ms": round((monotonic() - started) * 1000),
        "real_odds_only": True,
    }
    history = list(getattr(request.app.state, "api_monitor_history", []) or [])
    request.app.state.api_monitor_history = [payload, *history][:20]
    return payload


@app.get(f"{settings.api_prefix}/admin/operations/status")
async def admin_operations_status(
    request: Request,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    """Founder-only launch readiness and runtime monitor.

    The endpoint is intentionally read-only and does not alter predictions,
    settlements, memberships or payment state.
    """

    await admin_member(request, authorization)
    pregame = dict(getattr(request.app.state, "pregame_status", {}) or {})
    settlement = dict(getattr(request.app.state, "settlement_status", {}) or {})
    operations = dict(getattr(request.app.state, "operations_monitor_status", {}) or {})
    social_monitor = dict(getattr(request.app.state, "social_status", {}) or {})
    social_config = social_service(request).status()
    line_monitor = dict(getattr(request.app.state, "line_status", {}) or {})
    line_config = line_service(request).status()
    odds = odds_service(request).status()
    odds_io = odds_api_io_service(request).status()
    billing = billing_service(request)

    official_settlement_check = _official_settlement_verification_check([])
    if settings.records_enabled:
        try:
            official_records = await records_repository(request).list_records(
                limit=max(settings.records_limit, 100)
            )
            official_settlement_check = _official_settlement_verification_check(official_records)
        except RecordsStorageError:
            official_settlement_check.update({
                "status": "warning",
                "detail": "暫時無法讀取正式推薦紀錄，請重新整理後再檢查",
            })

    checks = [
        {
            "key": "records_database",
            "label": "Supabase 資料庫",
            "status": "pass" if settings.records_enabled else "fail",
            "detail": "推薦、會員、公告與模型資料庫已設定" if settings.records_enabled else "缺少 Supabase 連線設定",
            "blocking": True,
        },
        {
            "key": "odds_feed",
            "label": "真實盤口來源",
            "status": "pass" if (settings.odds_enabled or settings.odds_api_io_enabled) else "warning",
            "detail": (
                "The Odds API 與 Odds-API.io 已設定"
                if settings.odds_enabled and settings.odds_api_io_enabled
                else "The Odds API 已設定"
                if settings.odds_enabled
                else "Odds-API.io 已設定（四聯盟棒球備援）"
                if settings.odds_api_io_enabled
                else "未設定任何真實盤口來源，正式 Pro 玩法會被阻擋"
            ),
            "blocking": True,
        },
        {
            "key": "odds_api_io_quota",
            "label": "Odds-API.io 免費額度保護",
            "status": (
                "pass" if (odds_io.get("quota") or {}).get("state") == "normal"
                else "warning" if settings.odds_api_io_enabled
                else "pending"
            ),
            "detail": (
                f"本服務今日估算已使用 {((odds_io.get('quota') or {}).get('daily') or {}).get('used', 0)} / "
                f"{((odds_io.get('quota') or {}).get('daily') or {}).get('limit', 500)} 次；"
                f"一般更新於 {((odds_io.get('quota') or {}).get('daily') or {}).get('soft_limit', 450)} 次停止，"
                "保留額度給自動發布最後檢查。"
                if settings.odds_api_io_enabled
                else "尚未設定 ODDS_API_IO_KEY"
            ),
            "blocking": False,
        },
        {
            "key": "scheduler",
            "label": "排程密鑰",
            "status": "pass" if settings.scheduler_enabled else "warning",
            "detail": "伺服器排程驗證已設定" if settings.scheduler_enabled else "缺少 CRON_SECRET，外部排程無法安全觸發",
            "blocking": True,
        },
        {
            "key": "billing",
            "label": "付款服務",
            "status": "pass" if billing.enabled else "fail",
            "detail": f"綠界 {settings.ecpay_mode} 模式已設定" if billing.enabled else "付款服務設定不完整",
            "blocking": True,
        },
        {
            "key": "payment_live",
            "label": "正式收款模式",
            "status": "pass" if settings.ecpay_mode == "production" and billing.enabled else "pending",
            "detail": "已切換綠界正式環境" if settings.ecpay_mode == "production" and billing.enabled else "目前維持測試環境，正式收費前再切換",
            "blocking": False,
        },
        {
            "key": "support_channel",
            "label": "客服聯絡管道",
            "status": "pass" if settings.support_email else "pending",
            "detail": settings.support_email or "尚未設定 SUPPORT_EMAIL",
            "blocking": False,
        },
        {
            "key": "instagram_auto_publish",
            "label": "Instagram 全自動發佈",
            "status": "pass" if social_config["enabled"] else "pending",
            "detail": "貼文與限時動態已啟用全自動發佈" if social_config["enabled"] else "程式已就緒，等待在 Render 設定 Meta 帳號編號與權杖",
            "blocking": False,
        },
        {
            "key": "line_messaging",
            "label": "LINE 官方帳號自動通知",
            "status": "pass" if line_config["enabled"] else "pending",
            "detail": "推薦發布與賽後結算自動廣播已啟用" if line_config["enabled"] else "程式已就緒，等待設定 LINE_CHANNEL_ACCESS_TOKEN",
            "blocking": False,
        },
        official_settlement_check,
    ]
    blocking_failures = [item for item in checks if item.get("blocking") and item.get("status") != "pass"]
    monitor_errors = [value for value in (pregame.get("last_error"), settlement.get("last_error")) if value]
    monitor_errors.extend(
        str(item.get("detail") or item.get("label") or "operations_monitor")
        for item in (operations.get("critical_issues") or [])
    )
    overall = "attention" if blocking_failures or monitor_errors else "stage_ready"
    return {
        "ok": not bool(blocking_failures),
        "overall": overall,
        "version": APP_VERSION,
        "environment": settings.app_env,
        "generated_at": datetime.now(TAIPEI).isoformat(),
        "runtime_started_at": getattr(request.app.state, "started_at", None),
        "services": {
            "records_database": settings.records_enabled,
            "odds_feed": settings.odds_enabled or settings.odds_api_io_enabled,
            "odds_api_io_feed": settings.odds_api_io_enabled,
            "scheduler": settings.scheduler_enabled,
            "billing": billing.enabled,
            "billing_mode": settings.ecpay_mode,
            "billing_live": settings.ecpay_mode == "production" and billing.enabled,
            "support_email": settings.support_email or None,
            "public_api_base": settings.public_api_base,
            "frontend_base_url": settings.frontend_base_url,
            "odds_status": odds,
            "odds_api_io_status": odds_io,
            "instagram": social_config,
            "line": line_config,
        },
        "monitors": {
            "pregame": pregame,
            "settlement": settlement,
            "operations": operations,
            "instagram": social_monitor,
            "line": line_monitor,
        },
        "checks": checks,
        "blocking_failures": len(blocking_failures),
        "monitor_errors": monitor_errors,
    }


class AnnouncementPayload(BaseModel):
    title: str = Field(min_length=1, max_length=120)
    body: str = Field(min_length=1, max_length=6000)
    summary: str | None = Field(default=None, max_length=320)
    severity: str = Field(default="general", pattern="^(general|important|emergency)$")
    audience: str = Field(default="all", pattern="^(all|free|pro)$")
    show_home: bool = True
    show_login_modal: bool = True
    dismissible_today: bool = True
    action_label: str | None = Field(default=None, max_length=40)
    action_page: str | None = Field(default=None, pattern="^(|homePage|gamesPage|predictionPage|recordsPage|membershipPage|morePage)$")
    starts_at: datetime | None = None
    ends_at: datetime | None = None
    is_active: bool = True
    priority: int | None = Field(default=None, ge=0, le=999)


@app.get(f"{settings.api_prefix}/announcements/active")
async def active_announcements(
    request: Request,
    placement: str = Query(default="home", pattern="^(home|login)$"),
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    member = await optional_member(request, authorization)
    try:
        items = await announcement_service(request).active(role=str(member.get("role") or "guest"), placement=placement)
        return {"items": items, "placement": placement, "role": member.get("role"), "updated_at": iso_utc()}
    except AnnouncementError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


@app.get(f"{settings.api_prefix}/admin/announcements")
async def admin_announcements(
    request: Request,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    await admin_member(request, authorization)
    try:
        return {"items": await announcement_service(request).admin_list(), "updated_at": iso_utc()}
    except AnnouncementError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


@app.post(f"{settings.api_prefix}/admin/announcements")
async def admin_create_announcement(
    request: Request,
    payload: AnnouncementPayload,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    actor = await admin_member(request, authorization)
    try:
        return {"ok": True, "announcement": await announcement_service(request).create(payload.model_dump(), actor)}
    except AnnouncementError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc


@app.patch(f"{settings.api_prefix}/admin/announcements/{{announcement_id}}")
async def admin_update_announcement(
    request: Request,
    announcement_id: str,
    payload: AnnouncementPayload,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    actor = await admin_member(request, authorization)
    try:
        return {"ok": True, "announcement": await announcement_service(request).update(announcement_id, payload.model_dump(), actor)}
    except AnnouncementError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc


@app.delete(f"{settings.api_prefix}/admin/announcements/{{announcement_id}}")
async def admin_delete_announcement(
    request: Request,
    announcement_id: str,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    await admin_member(request, authorization)
    try:
        await announcement_service(request).delete(announcement_id)
        return {"ok": True, "deleted": announcement_id}
    except AnnouncementError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc


class BillingCheckout(BaseModel):
    plan: str = Field(pattern="^(monthly|quarterly|annual)$")


@app.get(f"{settings.api_prefix}/billing/config", response_class=JSONResponse)
async def billing_config(request: Request) -> JSONResponse:
    # Keep an explicit UTF-8 charset for mobile browsers and use ASCII-only
    # gateway item names so the ECPay page cannot display mojibake.
    return JSONResponse(
        content=billing_service(request).public_config(),
        media_type="application/json; charset=utf-8",
    )


@app.get(f"{settings.api_prefix}/billing/status")
async def billing_member_status(
    request: Request,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    member = await authenticated_member(request, authorization)
    if member.get("role") == "admin":
        return {
            "active": True,
            "status": "founder",
            "plan": "founder",
            "auto_renew": False,
            "current_period_end": None,
            "mode": settings.ecpay_mode,
        }
    try:
        return await billing_service(request).member_status(member)
    except BillingError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


@app.post(f"{settings.api_prefix}/billing/checkout")
async def billing_checkout(
    request: Request,
    command: BillingCheckout,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    member = await authenticated_member(request, authorization)
    try:
        return await billing_service(request).create_checkout(member, command.plan)
    except BillingError as exc:
        message = str(exc)
        status = 409 if "already exists" in message.lower() else 403 if "restricted" in message.lower() else 503
        raise HTTPException(status_code=status, detail=message) from exc


@app.post(f"{settings.api_prefix}/billing/cancel")
async def billing_cancel(
    request: Request,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    member = await authenticated_member(request, authorization)
    try:
        return await billing_service(request).cancel(member)
    except BillingError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc


@app.post(f"{settings.api_prefix}/billing/ecpay/return", response_class=PlainTextResponse)
async def billing_ecpay_return(request: Request) -> PlainTextResponse:
    payload = parse_form_body(await request.body())
    try:
        await billing_service(request).process_callback(payload, event_type="initial_payment")
        return PlainTextResponse("1|OK")
    except BillingError as exc:
        return PlainTextResponse(f"0|{str(exc)[:120]}")


@app.post(f"{settings.api_prefix}/billing/ecpay/result", response_class=HTMLResponse)
async def billing_ecpay_result(request: Request) -> HTMLResponse:
    payload = parse_form_body(await request.body())
    return HTMLResponse(billing_service(request).result_redirect_html(payload))


@app.post(f"{settings.api_prefix}/membership/trial/claim")
async def membership_trial_claim(
    request: Request,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    member = await authenticated_member(request, authorization)
    try:
        return await member_trial_service(request).claim(member)
    except NewMemberTrialError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    except BillingError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


class AdminMembershipCommandPayload(BaseModel):
    action: str = Field(pattern="^(grant|extend|cancel)$")
    plan: str | None = Field(default=None, pattern="^(trial_1d|gift_3d|gift_7d|monthly|quarterly|annual|custom)$")
    note: str | None = Field(default=None, max_length=300)
    custom_expires_at: str | None = Field(default=None, max_length=64)


class ChangePasswordPayload(BaseModel):
    new_password: str = Field(min_length=8, max_length=72)


@app.post(f"{settings.api_prefix}/account/change-password")
async def account_change_password(
    request: Request,
    payload: ChangePasswordPayload,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    member = await authenticated_member(request, authorization)
    try:
        return await password_security_service(request).change_for_member(
            member=member,
            new_password=payload.new_password,
        )
    except PasswordSecurityError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except BillingError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


@app.get(f"{settings.api_prefix}/admin/members")
async def admin_members(
    request: Request,
    query: str = Query(default="", max_length=120),
    role: str = Query(default="all", pattern="^(all|free|pro|admin)$"),
    status: str = Query(default="all", pattern="^(all|free|active|pending|expired|canceled|payment_failed|refunded|founder)$"),
    limit: int = Query(default=50, ge=1, le=200),
    offset: int = Query(default=0, ge=0),
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    await admin_member(request, authorization)
    try:
        return await membership_admin_service(request).overview(
            query=query, role=role, status=status, limit=limit, offset=offset
        )
    except (BillingError, AdminMembershipError) as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


@app.get(f"{settings.api_prefix}/admin/members/{{user_id}}")
async def admin_member_detail(
    request: Request,
    user_id: str,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    await admin_member(request, authorization)
    try:
        return await membership_admin_service(request).member_detail(user_id)
    except (BillingError, AdminMembershipError) as exc:
        raise HTTPException(status_code=404 if "invalid member" in str(exc).lower() else 503, detail=str(exc)) from exc


@app.post(f"{settings.api_prefix}/admin/members/{{user_id}}/membership")
async def admin_member_membership(
    request: Request,
    user_id: str,
    payload: AdminMembershipCommandPayload,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    actor = await admin_member(request, authorization)
    try:
        return await membership_admin_service(request).apply_command(
            actor=actor,
            target_user_id=user_id,
            command=AdminMemberCommand(action=payload.action, plan=payload.plan, note=payload.note, custom_expires_at=payload.custom_expires_at),
        )
    except AdminMembershipError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    except BillingError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


@app.post(f"{settings.api_prefix}/admin/members/{{user_id}}/password-reset")
async def admin_member_password_reset(
    request: Request,
    user_id: str,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    actor = await admin_member(request, authorization)
    try:
        return await password_security_service(request).reset_by_founder(
            actor=actor,
            target_user_id=user_id,
        )
    except PasswordSecurityError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    except BillingError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


@app.get(f"{settings.api_prefix}/admin/transactions")
async def admin_transactions(
    request: Request,
    query: str = Query(default="", max_length=120),
    result: str = Query(default="all", pattern="^(all|success|failed)$"),
    limit: int = Query(default=100, ge=1, le=200),
    offset: int = Query(default=0, ge=0),
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    await admin_member(request, authorization)
    try:
        return await membership_admin_service(request).transactions(
            query=query, result=result, limit=limit, offset=offset
        )
    except (BillingError, AdminMembershipError) as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


@app.get(f"{settings.api_prefix}/admin/export/members.csv")
async def admin_export_members_csv(
    request: Request,
    query: str = Query(default="", max_length=120),
    role: str = Query(default="all", pattern="^(all|free|pro|admin)$"),
    status: str = Query(default="all", pattern="^(all|free|active|pending|expired|canceled|payment_failed|refunded|founder)$"),
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> Response:
    await admin_member(request, authorization)
    try:
        members = await membership_admin_service(request).export_members(
            query=query, role=role, status=status
        )
    except (BillingError, AdminMembershipError) as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    rows = [
        {
            "會員ID": item.get("id"),
            "Email": item.get("email"),
            "暱稱": item.get("name"),
            "角色": item.get("role"),
            "狀態": item.get("status"),
            "方案": item.get("plan"),
            "到期日": item.get("pro_expires_at") or item.get("current_period_end"),
            "註冊時間": item.get("created_at"),
            "最後登入": item.get("last_sign_in_at"),
            "付款來源": item.get("provider"),
            "最近交易編號": item.get("merchant_trade_no"),
        }
        for item in members
    ]
    fields = ["會員ID", "Email", "暱稱", "角色", "狀態", "方案", "到期日", "註冊時間", "最後登入", "付款來源", "最近交易編號"]
    return _csv_response("diamondmind_members.csv", fields, rows)


@app.get(f"{settings.api_prefix}/admin/export/transactions.csv")
async def admin_export_transactions_csv(
    request: Request,
    query: str = Query(default="", max_length=120),
    result: str = Query(default="all", pattern="^(all|success|failed)$"),
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> Response:
    await admin_member(request, authorization)
    try:
        transactions = await membership_admin_service(request).export_transactions(
            query=query, result=result
        )
    except (BillingError, AdminMembershipError) as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    rows = [
        {
            "時間": item.get("created_at"),
            "Email": item.get("email"),
            "結果": "成功" if item.get("success") else "失敗",
            "金額TWD": item.get("amount"),
            "平台": item.get("provider"),
            "商店交易編號": item.get("merchant_trade_no"),
            "金流交易編號": item.get("provider_trade_no"),
            "付款方式": item.get("payment_type"),
            "事件類型": item.get("event_type"),
            "訊息": item.get("rtn_msg"),
        }
        for item in transactions
    ]
    fields = ["時間", "Email", "結果", "金額TWD", "平台", "商店交易編號", "金流交易編號", "付款方式", "事件類型", "訊息"]
    return _csv_response("diamondmind_transactions.csv", fields, rows)


@app.get(f"{settings.api_prefix}/odds/status")
async def odds_status(request: Request) -> dict:
    # These status payloads never expose either provider key.
    primary = odds_service(request).status()
    fallback = odds_api_io_service(request).status()
    return {
        **primary,
        "baseball_fallback": fallback,
        # Compatibility alias for founder clients deployed before MLB failover.
        "cpbl_fallback": fallback,
    }


@app.get(f"{settings.api_prefix}/odds/cpbl/diagnostics")
async def cpbl_odds_diagnostics(
    request: Request,
    target_date: date | None = Query(default=None, alias="date"),
) -> dict:
    """Probe CPBL coverage without exposing the API key.

    Results are cached by the provider adapter, so repeated browser refreshes do
    not repeatedly consume the free quota.
    """
    return await _asian_odds_diagnostics_payload(
        request,
        requested_date(target_date),
        "CPBL",
    )


@app.get(f"{settings.api_prefix}/odds/mlb/diagnostics")
async def mlb_odds_diagnostics(
    request: Request,
    target_date: date | None = Query(default=None, alias="date"),
) -> dict:
    """Probe the MLB primary/fallback chain without exposing either API key."""

    target = requested_date(target_date)
    if not odds_service(request).enabled and not odds_api_io_service(request).enabled:
        return {
            "ok": False,
            "date": target.isoformat(),
            "error": "No MLB real-odds provider is configured.",
        }
    try:
        feed = await mlb_odds_feed_for_date(
            request,
            target,
            priority=True,
        )
    except OddsUpstreamError as exc:
        return {
            "ok": False,
            "date": target.isoformat(),
            "error": str(exc),
            "primary": odds_service(request).status(),
            "fallback": odds_api_io_service(request).status(),
        }
    meta = feed.get("meta") or {}
    return {
        "ok": True,
        "date": target.isoformat(),
        "provider": meta.get("provider"),
        "provider_chain": meta.get("provider_chain") or [],
        "fallback_activated": bool(meta.get("fallback_activated")),
        "count": int(feed.get("count") or 0),
        "coverage_status": meta.get("coverage_status"),
        "coverage": meta.get("coverage") or {},
        "cache": meta.get("cache"),
        "quota": meta.get("quota") or {},
        "persistent_snapshot": bool(meta.get("persistent_snapshot")),
        "snapshot_captured_at": meta.get("snapshot_captured_at"),
        "snapshot_age_minutes": meta.get("snapshot_age_minutes"),
        "availability_reason": meta.get("availability_reason"),
        "provider_skips": meta.get("provider_skips") or [],
        "events": [
            {
                "event_id": item.get("event_id"),
                "away_team": item.get("away_team"),
                "home_team": item.get("home_team"),
                "time_taiwan": item.get("time_taiwan"),
                "markets": sorted((item.get("markets") or {}).keys()),
            }
            for item in feed.get("items") or []
        ],
    }


async def _asian_odds_diagnostics_payload(
    request: Request,
    target: date,
    league: str,
) -> dict:
    code = _prediction_league(league)
    feed = await asian_odds_feed_for_date(
        request,
        target,
        code,
        priority=True,
    )
    meta = feed.get("meta") or {}
    count = int(feed.get("count") or 0)
    fresh = bool(meta.get("fresh_for_model"))
    status = "available" if fresh and count > 0 else _asian_odds_waiting_state(code, feed)[0]
    message = (
        f"{code} 真實盤口已由 {meta.get('provider') or '盤口來源'} 取得。"
        if fresh and count > 0
        else _asian_odds_waiting_state(code, feed)[1]
    )
    return {
        "ok": fresh and count > 0,
        "date": target.isoformat(),
        "league": code,
        "status": status,
        "message": message,
        "provider": meta.get("provider"),
        "provider_chain": meta.get("provider_chain") or [],
        "fallback_activated": bool(meta.get("fallback_activated")),
        "fallback_reason": meta.get("fallback_reason"),
        "count": count,
        "coverage_status": meta.get("coverage_status"),
        "coverage": meta.get("coverage") or {},
        "cache": meta.get("cache"),
        "quota": meta.get("quota") or {},
        "persistent_snapshot": bool(meta.get("persistent_snapshot")),
        "snapshot_captured_at": meta.get("snapshot_captured_at"),
        "snapshot_age_minutes": meta.get("snapshot_age_minutes"),
        "availability_reason": meta.get("availability_reason"),
        "provider_skips": meta.get("provider_skips") or [],
        "primary_error": meta.get("primary_error") or {},
        "fallback_error": meta.get("fallback_error") or {},
        "events": [
            {
                "event_id": item.get("event_id"),
                "away_team": item.get("away_team"),
                "home_team": item.get("home_team"),
                "time_taiwan": item.get("time_taiwan"),
                "markets": sorted((item.get("markets") or {}).keys()),
            }
            for item in feed.get("items") or []
        ],
    }


@app.get(f"{settings.api_prefix}/odds/npb/diagnostics")
async def npb_odds_diagnostics(
    request: Request,
    target_date: date | None = Query(default=None, alias="date"),
) -> dict:
    """Probe the NPB primary/fallback chain without exposing either API key."""

    return await _asian_odds_diagnostics_payload(
        request,
        requested_date(target_date),
        "NPB",
    )


@app.get(f"{settings.api_prefix}/odds/kbo/diagnostics")
async def kbo_odds_diagnostics(
    request: Request,
    target_date: date | None = Query(default=None, alias="date"),
) -> dict:
    """Probe the KBO primary/fallback chain without exposing either API key."""

    return await _asian_odds_diagnostics_payload(
        request,
        requested_date(target_date),
        "KBO",
    )


@app.get(f"{settings.api_prefix}/advanced/status")
async def advanced_status(
    request: Request,
    season: int = Query(default=datetime.now(TAIPEI).year, ge=2015, le=2100),
) -> dict:
    """Public, non-sensitive Statcast source diagnostic."""
    return await service(request).statcast.diagnostics(season)


@app.get(f"{settings.api_prefix}/pregame/status")
async def pregame_status(request: Request) -> dict:
    return {
        **(getattr(request.app.state, "pregame_status", {}) or {}),
        "lineup_watch_minutes": settings.pregame_lineup_watch_minutes,
        "final_lock_minutes": settings.pregame_final_lock_minutes,
        "minimum_publish_data_quality": settings.minimum_publish_data_quality,
        "minimum_lineup_validation_rate": settings.minimum_lineup_validation_rate,
        "settlement_monitor": getattr(request.app.state, "settlement_status", {}) or {},
    }


@app.get(f"{settings.api_prefix}/admin/settlement/status")
async def admin_settlement_status(
    request: Request,
    target_date: date | None = Query(default=None, alias="date"),
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    await admin_member(request, authorization)
    try:
        dashboard = await settlement_dashboard(
            records_repository(request), service(request), npb_service(request), kbo_service(request), cpbl_service(request), requested_date(target_date)
        )
    except RecordsStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    dashboard["monitor"] = getattr(request.app.state, "settlement_status", {}) or {}
    return dashboard


@app.post(f"{settings.api_prefix}/admin/settlement/run")
async def admin_run_settlement(
    request: Request,
    target_date: date | None = Query(default=None, alias="date"),
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    actor = await admin_member(request, authorization)
    try:
        async with request.app.state.background_work_lock:
            free_count, package_count, game_lookups, diagnostics = await asyncio.wait_for(
                _run_settlement_pass(request.app),
                timeout=settings.settlement_phase_timeout_seconds,
            )
        social = _queue_social_sync(request.app, "manual_settlement", force=(free_count + package_count) > 0)
        line = _queue_line_sync(request.app, "manual_settlement", force=(free_count + package_count) > 0)
        dashboard = await settlement_dashboard(
            records_repository(request), service(request), npb_service(request), kbo_service(request), cpbl_service(request), requested_date(target_date)
        )
    except RecordsStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    previous_status = dict(getattr(request.app.state, "settlement_status", {}) or {})
    request.app.state.settlement_status = {
        **{key: previous_status.get(key) for key in (
            "scheduler", "scheduler_interval_seconds", "scheduler_last_check",
            "scheduler_queue_result", "scheduler_error",
        ) if previous_status.get(key) is not None},
        "enabled": True,
        "state": "idle",
        "running": False,
        "queued": False,
        "last_run": iso_utc(),
        "last_error": None,
        "free_settled_now": free_count,
        "packages_settled_now": package_count,
        "social": social,
        "line": line,
        "manual_by": actor.get("email"),
        "diagnostics": diagnostics,
    }
    return {
        "ok": True,
        "free_settled_now": free_count,
        "packages_settled_now": package_count,
        "official_game_lookups": game_lookups,
        "diagnostics": diagnostics,
        "social": social,
        "line": line,
        "dashboard": dashboard,
        "message": "已重新向 MLB／NPB／KBO／CPBL 官方資料檢查所有待結算推薦。",
    }




async def sync_existing_model_snapshots(request: Request) -> dict:
    """Idempotently backfill snapshots for recommendations published before this release."""

    records = records_repository(request)
    performance = performance_repository(request)
    if not records.enabled or not performance.enabled:
        return {"public": 0, "packages": 0}
    public_count = 0
    package_count = 0
    try:
        public_rows = await records.list_records(limit=1000)
        pending_packages = await records.list_pending_prediction_packages()
        settled_packages = await records.list_settled_prediction_packages(limit=1000)
    except RecordsStorageError:
        return {"public": 0, "packages": 0}
    seen_packages: dict[str, dict] = {}
    for item in [*pending_packages, *settled_packages]:
        if item.get("id") is not None:
            seen_packages[str(item.get("id"))] = item
    for record in public_rows:
        selection = record.get("prediction_snapshot")
        if not isinstance(selection, dict) or not record.get("id"):
            continue
        try:
            await performance.capture_public(str(record.get("recommendation_date")), str(record.get("id")), selection)
            if str(record.get("status")) in {"won", "lost", "push", "void"}:
                await performance.settle_public(str(record.get("id")), {
                    "status": record.get("status"),
                    "away_score": record.get("away_score"),
                    "home_score": record.get("home_score"),
                    "result_note": record.get("result_note"),
                    "settled_at": record.get("settled_at") or iso_utc(),
                })
            public_count += 1
        except PerformanceStorageError:
            break
    for record_id, record in seen_packages.items():
        try:
            package = package_from_record(record)
            await performance.capture_package(str(record.get("recommendation_date")), record_id, package)
            # Backfill every result already present in a partially settled
            # package.  Waiting for record.settled=True kept all snapshots
            # pending whenever one postponed selection remained open.
            await performance.settle_package(record_id, {"results": record.get("results") or {}})
            package_count += 1
        except PerformanceStorageError:
            break
    return {"public": public_count, "packages": package_count}


async def _model_snapshot_backfill_worker(app: FastAPI) -> None:
    status = app.state.model_backfill_status
    async with app.state.model_backfill_lock:
        status.update({
            "running": True,
            "last_started_at": iso_utc(),
            "last_error": None,
        })
        try:
            # The worker only needs request.app.state; using a tiny proxy keeps
            # the heavy migration outside the browser request lifecycle.
            class _RequestProxy:
                def __init__(self, target_app: FastAPI) -> None:
                    self.app = target_app

            result = await sync_existing_model_snapshots(_RequestProxy(app))
            status.update({
                "public": int(result.get("public") or 0),
                "packages": int(result.get("packages") or 0),
                "last_completed_at": iso_utc(),
                "last_completed_monotonic": monotonic(),
            })
        except asyncio.CancelledError:
            status["last_error"] = "cancelled"
            raise
        except Exception as exc:
            status.update({
                "last_error": type(exc).__name__,
                "last_completed_at": iso_utc(),
                "last_completed_monotonic": monotonic(),
            })
        finally:
            status["running"] = False


def queue_model_snapshot_backfill(request: Request, *, force: bool = False) -> dict:
    app = request.app
    status = app.state.model_backfill_status
    task = getattr(app.state, "model_backfill_task", None)
    if task is not None and not task.done():
        return {key: value for key, value in status.items() if not key.endswith("monotonic")}
    elapsed = monotonic() - float(status.get("last_completed_monotonic") or 0.0)
    cooldown = int(status.get("cooldown_seconds") or 21600)
    if force or not status.get("last_completed_at") or elapsed >= cooldown:
        app.state.model_backfill_task = asyncio.create_task(
            _model_snapshot_backfill_worker(app),
            name="diamondmind-model-snapshot-backfill",
        )
        status["running"] = True
        status["last_error"] = None
    return {key: value for key, value in status.items() if not key.endswith("monotonic")}


class ModelWeightCommand(BaseModel):
    weights: dict[str, float]
    note: str | None = Field(default=None, max_length=500)
    confirm: bool = False


class ModelWeightDeployCommand(BaseModel):
    run_id: str = Field(min_length=1, max_length=100)
    confirm: bool = False


class ModelTestSettlementCommand(BaseModel):
    recommendation_date: date
    market: str = Field(pattern="^(moneyline|run_line|totals)$")
    pick_side: str = Field(pattern="^(home|away|over|under)$")
    line: float | None = None
    away_score: int = Field(ge=0, le=99)
    home_score: int = Field(ge=0, le=99)
    confidence: float = Field(default=65.0, ge=50, le=99.9)
    data_quality: float = Field(default=0.75, ge=0, le=1)
    module_edges: dict[str, float] = Field(default_factory=dict)


def _performance_range_days(value: str) -> int | None:
    return {"7d": 7, "30d": 30, "season": None}.get(value, 30)


@app.get(f"{settings.api_prefix}/admin/model/performance")
async def admin_model_performance(
    request: Request,
    range_value: str = Query(default="30d", alias="range", pattern="^(7d|30d|season)$"),
    market: str = Query(default="all", pattern="^(all|moneyline|run_line|totals|two_leg|three_leg)$"),
    source_type: str = Query(default="all", pattern="^(all|public|pro)$"),
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    await admin_member(request, authorization)
    # Historical snapshot migration is queued in the background.  The
    # dashboard request must remain read-only and fast enough for mobile.
    backfill = queue_model_snapshot_backfill(request)
    try:
        dashboard = await performance_repository(request).performance_dashboard(
            days=_performance_range_days(range_value), market=market, source_type=source_type
        )
    except PerformanceStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    dashboard["range"] = range_value
    dashboard["backfill"] = backfill
    dashboard["model_runtime_weights"] = normalize_weights(service(request).model_weights)
    return dashboard


@app.get(f"{settings.api_prefix}/admin/model/snapshots")
async def admin_model_snapshots(
    request: Request,
    range_value: str = Query(default="30d", alias="range", pattern="^(7d|30d|season)$"),
    market: str = Query(default="all", pattern="^(all|moneyline|run_line|totals|two_leg|three_leg)$"),
    source_type: str = Query(default="all", pattern="^(all|public|pro|test)$"),
    include_test: bool = Query(default=False),
    limit: int = Query(default=250, ge=1, le=2000),
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    await admin_member(request, authorization)
    queue_model_snapshot_backfill(request)
    try:
        items = await performance_repository(request).list_snapshots(
            days=_performance_range_days(range_value),
            include_test=include_test,
            market=market,
            source_type=source_type,
            limit=limit,
        )
    except PerformanceStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    return {"items": items, "count": len(items), "range": range_value, "updated_at": iso_utc()}


@app.get(f"{settings.api_prefix}/admin/model/backfill/status")
async def admin_model_backfill_status(
    request: Request,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    await admin_member(request, authorization)
    return {
        "ok": True,
        "status": {
            key: value
            for key, value in request.app.state.model_backfill_status.items()
            if not key.endswith("monotonic")
        },
    }


@app.post(f"{settings.api_prefix}/admin/model/backfill/run")
async def admin_model_backfill_run(
    request: Request,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    await admin_member(request, authorization)
    status = queue_model_snapshot_backfill(request, force=True)
    return {
        "ok": True,
        "queued": True,
        "status": status,
        "message": "歷史模型快照已在背景同步；同步期間仍可查看目前已完成的績效。",
    }


@app.post(f"{settings.api_prefix}/admin/model/calibration/apply")
async def admin_apply_model_calibration(
    request: Request,
    command: ModelWeightCommand,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    actor = await admin_member(request, authorization)
    if not command.confirm:
        raise HTTPException(status_code=409, detail="建立 TEST 權重候選前必須再次確認。")
    unknown = sorted(set(command.weights) - set(DEFAULT_MODEL_WEIGHTS))
    if unknown:
        raise HTTPException(status_code=422, detail=f"未知模型模組：{', '.join(unknown)}")
    normalized = normalize_weights(command.weights)
    current = normalize_weights(service(request).model_weights)
    if normalized == current:
        raise HTTPException(status_code=409, detail="這組權重與目前 Production 相同，不需建立 TEST。")
    repository = performance_repository(request)
    try:
        rows = await repository.list_snapshots(
            days=settings.model_calibration_lookback_days,
            include_test=False,
            market="all",
            source_type="all",
            limit=5000,
        )
        calibration = calibration_suggestions(rows, current)
        if not calibration.get("ready"):
            raise HTTPException(
                status_code=409,
                detail=calibration.get("message") or "權重校正樣本尚未達到 TEST 門檻。",
            )
        test = await repository.create_weight_challenger(
            weights=normalized,
            actor_id=str(actor.get("id")),
            note=command.note,
            calibration=calibration,
        )
    except HTTPException:
        raise
    except PerformanceStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    return {
        "ok": True,
        "mode": "test",
        "deployed": False,
        "weights": normalized,
        "run": test["run"],
        "candidate": test["candidate"],
        "message": "TEST 權重 Challenger 已建立；尚未影響 Production 或會員推薦。",
    }


@app.post(f"{settings.api_prefix}/admin/model/calibration/deploy")
async def admin_deploy_model_calibration(
    request: Request,
    command: ModelWeightDeployCommand,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    actor = await admin_member(request, authorization)
    if not command.confirm:
        raise HTTPException(status_code=409, detail="Deploy 權重前必須由創辦人再次確認。")
    repository = performance_repository(request)
    try:
        run = await repository.get_calibration_run(command.run_id)
        if not run:
            raise HTTPException(status_code=404, detail="找不到指定的權重 TEST 紀錄。")
        candidate = next(
            (
                item
                for item in (run.get("candidates") or [])
                if isinstance(item, dict)
                and str(item.get("kind") or "") == "weight_profile"
            ),
            None,
        )
        if not candidate:
            raise HTTPException(status_code=404, detail="找不到指定的權重 Challenger。")
        if _calibration_scope_was_promoted(run, "GLOBAL", "weights"):
            raise HTTPException(status_code=409, detail="此權重 Challenger 已部署，不能重複部署。")
        if not candidate.get("ready") or not candidate.get("promote"):
            raise HTTPException(
                status_code=409,
                detail="此權重 Challenger 尚未通過樣本門檻，不能部署到 Production。",
            )
        normalized = normalize_weights(candidate.get("weights"))
        profile = await repository.activate_weights(
            weights=normalized,
            actor_id=str(actor.get("id") or actor.get("email") or "founder"),
            note=f"Founder deployed TEST weight challenger {command.run_id}",
        )
        await repository.record_weight_promotion(
            run_id=command.run_id,
            profile=profile,
            weights=normalized,
        )
    except HTTPException:
        raise
    except PerformanceStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    service(request).model_weights = normalized
    request.app.state.calibration_status = {
        **dict(getattr(request.app.state, "calibration_status", {}) or {}),
        "status": "weight_production_deployed",
        "last_deploy": iso_utc(),
        "last_error": None,
        "auto_promote": False,
    }
    return {
        "ok": True,
        "mode": "production",
        "weights": normalized,
        "profile": profile,
        "message": "TEST 權重已由創辦人確認升為 Production；只影響後續新分析。",
    }


@app.post(f"{settings.api_prefix}/admin/model/test-settlement")
async def admin_model_test_settlement(
    request: Request,
    command: ModelTestSettlementCommand,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    actor = await admin_member(request, authorization)
    if command.market in {"moneyline", "run_line"} and command.pick_side not in {"away", "home"}:
        raise HTTPException(status_code=422, detail="獨贏與讓分測試必須選擇客隊或主隊。")
    if command.market == "totals" and command.pick_side not in {"over", "under"}:
        raise HTTPException(status_code=422, detail="大小分測試必須選擇大分或小分。")
    if command.market in {"run_line", "totals"} and command.line is None:
        raise HTTPException(status_code=422, detail="讓分與大小分測試必須輸入盤口。")

    pick_team_id = 1 if command.pick_side == "away" else 2 if command.pick_side == "home" else None
    side_zh = {"away": "客隊", "home": "主隊", "over": "大", "under": "小"}[command.pick_side]
    selection = {
        "candidate_id": f"test:{command.market}:{command.recommendation_date.isoformat()}:{iso_utc()}",
        "game_pk": 0,
        "market": command.market,
        "pick": {
            "market": command.market,
            "side": command.pick_side,
            "team_id": pick_team_id,
            "line": command.line,
            "label": f"{side_zh}{'' if command.line is None else f' {command.line:g}'}",
        },
    }
    game = {
        "status": "Final",
        "detailed_status": "Final",
        "away": {"id": 1, "score": command.away_score},
        "home": {"id": 2, "score": command.home_score},
    }
    result = settle_market_selection(selection, game)
    if not result:
        raise HTTPException(status_code=422, detail="測試條件無法產生結算結果。")
    analysis_groups = {
        key: {
            "edge_home": float(command.module_edges.get(key, 0.0)),
            "quality": 1.0,
            "available": True,
        }
        for key in DEFAULT_MODEL_WEIGHTS
    }
    try:
        snapshot = await performance_repository(request).create_test_snapshot({
            "recommendation_date": command.recommendation_date.isoformat(),
            "market": command.market,
            "pick_side": command.pick_side,
            "pick_label": selection["pick"]["label"],
            "line": command.line,
            "confidence": command.confidence,
            "data_quality": command.data_quality,
            "weights": service(request).model_weights or DEFAULT_MODEL_WEIGHTS,
            "analysis_groups": analysis_groups,
            "result": result,
        })
    except PerformanceStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    return {
        "ok": True,
        "test": True,
        "result": result,
        "snapshot": snapshot,
        "created_by": actor.get("email"),
        "message": "測試推薦已完成發布、鎖定、結算與快照紀錄；不會出現在公開紀錄或真實績效。",
    }


@app.get(f"{settings.api_prefix}/admin/model/export/snapshots.csv")
async def admin_export_model_snapshots(
    request: Request,
    range_value: str = Query(default="season", alias="range", pattern="^(7d|30d|season)$"),
    include_test: bool = Query(default=False),
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> Response:
    await admin_member(request, authorization)
    try:
        rows = await performance_repository(request).list_snapshots(
            days=_performance_range_days(range_value), include_test=include_test, limit=5000
        )
    except PerformanceStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    output = []
    for item in rows:
        modules = item.get("module_scores") or {}
        output.append({
            "日期": item.get("recommendation_date"),
            "來源": item.get("source_type"),
            "玩法": item.get("market"),
            "推薦": item.get("pick_label"),
            "信心": item.get("confidence"),
            "資料完整度": item.get("data_quality"),
            "盤口": item.get("line"),
            "價格": item.get("price"),
            "結果": item.get("status"),
            "單位盈虧": ((item.get("result") or {}).get("performance") or {}).get("profit_units"),
            "單筆ROI": ((item.get("result") or {}).get("performance") or {}).get("roi_percent"),
            "測試資料": item.get("is_test"),
            "先發分數": (modules.get("starter") or {}).get("edge_for_pick"),
            "打線分數": (modules.get("lineup") or {}).get("edge_for_pick"),
            "牛棚分數": (modules.get("bullpen") or {}).get("edge_for_pick"),
            "球隊實力分數": (modules.get("team_strength") or {}).get("edge_for_pick"),
            "進階數據分數": (modules.get("advanced") or {}).get("edge_for_pick"),
            "環境分數": (modules.get("environment") or {}).get("edge_for_pick"),
            "模型版本": item.get("model_version"),
            "發布時間": item.get("created_at"),
            "結算時間": item.get("settled_at"),
        })
    fields = ["日期", "來源", "玩法", "推薦", "信心", "資料完整度", "盤口", "價格", "結果", "單位盈虧", "單筆ROI", "測試資料", "先發分數", "打線分數", "牛棚分數", "球隊實力分數", "進階數據分數", "環境分數", "模型版本", "發布時間", "結算時間"]
    return _csv_response("diamondmind_model_snapshots.csv", fields, output)


@app.get(f"{settings.api_prefix}/admin/model/export/performance.csv")
async def admin_export_model_performance(
    request: Request,
    range_value: str = Query(default="season", alias="range", pattern="^(7d|30d|season)$"),
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> Response:
    await admin_member(request, authorization)
    try:
        dashboard = await performance_repository(request).performance_dashboard(
            days=_performance_range_days(range_value), market="all", source_type="all"
        )
    except PerformanceStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    rows = []
    for group_name, items in (("玩法", dashboard.get("by_market") or []), ("聯盟", dashboard.get("by_league") or []), ("信心區間", dashboard.get("by_confidence") or []), ("來源", dashboard.get("by_source") or [])):
        for item in items:
            rows.append({
                "分類": group_name,
                "項目": item.get("key"),
                "總數": item.get("total"),
                "有效決策": item.get("decisions"),
                "命中": item.get("won"),
                "未中": item.get("lost"),
                "走水": item.get("push"),
                "作廢": item.get("void"),
                "等待": item.get("pending"),
                "命中率": item.get("hit_rate"),
                "有效投注單位": item.get("stake_units"),
                "累計盈虧單位": item.get("profit_units"),
                "ROI": item.get("roi_percent"),
            })
    fields = ["分類", "項目", "總數", "有效決策", "命中", "未中", "走水", "作廢", "等待", "命中率", "有效投注單位", "累計盈虧單位", "ROI"]
    return _csv_response("diamondmind_model_performance.csv", fields, rows)


@app.get(f"{settings.api_prefix}/sports")
async def sports_catalog() -> dict:
    return {
        "schema_version": SPORTS_SCHEMA_VERSION,
        "default_sport": "baseball",
        "items": registered_sports_catalog(),
    }


@app.get(f"{settings.api_prefix}/markets/catalog")
async def market_catalog(
    sport: str | None = Query(default=None),
    league: str | None = Query(default=None),
) -> dict:
    if not sport and not league:
        raise HTTPException(status_code=422, detail="sport or league is required")
    try:
        return registered_market_catalog(sport=sport, league=league)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.get(f"{settings.api_prefix}/leagues")
async def league_catalog() -> dict:
    return {
        "schema_version": SPORTS_SCHEMA_VERSION,
        "default": "MLB",
        "active": list(ACTIVE_LEAGUES),
        "items": registered_league_catalog(),
    }


@app.get(f"{settings.api_prefix}/leagues/{{league}}/capabilities")
async def league_capabilities(league: str) -> dict:
    try:
        code = normalize_league_code(league)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    item = dict(LEAGUES[code])
    item["market_catalog"] = registered_market_catalog(league=code)["items"]
    item["foundation_ready"] = True
    item["adapter_enabled"] = code in ACTIVE_LEAGUES
    return item


@app.get(f"{settings.api_prefix}/leagues/summary")
async def league_summary(
    request: Request,
    response: Response,
    game_date: date | None = Query(default=None, alias="date", description="Taiwan date, YYYY-MM-DD"),
) -> dict:
    response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
    response.headers["Pragma"] = "no-cache"
    response.headers["Expires"] = "0"
    target_date = requested_date(game_date)
    mlb_result, npb_result = await asyncio.gather(
        service(request).games_for_date(target_date),
        npb_service(request).games_for_date(target_date),
        return_exceptions=True,
    )

    def summarize(code: str, payload: object, status: str) -> dict:
        if isinstance(payload, Exception):
            return {"code": code, "status": status, "available": False, "count": None, "upcoming": 0, "live": 0, "final": 0}
        data = payload if isinstance(payload, dict) else {}
        items = data.get("items") or data.get("dates") or []
        if code == "MLB" and data.get("dates"):
            games = []
            for day in data.get("dates") or []:
                games.extend(day.get("games") or [])
            items = games
        normalized = [item for item in items if isinstance(item, dict)]
        def state(item: dict) -> str:
            value = str(item.get("status") or (item.get("status") or {}).get("abstractGameState") or "").lower()
            detailed = str(item.get("detailed_status") or (item.get("status") or {}).get("detailedState") or "").lower()
            if "final" in value or "final" in detailed or "game over" in detailed:
                return "final"
            if value in {"live", "in progress"} or "progress" in detailed:
                return "live"
            return "upcoming"
        states = [state(item) for item in normalized]
        return {
            "code": code,
            "status": status,
            "available": True,
            "count": len(normalized),
            "upcoming": states.count("upcoming"),
            "live": states.count("live"),
            "final": states.count("final"),
        }

    return {
        "date": target_date.isoformat(),
        "items": [
            summarize("MLB", mlb_result, LEAGUES["MLB"]["status"]),
            summarize("NPB", npb_result, LEAGUES["NPB"]["status"]),
            *[
                {
                    "code": code,
                    "sport": sport_for_league(code),
                    "status": LEAGUES[code]["status"],
                    "available": False,
                    "count": None,
                    "upcoming": 0,
                    "live": 0,
                    "final": 0,
                }
                for code in ("KBO", "CPBL", "NBA", "EPL")
            ],
        ],
    }


@app.get(f"{settings.api_prefix}/games")
async def multi_league_games(
    request: Request,
    league: str = Query(default="MLB", min_length=3, max_length=4),
    game_date: date | None = Query(default=None, alias="date", description="Taiwan date, YYYY-MM-DD"),
) -> dict:
    code = league.strip().upper()
    target_date = requested_date(game_date)
    try:
        if code == "MLB":
            payload = await service(request).games_for_date(target_date)
            return {**payload, "league": "MLB"}
        if code == "NPB":
            return await npb_service(request).games_for_date(target_date)
        if code == "KBO":
            return await kbo_service(request).games_for_date(target_date)
        if code == "CPBL":
            return await cpbl_service(request).games_for_date(target_date)
        if code in {"NBA", "EPL"}:
            raise HTTPException(
                status_code=501,
                detail={
                    "message": f"{code} adapter is not enabled yet",
                    "sport": sport_for_league(code),
                    "foundation_ready": True,
                    "status": LEAGUES[code]["status"],
                },
            )
        raise HTTPException(status_code=400, detail="Unsupported league")
    except MLBUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    except (NPBUpstreamError, AsianBaseballUpstreamError) as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    except AsianBaseballUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@app.get(f"{settings.api_prefix}/events")
async def generic_events(
    request: Request,
    league: str = Query(default="MLB", min_length=3, max_length=4),
    game_date: date | None = Query(default=None, alias="date", description="Taiwan date, YYYY-MM-DD"),
) -> dict:
    try:
        code = normalize_league_code(league)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    if code not in ACTIVE_LEAGUES:
        raise HTTPException(
            status_code=501,
            detail={
                "message": f"{code} event adapter is pending",
                "sport": sport_for_league(code),
                "foundation_ready": True,
            },
        )
    target_date = requested_date(game_date)
    try:
        if code == "MLB":
            payload = await service(request).games_for_date(target_date)
        elif code == "NPB":
            payload = await npb_service(request).games_for_date(target_date)
        elif code == "KBO":
            payload = await kbo_service(request).games_for_date(target_date)
        else:
            payload = await cpbl_service(request).games_for_date(target_date)
    except (MLBUpstreamError, NPBUpstreamError, AsianBaseballUpstreamError) as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    source_items = [item for item in payload.get("items") or [] if isinstance(item, dict)]
    return {
        "schema_version": SPORTS_SCHEMA_VERSION,
        "sport": sport_for_league(code),
        "league": code,
        "date": target_date.isoformat(),
        "count": len(source_items),
        "items": [normalize_event(item, code, target_date) for item in source_items],
        "meta": payload.get("meta") or {},
    }


@app.get(f"{settings.api_prefix}/npb/standings")
async def npb_standings(
    request: Request,
    season: int = Query(default=datetime.now(TAIPEI).year, ge=1936, le=2100),
) -> dict:
    try:
        return await npb_service(request).standings_for_season(season)
    except NPBUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@app.get(f"{settings.api_prefix}/npb/games")
async def npb_games(
    request: Request,
    game_date: date | None = Query(default=None, alias="date", description="Taiwan date, YYYY-MM-DD"),
) -> dict:
    try:
        return await npb_service(request).games_for_date(requested_date(game_date))
    except NPBUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@app.get(f"{settings.api_prefix}/npb/games/{{game_pk}}")
async def npb_game_detail(
    request: Request,
    game_pk: str,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    member = await optional_member(request, authorization)
    try:
        detail = await npb_service(request).game_detail(game_pk)
        if not member.get("has_pro_access"):
            locked = locked_game_detail(detail, member)
            locked["meta"] = {
                "source": "NPB.jp official data",
                "updated_at": (detail.get("meta") or {}).get("updated_at"),
                "analysis_payload_returned": False,
            }
            return locked
        detail["access"] = {
            "role": member.get("role") or "pro",
            "has_pro_access": True,
            "required_plan": "pro",
        }
        return detail
    except NPBUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@app.get(f"{settings.api_prefix}/kbo/games")
async def kbo_games(
    request: Request,
    game_date: date | None = Query(default=None, alias="date", description="Taiwan date, YYYY-MM-DD"),
) -> dict:
    try:
        return await kbo_service(request).games_for_date(requested_date(game_date))
    except AsianBaseballUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@app.get(f"{settings.api_prefix}/kbo/games/{{game_pk}}")
async def kbo_game_detail(
    request: Request,
    game_pk: str,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    member = await optional_member(request, authorization)
    try:
        detail = await kbo_service(request).game_detail(game_pk)
        if not member.get("has_pro_access"):
            return locked_game_detail(detail, member)
        return {**detail, "analysis_locked": False, "access": {"role": member.get("role"), "has_pro_access": True, "required_plan": "pro"}}
    except AsianBaseballUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@app.get(f"{settings.api_prefix}/cpbl/games")
async def cpbl_games(
    request: Request,
    game_date: date | None = Query(default=None, alias="date", description="Taiwan date, YYYY-MM-DD"),
) -> dict:
    try:
        return await cpbl_service(request).games_for_date(requested_date(game_date))
    except AsianBaseballUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@app.get(f"{settings.api_prefix}/cpbl/games/{{game_pk}}")
async def cpbl_game_detail(
    request: Request,
    game_pk: str,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    member = await optional_member(request, authorization)
    try:
        detail = await cpbl_service(request).game_detail(game_pk)
        if not member.get("has_pro_access"):
            return locked_game_detail(detail, member)
        return {**detail, "analysis_locked": False, "access": {"role": member.get("role"), "has_pro_access": True, "required_plan": "pro"}}
    except AsianBaseballUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@app.get(f"{settings.api_prefix}/mlb/games")
async def mlb_games(
    request: Request,
    game_date: date | None = Query(default=None, alias="date", description="Taiwan date, YYYY-MM-DD"),
) -> dict:
    try:
        return await service(request).games_for_date(requested_date(game_date))
    except MLBUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@app.get(f"{settings.api_prefix}/mlb/games/{{game_pk}}")
async def mlb_game_detail(
    request: Request,
    game_pk: int,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    member = await optional_member(request, authorization)
    try:
        detail = await service(request).game_detail(game_pk)
        if not member.get("has_pro_access"):
            return locked_game_detail(detail, member)
        return {
            **detail,
            "analysis_locked": False,
            "access": {
                "role": member.get("role"),
                "has_pro_access": True,
                "required_plan": "pro",
            },
        }
    except KeyError as exc:
        raise HTTPException(status_code=404, detail="Game not found") from exc
    except MLBUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


_TERMINAL_RECOMMENDATION_RESULTS = {"won", "lost", "push", "void"}


def _publication_datetime(value: object) -> datetime | None:
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(str(value).strip().replace("Z", "+00:00"))
    except (TypeError, ValueError):
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=TAIPEI)
    return parsed.astimezone(TAIPEI)


def _selection_start_datetime(selection: dict | None) -> datetime | None:
    if not isinstance(selection, dict):
        return None
    legs = selection.get("legs")
    if isinstance(legs, list) and legs:
        starts = [
            value
            for value in (_selection_start_datetime(leg) for leg in legs if isinstance(leg, dict))
            if value is not None
        ]
        return min(starts) if starts else None
    game = selection.get("game") or {}
    for value in (
        selection.get("game_date"),
        selection.get("start_at"),
        game.get("game_date"),
        game.get("start_at"),
    ):
        parsed = _publication_datetime(value)
        if parsed is not None:
            return parsed
    return None


def _selection_schedule_metadata(selection: dict | None) -> dict:
    if not isinstance(selection, dict):
        return {
            "time_taiwan": None,
            "display_time_taiwan": None,
            "game_label": "",
            "game_number": None,
            "is_doubleheader": False,
        }
    game = selection.get("game") or {}
    time_taiwan = selection.get("time_taiwan") or game.get("time_taiwan")
    return {
        "time_taiwan": time_taiwan,
        "display_time_taiwan": selection.get("display_time_taiwan")
        or game.get("display_time_taiwan")
        or (f"台灣 {time_taiwan}" if time_taiwan else None),
        "game_label": selection.get("game_label") or game.get("game_label") or "",
        "game_number": selection.get("game_number")
        if selection.get("game_number") is not None
        else game.get("game_number"),
        "is_doubleheader": bool(selection.get("is_doubleheader") or game.get("is_doubleheader")),
    }


def _lifecycle_status(
    result_statuses: list[str],
    starts: list[datetime],
    *,
    now: datetime | None = None,
) -> str:
    statuses = [str(value or "pending").lower() for value in result_statuses]
    if statuses and all(value in _TERMINAL_RECOMMENDATION_RESULTS for value in statuses):
        return "settled"
    current = now or datetime.now(TAIPEI)
    if any(value <= current for value in starts):
        return "live"
    return "published"


def _record_publication_metadata(record: dict, league: str) -> dict | None:
    snapshot = record.get("prediction_snapshot")
    if not isinstance(snapshot, dict) or not _selection_matches_league(snapshot, league):
        return None
    publication = snapshot.get("publication") or {}
    target_date = str(
        snapshot.get("target_date")
        or publication.get("target_date")
        or record.get("recommendation_date")
        or ""
    )
    published_at = str(
        snapshot.get("published_at")
        or publication.get("published_at")
        or record.get("published_at")
        or ""
    )
    result_status = str(record.get("status") or "pending").lower()
    start = _selection_start_datetime(snapshot)
    status = _lifecycle_status([result_status], [start] if start else [])
    return {
        "league": league,
        **_analysis_mode_metadata(
            str(
                publication.get("analysis_mode")
                or snapshot.get("analysis_mode")
                or _selection_analysis_mode(snapshot)
            )
        ),
        "target_date": target_date,
        "published_at": published_at,
        "status": status,
        "is_active": status != "settled",
        "game_id": str(record.get("game_pk") or snapshot.get("game_pk") or ""),
        "game_ids": [str(record.get("game_pk") or snapshot.get("game_pk") or "")],
        "recommendation_type": "free_pick",
        "result_status": result_status,
    }


def _package_result_for_selection(
    package: dict,
    group: str,
    selection: dict,
    index: int,
) -> dict:
    values = ((package.get("results") or {}).get(group) or [])
    candidate_id = str(selection.get("candidate_id") or "")
    if candidate_id:
        matched = next(
            (
                item
                for item in values
                if isinstance(item, dict) and str(item.get("candidate_id") or "") == candidate_id
            ),
            None,
        )
        if matched:
            return matched
        # Formal results are sparse while games finish at different times.
        # Never borrow another selection's result by array position when this
        # selection has its own stable candidate id.
        return {"status": "pending"}
    return values[index] if index < len(values) and isinstance(values[index], dict) else {"status": "pending"}


def _package_entries(package: dict, league: str) -> list[tuple[str, dict, dict]]:
    filtered = _package_for_league(package, league) or {}
    entries: list[tuple[str, dict, dict]] = []
    for group in ("moneylines", "run_lines", "totals"):
        for index, selection in enumerate(filtered.get(group) or []):
            if isinstance(selection, dict):
                entries.append((group, selection, _package_result_for_selection(filtered, group, selection, index)))
    for group in ("two_leg", "three_leg"):
        for index, selection in enumerate((filtered.get("parlays") or {}).get(group) or []):
            if isinstance(selection, dict):
                entries.append((group, selection, _package_result_for_selection(filtered, group, selection, index)))
    return entries


def _package_publication_metadata(package: dict, league: str) -> dict | None:
    entries = _package_entries(package, league)
    if not entries:
        return None
    publication = package.get("publication") or {}
    batches = publication.get("league_batches") or {}
    stored = batches.get(league) if isinstance(batches, dict) else {}
    stored = stored if isinstance(stored, dict) else {}
    target_date = str(stored.get("target_date") or package.get("target_date") or package.get("date") or "")
    published_at = str(
        stored.get("published_at")
        or publication.get("published_at")
        or package.get("published_at")
        or package.get("generated_at")
        or ""
    )
    statuses = [str(result.get("status") or "pending") for _group, _selection, result in entries]
    starts = [
        value
        for value in (_selection_start_datetime(selection) for _group, selection, _result in entries)
        if value is not None
    ]
    status = _lifecycle_status(statuses, starts)
    analysis_mode = str(
        stored.get("analysis_mode")
        or publication.get("analysis_mode")
        or _package_analysis_mode(package, league)
    )
    return {
        "league": league,
        **_analysis_mode_metadata(analysis_mode),
        "target_date": target_date,
        "published_at": published_at,
        "status": status,
        "is_active": status != "settled",
        "game_ids": _package_game_ids(package, league),
        "recommendation_type": "pro",
    }


def _published_sort_key(metadata: dict | None) -> tuple[datetime, str]:
    metadata = metadata or {}
    parsed = _publication_datetime(metadata.get("published_at"))
    return parsed or datetime.min.replace(tzinfo=TAIPEI), str(metadata.get("target_date") or "")


def _publication_target_is_visible(metadata: dict | None, minimum_target_date: str | None = None) -> bool:
    if metadata is None:
        return False
    if not minimum_target_date:
        return True
    target = str(metadata.get("target_date") or "").strip()
    if not target:
        return False
    try:
        return date.fromisoformat(target) >= date.fromisoformat(minimum_target_date)
    except ValueError:
        return False


def _latest_record_for_league(
    records: list[dict],
    league: str,
    minimum_target_date: str | None = None,
) -> tuple[dict | None, dict | None]:
    candidates = [
        (record, metadata)
        for record in records
        if (metadata := _record_publication_metadata(record, league)) is not None
        and _publication_target_is_visible(metadata, minimum_target_date)
    ]
    return max(candidates, key=lambda item: _published_sort_key(item[1])) if candidates else (None, None)


def _latest_package_for_league(
    records: list[dict],
    league: str,
    minimum_target_date: str | None = None,
) -> tuple[dict | None, dict | None, dict | None]:
    candidates: list[tuple[dict, dict, dict]] = []
    for record in records:
        package = package_from_record(record)
        metadata = _package_publication_metadata(package, league)
        if metadata is not None and _publication_target_is_visible(metadata, minimum_target_date):
            candidates.append((record, package, metadata))
    return max(candidates, key=lambda item: _published_sort_key(item[2])) if candidates else (None, None, None)


def _free_feed_row(record: dict, league: str) -> dict | None:
    metadata = _record_publication_metadata(record, league)
    snapshot = record.get("prediction_snapshot")
    if metadata is None or not isinstance(snapshot, dict):
        return None
    result = _record_result_payload(record) or {"status": "pending"}
    return {
        **metadata,
        **_selection_schedule_metadata(snapshot),
        "matchup": record.get("matchup") or snapshot.get("matchup"),
        "pick_label": record.get("pick_label") or (snapshot.get("pick") or {}).get("label"),
        "market": record.get("market") or (snapshot.get("pick") or {}).get("market") or "moneyline",
        "confidence": record.get("confidence") if record.get("confidence") is not None else snapshot.get("confidence"),
        "start_at": (_selection_start_datetime(snapshot) or "").isoformat() if _selection_start_datetime(snapshot) else None,
        "result": result,
        "result_status": str(result.get("status") or "pending"),
    }


def _package_feed_rows(package: dict, league: str) -> list[dict]:
    metadata = _package_publication_metadata(package, league)
    if metadata is None:
        return []
    rows: list[dict] = []
    for group, selection, result in _package_entries(package, league):
        legs = [leg for leg in selection.get("legs") or [] if isinstance(leg, dict)]
        matchup = selection.get("matchup") or " ＋ ".join(str(leg.get("matchup") or "") for leg in legs if leg.get("matchup"))
        pick_label = (selection.get("pick") or {}).get("label") or selection.get("label")
        if not pick_label and legs:
            pick_label = " ＋ ".join(str((leg.get("pick") or {}).get("label") or "") for leg in legs)
        result_status = str(result.get("status") or "pending").lower()
        start = _selection_start_datetime(selection)
        item_status = _lifecycle_status([result_status], [start] if start else [])
        game_ids = [
            str(leg.get("game_pk"))
            for leg in legs
            if leg.get("game_pk") is not None
        ] or ([str(selection.get("game_pk"))] if selection.get("game_pk") is not None else [])
        if legs:
            leg_schedule = [
                value
                for value in (
                    _selection_schedule_metadata(leg).get("display_time_taiwan")
                    for leg in legs
                )
                if value
            ]
            schedule_metadata = {
                "time_taiwan": None,
                "display_time_taiwan": " / ".join(leg_schedule) if leg_schedule else None,
                "game_label": "",
                "game_number": None,
                "is_doubleheader": any(_selection_schedule_metadata(leg).get("is_doubleheader") for leg in legs),
            }
        else:
            schedule_metadata = _selection_schedule_metadata(selection)
        rows.append(
            {
                **metadata,
                **schedule_metadata,
                "status": item_status,
                "is_active": item_status != "settled",
                "recommendation_type": f"pro_{group}",
                "game_id": game_ids[0] if len(game_ids) == 1 else None,
                "game_ids": game_ids,
                "matchup": matchup,
                "pick_label": pick_label,
                "market": group,
                "confidence": selection.get("model_probability") if selection.get("model_probability") is not None else selection.get("confidence"),
                "price": selection.get("price") if selection.get("price") is not None else selection.get("combined_american_odds"),
                "start_at": start.isoformat() if start else None,
                "result": result,
                "result_status": result_status,
            }
        )
    return rows


def _social_free_payload(record: dict) -> dict:
    snapshot = record.get("prediction_snapshot") or {}
    game = snapshot.get("game") or {}
    pick = snapshot.get("pick") or {}
    away = game.get("away") or {}
    home = game.get("home") or {}
    away_name = display_team(
        away.get("name") or record.get("away_team_name"),
        away.get("abbr") or record.get("away_team_abbr"),
    )
    home_name = display_team(
        home.get("name") or record.get("home_team_name"),
        home.get("abbr") or record.get("home_team_abbr"),
    )
    pick_name = display_team(
        pick.get("team_name") or record.get("pick_team_name"),
        pick.get("abbr") or record.get("pick_team_abbr"),
    )
    away_score = record.get("away_score")
    home_score = record.get("home_score")
    score = None
    if away_score is not None and home_score is not None:
        score = f"{away_name} {away_score}：{home_score} {home_name}"
    raw_price = (
        pick.get("decimal_odds")
        or snapshot.get("decimal_odds")
        or pick.get("price")
        or snapshot.get("price")
    )
    publication = snapshot.get("publication") or {}
    return {
        "matchup": f"{away_name} vs {home_name}",
        "away_name": away_name,
        "home_name": home_name,
        "pick_team_name": pick_name,
        "pick_team_abbr": pick.get("abbr") or record.get("pick_team_abbr"),
        "pick_label": pick.get("label") or record.get("pick_label"),
        "market": pick.get("market") or record.get("market") or "moneyline",
        "line": pick.get("line") if pick.get("line") is not None else snapshot.get("line"),
        "side": pick.get("side") or snapshot.get("side"),
        "confidence": record.get("confidence") if record.get("confidence") is not None else snapshot.get("confidence"),
        "price": raw_price,
        "analysis_mode": publication.get("analysis_mode") or snapshot.get("analysis_mode") or _selection_analysis_mode(snapshot),
        "status": str(record.get("status") or "pending").lower(),
        "score": score,
        "time_label": snapshot.get("display_time_taiwan") or snapshot.get("time_taiwan"),
        "venue": record.get("venue") or game.get("venue"),
    }


def _social_selection_label(selection: dict, market: str) -> str:
    legs = [item for item in selection.get("legs") or [] if isinstance(item, dict)]
    if legs:
        values = [_social_selection_label(item, str((item.get("pick") or {}).get("market") or "moneyline")) for item in legs]
        return " ＋ ".join(value for value in values if value)
    pick = selection.get("pick") or {}
    payload = {
        "pick_label": pick.get("label") or selection.get("label"),
        "market": pick.get("market") or selection.get("market") or market,
        "pick_team_name": pick.get("team_name") or pick.get("team"),
        "pick_team_abbr": pick.get("abbr"),
        "line": pick.get("line") if pick.get("line") is not None else selection.get("line"),
        "side": pick.get("side") or selection.get("side"),
    }
    return compact_pick_label(payload)


def _social_selection_game_payload(selection: dict) -> dict | None:
    if not isinstance(selection, dict) or selection.get("legs"):
        return None
    game = selection.get("game") or {}
    away = game.get("away") or selection.get("away") or {}
    home = game.get("home") or selection.get("home") or {}
    away_name = display_team(
        away.get("name") or selection.get("away_team_name"),
        away.get("abbr") or selection.get("away_team_abbr"),
    )
    home_name = display_team(
        home.get("name") or selection.get("home_team_name"),
        home.get("abbr") or selection.get("home_team_abbr"),
    )
    matchup = str(selection.get("matchup") or game.get("matchup") or "").strip()
    if not matchup or matchup == "待確認 vs 待確認":
        matchup = f"{away_name} vs {home_name}"
    schedule = _selection_schedule_metadata(selection)
    confidence = (
        selection.get("model_probability")
        if selection.get("model_probability") is not None
        else selection.get("confidence")
    )
    game_id = selection.get("game_pk") or game.get("game_pk") or game.get("id")
    return {
        "game_id": str(game_id) if game_id is not None else None,
        "matchup": matchup,
        "time_label": schedule.get("display_time_taiwan") or schedule.get("time_taiwan"),
        "confidence": confidence,
        "start_at": (_selection_start_datetime(selection).isoformat() if _selection_start_datetime(selection) else None),
    }


def _social_pro_games(package: dict, league: str) -> list[dict]:
    selected = _package_for_league(package, league) or {}
    games: dict[str, dict] = {}
    order: list[str] = []
    selections: list[dict] = []
    for group in ("moneylines", "run_lines", "totals"):
        selections.extend(item for item in selected.get(group) or [] if isinstance(item, dict))
    for group in ("two_leg", "three_leg"):
        for parlay in (selected.get("parlays") or {}).get(group) or []:
            selections.extend(item for item in parlay.get("legs") or [] if isinstance(item, dict))
    for selection in selections:
        item = _social_selection_game_payload(selection)
        if not item:
            continue
        key = item.get("game_id") or item.get("matchup") or f"row-{len(order)}"
        if key not in games:
            games[key] = item
            order.append(key)
            continue
        existing = games[key]
        try:
            new_conf = float(item.get("confidence"))
        except (TypeError, ValueError):
            new_conf = -1.0
        try:
            old_conf = float(existing.get("confidence"))
        except (TypeError, ValueError):
            old_conf = -1.0
        if new_conf > old_conf:
            existing["confidence"] = item.get("confidence")
        if not existing.get("time_label") and item.get("time_label"):
            existing["time_label"] = item.get("time_label")
        if not existing.get("start_at") and item.get("start_at"):
            existing["start_at"] = item.get("start_at")
    values = [games[key] for key in order]
    values.sort(key=lambda item: str(item.get("start_at") or "9999"))
    return values


def _social_pro_page_count(package: dict, league: str, batch_size: int = 5) -> int:
    count = len(_social_pro_games(package, league))
    return max(1, math.ceil(count / max(1, batch_size))) if count else 0


def _social_category_summary(package: dict, league: str) -> tuple[dict, dict, dict]:
    categories = {
        "moneylines": {"won": 0, "lost": 0, "neutral": 0, "pending": 0},
        "run_lines": {"won": 0, "lost": 0, "neutral": 0, "pending": 0},
        "totals": {"won": 0, "lost": 0, "neutral": 0, "pending": 0},
        "parlays": {"won": 0, "lost": 0, "neutral": 0, "pending": 0},
    }
    overall = {"won": 0, "lost": 0, "neutral": 0, "pending": 0}
    parlay = {"won": 0, "lost": 0, "neutral": 0, "two_leg_odds": None, "three_leg_odds": None}
    odds_values: dict[str, list[float]] = {"two_leg": [], "three_leg": []}
    for group, selection, settlement in _package_entries(package, league):
        category = "parlays" if group in {"two_leg", "three_leg"} else group
        status = str(settlement.get("status") or "pending").lower()
        bucket = "neutral" if status in {"push", "void"} else status if status in {"won", "lost"} else "pending"
        categories[category][bucket] += 1
        overall[bucket] += 1
        if category == "parlays":
            parlay[bucket if bucket in {"won", "lost", "neutral"} else "neutral"] += 1 if bucket != "pending" else 0
            raw_odds = (
                selection.get("combined_decimal_odds")
                or selection.get("decimal_odds")
                or selection.get("combined_american_odds")
                or selection.get("price")
            )
            converted = decimal_price(raw_odds)
            if converted:
                odds_values[group].append(converted)
    for item in categories.values():
        decided = int(item["won"]) + int(item["lost"])
        item["hit_rate"] = round(int(item["won"]) / decided * 100, 1) if decided else None
    if odds_values["two_leg"]:
        parlay["two_leg_odds"] = f"{max(odds_values['two_leg']):.2f}"
    if odds_values["three_leg"]:
        parlay["three_leg_odds"] = f"{max(odds_values['three_leg']):.2f}"
    return categories, overall, parlay


def _social_score_text(selection: dict, settlement: dict) -> str:
    for value in (
        settlement.get("score"),
        settlement.get("final_score"),
        (settlement.get("result") or {}).get("score") if isinstance(settlement.get("result"), dict) else None,
    ):
        if value:
            return str(value)

    game = selection.get("game") or {}
    settled_game = settlement.get("game") or {}
    away = game.get("away") or selection.get("away") or {}
    home = game.get("home") or selection.get("home") or {}
    away_name = display_team(
        away.get("name") or selection.get("away_team_name"),
        away.get("abbr") or selection.get("away_team_abbr"),
    )
    home_name = display_team(
        home.get("name") or selection.get("home_team_name"),
        home.get("abbr") or selection.get("home_team_abbr"),
    )
    away_score = next(
        (
            value
            for value in (
                settlement.get("away_score"),
                settled_game.get("away_score"),
                ((settlement.get("linescore") or {}).get("away") if isinstance(settlement.get("linescore"), dict) else None),
                game.get("away_score"),
            )
            if value is not None
        ),
        None,
    )
    home_score = next(
        (
            value
            for value in (
                settlement.get("home_score"),
                settled_game.get("home_score"),
                ((settlement.get("linescore") or {}).get("home") if isinstance(settlement.get("linescore"), dict) else None),
                game.get("home_score"),
            )
            if value is not None
        ),
        None,
    )
    if away_score is not None and home_score is not None:
        return f"{away_name} {away_score}：{home_score} {home_name}"
    if selection.get("legs"):
        return "串關依各腿最終賽果完成結算"
    return "官方最終賽果已完成結算"


def _social_free_result_payload(record: dict | None) -> dict:
    if not record:
        return {}
    status = str(record.get("status") or "pending").lower()
    payload = _social_free_payload(record)
    return {
        "label": f"{payload.get('matchup') or '每日免費推薦'}｜{compact_pick_label(payload)}",
        "status": status,
        "status_label": status_label(status),
    }


def _social_free_result_item(record: dict | None) -> dict | None:
    if not record:
        return None
    status = str(record.get("status") or "pending").lower()
    if status not in SOCIAL_TERMINAL_STATUSES:
        return None
    payload = _social_free_payload(record)
    snapshot = record.get("prediction_snapshot") or {}
    return {
        "source": "free",
        "candidate_id": f"free:{record.get('id') or record.get('game_pk') or payload.get('matchup')}",
        "market": payload.get("market") or "moneyline",
        "label": compact_pick_label(payload),
        "matchup": payload.get("matchup") or "每日免費推薦",
        "score": payload.get("score") or _social_score_text(snapshot, record),
        "status": status,
        "status_label": status_label(status),
        "confidence": payload.get("confidence"),
        "time_label": payload.get("time_label"),
        "price": payload.get("price"),
        "analysis_mode": payload.get("analysis_mode"),
    }


def _social_result_items(package: dict, league: str, free_record: dict | None = None) -> list[dict]:
    items: list[dict] = []
    seen: set[tuple[str, str]] = set()
    free_item = _social_free_result_item(free_record)
    if free_item:
        items.append(free_item)
        seen.add((str(free_item.get("matchup") or ""), str(free_item.get("label") or "")))

    for group, selection, settlement in _package_entries(package, league):
        status = str(settlement.get("status") or "pending").lower()
        if status not in SOCIAL_TERMINAL_STATUSES:
            continue
        legs = [leg for leg in selection.get("legs") or [] if isinstance(leg, dict)]
        if legs:
            matchup = " ＋ ".join(str(leg.get("matchup") or "") for leg in legs if leg.get("matchup"))
            if not matchup:
                matchup = "多場串關"
        else:
            game_payload = _social_selection_game_payload(selection) or {}
            matchup = str(selection.get("matchup") or game_payload.get("matchup") or "賽事對戰")
        label = _social_selection_label(selection, group)
        identity = (matchup, label)
        if identity in seen:
            continue
        seen.add(identity)
        items.append(
            {
                "source": "pro",
                "candidate_id": str(selection.get("candidate_id") or f"{group}:{len(items)}"),
                "market": group,
                "label": label,
                "matchup": matchup,
                "score": _social_score_text(selection, settlement),
                "status": status,
                "status_label": status_label(status),
                "analysis_mode": selection.get("analysis_mode") or _selection_analysis_mode(selection),
            }
        )
    return items


def _social_league_settled(package: dict, league: str) -> bool:
    entries = _package_entries(package, league)
    return bool(entries) and all(
        str(settlement.get("status") or "pending").lower() in SOCIAL_TERMINAL_STATUSES
        for _group, _selection, settlement in entries
    )


def _social_reel_ready(package: dict, league: str, free_record: dict | None = None) -> bool:
    if not _social_league_settled(package, league):
        return False
    if free_record and str(free_record.get("status") or "pending").lower() not in SOCIAL_TERMINAL_STATUSES:
        return False
    return True


def _social_pro_payload(
    package: dict,
    league: str,
    *,
    result: bool = False,
    page: int = 1,
    batch_size: int = 5,
    free_record: dict | None = None,
) -> dict:
    if not result:
        games = _social_pro_games(package, league)
        batch_size = max(1, int(batch_size))
        total_pages = max(1, math.ceil(len(games) / batch_size)) if games else 1
        page = max(1, min(int(page), total_pages))
        start = (page - 1) * batch_size
        return {
            "items": games[start:start + batch_size],
            "page": page,
            "total_pages": total_pages,
            "total_games": len(games),
            "batch_size": batch_size,
        }
    _package_categories, _package_overall, parlay = _social_category_summary(package, league)
    items = _social_result_items(package, league, free_record)

    # V19.1.2: summary statistics must match the actual Reel cards. This counts
    # the separate free pick exactly once and avoids double-counting when that
    # same matchup/direction also exists in the Pro package.
    categories = {
        "moneylines": {"won": 0, "lost": 0, "neutral": 0, "pending": 0},
        "run_lines": {"won": 0, "lost": 0, "neutral": 0, "pending": 0},
        "totals": {"won": 0, "lost": 0, "neutral": 0, "pending": 0},
        "parlays": {"won": 0, "lost": 0, "neutral": 0, "pending": 0},
    }
    overall = {"won": 0, "lost": 0, "neutral": 0, "pending": 0}
    for item in items:
        status = str(item.get("status") or "pending").lower()
        bucket = "neutral" if status in {"push", "void"} else status if status in {"won", "lost"} else "pending"
        market = str(item.get("market") or "").lower()
        if market in {"moneyline", "moneylines"}:
            category = "moneylines"
        elif market in {"run_line", "run_lines"}:
            category = "run_lines"
        elif market == "totals":
            category = "totals"
        else:
            category = "parlays"
        categories[category][bucket] += 1
        overall[bucket] += 1

    for stat in categories.values():
        decided = int(stat.get("won") or 0) + int(stat.get("lost") or 0)
        stat["hit_rate"] = round(int(stat.get("won") or 0) / decided * 100.0, 1) if decided else None
    decided = int(overall.get("won") or 0) + int(overall.get("lost") or 0)
    overall["hit_rate"] = round(int(overall.get("won") or 0) / decided * 100.0, 1) if decided else None
    parlay["won"] = int(categories["parlays"].get("won") or 0)
    parlay["lost"] = int(categories["parlays"].get("lost") or 0)
    parlay["neutral"] = int(categories["parlays"].get("neutral") or 0)
    return {
        "categories": categories,
        "overall": overall,
        "parlay": parlay,
        "free_result": _social_free_result_payload(free_record),
        "items": items,
        "max_cards": max(1, int(getattr(settings, "instagram_reel_max_cards", 30))),
        "card_seconds": max(1.4, float(getattr(settings, "instagram_reel_card_seconds", 2.2))),
        "batch_seconds": max(2.4, float(getattr(settings, "instagram_reel_batch_seconds", 3.2))),
        "result_batch_size": max(1, min(int(getattr(settings, "instagram_pro_batch_size", 5)), 5)),
        "summary_seconds": max(3.0, float(getattr(settings, "instagram_reel_summary_seconds", 4.5))),
        "transition_seconds": max(0.08, float(getattr(settings, "instagram_reel_transition_seconds", 0.24))),
        "audio_enabled": bool(getattr(settings, "instagram_reel_audio_enabled", True)),
    }



def _line_free_marker(record: dict, key: str) -> dict:
    snapshot = record.get("prediction_snapshot") or {}
    publication = snapshot.get("publication") or {}
    markers = publication.get("line_notifications") or {}
    marker = markers.get(key) if isinstance(markers, dict) else None
    return marker if isinstance(marker, dict) else {}


def _line_package_marker(record: dict, key: str) -> dict:
    thresholds = record.get("thresholds") or {}
    publication = thresholds.get("publication") or {}
    markers = publication.get("line_notifications") or {}
    marker = markers.get(key) if isinstance(markers, dict) else None
    return marker if isinstance(marker, dict) else {}


def _line_marker_busy(marker: dict) -> bool:
    if str(marker.get("status") or "") != "sending":
        return False
    started = _publication_datetime(marker.get("started_at"))
    if started is None:
        return False
    return datetime.now(TAIPEI) - started.astimezone(TAIPEI) < timedelta(minutes=10)


async def _save_free_line_marker(
    request: Request,
    recommendation_date: str,
    league: str,
    key: str,
    marker: dict,
) -> dict | None:
    repository = records_repository(request)
    current = await repository.get_record_for_date(recommendation_date, league)
    if not current or current.get("id") is None:
        return None
    snapshot = deepcopy(current.get("prediction_snapshot") or {})
    publication = deepcopy(snapshot.get("publication") or {})
    markers = deepcopy(publication.get("line_notifications") or {})
    markers[key] = marker
    publication["line_notifications"] = markers
    snapshot["publication"] = publication
    return await repository.update_prediction_snapshot_by_id(current["id"], snapshot)


async def _save_package_line_marker(
    request: Request,
    recommendation_date: str,
    key: str,
    marker: dict,
) -> dict | None:
    repository = records_repository(request)
    current = await repository.get_prediction_package_for_date(recommendation_date)
    if not current or current.get("id") is None:
        return None
    thresholds = deepcopy(current.get("thresholds") or {})
    publication = deepcopy(thresholds.get("publication") or {})
    markers = deepcopy(publication.get("line_notifications") or {})
    markers[key] = marker
    publication["line_notifications"] = markers
    thresholds["publication"] = publication
    return await repository.update_prediction_package_thresholds(current["id"], thresholds)


def _line_event_is_recent(value: object, *, now: datetime | None = None) -> bool:
    parsed = _publication_datetime(value)
    if parsed is None:
        return False
    current = now or datetime.now(TAIPEI)
    if current.tzinfo is None:
        current = current.replace(tzinfo=TAIPEI)
    age = current.astimezone(TAIPEI) - parsed.astimezone(TAIPEI)
    return timedelta(minutes=-5) <= age <= timedelta(hours=settings.line_notification_max_age_hours)


def _line_links() -> str:
    lines = [f"查看完整內容：\n{settings.frontend_base_url}"]
    if settings.line_community_url:
        lines.append(f"加入 LINE 社群：\n{settings.line_community_url}")
    return "\n\n".join(lines)


def _line_publish_text(
    *,
    recommendation_date: str,
    league: str,
    kind: str,
    package: dict | None = None,
) -> str:
    if kind == "free":
        title = "📢 DiamondMind 每日免費精選已發布"
        detail = "內容：今日免費獨贏精選"
    else:
        selected = _package_for_league(package, league) or {}
        counts = {
            "獨贏": len(selected.get("moneylines") or []),
            "讓分": len(selected.get("run_lines") or []),
            "大小分": len(selected.get("totals") or []),
            "二關": len((selected.get("parlays") or {}).get("two_leg") or []),
            "三關": len((selected.get("parlays") or {}).get("three_leg") or []),
        }
        count_text = "｜".join(f"{label} {count}" for label, count in counts.items() if count)
        title = "💎 DiamondMind Pro 會員推薦已發布"
        detail = f"已更新：{count_text or '正式會員推薦'}"
    return (
        f"{title}\n\n"
        f"賽事日：{recommendation_date}\n"
        f"聯盟：{league}\n"
        f"{detail}\n\n"
        f"{_line_links()}\n\n"
        "所有分析僅供研究與娛樂參考，不保證獲利，請理性評估風險。"
    )


def _line_category_text(label: str, stat: dict) -> str:
    won = int(stat.get("won") or 0)
    lost = int(stat.get("lost") or 0)
    neutral = int(stat.get("neutral") or 0)
    pending = int(stat.get("pending") or 0)
    text = f"{label}｜{won} 中 {lost} 未中"
    if neutral:
        text += f"・{neutral} 走水／作廢"
    if pending:
        text += f"・{pending} 待結算"
    return text


def _line_settlement_summary(
    package: dict | None,
    league: str,
    free_record: dict | None,
) -> dict:
    if package and _package_has_league(package, league):
        payload = _social_pro_payload(package, league, result=True, free_record=free_record)
        return {
            "categories": payload.get("categories") or {},
            "overall": payload.get("overall") or {},
        }

    categories = {
        "moneylines": {"won": 0, "lost": 0, "neutral": 0, "pending": 0},
        "run_lines": {"won": 0, "lost": 0, "neutral": 0, "pending": 0},
        "totals": {"won": 0, "lost": 0, "neutral": 0, "pending": 0},
        "parlays": {"won": 0, "lost": 0, "neutral": 0, "pending": 0},
    }
    status = str((free_record or {}).get("status") or "pending").lower()
    bucket = "neutral" if status in {"push", "void"} else status if status in {"won", "lost"} else "pending"
    categories["moneylines"][bucket] += 1
    overall = {"won": 0, "lost": 0, "neutral": 0, "pending": 0}
    overall[bucket] += 1
    decided = overall["won"] + overall["lost"]
    overall["hit_rate"] = round(overall["won"] / decided * 100.0, 1) if decided else None
    return {"categories": categories, "overall": overall}


def _line_settlement_text(
    *,
    recommendation_date: str,
    league: str,
    package: dict | None,
    free_record: dict | None,
) -> str:
    summary = _line_settlement_summary(package, league, free_record)
    categories = summary.get("categories") or {}
    overall = summary.get("overall") or {}
    won = int(overall.get("won") or 0)
    lost = int(overall.get("lost") or 0)
    neutral = int(overall.get("neutral") or 0)
    decided = won + lost
    rate = overall.get("hit_rate")
    rate_text = f"{float(rate):.1f}%" if rate is not None else "—"
    total_text = f"有效推薦 {decided} 項，{won} 中 {lost} 未中，命中率 {rate_text}"
    if neutral:
        total_text += f"；另有 {neutral} 項走水／作廢"
    return (
        "✅ DiamondMind 賽後結算完成\n\n"
        f"賽事日：{recommendation_date}\n"
        f"聯盟：{league}\n\n"
        f"{_line_category_text('獨贏', categories.get('moneylines') or {})}\n"
        f"{_line_category_text('讓分', categories.get('run_lines') or {})}\n"
        f"{_line_category_text('大小分', categories.get('totals') or {})}\n"
        f"{_line_category_text('串關', categories.get('parlays') or {})}\n\n"
        f"今日{total_text}。\n\n"
        f"{_line_links()}\n\n"
        "走水／作廢不列入命中率。"
    )


async def _send_line_event(request: Request, event: dict) -> dict:
    scope = str(event.get("scope") or "free")
    key = str(event.get("event_key") or "")
    recommendation_date = str(event.get("recommendation_date") or "")
    league = str(event.get("league") or "MLB")
    record = event.get("record") or {}
    marker = (
        _line_package_marker(record, key)
        if scope == "package"
        else _line_free_marker(record, key)
    )
    if str(marker.get("status") or "") == "sent":
        return {"status": "already_sent", "event": key}
    if _line_marker_busy(marker):
        return {"status": "sending", "event": key}

    attempt = {
        "status": "sending",
        "event": key,
        "started_at": iso_utc(),
        "retry_key": line_service(request).retry_key(key),
        "attempts": int(marker.get("attempts") or 0) + 1,
    }
    saved = (
        await _save_package_line_marker(request, recommendation_date, key, attempt)
        if scope == "package"
        else await _save_free_line_marker(request, recommendation_date, league, key, attempt)
    )
    if not saved:
        return {"status": "failed", "event": key, "error": "無法保存 LINE 發送狀態"}

    try:
        delivery = await line_service(request).broadcast_text(
            str(event.get("text") or ""), event_key=key
        )
        completed = {
            **attempt,
            **delivery,
            "status": "sent",
            "finished_at": iso_utc(),
        }
        if scope == "package":
            await _save_package_line_marker(request, recommendation_date, key, completed)
        else:
            await _save_free_line_marker(request, recommendation_date, league, key, completed)
        return {"status": "sent", "event": key, "delivery": delivery}
    except (LineMessagingError, RecordsStorageError) as exc:
        failed = {
            **attempt,
            "status": "failed",
            "finished_at": iso_utc(),
            "error": f"{type(exc).__name__}: {str(exc)[:300]}",
        }
        try:
            if scope == "package":
                await _save_package_line_marker(request, recommendation_date, key, failed)
            else:
                await _save_free_line_marker(request, recommendation_date, league, key, failed)
        except RecordsStorageError:
            pass
        return {"status": "failed", "event": key, "error": str(exc)}


def _line_candidate_timestamp(value: object) -> datetime:
    return _publication_datetime(value) or datetime.min.replace(tzinfo=TAIPEI)


async def sync_line_notifications(request: Request, *, max_events: int | None = None) -> dict:
    service = line_service(request)
    if not service.enabled:
        result = {
            "enabled": False,
            "status": "disabled",
            "last_run": iso_utc(),
            "sent_now": 0,
            "failed_now": 0,
            "events": [],
            "configuration": service.status(),
        }
        request.app.state.line_status = result
        return result

    repository = records_repository(request)
    if not repository.enabled:
        raise RecordsStorageError("Recommendation records database is not configured")

    now = datetime.now(TAIPEI)
    cutoff = now.date() - timedelta(days=settings.line_retry_lookback_days)
    records = await repository.list_records(limit=max(settings.records_limit, 100))
    packages = await repository.list_prediction_packages(limit=max(settings.records_limit, 100))
    free_by_key: dict[tuple[str, str], dict] = {}
    for record in records:
        recommendation_date = str(record.get("recommendation_date") or "")
        try:
            record_date = date.fromisoformat(recommendation_date)
        except ValueError:
            continue
        if record_date < cutoff:
            continue
        league = str(record.get("league") or _selection_league(record.get("prediction_snapshot") or {})).upper()
        free_by_key[(recommendation_date, league)] = record

    package_by_date: dict[str, dict] = {}
    for record in packages:
        recommendation_date = str(record.get("recommendation_date") or "")
        try:
            record_date = date.fromisoformat(recommendation_date)
        except ValueError:
            continue
        if record_date >= cutoff:
            package_by_date[recommendation_date] = record

    candidates: list[dict] = []
    if settings.line_notify_free_publish:
        for (recommendation_date, league), record in free_by_key.items():
            published_at = record.get("published_at") or (record.get("prediction_snapshot") or {}).get("published_at")
            if not _line_event_is_recent(published_at, now=now):
                continue
            key = f"line:{recommendation_date}:{league}:free:published"
            if str(_line_free_marker(record, key).get("status") or "") == "sent":
                continue
            candidates.append({
                "scope": "free",
                "event_key": key,
                "recommendation_date": recommendation_date,
                "league": league,
                "timestamp": published_at,
                "record": record,
                "text": _line_publish_text(
                    recommendation_date=recommendation_date,
                    league=league,
                    kind="free",
                ),
            })

    if settings.line_notify_pro_publish:
        for recommendation_date, record in package_by_date.items():
            package = package_from_record(record)
            batches = (package.get("publication") or {}).get("league_batches") or {}
            for league in LEAGUES:
                if not _package_has_league(package, league):
                    continue
                metadata = batches.get(league) if isinstance(batches, dict) else {}
                published_at = (metadata or {}).get("published_at") or package.get("published_at")
                if not _line_event_is_recent(published_at, now=now):
                    continue
                key = f"line:{recommendation_date}:{league}:pro:published"
                if str(_line_package_marker(record, key).get("status") or "") == "sent":
                    continue
                candidates.append({
                    "scope": "package",
                    "event_key": key,
                    "recommendation_date": recommendation_date,
                    "league": league,
                    "timestamp": published_at,
                    "record": record,
                    "text": _line_publish_text(
                        recommendation_date=recommendation_date,
                        league=league,
                        kind="pro",
                        package=package,
                    ),
                })

    if settings.line_notify_settlement:
        keys = set(free_by_key)
        for recommendation_date, record in package_by_date.items():
            package = package_from_record(record)
            for league in LEAGUES:
                if _package_has_league(package, league):
                    keys.add((recommendation_date, league))
        for recommendation_date, league in keys:
            free_record = free_by_key.get((recommendation_date, league))
            package_record = package_by_date.get(recommendation_date)
            package = package_from_record(package_record) if package_record else None
            has_pro = bool(package and _package_has_league(package, league))
            has_free = free_record is not None
            if not has_free and not has_pro:
                continue
            free_ready = (not has_free) or str(free_record.get("status") or "pending").lower() in SOCIAL_TERMINAL_STATUSES
            pro_ready = (not has_pro) or _social_league_settled(package or {}, league)
            if not (free_ready and pro_ready):
                continue
            timestamps = []
            if free_record:
                timestamps.append(free_record.get("settled_at"))
            if package_record:
                timestamps.append(package_record.get("settled_at"))
            parsed = [value for value in timestamps if _publication_datetime(value) is not None]
            settled_at = max(parsed, key=_line_candidate_timestamp) if parsed else None
            if not _line_event_is_recent(settled_at, now=now):
                continue
            key = f"line:{recommendation_date}:{league}:settled"
            scope = "package" if has_pro and package_record else "free"
            marker_record = package_record if scope == "package" else free_record
            marker = (
                _line_package_marker(marker_record or {}, key)
                if scope == "package"
                else _line_free_marker(marker_record or {}, key)
            )
            if str(marker.get("status") or "") == "sent":
                continue
            candidates.append({
                "scope": scope,
                "event_key": key,
                "recommendation_date": recommendation_date,
                "league": league,
                "timestamp": settled_at,
                "record": marker_record,
                "text": _line_settlement_text(
                    recommendation_date=recommendation_date,
                    league=league,
                    package=package if has_pro else None,
                    free_record=free_record,
                ),
            })

    candidates.sort(key=lambda item: _line_candidate_timestamp(item.get("timestamp")))
    cap = max(1, min(int(max_events or settings.line_max_events_per_sync), 20))
    outcomes: list[dict] = []
    for event in candidates[:cap]:
        outcomes.append(await _send_line_event(request, event))
        await asyncio.sleep(0)

    sent_now = sum(1 for item in outcomes if item.get("status") == "sent")
    failed_now = sum(1 for item in outcomes if item.get("status") == "failed")
    last_error = next((str(item.get("error")) for item in reversed(outcomes) if item.get("error")), None)
    result = {
        "enabled": True,
        "status": "warning" if failed_now else "ready",
        "last_run": iso_utc(),
        "sent_now": sent_now,
        "failed_now": failed_now,
        "pending_candidates": max(0, len(candidates) - len(outcomes)),
        "events": outcomes,
        "last_error": last_error,
        "configuration": service.status(),
    }
    request.app.state.line_status = result
    return result


def _instagram_league_enabled(league: str) -> bool:
    code = str(league or "").upper()
    return bool({
        "MLB": getattr(settings, "instagram_auto_mlb_enabled", True),
        "NPB": getattr(settings, "instagram_auto_npb_enabled", True),
        "KBO": getattr(settings, "instagram_auto_kbo_enabled", True),
        "CPBL": getattr(settings, "instagram_auto_cpbl_enabled", True),
    }.get(code, False))


def _social_free_marker(record: dict, key: str) -> dict:
    snapshot = record.get("prediction_snapshot") or {}
    publication = snapshot.get("publication") or {}
    social = publication.get("social") or {}
    marker = social.get(key) if isinstance(social, dict) else None
    return marker if isinstance(marker, dict) else {}


def _social_package_marker(record: dict, key: str) -> dict:
    thresholds = record.get("thresholds") or {}
    publication = thresholds.get("publication") or {}
    social = publication.get("social") or {}
    marker = social.get(key) if isinstance(social, dict) else None
    return marker if isinstance(marker, dict) else {}


def _social_marker_busy(marker: dict) -> bool:
    if str(marker.get("status") or "") != "publishing":
        return False
    started = _publication_datetime(marker.get("started_at"))
    if started is None:
        return False
    return datetime.now(TAIPEI) - started.astimezone(TAIPEI) < timedelta(minutes=20)


async def _save_free_social_marker(
    request: Request,
    recommendation_date: str,
    league: str,
    key: str,
    marker: dict,
) -> dict | None:
    repository = records_repository(request)
    current = await repository.get_record_for_date(recommendation_date, league)
    if not current or current.get("id") is None:
        return None
    snapshot = deepcopy(current.get("prediction_snapshot") or {})
    publication = deepcopy(snapshot.get("publication") or {})
    social = deepcopy(publication.get("social") or {})
    social[key] = marker
    publication["social"] = social
    snapshot["publication"] = publication
    return await repository.update_prediction_snapshot_by_id(current["id"], snapshot)


async def _save_package_social_marker(
    request: Request,
    recommendation_date: str,
    key: str,
    marker: dict,
) -> dict | None:
    repository = records_repository(request)
    current = await repository.get_prediction_package_for_date(recommendation_date)
    if not current or current.get("id") is None:
        return None
    thresholds = deepcopy(current.get("thresholds") or {})
    publication = deepcopy(thresholds.get("publication") or {})
    social = deepcopy(publication.get("social") or {})
    social[key] = marker
    publication["social"] = social
    thresholds["publication"] = publication
    return await repository.update_prediction_package_thresholds(current["id"], thresholds)


async def _publish_free_social(
    request: Request,
    record: dict,
    phase: str,
) -> dict:
    social = social_service(request)
    if not social.enabled:
        return {"status": "disabled", "reason": "instagram_not_enabled"}
    league = str(record.get("league") or _selection_league(record.get("prediction_snapshot") or {})).upper()
    recommendation_date = str(record.get("recommendation_date") or "")
    if not recommendation_date:
        return {"status": "failed", "error": "推薦日期遺失"}
    if not _instagram_league_enabled(league):
        return {"status": "disabled", "reason": "league_policy"}
    if phase != "pregame":
        return {"status": "disabled", "reason": "free_result_is_in_reel"}
    if phase == "pregame" and not settings.instagram_post_free_pregame:
        return {"status": "disabled", "reason": "policy"}
    key = social_event_key("free", phase, league)
    current = await records_repository(request).get_record_for_date(recommendation_date, league)
    if not current:
        return {"status": "failed", "error": "找不到已發布免費推薦"}
    marker = _social_free_marker(current, key)
    if str(marker.get("status") or "") == "published":
        return {"status": "already_published", "event": key, "destinations": marker.get("destinations") or {}}
    if _social_marker_busy(marker):
        return {"status": "publishing", "event": key}

    attempt = {
        **marker,
        "status": "publishing",
        "event": key,
        "started_at": social_utc_now(),
        "attempts": int(marker.get("attempts") or 0) + 1,
        "destinations": deepcopy(marker.get("destinations") or {}),
    }
    if not await _save_free_social_marker(request, recommendation_date, league, key, attempt):
        return {"status": "failed", "event": key, "error": "無法先保存 Instagram 發佈狀態"}
    latest = await records_repository(request).get_record_for_date(recommendation_date, league)
    payload = _social_free_payload(latest or current)
    spec = SocialAssetSpec("free", phase, "feed", recommendation_date, league)
    result = await social.publish_pair(
        spec,
        payload,
        existing_destinations=attempt.get("destinations") or {},
    )
    completed = {**attempt, **result, "finished_at": social_utc_now()}
    await _save_free_social_marker(request, recommendation_date, league, key, completed)
    return completed


async def _publish_pro_social(
    request: Request,
    record: dict,
    phase: str,
    league: str,
) -> dict:
    social = social_service(request)
    if not social.enabled:
        return {"status": "disabled", "reason": "instagram_not_enabled"}
    league = league.upper()
    recommendation_date = str(record.get("recommendation_date") or "")
    if not recommendation_date:
        return {"status": "failed", "error": "推薦日期遺失"}
    if not _instagram_league_enabled(league):
        return {"status": "disabled", "reason": "league_policy"}
    package = package_from_record(record)
    if phase == "teaser" and not settings.instagram_post_pro_teaser:
        return {"status": "disabled", "reason": "policy"}
    if phase == "result" and not settings.instagram_post_pro_result:
        return {"status": "disabled", "reason": "policy"}
    if phase == "teaser" and not _package_has_league(package, league):
        return {"status": "pending", "reason": "league_not_published"}
    repository = records_repository(request)
    if phase == "result":
        free_for_readiness = await repository.get_record_for_date(recommendation_date, league)
        if not _social_reel_ready(package, league, free_for_readiness):
            return {"status": "pending", "reason": "league_settlement_not_terminal"}

    current = await repository.get_prediction_package_for_date(recommendation_date)
    if not current:
        return {"status": "failed", "error": "找不到已發布 Pro 推薦"}
    current_package = package_from_record(current)
    batch_size = max(1, int(getattr(settings, "instagram_pro_batch_size", 5)))
    page_count = _social_pro_page_count(current_package, league, batch_size) if phase == "teaser" else 1
    if phase == "teaser" and page_count < 1:
        return {"status": "pending", "reason": "no_games_to_publish"}

    outcomes: list[dict] = []
    for page in range(1, page_count + 1):
        key = social_event_key("pro", phase, league, page)
        latest_record = await repository.get_prediction_package_for_date(recommendation_date)
        if not latest_record:
            outcomes.append({"status": "failed", "event": key, "error": "找不到已發布 Pro 推薦"})
            continue
        marker = _social_package_marker(latest_record, key)
        if str(marker.get("status") or "") == "published":
            outcomes.append({"status": "already_published", "event": key, "page": page, "destinations": marker.get("destinations") or {}})
            continue
        if _social_marker_busy(marker):
            outcomes.append({"status": "publishing", "event": key, "page": page})
            continue

        attempt = {
            **marker,
            "status": "publishing",
            "event": key,
            "page": page,
            "total_pages": page_count,
            "started_at": social_utc_now(),
            "attempts": int(marker.get("attempts") or 0) + 1,
            "destinations": deepcopy(marker.get("destinations") or {}),
        }
        if not await _save_package_social_marker(request, recommendation_date, key, attempt):
            outcomes.append({"status": "failed", "event": key, "page": page, "error": "無法先保存 Instagram 發佈狀態"})
            continue

        newest = await repository.get_prediction_package_for_date(recommendation_date)
        newest_package = package_from_record(newest or latest_record)
        free_record = None
        if phase == "result":
            free_record = await repository.get_record_for_date(recommendation_date, league)
        payload = _social_pro_payload(
            newest_package,
            league,
            result=phase == "result",
            page=page,
            batch_size=batch_size,
            free_record=free_record,
        )
        spec = SocialAssetSpec("pro", phase, "feed", recommendation_date, league, page)
        result_payload = await social.publish_pair(
            spec,
            payload,
            existing_destinations=attempt.get("destinations") or {},
        )
        completed = {**attempt, **result_payload, "finished_at": social_utc_now()}
        await _save_package_social_marker(request, recommendation_date, key, completed)
        outcomes.append(completed)

    statuses = {str(item.get("status") or "") for item in outcomes}
    published_like = {"published", "already_published"}
    if outcomes and all(status in published_like for status in statuses):
        final_status = "published" if "published" in statuses else "already_published"
    elif any(status in published_like for status in statuses):
        final_status = "partial"
    elif "publishing" in statuses:
        final_status = "publishing"
    elif "failed" in statuses:
        final_status = "failed"
    else:
        final_status = next(iter(statuses), "pending")
    errors = [str(item.get("error")) for item in outcomes if item.get("error")]
    return {
        "status": final_status,
        "event": f"pro_{phase}_{league}",
        "league": league,
        "pages": outcomes,
        "published_pages": sum(1 for item in outcomes if item.get("status") == "published"),
        "total_pages": page_count,
        "error": " / ".join(errors[:3]) if errors else None,
        "finished_at": social_utc_now(),
    }

def _social_preview_urls(social: DiamondMindSocialService, spec: SocialAssetSpec) -> dict:
    if not social.asset_secret:
        return {"feed": None, "story": None, "reel": None}
    try:
        preview = {
            "feed": social.asset_url(
                SocialAssetSpec(spec.source, spec.phase, "feed", spec.recommendation_date, spec.league, spec.page),
                lifetime_seconds=3600,
            ),
            "story": social.asset_url(
                SocialAssetSpec(spec.source, spec.phase, "story", spec.recommendation_date, spec.league, spec.page),
                lifetime_seconds=3600,
            ),
            "reel": None,
        }
        if spec.source == "pro" and spec.phase == "result" and spec.league in {"MLB", "NPB"}:
            preview["reel"] = social.reel_url(
                SocialReelSpec(spec.recommendation_date, spec.league),
                lifetime_seconds=3600,
            )
        return preview
    except (TypeError, ValueError):
        return {"feed": None, "story": None, "reel": None}


async def _social_recent_events(request: Request, limit: int = 30) -> list[dict]:
    repository = records_repository(request)
    if not repository.enabled:
        return []
    free_records, package_records = await asyncio.gather(
        repository.list_records(limit=max(20, limit)),
        repository.list_prediction_packages(limit=max(20, limit)),
    )
    social = social_service(request)
    events: list[dict] = []
    free_lookup = {
        (str(record.get("recommendation_date") or ""), str(record.get("league") or "MLB").upper()): record
        for record in free_records
    }
    for record in free_records:
        recommendation_date = str(record.get("recommendation_date") or "")
        league = str(record.get("league") or "MLB").upper()
        if not _instagram_league_enabled(league):
            continue
        key = social_event_key("free", "pregame", league)
        marker = _social_free_marker(record, key)
        spec = SocialAssetSpec("free", "pregame", "feed", recommendation_date, league)
        events.append({
            "event": key,
            "source": "free",
            "phase": "pregame",
            "league": league,
            "date": recommendation_date,
            "template": "daily_free_card",
            "status": marker.get("status") or "waiting",
            "attempts": int(marker.get("attempts") or 0),
            "destinations": marker.get("destinations") or {},
            "errors": marker.get("errors") or [],
            "preview": _social_preview_urls(social, spec),
        })
    batch_size = max(1, int(getattr(settings, "instagram_pro_batch_size", 5)))
    for record in package_records:
        recommendation_date = str(record.get("recommendation_date") or "")
        package = package_from_record(record)
        for league in ("MLB", "NPB"):
            if not _instagram_league_enabled(league) or not _package_has_league(package, league):
                continue
            page_count = _social_pro_page_count(package, league, batch_size)
            for page in range(1, page_count + 1):
                key = social_event_key("pro", "teaser", league, page)
                marker = _social_package_marker(record, key)
                spec = SocialAssetSpec("pro", "teaser", "feed", recommendation_date, league, page)
                events.append({
                    "event": key,
                    "source": "pro",
                    "phase": "teaser",
                    "league": league,
                    "date": recommendation_date,
                    "page": page,
                    "total_pages": page_count,
                    "template": "five_game_batch",
                    "status": marker.get("status") or "waiting",
                    "attempts": int(marker.get("attempts") or 0),
                    "destinations": marker.get("destinations") or {},
                    "errors": marker.get("errors") or [],
                    "preview": _social_preview_urls(social, spec),
                })
            free_record = free_lookup.get((recommendation_date, league))
            if _social_reel_ready(package, league, free_record):
                key = social_event_key("pro", "result", league)
                marker = _social_package_marker(record, key)
                spec = SocialAssetSpec("pro", "result", "feed", recommendation_date, league)
                events.append({
                    "event": key,
                    "source": "pro",
                    "phase": "result",
                    "league": league,
                    "date": recommendation_date,
                    "template": "settlement_summary",
                    "status": marker.get("status") or "waiting",
                    "attempts": int(marker.get("attempts") or 0),
                    "destinations": marker.get("destinations") or {},
                    "errors": marker.get("errors") or [],
                    "preview": _social_preview_urls(social, spec),
                })
    events.sort(
        key=lambda item: (
            item.get("date") or "",
            item.get("phase") == "result",
            int(item.get("page") or 0),
        ),
        reverse=True,
    )
    return events[:limit]

async def sync_social_publications(request: Request, *, max_events: int | None = None) -> dict:
    social = social_service(request)
    if not social.enabled:
        result = {
            "ok": True,
            "status": "disabled",
            "last_run": social_utc_now(),
            "published_now": 0,
            "configuration": social.status(),
        }
        request.app.state.social_status = result
        return result
    repository = records_repository(request)
    if not repository.enabled:
        result = {
            "ok": False,
            "status": "failed",
            "last_run": social_utc_now(),
            "last_error": "records_not_configured",
            "published_now": 0,
        }
        request.app.state.social_status = result
        return result

    cap = max(1, min(int(max_events or settings.instagram_max_events_per_sync), 12))
    lookback = max(1, min(settings.instagram_retry_lookback_days, 7))
    now = datetime.now(TAIPEI)
    cutoff = now.date() - timedelta(days=lookback)
    upper = now.date() + timedelta(days=1)
    free_records, packages = await asyncio.gather(
        repository.list_records(limit=max(settings.records_limit, 100)),
        repository.list_prediction_packages(limit=max(settings.records_limit, 100)),
    )
    actions: list[dict] = []
    lead_seconds = max(0, int(getattr(settings, "instagram_story_lead_minutes", 60))) * 60
    free_lookup = {
        (str(record.get("recommendation_date") or ""), str(record.get("league") or "MLB").upper()): record
        for record in free_records
    }

    # Free picks are independent Story cards and show the full public direction.
    for record in free_records:
        try:
            target = date.fromisoformat(str(record.get("recommendation_date") or ""))
        except ValueError:
            continue
        status = str(record.get("status") or "pending").lower()
        league = str(record.get("league") or "MLB").upper()
        if not _instagram_league_enabled(league):
            continue
        marker = _social_free_marker(record, social_event_key("free", "pregame", league))
        if status == "pending" and now.date() <= target <= upper and marker.get("status") != "published":
            start_at = _selection_start_datetime(record.get("prediction_snapshot") or {})
            if start_at is not None:
                remaining = (start_at.astimezone(TAIPEI) - now).total_seconds()
                if 0 < remaining <= lead_seconds:
                    actions.append({"kind": "free", "phase": "pregame", "league": league, "record": record})

    batch_size = max(1, int(getattr(settings, "instagram_pro_batch_size", 5)))
    for record in packages:
        try:
            target = date.fromisoformat(str(record.get("recommendation_date") or ""))
        except ValueError:
            continue
        package = package_from_record(record)
        recommendation_date = str(record.get("recommendation_date") or "")
        for league in ("MLB", "NPB"):
            if not _instagram_league_enabled(league):
                continue
            entries = _package_entries(package, league)
            if not entries:
                continue
            free_record = free_lookup.get((recommendation_date, league))
            if cutoff <= target <= now.date() and _social_reel_ready(package, league, free_record):
                result_marker = _social_package_marker(record, social_event_key("pro", "result", league))
                if result_marker.get("status") != "published":
                    actions.append({"kind": "pro", "phase": "result", "league": league, "record": record})
            if now.date() <= target <= upper:
                starts = [_selection_start_datetime(selection) for _group, selection, _result in entries]
                future_starts = [value.astimezone(TAIPEI) for value in starts if value is not None]
                page_count = _social_pro_page_count(package, league, batch_size)
                pending_page = any(
                    _social_package_marker(record, social_event_key("pro", "teaser", league, page)).get("status") != "published"
                    for page in range(1, page_count + 1)
                )
                if page_count and future_starts and pending_page:
                    remaining = (min(future_starts) - now).total_seconds()
                    if 0 < remaining <= lead_seconds:
                        actions.append({"kind": "pro", "phase": "teaser", "league": league, "record": record})

    actions.sort(
        key=lambda item: (
            str((item.get("record") or {}).get("recommendation_date") or ""),
            item.get("phase") == "result",
        ),
        reverse=True,
    )
    processed: list[dict] = []
    published_now = 0
    failures: list[str] = []
    for action in actions:
        if len(processed) >= cap:
            break
        try:
            if action["kind"] == "free":
                outcome = await _publish_free_social(request, action["record"], "pregame")
            else:
                outcome = await _publish_pro_social(request, action["record"], action["phase"], action["league"])
        except (RecordsStorageError, SocialPublishingError) as exc:
            outcome = {"status": "failed", "error": str(exc)}
        processed.append({
            "event": outcome.get("event"),
            "kind": action["kind"],
            "phase": action["phase"],
            "league": action.get("league") or action["record"].get("league"),
            "status": outcome.get("status"),
            "published_pages": int(outcome.get("published_pages") or (1 if outcome.get("status") == "published" else 0)),
        })
        published_now += int(outcome.get("published_pages") or (1 if outcome.get("status") == "published" else 0))
        if outcome.get("status") == "failed":
            failures.append(str(outcome.get("error") or "Instagram publish failed"))
    result = {
        "ok": not failures,
        "status": "running" if not failures else "warning",
        "last_run": social_utc_now(),
        "last_error": " / ".join(failures[:3]) if failures else None,
        "published_now": published_now,
        "processed": processed,
    }
    request.app.state.social_status = result
    return result

async def social_dashboard(request: Request) -> dict:
    recent = await _social_recent_events(request)
    waiting = sum(1 for item in recent if item.get("status") in {"waiting", "failed", "partial"})
    failed = sum(1 for item in recent if item.get("status") in {"failed", "partial"})
    return {
        "configuration": social_service(request).status(),
        "monitor": request.app.state.social_status,
        "summary": {
            "events": len(recent),
            "published": sum(1 for item in recent if item.get("status") == "published"),
            "waiting": waiting,
            "failed": failed,
        },
        "rules": {
            "free_pregame": "每日免費推薦獨立一則限動，公開完整方向",
            "pro_pregame": "Pro 每 5 場一則限動，只顯示對戰、時間與信心，不公開方向",
            "results": "MLB、NPB 各自在全數結算後產生單場卡＋總結卡 Reel，並同步顯示於貼文牆",
            "formats": ["1080x1920 story", "1080x1920 H.264 reel"],
        },
        "events": recent,
    }


@app.get(f"{settings.api_prefix}/social/assets/{{source}}/{{recommendation_date}}/{{league}}/{{phase}}/{{size}}.jpg")
async def social_asset(
    request: Request,
    source: str,
    recommendation_date: str,
    league: str,
    phase: str,
    size: str,
    page: int = Query(default=1, ge=1, le=99),
    expires: int = Query(...),
    signature: str = Query(..., min_length=32, max_length=128),
) -> Response:
    try:
        spec = SocialAssetSpec(source, phase, size, recommendation_date, league, page).validated()
    except (TypeError, ValueError) as exc:
        raise HTTPException(status_code=404, detail="Social image was not found") from exc
    social = social_service(request)
    if not social.verify_asset(spec, expires, signature):
        raise HTTPException(status_code=403, detail="Social image link is invalid or expired")
    repository = records_repository(request)
    if spec.source == "free":
        if spec.phase != "pregame" or spec.league == "ALL" or spec.page != 1:
            raise HTTPException(status_code=404, detail="Social image was not found")
        record = await repository.get_record_for_date(spec.recommendation_date, spec.league)
        if not record:
            raise HTTPException(status_code=404, detail="Published recommendation was not found")
        payload = _social_free_payload(record)
    else:
        if spec.phase not in {"teaser", "result"} or spec.league not in {"MLB", "NPB"}:
            raise HTTPException(status_code=404, detail="Social image was not found")
        record = await repository.get_prediction_package_for_date(spec.recommendation_date)
        if not record:
            raise HTTPException(status_code=404, detail="Published Pro package was not found")
        package = package_from_record(record)
        if spec.phase == "teaser":
            if not _package_has_league(package, spec.league):
                raise HTTPException(status_code=404, detail="Published Pro league was not found")
            batch_size = max(1, int(getattr(settings, "instagram_pro_batch_size", 5)))
            page_count = _social_pro_page_count(package, spec.league, batch_size)
            if spec.page > page_count:
                raise HTTPException(status_code=404, detail="Published Pro batch was not found")
            payload = _social_pro_payload(
                package, spec.league, page=spec.page, batch_size=batch_size
            )
        else:
            free_record = await repository.get_record_for_date(spec.recommendation_date, spec.league)
            if spec.page != 1 or not _social_reel_ready(package, spec.league, free_record):
                raise HTTPException(status_code=409, detail="League package has not reached a final result")
            payload = _social_pro_payload(
                package, spec.league, result=True, free_record=free_record
            )
    try:
        content = await asyncio.to_thread(social.render, spec, payload)
    except (OSError, ValueError) as exc:
        raise HTTPException(status_code=500, detail="Social image rendering failed") from exc
    return Response(
        content=content,
        media_type="image/jpeg",
        headers={
            "Cache-Control": "public, max-age=300",
            "Content-Disposition": f'inline; filename="diamondmind-{spec.source}-{spec.phase}-{spec.league}-p{spec.page}-{spec.size}.jpg"',
        },
    )


@app.get(f"{settings.api_prefix}/social/reels/{{recommendation_date}}/{{league}}.mp4")
async def social_reel(
    request: Request,
    recommendation_date: str,
    league: str,
    expires: int = Query(...),
    signature: str = Query(..., min_length=32, max_length=128),
) -> FileResponse:
    try:
        spec = SocialReelSpec(recommendation_date, league).validated()
    except (TypeError, ValueError) as exc:
        raise HTTPException(status_code=404, detail="Social Reel was not found") from exc
    social = social_service(request)
    if not social.verify_reel(spec, expires, signature):
        raise HTTPException(status_code=403, detail="Social Reel link is invalid or expired")
    repository = records_repository(request)
    record = await repository.get_prediction_package_for_date(spec.recommendation_date)
    if not record:
        raise HTTPException(status_code=404, detail="Published Pro package was not found")
    package = package_from_record(record)
    free_record = await repository.get_record_for_date(spec.recommendation_date, spec.league)
    if not _social_reel_ready(package, spec.league, free_record):
        raise HTTPException(status_code=409, detail="League package has not reached a final result")
    payload = _social_pro_payload(package, spec.league, result=True, free_record=free_record)
    try:
        path = await asyncio.to_thread(social.render_reel_file, spec, payload)
    except (OSError, ValueError, SocialPublishingError) as exc:
        raise HTTPException(status_code=500, detail=f"Social Reel rendering failed: {exc}") from exc
    return FileResponse(
        path=str(path),
        media_type="video/mp4",
        filename=f"diamondmind-{spec.recommendation_date}-{spec.league}-results.mp4",
        headers={"Cache-Control": "public, max-age=300"},
    )


@app.get(f"{settings.api_prefix}/admin/social/status")
async def admin_social_status(
    request: Request,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    await admin_member(request, authorization)
    try:
        return await social_dashboard(request)
    except RecordsStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


@app.post(f"{settings.api_prefix}/admin/social/sync")
async def admin_social_sync(
    request: Request,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    await admin_member(request, authorization)
    try:
        sync = await sync_social_publications(request)
        return {
            "ok": bool(sync.get("ok")),
            "sync": sync,
            "dashboard": await social_dashboard(request),
            "message": "Instagram 自動發佈同步完成。" if sync.get("ok") else "同步完成，但仍有項目等待重試。",
        }
    except RecordsStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


class LineTestBroadcast(BaseModel):
    confirm: bool = False
    message: str | None = None


@app.get(f"{settings.api_prefix}/admin/line/status")
async def admin_line_status(
    request: Request,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    await admin_member(request, authorization)
    return {
        "ok": True,
        "configuration": line_service(request).status(),
        "runtime": dict(getattr(request.app.state, "line_status", {}) or {}),
    }


@app.post(f"{settings.api_prefix}/admin/line/sync")
async def admin_line_sync(
    request: Request,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    await admin_member(request, authorization)
    try:
        result = await sync_line_notifications(request)
    except RecordsStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    return {
        "ok": int(result.get("failed_now") or 0) == 0,
        "sync": result,
        "message": "LINE 通知同步完成。" if not result.get("failed_now") else "LINE 同步完成，但仍有通知等待重試。",
    }


@app.post(f"{settings.api_prefix}/admin/line/test")
async def admin_line_test(
    request: Request,
    command: LineTestBroadcast,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    await admin_member(request, authorization)
    if not command.confirm:
        raise HTTPException(status_code=409, detail="請確認後再發送；這會廣播給所有已加入官方帳號的好友。")
    service = line_service(request)
    if not service.enabled:
        raise HTTPException(status_code=503, detail="LINE Messaging API 尚未完成設定")
    message = (command.message or "").strip() or (
        "✅ DiamondMind LINE 自動通知測試成功\n\n"
        "推薦發布與賽後結算完成後，系統將由官方帳號自動發送通知。\n\n"
        f"官方網站：\n{settings.frontend_base_url}"
    )
    try:
        result = await service.broadcast_text(
            message,
            event_key=f"manual-test:{datetime.now(TAIPEI).strftime('%Y%m%d%H%M%S')}",
        )
    except LineMessagingError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    return {"ok": True, "delivery": result, "message": "測試通知已交給 LINE 平台。"}


@app.get(f"{settings.api_prefix}/predictions/top")
async def top_prediction(
    request: Request,
    prediction_date: date | None = Query(default=None, alias="date", description="Taiwan date, YYYY-MM-DD"),
    league: str = Query(default="MLB", pattern="^(MLB|NPB|KBO|CPBL)$"),
    latest: bool = Query(default=False, description="Return the latest formally published pick, regardless of target date"),
) -> dict:
    league = _prediction_league(league)
    if latest:
        repository = records_repository(request)
        if repository.enabled:
            try:
                records = await repository.list_records(limit=max(settings.records_limit, 100))
            except RecordsStorageError as exc:
                raise HTTPException(status_code=503, detail=str(exc)) from exc
            record, metadata = _latest_record_for_league(records, league)
            if record and metadata:
                snapshot = deepcopy(record.get("prediction_snapshot") or {})
                snapshot["result"] = _record_result_payload(record) or {"status": "pending"}
                return {
                    "date": metadata["target_date"],
                    "target_date": metadata["target_date"],
                    "published_at": metadata["published_at"],
                    "status": metadata["status"],
                    "league": league,
                    "published": True,
                    "selection": _free_pick_for_member(snapshot),
                    "message": f"已載入 {league} 最近一次正式發布的免費精選。",
                }
        return {
            "date": None,
            "target_date": None,
            "published_at": None,
            "status": None,
            "league": league,
            "published": False,
            "selection": None,
            "message": f"{league} 尚無已正式發布的免費精選。",
        }
    target_date = requested_date(prediction_date)
    if league in {"NPB", "KBO", "CPBL"}:
        repository = records_repository(request)
        selection = None
        if repository.enabled:
            try:
                record = await repository.get_record_for_date(target_date.isoformat(), league)
            except RecordsStorageError as exc:
                raise HTTPException(status_code=503, detail=str(exc)) from exc
            snapshot = record.get("prediction_snapshot") if isinstance(record, dict) else None
            if isinstance(snapshot, dict) and _selection_matches_league(snapshot, league):
                selection = deepcopy(snapshot)
                selection["result"] = _record_result_payload(record) or {"status": "pending"}
        return {
            "date": target_date.isoformat(),
            "league": league,
            "published": bool(selection),
            "selection": _free_pick_for_member(selection) if selection else None,
            "message": f"今日 {league} 每日免費精選尚未正式發布。" if not selection else f"今日 {league} 每日免費精選已正式發布。",
        }
    try:
        payload = await prediction_with_persistence(request, target_date, publish_if_eligible=False)
        return {**_public_prediction_response(payload), "league": league}
    except MLBUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


def _record_result_payload(record: dict | None) -> dict | None:
    if not isinstance(record, dict):
        return None
    status = str(record.get("status") or "pending")
    return {
        "status": status,
        "away_score": record.get("away_score"),
        "home_score": record.get("home_score"),
        "result_note": record.get("result_note"),
        "settled_at": record.get("settled_at"),
    }


@app.get(f"{settings.api_prefix}/predictions/daily")
async def daily_predictions_for_member(
    request: Request,
    prediction_date: date | None = Query(default=None, alias="date", description="Taiwan date, YYYY-MM-DD"),
    league: str = Query(default="MLB", pattern="^(MLB|NPB|KBO|CPBL)$"),
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    member = await authenticated_member(request, authorization)
    league = _prediction_league(league)

    target_date = requested_date(prediction_date)
    repository = records_repository(request)
    # V20.2.5: this member endpoint is read-only. Automatic settlement runs in
    # the deduplicated background job so KBO/CPBL/NPB/MLB score lookups can
    # never delay the member response or Render health check.
    try:
        stored = await repository.get_prediction_package_for_date(target_date.isoformat())
        public_record = await repository.get_record_for_date(target_date.isoformat(), league)
    except RecordsStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc

    # The selected league's public daily record is the source of truth for the
    # large free-pick card. It may have been selected by the founder and must never
    # be replaced by the convenience ``moneyline`` snapshot embedded in a Pro
    # package. The package snapshot is only a fallback for legacy dates.
    public_snapshot = (
        public_record.get("prediction_snapshot")
        if public_record and isinstance(public_record.get("prediction_snapshot"), dict)
        else None
    )
    if public_snapshot and not _selection_matches_league(public_snapshot, league):
        public_snapshot = None

    moneyline = public_snapshot
    if stored:
        raw_package = package_from_record(stored)
        package = _package_for_league(raw_package, league)
        if not _package_has_league(raw_package, league):
            package = None
    else:
        package = None

    is_founder = member.get("role") == "admin"
    watchlist: dict[str, list[dict]] = {
        "moneylines": [],
        "run_lines": [],
        "totals": [],
    }
    watchlist_message = None
    if is_founder and package and isinstance(package.get("watchlist"), dict):
        watchlist = package.get("watchlist") or watchlist
    elif is_founder:
        # Observation candidates are founder-only internal review data. They
        # are never returned to free or Pro members, even though Pro members
        # may access the formally published recommendation package.
        try:
            live_bundle = await founder_market_candidate_bundle(request, target_date, league)
            watchlist = live_bundle.get("watchlist") or watchlist
        except HTTPException as exc:
            detail = exc.detail
            watchlist_message = (
                detail.get("message")
                if isinstance(detail, dict)
                else str(detail or "觀察名單暫時無法更新。")
            )

    formal_groups = {
        "moneylines": package.get("moneylines") if package else [],
        "run_lines": package.get("run_lines") if package else [],
        "totals": package.get("totals") if package else [],
        "two_leg": ((package.get("parlays") or {}).get("two_leg") if package else []),
        "three_leg": ((package.get("parlays") or {}).get("three_leg") if package else []),
    }
    formal_count = sum(len(items or []) for items in formal_groups.values())
    if not is_founder:
        formal_groups = {
            key: [
                _selection_for_member(item, founder=False)
                for item in (items or [])
                if isinstance(item, dict)
            ]
            for key, items in formal_groups.items()
        }
    moneyline = _free_pick_for_member(moneyline, founder=is_founder)
    if isinstance(moneyline, dict) and public_record:
        moneyline["result"] = _record_result_payload(public_record)
    watchlist_count = sum(len(items or []) for items in watchlist.values()) if is_founder else 0
    recommendation_status = (
        "formal_published"
        if formal_count
        else "founder_watchlist_only"
        if is_founder and watchlist_count
        else "no_recommendation"
    )
    if formal_count:
        message = f"今日 {league} 正式 Pro 推薦已載入。"
    elif is_founder and watchlist_count:
        message = f"今日 {league} 無正式 Pro 推薦；目前有創辦人內部觀察候選。"
    else:
        message = f"今日 {league} 沒有玩法通過正式發布門檻。"
        if is_founder and watchlist_message:
            message = watchlist_message

    candidate_counts = package.get("candidate_counts") if package else {}
    if not is_founder and isinstance(candidate_counts, dict):
        candidate_counts = {
            key: value
            for key, value in candidate_counts.items()
            if not str(key).startswith("watch_")
        }

    response = {
        "date": target_date.isoformat(),
        "league": league,
        "published": bool(package or moneyline),
        "locked": bool(package),
        "member": {"role": member["role"], "has_pro_access": member["has_pro_access"]},
        "moneyline": moneyline,
        "pro_access": "granted" if member["has_pro_access"] else "locked",
        "recommendation_status": recommendation_status,
        "formal_recommendation_count": formal_count,
        "watchlist_count": watchlist_count,
        "message": message,
    }
    if member["has_pro_access"]:
        response.update(
            {
                "moneylines": formal_groups["moneylines"],
                "run_lines": formal_groups["run_lines"],
                "totals": formal_groups["totals"],
                "parlays": {
                    "two_leg": formal_groups["two_leg"],
                    "three_leg": formal_groups["three_leg"],
                },
                # V14-compatible aliases during the transition.
                "run_line": (formal_groups["run_lines"] or [None])[0],
                "total": (formal_groups["totals"] or [None])[0],
                "candidate_counts": candidate_counts,
                "thresholds": package.get("thresholds") if package else {},
                "limits": package.get("limits") if package else {},
                "publication": package.get("publication") if package else {},
                "settled": package.get("settled") if package else False,
                "results": package.get("results") if package else {},
            }
        )
        if is_founder:
            response["watchlist"] = watchlist
            response["watchlist_message"] = watchlist_message
    return response


@app.get(f"{settings.api_prefix}/predictions/latest")
async def latest_predictions_for_member(
    request: Request,
    league: str = Query(default="MLB", pattern="^(MLB|NPB|KBO|CPBL)$"),
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    """Return the latest founder-published batch without a calendar-day gate.

    ``target_date`` remains the game date, while ``published_at`` controls what
    members see first.  Publishing tomorrow's MLB slate tonight therefore
    updates the MLB tab immediately and does not replace an independently
    published NPB batch.
    """

    member = await authenticated_member(request, authorization)
    league = _prediction_league(league)
    repository = records_repository(request)
    if not repository.enabled:
        raise HTTPException(status_code=503, detail="Recommendation database is not configured")

    # V20.2.5: latest recommendations are a pure cached database read.
    # Settlement is never executed from a browser polling request.

    try:
        records = await repository.list_records(limit=max(settings.records_limit, 100))
        package_records = await repository.list_prediction_packages(limit=max(settings.records_limit, 100))
    except RecordsStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc

    today = datetime.now(TAIPEI).date().isoformat()
    # Current recommendation cards may show today's slate or a future slate that
    # the founder published early, but they must never fall back to a past date.
    # Past batches remain available in the recommendation feed and records page.
    public_record, free_batch = _latest_record_for_league(records, league, today)
    _package_record, raw_package, pro_batch = _latest_package_for_league(package_records, league, today)
    package = _package_for_league(raw_package, league) if raw_package else None

    is_founder = member.get("role") == "admin"
    public_snapshot = (
        deepcopy(public_record.get("prediction_snapshot"))
        if public_record and isinstance(public_record.get("prediction_snapshot"), dict)
        else None
    )
    if public_snapshot and public_record:
        public_snapshot["result"] = _record_result_payload(public_record) or {"status": "pending"}
    moneyline = _free_pick_for_member(public_snapshot, founder=is_founder)

    formal_groups = {
        "moneylines": list(package.get("moneylines") or []) if package else [],
        "run_lines": list(package.get("run_lines") or []) if package else [],
        "totals": list(package.get("totals") or []) if package else [],
        "two_leg": list((package.get("parlays") or {}).get("two_leg") or []) if package else [],
        "three_leg": list((package.get("parlays") or {}).get("three_leg") or []) if package else [],
    }
    formal_count = sum(len(values) for values in formal_groups.values())
    if not is_founder:
        formal_groups = {
            key: [
                _selection_for_member(selection, founder=False)
                for selection in values
                if isinstance(selection, dict)
            ]
            for key, values in formal_groups.items()
        }

    feed_rows = [
        row
        for record in records
        if (row := _free_feed_row(record, league)) is not None
    ]
    if member.get("has_pro_access"):
        for package_record in package_records:
            candidate = package_from_record(package_record)
            feed_rows.extend(_package_feed_rows(candidate, league))

    current = [
        row
        for row in feed_rows
        if row.get("target_date") == today and row.get("status") in {"published", "live"}
    ]
    current.sort(
        key=lambda row: _publication_datetime(row.get("start_at"))
        or _publication_datetime(row.get("published_at"))
        or datetime.max.replace(tzinfo=TAIPEI)
    )
    history = [row for row in feed_rows if row.get("status") == "settled"]
    history.sort(
        key=lambda row: _publication_datetime((row.get("result") or {}).get("settled_at"))
        or _publication_datetime(row.get("published_at"))
        or datetime.min.replace(tzinfo=TAIPEI),
        reverse=True,
    )
    history = history[:10]

    visible_batches = [metadata for metadata in (free_batch, pro_batch if member.get("has_pro_access") else None) if metadata]
    latest_batch = max(visible_batches, key=_published_sort_key) if visible_batches else None
    visible_formal_count = formal_count if member.get("has_pro_access") else 0
    target_date = (
        ((pro_batch or {}).get("target_date") if member.get("has_pro_access") else None)
        or (free_batch or {}).get("target_date")
    )
    published_at = (
        (latest_batch or {}).get("published_at")
        if latest_batch
        else None
    )
    if visible_formal_count:
        message = f"已載入 {league} 最近一次正式發布的 Pro 推薦。"
    elif moneyline:
        message = f"已載入 {league} 最近一次正式發布的免費精選。"
    else:
        message = f"{league} 尚無已正式發布的推薦。"

    response = {
        "date": target_date,
        "target_date": target_date,
        "published_at": published_at,
        "status": (latest_batch or {}).get("status"),
        "league": league,
        "published": bool(moneyline or visible_formal_count),
        "locked": bool(visible_formal_count),
        "member": {"role": member["role"], "has_pro_access": member["has_pro_access"]},
        "moneyline": moneyline,
        "free_batch": free_batch,
        "pro_access": "granted" if member["has_pro_access"] else "locked",
        "recommendation_status": "formal_published" if visible_formal_count else "no_recommendation",
        "formal_recommendation_count": visible_formal_count,
        "message": message,
        "feed": {
            "league": league,
            "latest": latest_batch,
            "current": current,
            "history": history,
        },
    }
    if member["has_pro_access"]:
        response.update(
            {
                "pro_batch": pro_batch,
                "moneylines": formal_groups["moneylines"],
                "run_lines": formal_groups["run_lines"],
                "totals": formal_groups["totals"],
                "parlays": {
                    "two_leg": formal_groups["two_leg"],
                    "three_leg": formal_groups["three_leg"],
                },
                "run_line": (formal_groups["run_lines"] or [None])[0],
                "total": (formal_groups["totals"] or [None])[0],
                "candidate_counts": package.get("candidate_counts") if package else {},
                "thresholds": package.get("thresholds") if package else {},
                "limits": package.get("limits") if package else {},
                "publication": package.get("publication") if package else {},
                "settled": (pro_batch or {}).get("status") == "settled",
                "results": package.get("results") if package else {},
            }
        )
        if is_founder and package:
            response["watchlist"] = package.get("watchlist") or {}
    if not is_founder:
        response = _strip_member_financials(response)
    return response


class FounderPredictionPublish(BaseModel):
    date: date
    game_pk: str | int
    league: str = "MLB"
    confirm_warning: bool = False


def founder_candidate(analysis: dict) -> dict:
    """Return the founder-facing publication policy for one matchup."""

    game = analysis.get("game") or {}
    context = str(game.get("season_context") or "unsupported")
    confidence = float(analysis.get("confidence") or 0)
    data_quality = float(analysis.get("data_quality") or 0)
    policy = publication_policy(analysis, automatic=False)
    return {
        "game_pk": analysis.get("game_pk"),
        "league": _selection_league(analysis),
        "matchup": analysis.get("matchup"),
        "time_taiwan": analysis.get("time_taiwan"),
        "display_time_taiwan": analysis.get("display_time_taiwan") or game.get("display_time_taiwan"),
        "game_label": analysis.get("game_label") or game.get("game_label") or "",
        "game_number": analysis.get("game_number") if analysis.get("game_number") is not None else game.get("game_number"),
        "is_doubleheader": bool(analysis.get("is_doubleheader") or game.get("is_doubleheader")),
        "venue": game.get("venue"),
        "event": {
            "game_type": game.get("game_type"),
            "context": context,
            "label": game.get("event_label") or "例行賽",
            "special": bool(game.get("special_event")),
        },
        "pick": analysis.get("pick"),
        "confidence": confidence,
        "data_quality": data_quality,
        "warnings": policy["warnings"],
        "blockers": policy["blockers"],
        "can_publish": policy["can_publish"],
        "auto_publish_ready": policy["auto_publish_ready"],
        "requires_confirmation": policy["requires_confirmation"],
        "timing": policy["timing"],
        "checklist": policy["checklist"],
        "roster_validation": policy["roster_validation"],
        "lineup_validation_rate": policy["lineup_validation_rate"],
        "updated_at": (analysis.get("data_freshness") or {}).get("generated_at"),
    }


def founder_asian_candidate(selection: dict, league: str | None = None) -> dict:
    game = selection.get("game") or {}
    code = str(league or selection.get("league") or game.get("league") or "NPB").upper()
    starters = ((selection.get("analysis_groups") or {}).get("starter") or {})
    pick = selection.get("pick") or {}
    confidence = float(selection.get("confidence") or selection.get("model_probability") or 0)
    data_quality = float(selection.get("data_quality") or 0)
    model_stage = str(selection.get("model_stage") or "").lower()
    if model_stage not in {"base", "full"}:
        model_stage = "full" if starters.get("both_starters_ready") is True else "base"
    advisory_confidence = 54.0 if model_stage == "base" else 56.0
    advisory_data_quality = 0.55 if model_stage == "base" else 0.65
    status = str(game.get("status") or "upcoming").lower()
    game_id = selection.get("game_pk") or game.get("game_pk") or game.get("external_game_id")
    pick_side = str(pick.get("side") or "").lower()
    analysis_mode = _selection_analysis_mode(selection)
    odds_analysis_included = analysis_mode == "real_odds"
    blockers: list[str] = []
    warnings: list[str] = []
    if status not in {"upcoming", "scheduled", "preview"}:
        blockers.append("比賽已開打或結束，不能發布為新的每日免費精選。")
    if not game_id:
        blockers.append("賽事識別碼缺失，無法安全建立發布紀錄。")
    if pick_side not in {"away", "home"}:
        blockers.append("模型尚未產生有效的主隊或客隊推薦方向。")
    if starters.get("both_starters_ready") is not True:
        warnings.append("兩隊預告先發或投手數據尚未完整；已降低模型信心，不阻擋發布。")
    if data_quality < advisory_data_quality:
        warnings.append(f"{code} 資料完整度目前為 {data_quality * 100:.0f}%；僅供風險提示，不阻擋發布。")
    if confidence < advisory_confidence:
        warnings.append(f"模型信心 {confidence:.1f}% 低於原建議值 {advisory_confidence:.0f}%；仍可發布。")
    if not ((game.get("away") or {}).get("probable_pitcher") or {}).get("announced"):
        warnings.append("客隊預告先發來源仍在更新。")
    if not ((game.get("home") or {}).get("probable_pitcher") or {}).get("announced"):
        warnings.append("主隊預告先發來源仍在更新。")
    if analysis_mode == "model_only":
        warnings.append("目前未採用有效真實盤口；本候選只依球隊、先發、打線、牛棚、近期與進階資料評估獨贏方向。")
    return {
        "game_pk": game_id, "league": code, "matchup": selection.get("matchup"),
        "time_taiwan": selection.get("time_taiwan"), "display_time_taiwan": selection.get("display_time_taiwan") or game.get("display_time_taiwan"),
        "game_label": selection.get("game_label") or game.get("game_label") or "", "game_number": selection.get("game_number") if selection.get("game_number") is not None else game.get("game_number"),
        "is_doubleheader": bool(selection.get("is_doubleheader") or game.get("is_doubleheader")), "venue": game.get("venue"),
        "event": {"game_type": "R", "context": "regular", "label": game.get("event_label") or "例行賽", "special": False},
        "pick": selection.get("pick"), "confidence": confidence, "data_quality": data_quality,
        "market_basis": selection.get("market_basis"),
        "analysis_mode": analysis_mode,
        "odds_analysis_included": odds_analysis_included,
        "odds_source": selection.get("odds_source") or {},
        "price": selection.get("price"),
        "decimal_odds": selection.get("decimal_odds"),
        "implied_probability": selection.get("implied_probability"),
        "edge": selection.get("edge"),
        "warnings": warnings, "blockers": blockers, "can_publish": not blockers, "auto_publish_ready": not blockers,
        "requires_confirmation": False, "timing": {"stage": f"{code.lower()}_advisory_release"},
        "checklist": {"model_stage": model_stage, "analysis_mode": analysis_mode, "odds_analysis_included": odds_analysis_included, "valid_game_id": bool(game_id), "valid_pick_direction": pick_side in {"away", "home"}, "both_starters_ready": starters.get("both_starters_ready") is True, "data_quality_advisory_passed": data_quality >= advisory_data_quality, "confidence_advisory_passed": confidence >= advisory_confidence, "moneyline_only": True},
        "roster_validation": {}, "lineup_validation_rate": 1.0 if ((selection.get("analysis_groups") or {}).get("lineup") or {}).get("official_lineups_ready") else 0.0,
        "updated_at": selection.get("generated_at") or selection.get("updated_at"),
    }


def founder_npb_candidate(selection: dict) -> dict:
    return founder_asian_candidate(selection, "NPB")


def _lead_time_label(minutes: int) -> str:
    safe = max(1, int(minutes))
    if safe % 60 == 0:
        return f"{safe // 60} 小時"
    if safe > 60:
        return f"{safe // 60} 小時 {safe % 60} 分鐘"
    return f"{safe} 分鐘"


async def _founder_free_candidates(
    request: Request,
    target_date: date,
    league: str,
    odds_items: list[dict] | None = None,
) -> tuple[list[dict], list[dict], str]:
    if league in {"NPB", "KBO", "CPBL"}:
        effective_odds = odds_items
        if effective_odds is None and league in ASIAN_MODEL_ONLY_FALLBACK_LEAGUES:
            feed = await asian_odds_feed_for_date(
                request,
                target_date,
                league,
            )
            effective_odds = (
                list(feed.get("items") or [])
                if _odds_feed_is_live(feed)
                else []
            )
        selections = await asian_market_candidates_for_date(
            request,
            target_date,
            league,
            effective_odds or [],
        )
        selections = [item for item in selections if item.get("market") == "moneyline"]
        candidates = [founder_asian_candidate(item, league) for item in selections]
        candidates.sort(key=lambda item: item["confidence"], reverse=True)
        real_count = sum(1 for item in selections if is_real_odds_selection(item))
        model_count = sum(
            1
            for item in selections
            if is_model_only_asian_moneyline(item, league)
        )
        if league in ASIAN_MODEL_ONLY_FALLBACK_LEAGUES:
            message = (
                f"{league} 候選已載入：{real_count} 場包含真實盤口分析，"
                f"{model_count} 場改用純模型獨贏分析；純模型候選不顯示盤口、賠率、市場機率或優勢值。"
            )
        else:
            message = f"{league} 所有未開賽場次都會排序顯示；資料完整度、先發與打線僅作風險提示，不阻擋手動發布。"
        return candidates, selections, message
    try:
        analyses = await service(request).matchup_analyses(target_date, pitcher_limit=None)
    except MLBUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    selections = []
    for item in list(analyses.get("items") or []):
        candidate = dict(item)
        candidate.setdefault("league", "MLB")
        candidate.setdefault("market", "moneyline")
        selections.append(calibrate_selection(request, candidate, thresholds=False))
    candidates = [founder_candidate(item) for item in selections]
    candidates.sort(key=lambda item: item["confidence"], reverse=True)
    return candidates, selections, analyses.get("message") or "MLB 候選場次已載入。"


async def auto_publish_npb_free_pick(
    request: Request,
    target_date: date,
    *,
    now: datetime | None = None,
) -> dict:
    """Publish one NPB free pick inside the founder-authorized early window.

    The trigger is based on the earliest valid NPB game of the day.  It never
    publishes MLB or Pro packages, never replaces a manual NPB publication and
    requires only an unstarted game and a valid recommendation direction;
    missing enrichment data is advisory and lowers confidence instead of blocking.
    """

    if not settings.npb_auto_publish_enabled:
        return {
            "published": False,
            "state": "disabled",
            "league": "NPB",
            "message": "NPB 自動發布未啟用。",
        }
    repository = records_repository(request)
    if not repository.enabled:
        raise RecordsStorageError("Recommendation records database is not configured")

    existing = await repository.get_record_for_date(target_date.isoformat(), "NPB")
    if existing:
        return {
            "published": False,
            "state": "already_published",
            "league": "NPB",
            "record_id": existing.get("id"),
            "published_at": existing.get("published_at"),
            "message": "今日 NPB 已由創辦人或自動備援正式發布，不再更換。",
        }

    schedule = await npb_service(request).games_for_date(target_date)
    valid_schedule_items = [
        game for game in list(schedule.get("items") or [])
        if _asian_game_matches_target_date(game, target_date)
    ]
    window = _npb_auto_publish_window(
        valid_schedule_items,
        now=now,
        lead_minutes=settings.npb_auto_publish_lead_minutes,
        grace_minutes=settings.npb_auto_publish_scheduler_grace_minutes,
    )
    if not window["due"]:
        return {
            "published": False,
            "league": "NPB",
            **window,
        }

    current = now or datetime.now(TAIPEI)
    if current.tzinfo is None:
        current = current.replace(tzinfo=TAIPEI)
    current = current.astimezone(TAIPEI)
    future_game_ids = {
        str(game.get("game_pk") or game.get("external_game_id"))
        for game in valid_schedule_items
        if (start := parse_game_datetime(game.get("game_date"))) is not None
        and (start if start.tzinfo else start.replace(tzinfo=TAIPEI)).astimezone(TAIPEI) > current
        and str(game.get("status") or "upcoming").strip().lower()
        not in {"cancelled", "canceled", "postponed", "void", "no_game", "final", "completed", "live", "in_progress", "in progress"}
    }
    candidates, selections, _message = await _founder_free_candidates(request, target_date, "NPB")
    eligible = sorted(
        (
            item for item in candidates
            if item.get("can_publish") is True
            and str(item.get("game_pk")) in future_game_ids
        ),
        key=lambda item: float(item.get("confidence") or 0),
        reverse=True,
    )
    if not eligible:
        return {
            "published": False,
            "state": "no_eligible_candidate",
            "league": "NPB",
            "message": "已進入自動發布時間，但目前沒有具備有效賽事與推薦方向的 NPB 候選；稍後會再次檢查。",
            **{key: value for key, value in window.items() if key not in {"due", "state", "message"}},
        }

    policy = eligible[0]
    selected_key = str(policy.get("game_pk"))
    selection = next(
        (item for item in selections if str(item.get("game_pk")) == selected_key),
        None,
    )
    if selection is None:
        return {
            "published": False,
            "state": "candidate_changed",
            "league": "NPB",
            "message": "NPB 候選在鎖定前已更新，下一次排程會重新選擇。",
        }

    # Recheck immediately before the immutable insert so a founder click wins
    # cleanly if it races with the scheduled fallback.
    existing = await repository.get_record_for_date(target_date.isoformat(), "NPB")
    if existing:
        return {
            "published": False,
            "state": "already_published",
            "league": "NPB",
            "record_id": existing.get("id"),
            "published_at": existing.get("published_at"),
            "message": "創辦人已先完成 NPB 正式發布，自動備援未更換內容。",
        }

    published_at = iso_utc()
    selection = _stamp_free_selection(
        selection,
        league="NPB",
        target_date=target_date,
        published_at=published_at,
        mode="npb_auto_fallback",
        automatic=True,
        publication_extra={
            "trigger": f"earliest_npb_game_minus_{settings.npb_auto_publish_lead_minutes}_minutes",
            "trigger_game": window.get("earliest_game"),
            "lead_minutes": settings.npb_auto_publish_lead_minutes,
            "special_event": bool((policy.get("event") or {}).get("special")),
            "event_label": (policy.get("event") or {}).get("label") or "NPB 例行賽",
            "warnings_confirmed": bool(policy.get("warnings")),
            "founder_authorized_fallback": True,
        },
    )
    stored, created = await repository.publish_prediction_once(target_date.isoformat(), selection)
    if not created:
        return {
            "published": False,
            "state": "already_published",
            "league": "NPB",
            "record_id": stored.get("id"),
            "published_at": stored.get("published_at"),
            "message": "另一個發布動作已先鎖定今日 NPB，自動備援未覆蓋。",
        }
    try:
        await performance_repository(request).capture_public(
            target_date.isoformat(), str(stored.get("id")), selection
        )
    except PerformanceStorageError:
        pass
    try:
        social = await _publish_free_social(request, stored, "pregame")
    except (RecordsStorageError, SocialPublishingError) as exc:
        social = {"status": "failed", "error": str(exc)}
    return {
        "published": True,
        "state": "published",
        "league": "NPB",
        "record_id": stored.get("id"),
        "published_at": published_at,
        "selection": stored.get("prediction_snapshot") or selection,
        "social": social,
        "earliest_game": window.get("earliest_game"),
        "message": (
            "創辦人尚未手動發布；系統已在今日最早 NPB 開賽前 "
            f"{_lead_time_label(settings.npb_auto_publish_lead_minutes)}發布窗內，"
            "取得第一筆有效真實盤口後自動發布最高合格免費精選。"
        ),
    }


async def auto_publish_npb_pro_package(
    request: Request,
    target_date: date,
    *,
    now: datetime | None = None,
) -> dict:
    """Auto-publish NPB Pro when valid real-odds candidates exist.

    Model completeness remains visible as advisory metadata but is not a release
    gate because NPB starters and lineups are often unavailable until late.
    """

    if not settings.npb_pro_auto_publish_enabled:
        return {
            "published": False,
            "state": "disabled",
            "league": "NPB",
            "message": "NPB Pro 自動發布未啟用。",
        }
    repository = records_repository(request)
    if not repository.enabled:
        raise RecordsStorageError("Recommendation records database is not configured")

    existing_record = await repository.get_prediction_package_for_date(target_date.isoformat())
    existing_package = package_from_record(existing_record) if existing_record else None
    if existing_package and _package_has_league(existing_package, "NPB"):
        return {
            "published": False,
            "state": "already_published",
            "league": "NPB",
            "record_id": existing_record.get("id") if existing_record else None,
            "published_at": ((existing_package.get("publication") or {}).get("league_batches") or {}).get("NPB", {}).get("published_at"),
            "message": "今日 NPB Pro 已由創辦人或自動備援正式發布，不再更換。",
        }

    schedule = await npb_service(request).games_for_date(target_date)
    window = _npb_auto_publish_window(
        list(schedule.get("items") or []),
        now=now,
        lead_minutes=settings.npb_auto_publish_lead_minutes,
        grace_minutes=settings.npb_auto_publish_scheduler_grace_minutes,
    )
    if not window["due"]:
        return {"published": False, "league": "NPB", **window}

    bundle = await founder_market_candidate_bundle(request, target_date, "NPB")
    candidates = bundle.get("candidates") or {}
    parlays = candidates.get("parlays") or {}
    current = now or datetime.now(TAIPEI)
    if current.tzinfo is None:
        current = current.replace(tzinfo=TAIPEI)
    current = current.astimezone(TAIPEI)

    def unstarted(items: list[dict] | None) -> list[dict]:
        result: list[dict] = []
        for item in items or []:
            start = _selection_start_datetime(item)
            if start is not None and start > current:
                result.append(item)
        return result

    # The public NPB moneyline may also be the only qualified real-odds Pro
    # play.  Auto publication therefore uses every formal NPB candidate rather
    # than the UI convenience list that normally hides the free-pick duplicate.
    selected = {
        "moneylines": [item.get("candidate_id") for item in unstarted(candidates.get("moneylines"))],
        "run_lines": [item.get("candidate_id") for item in unstarted(candidates.get("run_lines"))],
        "totals": [item.get("candidate_id") for item in unstarted(candidates.get("totals"))],
        "two_leg": [item.get("candidate_id") for item in unstarted(parlays.get("two_leg"))[:2]],
        "three_leg": [item.get("candidate_id") for item in unstarted(parlays.get("three_leg"))[:1]],
    }
    league_package = build_selected_market_package(
        bundle,
        selected,
        publication_mode="npb_auto_fallback",
    )
    readiness = ((bundle.get("readiness") or {}).get("NPB") or {})
    if not league_package.get("published"):
        return {
            "published": False,
            "state": readiness.get("status") or "no_eligible_candidate",
            "league": "NPB",
            "readiness": readiness,
            "message": readiness.get("message") or "目前沒有具備有效推薦方向與真實盤口的 NPB Pro 候選；稍後會再次檢查。",
            **{key: value for key, value in window.items() if key not in {"due", "state", "message"}},
        }
    invalid = _npb_pro_package_errors(league_package)
    if invalid:
        return {
            "published": False,
            "state": "safety_gate_failed",
            "league": "NPB",
            "invalid_candidates": invalid,
            "message": "NPB Pro 安全驗證未通過；未發布任何模擬盤口或無效推薦方向。",
        }

    # Re-read immediately before persistence so a manual publish always wins.
    current_record = await repository.get_prediction_package_for_date(target_date.isoformat())
    current_package = package_from_record(current_record) if current_record else None
    if current_package and _package_has_league(current_package, "NPB"):
        return {
            "published": False,
            "state": "already_published",
            "league": "NPB",
            "record_id": current_record.get("id") if current_record else None,
            "message": "創辦人已先完成 NPB Pro 正式發布，自動備援未更換內容。",
        }

    published_at = iso_utc()
    league_package = _stamp_published_package(
        league_package,
        league="NPB",
        target_date=target_date,
        published_at=published_at,
    )
    publication = league_package.setdefault("publication", {})
    publication.update({
        "mode": "npb_auto_fallback",
        "automatic": True,
        "founder_authorized_fallback": True,
        "trigger": f"earliest_npb_game_minus_{settings.npb_auto_publish_lead_minutes}_minutes",
        "trigger_game": window.get("earliest_game"),
        "lead_minutes": settings.npb_auto_publish_lead_minutes,
        "league_locks": {"NPB": True},
        "last_published_league": "NPB",
    })

    if current_record and current_package:
        package = _merge_league_package(current_package, league_package, "NPB")
        stored = await repository.replace_prediction_package(
            target_date.isoformat(),
            package,
            preserve_results=current_record.get("results") or {},
        )
    else:
        package = league_package
        stored, created = await repository.publish_prediction_package_once(
            target_date.isoformat(), package
        )
        if not created:
            raced_package = package_from_record(stored)
            if _package_has_league(raced_package, "NPB"):
                return {
                    "published": False,
                    "state": "already_published",
                    "league": "NPB",
                    "record_id": stored.get("id"),
                    "message": "另一個發布動作已先鎖定今日 NPB Pro，自動備援未覆蓋。",
                }
            package = _merge_league_package(raced_package, league_package, "NPB")
            stored = await repository.replace_prediction_package(
                target_date.isoformat(),
                package,
                preserve_results=stored.get("results") or {},
            )
    try:
        await performance_repository(request).capture_package(
            target_date.isoformat(), str(stored.get("id")), package
        )
    except PerformanceStorageError:
        pass
    try:
        social = await _publish_pro_social(request, stored, "teaser", "NPB")
    except (RecordsStorageError, SocialPublishingError) as exc:
        social = {"status": "failed", "error": str(exc)}
    selected_counts = (league_package.get("publication") or {}).get("selected_counts") or {}
    return {
        "published": True,
        "state": "published",
        "league": "NPB",
        "record_id": stored.get("id"),
        "published_at": published_at,
        "selected_counts": selected_counts,
        "social": social,
        "readiness": readiness,
        "earliest_game": window.get("earliest_game"),
        "message": (
            "創辦人尚未手動發布；系統已在最早 NPB 開賽前 "
            f"{_lead_time_label(settings.npb_auto_publish_lead_minutes)}發布窗內，"
            "取得第一筆有效真實盤口後自動發布 Pro 推薦。"
        ),
    }


def _asian_auto_settings(league: str) -> dict:
    code = str(league).upper()
    if code == "NPB":
        return {
            "free": settings.npb_auto_publish_enabled,
            "pro": settings.npb_pro_auto_publish_enabled,
            "lead": settings.npb_auto_publish_lead_minutes,
            "odds_refresh_lead": settings.npb_odds_refresh_lead_minutes,
            "grace": settings.npb_auto_publish_scheduler_grace_minutes,
            "odds_key": settings.npb_odds_sport_key,
        }
    if code == "KBO":
        return {
            "free": settings.kbo_auto_publish_enabled,
            "pro": settings.kbo_pro_auto_publish_enabled,
            "lead": settings.kbo_auto_publish_lead_minutes,
            "odds_refresh_lead": settings.kbo_odds_refresh_lead_minutes,
            "grace": settings.kbo_auto_publish_scheduler_grace_minutes,
            "odds_key": settings.kbo_odds_sport_key,
        }
    if code == "CPBL":
        return {
            "free": settings.cpbl_auto_publish_enabled,
            "pro": settings.cpbl_pro_auto_publish_enabled,
            "lead": settings.cpbl_auto_publish_lead_minutes,
            "odds_refresh_lead": settings.cpbl_odds_refresh_lead_minutes,
            "grace": settings.cpbl_auto_publish_scheduler_grace_minutes,
            "odds_key": settings.cpbl_odds_sport_key,
        }
    raise ValueError(f"Unsupported auto-publish league: {code}")


async def refresh_asian_odds_snapshot(
    request: Request,
    target_date: date,
    league: str,
    *,
    now: datetime | None = None,
) -> dict:
    """Refresh real Asian odds before the later immutable publish window.

    This pass may run from twelve hours before first pitch. It only stores a
    verified provider snapshot; it never creates a Free or Pro publication.
    """

    code = _prediction_league(league)
    if code == "MLB":
        return {
            "refreshed": False,
            "refresh_only": True,
            "state": "manual_only",
            "league": code,
            "message": "MLB 維持原有創辦人流程。",
        }
    policy = _asian_auto_settings(code)
    schedule = await baseball_service(request, code).games_for_date(target_date)
    valid_schedule_items = [
        game
        for game in list(schedule.get("items") or [])
        if _asian_game_matches_target_date(game, target_date)
    ]
    refresh_window = _npb_auto_publish_window(
        valid_schedule_items,
        now=now,
        lead_minutes=policy["odds_refresh_lead"],
        grace_minutes=policy["grace"],
        league=code,
    )
    publication_window = _npb_auto_publish_window(
        valid_schedule_items,
        now=now,
        lead_minutes=policy["lead"],
        grace_minutes=policy["grace"],
        league=code,
    )
    common = {
        "refresh_only": True,
        "league": code,
        "odds_refresh_lead_minutes": int(policy["odds_refresh_lead"]),
        "publish_lead_minutes": int(policy["lead"]),
        "official_publish_due": bool(publication_window.get("due")),
        "earliest_game": refresh_window.get("earliest_game"),
        "minutes_to_start": refresh_window.get("minutes_to_start"),
    }
    if not refresh_window.get("due"):
        return {
            **common,
            "refreshed": False,
            "state": (
                "waiting_odds_refresh_window"
                if refresh_window.get("state") == "waiting"
                else refresh_window.get("state") or "schedule_unavailable"
            ),
            "message": refresh_window.get("message"),
        }

    odds_feed = await asian_odds_feed_for_date(
        request,
        target_date,
        code,
        priority=True,
    )
    odds_meta = odds_feed.get("meta") or {}
    odds_summary = {
        "provider": odds_meta.get("provider"),
        "provider_chain": odds_meta.get("provider_chain") or [],
        "provider_skips": odds_meta.get("provider_skips") or [],
        "count": int(odds_feed.get("count") or 0),
        "persistent_snapshot": bool(odds_meta.get("persistent_snapshot")),
        "snapshot_captured_at": odds_meta.get("snapshot_captured_at")
        or odds_meta.get("updated_at"),
        "snapshot_age_minutes": odds_meta.get("snapshot_age_minutes"),
        "availability_reason": odds_meta.get("availability_reason"),
        "fresh_for_model": bool(odds_meta.get("fresh_for_model")),
    }
    if _odds_feed_is_live(odds_feed):
        message = (
            f"{code} 已取得並保存真實盤口；"
            + (
                "目前已進入開賽前 3 小時正式發布窗。"
                if publication_window.get("due")
                else "系統會持續更新，開賽前 3 小時才正式發布。"
            )
        )
        return {
            **common,
            "refreshed": True,
            "state": "odds_snapshot_ready",
            "odds": odds_summary,
            "message": message,
        }

    waiting_state, waiting_message = _asian_odds_waiting_state(code, odds_feed)
    return {
        **common,
        "refreshed": False,
        "state": waiting_state,
        "odds": odds_summary,
        "message": waiting_message,
    }


async def auto_publish_asian_free_pick(request: Request, target_date: date, league: str, *, now: datetime | None = None) -> dict:
    code = _prediction_league(league)
    if code == "MLB":
        return {"published": False, "state": "manual_only", "league": code, "message": "MLB 維持創辦人手動發布。"}
    policy = _asian_auto_settings(code)
    if not policy["free"]:
        return {"published": False, "state": "disabled", "league": code, "message": f"{code} 自動發布未啟用。"}
    repository = records_repository(request)
    if not repository.enabled:
        raise RecordsStorageError("Recommendation records database is not configured")
    existing = await repository.get_record_for_date(target_date.isoformat(), code)
    if existing:
        return {"published": False, "state": "already_published", "league": code, "record_id": existing.get("id"), "published_at": existing.get("published_at"), "message": f"今日 {code} 已正式發布，不再更換。"}
    schedule = await baseball_service(request, code).games_for_date(target_date)
    valid_schedule_items = [
        game for game in list(schedule.get("items") or [])
        if _asian_game_matches_target_date(game, target_date)
    ]
    window = _npb_auto_publish_window(
        valid_schedule_items,
        now=now,
        lead_minutes=policy["lead"],
        grace_minutes=policy["grace"],
        league=code,
    )
    if not window["due"]:
        return {"published": False, "league": code, **window}
    odds_feed = await asian_odds_feed_for_date(
        request,
        target_date,
        code,
        priority=True,
    )
    odds_meta = odds_feed.get("meta") or {}
    live_odds = _odds_feed_is_live(odds_feed)
    odds_summary = {
        "provider": odds_meta.get("provider"),
        "provider_chain": odds_meta.get("provider_chain") or [],
        "count": int(odds_feed.get("count") or 0),
        "persistent_snapshot": bool(odds_meta.get("persistent_snapshot")),
        "snapshot_captured_at": odds_meta.get("snapshot_captured_at"),
        "snapshot_age_minutes": odds_meta.get("snapshot_age_minutes"),
        "availability_reason": odds_meta.get("availability_reason"),
        "fresh_for_model": bool(odds_meta.get("fresh_for_model")),
    }
    if not live_odds and code not in ASIAN_MODEL_ONLY_FALLBACK_LEAGUES:
        waiting_state, waiting_message = _asian_odds_waiting_state(
            code,
            odds_feed,
        )
        return {
            "published": False,
            "state": waiting_state,
            "league": code,
            "odds": odds_summary,
            "message": waiting_message,
            **{
                key: value
                for key, value in window.items()
                if key not in {"due", "state", "message"}
            },
        }
    current = now or datetime.now(TAIPEI)
    if current.tzinfo is None:
        current = current.replace(tzinfo=TAIPEI)
    current = current.astimezone(TAIPEI)
    future_ids = {
        str(game.get("game_pk") or game.get("external_game_id"))
        for game in valid_schedule_items
        if (start := parse_game_datetime(game.get("game_date"))) is not None
        and (start if start.tzinfo else start.replace(tzinfo=TAIPEI)).astimezone(TAIPEI) > current
        and str(game.get("status") or "upcoming").lower() in {"upcoming", "scheduled", "preview"}
    }
    candidates, selections, _ = await _founder_free_candidates(
        request,
        target_date,
        code,
        (odds_feed.get("items") or []) if live_odds else [],
    )
    selection_by_game = {
        str(item.get("game_pk")): item
        for item in selections
        if item.get("game_pk") is not None
    }
    base_eligible = [
        item
        for item in candidates
        if item.get("can_publish") is True
        and str(item.get("game_pk")) in future_ids
    ]
    real_eligible = sorted(
        (
            item
            for item in base_eligible
            if is_real_odds_selection(
                selection_by_game.get(str(item.get("game_pk"))) or {}
            )
        ),
        key=lambda item: float(item.get("confidence") or 0),
        reverse=True,
    )
    model_eligible = sorted(
        (
            item
            for item in base_eligible
            if is_model_only_asian_moneyline(
                selection_by_game.get(str(item.get("game_pk"))) or {},
                code,
            )
        ),
        key=lambda item: float(item.get("confidence") or 0),
        reverse=True,
    )
    eligible = (
        real_eligible or model_eligible
        if code in ASIAN_MODEL_ONLY_FALLBACK_LEAGUES
        else real_eligible
    )
    if not eligible:
        return {"published": False, "state": "no_eligible_candidate", "league": code, "odds": odds_summary, "message": f"已進入自動發布時間，但目前沒有具備有效賽事識別與推薦方向的 {code} 候選；稍後會再次檢查。", **{k: v for k, v in window.items() if k not in {"due", "state", "message"}}}
    chosen = eligible[0]
    selection = selection_by_game.get(str(chosen.get("game_pk")))
    if not selection:
        return {"published": False, "state": "candidate_changed", "league": code, "message": f"{code} 候選在鎖定前已更新。"}
    analysis_mode = _selection_analysis_mode(selection)
    existing = await repository.get_record_for_date(target_date.isoformat(), code)
    if existing:
        return {"published": False, "state": "already_published", "league": code, "record_id": existing.get("id"), "message": f"創辦人已先完成 {code} 正式發布。"}
    published_at = iso_utc()
    selection = _stamp_free_selection(
        selection,
        league=code,
        target_date=target_date,
        published_at=published_at,
        mode=f"{code.lower()}_auto_fallback",
        automatic=True,
        publication_extra={
            "trigger": f"earliest_{code.lower()}_game_minus_{policy['lead']}_minutes",
            "trigger_game": window.get("earliest_game"),
            "lead_minutes": policy["lead"],
            "warnings_confirmed": bool(chosen.get("warnings")),
            "founder_authorized_fallback": True,
            **_analysis_mode_metadata(analysis_mode),
            "odds_provider": odds_meta.get("provider") if analysis_mode == "real_odds" else None,
            "fallback_reason": (
                None
                if analysis_mode == "real_odds"
                else selection.get("fallback_reason") or "valid_real_odds_unavailable"
            ),
        },
    )
    stored, created = await repository.publish_prediction_once(target_date.isoformat(), selection)
    if not created:
        return {"published": False, "state": "already_published", "league": code, "record_id": stored.get("id"), "message": f"另一個發布動作已先鎖定今日 {code}。"}
    try:
        await performance_repository(request).capture_public(target_date.isoformat(), str(stored.get("id")), selection)
    except PerformanceStorageError:
        pass
    try:
        social = await _publish_free_social(request, stored, "pregame")
    except (RecordsStorageError, SocialPublishingError) as exc:
        social = {"status": "failed", "error": str(exc)}
    line = _queue_line_sync(request.app, f"{code.lower()}_auto_free_publish", force=True)
    return {
        "published": True,
        "state": "published",
        "league": code,
        "record_id": stored.get("id"),
        "published_at": published_at,
        "selection": stored.get("prediction_snapshot") or selection,
        "social": social,
        "line": line,
        "analysis_mode": analysis_mode,
        "odds": odds_summary,
        "earliest_game": window.get("earliest_game"),
        "message": (
            f"系統已在今日最早 {code} 開賽前 "
            f"{_lead_time_label(policy['lead'])}發布窗內，"
            + (
                "使用有效真實盤口與模型分析，自動發布最高合格免費精選。"
                if analysis_mode == "real_odds"
                else "在無有效真實盤口時改用純模型獨贏分析完成發布；未加入任何模擬盤口。"
            )
        ),
    }


async def auto_publish_asian_pro_package(request: Request, target_date: date, league: str, *, now: datetime | None = None) -> dict:
    code = _prediction_league(league)
    if code == "MLB":
        return {"published": False, "state": "manual_only", "league": code, "message": "MLB Pro 維持創辦人手動發布。"}
    policy = _asian_auto_settings(code)
    if not policy["pro"]:
        return {"published": False, "state": "disabled", "league": code, "message": f"{code} Pro 自動發布未啟用。"}
    repository = records_repository(request)
    if not repository.enabled:
        raise RecordsStorageError("Recommendation records database is not configured")
    existing_record = await repository.get_prediction_package_for_date(target_date.isoformat())
    existing_package = package_from_record(existing_record) if existing_record else None
    if existing_package and _package_has_league(existing_package, code):
        return {"published": False, "state": "already_published", "league": code, "record_id": existing_record.get("id") if existing_record else None, "message": f"今日 {code} Pro 已正式發布。"}
    schedule = await baseball_service(request, code).games_for_date(target_date)
    valid_schedule_items = [
        game for game in list(schedule.get("items") or [])
        if _asian_game_matches_target_date(game, target_date)
    ]
    window = _npb_auto_publish_window(
        valid_schedule_items,
        now=now,
        lead_minutes=policy["lead"],
        grace_minutes=policy["grace"],
        league=code,
    )
    if not window["due"]:
        return {"published": False, "league": code, **window}
    bundle = await founder_market_candidate_bundle(
        request, target_date, code, priority=True
    )
    candidates = bundle.get("candidates") or {}
    parlays = candidates.get("parlays") or {}
    current = now or datetime.now(TAIPEI)
    if current.tzinfo is None:
        current = current.replace(tzinfo=TAIPEI)
    current = current.astimezone(TAIPEI)
    def unstarted(items):
        return [item for item in (items or []) if (start := _selection_start_datetime(item)) is not None and start > current]
    selected = {"moneylines": [item.get("candidate_id") for item in unstarted(candidates.get("moneylines"))], "run_lines": [item.get("candidate_id") for item in unstarted(candidates.get("run_lines"))], "totals": [item.get("candidate_id") for item in unstarted(candidates.get("totals"))], "two_leg": [item.get("candidate_id") for item in unstarted(parlays.get("two_leg"))[:2]], "three_leg": [item.get("candidate_id") for item in unstarted(parlays.get("three_leg"))[:1]]}
    league_package = build_selected_market_package(bundle, selected, publication_mode=f"{code.lower()}_auto_fallback")
    readiness = ((bundle.get("readiness") or {}).get(code) or {})
    if not league_package.get("published"):
        return {"published": False, "state": readiness.get("status") or "no_eligible_candidate", "league": code, "readiness": readiness, "message": readiness.get("message") or f"目前沒有具備有效賽事識別與推薦方向的 {code} Pro 候選。", **{k: v for k, v in window.items() if k not in {"due", "state", "message"}}}
    invalid = _asian_pro_package_errors(league_package, code)
    if invalid:
        return {"published": False, "state": "safety_gate_failed", "league": code, "invalid_candidates": invalid, "message": f"{code} Pro 安全驗證未通過；純模型僅允許 NPB／KBO 獨贏，讓分、大小分與串關仍須真實盤口。"}
    analysis_mode = _package_analysis_mode(league_package, code)
    current_record = await repository.get_prediction_package_for_date(target_date.isoformat())
    current_package = package_from_record(current_record) if current_record else None
    if current_package and _package_has_league(current_package, code):
        return {"published": False, "state": "already_published", "league": code, "record_id": current_record.get("id") if current_record else None, "message": f"創辦人已先完成 {code} Pro 發布。"}
    published_at = iso_utc()
    league_package = _stamp_published_package(league_package, league=code, target_date=target_date, published_at=published_at)
    publication = league_package.setdefault("publication", {})
    publication.update({"mode": f"{code.lower()}_auto_fallback", "automatic": True, "founder_authorized_fallback": True, "trigger": f"earliest_{code.lower()}_game_minus_{policy['lead']}_minutes", "trigger_game": window.get("earliest_game"), "lead_minutes": policy["lead"], "league_locks": {code: True}, "last_published_league": code, **_analysis_mode_metadata(analysis_mode)})
    if current_record and current_package:
        package = _merge_league_package(current_package, league_package, code)
        stored = await repository.replace_prediction_package(target_date.isoformat(), package, preserve_results=current_record.get("results") or {})
    else:
        package = league_package
        stored, created = await repository.publish_prediction_package_once(target_date.isoformat(), package)
        if not created:
            raced = package_from_record(stored)
            if _package_has_league(raced, code):
                return {"published": False, "state": "already_published", "league": code, "record_id": stored.get("id"), "message": f"另一個發布動作已先鎖定今日 {code} Pro。"}
            package = _merge_league_package(raced, league_package, code)
            stored = await repository.replace_prediction_package(target_date.isoformat(), package, preserve_results=stored.get("results") or {})
    try:
        await performance_repository(request).capture_package(target_date.isoformat(), str(stored.get("id")), package)
    except PerformanceStorageError:
        pass
    try:
        social = await _publish_pro_social(request, stored, "teaser", code)
    except (RecordsStorageError, SocialPublishingError) as exc:
        social = {"status": "failed", "error": str(exc)}
    line = _queue_line_sync(request.app, f"{code.lower()}_auto_pro_publish", force=True)
    return {
        "published": True,
        "state": "published",
        "league": code,
        "record_id": stored.get("id"),
        "published_at": published_at,
        "selected_counts": (league_package.get("publication") or {}).get("selected_counts") or {},
        "social": social,
        "line": line,
        "readiness": readiness,
        "analysis_mode": analysis_mode,
        "earliest_game": window.get("earliest_game"),
        "message": (
            f"系統已在最早 {code} 開賽前 "
            f"{_lead_time_label(policy['lead'])}發布窗內，"
            + (
                "發布同時包含真實盤口與純模型獨贏候選的 Pro 推薦。"
                if analysis_mode == "mixed"
                else "使用有效真實盤口與模型分析完成 Pro 發布。"
                if analysis_mode == "real_odds"
                else "在無有效真實盤口時，以純模型獨贏完成 Pro 發布；未建立讓分、大小分、串關或模擬盤口。"
            )
        ),
    }


def _publishing_runtime_status(app: FastAPI) -> dict:
    status = dict(getattr(app.state, "publishing_status", {}) or {})
    return {
        key: status.get(key)
        for key in (
            "enabled",
            "state",
            "running",
            "queued",
            "source",
            "target_date",
            "queued_at",
            "started_at",
            "last_run",
            "last_error",
            "mode",
            "results",
        )
        if status.get(key) is not None
    }


@app.get(f"{settings.api_prefix}/admin/publishing/status")
async def founder_publishing_status(
    request: Request,
    prediction_date: date | None = Query(default=None, alias="date"),
    league: str = Query(default="MLB", pattern="^(MLB|NPB|KBO|CPBL)$"),
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    """Return one founder-facing Free/Pro publication control snapshot.

    This route is deliberately a database/status read. Candidate generation
    remains behind the separate Free and Pro endpoints, preventing a single
    button or failed request from ever publishing both access tiers.
    """

    await admin_member(request, authorization)
    code = _prediction_league(league)
    target_date = requested_date(prediction_date)
    repository = records_repository(request)
    if not repository.enabled:
        raise HTTPException(
            status_code=503,
            detail="Recommendation database is not configured",
        )
    try:
        free_record, package_record = await asyncio.gather(
            repository.get_record_for_date(target_date.isoformat(), code),
            repository.get_prediction_package_for_date(target_date.isoformat()),
        )
    except RecordsStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc

    free_metadata = (
        _record_publication_metadata(free_record, code)
        if free_record
        else None
    )
    package = package_from_record(package_record) if package_record else None
    pro_metadata = (
        _package_publication_metadata(package, code)
        if package and _package_has_league(package, code)
        else None
    )
    free_snapshot = (
        free_record.get("prediction_snapshot")
        if free_record and isinstance(free_record.get("prediction_snapshot"), dict)
        else {}
    )
    pro_entries = _package_entries(package or {}, code)
    if code == "MLB":
        automatic = {
            "mode": "manual_only",
            "free_enabled": False,
            "pro_enabled": False,
            "lead_minutes": None,
            "grace_minutes": None,
            "message": "MLB 免費與 Pro 維持創辦人分開確認、分開發布。",
        }
    else:
        policy = _asian_auto_settings(code)
        fallback_copy = (
            "若屆時沒有可安全配對的盤口，仍會以純模型獨贏分別完成尚未鎖定的 Free 與 Pro；"
            "不會產生模擬盤口、讓分、大小分或串關。"
            if code in ASIAN_MODEL_ONLY_FALLBACK_LEAGUES
            else "沒有有效真實盤口時不會自動發布。"
        )
        automatic = {
            "mode": "scheduled_fallback",
            "free_enabled": bool(policy["free"]),
            "pro_enabled": bool(policy["pro"]),
            "odds_refresh_lead_minutes": int(policy["odds_refresh_lead"]),
            "lead_minutes": int(policy["lead"]),
            "grace_minutes": int(policy["grace"]),
            "message": (
                f"{code} 會從最早場次開賽前 "
                f"{int(policy['odds_refresh_lead'])} 分鐘開始保存真實盤口，"
                f"到開賽前 {int(policy['lead'])} 分鐘才分別檢查並正式發布 "
                f"Free 與 Pro；{fallback_copy}已手動發布的通道不會被覆蓋。"
            ),
        }

    free_locked = free_metadata is not None
    pro_locked = pro_metadata is not None
    if free_locked and pro_locked:
        plan_state = "complete"
        advice = f"{code} Free 與 Pro 都已鎖定，不需再發布。"
    elif code == "MLB":
        plan_state = "manual_review"
        advice = "先載入 AI 建議，再分別確認尚未發布的 Free 與 Pro。"
    else:
        plan_state = "scheduled"
        advice = (
            "可提前人工發布；若不操作，系統會在安全時間窗"
            "分別完成尚未鎖定的通道。"
        )

    return {
        "ok": True,
        "version": APP_VERSION,
        "date": target_date.isoformat(),
        "league": code,
        "plan": {
            "state": plan_state,
            "advice": advice,
            "free_strategy": "最高信心且仍未開賽的有效獨贏候選",
            "pro_strategy": (
                "有有效盤口時加入盤口分析；缺盤時只發布純模型獨贏"
                if code in ASIAN_MODEL_ONLY_FALLBACK_LEAGUES
                else "真實盤口正式候選，依玩法上限建立建議組合"
            ),
            "combined_publish": False,
            "founder_confirmation_required": True,
        },
        "channels": {
            "free": {
                "channel": "free",
                "access_level": "free",
                "visibility": "public",
                "storage": "recommendations",
                "locked": free_locked,
                "status": (free_metadata or {}).get("status") or "unpublished",
                "record_id": free_record.get("id") if free_record else None,
                "published_at": (free_metadata or {}).get("published_at"),
                "mode": ((free_snapshot.get("publication") or {}).get("mode")),
                "analysis_mode": (free_metadata or {}).get("analysis_mode"),
                "odds_analysis_included": bool((free_metadata or {}).get("odds_analysis_included")),
                "selection": {
                    "game_pk": free_snapshot.get("game_pk"),
                    "matchup": free_snapshot.get("matchup"),
                    "pick": (free_snapshot.get("pick") or {}).get("label"),
                    "confidence": free_snapshot.get("confidence"),
                } if free_locked else None,
                "next_action": "locked" if free_locked else "load_free_ai_candidates",
            },
            "pro": {
                "channel": "pro",
                "access_level": "pro",
                "visibility": "members_only",
                "storage": "prediction_packages",
                "locked": pro_locked,
                "status": (pro_metadata or {}).get("status") or "unpublished",
                "record_id": package_record.get("id") if pro_locked and package_record else None,
                "published_at": (pro_metadata or {}).get("published_at"),
                "analysis_mode": (pro_metadata or {}).get("analysis_mode"),
                "odds_analysis_included": bool((pro_metadata or {}).get("odds_analysis_included")),
                "selection_count": len(pro_entries),
                "next_action": "locked" if pro_locked else "load_pro_ai_candidates",
            },
        },
        "automatic": automatic,
        "model_optimization": {
            "enabled": bool(settings.model_calibration_enabled),
            "interval_seconds": int(settings.model_calibration_interval_seconds),
            "interval_hours": round(
                settings.model_calibration_interval_seconds / 3600,
                1,
            ),
            "mode": "test_candidates_only",
            "automatic_deploy": False,
            "founder_confirmation_required": True,
            "message": (
                "模型持續優化只建立 TEST Challenger；"
                "通過驗證後仍須創辦人確認 Deploy。"
            ),
        },
        "runtime": _publishing_runtime_status(request.app),
        "safety": {
            "separate_persistence": True,
            "immutable_after_publish": True,
            "server_side_pro_gate": True,
            "member_ui_write_access": False,
            "candidate_generation_has_no_write": True,
        },
        "updated_at": iso_utc(),
    }


@app.get(f"{settings.api_prefix}/admin/predictions/candidates")
async def founder_prediction_candidates(
    request: Request,
    prediction_date: date | None = Query(default=None, alias="date"),
    league: str = Query(default="MLB", pattern="^(MLB|NPB|KBO|CPBL)$"),
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    await admin_member(request, authorization)
    league = _prediction_league(league)
    target_date = requested_date(prediction_date)
    repository = records_repository(request)
    if not repository.enabled:
        raise HTTPException(status_code=503, detail="Recommendation database is not configured")
    try:
        existing = await repository.get_record_for_date(target_date.isoformat(), league)
    except RecordsStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    if existing:
        snapshot = existing.get("prediction_snapshot")
        selection = deepcopy(snapshot) if isinstance(snapshot, dict) else {}
        # The founder control card must use the same settled record as the
        # public record page.  The immutable prediction snapshot itself does
        # not change after publication, so the settlement result has to be
        # merged from the record row every time this endpoint is read.
        selection["result"] = _record_result_payload(existing) or {"status": "pending"}
        return {
            "date": target_date.isoformat(),
            "league": _selection_league(selection or {}),
            "requested_league": league,
            "locked": True,
            "selection": selection,
            "items": [],
            "message": f"此賽事日的 {league} 免費精選已鎖定；MLB、NPB、KBO、CPBL 每天都可各自發布一場。",
        }

    items, _selections, message = await _founder_free_candidates(request, target_date, league)
    return {
        "date": target_date.isoformat(),
        "league": league,
        "locked": False,
        "items": items,
        "count": len(items),
        "message": message,
    }


@app.post(f"{settings.api_prefix}/admin/predictions/publish")
async def founder_publish_prediction(
    request: Request,
    command: FounderPredictionPublish,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    await admin_member(request, authorization)
    league = _prediction_league(command.league)
    repository = records_repository(request)
    if not repository.enabled:
        raise HTTPException(status_code=503, detail="Recommendation database is not configured")
    try:
        existing = await repository.get_record_for_date(command.date.isoformat(), league)
    except RecordsStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    if existing:
        existing_snapshot = existing.get("prediction_snapshot") if isinstance(existing.get("prediction_snapshot"), dict) else {}
        existing_game_pk = existing.get("game_pk") or existing_snapshot.get("game_pk") or existing_snapshot.get("game_id")
        if str(existing_game_pk or "") == str(command.game_pk):
            return {
                "ok": True,
                "date": command.date.isoformat(),
                "league": league,
                "locked": True,
                "created": False,
                "idempotent": True,
                "target_date": command.date.isoformat(),
                "published_at": existing.get("published_at") or existing_snapshot.get("published_at"),
                "status": "published",
                "selection": existing_snapshot,
                "social": {"status": "unchanged"},
                "line": _queue_line_sync(request.app, "founder_free_publish_reconcile", force=True),
                "message": f"{league} 每日免費精選先前已成功寫入；本次視為發布成功。",
            }
        raise HTTPException(status_code=409, detail=f"此賽事日的 {league} 免費精選已鎖定，不能再更換場次。")

    candidates, selections, _message = await _founder_free_candidates(request, command.date, league)
    key = str(command.game_pk)
    selection = next((item for item in selections if str(item.get("game_pk")) == key), None)
    policy = next((item for item in candidates if str(item.get("game_pk")) == key), None)
    if selection is None or policy is None:
        raise HTTPException(status_code=404, detail="找不到這場尚未開賽的候選賽事。")
    if not policy["can_publish"]:
        raise HTTPException(status_code=422, detail={"message": "這場比賽目前不可正式發布。", "blockers": policy["blockers"]})
    if policy["requires_confirmation"] and not command.confirm_warning:
        raise HTTPException(status_code=409, detail={"message": "這場比賽需要創辦人再次確認。", "warnings": policy["warnings"]})

    published_at = iso_utc()
    analysis_mode = _selection_analysis_mode(selection)
    selection = _stamp_free_selection(
        selection,
        league=league,
        target_date=command.date,
        published_at=published_at,
        mode="founder_selected",
        automatic=False,
        publication_extra={
            "special_event": policy["event"]["special"],
            "event_label": policy["event"]["label"],
            "warnings_confirmed": bool(policy["warnings"]),
            **_analysis_mode_metadata(analysis_mode),
            "odds_provider": (
                (selection.get("odds_source") or {}).get("provider")
                if analysis_mode == "real_odds"
                else None
            ),
            "fallback_reason": (
                None
                if analysis_mode == "real_odds"
                else selection.get("fallback_reason") or "valid_real_odds_unavailable"
            ),
        },
    )
    try:
        stored, created = await repository.publish_prediction_once(command.date.isoformat(), selection)
    except RecordsStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    if not created:
        stored_snapshot = stored.get("prediction_snapshot") if isinstance(stored.get("prediction_snapshot"), dict) else {}
        stored_game_pk = stored.get("game_pk") or stored_snapshot.get("game_pk") or stored_snapshot.get("game_id")
        if str(stored_game_pk or "") != str(command.game_pk):
            raise HTTPException(status_code=409, detail=f"另一筆 {league} 免費精選已先完成鎖定。")
        # A previous insert may have succeeded even when its HTTP response was
        # lost. Treat the read-back row as success and let the regular social
        # synchronization job publish any missing Instagram asset once.
        return {
            "ok": True,
            "date": command.date.isoformat(),
            "league": league,
            "locked": True,
            "created": False,
            "idempotent": True,
            "target_date": command.date.isoformat(),
            "published_at": stored.get("published_at") or stored_snapshot.get("published_at") or published_at,
            "status": "published",
            "selection": stored_snapshot or selection,
            "social": {"status": "pending_sync"},
            "line": _queue_line_sync(request.app, "founder_free_publish_reconcile", force=True),
            "message": f"{league} 每日免費精選已寫入；系統已確認鎖定成功。",
        }
    try:
        await performance_repository(request).capture_public(command.date.isoformat(), str(stored.get("id")), selection)
    except PerformanceStorageError:
        pass
    try:
        social = await _publish_free_social(request, stored, "pregame")
    except (RecordsStorageError, SocialPublishingError) as exc:
        social = {"status": "failed", "error": str(exc)}
    line = _queue_line_sync(request.app, "founder_free_publish", force=True)
    return {
        "ok": True,
        "date": command.date.isoformat(),
        "league": league,
        "locked": True,
        "created": True,
        "target_date": command.date.isoformat(),
        "published_at": published_at,
        "status": "published",
        "selection": stored.get("prediction_snapshot") or selection,
        "social": social,
        "line": line,
        "analysis_mode": analysis_mode,
        "message": (
            f"{league} 每日免費精選已正式發布；本次包含真實盤口分析，會員現在重新整理即可看見。"
            if analysis_mode == "real_odds"
            else f"{league} 每日免費精選已正式發布；本次為純模型獨贏分析，未加入模擬盤口。"
            if analysis_mode == "model_only"
            else f"{league} 每日免費精選已正式發布；會員現在重新整理即可看見。"
        ),
    }


class FounderMarketPublish(BaseModel):
    date: date
    league: str = "MLB"
    moneylines: list[str] = Field(default_factory=list)
    run_lines: list[str] = Field(default_factory=list)
    totals: list[str] = Field(default_factory=list)
    two_leg: list[str] = Field(default_factory=list)
    three_leg: list[str] = Field(default_factory=list)
    manual_two_leg: list[list[str]] = Field(default_factory=list)
    manual_three_leg: list[str] = Field(default_factory=list)


def _asian_analysis_for_markets(game: dict, analysis: dict, league: str) -> dict:
    groups = analysis.get("analysis_groups") or {}
    normalized_groups = {
        "team_strength": groups.get("team") or {},
        "starter": groups.get("starter") or {},
        "lineup": groups.get("offense") or {},
        "bullpen": groups.get("bullpen") or {},
        "advanced": groups.get("advanced") or {"available": False, "quality": 0.0, "metrics": []},
        "environment": groups.get("environment") or {"available": False, "quality": 0.0, "metrics": []},
    }
    away = game.get("away") or {}
    home = game.get("home") or {}
    return {
        "league": league,
        "game": game,
        "game_pk": str(game.get("game_pk") or game.get("external_game_id") or ""),
        "matchup": f'{away.get("abbr") or away.get("name")} @ {home.get("abbr") or home.get("name")}',
        "game_date": game.get("game_date") or game.get("date"),
        "time_taiwan": game.get("time_taiwan"),
        "display_time_taiwan": game.get("display_time_taiwan") or (f'台灣 {game.get("time_taiwan")}' if game.get("time_taiwan") else None),
        "game_label": game.get("game_label") or "",
        "game_number": game.get("game_number"),
        "is_doubleheader": bool(game.get("is_doubleheader")),
        "home_probability": analysis.get("home_probability"),
        "away_probability": analysis.get("away_probability"),
        "confidence": analysis.get("confidence"),
        "data_quality": analysis.get("data_quality"),
        "model_stage": analysis.get("model_stage") or (analysis.get("data_basis") or {}).get("model_stage"),
        "data_basis": analysis.get("data_basis") or {},
        "projections": analysis.get("projections") or {},
        "analysis_groups": normalized_groups,
        "engine": {"weights": (analysis.get("model_weights") or {}).get("engine") or {}},
        "factors": [],
        "model_version": analysis.get("model_version") or f"dm-{league.lower()}-markets-v1.0",
    }


async def asian_market_candidates_for_date(
    request: Request,
    target_date: date,
    league: str,
    odds_items: list[dict] | None = None,
    *,
    pro_only: bool = False,
    diagnostics: dict | None = None,
) -> list[dict]:
    league = _prediction_league(league)
    if league not in {"NPB", "KBO", "CPBL"}:
        return []
    adapter = baseball_service(request, league)
    try:
        schedule = await adapter.games_for_date(target_date)
    except (NPBUpstreamError, AsianBaseballUpstreamError) as exc:
        if diagnostics is not None:
            diagnostics.update({
                "date": target_date.isoformat(), "policy": "valid_direction_plus_real_odds" if pro_only else "data_advisory",
                "status": "schedule_unavailable", "schedule_games": 0, "games": [],
                "message": f"{league} 官方賽程暫時無法載入，不會發布推薦。", "error": type(exc).__name__,
            })
        return []
    games = [
        item for item in schedule.get("items") or []
        if _asian_game_matches_target_date(item, target_date)
    ]
    available_odds = odds_items or []

    async def build(game: dict) -> dict:
        game_pk = str(game.get("game_pk") or game.get("external_game_id") or "")
        matchup = f'{(game.get("away") or {}).get("abbr") or (game.get("away") or {}).get("name")} @ {(game.get("home") or {}).get("abbr") or (game.get("home") or {}).get("name")}'
        summary = {"game_pk": game_pk, "matchup": matchup, "time_taiwan": game.get("time_taiwan"), "display_time_taiwan": game.get("display_time_taiwan"), "model_stage": "unavailable", "full_model_ready": False, "official_lineups_ready": False, "odds_matched": False, "markets": [], "candidate_count": 0, "formal_count": 0, "blockers": [], "advisories": []}
        try:
            detail = await adapter.game_detail(game_pk)
        except (NPBUpstreamError, AsianBaseballUpstreamError) as exc:
            summary["blockers"] = ["基礎模型資料暫時無法載入"]
            summary["error"] = type(exc).__name__
            return {"selections": [], "diagnostic": summary, "event_id": None}
        detail_game = detail.get("game") or game
        analysis = detail.get("analysis") or {}
        data_basis = analysis.get("data_basis") or {}
        starter_group = (analysis.get("analysis_groups") or {}).get("starter") or {}
        data_quality = float(analysis.get("data_quality") or 0.0)
        model_stage = str(analysis.get("model_stage") or data_basis.get("model_stage") or "base").lower()
        full_model = model_stage == "full"
        full_market_ready = bool(data_basis.get("full_market_ready") or (full_model and starter_group.get("both_starters_ready") is True))
        summary.update({"model_stage": "full" if full_model else "base", "full_model_ready": full_market_ready, "official_lineups_ready": bool(data_basis.get("official_lineups_ready")), "data_quality": round(data_quality, 2)})
        market_analysis = _asian_analysis_for_markets(detail_game, analysis, league)
        event = match_odds_event(market_analysis, available_odds)
        summary["odds_matched"] = bool(event)
        summary["markets"] = list((event.get("markets") or {}).keys()) if event else []
        selections: list[dict] = []
        real_moneyline = None
        if event:
            real_moneyline = moneyline_candidate(market_analysis, event, minimum_probability=0.0, minimum_edge=-100.0)
            run_line = run_line_candidate(market_analysis, event, minimum_probability=0.0, minimum_edge=-100.0, minimum_projection_quality=0.0)
            total = totals_candidate(market_analysis, event, minimum_probability=0.0, minimum_edge=-100.0, minimum_projection_quality=0.0)
            for candidate in (real_moneyline, run_line, total):
                if not candidate:
                    continue
                candidate["league"] = league
                candidate["analysis_mode"] = "real_odds"
                candidate["odds_analysis_included"] = True
                candidate["model_stage"] = "full" if full_model else "base"
                candidate["recommendation_stage"] = "full_markets" if full_model else "advisory_markets"
                candidate["full_market_ready"] = full_market_ready
                candidate["requires_confirmation"] = False
                candidate["data_advisory"] = not full_market_ready or data_quality < 0.55
                candidate["meets_threshold"] = is_asian_baseball_pro_selection(candidate, league)
                candidate["candidate_tier"] = "formal" if candidate["meets_threshold"] else "unclassified"
                candidate.setdefault("qualification_thresholds", {})["minimum_projection_quality"] = 0.0
                selections.append(candidate)
        allow_model_only = (
            league in ASIAN_MODEL_ONLY_FALLBACK_LEAGUES
            or not pro_only
        )
        if real_moneyline is None and allow_model_only:
            model_candidate = model_only_moneyline_candidate(detail_game, analysis, minimum_probability=0.0, minimum_data_quality=0.0)
            if model_candidate:
                model_candidate["league"] = league
                model_candidate["analysis_mode"] = "model_only"
                model_candidate["odds_analysis_included"] = False
                model_candidate["fallback_reason"] = "valid_real_odds_unavailable"
                model_candidate["summary"] = (
                    f"{model_candidate.get('summary') or ''} "
                    "本推薦未採用盤口、賠率、市場機率或市場優勢值。"
                ).strip()
                model_candidate["requires_confirmation"] = False
                model_candidate["meets_threshold"] = True
                model_candidate["candidate_tier"] = "formal"
                selections.append(model_candidate)
        if starter_group.get("both_starters_ready") is not True:
            summary["advisories"].append("預告先發未完整；已降低模型信心，不阻擋免費推薦。")
        if data_quality < 0.55:
            summary["advisories"].append(f"資料完整度 {data_quality * 100:.0f}%，僅作風險提示。")
        summary["candidate_count"] = len(selections)
        summary["formal_count"] = sum(1 for item in selections if item.get("meets_threshold"))
        return {"selections": selections, "diagnostic": summary, "event_id": event.get("event_id") if event else None}

    results = await asyncio.gather(*(build(game) for game in games), return_exceptions=True)
    valid = [item for item in results if isinstance(item, dict)]
    selections = [selection for item in valid for selection in item.get("selections") or [] if isinstance(selection, dict)]
    selections = [calibrate_selection(request, selection, thresholds=pro_only) for selection in selections]
    if diagnostics is not None:
        rows = [item["diagnostic"] for item in valid]
        matched = sum(1 for row in rows if row.get("odds_matched"))
        formal_items = [item for item in selections if item.get("meets_threshold")]
        formal = len(formal_items)
        real_formal = sum(1 for item in formal_items if is_real_odds_selection(item))
        model_formal = sum(
            1
            for item in formal_items
            if is_model_only_asian_moneyline(item, league)
        )
        if real_formal and model_formal:
            state = "ready_mixed"
            message = (
                f"{league} 現有 {real_formal} 個真實盤口候選與 "
                f"{model_formal} 個純模型獨贏候選；缺盤場次不會建立讓分、大小分或串關。"
            )
        elif real_formal:
            state, message = "ready", f"{league} 有效推薦方向＋真實盤口已驗證，現有 {real_formal} 個正式 Pro 候選。"
        elif model_formal and league in ASIAN_MODEL_ONLY_FALLBACK_LEAGUES:
            state = "ready_model_only"
            message = (
                f"{league} 暫無可安全配對的有效真實盤口；現有 {model_formal} 個純模型獨贏候選可發布，"
                "不包含盤口、賠率、市場機率、讓分、大小分或串關。"
            )
        elif not available_odds:
            state, message = "waiting_real_odds", f"盤口商目前尚未提供 {league} 真實盤口；系統不會建立模擬盤口或自動發布 Pro。"
        elif not matched:
            state, message = "odds_unmatched", f"{league} 真實盤口已載入，但尚未和官方賽程安全配對。"
        else:
            state, message = "waiting_valid_selection", f"{league} 盤口已就緒，但目前沒有可驗證的推薦方向。"
        analysis_mode = (
            "mixed"
            if real_formal and model_formal
            else "real_odds"
            if real_formal
            else "model_only"
            if model_formal
            else "unavailable"
        )
        diagnostics.update({"date": target_date.isoformat(), "policy": "real_odds_enhanced_model_fallback" if pro_only and league in ASIAN_MODEL_ONLY_FALLBACK_LEAGUES else "valid_direction_plus_real_odds" if pro_only else "data_advisory", "status": state, "analysis_mode": analysis_mode, "odds_analysis_included": analysis_mode in {"real_odds", "mixed"}, "model_only_fallback_included": analysis_mode in {"model_only", "mixed"}, "schedule_games": len(games), "analyzed_games": len(rows), "full_model_ready_games": sum(1 for row in rows if row.get("full_model_ready")), "odds_events": len(available_odds), "matched_games": matched, "market_coverage": {"moneyline": sum(1 for row in rows if "moneyline" in row.get("markets", [])), "run_line": sum(1 for row in rows if "run_line" in row.get("markets", [])), "totals": sum(1 for row in rows if "totals" in row.get("markets", []))}, "pro_eligible_candidates": len(selections), "formal_candidates": formal, "real_odds_candidates": real_formal, "model_only_candidates": model_formal, "games": rows, "message": message})
    return selections


async def npb_market_candidates_for_date(request: Request, target_date: date, odds_items: list[dict] | None = None, *, pro_only: bool = False, diagnostics: dict | None = None) -> list[dict]:
    return await asian_market_candidates_for_date(request, target_date, "NPB", odds_items, pro_only=pro_only, diagnostics=diagnostics)


async def npb_moneyline_candidates_for_date(request: Request, target_date: date) -> list[dict]:
    """Compatibility wrapper for integrations still requesting NPB moneylines only."""

    candidates = await npb_market_candidates_for_date(request, target_date, [])
    return [item for item in candidates if item.get("market") == "moneyline"]


def _odds_state_key(league: str, target_date: date) -> str:
    return f"{str(league).upper()}:{target_date.isoformat()}"


def _odds_runtime_state_store(request: Request) -> dict[str, dict]:
    """Return process-local cooldown state when a real FastAPI request exists."""

    try:
        state = request.app.state
    except (AttributeError, TypeError):
        return {}
    store = getattr(state, "odds_fetch_state", None)
    if not isinstance(store, dict):
        store = {}
        state.odds_fetch_state = store
    return store


def _odds_runtime_snapshot_store(request: Request) -> dict[str, dict]:
    try:
        state = request.app.state
    except (AttributeError, TypeError):
        return {}
    store = getattr(state, "odds_feed_snapshots", None)
    if not isinstance(store, dict):
        store = {}
        state.odds_feed_snapshots = store
    return store


def _free_odds_optimization_active(request: Request) -> bool:
    """Enable the free-plan router only when its shared runtime state exists.

    Bare adapter calls used by older integrations continue to receive the
    historical primary/fallback order.  Every production HTTP/background
    request has ``app.state`` and therefore uses the quota-protected route.
    """

    if not settings.odds_free_optimization_enabled:
        return False
    try:
        return isinstance(request.app.state.odds_fetch_state, dict)
    except (AttributeError, TypeError):
        return False


def _parse_odds_timestamp(value: object) -> datetime | None:
    text = str(value or "").strip()
    if not text:
        return None
    try:
        parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def _odds_feed_is_live(feed: dict | None) -> bool:
    if not isinstance(feed, dict):
        return False
    meta = feed.get("meta") or {}
    return bool(meta.get("fresh_for_model")) and int(feed.get("count") or 0) > 0


def _odds_feed_captured_at(feed: dict | None) -> str:
    meta = (feed or {}).get("meta") or {}
    value = (
        meta.get("snapshot_captured_at")
        or meta.get("updated_at")
        or meta.get("checked_at")
    )
    parsed = _parse_odds_timestamp(value)
    if parsed is None:
        return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
    return parsed.isoformat().replace("+00:00", "Z")


async def _load_persistent_odds_context(
    request: Request,
    league: str,
    target_date: date,
) -> tuple[dict | None, dict]:
    """Load a persisted feed/cooldown row without making odds depend on SQL."""

    snapshot: dict | None = None
    if settings.odds_snapshot_enabled:
        try:
            repository = records_repository(request)
            getter = getattr(repository, "get_odds_snapshot", None)
            if repository.enabled and getter is not None:
                snapshot = await getter(str(league).upper(), target_date.isoformat())
                try:
                    request.app.state.odds_snapshot_status = {
                        "enabled": True,
                        "schema": "ready",
                        "last_error": None,
                    }
                except (AttributeError, TypeError):
                    pass
        except (AttributeError, RecordsStorageError):
            # V22.4.4 remains backward-compatible while the founder
            # runs the one-time SQL. Live providers remain usable meanwhile.
            try:
                request.app.state.odds_snapshot_status = {
                    "enabled": True,
                    "schema": "migration_required",
                    "last_error": "odds_snapshots_unavailable",
                }
            except (AttributeError, TypeError):
                pass

    persisted_state = deepcopy((snapshot or {}).get("fetch_state") or {})
    runtime_store = _odds_runtime_state_store(request)
    runtime_snapshot = deepcopy(
        _odds_runtime_snapshot_store(request).get(
            _odds_state_key(league, target_date)
        )
        or {}
    )
    if runtime_snapshot:
        persisted_captured = _parse_odds_timestamp((snapshot or {}).get("captured_at"))
        runtime_captured = _parse_odds_timestamp(runtime_snapshot.get("captured_at"))
        if (
            snapshot is None
            or runtime_captured is not None
            and (
                persisted_captured is None
                or runtime_captured >= persisted_captured
            )
        ):
            snapshot = runtime_snapshot
    runtime_state = deepcopy(
        runtime_store.get(_odds_state_key(league, target_date)) or {}
    )
    providers = {
        **deepcopy(persisted_state.get("providers") or {}),
        **deepcopy(runtime_state.get("providers") or {}),
    }
    return snapshot, {"providers": providers}


def _provider_probe_due(
    fetch_state: dict,
    provider: str,
    *,
    now: datetime | None = None,
) -> bool:
    state = ((fetch_state.get("providers") or {}).get(provider) or {})
    next_attempt = _parse_odds_timestamp(state.get("next_attempt_at"))
    current = now or datetime.now(timezone.utc)
    if current.tzinfo is None:
        current = current.replace(tzinfo=timezone.utc)
    return next_attempt is None or current.astimezone(timezone.utc) >= next_attempt


def _mark_provider_probe(
    fetch_state: dict,
    provider: str,
    *,
    result: str,
    cooldown_minutes: int,
    error: dict | None = None,
    now: datetime | None = None,
) -> None:
    current = now or datetime.now(timezone.utc)
    if current.tzinfo is None:
        current = current.replace(tzinfo=timezone.utc)
    current = current.astimezone(timezone.utc)
    providers = fetch_state.setdefault("providers", {})
    providers[provider] = {
        "last_attempt_at": current.isoformat().replace("+00:00", "Z"),
        "next_attempt_at": (
            current + timedelta(minutes=max(1, int(cooldown_minutes)))
        ).isoformat().replace("+00:00", "Z"),
        "last_result": result,
        "last_error": deepcopy(error or {}),
    }


async def _persist_odds_context(
    request: Request,
    league: str,
    target_date: date,
    *,
    snapshot: dict | None,
    fetch_state: dict,
    live_feed: dict | None = None,
) -> None:
    runtime_store = _odds_runtime_state_store(request)
    state_key = _odds_state_key(league, target_date)
    runtime_store[state_key] = deepcopy(fetch_state)
    if _odds_feed_is_live(live_feed):
        _odds_runtime_snapshot_store(request)[state_key] = {
            "league": str(league).upper(),
            "odds_date": target_date.isoformat(),
            "provider": str((live_feed.get("meta") or {}).get("provider") or "") or None,
            "feed": deepcopy(live_feed),
            "captured_at": _odds_feed_captured_at(live_feed),
            "fetch_state": deepcopy(fetch_state),
        }
    if not settings.odds_snapshot_enabled:
        return
    try:
        repository = records_repository(request)
        writer = getattr(repository, "upsert_odds_snapshot", None)
        if not repository.enabled or writer is None:
            return
        if _odds_feed_is_live(live_feed):
            feed = deepcopy(live_feed)
            captured_at = _odds_feed_captured_at(feed)
            provider = str((feed.get("meta") or {}).get("provider") or "") or None
        else:
            feed = deepcopy((snapshot or {}).get("feed") or {})
            captured_at = (snapshot or {}).get("captured_at")
            provider = (snapshot or {}).get("provider")
        await writer(
            str(league).upper(),
            target_date.isoformat(),
            provider=provider,
            feed=feed,
            captured_at=captured_at,
            fetch_state=fetch_state,
        )
        try:
            request.app.state.odds_snapshot_status = {
                "enabled": True,
                "schema": "ready",
                "last_error": None,
            }
        except (AttributeError, TypeError):
            pass
    except (AttributeError, RecordsStorageError):
        try:
            request.app.state.odds_snapshot_status = {
                "enabled": True,
                "schema": "migration_required",
                "last_error": "odds_snapshots_unavailable",
            }
        except (AttributeError, TypeError):
            pass


def _persistent_odds_feed(
    snapshot: dict | None,
    *,
    attempted_providers: list[str],
    provider_skips: list[dict],
    primary_error: dict | None = None,
    fallback_error: dict | None = None,
) -> dict | None:
    """Return a bounded stored feed; only recent rows can unlock new Pro."""

    stored = deepcopy((snapshot or {}).get("feed") or {})
    captured_at = _parse_odds_timestamp((snapshot or {}).get("captured_at"))
    if not stored or captured_at is None or int(stored.get("count") or 0) <= 0:
        return None
    age_minutes = max(
        0.0,
        (datetime.now(timezone.utc) - captured_at).total_seconds() / 60.0,
    )
    display_limit = settings.odds_snapshot_display_hours * 60
    within_display = age_minutes <= display_limit
    publish_fresh = (
        within_display
        and age_minutes <= settings.odds_snapshot_publish_fresh_minutes
    )
    meta = stored.setdefault("meta", {})
    meta.update(
        {
            "provider": meta.get("provider") or (snapshot or {}).get("provider"),
            "provider_chain": attempted_providers
            or [meta.get("provider") or (snapshot or {}).get("provider")],
            "provider_skips": provider_skips,
            "cache": "persistent_snapshot",
            "persistent_snapshot": True,
            "snapshot_captured_at": captured_at.isoformat().replace("+00:00", "Z"),
            "snapshot_age_minutes": round(age_minutes, 1),
            "snapshot_display_limit_hours": settings.odds_snapshot_display_hours,
            "snapshot_publish_fresh_minutes": settings.odds_snapshot_publish_fresh_minutes,
            "fresh_for_model": publish_fresh,
            "availability_reason": (
                "stored_snapshot_fresh"
                if publish_fresh
                else "stored_snapshot_stale"
                if within_display
                else "stored_snapshot_expired"
            ),
        }
    )
    if primary_error:
        meta["primary_error"] = primary_error
    if fallback_error:
        meta["fallback_error"] = fallback_error
    if not within_display:
        stored["count"] = 0
        stored["items"] = []
    return stored


def _primary_error_payload(error: OddsUpstreamError) -> dict:
    return {
        "provider": "The Odds API",
        "status_code": error.status_code,
        "error_code": error.error_code,
        "provider_detail": error.provider_detail,
    }


async def asian_odds_feed_for_date(
    request: Request, target_date: date, league: str, *, priority: bool = False
) -> dict:
    """Return Asian baseball odds using quota-aware provider routing.

    NPB/KBO receive one bounded The Odds API probe per cooldown window and then
    use Odds-API.io. CPBL prefers Odds-API.io because The Odds API normally
    lacks that sport. Every verified feed is persisted; provider cooldowns and
    the last real line therefore survive a Render restart.
    """
    code = _prediction_league(league)
    policy = _asian_auto_settings(code)
    empty = {
        "date": target_date.isoformat(),
        "timezone": "Asia/Taipei",
        "configured": False,
        "count": 0,
        "items": [],
        "meta": {"fresh_for_model": False, "coverage": {}, "quota": {}},
    }
    snapshot, fetch_state = await _load_persistent_odds_context(
        request, code, target_date
    )
    optimized = _free_odds_optimization_active(request)
    primary_service = odds_service(request)
    fallback_service = odds_api_io_service(request)
    fallback_fetcher = getattr(
        fallback_service,
        f"odds_for_{code.lower()}_date",
        None,
    )
    primary_enabled = bool(primary_service.enabled and policy.get("odds_key"))
    fallback_enabled = bool(fallback_service.enabled and fallback_fetcher is not None)

    # CPBL avoids a usually unsupported monthly-credit probe while the daily
    # fallback is configured. If the fallback is absent, preserve availability
    # by allowing the configured primary adapter.
    route = ["primary", "fallback"]
    if optimized and code == "CPBL" and fallback_enabled:
        route = ["fallback"]

    snapshot_provider = str(
        (snapshot or {}).get("provider")
        or (((snapshot or {}).get("feed") or {}).get("meta") or {}).get("provider")
        or ""
    )
    if (
        optimized
        and snapshot_provider
        and not _provider_probe_due(fetch_state, snapshot_provider)
    ):
        state = ((fetch_state.get("providers") or {}).get(snapshot_provider) or {})
        stored_feed = _persistent_odds_feed(
            snapshot,
            attempted_providers=[],
            provider_skips=[
                {
                    "provider": snapshot_provider,
                    "reason": "cooldown",
                    "next_attempt_at": state.get("next_attempt_at"),
                }
            ],
        )
        if stored_feed is not None and (stored_feed.get("meta") or {}).get(
            "fresh_for_model"
        ):
            (stored_feed.get("meta") or {})["free_plan_optimized"] = True
            return stored_feed

    primary: dict | None = None
    primary_error: OddsUpstreamError | None = None
    fallback: dict | None = None
    fallback_error: OddsApiIoUpstreamError | None = None
    attempted: list[str] = []
    provider_skips: list[dict] = []

    for provider_kind in route:
        if provider_kind == "primary":
            provider_name = "The Odds API"
            if not primary_enabled:
                continue
            if optimized and not _provider_probe_due(fetch_state, provider_name):
                state = ((fetch_state.get("providers") or {}).get(provider_name) or {})
                provider_skips.append(
                    {
                        "provider": provider_name,
                        "reason": "cooldown",
                        "next_attempt_at": state.get("next_attempt_at"),
                    }
                )
                continue
            attempted.append(provider_name)
            try:
                primary = await primary_service.odds_for_date(
                    target_date,
                    sport_key=policy["odds_key"],
                )
                result = "available" if _odds_feed_is_live(primary) else "empty"
                _mark_provider_probe(
                    fetch_state,
                    provider_name,
                    result=result,
                    cooldown_minutes=settings.odds_primary_probe_cooldown_minutes,
                )
                primary_meta = primary.setdefault("meta", {})
                primary_meta.update(
                    {
                        "provider_chain": list(attempted),
                        "provider_skips": provider_skips,
                        "availability_reason": (
                            "available"
                            if result == "available"
                            else "primary_empty_or_stale"
                        ),
                        "free_plan_optimized": optimized,
                    }
                )
                if _odds_feed_is_live(primary):
                    await _persist_odds_context(
                        request,
                        code,
                        target_date,
                        snapshot=snapshot,
                        fetch_state=fetch_state,
                        live_feed=primary,
                    )
                    return primary
            except OddsUpstreamError as exc:
                primary_error = exc
                diagnostic = _primary_error_payload(exc)
                quota_exhausted = exc.error_code == "OUT_OF_USAGE_CREDITS"
                _mark_provider_probe(
                    fetch_state,
                    provider_name,
                    result="quota_exhausted" if quota_exhausted else "error",
                    cooldown_minutes=(
                        settings.odds_primary_quota_retry_minutes
                        if quota_exhausted
                        else settings.odds_primary_probe_cooldown_minutes
                    ),
                    error=diagnostic,
                )

        if provider_kind == "fallback":
            provider_name = "Odds-API.io"
            if not fallback_enabled:
                continue
            if optimized and not _provider_probe_due(fetch_state, provider_name):
                state = ((fetch_state.get("providers") or {}).get(provider_name) or {})
                provider_skips.append(
                    {
                        "provider": provider_name,
                        "reason": "cooldown",
                        "next_attempt_at": state.get("next_attempt_at"),
                    }
                )
                continue
            attempted.append(provider_name)
            try:
                fallback = await fallback_fetcher(
                    target_date,
                    priority=priority,
                )
                result = "available" if _odds_feed_is_live(fallback) else "empty"
                _mark_provider_probe(
                    fetch_state,
                    provider_name,
                    result=result,
                    cooldown_minutes=settings.odds_fallback_probe_cooldown_minutes,
                )
                fallback_meta = fallback.setdefault("meta", {})
                fallback_reason = (
                    primary_error.error_code
                    if primary_error is not None and primary_error.error_code
                    else type(primary_error).__name__
                    if primary_error is not None
                    else "primary_empty_or_stale"
                    if primary is not None
                    else "free_plan_preferred"
                    if optimized and code == "CPBL"
                    else "primary_not_configured"
                    if not primary_enabled
                    else "primary_cooldown"
                    if provider_skips
                    else "primary_unavailable"
                )
                fallback_meta.update(
                    {
                        "provider_chain": list(attempted),
                        "provider_skips": provider_skips,
                        "fallback_activated": bool(
                            primary is not None or primary_error is not None
                        ),
                        "fallback_reason": fallback_reason,
                        "availability_reason": (
                            "available"
                            if result == "available"
                            else "fallback_empty_or_stale"
                        ),
                        "free_plan_optimized": optimized,
                    }
                )
                if primary_error is not None:
                    fallback_meta["primary_error"] = _primary_error_payload(
                        primary_error
                    )
                if _odds_feed_is_live(fallback):
                    await _persist_odds_context(
                        request,
                        code,
                        target_date,
                        snapshot=snapshot,
                        fetch_state=fetch_state,
                        live_feed=fallback,
                    )
                    return fallback
            except OddsApiIoUpstreamError as exc:
                fallback_error = exc
                _mark_provider_probe(
                    fetch_state,
                    provider_name,
                    result="error",
                    cooldown_minutes=settings.odds_fallback_probe_cooldown_minutes,
                    error=exc.diagnostic(),
                )

    primary_error_payload = (
        _primary_error_payload(primary_error) if primary_error is not None else None
    )
    fallback_error_payload = (
        fallback_error.diagnostic() if fallback_error is not None else None
    )
    stored_feed = _persistent_odds_feed(
        snapshot,
        attempted_providers=attempted,
        provider_skips=provider_skips,
        primary_error=primary_error_payload,
        fallback_error=fallback_error_payload,
    )
    await _persist_odds_context(
        request,
        code,
        target_date,
        snapshot=snapshot,
        fetch_state=fetch_state,
    )
    if stored_feed is not None:
        return stored_feed

    if fallback is not None:
        fallback_meta = fallback.setdefault("meta", {})
        fallback_meta.update(
            {
                "provider_chain": attempted,
                "provider_skips": provider_skips,
                "free_plan_optimized": optimized,
            }
        )
        if primary_error_payload:
            fallback_meta["primary_error"] = primary_error_payload
        return fallback
    if primary is not None:
        primary_meta = primary.setdefault("meta", {})
        primary_meta["provider_chain"] = attempted
        primary_meta["provider_skips"] = provider_skips
        primary_meta["fallback_activated"] = bool(fallback_enabled)
        primary_meta["free_plan_optimized"] = optimized
        primary_meta["availability_reason"] = (
            "fallback_unavailable"
            if fallback_error is not None
            else "primary_empty_or_stale"
        )
        if fallback_error is not None:
            primary_meta["fallback_error"] = fallback_error.diagnostic()
        return primary

    failure = {
        **empty,
        "meta": {
            **empty["meta"],
            "provider": None,
            "provider_chain": attempted,
            "provider_skips": provider_skips,
            "fallback_activated": bool(fallback_enabled),
            "free_plan_optimized": optimized,
            "availability_reason": "providers_unavailable",
        },
    }
    if primary_error_payload is not None:
        failure["meta"]["primary_error"] = primary_error_payload
        if primary_error.error_code == "OUT_OF_USAGE_CREDITS":
            failure["meta"]["availability_reason"] = "primary_quota_exhausted"
    if fallback_error_payload is not None:
        failure["meta"]["fallback_error"] = fallback_error_payload
    return failure


def _asian_odds_waiting_state(league: str, feed: dict) -> tuple[str, str]:
    """Return an accurate founder-facing reason for an empty Asian odds feed."""

    code = _prediction_league(league)
    model_fallback = code in ASIAN_MODEL_ONLY_FALLBACK_LEAGUES
    fallback_note = (
        "該盤口不會納入新發布；系統仍可改用純模型獨贏，且不會建立模擬盤口、讓分、大小分或串關。"
        if model_fallback
        else "系統不會建立模擬盤口或自動發布 Pro。"
    )
    meta = feed.get("meta") or {}
    primary_error = meta.get("primary_error") or {}
    error_code = str(primary_error.get("error_code") or "")
    fallback_error = meta.get("fallback_error") or {}
    coverage_status = str(meta.get("coverage_status") or "")
    availability_reason = str(meta.get("availability_reason") or "")
    if availability_reason in {"stored_snapshot_stale", "stored_snapshot_expired"}:
        captured = str(meta.get("snapshot_captured_at") or "").strip()
        time_note = f"（最後取得 {captured}）" if captured else ""
        return (
            "odds_snapshot_stale",
            f"{code} 目前只有超過正式發布鮮度的最後真實盤口{time_note}；可供創辦人查看，{fallback_note}",
        )
    if error_code == "OUT_OF_USAGE_CREDITS":
        if coverage_status == f"{code.lower()}_not_listed":
            message = (
                f"{code} 主要盤口 API 額度已用盡，Odds-API.io 備援目前未找到 "
                f"{code} 聯盟盤口；{fallback_note}"
            )
        elif fallback_error:
            message = (
                f"{code} 主要盤口 API 額度已用盡，Odds-API.io 備援暫時也無法取得 "
                f"真實盤口；{fallback_note}"
            )
        else:
            message = (
                f"{code} 主要盤口 API 額度已用盡；Odds-API.io 備援目前也沒有可用 "
                f"真實盤口；{fallback_note}"
            )
        return "odds_quota_exhausted", message
    if availability_reason in {"providers_unavailable", "fallback_unavailable"}:
        return (
            "odds_providers_unavailable",
            f"{code} 主盤口與備援來源暫時皆無法取得；{fallback_note}",
        )
    return (
        "waiting_real_odds",
        f"盤口商目前尚未提供 {code} 真實盤口；{fallback_note}",
    )


async def mlb_odds_feed_for_date(
    request: Request,
    target_date: date,
    *,
    priority: bool = False,
) -> dict:
    """Return MLB real odds while preserving scarce monthly primary credits.

    In production Odds-API.io is preferred for MLB. The Odds API is used only
    when the daily-limit provider cannot supply a live feed and its own bounded
    cooldown has expired. Older bare adapter integrations retain the historical
    primary/fallback order for backward compatibility.
    """
    snapshot, fetch_state = await _load_persistent_odds_context(
        request, "MLB", target_date
    )
    optimized = _free_odds_optimization_active(request)
    primary_service = odds_service(request)
    fallback_service = odds_api_io_service(request)
    primary_enabled = bool(primary_service.enabled)
    fallback_enabled = bool(fallback_service.enabled)
    route = ["fallback", "primary"] if optimized else ["primary", "fallback"]
    snapshot_provider = str(
        (snapshot or {}).get("provider")
        or (((snapshot or {}).get("feed") or {}).get("meta") or {}).get("provider")
        or ""
    )
    if (
        optimized
        and snapshot_provider
        and not _provider_probe_due(fetch_state, snapshot_provider)
    ):
        state = ((fetch_state.get("providers") or {}).get(snapshot_provider) or {})
        stored_feed = _persistent_odds_feed(
            snapshot,
            attempted_providers=[],
            provider_skips=[
                {
                    "provider": snapshot_provider,
                    "reason": "cooldown",
                    "next_attempt_at": state.get("next_attempt_at"),
                }
            ],
        )
        if stored_feed is not None and (stored_feed.get("meta") or {}).get(
            "fresh_for_model"
        ):
            (stored_feed.get("meta") or {})["free_plan_optimized"] = True
            return stored_feed
    primary: dict | None = None
    primary_error: OddsUpstreamError | None = None
    fallback: dict | None = None
    fallback_error: OddsApiIoUpstreamError | None = None
    attempted: list[str] = []
    provider_skips: list[dict] = []

    for provider_kind in route:
        if provider_kind == "fallback":
            provider_name = "Odds-API.io"
            if not fallback_enabled:
                continue
            if optimized and not _provider_probe_due(fetch_state, provider_name):
                state = ((fetch_state.get("providers") or {}).get(provider_name) or {})
                provider_skips.append(
                    {
                        "provider": provider_name,
                        "reason": "cooldown",
                        "next_attempt_at": state.get("next_attempt_at"),
                    }
                )
                continue
            attempted.append(provider_name)
            try:
                fallback = await fallback_service.odds_for_mlb_date(
                    target_date,
                    priority=priority,
                )
                result = "available" if _odds_feed_is_live(fallback) else "empty"
                _mark_provider_probe(
                    fetch_state,
                    provider_name,
                    result=result,
                    cooldown_minutes=settings.odds_fallback_probe_cooldown_minutes,
                )
                fallback_meta = fallback.setdefault("meta", {})
                fallback_meta.update(
                    {
                        "provider_chain": list(attempted),
                        "provider_skips": provider_skips,
                        "fallback_activated": not optimized,
                        "fallback_reason": (
                            type(primary_error).__name__
                            if primary_error is not None
                            else "primary_empty_or_stale"
                            if primary is not None
                            else "free_plan_preferred"
                            if optimized
                            else "primary_unavailable"
                        ),
                        "availability_reason": (
                            "available"
                            if result == "available"
                            else "fallback_empty_or_stale"
                        ),
                        "free_plan_optimized": optimized,
                    }
                )
                if primary_error is not None:
                    fallback_meta["primary_error"] = _primary_error_payload(
                        primary_error
                    )
                if _odds_feed_is_live(fallback):
                    await _persist_odds_context(
                        request,
                        "MLB",
                        target_date,
                        snapshot=snapshot,
                        fetch_state=fetch_state,
                        live_feed=fallback,
                    )
                    return fallback
            except OddsApiIoUpstreamError as exc:
                fallback_error = exc
                _mark_provider_probe(
                    fetch_state,
                    provider_name,
                    result="error",
                    cooldown_minutes=settings.odds_fallback_probe_cooldown_minutes,
                    error=exc.diagnostic(),
                )

        if provider_kind == "primary":
            provider_name = "The Odds API"
            if not primary_enabled:
                continue
            if optimized and not _provider_probe_due(fetch_state, provider_name):
                state = ((fetch_state.get("providers") or {}).get(provider_name) or {})
                provider_skips.append(
                    {
                        "provider": provider_name,
                        "reason": "cooldown",
                        "next_attempt_at": state.get("next_attempt_at"),
                    }
                )
                continue
            attempted.append(provider_name)
            try:
                primary = await primary_service.odds_for_date(target_date)
                result = "available" if _odds_feed_is_live(primary) else "empty"
                _mark_provider_probe(
                    fetch_state,
                    provider_name,
                    result=result,
                    cooldown_minutes=settings.odds_primary_probe_cooldown_minutes,
                )
                primary_meta = primary.setdefault("meta", {})
                primary_meta.update(
                    {
                        "provider_chain": list(attempted),
                        "provider_skips": provider_skips,
                        "fallback_activated": bool(fallback is not None or fallback_error),
                        "fallback_reason": (
                            type(fallback_error).__name__
                            if fallback_error is not None
                            else "preferred_provider_empty_or_stale"
                            if fallback is not None
                            else None
                        ),
                        "availability_reason": (
                            "available"
                            if result == "available"
                            else "primary_empty_or_stale"
                        ),
                        "free_plan_optimized": optimized,
                    }
                )
                if fallback_error is not None:
                    primary_meta["fallback_error"] = fallback_error.diagnostic()
                if _odds_feed_is_live(primary):
                    await _persist_odds_context(
                        request,
                        "MLB",
                        target_date,
                        snapshot=snapshot,
                        fetch_state=fetch_state,
                        live_feed=primary,
                    )
                    return primary
            except OddsUpstreamError as exc:
                primary_error = exc
                diagnostic = _primary_error_payload(exc)
                quota_exhausted = exc.error_code == "OUT_OF_USAGE_CREDITS"
                _mark_provider_probe(
                    fetch_state,
                    provider_name,
                    result="quota_exhausted" if quota_exhausted else "error",
                    cooldown_minutes=(
                        settings.odds_primary_quota_retry_minutes
                        if quota_exhausted
                        else settings.odds_primary_probe_cooldown_minutes
                    ),
                    error=diagnostic,
                )

    stored_feed = _persistent_odds_feed(
        snapshot,
        attempted_providers=attempted,
        provider_skips=provider_skips,
        primary_error=(
            _primary_error_payload(primary_error)
            if primary_error is not None
            else None
        ),
        fallback_error=(
            fallback_error.diagnostic() if fallback_error is not None else None
        ),
    )
    await _persist_odds_context(
        request,
        "MLB",
        target_date,
        snapshot=snapshot,
        fetch_state=fetch_state,
    )
    if stored_feed is not None:
        return stored_feed

    # Preserve a successful-but-empty feed so the caller can distinguish
    # "no markets posted yet" from a provider outage.
    if fallback is not None:
        fallback_meta = fallback.setdefault("meta", {})
        fallback_meta.update(
            {
                "provider_chain": attempted,
                "provider_skips": provider_skips,
                "free_plan_optimized": optimized,
            }
        )
        return fallback
    if primary is not None:
        primary_meta = primary.setdefault("meta", {})
        primary_meta.update(
            {
                "provider_chain": attempted,
                "provider_skips": provider_skips,
                "free_plan_optimized": optimized,
            }
        )
        return primary
    error = fallback_error or primary_error
    raise OddsUpstreamError("MLB real-odds providers are temporarily unavailable") from error


async def _candidate_stage_retry(label: str, operation, *, attempts: int = 2, timeout_seconds: float = 35.0):
    """Run one candidate-building stage with bounded retry and timeout.

    Candidate discovery is an operator-facing read action. Upstream failures should
    degrade to a structured waiting state instead of escaping as a gateway error.
    """
    last_error = None
    for attempt in range(1, max(1, attempts) + 1):
        try:
            return await asyncio.wait_for(operation(), timeout=timeout_seconds)
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # upstream libraries expose several exception types
            last_error = exc
            if attempt < attempts:
                await asyncio.sleep(1.5 * attempt)
    raise RuntimeError(f"{label}: {last_error or 'unknown error'}") from last_error


def _candidate_waiting_bundle(target_date: date, league: str, *, stage: str, message: str, retryable: bool = True) -> dict:
    code = _prediction_league(league)
    empty = build_daily_market_candidates(
        target_date.isoformat(), [], [], None,
        minimum_probability=settings.min_market_probability,
        minimum_edge=settings.min_market_edge,
        minimum_projection_quality=settings.min_projection_quality,
        minimum_parlay_probability=settings.min_parlay_leg_probability,
    )
    empty.update({
        "date": target_date.isoformat(),
        "selected_league": code,
        "available": False,
        "retryable": retryable,
        "failure_stage": stage,
        "message": message,
        "diagnostics": {
            "schedule": {"status": "waiting" if stage == "schedule" else "unknown"},
            "odds": {"status": "waiting" if stage == "odds" else "unknown"},
            "model": {"status": "waiting" if stage in {"schedule", "model"} else "unknown"},
            "recommendations": {"status": "unavailable", "count": 0},
        },
        "readiness": {code: {
            "ready": False,
            "message": message,
            "schedule_games": 0,
            "analyzed_games": 0,
            "matched_games": 0,
            "formal_candidates": 0,
            "coverage": {"moneyline": 0, "run_line": 0, "totals": 0},
        }},
        "odds_feeds": {code: {"count": 0, "fresh_for_model": False, "provider": "waiting"}},
        "league_status": {code: {"enabled": True, "formal": 0, "markets": {}, "real_odds": False}},
    })
    return empty


async def founder_market_candidate_bundle(
    request: Request, target_date: date, league: str = "MLB", *, priority: bool = False
) -> dict:
    league = _prediction_league(league)
    repository = records_repository(request)
    try:
        public_record = await repository.get_record_for_date(target_date.isoformat(), league)
    except RecordsStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    public_selection = None
    if public_record and isinstance(public_record.get("prediction_snapshot"), dict):
        candidate = public_record["prediction_snapshot"]
        if _selection_matches_league(candidate, league):
            public_selection = candidate

    if league == "MLB":
        if not odds_service(request).enabled and not odds_api_io_service(request).enabled:
            return _candidate_waiting_bundle(
                target_date, league, stage="odds",
                message="真實盤口來源尚未設定；目前不能建立正式會員玩法。",
                retryable=False,
            )
        try:
            schedule = await _candidate_stage_retry(
                "MLB 官方賽程",
                lambda: service(request).games_for_date(target_date),
                attempts=2,
                timeout_seconds=24.0,
            )
        except Exception:
            return _candidate_waiting_bundle(
                target_date,
                league,
                stage="schedule",
                message="MLB 官方賽程暫時無法確認；系統已重試，請稍後重新載入。",
            )
        schedule_items = [
            item
            for item in schedule.get("items") or []
            if isinstance(item, dict)
        ]
        upcoming_games = [
            item for item in schedule_items
            if item.get("status") == "upcoming"
        ]
        if not upcoming_games:
            if schedule_items:
                message = "所選日期的 MLB 場次均已開賽或結束，已停止建立新的正式會員玩法。"
            else:
                message = "MLB 官方賽程已確認；所選日期目前沒有可發布的未開賽賽事。"
            waiting = _candidate_waiting_bundle(
                target_date,
                league,
                stage="schedule",
                message=message,
                retryable=False,
            )
            waiting["diagnostics"]["schedule"] = {
                "status": "confirmed",
                "games": len(schedule_items),
                "upcoming": 0,
                "live": sum(1 for item in schedule_items if item.get("status") == "live"),
                "final": sum(1 for item in schedule_items if item.get("status") == "final"),
            }
            waiting["diagnostics"]["odds"]["status"] = "not_required"
            waiting["diagnostics"]["model"]["status"] = "not_required"
            waiting["readiness"]["MLB"]["schedule_games"] = len(schedule_items)
            return waiting
        try:
            feed = await _candidate_stage_retry(
                "MLB 真實盤口",
                lambda: mlb_odds_feed_for_date(
                    request,
                    target_date,
                    priority=priority,
                ),
                attempts=1,
                timeout_seconds=45.0,
            )
        except Exception as exc:
            waiting = _candidate_waiting_bundle(
                target_date, league, stage="odds",
                message="MLB 兩個真實盤口來源目前皆無法取得；請稍後重新載入。",
            )
            last = (odds_service(request).status().get("last_checks") or {}).get("MLB") or {}
            fallback_last = (
                odds_api_io_service(request).status().get("last_checks") or {}
            ).get("MLB") or {}
            waiting["diagnostics"]["odds"].update({
                "error": last.get("last_error") or type(exc).__name__,
                "error_code": last.get("error_code"),
                "status_code": last.get("status_code"),
                "provider_detail": last.get("provider_detail"),
                "consecutive_failures": int(last.get("consecutive_failures") or 0),
                "checked_at": last.get("checked_at"),
                "providers": {
                    "primary": {
                        "provider": "The Odds API",
                        "status": "unavailable",
                        "checked_at": last.get("checked_at"),
                    },
                    "fallback": {
                        "provider": "Odds-API.io",
                        "status": "unavailable",
                        "checked_at": fallback_last.get("checked_at"),
                        "last_error": fallback_last.get("last_error"),
                    },
                },
            })
            return waiting
        feed_meta = feed.get("meta") or {}
        if not feed_meta.get("fresh_for_model"):
            captured = feed_meta.get("snapshot_captured_at")
            waiting = _candidate_waiting_bundle(
                target_date, league, stage="odds",
                message=(
                    f"MLB 目前只有最後真實盤口（取得時間 {captured}），已超過正式發布鮮度；"
                    "可查看但不會拿來建立新的會員玩法。"
                    if captured
                    else "MLB 目前只有過期備援盤口；等待最新正式盤口後即可建立會員玩法。"
                ),
            )
            waiting["diagnostics"]["odds"].update({
                "status": "snapshot_stale",
                "provider": feed_meta.get("provider"),
                "persistent_snapshot": bool(feed_meta.get("persistent_snapshot")),
                "snapshot_captured_at": captured,
                "snapshot_age_minutes": feed_meta.get("snapshot_age_minutes"),
                "availability_reason": feed_meta.get("availability_reason"),
            })
            waiting["readiness"]["MLB"]["odds_feed"] = {
                "count": int(feed.get("count") or 0),
                "fresh_for_model": False,
                "provider": feed_meta.get("provider"),
                "persistent_snapshot": bool(feed_meta.get("persistent_snapshot")),
                "snapshot_captured_at": captured,
                "snapshot_age_minutes": feed_meta.get("snapshot_age_minutes"),
                "availability_reason": feed_meta.get("availability_reason"),
            }
            return waiting
        if int(feed.get("count") or 0) <= 0:
            waiting = _candidate_waiting_bundle(
                target_date,
                league,
                stage="odds",
                message="MLB 官方賽程已確認，但兩個真實盤口來源尚未提供所選日期盤口；系統不會使用模擬資料。",
            )
            waiting["diagnostics"]["schedule"] = {
                "status": "confirmed",
                "games": len(schedule_items),
                "upcoming": len(upcoming_games),
            }
            waiting["diagnostics"]["odds"].update({
                "status": "waiting",
                "provider": feed_meta.get("provider"),
                "provider_chain": feed_meta.get("provider_chain") or [],
                "coverage": feed_meta.get("coverage") or {},
                "coverage_status": feed_meta.get("coverage_status") or "no_odds",
            })
            waiting["readiness"]["MLB"]["schedule_games"] = len(schedule_items)
            return waiting
        try:
            analyses = await _candidate_stage_retry(
                "MLB 官方數據模型",
                lambda: service(request).matchup_analyses(target_date, pitcher_limit=None),
                attempts=2,
                timeout_seconds=38.0,
            )
        except Exception:
            return _candidate_waiting_bundle(
                target_date, league, stage="model",
                message="MLB 官方數據或模型分析暫時無法完成；盤口資料仍保留，可稍後重試。",
            )
        # Founder candidate loading must not disappear merely because a game
        # misses an automatic-publish threshold. Include every upcoming matchup
        # that has a usable model snapshot; build_daily_market_candidates will
        # still separate formal candidates from watchlist items. Real odds and
        # game-state validation remain mandatory at publish time.
        eligible = [
            item
            for item in analyses.get("items") or []
            if isinstance(item, dict)
            and (item.get("game") or {}).get("status") not in {"final", "live", "postponed", "cancelled", "canceled"}
        ]
        bundle = build_daily_market_candidates(
            target_date.isoformat(),
            eligible,
            feed.get("items") or [],
            public_selection,
            minimum_probability=settings.min_market_probability,
            minimum_edge=settings.min_market_edge,
            minimum_projection_quality=settings.min_projection_quality,
            minimum_parlay_probability=settings.min_parlay_leg_probability,
        )
        bundle["odds_feeds"] = {
            "MLB": {
                "count": int(feed.get("count") or 0),
                "fresh_for_model": True,
                "cache": feed_meta.get("cache"),
                "provider": feed_meta.get("provider"),
                "provider_chain": feed_meta.get("provider_chain") or [
                    feed_meta.get("provider")
                ],
                "fallback_activated": bool(feed_meta.get("fallback_activated")),
                "coverage": feed_meta.get("coverage") or {},
                "persistent_snapshot": bool(feed_meta.get("persistent_snapshot")),
                "snapshot_captured_at": feed_meta.get("snapshot_captured_at"),
                "snapshot_age_minutes": feed_meta.get("snapshot_age_minutes"),
                "availability_reason": feed_meta.get("availability_reason"),
                "provider_skips": feed_meta.get("provider_skips") or [],
            }
        }
    else:
        league_policy = _asian_auto_settings(league)
        feed = await asian_odds_feed_for_date(
            request, target_date, league, priority=priority
        )
        feed_meta = feed.get("meta") or {}
        bundle = build_daily_market_candidates(
            target_date.isoformat(), [], [], public_selection,
            minimum_probability=settings.min_market_probability,
            minimum_edge=settings.min_market_edge,
            minimum_projection_quality=settings.min_projection_quality,
            minimum_parlay_probability=settings.min_parlay_leg_probability,
        )
        readiness: dict = {}
        asian_candidates = await asian_market_candidates_for_date(
            request, target_date, league,
            (feed.get("items") or []) if feed_meta.get("fresh_for_model") else [],
            pro_only=True, diagnostics=readiness,
        )
        bundle = merge_market_candidates(bundle, asian_candidates, minimum_parlay_probability=settings.min_parlay_leg_probability)
        bundle["odds_feeds"] = {
            league: {
                "sport_key": league_policy.get("odds_key"),
                "count": int(feed.get("count") or 0),
                "fresh_for_model": bool(feed_meta.get("fresh_for_model")),
                "cache": feed_meta.get("cache"),
                "coverage": feed_meta.get("coverage") or {},
                "quota": feed_meta.get("quota") or {},
                "provider": feed_meta.get("provider"),
                "provider_chain": feed_meta.get("provider_chain") or [],
                "fallback_activated": bool(feed_meta.get("fallback_activated")),
                "fallback_reason": feed_meta.get("fallback_reason"),
                "provider_league": feed_meta.get("provider_league"),
                "coverage_status": feed_meta.get("coverage_status"),
                "availability_reason": feed_meta.get("availability_reason"),
                "persistent_snapshot": bool(feed_meta.get("persistent_snapshot")),
                "snapshot_captured_at": feed_meta.get("snapshot_captured_at"),
                "snapshot_age_minutes": feed_meta.get("snapshot_age_minutes"),
                "provider_skips": feed_meta.get("provider_skips") or [],
                "primary_error": feed_meta.get("primary_error") or {},
                "fallback_error": feed_meta.get("fallback_error") or {},
            }
        }
        readiness["odds_feed"] = bundle["odds_feeds"][league]
        if (
            int(feed.get("count") or 0) <= 0
            or not bool(feed_meta.get("fresh_for_model"))
        ):
            if not (
                league in ASIAN_MODEL_ONLY_FALLBACK_LEAGUES
                and int(readiness.get("model_only_candidates") or 0) > 0
            ):
                waiting_state, waiting_message = _asian_odds_waiting_state(
                    league,
                    feed,
                )
                readiness["status"] = waiting_state
                readiness["message"] = waiting_message
        bundle["readiness"] = {league: readiness}


    bundle = calibrate_bundle(request, bundle)
    counts = (bundle.get("candidate_counts") or {}).get("by_league") or {}
    league_counts = counts.get(league) or {}
    formal_selections = [
        item
        for group in ("moneylines", "run_lines", "totals")
        for item in (bundle.get("candidates") or {}).get(group) or []
        if isinstance(item, dict) and _selection_matches_league(item, league)
    ]
    real_formal_count = sum(
        1 for item in formal_selections if is_real_odds_selection(item)
    )
    model_only_count = sum(
        1
        for item in formal_selections
        if is_model_only_asian_moneyline(item, league)
    )
    analysis_mode = (
        "mixed"
        if real_formal_count and model_only_count
        else "real_odds"
        if real_formal_count
        else "model_only"
        if model_only_count
        else "unavailable"
    )
    bundle["selected_league"] = league
    bundle["league_status"] = {
        league: {
            "enabled": True,
            "formal": int(league_counts.get("total") or 0),
            "markets": league_counts,
            "analysis_mode": analysis_mode,
            "real_odds": real_formal_count > 0,
            "real_odds_candidates": real_formal_count,
            "model_only": model_only_count > 0,
            "model_only_candidates": model_only_count,
            "odds_analysis_included": analysis_mode in {"real_odds", "mixed"},
        }
    }
    readiness = ((bundle.get("readiness") or {}).get(league) or {})
    readiness.update({
        "analysis_mode": analysis_mode,
        "odds_analysis_included": analysis_mode in {"real_odds", "mixed"},
        "model_only_fallback_included": analysis_mode in {"model_only", "mixed"},
        "formal_candidates": int(league_counts.get("total") or 0),
        "real_odds_candidates": real_formal_count,
        "model_only_candidates": model_only_count,
    })
    if analysis_mode == "mixed":
        readiness["status"] = "ready_mixed"
        readiness["message"] = (
            f"{league} 已建立 {real_formal_count} 個真實盤口候選與 "
            f"{model_only_count} 個純模型獨贏候選；缺盤場次不提供讓分、大小分或串關。"
        )
    elif analysis_mode == "model_only":
        readiness["status"] = "ready_model_only"
        readiness["message"] = (
            f"{league} 暫無有效真實盤口，已改用 {model_only_count} 個純模型獨贏候選；"
            "不顯示盤口、賠率、市場機率或優勢值，也不建立讓分、大小分與串關。"
        )
    elif analysis_mode == "real_odds":
        readiness["status"] = "ready"
        readiness["message"] = (
            readiness.get("message")
            or f"{league} 已驗證 {real_formal_count} 個真實盤口正式候選。"
        )
    bundle["message"] = readiness.get("message") or (
        f"{league} 候選已獨立載入；缺少先發或打線只會降低信心，不會阻擋免費推薦。"
    )
    bundle["available"] = True
    bundle["retryable"] = False
    bundle["failure_stage"] = None
    bundle["diagnostics"] = {
        "schedule": {"status": "ok", "count": int(readiness.get("schedule_games") or 0)},
        "odds": {
            "status": (
                "ok"
                if bundle["league_status"][league]["real_odds"]
                else "quota_exhausted"
                if readiness.get("status") == "odds_quota_exhausted"
                else "unavailable"
                if readiness.get("status") == "odds_providers_unavailable"
                else "waiting"
            ),
            "count": int(((bundle.get("odds_feeds") or {}).get(league) or {}).get("count") or 0),
        },
        "model": {"status": "ok", "count": int(readiness.get("analyzed_games") or readiness.get("full_model_ready_games") or 0)},
        "recommendations": {"status": "ok", "count": int(league_counts.get("total") or 0)},
    }
    return bundle


@app.get(f"{settings.api_prefix}/admin/markets/candidates")
async def founder_market_candidates(
    request: Request,
    prediction_date: date | None = Query(default=None, alias="date"),
    league: str = Query(default="MLB", pattern="^(MLB|NPB|KBO|CPBL)$"),
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    await admin_member(request, authorization)
    league = _prediction_league(league)
    target_date = requested_date(prediction_date)
    repository = records_repository(request)
    if not repository.enabled:
        raise HTTPException(status_code=503, detail="Recommendation database is not configured")
    try:
        existing = await repository.get_prediction_package_for_date(target_date.isoformat())
    except RecordsStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    if existing:
        existing_package = package_from_record(existing)
        locks = (existing_package.get("publication") or {}).get("league_locks") or {}
        if locks.get(league) or _package_has_league(existing_package, league):
            return {
                "date": target_date.isoformat(),
                "league": league,
                "locked": True,
                "package": _package_for_league(existing_package, league),
                "message": f"此賽事日的 {league} 會員玩法已鎖定；另一聯盟仍可稍後獨立發布。",
            }
    try:
        bundle = await asyncio.wait_for(
            founder_market_candidate_bundle(request, target_date, league),
            timeout=82.0,
        )
    except asyncio.TimeoutError:
        bundle = _candidate_waiting_bundle(
            target_date, league, stage="model",
            message=f"{league} 候選整理超過安全等待時間；背景服務仍可繼續運作，請稍後重新載入。",
        )
    except HTTPException as exc:
        if exc.status_code in {409, 429, 500, 502, 503, 504}:
            bundle = _candidate_waiting_bundle(
                target_date, league, stage="model",
                message=str(exc.detail or f"{league} 候選暫時無法建立。"),
                retryable=exc.status_code != 503,
            )
        else:
            raise
    except Exception:
        bundle = _candidate_waiting_bundle(
            target_date, league, stage="model",
            message=f"{league} 候選暫時無法建立；錯誤已被隔離，不影響發布紀錄與自動結算。",
        )
    return {
        **bundle,
        "league": league,
        "locked": False,
        "message": bundle.get("message") or f"{league} 候選已載入；只會發布此聯盟的獨贏、讓分、大小分與同聯盟串關。",
    }


@app.post(f"{settings.api_prefix}/admin/markets/publish")
async def founder_publish_markets(
    request: Request,
    command: FounderMarketPublish,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    await admin_member(request, authorization)
    league = _prediction_league(command.league)
    repository = records_repository(request)
    if not repository.enabled:
        raise HTTPException(status_code=503, detail="Recommendation database is not configured")
    try:
        existing_record = await repository.get_prediction_package_for_date(command.date.isoformat())
    except RecordsStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    existing_package = package_from_record(existing_record) if existing_record else None
    if existing_package:
        locks = (existing_package.get("publication") or {}).get("league_locks") or {}
        if locks.get(league) or _package_has_league(existing_package, league):
            raise HTTPException(status_code=409, detail=f"此賽事日的 {league} 會員玩法已鎖定，不能再更換。")

    bundle = await founder_market_candidate_bundle(request, command.date, league)
    if bundle.get("available") is False:
        raise HTTPException(status_code=409, detail=bundle.get("message") or f"{league} 候選資料尚未就緒，請稍後重新載入。")
    selected = {
        "moneylines": command.moneylines,
        "run_lines": command.run_lines,
        "totals": command.totals,
        "two_leg": command.two_leg,
        "three_leg": command.three_leg,
        "manual_two_leg": command.manual_two_leg,
        "manual_three_leg": command.manual_three_leg,
    }
    try:
        league_package = build_selected_market_package(bundle, selected, publication_mode="founder_selected")
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    if not league_package.get("published"):
        raise HTTPException(status_code=422, detail=f"至少選擇一個具備有效推薦方向的 {league} 會員玩法後才能發布。")
    if league in {"NPB", "KBO", "CPBL"}:
        invalid = _asian_pro_package_errors(league_package, league)
        if invalid:
            policy_message = (
                f"{league} Pro 有真實盤口時可發布獨贏、讓分、大小分與串關；"
                "沒有有效盤口時只允許純模型獨贏候選，且不得包含任何模擬盤口。"
                if league in ASIAN_MODEL_ONLY_FALLBACK_LEAGUES
                else f"{league} Pro 只允許發布具備有效推薦方向＋真實盤口的候選；資料完整度僅作提示。"
            )
            raise HTTPException(
                status_code=422,
                detail={
                    "message": policy_message,
                    "invalid_candidates": invalid,
                },
            )
    analysis_mode = _package_analysis_mode(league_package, league)
    published_at = iso_utc()
    league_package = _stamp_published_package(
        league_package,
        league=league,
        target_date=command.date,
        published_at=published_at,
    )
    publication = league_package.setdefault("publication", {})
    publication["league_locks"] = {league: True}
    publication["last_published_league"] = league
    publication.update(_analysis_mode_metadata(analysis_mode))

    try:
        async with request.app.state.external_publish_lock:
            # Candidate preparation may take time. Re-read inside the publish
            # lock so a manual click and an automatic fallback cannot replace
            # one another after either side has completed its analysis.
            current_record = await repository.get_prediction_package_for_date(
                command.date.isoformat()
            )
            current_package = (
                package_from_record(current_record) if current_record else None
            )
            if current_package and _package_has_league(current_package, league):
                raise HTTPException(
                    status_code=409,
                    detail=f"此賽事日的 {league} 會員玩法已由另一個發布動作鎖定。",
                )
            if current_record and current_package:
                package = _merge_league_package(
                    current_package,
                    league_package,
                    league,
                )
                stored = await repository.replace_prediction_package(
                    command.date.isoformat(),
                    package,
                    preserve_results=current_record.get("results") or {},
                )
            else:
                package = league_package
                stored, created = await repository.publish_prediction_package_once(
                    command.date.isoformat(),
                    package,
                )
                if not created:
                    raced = package_from_record(stored)
                    if _package_has_league(raced, league):
                        raise HTTPException(
                            status_code=409,
                            detail=f"另一筆 {league} 會員玩法已先完成鎖定。",
                        )
                    package = _merge_league_package(
                        raced,
                        league_package,
                        league,
                    )
                    stored = await repository.replace_prediction_package(
                        command.date.isoformat(),
                        package,
                        preserve_results=stored.get("results") or {},
                    )
    except RecordsStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    try:
        await performance_repository(request).capture_package(command.date.isoformat(), str(stored.get("id")), package)
    except PerformanceStorageError:
        pass
    try:
        social = await _publish_pro_social(request, stored, "teaser", league)
    except (RecordsStorageError, SocialPublishingError) as exc:
        social = {"status": "failed", "error": str(exc)}
    line = _queue_line_sync(request.app, "founder_pro_publish", force=True)
    locked = package_from_record(stored)
    return {
        "ok": True,
        "date": command.date.isoformat(),
        "target_date": command.date.isoformat(),
        "published_at": published_at,
        "status": "published",
        "league": league,
        "locked": True,
        "package": _package_for_league(locked, league),
        "social": social,
        "line": line,
        "analysis_mode": analysis_mode,
        "message": (
            f"{league} 付費會員推薦已正式發布；有盤口場次包含盤口分析，缺盤場次僅發布純模型獨贏。"
            if analysis_mode == "mixed"
            else f"{league} 付費會員推薦已正式發布；本次包含真實盤口分析。"
            if analysis_mode == "real_odds"
            else f"{league} 付費會員推薦已正式發布；本次僅有純模型獨贏，不含讓分、大小分、串關或模擬盤口。"
            if analysis_mode == "model_only"
            else f"{league} 付費會員推薦已正式發布，會員現在即可看見；另一聯盟可稍後獨立發布。"
        ),
    }


async def _run_external_settlement_job(app: FastAPI) -> None:
    """Run one bounded, deduplicated settlement pass in the background.

    The pass covers MLB, NPB, KBO and CPBL, shares official game lookups between
    free and Pro records, and queues social publishing separately. No member API
    request ever waits for this workflow.
    """

    async with app.state.external_settlement_lock:
        started_at = iso_utc()
        trigger_source = str((app.state.settlement_status or {}).get("source") or "settlement_job")
        previous_status = dict(app.state.settlement_status or {})
        app.state.settlement_status = {
            **previous_status,
            "state": "running",
            "running": True,
            "queued": False,
            "source": trigger_source,
            "started_at": started_at,
            "last_run": app.state.settlement_status.get("last_run"),
            "last_error": None,
            "free_settled_now": 0,
            "packages_settled_now": 0,
            "mode": "background_only",
            "scheduler": (app.state.settlement_status or {}).get("scheduler", "internal_fallback"),
            "scheduler_interval_seconds": settings.settlement_internal_interval_seconds,
        }
        try:
            async with app.state.background_work_lock:
                free_count, package_count, game_lookups, diagnostics = await asyncio.wait_for(
                    _run_settlement_pass(app),
                    timeout=settings.settlement_phase_timeout_seconds,
                )

            monitor: dict = {
                "ok": True,
                "status": "skipped",
                "checked_at": datetime.now(TAIPEI).isoformat(),
                "checks": [],
                "warnings": [],
                "critical_issues": [],
                "message": "Source probes are disabled on routine settlement to protect API responsiveness.",
            }
            if settings.settlement_source_probe_enabled:
                try:
                    source_probes = await asyncio.wait_for(
                        probe_league_sources(
                            app.state.mlb, app.state.npb, datetime.now(TAIPEI).date(),
                            app.state.kbo, app.state.cpbl,
                        ),
                        timeout=max(15.0, settings.request_timeout_seconds * 2.0),
                    )
                    monitor = await build_operations_report(
                        repository=app.state.records,
                        odds=app.state.odds,
                        source_probes=source_probes,
                        failure_counters=app.state.operations_monitor_failures,
                        settings=settings,
                        now=datetime.now(TAIPEI),
                    )
                except Exception as exc:
                    monitor = {
                        "ok": False,
                        "status": "warning",
                        "checked_at": datetime.now(TAIPEI).isoformat(),
                        "checks": [],
                        "warnings": [{"key": "source_probe", "detail": type(exc).__name__}],
                        "critical_issues": [],
                    }

            settled_total = free_count + package_count
            notification_key = "|".join(diagnostics.get("settled_ids") or [])
            is_new_notification = bool(
                settled_total > 0
                and notification_key
                and notification_key != getattr(app.state, "last_settlement_notification_key", None)
            )
            social_queue = (
                _queue_social_sync(app, "settlement_completed", force=True)
                if is_new_notification
                else {
                    "queued": False,
                    "reason": "no_new_settlements" if settled_total == 0 else "duplicate_settlement_notification_suppressed",
                }
            )
            line_queue = (
                _queue_line_sync(app, "settlement_completed", force=True)
                if is_new_notification
                else {
                    "queued": False,
                    "reason": "no_new_settlements" if settled_total == 0 else "duplicate_settlement_notification_suppressed",
                }
            )
            if is_new_notification:
                app.state.last_settlement_notification_key = notification_key
            result = {
                "ok": True,
                "state": "idle",
                "running": False,
                "queued": False,
                "settlement_ok": True,
                "monitor_ok": bool(monitor.get("ok")),
                "time_taiwan": datetime.now(TAIPEI).isoformat(),
                "started_at": started_at,
                "last_run": iso_utc(),
                "free_settled_now": free_count,
                "packages_settled_now": package_count,
                "settled_now": settled_total,
                "official_game_lookups": game_lookups,
                "settlement_diagnostics": diagnostics,
                "odds_refreshed": False,
                "recommendations_published": False,
                "instagram": social_queue,
                "line": line_queue,
                "monitor": monitor,
                "source": trigger_source,
                "mode": "background_only",
                "last_error": None,
            }
            preserved = dict(app.state.settlement_status or {})
            app.state.settlement_status = {
                **{key: preserved.get(key) for key in (
                    "scheduler", "scheduler_interval_seconds", "scheduler_last_check",
                    "scheduler_queue_result", "scheduler_error",
                ) if preserved.get(key) is not None},
                **result,
            }
            app.state.operations_monitor_status = monitor
            app.state.last_settlement_completed_monotonic = monotonic()
        except asyncio.CancelledError:
            app.state.settlement_status = {
                **dict(app.state.settlement_status or {}),
                "state": "error",
                "running": False,
                "queued": False,
                "last_run": iso_utc(),
                "last_error": "CancelledError",
            }
            raise
        except (TimeoutError, asyncio.TimeoutError):
            app.state.settlement_status = {
                **dict(app.state.settlement_status or {}),
                "state": "error",
                "running": False,
                "queued": False,
                "last_run": iso_utc(),
                "last_error": "SettlementTimeout",
                "error_detail": f"Settlement exceeded {settings.settlement_phase_timeout_seconds:.0f} seconds and was cancelled safely.",
            }
            app.state.last_settlement_completed_monotonic = monotonic()
            await _enqueue_retry_job_safely(
                app,
                job_type="settlement",
                worker_role="settlement",
                payload={"reason": trigger_source},
                error="SettlementTimeout",
            )
        except Exception as exc:
            app.state.settlement_status = {
                **dict(app.state.settlement_status or {}),
                "state": "error",
                "running": False,
                "queued": False,
                "last_run": iso_utc(),
                "last_error": type(exc).__name__,
                "error_detail": str(exc)[:500],
            }
            app.state.last_settlement_completed_monotonic = monotonic()
            await _enqueue_retry_job_safely(
                app,
                job_type="settlement",
                worker_role="settlement",
                payload={"reason": trigger_source},
                error=f"{type(exc).__name__}: {str(exc)[:500]}",
            )


def _queue_settlement_background(app: FastAPI, reason: str, *, respect_cooldown: bool = True) -> dict:
    current = getattr(app.state, "external_settlement_task", None)
    if current is not None and not current.done():
        return {
            "accepted": True,
            "already_running": True,
            "cooldown": False,
            "reason": reason,
            "status": dict(getattr(app.state, "settlement_status", {}) or {}),
        }
    elapsed = monotonic() - float(getattr(app.state, "last_settlement_completed_monotonic", 0.0) or 0.0)
    if respect_cooldown and elapsed < settings.settlement_min_interval_seconds:
        return {
            "accepted": True,
            "already_running": False,
            "cooldown": True,
            "retry_after_seconds": max(1, int(settings.settlement_min_interval_seconds - elapsed)),
            "reason": reason,
            "status": dict(getattr(app.state, "settlement_status", {}) or {}),
        }
    queued_at = iso_utc()
    app.state.settlement_status = {
        **dict(getattr(app.state, "settlement_status", {}) or {}),
        "state": "queued",
        "running": True,
        "queued": True,
        "queued_at": queued_at,
        "source": reason,
        "mode": "background_only",
        "last_error": None,
    }
    task = asyncio.create_task(_run_external_settlement_job(app), name="diamondmind-external-settlement")
    app.state.external_settlement_task = task
    return {
        "accepted": True,
        "already_running": False,
        "cooldown": False,
        "queued_at": queued_at,
        "reason": reason,
    }


@app.post(f"{settings.api_prefix}/jobs/settlement")
async def settlement_job(
    request: Request,
    cron_secret: str | None = Header(default=None, alias="X-DiamondMind-Cron"),
) -> Response:
    """Acknowledge immediately and queue one cooldown-protected settlement."""
    if not settings.scheduler_enabled:
        raise HTTPException(status_code=503, detail="Settlement scheduler secret is not configured")
    if not cron_secret_matches(cron_secret, settings.cron_secret):
        raise HTTPException(status_code=401, detail="Invalid scheduler credentials")
    if not settings.records_enabled:
        raise HTTPException(status_code=503, detail="Recommendation records database is not configured")

    queued = _queue_settlement_background(request.app, "external_settlement_job")
    message = (
        "Settlement is already running; duplicate execution was skipped."
        if queued.get("already_running")
        else "A recent settlement pass already completed; duplicate scanning was skipped."
        if queued.get("cooldown")
        else "Settlement was queued and will continue in the backend."
    )
    return JSONResponse(status_code=202, content={"ok": True, **queued, "message": message})


async def _run_asian_auto_publish_background(
    app: FastAPI,
    target_date: date,
    source: str,
) -> None:
    """Run the heavy Asian publication pass after the cron request returns."""

    async with app.state.external_publish_lock:
        started_at = iso_utc()
        app.state.publishing_status = {
            **dict(getattr(app.state, "publishing_status", {}) or {}),
            "enabled": True,
            "state": "running",
            "running": True,
            "queued": False,
            "source": source,
            "target_date": target_date.isoformat(),
            "started_at": started_at,
            "last_error": None,
            "mode": "background_only",
        }
        background_request = type("BackgroundRequest", (), {"app": app})()
        results: dict[str, dict] = {}
        retry_errors: list[str] = []
        try:
            # Publishing and settlement mutate the same immutable recommendation
            # rows. Sharing this lock keeps a delayed cron, the internal
            # pregame worker and manual settlement from racing in one process.
            async with app.state.background_work_lock:
                for code in ("NPB", "KBO", "CPBL"):
                    channel_results: dict[str, dict] = {}
                    try:
                        channel_results["odds_refresh"] = await asyncio.wait_for(
                            refresh_asian_odds_snapshot(
                                background_request,
                                target_date,
                                code,
                            ),
                            timeout=45.0,
                        )
                    except asyncio.CancelledError:
                        raise
                    except Exception as exc:
                        error = f"{code}:odds_refresh:{type(exc).__name__}"
                        retry_errors.append(error)
                        channel_results["odds_refresh"] = {
                            "refreshed": False,
                            "state": "error",
                            "league": code,
                            "error": type(exc).__name__,
                            "message": str(exc)[:300],
                        }
                    for channel, publisher, timeout_seconds in (
                        ("free", auto_publish_asian_free_pick, 70.0),
                        ("pro", auto_publish_asian_pro_package, 100.0),
                    ):
                        try:
                            channel_results[channel] = await asyncio.wait_for(
                                publisher(
                                    background_request,
                                    target_date,
                                    code,
                                ),
                                timeout=timeout_seconds,
                            )
                        except asyncio.CancelledError:
                            raise
                        except Exception as exc:
                            error = f"{code}:{channel}:{type(exc).__name__}"
                            retry_errors.append(error)
                            channel_results[channel] = {
                                "published": False,
                                "state": "error",
                                "league": code,
                                "channel": channel,
                                "error": type(exc).__name__,
                                "message": str(exc)[:300],
                            }
                    channel_results["lead_minutes"] = _asian_auto_settings(code)["lead"]
                    channel_results["odds_refresh_lead_minutes"] = (
                        _asian_auto_settings(code)["odds_refresh_lead"]
                    )
                    results[code] = channel_results
                    await asyncio.sleep(0)

            social = (
                _queue_social_sync(app, "asian_auto_publish")
                if _auto_publish_created(results)
                else {"queued": False, "reason": "nothing_published"}
            )
            line = (
                _queue_line_sync(app, "asian_auto_publish", force=True)
                if _auto_publish_created(results)
                else {"queued": False, "reason": "nothing_published"}
            )
            for error in retry_errors:
                await _enqueue_retry_job_safely(
                    app,
                    job_type="publish_refresh",
                    worker_role="publish",
                    payload={"reason": f"asian_auto_publish:{error}"},
                    error=error,
                )
            settlement = _queue_settlement_background(
                app,
                "asian_auto_publish_job",
                respect_cooldown=True,
            )
            app.state.publishing_status = {
                "enabled": True,
                "state": "warning" if retry_errors else "idle",
                "running": False,
                "queued": False,
                "source": source,
                "target_date": target_date.isoformat(),
                "started_at": started_at,
                "last_run": iso_utc(),
                "last_error": ", ".join(retry_errors) if retry_errors else None,
                "mode": "background_only",
                "results": results,
                "instagram": social,
                "line": line,
                "settlement": {
                    key: settlement.get(key)
                    for key in (
                        "accepted",
                        "already_running",
                        "cooldown",
                        "retry_after_seconds",
                    )
                    if key in settlement
                },
            }
            app.state.last_publish_completed_monotonic = monotonic()
        except asyncio.CancelledError:
            app.state.publishing_status = {
                **dict(getattr(app.state, "publishing_status", {}) or {}),
                "state": "error",
                "running": False,
                "queued": False,
                "last_run": iso_utc(),
                "last_error": "CancelledError",
            }
            raise
        except Exception as exc:
            error = f"{type(exc).__name__}: {str(exc)[:400]}"
            app.state.publishing_status = {
                **dict(getattr(app.state, "publishing_status", {}) or {}),
                "state": "error",
                "running": False,
                "queued": False,
                "last_run": iso_utc(),
                "last_error": error,
                "results": results,
            }
            app.state.last_publish_completed_monotonic = monotonic()
            await _enqueue_retry_job_safely(
                app,
                job_type="publish_refresh",
                worker_role="publish",
                payload={"reason": "asian_auto_publish_background_failure"},
                error=error,
            )


def _queue_asian_auto_publish_background(
    app: FastAPI,
    target_date: date,
    source: str,
) -> dict:
    current = getattr(app.state, "external_publish_task", None)
    if current is not None and not current.done():
        return {
            "accepted": True,
            "already_running": True,
            "cooldown": False,
            "target_date": target_date.isoformat(),
            "source": source,
        }
    elapsed = monotonic() - float(
        getattr(app.state, "last_publish_completed_monotonic", 0.0) or 0.0
    )
    if elapsed < 60:
        return {
            "accepted": True,
            "already_running": False,
            "cooldown": True,
            "retry_after_seconds": max(1, int(60 - elapsed)),
            "target_date": target_date.isoformat(),
            "source": source,
        }
    queued_at = iso_utc()
    app.state.publishing_status = {
        **dict(getattr(app.state, "publishing_status", {}) or {}),
        "enabled": True,
        "state": "queued",
        "running": True,
        "queued": True,
        "queued_at": queued_at,
        "source": source,
        "target_date": target_date.isoformat(),
        "last_error": None,
        "mode": "background_only",
    }
    task = asyncio.create_task(
        _run_asian_auto_publish_background(app, target_date, source),
        name="diamondmind-asian-auto-publish",
    )
    app.state.external_publish_task = task
    return {
        "accepted": True,
        "already_running": False,
        "cooldown": False,
        "queued_at": queued_at,
        "target_date": target_date.isoformat(),
        "source": source,
    }


@app.post(f"{settings.api_prefix}/jobs/asian-auto-publish")
async def asian_auto_publish_job(
    request: Request,
    job_date: date | None = Query(default=None, alias="date", description="Taiwan date, YYYY-MM-DD"),
    cron_secret: str | None = Header(default=None, alias="X-DiamondMind-Cron"),
) -> Response:
    if not settings.scheduler_enabled:
        raise HTTPException(status_code=503, detail="Asian baseball auto-publish scheduler secret is not configured")
    if not cron_secret_matches(cron_secret, settings.cron_secret):
        raise HTTPException(status_code=401, detail="Invalid scheduler credentials")
    if not settings.records_enabled:
        raise HTTPException(status_code=503, detail="Recommendation records database is not configured")

    target_date = requested_date(job_date)
    queued = _queue_asian_auto_publish_background(
        request.app,
        target_date,
        "external_asian_auto_publish",
    )
    message = (
        "Asian auto-publishing is already running; the duplicate request was skipped."
        if queued.get("already_running")
        else "A recent Asian auto-publish pass completed; the duplicate request was skipped."
        if queued.get("cooldown")
        else "Asian Free and Pro checks were queued and will continue in the backend."
    )
    return JSONResponse(status_code=202, content={
        "ok": True,
        **queued,
        "date": target_date.isoformat(),
        "time_taiwan": datetime.now(TAIPEI).isoformat(),
        "mode": "background_only",
        "mlb_auto_publish": {
            "free": False,
            "pro": False,
            "message": "MLB 免費與 Pro 都維持創辦人手動發布。",
        },
        "message": message,
    })


@app.post(f"{settings.api_prefix}/jobs/npb-auto-publish")
async def npb_auto_publish_job(
    request: Request,
    job_date: date | None = Query(default=None, alias="date", description="Taiwan date, YYYY-MM-DD"),
    cron_secret: str | None = Header(default=None, alias="X-DiamondMind-Cron"),
) -> Response:
    """Backward-compatible cron route that now covers NPB, KBO and CPBL.

    Existing cron-job.org configurations do not need their URL changed.
    """
    if not settings.scheduler_enabled:
        raise HTTPException(
            status_code=503,
            detail="Asian baseball auto-publish scheduler secret is not configured",
        )
    if not cron_secret_matches(cron_secret, settings.cron_secret):
        raise HTTPException(status_code=401, detail="Invalid scheduler credentials")
    if not settings.records_enabled:
        raise HTTPException(
            status_code=503,
            detail="Recommendation records database is not configured",
        )
    target_date = requested_date(job_date)
    queued = _queue_asian_auto_publish_background(
        request.app,
        target_date,
        "legacy_npb_auto_publish",
    )
    return JSONResponse(status_code=202, content={
        "ok": True,
        **queued,
        "date": target_date.isoformat(),
        "legacy_route": True,
        "mode": "background_only",
        "message": (
            "既有 NPB 排程網址已接收；NPB、KBO、CPBL 的 Free 與 Pro"
            "會在背景分開檢查，重複執行不會覆蓋正式資料。"
        ),
    })


@app.post(f"{settings.api_prefix}/jobs/daily")
async def daily_job(
    request: Request,
    job_date: date | None = Query(default=None, alias="date", description="Taiwan date, YYYY-MM-DD"),
    cron_secret: str | None = Header(default=None, alias="X-DiamondMind-Cron"),
) -> dict:
    if not settings.scheduler_enabled:
        raise HTTPException(status_code=503, detail="Daily scheduler secret is not configured")
    if not cron_secret_matches(cron_secret, settings.cron_secret):
        raise HTTPException(status_code=401, detail="Invalid scheduler credentials")

    target_date = requested_date(job_date)
    try:
        prediction = await prediction_with_persistence(request, target_date, publish_if_eligible=False)
    except MLBUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc

    settlement = {
        "enabled": settings.records_enabled,
        "mode": "background_only",
        "settled_now": 0,
        "packages_settled_now": 0,
    }
    social = {"status": "background_only", "published_now": 0}
    line = {"status": "background_only", "sent_now": 0}
    if settings.records_enabled:
        settlement.update(_queue_settlement_background(request.app, "daily_job"))

    odds = odds_service(request).status()
    market_package = {
        "date": target_date.isoformat(),
        "published": False,
        "message": "真實盤口尚未提供，會員玩法不會使用猜測資料。",
    }
    if odds_service(request).enabled or odds_api_io_service(request).enabled:
        try:
            feed = await mlb_odds_feed_for_date(
                request,
                target_date,
                priority=True,
            )
            odds.update(
                {
                    "available": True,
                    "count": feed["count"],
                    "cache": feed["meta"]["cache"],
                    "fresh_for_model": feed["meta"]["fresh_for_model"],
                    "quota": feed["meta"]["quota"],
                    "provider": feed["meta"].get("provider"),
                    "provider_chain": feed["meta"].get("provider_chain") or [],
                    "fallback_activated": bool(feed["meta"].get("fallback_activated")),
                }
            )
            if feed["meta"]["fresh_for_model"]:
                market_package = await locked_or_generated_market_package(
                    request, target_date, prediction, feed, persist=False
                )
            else:
                market_package["message"] = "目前只有過期備援盤口，不發布新的正式玩法。"
        except OddsUpstreamError:
            # A temporary odds incident must not prevent the independent
            # moneyline model or record settlement from completing.
            odds.update({"available": False, "message": "真實盤口來源暫時無法使用。"})
    else:
        odds["available"] = False

    return {
        "ok": True,
        "date": target_date.isoformat(),
        "time_taiwan": datetime.now(TAIPEI).isoformat(),
        "prediction": prediction,
        "market_package": market_package,
        "settlement": settlement,
        "instagram": social,
        "line": line,
        "odds": odds,
    }


@app.get(f"{settings.api_prefix}/records")
async def recommendation_records(
    request: Request,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    member = await optional_member(request, authorization)
    repository = records_repository(request)
    if not repository.enabled:
        return {
            "items": [],
            "market_packages": [],
            "count": 0,
            "stats": summarize_records([]),
            "message": "推薦紀錄資料庫尚未設定。",
            "is_demo": False,
            "database": "not_configured",
            "member": {"role": member["role"], "has_pro_access": member["has_pro_access"]},
            "pro_history_locked": not member["has_pro_access"],
            "performance_access": member.get("role") == "admin",
        }

    try:
        items = await repository.list_records()
        prediction_packages = await repository.list_prediction_packages()
        settlement_snapshot = dict(getattr(request.app.state, "settlement_status", {}) or {})
        settled_now = int(settlement_snapshot.get("free_settled_now") or 0)
        packages_settled_now = int(settlement_snapshot.get("packages_settled_now") or 0)
    except RecordsStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc

    # Pro history is membership content. Free visitors receive only the
    # public daily free-pick record. Paid members receive every locked formal
    # package immediately, with each completed selection settling independently.
    today_taiwan = datetime.now(TAIPEI).date().isoformat()
    visible_prediction_packages: list[dict] = []
    for item in prediction_packages:
        recommendation_date = str(item.get("recommendation_date") or "")
        if recommendation_date and recommendation_date > today_taiwan:
            # The records page is history, never a preview of a future slate.
            continue
        package = package_from_record(item)
        visible_prediction_packages.append(package)

    market_packages = visible_prediction_packages if member.get("has_pro_access") else []
    if member.get("role") != "admin":
        # Public free-pick history never exposes the five-engine snapshot.
        items = [
            _strip_member_financials(deepcopy(item))
            for item in items
        ]
        for item in items:
            if isinstance(item.get("prediction_snapshot"), dict):
                item["prediction_snapshot"] = _free_pick_for_member(item["prediction_snapshot"])

        market_packages = [
            _strip_member_financials(package)
            for package in market_packages
        ]

        # Historical Pro packages may persist founder watchlist snapshots in
        # the database. Strip them at the API boundary so paid members cannot
        # recover internal candidates or internal publication notes through
        # browser developer tools.
        for package in market_packages:
            package.pop("watchlist", None)
            for group in ("moneylines", "run_lines", "totals"):
                package[group] = [
                    _selection_for_member(selection, founder=False)
                    for selection in (package.get(group) or [])
                    if isinstance(selection, dict)
                ]
            parlays = package.get("parlays") or {}
            package["parlays"] = {
                "two_leg": [
                    _selection_for_member(selection, founder=False)
                    for selection in (parlays.get("two_leg") or [])
                    if isinstance(selection, dict)
                ],
                "three_leg": [
                    _selection_for_member(selection, founder=False)
                    for selection in (parlays.get("three_leg") or [])
                    if isinstance(selection, dict)
                ],
            }
            if isinstance(package.get("moneyline"), dict):
                package["moneyline"] = _free_pick_for_member(package["moneyline"])
            counts = package.get("candidate_counts")
            if isinstance(counts, dict):
                package["candidate_counts"] = {
                    key: value
                    for key, value in counts.items()
                    if not str(key).startswith("watch_")
                }
            if package.get("recommendation_status") in {
                "watchlist_only", "founder_watchlist_only"
            }:
                package["recommendation_status"] = "no_recommendation"
            formal_total = sum(
                len(items or [])
                for items in (
                    package.get("moneylines"),
                    package.get("run_lines"),
                    package.get("totals"),
                    (package.get("parlays") or {}).get("two_leg"),
                    (package.get("parlays") or {}).get("three_leg"),
                )
            )
            package["message"] = (
                "正式玩法已鎖定。"
                if formal_total
                else "此日期沒有正式 Pro 推薦。"
            )

    pro_performance = None
    if member.get("role") == "admin":
        try:
            pro_performance = await performance_repository(request).records_performance(days=None)
        except PerformanceStorageError:
            # Recommendation history remains available even when the auxiliary
            # performance snapshot store is temporarily unavailable.
            pro_performance = None

    return {
        "items": items,
        "market_packages": market_packages,
        "pro_performance": pro_performance,
        "count": len(items),
        "stats": summarize_records(items),
        "message": "尚無正式推薦紀錄。" if not items else "正式推薦紀錄已載入。",
        "is_demo": False,
        "database": "connected",
        "settled_now": settled_now,
        "packages_settled_now": packages_settled_now,
        "member": {"role": member["role"], "has_pro_access": member["has_pro_access"]},
        "pro_history_locked": not member["has_pro_access"],
        "performance_access": member.get("role") == "admin",
    }
