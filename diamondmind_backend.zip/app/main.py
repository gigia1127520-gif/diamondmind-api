from __future__ import annotations

import asyncio
import csv
from copy import deepcopy
import io
import re
from contextlib import asynccontextmanager, suppress
from datetime import date, datetime, timedelta
from secrets import compare_digest
from zoneinfo import ZoneInfo

from fastapi import FastAPI, Header, HTTPException, Query, Request
from fastapi.responses import HTMLResponse, JSONResponse, PlainTextResponse, Response
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from .config import settings
from .billing import BillingError, BillingRepository, ECPayBillingService, parse_form_body
from .admin import AdminMemberCommand, AdminMembershipError, AdminMembershipService
from .announcements import AnnouncementError, AnnouncementRepository, AnnouncementService
from .auth import MemberAccessError, SupabaseMemberAuth
from .trials import NewMemberTrialError, NewMemberTrialService
from .markets import (
    build_daily_market_candidates,
    build_daily_market_package,
    build_selected_market_package,
    match_odds_event,
    merge_market_candidates,
    model_only_moneyline_candidate,
    moneyline_candidate,
    run_line_candidate,
    totals_candidate,
)
from .mlb import MLBService, MLBUpstreamError
from .npb import NPBService, NPBUpstreamError
from .odds import OddsService, OddsUpstreamError
from .operations import build_operations_report, probe_league_sources
from .validation import game_timing, iso_utc
from .records import (
    RecordsStorageError,
    SupabaseRecordsRepository,
    package_from_record,
    preview_prediction_package,
    preview_public_record,
    settlement_for,
    settle_market_selection,
    settle_prediction_package,
    summarize_records,
)
from .performance import (
    DEFAULT_MODEL_WEIGHTS,
    PerformanceRepository,
    PerformanceStorageError,
    calibration_suggestions,
    normalize_weights,
)


TAIPEI = ZoneInfo("Asia/Taipei")


@asynccontextmanager
async def lifespan(app: FastAPI):
    service = MLBService(settings)
    npb = NPBService(settings)
    odds = OddsService(settings)
    records = SupabaseRecordsRepository(settings)
    member_auth = SupabaseMemberAuth(settings)
    billing_repository = BillingRepository(settings)
    billing = ECPayBillingService(settings, billing_repository)
    membership_admin = AdminMembershipService(billing_repository)
    member_trial = NewMemberTrialService(settings, billing_repository)
    announcement_repository = AnnouncementRepository(settings)
    announcements = AnnouncementService(announcement_repository)
    performance = PerformanceRepository(settings)
    try:
        service.model_weights = await performance.active_weights() if performance.enabled else dict(DEFAULT_MODEL_WEIGHTS)
    except PerformanceStorageError:
        service.model_weights = dict(DEFAULT_MODEL_WEIGHTS)
    app.state.mlb = service
    app.state.npb = npb
    app.state.odds = odds
    app.state.records = records
    app.state.member_auth = member_auth
    app.state.billing_repository = billing_repository
    app.state.billing = billing
    app.state.membership_admin = membership_admin
    app.state.member_trial = member_trial
    app.state.announcements = announcements
    app.state.performance = performance
    app.state.started_at = datetime.now(TAIPEI).isoformat()
    app.state.pregame_status = {"running": True, "last_run": None, "last_error": None}
    app.state.settlement_status = {
        "running": True,
        "last_run": None,
        "last_error": None,
        "free_settled_now": 0,
        "packages_settled_now": 0,
    }
    app.state.operations_monitor_status = {
        "ok": True,
        "status": "starting",
        "checked_at": None,
        "checks": [],
        "critical_issues": [],
        "warnings": [],
    }
    app.state.operations_monitor_failures = {}
    monitor_task = asyncio.create_task(_pregame_refresh_loop(app), name="diamondmind-pregame-refresh")
    app.state.pregame_task = monitor_task
    yield
    monitor_task.cancel()
    with suppress(asyncio.CancelledError):
        await monitor_task
    await service.aclose()
    await npb.aclose()
    await odds.aclose()
    await records.aclose()
    await member_auth.aclose()
    await billing.aclose()
    await billing_repository.aclose()
    await announcement_repository.aclose()
    await performance.aclose()


app = FastAPI(
    title="DiamondMind API",
    version="18.9.5",
    description="Multi-league baseball platform with MLB and NPB schedules, analysis, real sportsbook markets and a unified formal recommendation pool; KBO and CPBL homepage coverage are staged for the next adapters. Includes protected Pro access, trials, publishing, automatic multi-league settlement, payments, announcements and performance monitoring.",
    lifespan=lifespan,
)

allow_all = "*" in settings.cors_origins
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"] if allow_all else settings.cors_origins,
    allow_credentials=not allow_all,
    allow_methods=["GET", "POST", "PATCH", "DELETE", "OPTIONS"],
    allow_headers=["*"],
)


def service(request: Request) -> MLBService:
    return request.app.state.mlb


def npb_service(request: Request) -> NPBService:
    return request.app.state.npb


def records_repository(request: Request) -> SupabaseRecordsRepository:
    return request.app.state.records


def membership_admin_service(request: Request) -> AdminMembershipService:
    return request.app.state.membership_admin


def member_trial_service(request: Request) -> NewMemberTrialService:
    return request.app.state.member_trial


def announcement_service(request: Request) -> AnnouncementService:
    return request.app.state.announcements


def performance_repository(request: Request) -> PerformanceRepository:
    return request.app.state.performance


def odds_service(request: Request) -> OddsService:
    return request.app.state.odds


def member_auth_service(request: Request) -> SupabaseMemberAuth:
    return request.app.state.member_auth


def billing_service(request: Request) -> ECPayBillingService:
    return request.app.state.billing


def _csv_safe(value: object) -> str:
    if value is None:
        return ""
    text = str(value)
    if text.startswith(("=", "+", "-", "@")):
        return "'" + text
    return text


def _csv_response(filename: str, fieldnames: list[str], rows: list[dict[str, object]]) -> Response:
    buffer = io.StringIO(newline="")
    writer = csv.DictWriter(buffer, fieldnames=fieldnames, extrasaction="ignore")
    writer.writeheader()
    for row in rows:
        writer.writerow({key: _csv_safe(row.get(key)) for key in fieldnames})
    content = ("\ufeff" + buffer.getvalue()).encode("utf-8")
    return Response(
        content=content,
        media_type="text/csv; charset=utf-8",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


def bearer_token(authorization: str | None) -> str | None:
    if authorization and authorization.lower().startswith("bearer "):
        return authorization[7:].strip()
    return None


async def authenticated_member(request: Request, authorization: str | None) -> dict:
    try:
        return await member_auth_service(request).member(bearer_token(authorization))
    except MemberAccessError as exc:
        raise HTTPException(status_code=401, detail=str(exc)) from exc


async def optional_member(request: Request, authorization: str | None) -> dict:
    """Return guest access when no bearer token is supplied.

    An invalid or expired token is still rejected so the browser can clear the
    stale session instead of silently treating it as a valid free account.
    """

    token = bearer_token(authorization)
    if not token:
        return {"id": None, "email": None, "role": "guest", "has_pro_access": False}
    try:
        return await member_auth_service(request).member(token)
    except MemberAccessError as exc:
        raise HTTPException(status_code=401, detail=str(exc)) from exc


def _public_team_snapshot(team: dict | None) -> dict:
    team = team or {}
    pitcher = team.get("probable_pitcher") or {}
    return {
        "id": team.get("id"),
        "name": team.get("name"),
        "abbr": team.get("abbr"),
        "score": team.get("score"),
        "probable_pitcher": {
            "id": pitcher.get("id"),
            "name": pitcher.get("name") or "尚未公布",
        },
    }


def locked_game_detail(detail: dict, member: dict) -> dict:
    """Whitelist the only matchup fields available without Pro access.

    Never return the analysis object and then rely on CSS to hide it. This
    response deliberately omits lineups, bullpen, weather, Statcast, model pick,
    confidence, completeness, sources and every five-engine metric.
    """

    game = detail.get("game") or {}
    public_game = {
        key: game.get(key)
        for key in (
            "game_pk", "game_date", "date_taiwan", "time_taiwan", "status",
            "detailed_status", "inning", "inning_state", "venue_id", "venue",
            "game_type", "season_context", "event_label", "is_special_event",
        )
        if key in game
    }
    public_game["away"] = _public_team_snapshot(game.get("away"))
    public_game["home"] = _public_team_snapshot(game.get("home"))
    return {
        "game": public_game,
        "analysis_locked": True,
        "access": {
            "role": member.get("role") or "guest",
            "has_pro_access": False,
            "required_plan": "pro",
        },
        "locked_modules": [
            "starter", "lineup", "bullpen", "environment", "advanced",
        ],
        "message": "升級 Pro 解鎖完整賽事情報。",
        "meta": {
            "source": "MLB Stats API",
            "updated_at": (detail.get("meta") or {}).get("updated_at"),
            "analysis_payload_returned": False,
        },
    }


async def admin_member(request: Request, authorization: str | None) -> dict:
    member = await authenticated_member(request, authorization)
    if member.get("role") != "admin":
        raise HTTPException(status_code=403, detail="Founder access is required")
    return member


def requested_date(value: date | None) -> date:
    return value or datetime.now(TAIPEI).date()


def cron_secret_matches(provided: str | None, configured: str) -> bool:
    """Constant-time comparison for the server-to-server scheduler secret."""

    if not provided or not configured:
        return False
    return compare_digest(provided.encode("utf-8"), configured.encode("utf-8"))



def publication_policy(analysis: dict, *, automatic: bool = False, now: datetime | None = None) -> dict:
    game = analysis.get("game") or {}
    context = str(game.get("season_context") or "unsupported")
    confidence = float(analysis.get("confidence") or 0)
    data_quality = float(analysis.get("data_quality") or 0)
    timing = analysis.get("timing") or game_timing(
        game,
        now=now,
        lineup_watch_minutes=settings.pregame_lineup_watch_minutes,
        final_lock_minutes=settings.pregame_final_lock_minutes,
    )
    validation = analysis.get("roster_validation") or {}
    validation_overall = validation.get("overall") or {}
    lineups = validation.get("lineups") or {}
    lineup_rates = [
        float((lineups.get(side) or {}).get("validation_rate") or 0)
        for side in ("away", "home")
    ]
    lineup_rate = min(lineup_rates) if lineup_rates else 0.0
    starter_group = ((analysis.get("analysis_groups") or {}).get("starter") or {})
    blockers: list[str] = []
    warnings: list[str] = []

    if str(game.get("status") or "upcoming") != "upcoming" or timing.get("stage") == "started":
        blockers.append("比賽已開始或不再接受賽前發布。")
    if context not in {"regular_season", "postseason"}:
        blockers.append(f"{game.get('event_label') or '特殊賽事'}專用模型尚未啟用，不能套用一般模型正式發布。")
    if data_quality < settings.minimum_publish_data_quality:
        blockers.append(f"整體資料完整度不足 {settings.minimum_publish_data_quality * 100:.0f}%。")
    if starter_group.get("both_starters_ready") is not True:
        blockers.append("兩隊先發投手、投手數據或名單驗證尚未達正式發布標準。")
    if validation_overall.get("status") == "mismatch":
        blockers.append("球員與球隊身分驗證發現不一致，需重新整理後再確認。")
    if lineup_rate < settings.minimum_lineup_validation_rate:
        blockers.append(f"打線名單驗證率不足 {settings.minimum_lineup_validation_rate * 100:.0f}%。")
    if confidence < settings.min_confidence:
        message = f"模型信心 {confidence:.1f}% 低於門檻 {settings.min_confidence:.1f}%。"
        if automatic:
            blockers.append(message)
        else:
            warnings.append(message)
    if timing.get("stage") == "preview":
        warnings.append("目前仍是賽前預覽階段；先發、打線或盤口後續可能變動。")
    elif timing.get("stage") == "lineup_watch":
        warnings.append("已進入開賽前 90 分鐘監控階段；系統會持續重新分析正式打線。")
    if context == "postseason":
        warnings.append("季後賽請再確認輪值、休息天數與系列賽狀況。")

    can_publish = not blockers
    auto_ready = can_publish and timing.get("stage") == "final_lock" and confidence >= settings.min_confidence
    return {
        "can_publish": can_publish,
        "auto_publish_ready": auto_ready,
        "requires_confirmation": bool(warnings),
        "blockers": blockers,
        "warnings": warnings,
        "timing": timing,
        "lineup_validation_rate": round(lineup_rate, 3),
        "roster_validation": validation_overall,
        "checklist": {
            "game_not_started": timing.get("stage") != "started",
            "supported_event": context in {"regular_season", "postseason"},
            "both_starters_confirmed": starter_group.get("both_starters_ready") is True,
            "data_quality_passed": data_quality >= settings.minimum_publish_data_quality,
            "lineup_validation_passed": lineup_rate >= settings.minimum_lineup_validation_rate,
            "roster_validation_passed": validation_overall.get("status") != "mismatch",
            "confidence_passed": confidence >= settings.min_confidence,
            "final_lock_window": timing.get("stage") == "final_lock",
        },
    }


async def _pregame_refresh_loop(app: FastAPI) -> None:
    """Refresh analyses throughout the day and auto-lock only the daily top pick.

    It uses no additional API key or environment variable. On platforms that
    suspend idle services, the normal page/API request still performs the same
    live analysis; this loop is an in-process acceleration and safety fallback.
    """

    await asyncio.sleep(20)
    while True:
        try:
            now = datetime.now(TAIPEI)
            summaries = []
            for target_date in (now.date(), (now + timedelta(days=1)).date()):
                analyses = await app.state.mlb.matchup_analyses(target_date, pitcher_limit=None)
                items = analyses.get("items") or []
                summaries.append({"date": target_date.isoformat(), "games": len(items)})
                if app.state.records.enabled:
                    existing = await app.state.records.get_record_for_date(target_date.isoformat())
                    if not existing:
                        eligible = []
                        for item in items:
                            policy = publication_policy(item, automatic=True, now=now)
                            if policy["can_publish"] and float(item.get("confidence") or 0) >= settings.min_confidence:
                                eligible.append((item, policy))
                        if eligible:
                            top_item, top_policy = max(eligible, key=lambda row: float(row[0].get("confidence") or 0))
                            if top_policy["auto_publish_ready"]:
                                selection = {
                                    **top_item,
                                    "publication": {
                                        "mode": "pregame_auto_final",
                                        "locked_at": iso_utc(),
                                        "timing": top_policy["timing"],
                                        "checklist": top_policy["checklist"],
                                    },
                                }
                                stored, _created = await app.state.records.publish_prediction_once(target_date.isoformat(), selection)
                                try:
                                    await app.state.performance.capture_public(target_date.isoformat(), str(stored.get("id")), selection)
                                except PerformanceStorageError:
                                    pass
            settlement_run = {"free_settled_now": 0, "packages_settled_now": 0}
            if app.state.records.enabled:
                settlement_run["free_settled_now"] = await _settle_pending_records_with(app.state.records, app.state.mlb, app.state.performance)
                settlement_run["packages_settled_now"] = await _settle_pending_prediction_packages_with(app.state.records, app.state.mlb, app.state.npb, app.state.performance)
            app.state.settlement_status = {
                "running": True,
                "last_run": iso_utc(),
                "last_error": None,
                **settlement_run,
            }
            app.state.pregame_status = {
                "running": True,
                "last_run": iso_utc(),
                "last_error": None,
                "interval_seconds": settings.pregame_refresh_interval_seconds,
                "dates": summaries,
                "settlement": settlement_run,
            }
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # background loop must never stop the API
            app.state.pregame_status = {
                "running": True,
                "last_run": iso_utc(),
                "last_error": type(exc).__name__,
                "interval_seconds": settings.pregame_refresh_interval_seconds,
            }
            app.state.settlement_status = {
                "running": True,
                "last_run": iso_utc(),
                "last_error": type(exc).__name__,
                "free_settled_now": 0,
                "packages_settled_now": 0,
            }
        await asyncio.sleep(max(300, settings.pregame_refresh_interval_seconds))


_INTERNAL_MEMBER_COPY = re.compile(
    r"(創辦人|觀察名單|觀察候選|內部審核|不(?:計入|記錄|列入|計)[^。！？]{0,16}戰績)"
)


def _member_visible_summary(value: object) -> str:
    text = str(value or "").strip()
    if not text:
        return "此推薦已正式發布並鎖定。"
    sentences = re.findall(r"[^。！？]+[。！？]?", text) or [text]
    visible = "".join(
        sentence for sentence in sentences
        if not _INTERNAL_MEMBER_COPY.search(sentence)
    ).strip()
    return visible or "此推薦已正式發布並鎖定。"


def _selection_for_member(selection: dict | None, *, founder: bool = False) -> dict | None:
    if not isinstance(selection, dict):
        return None
    result = deepcopy(selection)
    if founder:
        return result

    result["summary"] = _member_visible_summary(result.get("summary"))
    result.pop("watchlist_reasons", None)
    if result.get("candidate_tier") in {"watchlist", "founder_selected"}:
        result["candidate_tier"] = "formal"

    publication = result.get("publication")
    if isinstance(publication, dict):
        publication = deepcopy(publication)
        for key in (
            "origin_tier",
            "selection_tier",
            "promoted_from_watchlist",
            "counts_as_ai_formal",
        ):
            publication.pop(key, None)
        if publication.get("mode") == "founder_selected":
            publication["mode"] = "published"
        result["publication"] = publication

    legs = result.get("legs")
    if isinstance(legs, list):
        result["legs"] = [
            _selection_for_member(leg, founder=False) or {}
            for leg in legs
            if isinstance(leg, dict)
        ]
    return result


_MEMBER_FINANCIAL_KEYS = {
    "performance",
    "profit_units",
    "roi_percent",
    "stake_units",
    "returned_units",
    "effective_decimal_odds",
    "cumulative_profit_units",
    "daily_profit_units",
}


def _strip_member_financials(value: object) -> object:
    """Remove founder-only financial metrics from member-facing payloads."""
    if isinstance(value, dict):
        return {
            key: _strip_member_financials(item)
            for key, item in value.items()
            if key not in _MEMBER_FINANCIAL_KEYS
        }
    if isinstance(value, list):
        return [_strip_member_financials(item) for item in value]
    return value


def _free_pick_for_member(
    selection: dict | None,
    *,
    founder: bool = False,
) -> dict | None:
    """Return the compact daily-pick card payload.

    Founder/admin requests preserve the publication source marker so the UI
    can show that the locked daily pick was explicitly selected by the
    founder. Member requests still receive the same public card without
    internal publication metadata.
    """

    result = _selection_for_member(selection, founder=founder)
    if not result:
        return result
    for key in (
        "factors",
        "analysis_groups",
        "engine",
        "starting_pitchers",
        "lineups",
        "bullpen",
        "environment",
        "advanced",
        "data_sources",
        "source_status",
        "model_inputs",
    ):
        result.pop(key, None)
    game = result.get("game")
    if isinstance(game, dict):
        result["game"] = {
            key: game.get(key)
            for key in ("event_label", "season_context", "status", "detailed_status")
            if game.get(key) is not None
        }
    return result


def _public_prediction_response(payload: dict) -> dict:
    result = deepcopy(payload)
    if isinstance(result.get("selection"), dict):
        result["selection"] = _free_pick_for_member(result["selection"])
    # Unpublished candidates and publication policy are internal model review data.
    result.pop("candidate", None)
    result.pop("publication_policy", None)
    return result


def locked_prediction_from_record(
    prediction_date: date,
    record: dict,
) -> dict | None:
    snapshot = record.get("prediction_snapshot")
    if not isinstance(snapshot, dict) or not snapshot:
        return None
    snapshot = deepcopy(snapshot)
    snapshot["result"] = {
        "status": str(record.get("status") or "pending"),
        "away_score": record.get("away_score"),
        "home_score": record.get("home_score"),
        "result_note": record.get("result_note"),
        "settled_at": record.get("settled_at"),
    }
    return {
        "date": prediction_date.isoformat(),
        "published": True,
        "locked": True,
        "selection": snapshot,
        "message": "今日正式推薦已鎖定，後續更新不會更換推薦內容。",
        "meta": {
            "locked": True,
            "record_id": record.get("id"),
            "published_at": record.get("published_at"),
            "model_version": snapshot.get("model_version"),
        },
        "persistence": {
            "enabled": True,
            "stored": True,
            "created": False,
            "locked": True,
            "record_id": record.get("id"),
        },
    }


async def prediction_with_persistence(
    request: Request,
    prediction_date: date,
    *,
    publish_if_eligible: bool = True,
) -> dict:
    repository = records_repository(request)
    lookup_message = None
    if repository.enabled:
        try:
            existing = await repository.get_record_for_date(prediction_date.isoformat())
            if existing:
                snapshot = existing.get("prediction_snapshot")
                if isinstance(snapshot, dict):
                    try:
                        await performance_repository(request).capture_public(prediction_date.isoformat(), str(existing.get("id")), snapshot)
                    except PerformanceStorageError:
                        pass
                locked = locked_prediction_from_record(prediction_date, existing)
                if locked:
                    return locked
        except RecordsStorageError:
            # The model can still provide a result during a temporary database
            # incident, but it is clearly marked as not durably locked.
            lookup_message = "紀錄資料庫暫時無法確認今日鎖單。"

    result = await service(request).top_prediction(prediction_date)
    if result.get("published") and result.get("selection"):
        policy = publication_policy(result["selection"], automatic=True)
        if not policy["auto_publish_ready"]:
            result = {
                **result, "published": False, "selection": None,
                "candidate": result.get("selection"),
                "message": "模型已完成預覽；系統會在最高候選場次進入開賽前 30 分鐘最終鎖定窗後自動發布。",
                "publication_policy": policy,
            }
    persistence = {"enabled": repository.enabled, "stored": False}
    if lookup_message:
        persistence["message"] = lookup_message
    if result.get("published") and not publish_if_eligible:
        # A normal page view must never become the action that locks the
        # official pick. Only the protected scheduler or the founder publish
        # endpoint is allowed to create the immutable public record.
        return {
            "date": prediction_date.isoformat(),
            "published": False,
            "locked": False,
            "selection": None,
            "message": "今日正式推薦尚未發布；將由固定排程自動發布，或由創辦人提前指定。",
            "meta": {
                **(result.get("meta") or {}),
                "publication_status": "pending",
            },
            "persistence": persistence,
        }
    if result.get("published") and repository.enabled:
        try:
            stored, created = await repository.publish_prediction_once(
                result["date"], result["selection"]
            )
            persistence.update(
                {
                    "stored": True,
                    "created": created,
                    "locked": True,
                    "record_id": stored.get("id"),
                }
            )
            try:
                await performance_repository(request).capture_public(result["date"], str(stored.get("id")), result["selection"])
            except PerformanceStorageError:
                persistence["snapshot_message"] = "模型快照資料表暫時無法寫入。"
            if not created:
                locked = locked_prediction_from_record(prediction_date, stored)
                if locked:
                    return locked
        except RecordsStorageError:
            # Prediction remains available even if the records database has a
            # temporary incident. It can be requested again to retry the upsert.
            persistence["message"] = "推薦已產生，但紀錄資料庫暫時無法寫入。"
    result["persistence"] = persistence
    return result


async def _settle_pending_records_with(
    repository: SupabaseRecordsRepository,
    mlb_service: MLBService,
    performance: PerformanceRepository | None = None,
) -> int:
    if not repository.enabled:
        return 0
    pending = await repository.list_records(status="pending")
    settled_now = 0
    for record in pending:
        try:
            game = await mlb_service.game_result(int(record["game_pk"]))
        except (KeyError, MLBUpstreamError, TypeError, ValueError):
            continue
        result = settlement_for(record, game)
        settled_record = await repository.settle(int(record["game_pk"]), result) if result else None
        if result and settled_record:
            settled_now += 1
            if performance is not None:
                try:
                    await performance.settle_public(str(record.get("id")), result)
                except PerformanceStorageError:
                    pass
    return settled_now


async def settle_pending_records(request: Request) -> int:
    return await _settle_pending_records_with(records_repository(request), service(request), performance_repository(request))


def _selection_league(selection: dict) -> str:
    return str(selection.get("league") or (selection.get("game") or {}).get("league") or "MLB").upper()


def _package_game_refs(record: dict) -> set[tuple[str, str]]:
    refs: set[tuple[str, str]] = set()
    package = package_from_record(record)
    for key in ("moneylines", "run_lines", "totals"):
        for selection in package.get(key) or []:
            game_pk = selection.get("game_pk")
            if game_pk is not None:
                refs.add((_selection_league(selection), str(game_pk)))
    for key in ("two_leg", "three_leg"):
        for parlay in (package.get("parlays") or {}).get(key) or []:
            for leg in parlay.get("legs") or []:
                game_pk = leg.get("game_pk")
                if game_pk is not None:
                    refs.add((_selection_league(leg), str(game_pk)))
    return refs


async def _game_result_for_ref(
    mlb_service: MLBService,
    npb_adapter: NPBService,
    league: str,
    game_pk: str,
) -> dict:
    if league == "NPB":
        return await npb_adapter.game_result(game_pk)
    return await mlb_service.game_result(int(game_pk))


async def _settle_pending_prediction_packages_with(
    repository: SupabaseRecordsRepository,
    mlb_service: MLBService,
    npb_adapter: NPBService,
    performance: PerformanceRepository | None = None,
) -> int:
    if not repository.enabled:
        return 0
    pending = await repository.list_pending_prediction_packages()
    settled_now = 0
    for record in pending:
        package = package_from_record(record)
        publication_mode = str((package.get("publication") or {}).get("mode") or "")
        if publication_mode == "ai_auto":
            # Scheduler placeholders were never founder-approved formal picks.
            # Do not settle them or include them in model performance.
            continue
        games: dict[str, dict] = {}
        for league, game_pk in _package_game_refs(record):
            try:
                games[game_pk] = await _game_result_for_ref(mlb_service, npb_adapter, league, game_pk)
            except (KeyError, MLBUpstreamError, NPBUpstreamError, TypeError, ValueError):
                continue
        result = settle_prediction_package(record, games)
        settled_package = await repository.settle_prediction_package(str(record["id"]), result) if result else None
        if result and settled_package and result.get("settled") is True:
            settled_now += 1
            if performance is not None:
                try:
                    await performance.settle_package(str(record.get("id")), result)
                except PerformanceStorageError:
                    pass
    return settled_now


async def settle_pending_prediction_packages(request: Request) -> int:
    return await _settle_pending_prediction_packages_with(
        records_repository(request), service(request), npb_service(request), performance_repository(request)
    )


async def _game_results_for_refs(
    mlb_service: MLBService,
    npb_adapter: NPBService,
    refs: set[tuple[str, str]],
) -> tuple[dict[str, dict], list[dict]]:
    games: dict[str, dict] = {}
    errors: list[dict] = []
    for league, game_pk in sorted(refs):
        try:
            games[game_pk] = await _game_result_for_ref(mlb_service, npb_adapter, league, game_pk)
        except (KeyError, MLBUpstreamError, NPBUpstreamError, TypeError, ValueError) as exc:
            errors.append({"league": league, "game_pk": game_pk, "error": type(exc).__name__})
    return games, errors


async def settlement_dashboard(
    repository: SupabaseRecordsRepository,
    mlb_service: MLBService,
    npb_adapter: NPBService,
    target_date: date,
) -> dict:
    if not repository.enabled:
        return {
            "date": target_date.isoformat(),
            "database": "not_configured",
            "public": None,
            "package": None,
            "summary": {"total": 0, "pending": 0, "settled": 0, "won": 0, "lost": 0, "push": 0, "void": 0},
            "errors": [],
        }
    public_record = await repository.get_record_for_date(target_date.isoformat())
    package_record = await repository.get_prediction_package_for_date(target_date.isoformat())
    refs: set[tuple[str, str]] = set()
    if public_record and public_record.get("game_pk") is not None:
        refs.add(("MLB", str(public_record.get("game_pk"))))
    if package_record:
        refs.update(_package_game_refs(package_record))
    games, errors = await _game_results_for_refs(mlb_service, npb_adapter, refs)
    public_game = games.get(str(public_record.get("game_pk"))) if public_record and public_record.get("game_pk") is not None else None
    public_preview = preview_public_record(public_record, public_game)
    package_preview = preview_prediction_package(package_record, games)
    statuses: list[str] = []
    if public_preview:
        statuses.append(str((public_preview.get("preview") or {}).get("status") or "pending"))
    if package_preview:
        for values in (package_preview.get("groups") or {}).values():
            statuses.extend(str(item.get("status") or "pending") for item in values)
    summary = {
        "total": len(statuses),
        "pending": statuses.count("pending"),
        "won": statuses.count("won"),
        "lost": statuses.count("lost"),
        "push": statuses.count("push"),
        "void": statuses.count("void"),
    }
    summary["settled"] = summary["total"] - summary["pending"]
    return {
        "date": target_date.isoformat(),
        "database": "connected",
        "public": public_preview,
        "package": package_preview,
        "summary": summary,
        "games": games,
        "errors": errors,
        "updated_at": iso_utc(),
    }


async def locked_or_generated_market_package(
    request: Request,
    target_date: date,
    public_prediction: dict,
    odds_feed: dict,
    *,
    persist: bool = True,
) -> dict:
    repository = records_repository(request)
    if repository.enabled:
        try:
            existing = await repository.get_prediction_package_for_date(target_date.isoformat())
            if existing:
                existing_package = package_from_record(existing)
                try:
                    await performance_repository(request).capture_package(target_date.isoformat(), str(existing.get("id")), existing_package)
                except PerformanceStorageError:
                    pass
                return existing_package
        except RecordsStorageError:
            existing = None

    analyses = await service(request).matchup_analyses(target_date, pitcher_limit=None)
    eligible_analyses = [
        item
        for item in analyses["items"]
        if (item.get("game") or {}).get("auto_recommendation_eligible") is True
        and publication_policy(item, automatic=False)["can_publish"]
        and (((item.get("analysis_groups") or {}).get("starter") or {}).get("both_starters_ready") is True)
    ]
    bundle = build_daily_market_candidates(
        target_date.isoformat(),
        eligible_analyses,
        odds_feed.get("items") or [],
        public_prediction.get("selection") if public_prediction.get("published") else None,
        minimum_probability=settings.min_market_probability,
        minimum_edge=settings.min_market_edge,
        minimum_projection_quality=settings.min_projection_quality,
        minimum_parlay_probability=settings.min_parlay_leg_probability,
    )
    npb_feed = {"items": [], "meta": {"fresh_for_model": False, "status": "unavailable"}}
    if odds_service(request).enabled:
        try:
            fetched_npb_feed = await odds_service(request).odds_for_date(
                target_date,
                sport_key=settings.npb_odds_sport_key,
            )
            npb_feed = fetched_npb_feed
        except OddsUpstreamError:
            pass
    npb_candidates = await npb_market_candidates_for_date(
        request,
        target_date,
        (npb_feed.get("items") or [])
        if (npb_feed.get("meta") or {}).get("fresh_for_model")
        else [],
    )
    bundle = merge_market_candidates(
        bundle,
        npb_candidates,
        minimum_parlay_probability=settings.min_parlay_leg_probability,
    )
    bundle.setdefault("odds_feeds", {})["NPB"] = {
        "sport_key": settings.npb_odds_sport_key,
        "count": int(npb_feed.get("count") or 0),
        "fresh_for_model": bool((npb_feed.get("meta") or {}).get("fresh_for_model")),
        "cache": (npb_feed.get("meta") or {}).get("cache"),
    }
    package = build_selected_market_package(bundle, publication_mode="ai_auto")
    package["persistence"] = {"enabled": repository.enabled, "stored": False}
    if package["published"] and repository.enabled and persist:
        try:
            stored, created = await repository.publish_prediction_package_once(
                target_date.isoformat(), package
            )
            locked = package_from_record(stored)
            locked["persistence"] = {
                "enabled": True,
                "stored": True,
                "created": created,
                "record_id": stored.get("id"),
            }
            try:
                await performance_repository(request).capture_package(target_date.isoformat(), str(stored.get("id")), package)
            except PerformanceStorageError:
                locked["persistence"]["snapshot_message"] = "模型快照資料表暫時無法寫入。"
            return locked
        except RecordsStorageError:
            package["persistence"]["message"] = "會員玩法已產生，但資料表尚未完成設定或暫時無法寫入。"
    elif package["published"] and not persist:
        package["persistence"] = {
            "enabled": repository.enabled,
            "stored": False,
            "mode": "founder_approval_required",
        }
        package["message"] = "候選已產生，等待創辦人正式發布；排程不會自動建立 Pro 紀錄。"
    return package


@app.get("/")
async def root() -> dict:
    return {
        "name": settings.app_name,
        "version": "18.9.5",
        "status": "online",
        "docs": "/docs",
        "health": f"{settings.api_prefix}/health",
    }


@app.get(f"{settings.api_prefix}/health")
async def health() -> dict:
    return {
        "ok": True,
        "service": settings.app_name,
        "version": "18.9.5",
        "environment": settings.app_env,
        "records_database": "configured" if settings.records_enabled else "not_configured",
        "odds_feed": "configured" if settings.odds_enabled else "not_configured",
        "daily_scheduler": "configured" if settings.scheduler_enabled else "not_configured",
        "pregame_refresh": "running",
        "settlement_monitor": "running",
        "operations_monitor": getattr(app.state, "operations_monitor_status", {}).get("status", "starting"),
        "billing": "configured" if settings.billing_enabled else "not_configured",
        "billing_mode": settings.ecpay_mode if settings.billing_enabled else None,
        "announcements": "configured" if settings.records_enabled else "not_configured",
        "model_performance": "configured" if settings.records_enabled else "not_configured",
        "new_member_trial": "enabled" if settings.new_member_trial_enabled else "disabled",
        "new_member_trial_hours": settings.new_member_trial_hours if settings.new_member_trial_enabled else 0,
        "leagues": {"MLB": "full", "NPB": "full_markets", "KBO": "planned", "CPBL": "planned"},
        "time_taiwan": datetime.now(TAIPEI).isoformat(),
    }

@app.get(f"{settings.api_prefix}/admin/operations/status")
async def admin_operations_status(
    request: Request,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    """Founder-only launch readiness and runtime monitor.

    The endpoint is intentionally read-only and does not alter predictions,
    settlements, memberships or payment state.
    """

    await admin_member(request, authorization)
    pregame = dict(getattr(request.app.state, "pregame_status", {}) or {})
    settlement = dict(getattr(request.app.state, "settlement_status", {}) or {})
    operations = dict(getattr(request.app.state, "operations_monitor_status", {}) or {})
    odds = odds_service(request).status()
    billing = billing_service(request)

    checks = [
        {
            "key": "records_database",
            "label": "Supabase 資料庫",
            "status": "pass" if settings.records_enabled else "fail",
            "detail": "推薦、會員、公告與模型資料庫已設定" if settings.records_enabled else "缺少 Supabase 連線設定",
            "blocking": True,
        },
        {
            "key": "odds_feed",
            "label": "真實盤口來源",
            "status": "pass" if settings.odds_enabled else "warning",
            "detail": "Odds API 已設定" if settings.odds_enabled else "未設定 Odds API，正式 Pro 玩法會被阻擋",
            "blocking": True,
        },
        {
            "key": "scheduler",
            "label": "排程密鑰",
            "status": "pass" if settings.scheduler_enabled else "warning",
            "detail": "伺服器排程驗證已設定" if settings.scheduler_enabled else "缺少 CRON_SECRET，外部排程無法安全觸發",
            "blocking": True,
        },
        {
            "key": "billing",
            "label": "付款服務",
            "status": "pass" if billing.enabled else "fail",
            "detail": f"綠界 {settings.ecpay_mode} 模式已設定" if billing.enabled else "付款服務設定不完整",
            "blocking": True,
        },
        {
            "key": "payment_live",
            "label": "正式收款模式",
            "status": "pass" if settings.ecpay_mode == "production" and billing.enabled else "pending",
            "detail": "已切換綠界正式環境" if settings.ecpay_mode == "production" and billing.enabled else "目前維持測試環境，正式收費前再切換",
            "blocking": False,
        },
        {
            "key": "support_channel",
            "label": "客服聯絡管道",
            "status": "pass" if settings.support_email else "pending",
            "detail": settings.support_email or "尚未設定 SUPPORT_EMAIL",
            "blocking": False,
        },
        {
            "key": "official_settlement_verification",
            "label": "真實推薦與結算驗收",
            "status": "pending",
            "detail": "7 月 17 日發布正式推薦，賽後確認紀錄保留與自動結算",
            "blocking": False,
            "manual": True,
        },
    ]
    blocking_failures = [item for item in checks if item.get("blocking") and item.get("status") != "pass"]
    monitor_errors = [value for value in (pregame.get("last_error"), settlement.get("last_error")) if value]
    monitor_errors.extend(
        str(item.get("detail") or item.get("label") or "operations_monitor")
        for item in (operations.get("critical_issues") or [])
    )
    overall = "attention" if blocking_failures or monitor_errors else "stage_ready"
    return {
        "ok": not bool(blocking_failures),
        "overall": overall,
        "version": "18.9.5",
        "environment": settings.app_env,
        "generated_at": datetime.now(TAIPEI).isoformat(),
        "runtime_started_at": getattr(request.app.state, "started_at", None),
        "services": {
            "records_database": settings.records_enabled,
            "odds_feed": settings.odds_enabled,
            "scheduler": settings.scheduler_enabled,
            "billing": billing.enabled,
            "billing_mode": settings.ecpay_mode,
            "billing_live": settings.ecpay_mode == "production" and billing.enabled,
            "support_email": settings.support_email or None,
            "public_api_base": settings.public_api_base,
            "frontend_base_url": settings.frontend_base_url,
            "odds_status": odds,
        },
        "monitors": {
            "pregame": pregame,
            "settlement": settlement,
            "operations": operations,
        },
        "checks": checks,
        "blocking_failures": len(blocking_failures),
        "monitor_errors": monitor_errors,
    }


class AnnouncementPayload(BaseModel):
    title: str = Field(min_length=1, max_length=120)
    body: str = Field(min_length=1, max_length=6000)
    summary: str | None = Field(default=None, max_length=320)
    severity: str = Field(default="general", pattern="^(general|important|emergency)$")
    audience: str = Field(default="all", pattern="^(all|free|pro)$")
    show_home: bool = True
    show_login_modal: bool = True
    dismissible_today: bool = True
    action_label: str | None = Field(default=None, max_length=40)
    action_page: str | None = Field(default=None, pattern="^(|homePage|gamesPage|predictionPage|recordsPage|membershipPage|morePage)$")
    starts_at: datetime | None = None
    ends_at: datetime | None = None
    is_active: bool = True
    priority: int | None = Field(default=None, ge=0, le=999)


@app.get(f"{settings.api_prefix}/announcements/active")
async def active_announcements(
    request: Request,
    placement: str = Query(default="home", pattern="^(home|login)$"),
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    member = await optional_member(request, authorization)
    try:
        items = await announcement_service(request).active(role=str(member.get("role") or "guest"), placement=placement)
        return {"items": items, "placement": placement, "role": member.get("role"), "updated_at": iso_utc()}
    except AnnouncementError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


@app.get(f"{settings.api_prefix}/admin/announcements")
async def admin_announcements(
    request: Request,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    await admin_member(request, authorization)
    try:
        return {"items": await announcement_service(request).admin_list(), "updated_at": iso_utc()}
    except AnnouncementError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


@app.post(f"{settings.api_prefix}/admin/announcements")
async def admin_create_announcement(
    request: Request,
    payload: AnnouncementPayload,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    actor = await admin_member(request, authorization)
    try:
        return {"ok": True, "announcement": await announcement_service(request).create(payload.model_dump(), actor)}
    except AnnouncementError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc


@app.patch(f"{settings.api_prefix}/admin/announcements/{{announcement_id}}")
async def admin_update_announcement(
    request: Request,
    announcement_id: str,
    payload: AnnouncementPayload,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    actor = await admin_member(request, authorization)
    try:
        return {"ok": True, "announcement": await announcement_service(request).update(announcement_id, payload.model_dump(), actor)}
    except AnnouncementError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc


@app.delete(f"{settings.api_prefix}/admin/announcements/{{announcement_id}}")
async def admin_delete_announcement(
    request: Request,
    announcement_id: str,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    await admin_member(request, authorization)
    try:
        await announcement_service(request).delete(announcement_id)
        return {"ok": True, "deleted": announcement_id}
    except AnnouncementError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc


class BillingCheckout(BaseModel):
    plan: str = Field(pattern="^(monthly|quarterly|annual)$")


@app.get(f"{settings.api_prefix}/billing/config", response_class=JSONResponse)
async def billing_config(request: Request) -> JSONResponse:
    # Keep an explicit UTF-8 charset for mobile browsers and use ASCII-only
    # gateway item names so the ECPay page cannot display mojibake.
    return JSONResponse(
        content=billing_service(request).public_config(),
        media_type="application/json; charset=utf-8",
    )


@app.get(f"{settings.api_prefix}/billing/status")
async def billing_member_status(
    request: Request,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    member = await authenticated_member(request, authorization)
    if member.get("role") == "admin":
        return {
            "active": True,
            "status": "founder",
            "plan": "founder",
            "auto_renew": False,
            "current_period_end": None,
            "mode": settings.ecpay_mode,
        }
    try:
        return await billing_service(request).member_status(member)
    except BillingError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


@app.post(f"{settings.api_prefix}/billing/checkout")
async def billing_checkout(
    request: Request,
    command: BillingCheckout,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    member = await authenticated_member(request, authorization)
    try:
        return await billing_service(request).create_checkout(member, command.plan)
    except BillingError as exc:
        message = str(exc)
        status = 409 if "already exists" in message.lower() else 403 if "restricted" in message.lower() else 503
        raise HTTPException(status_code=status, detail=message) from exc


@app.post(f"{settings.api_prefix}/billing/cancel")
async def billing_cancel(
    request: Request,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    member = await authenticated_member(request, authorization)
    try:
        return await billing_service(request).cancel(member)
    except BillingError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc


@app.post(f"{settings.api_prefix}/billing/ecpay/return", response_class=PlainTextResponse)
async def billing_ecpay_return(request: Request) -> PlainTextResponse:
    payload = parse_form_body(await request.body())
    try:
        await billing_service(request).process_callback(payload, event_type="initial_payment")
        return PlainTextResponse("1|OK")
    except BillingError as exc:
        return PlainTextResponse(f"0|{str(exc)[:120]}")


@app.post(f"{settings.api_prefix}/billing/ecpay/result", response_class=HTMLResponse)
async def billing_ecpay_result(request: Request) -> HTMLResponse:
    payload = parse_form_body(await request.body())
    return HTMLResponse(billing_service(request).result_redirect_html(payload))


@app.post(f"{settings.api_prefix}/membership/trial/claim")
async def membership_trial_claim(
    request: Request,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    member = await authenticated_member(request, authorization)
    try:
        return await member_trial_service(request).claim(member)
    except NewMemberTrialError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    except BillingError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


class AdminMembershipCommandPayload(BaseModel):
    action: str = Field(pattern="^(grant|extend|cancel)$")
    plan: str | None = Field(default=None, pattern="^(trial_1d|gift_3d|gift_7d|monthly|quarterly|annual|custom)$")
    note: str | None = Field(default=None, max_length=300)
    custom_expires_at: str | None = Field(default=None, max_length=64)


@app.get(f"{settings.api_prefix}/admin/members")
async def admin_members(
    request: Request,
    query: str = Query(default="", max_length=120),
    role: str = Query(default="all", pattern="^(all|free|pro|admin)$"),
    status: str = Query(default="all", pattern="^(all|free|active|pending|expired|canceled|payment_failed|refunded|founder)$"),
    limit: int = Query(default=50, ge=1, le=200),
    offset: int = Query(default=0, ge=0),
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    await admin_member(request, authorization)
    try:
        return await membership_admin_service(request).overview(
            query=query, role=role, status=status, limit=limit, offset=offset
        )
    except (BillingError, AdminMembershipError) as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


@app.get(f"{settings.api_prefix}/admin/members/{{user_id}}")
async def admin_member_detail(
    request: Request,
    user_id: str,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    await admin_member(request, authorization)
    try:
        return await membership_admin_service(request).member_detail(user_id)
    except (BillingError, AdminMembershipError) as exc:
        raise HTTPException(status_code=404 if "invalid member" in str(exc).lower() else 503, detail=str(exc)) from exc


@app.post(f"{settings.api_prefix}/admin/members/{{user_id}}/membership")
async def admin_member_membership(
    request: Request,
    user_id: str,
    payload: AdminMembershipCommandPayload,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    actor = await admin_member(request, authorization)
    try:
        return await membership_admin_service(request).apply_command(
            actor=actor,
            target_user_id=user_id,
            command=AdminMemberCommand(action=payload.action, plan=payload.plan, note=payload.note, custom_expires_at=payload.custom_expires_at),
        )
    except AdminMembershipError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    except BillingError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


@app.get(f"{settings.api_prefix}/admin/transactions")
async def admin_transactions(
    request: Request,
    query: str = Query(default="", max_length=120),
    result: str = Query(default="all", pattern="^(all|success|failed)$"),
    limit: int = Query(default=100, ge=1, le=200),
    offset: int = Query(default=0, ge=0),
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    await admin_member(request, authorization)
    try:
        return await membership_admin_service(request).transactions(
            query=query, result=result, limit=limit, offset=offset
        )
    except (BillingError, AdminMembershipError) as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc


@app.get(f"{settings.api_prefix}/admin/export/members.csv")
async def admin_export_members_csv(
    request: Request,
    query: str = Query(default="", max_length=120),
    role: str = Query(default="all", pattern="^(all|free|pro|admin)$"),
    status: str = Query(default="all", pattern="^(all|free|active|pending|expired|canceled|payment_failed|refunded|founder)$"),
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> Response:
    await admin_member(request, authorization)
    try:
        members = await membership_admin_service(request).export_members(
            query=query, role=role, status=status
        )
    except (BillingError, AdminMembershipError) as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    rows = [
        {
            "會員ID": item.get("id"),
            "Email": item.get("email"),
            "暱稱": item.get("name"),
            "角色": item.get("role"),
            "狀態": item.get("status"),
            "方案": item.get("plan"),
            "到期日": item.get("pro_expires_at") or item.get("current_period_end"),
            "註冊時間": item.get("created_at"),
            "最後登入": item.get("last_sign_in_at"),
            "付款來源": item.get("provider"),
            "最近交易編號": item.get("merchant_trade_no"),
        }
        for item in members
    ]
    fields = ["會員ID", "Email", "暱稱", "角色", "狀態", "方案", "到期日", "註冊時間", "最後登入", "付款來源", "最近交易編號"]
    return _csv_response("diamondmind_members.csv", fields, rows)


@app.get(f"{settings.api_prefix}/admin/export/transactions.csv")
async def admin_export_transactions_csv(
    request: Request,
    query: str = Query(default="", max_length=120),
    result: str = Query(default="all", pattern="^(all|success|failed)$"),
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> Response:
    await admin_member(request, authorization)
    try:
        transactions = await membership_admin_service(request).export_transactions(
            query=query, result=result
        )
    except (BillingError, AdminMembershipError) as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    rows = [
        {
            "時間": item.get("created_at"),
            "Email": item.get("email"),
            "結果": "成功" if item.get("success") else "失敗",
            "金額TWD": item.get("amount"),
            "平台": item.get("provider"),
            "商店交易編號": item.get("merchant_trade_no"),
            "金流交易編號": item.get("provider_trade_no"),
            "付款方式": item.get("payment_type"),
            "事件類型": item.get("event_type"),
            "訊息": item.get("rtn_msg"),
        }
        for item in transactions
    ]
    fields = ["時間", "Email", "結果", "金額TWD", "平台", "商店交易編號", "金流交易編號", "付款方式", "事件類型", "訊息"]
    return _csv_response("diamondmind_transactions.csv", fields, rows)


@app.get(f"{settings.api_prefix}/odds/status")
async def odds_status(request: Request) -> dict:
    # This endpoint never calls the paid upstream service and never exposes its key.
    return odds_service(request).status()


@app.get(f"{settings.api_prefix}/advanced/status")
async def advanced_status(
    request: Request,
    season: int = Query(default=datetime.now(TAIPEI).year, ge=2015, le=2100),
) -> dict:
    """Public, non-sensitive Statcast source diagnostic."""
    return await service(request).statcast.diagnostics(season)


@app.get(f"{settings.api_prefix}/pregame/status")
async def pregame_status(request: Request) -> dict:
    return {
        **(getattr(request.app.state, "pregame_status", {}) or {}),
        "lineup_watch_minutes": settings.pregame_lineup_watch_minutes,
        "final_lock_minutes": settings.pregame_final_lock_minutes,
        "minimum_publish_data_quality": settings.minimum_publish_data_quality,
        "minimum_lineup_validation_rate": settings.minimum_lineup_validation_rate,
        "settlement_monitor": getattr(request.app.state, "settlement_status", {}) or {},
    }


@app.get(f"{settings.api_prefix}/admin/settlement/status")
async def admin_settlement_status(
    request: Request,
    target_date: date | None = Query(default=None, alias="date"),
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    await admin_member(request, authorization)
    try:
        dashboard = await settlement_dashboard(
            records_repository(request), service(request), npb_service(request), requested_date(target_date)
        )
    except RecordsStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    dashboard["monitor"] = getattr(request.app.state, "settlement_status", {}) or {}
    return dashboard


@app.post(f"{settings.api_prefix}/admin/settlement/run")
async def admin_run_settlement(
    request: Request,
    target_date: date | None = Query(default=None, alias="date"),
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    actor = await admin_member(request, authorization)
    try:
        free_count = await settle_pending_records(request)
        package_count = await settle_pending_prediction_packages(request)
        dashboard = await settlement_dashboard(
            records_repository(request), service(request), npb_service(request), requested_date(target_date)
        )
    except RecordsStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    request.app.state.settlement_status = {
        "running": True,
        "last_run": iso_utc(),
        "last_error": None,
        "free_settled_now": free_count,
        "packages_settled_now": package_count,
        "manual_by": actor.get("email"),
    }
    return {
        "ok": True,
        "free_settled_now": free_count,
        "packages_settled_now": package_count,
        "dashboard": dashboard,
        "message": "已重新向 MLB 官方資料檢查所有待結算推薦。",
    }




async def sync_existing_model_snapshots(request: Request) -> dict:
    """Idempotently backfill snapshots for recommendations published before this release."""

    records = records_repository(request)
    performance = performance_repository(request)
    if not records.enabled or not performance.enabled:
        return {"public": 0, "packages": 0}
    public_count = 0
    package_count = 0
    try:
        public_rows = await records.list_records(limit=1000)
        pending_packages = await records.list_pending_prediction_packages()
        settled_packages = await records.list_settled_prediction_packages(limit=1000)
    except RecordsStorageError:
        return {"public": 0, "packages": 0}
    seen_packages: dict[str, dict] = {}
    for item in [*pending_packages, *settled_packages]:
        if item.get("id") is not None:
            seen_packages[str(item.get("id"))] = item
    for record in public_rows:
        selection = record.get("prediction_snapshot")
        if not isinstance(selection, dict) or not record.get("id"):
            continue
        try:
            await performance.capture_public(str(record.get("recommendation_date")), str(record.get("id")), selection)
            if str(record.get("status")) in {"won", "lost", "push", "void"}:
                await performance.settle_public(str(record.get("id")), {
                    "status": record.get("status"),
                    "away_score": record.get("away_score"),
                    "home_score": record.get("home_score"),
                    "result_note": record.get("result_note"),
                    "settled_at": record.get("settled_at") or iso_utc(),
                })
            public_count += 1
        except PerformanceStorageError:
            break
    for record_id, record in seen_packages.items():
        try:
            package = package_from_record(record)
            publication_mode = str((package.get("publication") or {}).get("mode") or "")
            if publication_mode == "ai_auto":
                continue
            await performance.capture_package(str(record.get("recommendation_date")), record_id, package)
            if record.get("settled") is True:
                await performance.settle_package(record_id, {"results": record.get("results") or {}})
            package_count += 1
        except PerformanceStorageError:
            break
    return {"public": public_count, "packages": package_count}


class ModelWeightCommand(BaseModel):
    weights: dict[str, float]
    note: str | None = Field(default=None, max_length=500)
    confirm: bool = False


class ModelTestSettlementCommand(BaseModel):
    recommendation_date: date
    market: str = Field(pattern="^(moneyline|run_line|totals)$")
    pick_side: str = Field(pattern="^(home|away|over|under)$")
    line: float | None = None
    away_score: int = Field(ge=0, le=99)
    home_score: int = Field(ge=0, le=99)
    confidence: float = Field(default=65.0, ge=50, le=99.9)
    data_quality: float = Field(default=0.75, ge=0, le=1)
    module_edges: dict[str, float] = Field(default_factory=dict)


def _performance_range_days(value: str) -> int | None:
    return {"7d": 7, "30d": 30, "season": None}.get(value, 30)


@app.get(f"{settings.api_prefix}/admin/model/performance")
async def admin_model_performance(
    request: Request,
    range_value: str = Query(default="30d", alias="range", pattern="^(7d|30d|season)$"),
    market: str = Query(default="all", pattern="^(all|moneyline|run_line|totals|two_leg|three_leg)$"),
    source_type: str = Query(default="all", pattern="^(all|public|pro)$"),
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    await admin_member(request, authorization)
    backfill = await sync_existing_model_snapshots(request)
    try:
        dashboard = await performance_repository(request).performance_dashboard(
            days=_performance_range_days(range_value), market=market, source_type=source_type
        )
    except PerformanceStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    dashboard["range"] = range_value
    dashboard["backfill"] = backfill
    dashboard["model_runtime_weights"] = normalize_weights(service(request).model_weights)
    return dashboard


@app.get(f"{settings.api_prefix}/admin/model/snapshots")
async def admin_model_snapshots(
    request: Request,
    range_value: str = Query(default="30d", alias="range", pattern="^(7d|30d|season)$"),
    market: str = Query(default="all", pattern="^(all|moneyline|run_line|totals|two_leg|three_leg)$"),
    source_type: str = Query(default="all", pattern="^(all|public|pro|test)$"),
    include_test: bool = Query(default=False),
    limit: int = Query(default=250, ge=1, le=2000),
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    await admin_member(request, authorization)
    await sync_existing_model_snapshots(request)
    try:
        items = await performance_repository(request).list_snapshots(
            days=_performance_range_days(range_value),
            include_test=include_test,
            market=market,
            source_type=source_type,
            limit=limit,
        )
    except PerformanceStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    return {"items": items, "count": len(items), "range": range_value, "updated_at": iso_utc()}


@app.post(f"{settings.api_prefix}/admin/model/calibration/apply")
async def admin_apply_model_calibration(
    request: Request,
    command: ModelWeightCommand,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    actor = await admin_member(request, authorization)
    if not command.confirm:
        raise HTTPException(status_code=409, detail="套用模型權重前必須再次確認。")
    unknown = sorted(set(command.weights) - set(DEFAULT_MODEL_WEIGHTS))
    if unknown:
        raise HTTPException(status_code=422, detail=f"未知模型模組：{', '.join(unknown)}")
    normalized = normalize_weights(command.weights)
    try:
        profile = await performance_repository(request).activate_weights(
            weights=normalized,
            actor_id=str(actor.get("id")),
            note=command.note,
        )
    except PerformanceStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    service(request).model_weights = normalized
    return {
        "ok": True,
        "weights": normalized,
        "profile": profile,
        "message": "新模型權重已啟用；後續新分析會使用這組權重，已發布推薦不會被改寫。",
    }


@app.post(f"{settings.api_prefix}/admin/model/test-settlement")
async def admin_model_test_settlement(
    request: Request,
    command: ModelTestSettlementCommand,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    actor = await admin_member(request, authorization)
    if command.market in {"moneyline", "run_line"} and command.pick_side not in {"away", "home"}:
        raise HTTPException(status_code=422, detail="獨贏與讓分測試必須選擇客隊或主隊。")
    if command.market == "totals" and command.pick_side not in {"over", "under"}:
        raise HTTPException(status_code=422, detail="大小分測試必須選擇大分或小分。")
    if command.market in {"run_line", "totals"} and command.line is None:
        raise HTTPException(status_code=422, detail="讓分與大小分測試必須輸入盤口。")

    pick_team_id = 1 if command.pick_side == "away" else 2 if command.pick_side == "home" else None
    side_zh = {"away": "客隊", "home": "主隊", "over": "大", "under": "小"}[command.pick_side]
    selection = {
        "candidate_id": f"test:{command.market}:{command.recommendation_date.isoformat()}:{iso_utc()}",
        "game_pk": 0,
        "market": command.market,
        "pick": {
            "market": command.market,
            "side": command.pick_side,
            "team_id": pick_team_id,
            "line": command.line,
            "label": f"{side_zh}{'' if command.line is None else f' {command.line:g}'}",
        },
    }
    game = {
        "status": "Final",
        "detailed_status": "Final",
        "away": {"id": 1, "score": command.away_score},
        "home": {"id": 2, "score": command.home_score},
    }
    result = settle_market_selection(selection, game)
    if not result:
        raise HTTPException(status_code=422, detail="測試條件無法產生結算結果。")
    analysis_groups = {
        key: {
            "edge_home": float(command.module_edges.get(key, 0.0)),
            "quality": 1.0,
            "available": True,
        }
        for key in DEFAULT_MODEL_WEIGHTS
    }
    try:
        snapshot = await performance_repository(request).create_test_snapshot({
            "recommendation_date": command.recommendation_date.isoformat(),
            "market": command.market,
            "pick_side": command.pick_side,
            "pick_label": selection["pick"]["label"],
            "line": command.line,
            "confidence": command.confidence,
            "data_quality": command.data_quality,
            "weights": service(request).model_weights or DEFAULT_MODEL_WEIGHTS,
            "analysis_groups": analysis_groups,
            "result": result,
        })
    except PerformanceStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    return {
        "ok": True,
        "test": True,
        "result": result,
        "snapshot": snapshot,
        "created_by": actor.get("email"),
        "message": "測試推薦已完成發布、鎖定、結算與快照紀錄；不會出現在公開紀錄或真實績效。",
    }


@app.get(f"{settings.api_prefix}/admin/model/export/snapshots.csv")
async def admin_export_model_snapshots(
    request: Request,
    range_value: str = Query(default="season", alias="range", pattern="^(7d|30d|season)$"),
    include_test: bool = Query(default=False),
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> Response:
    await admin_member(request, authorization)
    try:
        rows = await performance_repository(request).list_snapshots(
            days=_performance_range_days(range_value), include_test=include_test, limit=5000
        )
    except PerformanceStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    output = []
    for item in rows:
        modules = item.get("module_scores") or {}
        output.append({
            "日期": item.get("recommendation_date"),
            "來源": item.get("source_type"),
            "玩法": item.get("market"),
            "推薦": item.get("pick_label"),
            "信心": item.get("confidence"),
            "資料完整度": item.get("data_quality"),
            "盤口": item.get("line"),
            "價格": item.get("price"),
            "結果": item.get("status"),
            "單位盈虧": ((item.get("result") or {}).get("performance") or {}).get("profit_units"),
            "單筆ROI": ((item.get("result") or {}).get("performance") or {}).get("roi_percent"),
            "測試資料": item.get("is_test"),
            "先發分數": (modules.get("starter") or {}).get("edge_for_pick"),
            "打線分數": (modules.get("lineup") or {}).get("edge_for_pick"),
            "牛棚分數": (modules.get("bullpen") or {}).get("edge_for_pick"),
            "球隊實力分數": (modules.get("team_strength") or {}).get("edge_for_pick"),
            "進階數據分數": (modules.get("advanced") or {}).get("edge_for_pick"),
            "環境分數": (modules.get("environment") or {}).get("edge_for_pick"),
            "模型版本": item.get("model_version"),
            "發布時間": item.get("created_at"),
            "結算時間": item.get("settled_at"),
        })
    fields = ["日期", "來源", "玩法", "推薦", "信心", "資料完整度", "盤口", "價格", "結果", "單位盈虧", "單筆ROI", "測試資料", "先發分數", "打線分數", "牛棚分數", "球隊實力分數", "進階數據分數", "環境分數", "模型版本", "發布時間", "結算時間"]
    return _csv_response("diamondmind_model_snapshots.csv", fields, output)


@app.get(f"{settings.api_prefix}/admin/model/export/performance.csv")
async def admin_export_model_performance(
    request: Request,
    range_value: str = Query(default="season", alias="range", pattern="^(7d|30d|season)$"),
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> Response:
    await admin_member(request, authorization)
    try:
        dashboard = await performance_repository(request).performance_dashboard(
            days=_performance_range_days(range_value), market="all", source_type="all"
        )
    except PerformanceStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    rows = []
    for group_name, items in (("玩法", dashboard.get("by_market") or []), ("聯盟", dashboard.get("by_league") or []), ("信心區間", dashboard.get("by_confidence") or []), ("來源", dashboard.get("by_source") or [])):
        for item in items:
            rows.append({
                "分類": group_name,
                "項目": item.get("key"),
                "總數": item.get("total"),
                "有效決策": item.get("decisions"),
                "命中": item.get("won"),
                "未中": item.get("lost"),
                "走水": item.get("push"),
                "作廢": item.get("void"),
                "等待": item.get("pending"),
                "命中率": item.get("hit_rate"),
                "有效投注單位": item.get("stake_units"),
                "累計盈虧單位": item.get("profit_units"),
                "ROI": item.get("roi_percent"),
            })
    fields = ["分類", "項目", "總數", "有效決策", "命中", "未中", "走水", "作廢", "等待", "命中率", "有效投注單位", "累計盈虧單位", "ROI"]
    return _csv_response("diamondmind_model_performance.csv", fields, rows)


@app.get(f"{settings.api_prefix}/leagues")
async def league_catalog() -> dict:
    return {
        "default": "MLB",
        "items": [
            {
                "code": "MLB",
                "name": "Major League Baseball",
                "name_zh": "美國職棒",
                "status": "full",
                "capabilities": ["schedule", "live_scores", "probable_pitchers", "analysis", "predictions", "settlement"],
            },
            {
                "code": "NPB",
                "name": "Nippon Professional Baseball",
                "name_zh": "日本職棒",
                "status": "full_markets",
                "capabilities": ["schedule", "scores", "probable_pitchers", "standings", "team_form", "starter_stats", "analysis", "real_odds", "moneyline_predictions", "run_line_predictions", "totals_predictions", "parlays", "settlement"],
            },
            {"code": "KBO", "name": "Korea Baseball Organization", "name_zh": "韓國職棒", "status": "planned", "capabilities": []},
            {"code": "CPBL", "name": "Chinese Professional Baseball League", "name_zh": "中華職棒", "status": "planned", "capabilities": []},
        ],
    }


@app.get(f"{settings.api_prefix}/leagues/summary")
async def league_summary(
    request: Request,
    game_date: date | None = Query(default=None, alias="date", description="Taiwan date, YYYY-MM-DD"),
) -> dict:
    target_date = requested_date(game_date)
    mlb_result, npb_result = await asyncio.gather(
        service(request).games_for_date(target_date),
        npb_service(request).games_for_date(target_date),
        return_exceptions=True,
    )

    def summarize(code: str, payload: object, status: str) -> dict:
        if isinstance(payload, Exception):
            return {"code": code, "status": status, "available": False, "count": None, "upcoming": 0, "live": 0, "final": 0}
        data = payload if isinstance(payload, dict) else {}
        items = data.get("items") or data.get("dates") or []
        if code == "MLB" and data.get("dates"):
            games = []
            for day in data.get("dates") or []:
                games.extend(day.get("games") or [])
            items = games
        normalized = [item for item in items if isinstance(item, dict)]
        def state(item: dict) -> str:
            value = str(item.get("status") or (item.get("status") or {}).get("abstractGameState") or "").lower()
            detailed = str(item.get("detailed_status") or (item.get("status") or {}).get("detailedState") or "").lower()
            if "final" in value or "final" in detailed or "game over" in detailed:
                return "final"
            if value in {"live", "in progress"} or "progress" in detailed:
                return "live"
            return "upcoming"
        states = [state(item) for item in normalized]
        return {
            "code": code,
            "status": status,
            "available": True,
            "count": len(normalized),
            "upcoming": states.count("upcoming"),
            "live": states.count("live"),
            "final": states.count("final"),
        }

    return {
        "date": target_date.isoformat(),
        "items": [
            summarize("MLB", mlb_result, "full"),
            summarize("NPB", npb_result, "full_markets"),
            {"code": "KBO", "status": "planned", "available": False, "count": None, "upcoming": 0, "live": 0, "final": 0},
            {"code": "CPBL", "status": "planned", "available": False, "count": None, "upcoming": 0, "live": 0, "final": 0},
        ],
    }


@app.get(f"{settings.api_prefix}/games")
async def multi_league_games(
    request: Request,
    league: str = Query(default="MLB", min_length=3, max_length=4),
    game_date: date | None = Query(default=None, alias="date", description="Taiwan date, YYYY-MM-DD"),
) -> dict:
    code = league.strip().upper()
    target_date = requested_date(game_date)
    try:
        if code == "MLB":
            payload = await service(request).games_for_date(target_date)
            return {**payload, "league": "MLB"}
        if code == "NPB":
            return await npb_service(request).games_for_date(target_date)
        if code in {"KBO", "CPBL"}:
            raise HTTPException(status_code=501, detail=f"{code} adapter is planned but not enabled yet")
        raise HTTPException(status_code=400, detail="Unsupported league")
    except MLBUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    except NPBUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@app.get(f"{settings.api_prefix}/npb/standings")
async def npb_standings(
    request: Request,
    season: int = Query(default=datetime.now(TAIPEI).year, ge=1936, le=2100),
) -> dict:
    try:
        return await npb_service(request).standings_for_season(season)
    except NPBUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@app.get(f"{settings.api_prefix}/npb/games")
async def npb_games(
    request: Request,
    game_date: date | None = Query(default=None, alias="date", description="Taiwan date, YYYY-MM-DD"),
) -> dict:
    try:
        return await npb_service(request).games_for_date(requested_date(game_date))
    except NPBUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@app.get(f"{settings.api_prefix}/npb/games/{{game_pk}}")
async def npb_game_detail(
    request: Request,
    game_pk: str,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    member = await optional_member(request, authorization)
    try:
        detail = await npb_service(request).game_detail(game_pk)
        if not member.get("has_pro_access"):
            locked = locked_game_detail(detail, member)
            locked["meta"] = {
                "source": "NPB.jp official data",
                "updated_at": (detail.get("meta") or {}).get("updated_at"),
                "analysis_payload_returned": False,
            }
            return locked
        detail["access"] = {
            "role": member.get("role") or "pro",
            "has_pro_access": True,
            "required_plan": "pro",
        }
        return detail
    except NPBUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@app.get(f"{settings.api_prefix}/mlb/games")
async def mlb_games(
    request: Request,
    game_date: date | None = Query(default=None, alias="date", description="Taiwan date, YYYY-MM-DD"),
) -> dict:
    try:
        return await service(request).games_for_date(requested_date(game_date))
    except MLBUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@app.get(f"{settings.api_prefix}/mlb/games/{{game_pk}}")
async def mlb_game_detail(
    request: Request,
    game_pk: int,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    member = await optional_member(request, authorization)
    try:
        detail = await service(request).game_detail(game_pk)
        if not member.get("has_pro_access"):
            return locked_game_detail(detail, member)
        return {
            **detail,
            "analysis_locked": False,
            "access": {
                "role": member.get("role"),
                "has_pro_access": True,
                "required_plan": "pro",
            },
        }
    except KeyError as exc:
        raise HTTPException(status_code=404, detail="Game not found") from exc
    except MLBUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@app.get(f"{settings.api_prefix}/predictions/top")
async def top_prediction(
    request: Request,
    prediction_date: date | None = Query(default=None, alias="date", description="Taiwan date, YYYY-MM-DD"),
) -> dict:
    try:
        payload = await prediction_with_persistence(
            request,
            requested_date(prediction_date),
            publish_if_eligible=False,
        )
        return _public_prediction_response(payload)
    except MLBUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


def _record_result_payload(record: dict | None) -> dict | None:
    if not isinstance(record, dict):
        return None
    status = str(record.get("status") or "pending")
    return {
        "status": status,
        "away_score": record.get("away_score"),
        "home_score": record.get("home_score"),
        "result_note": record.get("result_note"),
        "settled_at": record.get("settled_at"),
    }


@app.get(f"{settings.api_prefix}/predictions/daily")
async def daily_predictions_for_member(
    request: Request,
    prediction_date: date | None = Query(default=None, alias="date", description="Taiwan date, YYYY-MM-DD"),
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    member = await authenticated_member(request, authorization)

    target_date = requested_date(prediction_date)
    repository = records_repository(request)
    if repository.enabled and target_date <= datetime.now(TAIPEI).date():
        try:
            await settle_pending_records(request)
            await settle_pending_prediction_packages(request)
        except (RecordsStorageError, MLBUpstreamError, NPBUpstreamError):
            # Results already stored remain readable even if a live settlement
            # refresh temporarily fails.
            pass
    try:
        stored = await repository.get_prediction_package_for_date(target_date.isoformat())
        public_record = await repository.get_record_for_date(target_date.isoformat())
    except RecordsStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc

    # The public daily record is the single source of truth for the large
    # free-pick card. It may have been selected by the founder and must never
    # be replaced by the convenience ``moneyline`` snapshot embedded in a Pro
    # package. The package snapshot is only a fallback for legacy dates.
    public_snapshot = (
        public_record.get("prediction_snapshot")
        if public_record and isinstance(public_record.get("prediction_snapshot"), dict)
        else None
    )

    moneyline = public_snapshot
    if stored:
        package = package_from_record(stored)
        publication_mode = str((package.get("publication") or {}).get("mode") or "")
        if publication_mode == "ai_auto":
            # Older schedulers could create a paid package before the founder
            # approved it. Treat that row as an internal placeholder only.
            package = None
        elif moneyline is None:
            moneyline = package.get("moneyline")
    else:
        package = None

    is_founder = member.get("role") == "admin"
    watchlist: dict[str, list[dict]] = {
        "moneylines": [],
        "run_lines": [],
        "totals": [],
    }
    watchlist_message = None
    if is_founder and package and isinstance(package.get("watchlist"), dict):
        watchlist = package.get("watchlist") or watchlist
    elif is_founder:
        # Observation candidates are founder-only internal review data. They
        # are never returned to free or Pro members, even though Pro members
        # may access the formally published recommendation package.
        try:
            live_bundle = await founder_market_candidate_bundle(request, target_date)
            watchlist = live_bundle.get("watchlist") or watchlist
        except HTTPException as exc:
            detail = exc.detail
            watchlist_message = (
                detail.get("message")
                if isinstance(detail, dict)
                else str(detail or "觀察名單暫時無法更新。")
            )

    formal_groups = {
        "moneylines": package.get("moneylines") if package else [],
        "run_lines": package.get("run_lines") if package else [],
        "totals": package.get("totals") if package else [],
        "two_leg": ((package.get("parlays") or {}).get("two_leg") if package else []),
        "three_leg": ((package.get("parlays") or {}).get("three_leg") if package else []),
    }
    formal_count = sum(len(items or []) for items in formal_groups.values())
    if not is_founder:
        formal_groups = {
            key: [
                _selection_for_member(item, founder=False)
                for item in (items or [])
                if isinstance(item, dict)
            ]
            for key, items in formal_groups.items()
        }
    moneyline = _free_pick_for_member(moneyline, founder=is_founder)
    if isinstance(moneyline, dict) and public_record:
        moneyline["result"] = _record_result_payload(public_record)
    watchlist_count = sum(len(items or []) for items in watchlist.values()) if is_founder else 0
    recommendation_status = (
        "formal_published"
        if formal_count
        else "founder_watchlist_only"
        if is_founder and watchlist_count
        else "no_recommendation"
    )
    if formal_count:
        message = "今日正式 Pro 推薦已載入。"
    elif is_founder and watchlist_count:
        message = "今日無正式 Pro 推薦；目前有創辦人內部觀察候選。"
    else:
        message = "今日沒有玩法通過正式發布門檻。"
        if is_founder and watchlist_message:
            message = watchlist_message

    candidate_counts = package.get("candidate_counts") if package else {}
    if not is_founder and isinstance(candidate_counts, dict):
        candidate_counts = {
            key: value
            for key, value in candidate_counts.items()
            if not str(key).startswith("watch_")
        }

    response = {
        "date": target_date.isoformat(),
        "published": bool(package or moneyline),
        "locked": bool(package),
        "member": {"role": member["role"], "has_pro_access": member["has_pro_access"]},
        "moneyline": moneyline,
        "pro_access": "granted" if member["has_pro_access"] else "locked",
        "recommendation_status": recommendation_status,
        "formal_recommendation_count": formal_count,
        "watchlist_count": watchlist_count,
        "message": message,
    }
    if member["has_pro_access"]:
        response.update(
            {
                "moneylines": formal_groups["moneylines"],
                "run_lines": formal_groups["run_lines"],
                "totals": formal_groups["totals"],
                "parlays": {
                    "two_leg": formal_groups["two_leg"],
                    "three_leg": formal_groups["three_leg"],
                },
                # V14-compatible aliases during the transition.
                "run_line": (formal_groups["run_lines"] or [None])[0],
                "total": (formal_groups["totals"] or [None])[0],
                "candidate_counts": candidate_counts,
                "thresholds": package.get("thresholds") if package else {},
                "limits": package.get("limits") if package else {},
                "publication": package.get("publication") if package else {},
                "settled": package.get("settled") if package else False,
                "results": package.get("results") if package else {},
            }
        )
        if is_founder:
            response["watchlist"] = watchlist
            response["watchlist_message"] = watchlist_message
    return response


class FounderPredictionPublish(BaseModel):
    date: date
    game_pk: int
    confirm_warning: bool = False


def founder_candidate(analysis: dict) -> dict:
    """Return the founder-facing publication policy for one matchup."""

    game = analysis.get("game") or {}
    context = str(game.get("season_context") or "unsupported")
    confidence = float(analysis.get("confidence") or 0)
    data_quality = float(analysis.get("data_quality") or 0)
    policy = publication_policy(analysis, automatic=False)
    return {
        "game_pk": analysis.get("game_pk"),
        "matchup": analysis.get("matchup"),
        "time_taiwan": analysis.get("time_taiwan"),
        "venue": game.get("venue"),
        "event": {
            "game_type": game.get("game_type"),
            "context": context,
            "label": game.get("event_label") or "例行賽",
            "special": bool(game.get("special_event")),
        },
        "pick": analysis.get("pick"),
        "confidence": confidence,
        "data_quality": data_quality,
        "warnings": policy["warnings"],
        "blockers": policy["blockers"],
        "can_publish": policy["can_publish"],
        "auto_publish_ready": policy["auto_publish_ready"],
        "requires_confirmation": policy["requires_confirmation"],
        "timing": policy["timing"],
        "checklist": policy["checklist"],
        "roster_validation": policy["roster_validation"],
        "lineup_validation_rate": policy["lineup_validation_rate"],
        "updated_at": (analysis.get("data_freshness") or {}).get("generated_at"),
    }


@app.get(f"{settings.api_prefix}/admin/predictions/candidates")
async def founder_prediction_candidates(
    request: Request,
    prediction_date: date | None = Query(default=None, alias="date"),
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    await admin_member(request, authorization)
    target_date = requested_date(prediction_date)
    repository = records_repository(request)
    if not repository.enabled:
        raise HTTPException(status_code=503, detail="Recommendation database is not configured")
    try:
        existing = await repository.get_record_for_date(target_date.isoformat())
    except RecordsStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    if existing:
        return {
            "date": target_date.isoformat(),
            "locked": True,
            "selection": existing.get("prediction_snapshot"),
            "items": [],
            "message": "今日正式推薦已鎖定，不能再更換場次。",
        }

    try:
        analyses = await service(request).matchup_analyses(target_date, pitcher_limit=None)
    except MLBUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    items = [founder_candidate(item) for item in analyses.get("items") or []]
    items.sort(key=lambda item: item["confidence"], reverse=True)
    return {
        "date": target_date.isoformat(),
        "locked": False,
        "items": items,
        "count": len(items),
        "message": analyses.get("message") or "候選場次已載入。",
    }


@app.post(f"{settings.api_prefix}/admin/predictions/publish")
async def founder_publish_prediction(
    request: Request,
    command: FounderPredictionPublish,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    await admin_member(request, authorization)
    repository = records_repository(request)
    if not repository.enabled:
        raise HTTPException(status_code=503, detail="Recommendation database is not configured")
    try:
        existing = await repository.get_record_for_date(command.date.isoformat())
    except RecordsStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    if existing:
        raise HTTPException(status_code=409, detail="今日正式推薦已鎖定，不能再更換場次。")

    try:
        analyses = await service(request).matchup_analyses(command.date, pitcher_limit=None)
    except MLBUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    selection = next(
        (item for item in analyses.get("items") or [] if item.get("game_pk") == command.game_pk),
        None,
    )
    if selection is None:
        raise HTTPException(status_code=404, detail="找不到這場尚未開賽的候選賽事。")

    policy = founder_candidate(selection)
    if not policy["can_publish"]:
        raise HTTPException(
            status_code=422,
            detail={"message": "這場比賽目前不可正式發布。", "blockers": policy["blockers"]},
        )
    if policy["requires_confirmation"] and not command.confirm_warning:
        raise HTTPException(
            status_code=409,
            detail={"message": "這場比賽需要創辦人再次確認。", "warnings": policy["warnings"]},
        )

    selection = {
        **selection,
        "publication": {
            "mode": "founder_selected",
            "special_event": policy["event"]["special"],
            "event_label": policy["event"]["label"],
            "warnings_confirmed": bool(policy["warnings"]),
        },
    }
    try:
        stored, created = await repository.publish_prediction_once(
            command.date.isoformat(), selection
        )
    except RecordsStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    if not created:
        raise HTTPException(status_code=409, detail="另一筆正式推薦已先完成鎖定。")
    try:
        await performance_repository(request).capture_public(command.date.isoformat(), str(stored.get("id")), selection)
    except PerformanceStorageError:
        pass
    return {
        "ok": True,
        "date": command.date.isoformat(),
        "locked": True,
        "created": True,
        "selection": stored.get("prediction_snapshot") or selection,
        "message": "創辦人指定場次已正式發布並鎖定。",
    }


class FounderMarketPublish(BaseModel):
    date: date
    moneylines: list[str] = Field(default_factory=list)
    run_lines: list[str] = Field(default_factory=list)
    totals: list[str] = Field(default_factory=list)
    two_leg: list[str] = Field(default_factory=list)
    three_leg: list[str] = Field(default_factory=list)


def _npb_analysis_for_markets(game: dict, analysis: dict) -> dict:
    groups = analysis.get("analysis_groups") or {}
    normalized_groups = {
        "team_strength": groups.get("team") or {},
        "starter": groups.get("starter") or {},
        "lineup": groups.get("offense") or {},
        "bullpen": groups.get("bullpen") or {},
        "advanced": {
            "available": False,
            "quality": 0.0,
            "metrics": [],
            "note": "NPB 尚未提供 Statcast 同級資料",
        },
        "environment": {
            "available": False,
            "quality": 0.0,
            "metrics": [],
            "note": "NPB 環境模型將於後續版本加入",
        },
    }
    away = game.get("away") or {}
    home = game.get("home") or {}
    return {
        "league": "NPB",
        "game": game,
        "game_pk": str(game.get("game_pk") or game.get("external_game_id") or ""),
        "matchup": f'{away.get("abbr") or away.get("name")} @ {home.get("abbr") or home.get("name")}',
        "game_date": game.get("game_date") or game.get("date"),
        "time_taiwan": game.get("time_taiwan"),
        "home_probability": analysis.get("home_probability"),
        "away_probability": analysis.get("away_probability"),
        "confidence": analysis.get("confidence"),
        "data_quality": analysis.get("data_quality"),
        "projections": analysis.get("projections") or {},
        "analysis_groups": normalized_groups,
        "engine": {
            "weights": {
                "team_strength": 0.28,
                "starter": 0.32,
                "lineup": 0.24,
                "bullpen": 0.16,
                "advanced": 0.0,
                "environment": 0.0,
            }
        },
        "factors": [],
        "model_version": analysis.get("model_version") or "dm-npb-markets-v1.1",
    }


async def npb_market_candidates_for_date(
    request: Request,
    target_date: date,
    odds_items: list[dict] | None = None,
) -> list[dict]:
    try:
        schedule = await npb_service(request).games_for_date(target_date)
    except NPBUpstreamError:
        return []
    games = [
        item
        for item in schedule.get("items") or []
        if str(item.get("status") or "").lower() in {"upcoming", "scheduled", "preview"}
        and all(((item.get(side) or {}).get("probable_pitcher") or {}).get("announced") is True for side in ("away", "home"))
    ]
    available_odds = odds_items or []

    async def build(game: dict) -> list[dict]:
        try:
            detail = await npb_service(request).game_detail(str(game.get("game_pk")))
        except NPBUpstreamError:
            return []
        detail_game = detail.get("game") or game
        raw_analysis = detail.get("analysis") or {}
        if raw_analysis.get("official_recommendation_enabled") is not True:
            return []
        market_analysis = _npb_analysis_for_markets(detail_game, raw_analysis)
        event = match_odds_event(market_analysis, available_odds)
        selections: list[dict] = []
        real_moneyline = None
        if event:
            real_moneyline = moneyline_candidate(
                market_analysis,
                event,
                minimum_probability=max(56.0, settings.min_market_probability),
                minimum_edge=max(1.5, settings.min_market_edge / 2.0),
            )
            run_line = run_line_candidate(
                market_analysis,
                event,
                minimum_probability=settings.min_market_probability,
                minimum_edge=settings.min_market_edge,
                minimum_projection_quality=settings.min_projection_quality,
            )
            total = totals_candidate(
                market_analysis,
                event,
                minimum_probability=settings.min_market_probability,
                minimum_edge=settings.min_market_edge,
                minimum_projection_quality=settings.min_projection_quality,
            )
            selections.extend(item for item in (real_moneyline, run_line, total) if item)
        if real_moneyline is None:
            fallback = model_only_moneyline_candidate(
                detail_game,
                raw_analysis,
                minimum_probability=56.0,
                minimum_data_quality=0.65,
            )
            if fallback:
                selections.append(fallback)
        return selections

    results = await asyncio.gather(*(build(game) for game in games), return_exceptions=True)
    return [
        selection
        for item in results
        if isinstance(item, list)
        for selection in item
        if isinstance(selection, dict)
    ]


async def npb_moneyline_candidates_for_date(request: Request, target_date: date) -> list[dict]:
    """Compatibility wrapper for integrations still requesting NPB moneylines only."""

    candidates = await npb_market_candidates_for_date(request, target_date, [])
    return [item for item in candidates if item.get("market") == "moneyline"]


async def founder_market_candidate_bundle(request: Request, target_date: date) -> dict:
    repository = records_repository(request)
    try:
        public_record = await repository.get_record_for_date(target_date.isoformat())
    except RecordsStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    public_selection = None
    if public_record and isinstance(public_record.get("prediction_snapshot"), dict):
        public_selection = public_record["prediction_snapshot"]

    if not odds_service(request).enabled:
        raise HTTPException(status_code=503, detail="真實盤口來源尚未設定，不能建立正式會員玩法。")
    try:
        feed = await odds_service(request).odds_for_date(target_date)
    except OddsUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    if not (feed.get("meta") or {}).get("fresh_for_model"):
        raise HTTPException(status_code=409, detail="目前只有過期備援盤口，不能發布新的正式會員玩法。")

    try:
        analyses = await service(request).matchup_analyses(target_date, pitcher_limit=None)
    except MLBUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    eligible = [
        item
        for item in analyses.get("items") or []
        if (item.get("game") or {}).get("auto_recommendation_eligible") is True
        and publication_policy(item, automatic=False)["can_publish"]
        and (((item.get("analysis_groups") or {}).get("starter") or {}).get("both_starters_ready") is True)
    ]
    bundle = build_daily_market_candidates(
        target_date.isoformat(),
        eligible,
        feed.get("items") or [],
        public_selection,
        minimum_probability=settings.min_market_probability,
        minimum_edge=settings.min_market_edge,
        minimum_projection_quality=settings.min_projection_quality,
        minimum_parlay_probability=settings.min_parlay_leg_probability,
    )
    npb_feed = {"items": [], "meta": {"fresh_for_model": False}}
    try:
        fetched_npb_feed = await odds_service(request).odds_for_date(
            target_date,
            sport_key=settings.npb_odds_sport_key,
        )
        npb_feed = fetched_npb_feed
    except OddsUpstreamError:
        pass
    npb_candidates = await npb_market_candidates_for_date(
        request,
        target_date,
        (npb_feed.get("items") or [])
        if (npb_feed.get("meta") or {}).get("fresh_for_model")
        else [],
    )
    bundle = merge_market_candidates(
        bundle,
        npb_candidates,
        minimum_parlay_probability=settings.min_parlay_leg_probability,
    )
    bundle.setdefault("odds_feeds", {})["NPB"] = {
        "sport_key": settings.npb_odds_sport_key,
        "count": int(npb_feed.get("count") or 0),
        "fresh_for_model": bool((npb_feed.get("meta") or {}).get("fresh_for_model")),
        "cache": (npb_feed.get("meta") or {}).get("cache"),
    }
    league_counts = (bundle.get("candidate_counts") or {}).get("by_league") or {}
    bundle["league_status"] = {
        "MLB": {
            "enabled": True,
            "formal": int((league_counts.get("MLB") or {}).get("total") or 0),
            "markets": league_counts.get("MLB") or {},
        },
        "NPB": {
            "enabled": True,
            "formal": int((league_counts.get("NPB") or {}).get("total") or 0),
            "markets": league_counts.get("NPB") or {},
            "real_odds": bool((npb_feed.get("meta") or {}).get("fresh_for_model")),
        },
        "KBO": {"enabled": False, "status": "planned"},
        "CPBL": {"enabled": False, "status": "planned"},
    }
    return bundle


@app.get(f"{settings.api_prefix}/admin/markets/candidates")
async def founder_market_candidates(
    request: Request,
    prediction_date: date | None = Query(default=None, alias="date"),
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    await admin_member(request, authorization)
    target_date = requested_date(prediction_date)
    repository = records_repository(request)
    if not repository.enabled:
        raise HTTPException(status_code=503, detail="Recommendation database is not configured")
    try:
        existing = await repository.get_prediction_package_for_date(target_date.isoformat())
    except RecordsStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    if existing:
        existing_package = package_from_record(existing)
        existing_mode = str((existing_package.get("publication") or {}).get("mode") or "")
        if existing_mode != "ai_auto":
            return {
                "date": target_date.isoformat(),
                "locked": True,
                "package": existing_package,
                "message": "今日會員玩法已鎖定，不能再更換。",
            }
    bundle = await founder_market_candidate_bundle(request, target_date)
    return {
        **bundle,
        "locked": False,
        "message": "MLB／NPB 跨聯盟候選已載入；所有通過門檻的單場正式候選會由 AI 全部預選，觀察名單仍需創辦人確認。",
    }


@app.post(f"{settings.api_prefix}/admin/markets/publish")
async def founder_publish_markets(
    request: Request,
    command: FounderMarketPublish,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    await admin_member(request, authorization)
    repository = records_repository(request)
    if not repository.enabled:
        raise HTTPException(status_code=503, detail="Recommendation database is not configured")
    try:
        existing = await repository.get_prediction_package_for_date(command.date.isoformat())
    except RecordsStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    replace_auto_placeholder = False
    if existing:
        existing_package = package_from_record(existing)
        existing_mode = str((existing_package.get("publication") or {}).get("mode") or "")
        if existing_mode == "ai_auto":
            replace_auto_placeholder = True
        else:
            raise HTTPException(status_code=409, detail="今日會員玩法已鎖定，不能再更換。")

    bundle = await founder_market_candidate_bundle(request, command.date)
    selected = {
        "moneylines": command.moneylines,
        "run_lines": command.run_lines,
        "totals": command.totals,
        "two_leg": command.two_leg,
        "three_leg": command.three_leg,
    }
    try:
        package = build_selected_market_package(
            bundle,
            selected,
            publication_mode="founder_selected",
        )
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    if not package.get("published"):
        raise HTTPException(status_code=422, detail="至少選擇一個通過門檻的會員玩法後才能發布。")
    try:
        if replace_auto_placeholder:
            stored = await repository.replace_prediction_package(
                command.date.isoformat(), package
            )
            created = True
        else:
            stored, created = await repository.publish_prediction_package_once(
                command.date.isoformat(), package
            )
    except RecordsStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    if not created:
        raise HTTPException(status_code=409, detail="另一筆會員玩法已先完成鎖定。")
    try:
        await performance_repository(request).capture_package(command.date.isoformat(), str(stored.get("id")), package)
    except PerformanceStorageError:
        pass
    locked = package_from_record(stored)
    return {
        "ok": True,
        "date": command.date.isoformat(),
        "locked": True,
        "package": locked,
        "message": "創辦人選擇的會員玩法已正式發布並永久鎖定；創辦人指定項目會與 AI 正式推薦分開標記。",
    }


@app.post(f"{settings.api_prefix}/jobs/settlement")
async def settlement_job(
    request: Request,
    cron_secret: str | None = Header(default=None, alias="X-DiamondMind-Cron"),
) -> Response:
    """Settle formal records and run operational anomaly checks.

    The same cron-job.org request now performs two independent duties:
    settlement and low-cost monitoring. A critical anomaly returns HTTP 503 so
    cron-job.org sends the configured failure email. Warnings remain HTTP 200
    and are visible in the JSON/admin monitor without causing alert spam.
    """
    if not settings.scheduler_enabled:
        raise HTTPException(status_code=503, detail="Settlement scheduler secret is not configured")
    if not cron_secret_matches(cron_secret, settings.cron_secret):
        raise HTTPException(status_code=401, detail="Invalid scheduler credentials")
    if not settings.records_enabled:
        raise HTTPException(status_code=503, detail="Recommendation records database is not configured")

    source_probe_task = asyncio.create_task(
        probe_league_sources(service(request), npb_service(request), datetime.now(TAIPEI).date()),
        name="diamondmind-operations-source-probe",
    )
    try:
        free_count = await settle_pending_records(request)
        package_count = await settle_pending_prediction_packages(request)
    except RecordsStorageError as exc:
        source_probe_task.cancel()
        with suppress(asyncio.CancelledError):
            await source_probe_task
        raise HTTPException(status_code=503, detail=str(exc)) from exc

    try:
        source_probes = await asyncio.wait_for(
            source_probe_task,
            timeout=max(15.0, settings.request_timeout_seconds * 2.0),
        )
    except TimeoutError:
        source_probes = {
            "MLB": {"ok": False, "error": "MonitorTimeout", "detail": "MLB official source probe timed out"},
            "NPB": {"ok": False, "error": "MonitorTimeout", "detail": "NPB official source probe timed out"},
        }

    try:
        monitor = await build_operations_report(
            repository=records_repository(request),
            odds=odds_service(request),
            source_probes=source_probes,
            failure_counters=request.app.state.operations_monitor_failures,
            settings=settings,
            now=datetime.now(TAIPEI),
        )
    except Exception as exc:
        monitor = {
            "ok": False,
            "status": "critical",
            "checked_at": datetime.now(TAIPEI).isoformat(),
            "checks": [],
            "warnings": [],
            "critical_issues": [{
                "key": "monitor_runtime",
                "label": "異常監控程式",
                "status": "critical",
                "detail": f"監控執行失敗：{type(exc).__name__}",
            }],
        }

    result = {
        "ok": bool(monitor.get("ok")),
        "time_taiwan": datetime.now(TAIPEI).isoformat(),
        "free_settled_now": free_count,
        "packages_settled_now": package_count,
        "settled_now": free_count + package_count,
        "odds_refreshed": False,
        "recommendations_published": False,
        "monitor": monitor,
    }
    request.app.state.settlement_status = {
        **result,
        "source": "external_settlement_job",
        "last_error": None if monitor.get("ok") else "operations_monitor_critical",
    }
    request.app.state.operations_monitor_status = monitor
    return JSONResponse(
        status_code=200 if monitor.get("ok") else 503,
        content=result,
    )


@app.post(f"{settings.api_prefix}/jobs/daily")
async def daily_job(
    request: Request,
    job_date: date | None = Query(default=None, alias="date", description="Taiwan date, YYYY-MM-DD"),
    cron_secret: str | None = Header(default=None, alias="X-DiamondMind-Cron"),
) -> dict:
    if not settings.scheduler_enabled:
        raise HTTPException(status_code=503, detail="Daily scheduler secret is not configured")
    if not cron_secret_matches(cron_secret, settings.cron_secret):
        raise HTTPException(status_code=401, detail="Invalid scheduler credentials")

    target_date = requested_date(job_date)
    try:
        prediction = await prediction_with_persistence(request, target_date)
    except MLBUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc

    settlement = {"enabled": settings.records_enabled, "settled_now": 0}
    if settings.records_enabled:
        try:
            settlement["settled_now"] = await settle_pending_records(request)
            settlement["packages_settled_now"] = await settle_pending_prediction_packages(request)
        except RecordsStorageError:
            settlement["message"] = "紀錄資料庫暫時無法執行結算。"

    odds = odds_service(request).status()
    market_package = {
        "date": target_date.isoformat(),
        "published": False,
        "message": "真實盤口尚未提供，會員玩法不會使用猜測資料。",
    }
    if odds_service(request).enabled:
        try:
            feed = await odds_service(request).odds_for_date(target_date)
            odds.update(
                {
                    "available": True,
                    "count": feed["count"],
                    "cache": feed["meta"]["cache"],
                    "fresh_for_model": feed["meta"]["fresh_for_model"],
                    "quota": feed["meta"]["quota"],
                }
            )
            if feed["meta"]["fresh_for_model"]:
                market_package = await locked_or_generated_market_package(
                    request, target_date, prediction, feed, persist=False
                )
            else:
                market_package["message"] = "目前只有過期備援盤口，不發布新的正式玩法。"
        except OddsUpstreamError:
            # A temporary odds incident must not prevent the independent
            # moneyline model or record settlement from completing.
            odds.update({"available": False, "message": "真實盤口來源暫時無法使用。"})
    else:
        odds["available"] = False

    return {
        "ok": True,
        "date": target_date.isoformat(),
        "time_taiwan": datetime.now(TAIPEI).isoformat(),
        "prediction": prediction,
        "market_package": market_package,
        "settlement": settlement,
        "odds": odds,
    }


@app.get(f"{settings.api_prefix}/records")
async def recommendation_records(
    request: Request,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    member = await optional_member(request, authorization)
    repository = records_repository(request)
    if not repository.enabled:
        return {
            "items": [],
            "market_packages": [],
            "count": 0,
            "stats": summarize_records([]),
            "message": "推薦紀錄資料庫尚未設定。",
            "is_demo": False,
            "database": "not_configured",
            "member": {"role": member["role"], "has_pro_access": member["has_pro_access"]},
            "pro_history_locked": not member["has_pro_access"],
            "performance_access": member.get("role") == "admin",
        }

    try:
        settled_now = await settle_pending_records(request)
        packages_settled_now = await settle_pending_prediction_packages(request)
        items = await repository.list_records()
        prediction_packages = await repository.list_prediction_packages()
    except RecordsStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc

    # Pro history is membership content. Free visitors receive only the
    # public daily free-pick record. Paid members receive every locked formal
    # package immediately, with each completed selection settling independently.
    today_taiwan = datetime.now(TAIPEI).date().isoformat()
    visible_prediction_packages: list[dict] = []
    for item in prediction_packages:
        recommendation_date = str(item.get("recommendation_date") or "")
        if recommendation_date and recommendation_date > today_taiwan:
            # The records page is history, never a preview of a future slate.
            continue
        package = package_from_record(item)
        publication_mode = str((package.get("publication") or {}).get("mode") or "")
        if publication_mode == "ai_auto":
            # V18.7 and earlier could persist scheduler candidates without
            # founder approval. Those placeholders are not formal records.
            continue
        visible_prediction_packages.append(package)

    market_packages = visible_prediction_packages if member.get("has_pro_access") else []
    if member.get("role") != "admin":
        # Public free-pick history never exposes the five-engine snapshot.
        items = [
            _strip_member_financials(deepcopy(item))
            for item in items
        ]
        for item in items:
            if isinstance(item.get("prediction_snapshot"), dict):
                item["prediction_snapshot"] = _free_pick_for_member(item["prediction_snapshot"])

        market_packages = [
            _strip_member_financials(package)
            for package in market_packages
        ]

        # Historical Pro packages may persist founder watchlist snapshots in
        # the database. Strip them at the API boundary so paid members cannot
        # recover internal candidates or internal publication notes through
        # browser developer tools.
        for package in market_packages:
            package.pop("watchlist", None)
            for group in ("moneylines", "run_lines", "totals"):
                package[group] = [
                    _selection_for_member(selection, founder=False)
                    for selection in (package.get(group) or [])
                    if isinstance(selection, dict)
                ]
            parlays = package.get("parlays") or {}
            package["parlays"] = {
                "two_leg": [
                    _selection_for_member(selection, founder=False)
                    for selection in (parlays.get("two_leg") or [])
                    if isinstance(selection, dict)
                ],
                "three_leg": [
                    _selection_for_member(selection, founder=False)
                    for selection in (parlays.get("three_leg") or [])
                    if isinstance(selection, dict)
                ],
            }
            if isinstance(package.get("moneyline"), dict):
                package["moneyline"] = _free_pick_for_member(package["moneyline"])
            counts = package.get("candidate_counts")
            if isinstance(counts, dict):
                package["candidate_counts"] = {
                    key: value
                    for key, value in counts.items()
                    if not str(key).startswith("watch_")
                }
            if package.get("recommendation_status") in {
                "watchlist_only", "founder_watchlist_only"
            }:
                package["recommendation_status"] = "no_recommendation"
            formal_total = sum(
                len(items or [])
                for items in (
                    package.get("moneylines"),
                    package.get("run_lines"),
                    package.get("totals"),
                    (package.get("parlays") or {}).get("two_leg"),
                    (package.get("parlays") or {}).get("three_leg"),
                )
            )
            package["message"] = (
                "正式玩法已鎖定。"
                if formal_total
                else "此日期沒有正式 Pro 推薦。"
            )

    pro_performance = None
    if member.get("role") == "admin":
        try:
            pro_performance = await performance_repository(request).records_performance(days=None)
        except PerformanceStorageError:
            # Recommendation history remains available even when the auxiliary
            # performance snapshot store is temporarily unavailable.
            pro_performance = None

    return {
        "items": items,
        "market_packages": market_packages,
        "pro_performance": pro_performance,
        "count": len(items),
        "stats": summarize_records(items),
        "message": "尚無正式推薦紀錄。" if not items else "正式推薦紀錄已載入。",
        "is_demo": False,
        "database": "connected",
        "settled_now": settled_now,
        "packages_settled_now": packages_settled_now,
        "member": {"role": member["role"], "has_pro_access": member["has_pro_access"]},
        "pro_history_locked": not member["has_pro_access"],
        "performance_access": member.get("role") == "admin",
    }
