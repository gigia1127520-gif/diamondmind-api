from __future__ import annotations

import asyncio
from contextlib import asynccontextmanager, suppress
from datetime import date, datetime, timedelta
from secrets import compare_digest
from zoneinfo import ZoneInfo

from fastapi import FastAPI, Header, HTTPException, Query, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from .config import settings
from .auth import MemberAccessError, SupabaseMemberAuth
from .markets import (
    build_daily_market_candidates,
    build_daily_market_package,
    build_selected_market_package,
)
from .mlb import MLBService, MLBUpstreamError
from .odds import OddsService, OddsUpstreamError
from .validation import game_timing, iso_utc
from .records import (
    RecordsStorageError,
    SupabaseRecordsRepository,
    package_from_record,
    settlement_for,
    settle_prediction_package,
    summarize_records,
)


TAIPEI = ZoneInfo("Asia/Taipei")


@asynccontextmanager
async def lifespan(app: FastAPI):
    service = MLBService(settings)
    odds = OddsService(settings)
    records = SupabaseRecordsRepository(settings)
    member_auth = SupabaseMemberAuth(settings)
    app.state.mlb = service
    app.state.odds = odds
    app.state.records = records
    app.state.member_auth = member_auth
    app.state.pregame_status = {"running": True, "last_run": None, "last_error": None}
    monitor_task = asyncio.create_task(_pregame_refresh_loop(app), name="diamondmind-pregame-refresh")
    app.state.pregame_task = monitor_task
    yield
    monitor_task.cancel()
    with suppress(asyncio.CancelledError):
        await monitor_task
    await service.aclose()
    await odds.aclose()
    await records.aclose()
    await member_auth.aclose()


app = FastAPI(
    title="DiamondMind API",
    version="16.6.0",
    description="MLB five-module analysis with server-side Pro access protection, roster validation, freshness and pregame publication safety gates.",
    lifespan=lifespan,
)

allow_all = "*" in settings.cors_origins
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"] if allow_all else settings.cors_origins,
    allow_credentials=not allow_all,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["*"],
)


def service(request: Request) -> MLBService:
    return request.app.state.mlb


def records_repository(request: Request) -> SupabaseRecordsRepository:
    return request.app.state.records


def odds_service(request: Request) -> OddsService:
    return request.app.state.odds


def member_auth_service(request: Request) -> SupabaseMemberAuth:
    return request.app.state.member_auth


def bearer_token(authorization: str | None) -> str | None:
    if authorization and authorization.lower().startswith("bearer "):
        return authorization[7:].strip()
    return None


async def authenticated_member(request: Request, authorization: str | None) -> dict:
    try:
        return await member_auth_service(request).member(bearer_token(authorization))
    except MemberAccessError as exc:
        raise HTTPException(status_code=401, detail=str(exc)) from exc


async def optional_member(request: Request, authorization: str | None) -> dict:
    """Return guest access when no bearer token is supplied.

    An invalid or expired token is still rejected so the browser can clear the
    stale session instead of silently treating it as a valid free account.
    """

    token = bearer_token(authorization)
    if not token:
        return {"id": None, "email": None, "role": "guest", "has_pro_access": False}
    try:
        return await member_auth_service(request).member(token)
    except MemberAccessError as exc:
        raise HTTPException(status_code=401, detail=str(exc)) from exc


def _public_team_snapshot(team: dict | None) -> dict:
    team = team or {}
    pitcher = team.get("probable_pitcher") or {}
    return {
        "id": team.get("id"),
        "name": team.get("name"),
        "abbr": team.get("abbr"),
        "score": team.get("score"),
        "probable_pitcher": {
            "id": pitcher.get("id"),
            "name": pitcher.get("name") or "尚未公布",
        },
    }


def locked_game_detail(detail: dict, member: dict) -> dict:
    """Whitelist the only matchup fields available without Pro access.

    Never return the analysis object and then rely on CSS to hide it. This
    response deliberately omits lineups, bullpen, weather, Statcast, model pick,
    confidence, completeness, sources and every five-engine metric.
    """

    game = detail.get("game") or {}
    public_game = {
        key: game.get(key)
        for key in (
            "game_pk", "game_date", "date_taiwan", "time_taiwan", "status",
            "detailed_status", "inning", "inning_state", "venue_id", "venue",
            "game_type", "season_context", "event_label", "is_special_event",
        )
        if key in game
    }
    public_game["away"] = _public_team_snapshot(game.get("away"))
    public_game["home"] = _public_team_snapshot(game.get("home"))
    return {
        "game": public_game,
        "analysis_locked": True,
        "access": {
            "role": member.get("role") or "guest",
            "has_pro_access": False,
            "required_plan": "pro",
        },
        "locked_modules": [
            "starter", "lineup", "bullpen", "environment", "advanced",
        ],
        "message": "升級 Pro 解鎖完整賽事情報。",
        "meta": {
            "source": "MLB Stats API",
            "updated_at": (detail.get("meta") or {}).get("updated_at"),
            "analysis_payload_returned": False,
        },
    }


async def admin_member(request: Request, authorization: str | None) -> dict:
    member = await authenticated_member(request, authorization)
    if member.get("role") != "admin":
        raise HTTPException(status_code=403, detail="Founder access is required")
    return member


def requested_date(value: date | None) -> date:
    return value or datetime.now(TAIPEI).date()


def cron_secret_matches(provided: str | None, configured: str) -> bool:
    """Constant-time comparison for the server-to-server scheduler secret."""

    if not provided or not configured:
        return False
    return compare_digest(provided.encode("utf-8"), configured.encode("utf-8"))



def publication_policy(analysis: dict, *, automatic: bool = False, now: datetime | None = None) -> dict:
    game = analysis.get("game") or {}
    context = str(game.get("season_context") or "unsupported")
    confidence = float(analysis.get("confidence") or 0)
    data_quality = float(analysis.get("data_quality") or 0)
    timing = analysis.get("timing") or game_timing(
        game,
        now=now,
        lineup_watch_minutes=settings.pregame_lineup_watch_minutes,
        final_lock_minutes=settings.pregame_final_lock_minutes,
    )
    validation = analysis.get("roster_validation") or {}
    validation_overall = validation.get("overall") or {}
    lineups = validation.get("lineups") or {}
    lineup_rates = [
        float((lineups.get(side) or {}).get("validation_rate") or 0)
        for side in ("away", "home")
    ]
    lineup_rate = min(lineup_rates) if lineup_rates else 0.0
    starter_group = ((analysis.get("analysis_groups") or {}).get("starter") or {})
    blockers: list[str] = []
    warnings: list[str] = []

    if str(game.get("status") or "upcoming") != "upcoming" or timing.get("stage") == "started":
        blockers.append("比賽已開始或不再接受賽前發布。")
    if context not in {"regular_season", "postseason"}:
        blockers.append(f"{game.get('event_label') or '特殊賽事'}專用模型尚未啟用，不能套用一般模型正式發布。")
    if data_quality < settings.minimum_publish_data_quality:
        blockers.append(f"整體資料完整度不足 {settings.minimum_publish_data_quality * 100:.0f}%。")
    if starter_group.get("both_starters_ready") is not True:
        blockers.append("兩隊先發投手、投手數據或名單驗證尚未達正式發布標準。")
    if validation_overall.get("status") == "mismatch":
        blockers.append("球員與球隊身分驗證發現不一致，需重新整理後再確認。")
    if lineup_rate < settings.minimum_lineup_validation_rate:
        blockers.append(f"打線名單驗證率不足 {settings.minimum_lineup_validation_rate * 100:.0f}%。")
    if confidence < settings.min_confidence:
        message = f"模型信心 {confidence:.1f}% 低於門檻 {settings.min_confidence:.1f}%。"
        if automatic:
            blockers.append(message)
        else:
            warnings.append(message)
    if timing.get("stage") == "preview":
        warnings.append("目前仍是賽前預覽階段；先發、打線或盤口後續可能變動。")
    elif timing.get("stage") == "lineup_watch":
        warnings.append("已進入開賽前 90 分鐘監控階段；系統會持續重新分析正式打線。")
    if context == "postseason":
        warnings.append("季後賽請再確認輪值、休息天數與系列賽狀況。")

    can_publish = not blockers
    auto_ready = can_publish and timing.get("stage") == "final_lock" and confidence >= settings.min_confidence
    return {
        "can_publish": can_publish,
        "auto_publish_ready": auto_ready,
        "requires_confirmation": bool(warnings),
        "blockers": blockers,
        "warnings": warnings,
        "timing": timing,
        "lineup_validation_rate": round(lineup_rate, 3),
        "roster_validation": validation_overall,
        "checklist": {
            "game_not_started": timing.get("stage") != "started",
            "supported_event": context in {"regular_season", "postseason"},
            "both_starters_confirmed": starter_group.get("both_starters_ready") is True,
            "data_quality_passed": data_quality >= settings.minimum_publish_data_quality,
            "lineup_validation_passed": lineup_rate >= settings.minimum_lineup_validation_rate,
            "roster_validation_passed": validation_overall.get("status") != "mismatch",
            "confidence_passed": confidence >= settings.min_confidence,
            "final_lock_window": timing.get("stage") == "final_lock",
        },
    }


async def _pregame_refresh_loop(app: FastAPI) -> None:
    """Refresh analyses throughout the day and auto-lock only the daily top pick.

    It uses no additional API key or environment variable. On platforms that
    suspend idle services, the normal page/API request still performs the same
    live analysis; this loop is an in-process acceleration and safety fallback.
    """

    await asyncio.sleep(20)
    while True:
        try:
            now = datetime.now(TAIPEI)
            summaries = []
            for target_date in (now.date(), (now + timedelta(days=1)).date()):
                analyses = await app.state.mlb.matchup_analyses(target_date, pitcher_limit=None)
                items = analyses.get("items") or []
                summaries.append({"date": target_date.isoformat(), "games": len(items)})
                if app.state.records.enabled:
                    existing = await app.state.records.get_record_for_date(target_date.isoformat())
                    if not existing:
                        eligible = []
                        for item in items:
                            policy = publication_policy(item, automatic=True, now=now)
                            if policy["can_publish"] and float(item.get("confidence") or 0) >= settings.min_confidence:
                                eligible.append((item, policy))
                        if eligible:
                            top_item, top_policy = max(eligible, key=lambda row: float(row[0].get("confidence") or 0))
                            if top_policy["auto_publish_ready"]:
                                selection = {
                                    **top_item,
                                    "publication": {
                                        "mode": "pregame_auto_final",
                                        "locked_at": iso_utc(),
                                        "timing": top_policy["timing"],
                                        "checklist": top_policy["checklist"],
                                    },
                                }
                                await app.state.records.publish_prediction_once(target_date.isoformat(), selection)
            app.state.pregame_status = {
                "running": True,
                "last_run": iso_utc(),
                "last_error": None,
                "interval_seconds": settings.pregame_refresh_interval_seconds,
                "dates": summaries,
            }
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # background loop must never stop the API
            app.state.pregame_status = {
                "running": True,
                "last_run": iso_utc(),
                "last_error": type(exc).__name__,
                "interval_seconds": settings.pregame_refresh_interval_seconds,
            }
        await asyncio.sleep(max(300, settings.pregame_refresh_interval_seconds))


def locked_prediction_from_record(
    prediction_date: date,
    record: dict,
) -> dict | None:
    snapshot = record.get("prediction_snapshot")
    if not isinstance(snapshot, dict) or not snapshot:
        return None
    return {
        "date": prediction_date.isoformat(),
        "published": True,
        "locked": True,
        "selection": snapshot,
        "message": "今日正式推薦已鎖定，後續更新不會更換推薦內容。",
        "meta": {
            "locked": True,
            "record_id": record.get("id"),
            "published_at": record.get("published_at"),
            "model_version": snapshot.get("model_version"),
        },
        "persistence": {
            "enabled": True,
            "stored": True,
            "created": False,
            "locked": True,
            "record_id": record.get("id"),
        },
    }


async def prediction_with_persistence(
    request: Request,
    prediction_date: date,
    *,
    publish_if_eligible: bool = True,
) -> dict:
    repository = records_repository(request)
    lookup_message = None
    if repository.enabled:
        try:
            existing = await repository.get_record_for_date(prediction_date.isoformat())
            if existing:
                locked = locked_prediction_from_record(prediction_date, existing)
                if locked:
                    return locked
        except RecordsStorageError:
            # The model can still provide a result during a temporary database
            # incident, but it is clearly marked as not durably locked.
            lookup_message = "紀錄資料庫暫時無法確認今日鎖單。"

    result = await service(request).top_prediction(prediction_date)
    if result.get("published") and result.get("selection"):
        policy = publication_policy(result["selection"], automatic=True)
        if not policy["auto_publish_ready"]:
            result = {
                **result, "published": False, "selection": None,
                "candidate": result.get("selection"),
                "message": "模型已完成預覽；系統會在最高候選場次進入開賽前 30 分鐘最終鎖定窗後自動發布。",
                "publication_policy": policy,
            }
    persistence = {"enabled": repository.enabled, "stored": False}
    if lookup_message:
        persistence["message"] = lookup_message
    if result.get("published") and not publish_if_eligible:
        # A normal page view must never become the action that locks the
        # official pick. Only the protected scheduler or the founder publish
        # endpoint is allowed to create the immutable public record.
        return {
            "date": prediction_date.isoformat(),
            "published": False,
            "locked": False,
            "selection": None,
            "message": "今日正式推薦尚未發布；將由固定排程自動發布，或由創辦人提前指定。",
            "meta": {
                **(result.get("meta") or {}),
                "publication_status": "pending",
            },
            "persistence": persistence,
        }
    if result.get("published") and repository.enabled:
        try:
            stored, created = await repository.publish_prediction_once(
                result["date"], result["selection"]
            )
            persistence.update(
                {
                    "stored": True,
                    "created": created,
                    "locked": True,
                    "record_id": stored.get("id"),
                }
            )
            if not created:
                locked = locked_prediction_from_record(prediction_date, stored)
                if locked:
                    return locked
        except RecordsStorageError:
            # Prediction remains available even if the records database has a
            # temporary incident. It can be requested again to retry the upsert.
            persistence["message"] = "推薦已產生，但紀錄資料庫暫時無法寫入。"
    result["persistence"] = persistence
    return result


async def settle_pending_records(request: Request) -> int:
    repository = records_repository(request)
    if not repository.enabled:
        return 0

    pending = await repository.list_records(status="pending")
    settled_now = 0
    for record in pending:
        try:
            game = await service(request).game_result(int(record["game_pk"]))
        except (KeyError, MLBUpstreamError, TypeError, ValueError):
            continue
        result = settlement_for(record, game)
        if result and await repository.settle(int(record["game_pk"]), result):
            settled_now += 1
    return settled_now


def _package_game_ids(record: dict) -> set[int]:
    ids: set[int] = set()
    package = package_from_record(record)
    for key in ("moneylines", "run_lines", "totals"):
        for selection in package.get(key) or []:
            try:
                ids.add(int(selection.get("game_pk")))
            except (TypeError, ValueError):
                pass
    for key in ("two_leg", "three_leg"):
        for parlay in (package.get("parlays") or {}).get(key) or []:
            for leg in parlay.get("legs") or []:
                try:
                    ids.add(int(leg.get("game_pk")))
                except (TypeError, ValueError):
                    pass
    return ids


async def settle_pending_prediction_packages(request: Request) -> int:
    repository = records_repository(request)
    if not repository.enabled:
        return 0
    pending = await repository.list_pending_prediction_packages()
    settled_now = 0
    for record in pending:
        games: dict[int, dict] = {}
        for game_pk in _package_game_ids(record):
            try:
                games[game_pk] = await service(request).game_result(game_pk)
            except (KeyError, MLBUpstreamError):
                continue
        result = settle_prediction_package(record, games)
        if result and await repository.settle_prediction_package(str(record["id"]), result):
            settled_now += 1
    return settled_now


async def locked_or_generated_market_package(
    request: Request,
    target_date: date,
    public_prediction: dict,
    odds_feed: dict,
) -> dict:
    repository = records_repository(request)
    if repository.enabled:
        try:
            existing = await repository.get_prediction_package_for_date(target_date.isoformat())
            if existing:
                return package_from_record(existing)
        except RecordsStorageError:
            existing = None

    analyses = await service(request).matchup_analyses(target_date, pitcher_limit=None)
    eligible_analyses = [
        item
        for item in analyses["items"]
        if (item.get("game") or {}).get("auto_recommendation_eligible") is True
        and publication_policy(item, automatic=False)["can_publish"]
        and (((item.get("analysis_groups") or {}).get("starter") or {}).get("both_starters_ready") is True)
    ]
    package = build_daily_market_package(
        target_date.isoformat(),
        eligible_analyses,
        odds_feed.get("items") or [],
        public_prediction.get("selection") if public_prediction.get("published") else None,
        minimum_probability=settings.min_market_probability,
        minimum_edge=settings.min_market_edge,
        minimum_projection_quality=settings.min_projection_quality,
        minimum_parlay_probability=settings.min_parlay_leg_probability,
    )
    package["persistence"] = {"enabled": repository.enabled, "stored": False}
    if package["published"] and repository.enabled:
        try:
            stored, created = await repository.publish_prediction_package_once(
                target_date.isoformat(), package
            )
            locked = package_from_record(stored)
            locked["persistence"] = {
                "enabled": True,
                "stored": True,
                "created": created,
                "record_id": stored.get("id"),
            }
            return locked
        except RecordsStorageError:
            package["persistence"]["message"] = "會員玩法已產生，但資料表尚未完成設定或暫時無法寫入。"
    return package


@app.get("/")
async def root() -> dict:
    return {
        "name": settings.app_name,
        "version": "16.6.0",
        "status": "online",
        "docs": "/docs",
        "health": f"{settings.api_prefix}/health",
    }


@app.get(f"{settings.api_prefix}/health")
async def health() -> dict:
    return {
        "ok": True,
        "service": settings.app_name,
        "version": "16.6.0",
        "environment": settings.app_env,
        "records_database": "configured" if settings.records_enabled else "not_configured",
        "odds_feed": "configured" if settings.odds_enabled else "not_configured",
        "daily_scheduler": "configured" if settings.scheduler_enabled else "not_configured",
        "pregame_refresh": "running",
        "time_taiwan": datetime.now(TAIPEI).isoformat(),
    }


@app.get(f"{settings.api_prefix}/odds/status")
async def odds_status(request: Request) -> dict:
    # This endpoint never calls the paid upstream service and never exposes its key.
    return odds_service(request).status()


@app.get(f"{settings.api_prefix}/advanced/status")
async def advanced_status(
    request: Request,
    season: int = Query(default=datetime.now(TAIPEI).year, ge=2015, le=2100),
) -> dict:
    """Public, non-sensitive Statcast source diagnostic."""
    return await service(request).statcast.diagnostics(season)


@app.get(f"{settings.api_prefix}/pregame/status")
async def pregame_status(request: Request) -> dict:
    return {
        **(getattr(request.app.state, "pregame_status", {}) or {}),
        "lineup_watch_minutes": settings.pregame_lineup_watch_minutes,
        "final_lock_minutes": settings.pregame_final_lock_minutes,
        "minimum_publish_data_quality": settings.minimum_publish_data_quality,
        "minimum_lineup_validation_rate": settings.minimum_lineup_validation_rate,
    }


@app.get(f"{settings.api_prefix}/mlb/games")
async def mlb_games(
    request: Request,
    game_date: date | None = Query(default=None, alias="date", description="Taiwan date, YYYY-MM-DD"),
) -> dict:
    try:
        return await service(request).games_for_date(requested_date(game_date))
    except MLBUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@app.get(f"{settings.api_prefix}/mlb/games/{{game_pk}}")
async def mlb_game_detail(
    request: Request,
    game_pk: int,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    member = await optional_member(request, authorization)
    try:
        detail = await service(request).game_detail(game_pk)
        if not member.get("has_pro_access"):
            return locked_game_detail(detail, member)
        return {
            **detail,
            "analysis_locked": False,
            "access": {
                "role": member.get("role"),
                "has_pro_access": True,
                "required_plan": "pro",
            },
        }
    except KeyError as exc:
        raise HTTPException(status_code=404, detail="Game not found") from exc
    except MLBUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@app.get(f"{settings.api_prefix}/predictions/top")
async def top_prediction(
    request: Request,
    prediction_date: date | None = Query(default=None, alias="date", description="Taiwan date, YYYY-MM-DD"),
) -> dict:
    try:
        return await prediction_with_persistence(
            request,
            requested_date(prediction_date),
            publish_if_eligible=False,
        )
    except MLBUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@app.get(f"{settings.api_prefix}/predictions/daily")
async def daily_predictions_for_member(
    request: Request,
    prediction_date: date | None = Query(default=None, alias="date", description="Taiwan date, YYYY-MM-DD"),
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    member = await authenticated_member(request, authorization)

    target_date = requested_date(prediction_date)
    repository = records_repository(request)
    try:
        stored = await repository.get_prediction_package_for_date(target_date.isoformat())
        public_record = await repository.get_record_for_date(target_date.isoformat())
    except RecordsStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc

    moneyline = None
    if stored:
        package = package_from_record(stored)
        moneyline = package.get("moneyline")
        if moneyline is None and public_record and isinstance(public_record.get("prediction_snapshot"), dict):
            moneyline = public_record["prediction_snapshot"]
    else:
        package = None
        if public_record and isinstance(public_record.get("prediction_snapshot"), dict):
            moneyline = public_record["prediction_snapshot"]

    response = {
        "date": target_date.isoformat(),
        "published": bool(package or moneyline),
        "locked": bool(package),
        "member": {"role": member["role"], "has_pro_access": member["has_pro_access"]},
        "moneyline": moneyline,
        "pro_access": "granted" if member["has_pro_access"] else "locked",
        "message": (
            "今日正式推薦已載入。"
            if package or moneyline
            else "今日尚未發布通過門檻的正式推薦。"
        ),
    }
    if member["has_pro_access"]:
        response.update(
            {
                "moneylines": package.get("moneylines") if package else [],
                "run_lines": package.get("run_lines") if package else [],
                "totals": package.get("totals") if package else [],
                "parlays": package.get("parlays") if package else {"two_leg": [], "three_leg": []},
                # V14-compatible aliases during the transition.
                "run_line": (package.get("run_lines") or [None])[0] if package else None,
                "total": (package.get("totals") or [None])[0] if package else None,
                "candidate_counts": package.get("candidate_counts") if package else {},
                "thresholds": package.get("thresholds") if package else {},
                "limits": package.get("limits") if package else {},
                "publication": package.get("publication") if package else {},
                "settled": package.get("settled") if package else False,
                "results": package.get("results") if package else {},
            }
        )
    return response


class FounderPredictionPublish(BaseModel):
    date: date
    game_pk: int
    confirm_warning: bool = False


def founder_candidate(analysis: dict) -> dict:
    """Return the founder-facing publication policy for one matchup."""

    game = analysis.get("game") or {}
    context = str(game.get("season_context") or "unsupported")
    confidence = float(analysis.get("confidence") or 0)
    data_quality = float(analysis.get("data_quality") or 0)
    policy = publication_policy(analysis, automatic=False)
    return {
        "game_pk": analysis.get("game_pk"),
        "matchup": analysis.get("matchup"),
        "time_taiwan": analysis.get("time_taiwan"),
        "venue": game.get("venue"),
        "event": {
            "game_type": game.get("game_type"),
            "context": context,
            "label": game.get("event_label") or "例行賽",
            "special": bool(game.get("special_event")),
        },
        "pick": analysis.get("pick"),
        "confidence": confidence,
        "data_quality": data_quality,
        "warnings": policy["warnings"],
        "blockers": policy["blockers"],
        "can_publish": policy["can_publish"],
        "auto_publish_ready": policy["auto_publish_ready"],
        "requires_confirmation": policy["requires_confirmation"],
        "timing": policy["timing"],
        "checklist": policy["checklist"],
        "roster_validation": policy["roster_validation"],
        "lineup_validation_rate": policy["lineup_validation_rate"],
        "updated_at": (analysis.get("data_freshness") or {}).get("generated_at"),
    }


@app.get(f"{settings.api_prefix}/admin/predictions/candidates")
async def founder_prediction_candidates(
    request: Request,
    prediction_date: date | None = Query(default=None, alias="date"),
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    await admin_member(request, authorization)
    target_date = requested_date(prediction_date)
    repository = records_repository(request)
    if not repository.enabled:
        raise HTTPException(status_code=503, detail="Recommendation database is not configured")
    try:
        existing = await repository.get_record_for_date(target_date.isoformat())
    except RecordsStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    if existing:
        return {
            "date": target_date.isoformat(),
            "locked": True,
            "selection": existing.get("prediction_snapshot"),
            "items": [],
            "message": "今日正式推薦已鎖定，不能再更換場次。",
        }

    try:
        analyses = await service(request).matchup_analyses(target_date, pitcher_limit=None)
    except MLBUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    items = [founder_candidate(item) for item in analyses.get("items") or []]
    items.sort(key=lambda item: item["confidence"], reverse=True)
    return {
        "date": target_date.isoformat(),
        "locked": False,
        "items": items,
        "count": len(items),
        "message": analyses.get("message") or "候選場次已載入。",
    }


@app.post(f"{settings.api_prefix}/admin/predictions/publish")
async def founder_publish_prediction(
    request: Request,
    command: FounderPredictionPublish,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    await admin_member(request, authorization)
    repository = records_repository(request)
    if not repository.enabled:
        raise HTTPException(status_code=503, detail="Recommendation database is not configured")
    try:
        existing = await repository.get_record_for_date(command.date.isoformat())
    except RecordsStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    if existing:
        raise HTTPException(status_code=409, detail="今日正式推薦已鎖定，不能再更換場次。")

    try:
        analyses = await service(request).matchup_analyses(command.date, pitcher_limit=None)
    except MLBUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    selection = next(
        (item for item in analyses.get("items") or [] if item.get("game_pk") == command.game_pk),
        None,
    )
    if selection is None:
        raise HTTPException(status_code=404, detail="找不到這場尚未開賽的候選賽事。")

    policy = founder_candidate(selection)
    if not policy["can_publish"]:
        raise HTTPException(
            status_code=422,
            detail={"message": "這場比賽目前不可正式發布。", "blockers": policy["blockers"]},
        )
    if policy["requires_confirmation"] and not command.confirm_warning:
        raise HTTPException(
            status_code=409,
            detail={"message": "這場比賽需要創辦人再次確認。", "warnings": policy["warnings"]},
        )

    selection = {
        **selection,
        "publication": {
            "mode": "founder_selected",
            "special_event": policy["event"]["special"],
            "event_label": policy["event"]["label"],
            "warnings_confirmed": bool(policy["warnings"]),
        },
    }
    try:
        stored, created = await repository.publish_prediction_once(
            command.date.isoformat(), selection
        )
    except RecordsStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    if not created:
        raise HTTPException(status_code=409, detail="另一筆正式推薦已先完成鎖定。")
    return {
        "ok": True,
        "date": command.date.isoformat(),
        "locked": True,
        "created": True,
        "selection": stored.get("prediction_snapshot") or selection,
        "message": "創辦人指定場次已正式發布並鎖定。",
    }


class FounderMarketPublish(BaseModel):
    date: date
    moneylines: list[str] = Field(default_factory=list)
    run_lines: list[str] = Field(default_factory=list)
    totals: list[str] = Field(default_factory=list)
    two_leg: list[str] = Field(default_factory=list)
    three_leg: list[str] = Field(default_factory=list)


async def founder_market_candidate_bundle(request: Request, target_date: date) -> dict:
    repository = records_repository(request)
    try:
        public_record = await repository.get_record_for_date(target_date.isoformat())
    except RecordsStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    public_selection = None
    if public_record and isinstance(public_record.get("prediction_snapshot"), dict):
        public_selection = public_record["prediction_snapshot"]

    if not odds_service(request).enabled:
        raise HTTPException(status_code=503, detail="真實盤口來源尚未設定，不能建立正式會員玩法。")
    try:
        feed = await odds_service(request).odds_for_date(target_date)
    except OddsUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    if not (feed.get("meta") or {}).get("fresh_for_model"):
        raise HTTPException(status_code=409, detail="目前只有過期備援盤口，不能發布新的正式會員玩法。")

    try:
        analyses = await service(request).matchup_analyses(target_date, pitcher_limit=None)
    except MLBUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
    eligible = [
        item
        for item in analyses.get("items") or []
        if (item.get("game") or {}).get("auto_recommendation_eligible") is True
        and publication_policy(item, automatic=False)["can_publish"]
        and (((item.get("analysis_groups") or {}).get("starter") or {}).get("both_starters_ready") is True)
    ]
    return build_daily_market_candidates(
        target_date.isoformat(),
        eligible,
        feed.get("items") or [],
        public_selection,
        minimum_probability=settings.min_market_probability,
        minimum_edge=settings.min_market_edge,
        minimum_projection_quality=settings.min_projection_quality,
        minimum_parlay_probability=settings.min_parlay_leg_probability,
    )


@app.get(f"{settings.api_prefix}/admin/markets/candidates")
async def founder_market_candidates(
    request: Request,
    prediction_date: date | None = Query(default=None, alias="date"),
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    await admin_member(request, authorization)
    target_date = requested_date(prediction_date)
    repository = records_repository(request)
    if not repository.enabled:
        raise HTTPException(status_code=503, detail="Recommendation database is not configured")
    try:
        existing = await repository.get_prediction_package_for_date(target_date.isoformat())
    except RecordsStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    if existing:
        return {
            "date": target_date.isoformat(),
            "locked": True,
            "package": package_from_record(existing),
            "message": "今日會員玩法已鎖定，不能再更換。",
        }
    bundle = await founder_market_candidate_bundle(request, target_date)
    return {
        **bundle,
        "locked": False,
        "message": "會員玩法候選已載入；可採用 AI 建議，或自行勾選通過門檻的內容。",
    }


@app.post(f"{settings.api_prefix}/admin/markets/publish")
async def founder_publish_markets(
    request: Request,
    command: FounderMarketPublish,
    authorization: str | None = Header(default=None, alias="Authorization"),
) -> dict:
    await admin_member(request, authorization)
    repository = records_repository(request)
    if not repository.enabled:
        raise HTTPException(status_code=503, detail="Recommendation database is not configured")
    try:
        existing = await repository.get_prediction_package_for_date(command.date.isoformat())
    except RecordsStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    if existing:
        raise HTTPException(status_code=409, detail="今日會員玩法已鎖定，不能再更換。")

    bundle = await founder_market_candidate_bundle(request, command.date)
    selected = {
        "moneylines": command.moneylines,
        "run_lines": command.run_lines,
        "totals": command.totals,
        "two_leg": command.two_leg,
        "three_leg": command.three_leg,
    }
    try:
        package = build_selected_market_package(
            bundle,
            selected,
            publication_mode="founder_selected",
        )
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    if not package.get("published"):
        raise HTTPException(status_code=422, detail="至少選擇一個通過門檻的會員玩法後才能發布。")
    try:
        stored, created = await repository.publish_prediction_package_once(
            command.date.isoformat(), package
        )
    except RecordsStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    if not created:
        raise HTTPException(status_code=409, detail="另一筆會員玩法已先完成鎖定。")
    locked = package_from_record(stored)
    return {
        "ok": True,
        "date": command.date.isoformat(),
        "locked": True,
        "package": locked,
        "message": "創辦人選擇的會員玩法已正式發布並永久鎖定。",
    }


@app.post(f"{settings.api_prefix}/jobs/daily")
async def daily_job(
    request: Request,
    job_date: date | None = Query(default=None, alias="date", description="Taiwan date, YYYY-MM-DD"),
    cron_secret: str | None = Header(default=None, alias="X-DiamondMind-Cron"),
) -> dict:
    if not settings.scheduler_enabled:
        raise HTTPException(status_code=503, detail="Daily scheduler secret is not configured")
    if not cron_secret_matches(cron_secret, settings.cron_secret):
        raise HTTPException(status_code=401, detail="Invalid scheduler credentials")

    target_date = requested_date(job_date)
    try:
        prediction = await prediction_with_persistence(request, target_date)
    except MLBUpstreamError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc

    settlement = {"enabled": settings.records_enabled, "settled_now": 0}
    if settings.records_enabled:
        try:
            settlement["settled_now"] = await settle_pending_records(request)
            settlement["packages_settled_now"] = await settle_pending_prediction_packages(request)
        except RecordsStorageError:
            settlement["message"] = "紀錄資料庫暫時無法執行結算。"

    odds = odds_service(request).status()
    market_package = {
        "date": target_date.isoformat(),
        "published": False,
        "message": "真實盤口尚未提供，會員玩法不會使用猜測資料。",
    }
    if odds_service(request).enabled:
        try:
            feed = await odds_service(request).odds_for_date(target_date)
            odds.update(
                {
                    "available": True,
                    "count": feed["count"],
                    "cache": feed["meta"]["cache"],
                    "fresh_for_model": feed["meta"]["fresh_for_model"],
                    "quota": feed["meta"]["quota"],
                }
            )
            if feed["meta"]["fresh_for_model"]:
                market_package = await locked_or_generated_market_package(
                    request, target_date, prediction, feed
                )
            else:
                market_package["message"] = "目前只有過期備援盤口，不發布新的正式玩法。"
        except OddsUpstreamError:
            # A temporary odds incident must not prevent the independent
            # moneyline model or record settlement from completing.
            odds.update({"available": False, "message": "真實盤口來源暫時無法使用。"})
    else:
        odds["available"] = False

    return {
        "ok": True,
        "date": target_date.isoformat(),
        "time_taiwan": datetime.now(TAIPEI).isoformat(),
        "prediction": prediction,
        "market_package": market_package,
        "settlement": settlement,
        "odds": odds,
    }


@app.get(f"{settings.api_prefix}/records")
async def recommendation_records(request: Request) -> dict:
    repository = records_repository(request)
    if not repository.enabled:
        return {
            "items": [],
            "market_packages": [],
            "count": 0,
            "stats": summarize_records([]),
            "message": "推薦紀錄資料庫尚未設定。",
            "is_demo": False,
            "database": "not_configured",
        }

    try:
        settled_now = await settle_pending_records(request)
        packages_settled_now = await settle_pending_prediction_packages(request)
        items = await repository.list_records()
        settled_packages = await repository.list_settled_prediction_packages()
    except RecordsStorageError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc

    # Defence in depth: never serialize a paid package through this public
    # endpoint unless every included product has already been settled.
    market_packages = [
        package_from_record(item)
        for item in settled_packages
        if item.get("settled") is True
    ]

    return {
        "items": items,
        "market_packages": market_packages,
        "count": len(items),
        "stats": summarize_records(items),
        "message": "尚無正式推薦紀錄。" if not items else "正式推薦紀錄已載入。",
        "is_demo": False,
        "database": "connected",
        "settled_now": settled_now,
        "packages_settled_now": packages_settled_now,
    }
