from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Iterable
from zoneinfo import ZoneInfo

TAIPEI = ZoneInfo("Asia/Taipei")


def iso_utc() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def parse_game_datetime(value: Any) -> datetime | None:
    if not value:
        return None
    try:
        return datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except (TypeError, ValueError):
        return None


def game_timing(
    game: dict[str, Any] | None,
    *,
    now: datetime | None = None,
    lineup_watch_minutes: int = 90,
    final_lock_minutes: int = 30,
) -> dict[str, Any]:
    now_taipei = (now or datetime.now(TAIPEI)).astimezone(TAIPEI)
    game_time = parse_game_datetime((game or {}).get("game_date"))
    if game_time is None:
        return {
            "stage": "unknown",
            "label": "開賽時間待確認",
            "minutes_to_start": None,
            "game_time_taipei": None,
            "generated_at": iso_utc(),
        }
    game_time_taipei = game_time.astimezone(TAIPEI)
    minutes = (game_time_taipei - now_taipei).total_seconds() / 60.0
    if minutes <= 0:
        stage, label = "started", "比賽已開始"
    elif minutes <= final_lock_minutes:
        stage, label = "final_lock", f"最終鎖定窗（開賽前 {final_lock_minutes} 分鐘）"
    elif minutes <= lineup_watch_minutes:
        stage, label = "lineup_watch", "正式打線監控中"
    else:
        stage, label = "preview", "賽前預覽"
    return {
        "stage": stage,
        "label": label,
        "minutes_to_start": round(minutes, 1),
        "game_time_taipei": game_time_taipei.isoformat(),
        "generated_at": iso_utc(),
    }


def validate_roster_member(
    player_id: Any,
    roster_ids: Iterable[Any],
    *,
    team_id: Any,
    role: str,
    roster_date: str,
    authoritative_ids: Iterable[Any] = (),
) -> dict[str, Any]:
    try:
        normalized_player = int(player_id) if player_id is not None else None
    except (TypeError, ValueError):
        normalized_player = None
    normalized_roster = {int(value) for value in roster_ids if value is not None}
    normalized_authoritative = {int(value) for value in authoritative_ids if value is not None}
    if normalized_player is None:
        status, valid, reason = "pending", False, f"{role}尚未公布"
    elif normalized_player in normalized_authoritative:
        status, valid, reason = "valid", True, "已由比賽官方名單確認"
    elif normalized_roster and normalized_player in normalized_roster:
        status, valid, reason = "valid", True, "已通過指定比賽日球隊名單驗證"
    elif normalized_roster:
        status, valid, reason = "mismatch", False, "球員未出現在指定比賽日有效名單，需重新確認"
    else:
        status, valid, reason = "pending", False, "球隊名單來源暫時不足"
    return {
        "status": status,
        "valid": valid,
        "player_id": normalized_player,
        "team_id": team_id,
        "role": role,
        "roster_date": roster_date,
        "reason": reason,
    }


def lineup_validation(
    player_ids: Iterable[Any],
    roster_ids: Iterable[Any],
    *,
    team_id: Any,
    roster_date: str,
    authoritative_ids: Iterable[Any] = (),
) -> dict[str, Any]:
    players = [int(value) for value in player_ids if value is not None]
    roster = {int(value) for value in roster_ids if value is not None}
    official = {int(value) for value in authoritative_ids if value is not None}
    valid_ids = roster | official
    invalid = [value for value in players if valid_ids and value not in valid_ids]
    validated = len(players) - len(invalid)
    rate = validated / len(players) if players else 0.0
    if not players:
        status = "pending"
        reason = "打線尚未建立"
    elif invalid:
        status = "mismatch"
        reason = "部分球員未通過指定比賽日名單驗證"
    elif valid_ids:
        status = "valid"
        reason = "全部球員已通過球隊名單驗證"
    else:
        status = "pending"
        reason = "球隊名單來源暫時不足"
    return {
        "status": status,
        "valid": status == "valid",
        "team_id": team_id,
        "roster_date": roster_date,
        "player_count": len(players),
        "validated_count": validated,
        "validation_rate": round(rate, 3),
        "invalid_player_ids": invalid,
        "reason": reason,
    }


def aggregate_validation(*sections: dict[str, Any] | None) -> dict[str, Any]:
    rows = [section for section in sections if isinstance(section, dict)]
    mismatches = [section for section in rows if section.get("status") == "mismatch"]
    pending = [section for section in rows if section.get("status") == "pending"]
    passed = bool(rows) and not mismatches and not pending and all(section.get("valid") is True for section in rows)
    return {
        "passed": passed,
        "status": "valid" if passed else "mismatch" if mismatches else "pending",
        "checked": len(rows),
        "mismatches": len(mismatches),
        "pending": len(pending),
        "updated_at": iso_utc(),
    }
