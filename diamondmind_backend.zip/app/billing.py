from __future__ import annotations

import hashlib
import html
import json
import secrets
from dataclasses import dataclass
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from hmac import compare_digest
from typing import Any
from urllib.parse import parse_qsl, quote_plus, urlencode
from zoneinfo import ZoneInfo

import httpx

from .config import Settings

TAIPEI = ZoneInfo("Asia/Taipei")
UTC = timezone.utc


class BillingError(RuntimeError):
    pass


@dataclass(frozen=True)
class BillingPlan:
    code: str
    name: str
    amount: int
    months: int


PLANS: dict[str, BillingPlan] = {
    "monthly": BillingPlan("monthly", "DiamondMind Pro 月方案", 399, 1),
    "quarterly": BillingPlan("quarterly", "DiamondMind Pro 季方案", 999, 3),
    "annual": BillingPlan("annual", "DiamondMind Pro 年方案", 2999, 12),
}


def utc_now() -> datetime:
    return datetime.now(UTC)


def iso_utc(value: datetime | None = None) -> str:
    value = value or utc_now()
    if value.tzinfo is None:
        value = value.replace(tzinfo=UTC)
    return value.astimezone(UTC).isoformat().replace("+00:00", "Z")


def parse_datetime(value: Any) -> datetime | None:
    if value in (None, ""):
        return None
    text = str(value).strip()
    for fmt in (
        "%Y/%m/%d %H:%M:%S",
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%dT%H:%M:%S%z",
        "%Y-%m-%dT%H:%M:%S.%f%z",
    ):
        try:
            parsed = datetime.strptime(text, fmt)
            if parsed.tzinfo is None:
                parsed = parsed.replace(tzinfo=TAIPEI)
            return parsed.astimezone(UTC)
        except ValueError:
            pass
    try:
        parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=UTC)
        return parsed.astimezone(UTC)
    except ValueError:
        pass
    try:
        return parsedate_to_datetime(text).astimezone(UTC)
    except (TypeError, ValueError):
        return None


def add_months(value: datetime, months: int) -> datetime:
    if value.tzinfo is None:
        value = value.replace(tzinfo=UTC)
    month_index = value.month - 1 + months
    year = value.year + month_index // 12
    month = month_index % 12 + 1
    day = value.day
    while day > 28:
        try:
            return value.replace(year=year, month=month, day=day)
        except ValueError:
            day -= 1
    return value.replace(year=year, month=month, day=day)


def parse_form_body(raw: bytes) -> dict[str, str]:
    return {
        key: value
        for key, value in parse_qsl(raw.decode("utf-8", errors="replace"), keep_blank_values=True)
    }


def _ecpay_urlencode(value: str) -> str:
    # PHP urlencode / RFC1866 uses + for spaces. ECPay then converts the seven
    # characters below back to the .NET representation and lower-cases all text.
    return quote_plus(value, safe="-_.!*()").lower()


def check_mac_value(parameters: dict[str, Any], hash_key: str, hash_iv: str) -> str:
    values = {
        str(key): "" if value is None else str(value)
        for key, value in parameters.items()
        if str(key).lower() != "checkmacvalue"
    }
    ordered = sorted(values, key=lambda key: key.lower())
    joined = "&".join(f"{key}={values[key]}" for key in ordered)
    raw = f"HashKey={hash_key}&{joined}&HashIV={hash_iv}"
    return hashlib.sha256(_ecpay_urlencode(raw).encode("utf-8")).hexdigest().upper()


def safe_event_payload(payload: dict[str, Any]) -> dict[str, Any]:
    blocked = {"checkmacvalue", "authcode"}
    return {key: value for key, value in payload.items() if str(key).lower() not in blocked}


def trade_number() -> str:
    # ECPay MerchantTradeNo is capped at 20 alphanumeric characters.
    return f"DM{datetime.now(TAIPEI).strftime('%y%m%d%H%M%S')}{secrets.token_hex(3).upper()}"


class BillingRepository:
    def __init__(self, settings: Settings, transport: httpx.AsyncBaseTransport | None = None) -> None:
        self.settings = settings
        self.enabled = settings.records_enabled
        key = settings.supabase_secret_key
        headers = {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "User-Agent": "DiamondMind-Billing/17.0",
            "apikey": key,
        }
        # Legacy service_role JWTs require Authorization. New sb_secret keys are
        # accepted through the apikey header and must never be exposed publicly.
        if key and not key.startswith("sb_secret_"):
            headers["Authorization"] = f"Bearer {key}"
        rest_base = f"{settings.supabase_url}/rest/v1/" if settings.supabase_url else "https://billing.invalid/rest/v1/"
        auth_base = f"{settings.supabase_url}/auth/v1/" if settings.supabase_url else "https://billing.invalid/auth/v1/"
        timeout = max(settings.request_timeout_seconds, 20.0)
        self.rest = httpx.AsyncClient(base_url=rest_base, headers=headers, timeout=timeout, follow_redirects=True, trust_env=False, transport=transport)
        self.auth = httpx.AsyncClient(base_url=auth_base, headers=headers, timeout=timeout, follow_redirects=True, trust_env=False, transport=transport)

    async def aclose(self) -> None:
        await self.rest.aclose()
        await self.auth.aclose()

    def _require(self) -> None:
        if not self.enabled:
            raise BillingError("Supabase billing storage is not configured")

    async def _request(self, method: str, path: str, **kwargs: Any) -> Any:
        self._require()
        try:
            response = await self.rest.request(method, path, **kwargs)
            response.raise_for_status()
            return response.json() if response.content else None
        except httpx.HTTPStatusError as exc:
            detail = exc.response.text[:350]
            if exc.response.status_code in {400, 404} and ("member_subscriptions" in detail or "payment_events" in detail):
                raise BillingError("Billing database tables have not been installed") from exc
            raise BillingError(f"Billing database request failed: HTTP {exc.response.status_code}") from exc
        except (httpx.HTTPError, ValueError) as exc:
            raise BillingError("Billing database is temporarily unavailable") from exc

    async def subscription_for_user(self, user_id: str) -> dict[str, Any] | None:
        data = await self._request("GET", "member_subscriptions", params={"select": "*", "user_id": f"eq.{user_id}", "limit": 1})
        if not isinstance(data, list):
            raise BillingError("Billing database returned an invalid response")
        return data[0] if data else None

    async def subscription_for_trade(self, trade_no: str) -> dict[str, Any] | None:
        data = await self._request("GET", "member_subscriptions", params={"select": "*", "merchant_trade_no": f"eq.{trade_no}", "limit": 1})
        if not isinstance(data, list):
            raise BillingError("Billing database returned an invalid response")
        return data[0] if data else None

    async def upsert_pending(self, *, user_id: str, email: str | None, trade_no: str, plan: BillingPlan) -> dict[str, Any]:
        now = iso_utc()
        payload = {
            "user_id": user_id,
            "email": email,
            "provider": "ecpay",
            "merchant_trade_no": trade_no,
            "provider_trade_no": None,
            "plan_code": plan.code,
            "amount": plan.amount,
            "currency": "TWD",
            "status": "pending",
            "auto_renew": False,
            "billing_anchor": None,
            "current_period_start": None,
            "current_period_end": None,
            "total_success_times": 0,
            "last_rtn_code": None,
            "last_rtn_msg": None,
            "card6_no": None,
            "card4_no": None,
            "updated_at": now,
        }
        data = await self._request(
            "POST", "member_subscriptions",
            params={"on_conflict": "user_id"},
            headers={"Prefer": "resolution=merge-duplicates,return=representation"},
            json=payload,
        )
        if not isinstance(data, list) or not data:
            raise BillingError("Pending payment could not be created")
        return data[0]

    async def update_subscription(self, user_id: str, payload: dict[str, Any]) -> dict[str, Any]:
        data = await self._request(
            "PATCH", "member_subscriptions",
            params={"user_id": f"eq.{user_id}"},
            headers={"Prefer": "return=representation"},
            json={**payload, "updated_at": iso_utc()},
        )
        if not isinstance(data, list) or not data:
            raise BillingError("Membership status could not be updated")
        return data[0]

    async def record_event(self, payload: dict[str, Any]) -> None:
        await self._request(
            "POST", "payment_events",
            params={"on_conflict": "event_key"},
            headers={"Prefer": "resolution=ignore-duplicates,return=minimal"},
            json=payload,
        )

    async def admin_user(self, user_id: str) -> dict[str, Any]:
        self._require()
        try:
            response = await self.auth.get(f"admin/users/{user_id}")
            response.raise_for_status()
            payload = response.json()
        except (httpx.HTTPError, ValueError) as exc:
            raise BillingError("Supabase member metadata could not be loaded") from exc
        if not isinstance(payload, dict) or not payload.get("id"):
            raise BillingError("Supabase returned an invalid member record")
        return payload

    async def update_app_metadata(self, user_id: str, changes: dict[str, Any]) -> dict[str, Any]:
        current = await self.admin_user(user_id)
        merged = {**(current.get("app_metadata") or {}), **changes}
        try:
            response = await self.auth.put(f"admin/users/{user_id}", json={"app_metadata": merged})
            response.raise_for_status()
            payload = response.json()
        except (httpx.HTTPError, ValueError) as exc:
            raise BillingError("Pro membership metadata could not be updated") from exc
        return payload if isinstance(payload, dict) else {"id": user_id, "app_metadata": merged}


class ECPayBillingService:
    def __init__(self, settings: Settings, repository: BillingRepository, transport: httpx.AsyncBaseTransport | None = None) -> None:
        del transport
        self.settings = settings
        self.repository = repository

    async def aclose(self) -> None:
        return None

    @property
    def enabled(self) -> bool:
        return self.settings.billing_enabled and self.repository.enabled

    def public_config(self) -> dict[str, Any]:
        return {
            "provider": "ECPay",
            "enabled": self.enabled,
            "mode": self.settings.ecpay_mode,
            "live": self.settings.ecpay_mode == "production",
            "auto_renew": False,
            "payment_model": "fixed_term",
            "plans": [
                {"code": p.code, "name": p.name, "amount": p.amount, "currency": "TWD", "months": p.months}
                for p in PLANS.values()
            ],
        }

    def _require_enabled(self) -> None:
        if not self.enabled:
            raise BillingError("Payment service is not configured")

    def _plan(self, code: str) -> BillingPlan:
        plan = PLANS.get(str(code).lower())
        if not plan:
            raise BillingError("Unknown membership plan")
        return plan

    def _stage_allowed(self, email: str | None) -> bool:
        if self.settings.ecpay_mode != "stage":
            return True
        return bool(email and email.lower() in self.settings.ecpay_test_emails)

    async def create_checkout(self, member: dict[str, Any], plan_code: str) -> dict[str, Any]:
        self._require_enabled()
        if member.get("role") == "admin":
            raise BillingError("Founder accounts already have full access")
        if not self._stage_allowed(member.get("email")):
            raise BillingError("Payment test mode is restricted to approved test accounts")
        plan = self._plan(plan_code)
        existing = await self.repository.subscription_for_user(str(member["id"]))
        if existing:
            end = parse_datetime(existing.get("current_period_end"))
            if end and end > utc_now():
                raise BillingError("An active Pro membership already exists")
        trade_no = trade_number()
        await self.repository.upsert_pending(user_id=str(member["id"]), email=member.get("email"), trade_no=trade_no, plan=plan)
        callback_base = self.settings.public_api_base.rstrip("/")
        frontend = self.settings.frontend_base_url.rstrip("/") + "/"
        fields: dict[str, Any] = {
            "MerchantID": self.settings.ecpay_merchant_id,
            "MerchantTradeNo": trade_no,
            "MerchantTradeDate": datetime.now(TAIPEI).strftime("%Y/%m/%d %H:%M:%S"),
            "PaymentType": "aio",
            "TotalAmount": plan.amount,
            "TradeDesc": "DiamondMind Pro membership",
            "ItemName": plan.name,
            "ReturnURL": f"{callback_base}{self.settings.api_prefix}/billing/ecpay/return",
            "ChoosePayment": "Credit",
            "EncryptType": 1,
            "ClientBackURL": f"{frontend}?payment=cancelled#membership",
            "OrderResultURL": f"{callback_base}{self.settings.api_prefix}/billing/ecpay/result",
            "NeedExtraPaidInfo": "Y",
            "CustomField1": plan.code,
            "CustomField2": "DiamondMind",
        }
        fields["CheckMacValue"] = check_mac_value(fields, self.settings.ecpay_hash_key, self.settings.ecpay_hash_iv)
        return {
            "provider": "ECPay",
            "mode": self.settings.ecpay_mode,
            "action": self.settings.ecpay_checkout_url,
            "method": "POST",
            "fields": {key: str(value) for key, value in fields.items()},
            "trade_no": trade_no,
            "plan": {"code": plan.code, "name": plan.name, "amount": plan.amount, "currency": "TWD", "months": plan.months},
        }

    def verify(self, payload: dict[str, Any]) -> None:
        if str(payload.get("MerchantID") or "") != self.settings.ecpay_merchant_id:
            raise BillingError("Merchant ID mismatch")
        provided = str(payload.get("CheckMacValue") or "").upper()
        if not provided:
            raise BillingError("Missing CheckMacValue")
        expected = check_mac_value(payload, self.settings.ecpay_hash_key, self.settings.ecpay_hash_iv)
        if not compare_digest(provided, expected):
            raise BillingError("Invalid CheckMacValue")

    async def process_callback(self, payload: dict[str, Any], *, event_type: str = "payment") -> dict[str, Any]:
        self._require_enabled()
        self.verify(payload)
        trade_no = str(payload.get("MerchantTradeNo") or "")
        if not trade_no:
            raise BillingError("Missing merchant trade number")
        subscription = await self.repository.subscription_for_trade(trade_no)
        if not subscription:
            raise BillingError("Unknown payment order")
        plan = self._plan(str(subscription.get("plan_code") or ""))
        try:
            amount = int(str(payload.get("TradeAmt") or payload.get("TotalAmount") or "-1"))
        except ValueError:
            amount = -1
        if amount != plan.amount:
            raise BillingError("Payment amount mismatch")
        try:
            rtn_code = int(str(payload.get("RtnCode") or "0"))
        except ValueError:
            rtn_code = 0
        simulated = str(payload.get("SimulatePaid") or "0") == "1"
        success = rtn_code == 1 and not (self.settings.ecpay_mode == "production" and simulated)
        provider_trade_no = str(payload.get("TradeNo") or "") or None

        # ECPay can retry ReturnURL. Do not extend the membership twice for the
        # same successful transaction.
        if success and subscription.get("status") == "active" and provider_trade_no and subscription.get("provider_trade_no") == provider_trade_no:
            return {"ok": True, "status": "active", "trade_no": trade_no, "plan": plan.code, "expires_at": subscription.get("current_period_end"), "duplicate": True}

        payment_time = parse_datetime(payload.get("PaymentDate")) or parse_datetime(payload.get("TradeDate")) or utc_now()
        common = {
            "provider_trade_no": provider_trade_no,
            "last_rtn_code": rtn_code,
            "last_rtn_msg": str(payload.get("RtnMsg") or ""),
            "card6_no": str(payload.get("card6No") or payload.get("Card6No") or "") or None,
            "card4_no": str(payload.get("card4No") or payload.get("Card4No") or "") or None,
        }
        if success:
            period_start = payment_time
            period_end = add_months(period_start, plan.months)
            updated = await self.repository.update_subscription(str(subscription["user_id"]), {
                **common,
                "status": "active",
                "auto_renew": False,
                "billing_anchor": iso_utc(period_start),
                "current_period_start": iso_utc(period_start),
                "current_period_end": iso_utc(period_end),
                "total_success_times": 1,
            })
            await self.repository.update_app_metadata(str(subscription["user_id"]), {
                "role": "pro",
                "plan": plan.code,
                "billing_provider": "ecpay",
                "billing_status": "active",
                "billing_auto_renew": False,
                "billing_trade_no": trade_no,
                "pro_expires_at": iso_utc(period_end),
            })
        else:
            updated = await self.repository.update_subscription(str(subscription["user_id"]), {**common, "status": "payment_failed", "auto_renew": False})
            await self.repository.update_app_metadata(str(subscription["user_id"]), {"billing_status": "payment_failed", "billing_auto_renew": False})

        event_key = f"{event_type}:{trade_no}:{provider_trade_no or 'none'}:{rtn_code}"
        await self.repository.record_event({
            "event_key": event_key,
            "provider": "ecpay",
            "merchant_trade_no": trade_no,
            "user_id": subscription["user_id"],
            "event_type": event_type,
            "success": success,
            "amount": amount,
            "raw_payload": safe_event_payload(payload),
        })
        return {"ok": success, "status": updated.get("status"), "trade_no": trade_no, "plan": plan.code, "expires_at": updated.get("current_period_end")}

    async def member_status(self, member: dict[str, Any]) -> dict[str, Any]:
        self._require_enabled()
        row = await self.repository.subscription_for_user(str(member["id"]))
        if not row:
            return {"active": False, "status": "free", "plan": None, "auto_renew": False, "current_period_end": None, "mode": self.settings.ecpay_mode}
        end = parse_datetime(row.get("current_period_end"))
        active = bool(end and end > utc_now() and row.get("status") == "active")
        return {
            "active": active,
            "status": row.get("status") or "free",
            "plan": row.get("plan_code"),
            "amount": row.get("amount"),
            "currency": row.get("currency") or "TWD",
            "auto_renew": False,
            "current_period_start": row.get("current_period_start"),
            "current_period_end": row.get("current_period_end"),
            "merchant_trade_no": row.get("merchant_trade_no"),
            "mode": self.settings.ecpay_mode,
        }

    async def cancel(self, member: dict[str, Any]) -> dict[str, Any]:
        del member
        raise BillingError("Current plans are fixed-term purchases and do not renew automatically")

    def result_redirect_html(self, payload: dict[str, Any]) -> str:
        try:
            self.verify(payload)
            success = int(str(payload.get("RtnCode") or "0")) == 1
        except (BillingError, ValueError):
            success = False
        status = "success" if success else "failed"
        frontend = self.settings.frontend_base_url.rstrip("/") + "/"
        query = urlencode({"payment": status, "trade_no": str(payload.get("MerchantTradeNo") or "")})
        target = f"{frontend}?{query}#membership"
        escaped = html.escape(target, quote=True)
        return f'<!doctype html><html lang="zh-Hant"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>DiamondMind 付款結果</title><meta http-equiv="refresh" content="0;url={escaped}"></head><body><p>正在返回 DiamondMind…</p><script>location.replace({json.dumps(target)});</script></body></html>'
