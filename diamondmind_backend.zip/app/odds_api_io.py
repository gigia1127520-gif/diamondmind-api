from __future__ import annotations

import asyncio
import json
import re
from contextvars import ContextVar
from copy import deepcopy
from pathlib import Path
from collections import Counter, defaultdict
from datetime import date, datetime, time, timedelta, timezone
from typing import Any, Iterable
from zoneinfo import ZoneInfo

import httpx

from .cache import AsyncTTLCache
from .config import Settings


TAIPEI = ZoneInfo("Asia/Taipei")


class OddsApiIoUpstreamError(RuntimeError):
    """Raised when Odds-API.io cannot return a usable response."""

    def __init__(
        self,
        message: str,
        *,
        status_code: int | None = None,
        path: str | None = None,
        provider_detail: str | None = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.path = path
        self.provider_detail = provider_detail

    def diagnostic(self) -> dict[str, Any]:
        return {
            "message": str(self),
            "status_code": self.status_code,
            "path": self.path,
            "provider_detail": self.provider_detail,
        }


def _iso_utc(timestamp: float | None = None) -> str:
    dt = datetime.fromtimestamp(timestamp, tz=timezone.utc) if timestamp else datetime.now(timezone.utc)
    return dt.isoformat().replace("+00:00", "Z")


def _parse_datetime(value: Any) -> datetime | None:
    if not isinstance(value, str) or not value.strip():
        return None
    try:
        parsed = datetime.fromisoformat(value.strip().replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed


def _number(value: Any) -> float | None:
    try:
        number = float(str(value).strip())
    except (TypeError, ValueError):
        return None
    return number


def _decimal_to_american(value: Any) -> int | None:
    decimal = _number(value)
    if decimal is None or decimal <= 1.0:
        return None
    if decimal >= 2.0:
        return round((decimal - 1.0) * 100.0)
    return round(-100.0 / (decimal - 1.0))


def _slug(value: Any) -> str:
    return re.sub(r"[^a-z0-9]+", "-", str(value or "").lower()).strip("-")


def _provider_error_text(response: httpx.Response) -> str | None:
    """Extract a short provider error without exposing request credentials."""

    try:
        payload = response.json()
    except (ValueError, json.JSONDecodeError):
        payload = None
    detail: Any = None
    if isinstance(payload, dict):
        for key in ("message", "error", "detail", "errors"):
            if payload.get(key) not in (None, "", [], {}):
                detail = payload.get(key)
                break
    elif isinstance(payload, list) and payload:
        detail = payload
    if detail is None:
        detail = response.text.strip()
    if not detail:
        return None
    if not isinstance(detail, str):
        detail = json.dumps(detail, ensure_ascii=False, separators=(",", ":"))
    detail = re.sub(r"apiKey=[^&\s]+", "apiKey=***", detail, flags=re.I)
    return detail[:600]


def _quota_allowed_bookmakers(error: OddsApiIoUpstreamError) -> list[str]:
    """Parse the provider's authoritative allowed-bookmaker list from a 403."""

    if error.status_code != 403:
        return []
    detail = str(error.provider_detail or error)
    match = re.search(
        r"Allowed\s*:\s*(.+?)(?:\.\s*(?:To reset|Upgrade)|\n(?:To reset|Upgrade)|$)",
        detail,
        flags=re.I | re.S,
    )
    if not match:
        return []
    values = [value.strip(" \t\r\n.") for value in match.group(1).split(",")]
    return list(dict.fromkeys(value for value in values if value))


def _market_rows(market: dict[str, Any]) -> list[dict[str, Any]]:
    rows = market.get("odds")
    if isinstance(rows, dict):
        return [rows]
    if isinstance(rows, list):
        return [row for row in rows if isinstance(row, dict)]
    return []


def _market_list(raw: Any) -> list[dict[str, Any]]:
    if isinstance(raw, list):
        return [item for item in raw if isinstance(item, dict)]
    if isinstance(raw, dict):
        result: list[dict[str, Any]] = []
        for name, value in raw.items():
            if isinstance(value, dict):
                result.append({"name": value.get("name") or name, **value})
            elif isinstance(value, list):
                result.append({"name": name, "odds": value})
        return result
    return []


def _chunks(values: list[Any], size: int) -> Iterable[list[Any]]:
    step = max(1, int(size))
    for offset in range(0, len(values), step):
        yield values[offset : offset + step]


def _event_id(item: dict[str, Any]) -> str:
    value = item.get("id", item.get("event_id"))
    return str(value) if value not in (None, "") else ""


def _bookmaker_names_from_payload(payload: Any) -> list[str]:
    if isinstance(payload, list):
        values = payload
    elif isinstance(payload, dict):
        values = payload.get("bookmakers", payload.get("selected", payload))
        if isinstance(values, dict):
            return [
                str(key).strip()
                for key, enabled in values.items()
                if enabled not in (False, None, 0, "0", "false", "False") and str(key).strip()
            ]
        if not isinstance(values, list):
            values = []
    else:
        values = []
    result: list[str] = []
    for item in values:
        if isinstance(item, dict):
            value = item.get("name") or item.get("bookmaker") or item.get("slug") or item.get("id")
        else:
            value = item
        if str(value or "").strip():
            result.append(str(value).strip())
    return list(dict.fromkeys(result))


def _bookmaker_payload(event: dict[str, Any]) -> dict[str, Any]:
    bookmakers = event.get("bookmakers")
    return bookmakers if isinstance(bookmakers, dict) else {}


def _bookmaker_market_count(event: dict[str, Any], bookmaker: str) -> int:
    return len(_market_list(_bookmaker_payload(event).get(bookmaker)))


def _merge_event_payloads(payloads: list[dict[str, Any]], base_event: dict[str, Any] | None = None) -> dict[str, Any] | None:
    if not payloads and not base_event:
        return None
    merged: dict[str, Any] = dict(base_event or payloads[0])
    merged_bookmakers: dict[str, Any] = {}
    merged_urls: dict[str, Any] = {}
    for payload in payloads:
        for key, value in payload.items():
            if key not in {"bookmakers", "urls"} and value not in (None, "", [], {}):
                merged[key] = value
        merged_bookmakers.update(_bookmaker_payload(payload))
        if isinstance(payload.get("urls"), dict):
            merged_urls.update(payload["urls"])
    merged["bookmakers"] = merged_bookmakers
    if merged_urls:
        merged["urls"] = merged_urls
    return merged


class OddsApiIoService:
    """CPBL real-odds adapter with bookmaker discovery and safe degradation.

    Odds-API.io currently accepts the provider's exact bookmaker *name* in the
    `bookmakers` query parameter. V20.2 therefore resolves the official catalog
    entry automatically and records its provider identifier (numeric ID/slug/key
    when supplied, otherwise the exact official name) before sending requests.
    """

    def __init__(
        self,
        settings: Settings,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self.settings = settings
        self.enabled = settings.odds_api_io_enabled
        self.cache = AsyncTTLCache()
        self.feed_cache = AsyncTTLCache()
        self.quota_lock = asyncio.Lock()
        self._priority_context: ContextVar[bool] = ContextVar(
            "diamondmind_odds_api_io_priority", default=False
        )
        self._quota_ledger = self._load_quota_ledger()
        self.last_check: dict[str, Any] = {}
        # Provider 403 responses can reveal the account's authoritative allowed
        # bookmaker set. Keep it in-memory so later refreshes do not repeat the
        # rejected request even when metadata endpoints are stale.
        self._quota_allowed_override: list[str] = []
        self.request_stats = {
            "network_requests": 0,
            "cache_hits": 0,
            "stale_served": 0,
            "blocked_requests": 0,
            "errors": 0,
        }
        self.client = httpx.AsyncClient(
            timeout=settings.request_timeout_seconds,
            follow_redirects=True,
            trust_env=False,
            transport=transport,
            headers={"Accept": "application/json", "User-Agent": "DiamondMind-OddsApiIo/2.0"},
        )

    async def aclose(self) -> None:
        await self.client.aclose()

    def _quota_windows(self, now: datetime | None = None) -> tuple[str, str]:
        current = (now or datetime.now(timezone.utc)).astimezone(timezone.utc)
        return current.strftime("%Y-%m-%d"), current.strftime("%Y-%m-%dT%H")

    def _quota_defaults(self) -> dict[str, Any]:
        day, hour = self._quota_windows()
        return {
            "utc_day": day,
            "utc_hour": hour,
            "daily_requests": 0,
            "hourly_requests": 0,
            "blocked_requests": 0,
            "last_network_at": None,
            "last_path": None,
            "last_block_reason": None,
            "provider_remaining": None,
            "provider_limit": None,
            "provider_reset": None,
        }

    def _load_quota_ledger(self) -> dict[str, Any]:
        defaults = self._quota_defaults()
        try:
            path = Path(self.settings.odds_api_io_quota_ledger_path)
            if not path.exists():
                return defaults
            payload = json.loads(path.read_text(encoding="utf-8"))
            if not isinstance(payload, dict):
                return defaults
            defaults.update({key: payload.get(key, value) for key, value in defaults.items()})
        except (OSError, ValueError, json.JSONDecodeError):
            return defaults
        self._refresh_quota_windows(defaults)
        return defaults

    def _persist_quota_ledger(self) -> None:
        try:
            path = Path(self.settings.odds_api_io_quota_ledger_path)
            path.parent.mkdir(parents=True, exist_ok=True)
            temp = path.with_suffix(path.suffix + ".tmp")
            temp.write_text(
                json.dumps(self._quota_ledger, ensure_ascii=False, sort_keys=True),
                encoding="utf-8",
            )
            temp.replace(path)
        except OSError:
            # The protection still works in memory when Render's temporary
            # filesystem is unavailable. Provider-side limits remain authoritative.
            pass

    def _refresh_quota_windows(self, ledger: dict[str, Any] | None = None) -> None:
        target = ledger if ledger is not None else self._quota_ledger
        day, hour = self._quota_windows()
        if target.get("utc_day") != day:
            target.update({
                "utc_day": day,
                "daily_requests": 0,
                "blocked_requests": 0,
                "last_block_reason": None,
                "provider_remaining": None,
                "provider_limit": None,
                "provider_reset": None,
            })
        if target.get("utc_hour") != hour:
            target.update({"utc_hour": hour, "hourly_requests": 0})

    def _quota_snapshot(self) -> dict[str, Any]:
        self._refresh_quota_windows()
        daily_limit = max(1, int(self.settings.odds_api_io_daily_limit))
        daily_soft = min(daily_limit, max(1, int(self.settings.odds_api_io_daily_soft_limit)))
        hourly_limit = max(1, int(self.settings.odds_api_io_hourly_limit))
        hourly_soft = min(hourly_limit, max(1, int(self.settings.odds_api_io_hourly_soft_limit)))
        daily_hard = daily_limit if daily_limit <= 10 else max(daily_soft, daily_limit - 5)
        hourly_hard = hourly_limit if hourly_limit <= 5 else max(hourly_soft, hourly_limit - 2)
        daily_used = max(0, int(self._quota_ledger.get("daily_requests") or 0))
        hourly_used = max(0, int(self._quota_ledger.get("hourly_requests") or 0))
        if daily_used >= daily_hard or hourly_used >= hourly_hard:
            state = "blocked"
        elif daily_used >= daily_soft or hourly_used >= hourly_soft:
            state = "reserve_only"
        elif daily_used >= int(daily_soft * 0.8) or hourly_used >= int(hourly_soft * 0.8):
            state = "warning"
        else:
            state = "normal"
        return {
            "counter_scope": "render_process_local_estimate",
            "timezone": "UTC",
            "day": self._quota_ledger.get("utc_day"),
            "hour": self._quota_ledger.get("utc_hour"),
            "daily": {
                "used": daily_used,
                "limit": daily_limit,
                "soft_limit": daily_soft,
                "priority_hard_limit": daily_hard,
                "remaining": max(0, daily_limit - daily_used),
                "standard_remaining": max(0, daily_soft - daily_used),
                "reserved_for_automatic_checks": max(0, daily_hard - daily_soft),
            },
            "hourly": {
                "used": hourly_used,
                "limit": hourly_limit,
                "soft_limit": hourly_soft,
                "priority_hard_limit": hourly_hard,
                "remaining": max(0, hourly_limit - hourly_used),
                "standard_remaining": max(0, hourly_soft - hourly_used),
            },
            "state": state,
            "blocked_requests": int(self._quota_ledger.get("blocked_requests") or 0),
            "last_network_at": self._quota_ledger.get("last_network_at"),
            "last_path": self._quota_ledger.get("last_path"),
            "last_block_reason": self._quota_ledger.get("last_block_reason"),
            "provider_reported": {
                "remaining": self._quota_ledger.get("provider_remaining"),
                "limit": self._quota_ledger.get("provider_limit"),
                "reset": self._quota_ledger.get("provider_reset"),
            },
        }

    def _quota_block_reason(self, *, priority: bool) -> str | None:
        quota = self._quota_snapshot()
        daily = quota["daily"]
        hourly = quota["hourly"]
        if daily["used"] >= daily["priority_hard_limit"]:
            return "daily_priority_hard_limit"
        if hourly["used"] >= hourly["priority_hard_limit"]:
            return "hourly_priority_hard_limit"
        if not priority and daily["used"] >= daily["soft_limit"]:
            return "daily_soft_limit_reserved_for_auto_publish"
        if not priority and hourly["used"] >= hourly["soft_limit"]:
            return "hourly_soft_limit_reserved_for_auto_publish"
        return None

    async def _reserve_network_request(self, path: str) -> str | None:
        async with self.quota_lock:
            self._refresh_quota_windows()
            priority = bool(self._priority_context.get())
            reason = self._quota_block_reason(priority=priority)
            if reason:
                self.request_stats["blocked_requests"] += 1
                self._quota_ledger["blocked_requests"] = int(
                    self._quota_ledger.get("blocked_requests") or 0
                ) + 1
                self._quota_ledger["last_block_reason"] = reason
                self._persist_quota_ledger()
                return reason
            self._quota_ledger["daily_requests"] = int(
                self._quota_ledger.get("daily_requests") or 0
            ) + 1
            self._quota_ledger["hourly_requests"] = int(
                self._quota_ledger.get("hourly_requests") or 0
            ) + 1
            self._quota_ledger["last_network_at"] = _iso_utc()
            self._quota_ledger["last_path"] = path
            self._quota_ledger["last_block_reason"] = None
            self.request_stats["network_requests"] += 1
            self._persist_quota_ledger()
            return None

    @staticmethod
    def _first_header_int(headers: httpx.Headers, names: Iterable[str]) -> int | None:
        for name in names:
            value = headers.get(name)
            try:
                if value is not None:
                    return int(float(value))
            except (TypeError, ValueError):
                continue
        return None

    async def _capture_provider_quota(self, response: httpx.Response) -> None:
        remaining = self._first_header_int(response.headers, (
            "x-ratelimit-remaining", "x-rate-limit-remaining",
            "x-requests-remaining", "ratelimit-remaining",
        ))
        limit = self._first_header_int(response.headers, (
            "x-ratelimit-limit", "x-rate-limit-limit",
            "x-requests-limit", "ratelimit-limit",
        ))
        reset = response.headers.get("x-ratelimit-reset") or response.headers.get("ratelimit-reset")
        if remaining is None and limit is None and reset is None:
            return
        async with self.quota_lock:
            if remaining is not None:
                self._quota_ledger["provider_remaining"] = remaining
            if limit is not None:
                self._quota_ledger["provider_limit"] = limit
            if reset is not None:
                self._quota_ledger["provider_reset"] = str(reset)[:80]
            self._persist_quota_ledger()

    def _stats_snapshot(self) -> dict[str, int]:
        return {key: int(value) for key, value in self.request_stats.items()}

    @staticmethod
    def _stats_delta(before: dict[str, int], after: dict[str, int]) -> dict[str, int]:
        return {key: int(after.get(key, 0)) - int(before.get(key, 0)) for key in after}

    def status(self) -> dict[str, Any]:
        return {
            "configured": self.enabled,
            "provider": "Odds-API.io",
            "base_url": self.settings.odds_api_io_base,
            "sport": self.settings.odds_api_io_cpbl_sport,
            "league_slug_override": self.settings.odds_api_io_cpbl_league_slug or None,
            "requested_bookmakers": self.settings.odds_api_io_cpbl_bookmakers,
            "free_plan_only": self.settings.odds_api_io_free_plan_only,
            "free_plan_bookmakers": self.settings.odds_api_io_free_bookmakers,
            "account_allowed_override": list(self._quota_allowed_override),
            "quota_guard_enabled": True,
            "quota": self._quota_snapshot(),
            "safe_fallback_bookmakers": max(
                1, int(self.settings.odds_api_io_safe_fallback_bookmakers)
            ),
            "odds_cache_ttl_seconds": self.settings.odds_api_io_cache_ttl_seconds,
            "events_cache_ttl_seconds": self.settings.odds_api_io_events_cache_ttl_seconds,
            "metadata_cache_ttl_seconds": self.settings.odds_api_io_metadata_cache_ttl_seconds,
            "request_stats": self._stats_snapshot(),
            "last_check": dict(self.last_check),
            "message": (
                "Odds-API.io 金鑰已設定；免費方案保護、整體盤口快取與每日／每小時安全額度已啟用。"
                if self.enabled
                else "尚未設定 ODDS_API_IO_KEY。"
            ),
        }

    async def _get_json(
        self,
        path: str,
        params: dict[str, Any],
        *,
        ttl_seconds: int | None = None,
        stale_seconds: int | None = None,
    ) -> Any:
        if not self.enabled:
            raise OddsApiIoUpstreamError("Odds-API.io is not configured", path=path)
        safe_params = {key: value for key, value in params.items() if key != "apiKey"}
        cache_key = f"odds-api-io:{path}:{json.dumps(safe_params, sort_keys=True, ensure_ascii=True)}"
        cached = self.cache.get(cache_key)
        if cached and cached.is_fresh:
            self.request_stats["cache_hits"] += 1
            return cached.value
        async with self.cache.lock(cache_key):
            cached = self.cache.get(cache_key)
            if cached and cached.is_fresh:
                self.request_stats["cache_hits"] += 1
                return cached.value
            reason = await self._reserve_network_request(path)
            if reason:
                if cached and cached.can_serve_stale:
                    self.request_stats["stale_served"] += 1
                    return cached.value
                raise OddsApiIoUpstreamError(
                    "Odds-API.io 安全額度保護已啟動；保留剩餘請求給自動發布最後檢查。",
                    status_code=429,
                    path=path,
                    provider_detail=reason,
                )
            try:
                response = await self.client.get(
                    f"{self.settings.odds_api_io_base}/{path.lstrip('/')}",
                    params=params,
                )
                await self._capture_provider_quota(response)
            except httpx.RequestError as exc:
                self.request_stats["errors"] += 1
                if cached and cached.can_serve_stale:
                    self.request_stats["stale_served"] += 1
                    return cached.value
                raise OddsApiIoUpstreamError(
                    "Odds-API.io connection failed.",
                    path=path,
                    provider_detail=str(exc)[:300],
                ) from exc
            if response.status_code >= 400:
                self.request_stats["errors"] += 1
                if cached and cached.can_serve_stale:
                    self.request_stats["stale_served"] += 1
                    return cached.value
                detail = _provider_error_text(response)
                suffix = f" HTTP {response.status_code}"
                if detail:
                    suffix += f": {detail}"
                raise OddsApiIoUpstreamError(
                    f"Odds-API.io request rejected.{suffix}",
                    status_code=response.status_code,
                    path=path,
                    provider_detail=detail,
                )
            try:
                payload = response.json()
            except (ValueError, json.JSONDecodeError) as exc:
                self.request_stats["errors"] += 1
                if cached and cached.can_serve_stale:
                    self.request_stats["stale_served"] += 1
                    return cached.value
                raise OddsApiIoUpstreamError(
                    "Odds-API.io returned invalid JSON.",
                    status_code=response.status_code,
                    path=path,
                ) from exc
            ttl = self.settings.odds_api_io_cache_ttl_seconds if ttl_seconds is None else ttl_seconds
            stale = self.settings.odds_api_io_stale_ttl_seconds if stale_seconds is None else stale_seconds
            self.cache.set(cache_key, payload, ttl, stale)
            return payload

    @staticmethod
    def _looks_like_cpbl(item: dict[str, Any]) -> bool:
        name = str(item.get("name") or "")
        slug = str(item.get("slug") or "")
        canonical = _slug(f"{name} {slug}")
        if "cpbl" in canonical.split("-"):
            return True
        phrases = (
            "chinese-professional-baseball-league",
            "taiwan-professional-baseball",
            "taiwan-baseball-league",
        )
        return any(phrase in canonical for phrase in phrases)

    async def discover_cpbl(self) -> dict[str, Any]:
        if not self.enabled:
            return {"configured": False, "supported": False, "league": None, "leagues_checked": 0}
        override = self.settings.odds_api_io_cpbl_league_slug
        if override:
            league = {"name": "CPBL (configured override)", "slug": override, "eventsCount": None}
            return {"configured": True, "supported": True, "league": league, "leagues_checked": None, "source": "override"}
        payload = await self._get_json(
            "leagues",
            {
                "apiKey": self.settings.odds_api_io_key,
                "sport": self.settings.odds_api_io_cpbl_sport,
                "all": "true",
            },
            ttl_seconds=self.settings.odds_api_io_metadata_cache_ttl_seconds,
        )
        leagues = [item for item in payload if isinstance(item, dict)] if isinstance(payload, list) else []
        matched = next((item for item in leagues if self._looks_like_cpbl(item)), None)
        return {
            "configured": True,
            "supported": matched is not None,
            "league": matched,
            "leagues_checked": len(leagues),
            "source": "discovery",
            "possible_taiwan_leagues": [
                {
                    "name": item.get("name"),
                    "slug": item.get("slug"),
                    "eventsCount": item.get("eventsCount", item.get("eventCount")),
                }
                for item in leagues
                if "taiwan" in f"{item.get('name', '')} {item.get('slug', '')}".lower()
            ][:10],
        }

    @staticmethod
    def _catalog_ref(item: dict[str, Any]) -> dict[str, Any] | None:
        name = str(item.get("name") or "").strip()
        if not name:
            return None
        raw_id = item.get("id", item.get("key", item.get("slug")))
        provider_id = str(raw_id).strip() if raw_id not in (None, "") else name
        return {
            "name": name,
            "request_value": name,
            "provider_id": provider_id,
            "provider_id_source": "id" if item.get("id") not in (None, "") else "key" if item.get("key") not in (None, "") else "slug" if item.get("slug") not in (None, "") else "official_name",
            "active": item.get("active", True) is not False,
        }

    async def _usable_bookmakers(self) -> dict[str, Any]:
        """Resolve only bookmakers authorized for this API account.

        The provider's selected-bookmaker endpoint is authoritative. When it
        returns a non-empty list, V20.2.2 never pads that list with unselected
        catalog entries. If the endpoint is unavailable or empty, the adapter
        uses only a small configured preference set instead of scanning the
        entire provider catalog.
        """

        preferred = list(dict.fromkeys(self.settings.odds_api_io_cpbl_bookmakers))
        available_payload = await self._get_json(
            "bookmakers",
            {},
            ttl_seconds=self.settings.odds_api_io_metadata_cache_ttl_seconds,
        )
        refs = [
            ref
            for item in (available_payload if isinstance(available_payload, list) else [])
            if isinstance(item, dict)
            and (ref := self._catalog_ref(item))
            and ref["active"]
        ]
        by_name = {str(ref["name"]).casefold(): ref for ref in refs}
        by_provider_id = {str(ref["provider_id"]).casefold(): ref for ref in refs}

        selected_names: list[str] = []
        selected_error: dict[str, Any] | None = None
        selected_source = "bookmakers_selected"
        try:
            selected_payload = await self._get_json(
                "bookmakers/selected",
                {"apiKey": self.settings.odds_api_io_key},
                ttl_seconds=self.settings.odds_api_io_metadata_cache_ttl_seconds,
            )
            selected_names = _bookmaker_names_from_payload(selected_payload)
        except OddsApiIoUpstreamError as exc:
            selected_error = exc.diagnostic()

        if self._quota_allowed_override:
            selected_names = list(self._quota_allowed_override)
            selected_source = "provider_403_allowed_cache"

        def resolve(value: str) -> dict[str, Any] | None:
            token = value.casefold()
            return by_name.get(token) or by_provider_id.get(token)

        unresolved_selected: list[str] = []
        selected_refs: list[dict[str, Any]] = []
        for value in selected_names:
            ref = resolve(value)
            if ref is None:
                # The selected endpoint itself is provider-authoritative. Retain
                # the exact value even when the public catalog is temporarily
                # behind or uses a different identifier shape.
                unresolved_selected.append(value)
                ref = {
                    "name": value,
                    "request_value": value,
                    "provider_id": value,
                    "provider_id_source": "selected_endpoint",
                    "active": True,
                }
            selected_refs.append(dict(ref))

        preferred_refs = [dict(ref) for value in preferred if (ref := resolve(value))]
        common_refs = [
            dict(ref)
            for value in ("Bet365", "SingBet", "Pinnacle", "Unibet", "Betfair")
            if (ref := resolve(value))
        ]

        max_books = max(1, int(self.settings.odds_api_io_cpbl_max_bookmakers))
        safe_limit = max(
            1,
            min(
                max_books,
                int(self.settings.odds_api_io_safe_fallback_bookmakers),
            ),
        )

        if selected_refs:
            candidates = selected_refs
            selection_policy = "account_selected_only"
            authoritative = True
            limit = max_books
        else:
            # Never append the entire catalog here. Doing that caused free-plan
            # requests to exceed the provider's selected-bookmaker allowance.
            candidates = [*preferred_refs, *common_refs]
            selection_policy = "safe_preference_fallback"
            authoritative = False
            limit = safe_limit

        ordered: list[dict[str, Any]] = []
        seen: set[str] = set()
        for ref in candidates:
            key = str(ref["name"]).casefold()
            if key not in seen:
                seen.add(key)
                ordered.append(dict(ref))
        used = ordered[:limit]

        selected_set = {value.casefold() for value in selected_names}
        preferred_set = {value.casefold() for value in preferred}
        for ref in used:
            ref["selected_for_account"] = (
                str(ref["name"]).casefold() in selected_set
                or str(ref["provider_id"]).casefold() in selected_set
            )
            ref["requested_preference"] = (
                str(ref["name"]).casefold() in preferred_set
            )

        used_names = {str(ref["name"]).casefold() for ref in used}
        return {
            "requested": preferred,
            "available_count": len(refs),
            "selected": selected_names,
            "selected_source": selected_source,
            "selected_error": selected_error,
            "unresolved_selected": unresolved_selected,
            "used": used,
            "request_values": [ref["request_value"] for ref in used],
            "selection_policy": selection_policy,
            "selected_endpoint_authoritative": authoritative,
            "quota_guard_enabled": True,
            "safe_fallback_limit": safe_limit,
            "ignored_unselected_count": max(0, len(refs) - len(used_names)),
            "requested_not_used": [
                value for value in preferred if value.casefold() not in used_names
            ],
            "identifier_contract": (
                "Odds-API.io /odds accepts exact bookmaker names; account-selected "
                "names are authoritative and unselected catalog entries are never "
                "auto-added."
            ),
        }

    @staticmethod
    def _taipei_window(taiwan_date: date) -> tuple[str, str]:
        start = datetime.combine(taiwan_date, time.min, tzinfo=TAIPEI)
        end = start + timedelta(days=1)
        return (
            start.astimezone(timezone.utc).isoformat().replace("+00:00", "Z"),
            end.astimezone(timezone.utc).isoformat().replace("+00:00", "Z"),
        )

    @staticmethod
    def _matching_date_events(payload: Any, taiwan_date: date) -> list[dict[str, Any]]:
        rows = [item for item in payload if isinstance(item, dict)] if isinstance(payload, list) else []
        result: list[dict[str, Any]] = []
        for event in rows:
            commence = _parse_datetime(event.get("date") or event.get("commence_time"))
            if commence and commence.astimezone(TAIPEI).date() == taiwan_date:
                result.append(event)
        return result

    @staticmethod
    def _bookmaker_diagnostic(ref: dict[str, Any]) -> dict[str, Any]:
        return {
            "name": ref.get("name"),
            "provider_id": ref.get("provider_id"),
            "provider_id_source": ref.get("provider_id_source"),
            "selected_for_account": bool(ref.get("selected_for_account")),
            "requested_preference": bool(ref.get("requested_preference")),
            "events_found": 0,
            "events_returned_with_odds": 0,
            "markets": {"moneyline": 0, "run_line": 0, "totals": 0},
            "attempts": {"events_filter": 0, "multi": 0, "single_group": 0, "single_bookmaker": 0},
            "status": "not_checked",
            "errors": [],
        }

    @staticmethod
    def _record_error(target: dict[str, Any], *, stage: str, error: OddsApiIoUpstreamError, event_id: str | None = None) -> None:
        row = {"stage": stage, **error.diagnostic()}
        if event_id:
            row["event_id"] = event_id
        target.setdefault("errors", []).append(row)
        target["status"] = "error"

    async def _events_by_bookmaker(
        self,
        taiwan_date: date,
        league_slug: str,
        from_utc: str,
        to_utc: str,
        refs: list[dict[str, Any]],
        bookmaker_diagnostics: dict[str, dict[str, Any]],
    ) -> tuple[dict[str, dict[str, Any]], dict[str, set[str]]]:
        events_by_id: dict[str, dict[str, Any]] = {}
        event_bookmakers: dict[str, set[str]] = defaultdict(set)
        for ref in refs:
            name = str(ref["request_value"])
            diagnostic = bookmaker_diagnostics[name]
            diagnostic["attempts"]["events_filter"] += 1
            try:
                payload = await self._get_json(
                    "events",
                    {
                        "apiKey": self.settings.odds_api_io_key,
                        "sport": self.settings.odds_api_io_cpbl_sport,
                        "league": league_slug,
                        "status": "pending",
                        "from": from_utc,
                        "to": to_utc,
                        "bookmaker": name,
                    },
                    ttl_seconds=self.settings.odds_api_io_events_cache_ttl_seconds,
                )
            except OddsApiIoUpstreamError as exc:
                self._record_error(diagnostic, stage="events_filter", error=exc)
                continue
            events = self._matching_date_events(payload, taiwan_date)
            diagnostic["events_found"] = len(events)
            diagnostic["status"] = "events_found" if events else "no_cpbl_events"
            for event in events:
                event_key = _event_id(event)
                if not event_key:
                    continue
                events_by_id.setdefault(event_key, event)
                event_bookmakers[event_key].add(name)
        return events_by_id, event_bookmakers

    @staticmethod
    def _payloads_from_response(payload: Any) -> list[dict[str, Any]]:
        if isinstance(payload, dict):
            return [payload]
        if isinstance(payload, list):
            return [item for item in payload if isinstance(item, dict)]
        return []

    async def _single_event_odds(
        self,
        event_id: str,
        bookmakers: list[str],
        bookmaker_diagnostics: dict[str, dict[str, Any]],
    ) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[str]]:
        errors: list[dict[str, Any]] = []
        payloads: list[dict[str, Any]] = []
        if not bookmakers:
            return payloads, errors, []
        for name in bookmakers:
            bookmaker_diagnostics[name]["attempts"]["single_group"] += 1
        try:
            payload = await self._get_json(
                "odds",
                {
                    "apiKey": self.settings.odds_api_io_key,
                    "eventId": event_id,
                    "bookmakers": ",".join(bookmakers),
                },
            )
            payloads.extend(self._payloads_from_response(payload))
        except OddsApiIoUpstreamError as exc:
            errors.append({
                "stage": "odds_single_group",
                "event_id": event_id,
                "bookmakers": bookmakers,
                **exc.diagnostic(),
            })
            for name in bookmakers:
                self._record_error(
                    bookmaker_diagnostics[name],
                    stage="odds_single_group",
                    error=exc,
                    event_id=event_id,
                )
            allowed = _quota_allowed_bookmakers(exc)
            if allowed:
                # A provider quota rejection is authoritative. Do not fan out
                # into more rejected single-bookmaker requests.
                return payloads, errors, allowed

        present = {
            name.casefold()
            for payload in payloads
            for name in _bookmaker_payload(payload)
        }
        missing = [name for name in bookmakers if name.casefold() not in present]
        for bookmaker in missing:
            diagnostic = bookmaker_diagnostics[bookmaker]
            diagnostic["attempts"]["single_bookmaker"] += 1
            try:
                payload = await self._get_json(
                    "odds",
                    {
                        "apiKey": self.settings.odds_api_io_key,
                        "eventId": event_id,
                        "bookmakers": bookmaker,
                    },
                )
                rows = self._payloads_from_response(payload)
                if rows:
                    payloads.extend(rows)
                else:
                    diagnostic["status"] = "empty_odds_response"
            except OddsApiIoUpstreamError as exc:
                errors.append({
                    "stage": "odds_single_bookmaker",
                    "event_id": event_id,
                    "bookmaker": bookmaker,
                    **exc.diagnostic(),
                })
                self._record_error(
                    diagnostic,
                    stage="odds_single_bookmaker",
                    error=exc,
                    event_id=event_id,
                )
                allowed = _quota_allowed_bookmakers(exc)
                if allowed:
                    return payloads, errors, allowed
        return payloads, errors, []

    async def _fetch_grouped_odds(
        self,
        events_by_id: dict[str, dict[str, Any]],
        event_bookmakers: dict[str, set[str]],
        refs: list[dict[str, Any]],
        bookmaker_diagnostics: dict[str, dict[str, Any]],
    ) -> tuple[
        list[dict[str, Any]],
        list[dict[str, Any]],
        list[dict[str, Any]],
        list[str],
    ]:
        event_ids = list(events_by_id)
        if not event_ids or not refs:
            return [], [], [], []
        bookmaker_names = [str(ref["request_value"]) for ref in refs]
        by_event_payloads: dict[str, list[dict[str, Any]]] = defaultdict(list)
        errors: list[dict[str, Any]] = []
        batch_diagnostics: list[dict[str, Any]] = []
        group_size = max(
            1,
            min(
                len(bookmaker_names),
                30,
                int(self.settings.odds_api_io_bookmaker_group_size),
            ),
        )

        for id_batch in _chunks(event_ids, 10):
            for bookmaker_group in _chunks(bookmaker_names, group_size):
                expected_by_event = {
                    event_id: [
                        name
                        for name in bookmaker_group
                        if not event_bookmakers.get(event_id)
                        or name in event_bookmakers[event_id]
                    ]
                    for event_id in id_batch
                }
                expected_names = sorted({
                    name for values in expected_by_event.values() for name in values
                })
                if not expected_names:
                    continue
                for name in expected_names:
                    bookmaker_diagnostics[name]["attempts"]["multi"] += 1
                row = {
                    "event_ids": list(id_batch),
                    "bookmakers": expected_names,
                    "endpoint": "odds/multi",
                    "status": "pending",
                    "events_returned": 0,
                    "fallback_events": [],
                    "error": None,
                    "quota_allowed_bookmakers": [],
                }
                returned_payloads: list[dict[str, Any]] = []
                try:
                    payload = await self._get_json(
                        "odds/multi",
                        {
                            "apiKey": self.settings.odds_api_io_key,
                            "eventIds": ",".join(id_batch),
                            "bookmakers": ",".join(expected_names),
                        },
                    )
                    returned_payloads = self._payloads_from_response(payload)
                    row["status"] = "ok" if returned_payloads else "empty"
                    row["events_returned"] = len(returned_payloads)
                except OddsApiIoUpstreamError as exc:
                    allowed = _quota_allowed_bookmakers(exc)
                    row["status"] = "quota_restricted" if allowed else "error"
                    row["error"] = exc.diagnostic()
                    row["quota_allowed_bookmakers"] = allowed
                    errors.append({
                        "stage": "odds_multi",
                        "event_ids": id_batch,
                        "bookmakers": expected_names,
                        **exc.diagnostic(),
                    })
                    for name in expected_names:
                        self._record_error(
                            bookmaker_diagnostics[name],
                            stage="odds_multi",
                            error=exc,
                        )
                    batch_diagnostics.append(row)
                    if allowed:
                        # Stop immediately. The caller will retry once using the
                        # provider's authoritative allowed set.
                        return [], errors, batch_diagnostics, allowed

                returned_by_id: dict[str, list[dict[str, Any]]] = defaultdict(list)
                for payload in returned_payloads:
                    key = _event_id(payload)
                    if key:
                        returned_by_id[key].append(payload)
                        by_event_payloads[key].append(payload)

                for event_id in id_batch:
                    expected_for_event = expected_by_event[event_id]
                    present_for_event = {
                        name.casefold()
                        for payload in returned_by_id.get(event_id, [])
                        for name in _bookmaker_payload(payload)
                    }
                    missing_for_event = [
                        name
                        for name in expected_for_event
                        if name.casefold() not in present_for_event
                    ]
                    if not returned_by_id.get(event_id) or missing_for_event:
                        fallback_names = missing_for_event or expected_for_event
                        if fallback_names:
                            row["fallback_events"].append({
                                "event_id": event_id,
                                "bookmakers": fallback_names,
                            })
                            single_payloads, single_errors, allowed = (
                                await self._single_event_odds(
                                    event_id,
                                    fallback_names,
                                    bookmaker_diagnostics,
                                )
                            )
                            errors.extend(single_errors)
                            by_event_payloads[event_id].extend(single_payloads)
                            if allowed:
                                row["status"] = "quota_restricted"
                                row["quota_allowed_bookmakers"] = allowed
                                batch_diagnostics.append(row)
                                return [], errors, batch_diagnostics, allowed
                batch_diagnostics.append(row)

        full_events: list[dict[str, Any]] = []
        for event_id, base_event in events_by_id.items():
            merged = _merge_event_payloads(
                by_event_payloads.get(event_id, []),
                base_event,
            )
            if merged:
                full_events.append(merged)
        return full_events, errors, batch_diagnostics, []

    @staticmethod
    def _source(bookmaker: str, market: dict[str, Any], bookmaker_ref: dict[str, Any] | None = None) -> dict[str, Any]:
        ref = bookmaker_ref or {}
        return {
            "type": "real_bookmaker",
            "provider": "Odds-API.io",
            "bookmaker_key": _slug(bookmaker),
            "bookmaker": bookmaker,
            "bookmaker_id": ref.get("provider_id") or bookmaker,
            "bookmaker_id_source": ref.get("provider_id_source") or "official_name",
            "last_update": market.get("updatedAt") or market.get("updated_at"),
        }

    @staticmethod
    def _best_offer(offers: list[dict[str, Any]], key: str) -> dict[str, Any] | None:
        usable = [offer for offer in offers if _number(offer.get(key)) is not None and float(offer[key]) > 1.0]
        return max(usable, key=lambda offer: float(offer[key])) if usable else None

    @staticmethod
    def _best_line(offers: list[dict[str, Any]], line_key: str, *, target: float | None = None) -> float | None:
        lines = [round(float(offer[line_key]), 4) for offer in offers if _number(offer.get(line_key)) is not None]
        if not lines:
            return None
        counts = Counter(lines)
        return max(
            counts,
            key=lambda line: (
                counts[line],
                -abs(abs(line) - target) if target is not None else 0,
                -abs(line),
            ),
        )

    def _normalize_odds_event(
        self,
        event: dict[str, Any],
        bookmaker_refs: dict[str, dict[str, Any]],
    ) -> dict[str, Any] | None:
        commence = _parse_datetime(event.get("date") or event.get("commence_time"))
        home_name = event.get("home") or event.get("home_team")
        away_name = event.get("away") or event.get("away_team")
        if commence is None or not home_name or not away_name:
            return None

        moneyline_offers: list[dict[str, Any]] = []
        spread_offers: list[dict[str, Any]] = []
        totals_offers: list[dict[str, Any]] = []
        bookmakers = _bookmaker_payload(event)
        preferred = [name.casefold() for name in self.settings.odds_api_io_cpbl_bookmakers]
        ordered_names = sorted(
            bookmakers,
            key=lambda name: preferred.index(name.casefold()) if name.casefold() in preferred else len(preferred),
        )
        for bookmaker in ordered_names:
            raw_markets = _market_list(bookmakers.get(bookmaker))
            ref = bookmaker_refs.get(bookmaker.casefold())
            for market in raw_markets:
                market_name = _slug(market.get("name"))
                source = self._source(bookmaker, market, ref)
                for row in _market_rows(market):
                    if market_name in {"ml", "moneyline", "money-line", "h2h", "match-winner"}:
                        home_decimal = _number(row.get("home"))
                        away_decimal = _number(row.get("away"))
                        if home_decimal and away_decimal and home_decimal > 1.0 and away_decimal > 1.0:
                            moneyline_offers.append({"home_decimal": home_decimal, "away_decimal": away_decimal, "source": source})
                    elif market_name in {"spread", "spreads", "run-line", "runline", "asian-handicap", "handicap"}:
                        home_point = _number(row.get("hdp", row.get("handicap", row.get("line"))))
                        home_decimal = _number(row.get("home"))
                        away_decimal = _number(row.get("away"))
                        if home_point is not None and home_decimal and away_decimal and home_decimal > 1.0 and away_decimal > 1.0:
                            spread_offers.append({
                                "home_point": home_point,
                                "away_point": -home_point,
                                "home_decimal": home_decimal,
                                "away_decimal": away_decimal,
                                "source": source,
                            })
                    elif market_name in {"totals", "total", "over-under", "overunder", "total-runs"}:
                        total = _number(row.get("hdp", row.get("total", row.get("line"))))
                        over_decimal = _number(row.get("over"))
                        under_decimal = _number(row.get("under"))
                        if total is not None and over_decimal and under_decimal and over_decimal > 1.0 and under_decimal > 1.0:
                            totals_offers.append({
                                "total": total,
                                "over_decimal": over_decimal,
                                "under_decimal": under_decimal,
                                "source": source,
                            })

        markets: dict[str, Any] = {}
        if moneyline_offers:
            best_home = self._best_offer(moneyline_offers, "home_decimal")
            best_away = self._best_offer(moneyline_offers, "away_decimal")
            if best_home and best_away:
                markets["moneyline"] = {
                    **best_home["source"],
                    "home_price": _decimal_to_american(best_home["home_decimal"]),
                    "away_price": _decimal_to_american(best_away["away_decimal"]),
                    "home_decimal_odds": round(float(best_home["home_decimal"]), 4),
                    "away_decimal_odds": round(float(best_away["away_decimal"]), 4),
                    "home_source": best_home["source"],
                    "away_source": best_away["source"],
                    "offer_count": len(moneyline_offers),
                    "bookmaker_count": len({offer["source"]["bookmaker"] for offer in moneyline_offers}),
                    "best_odds": True,
                }

        spread_line = self._best_line(spread_offers, "home_point", target=1.5)
        if spread_line is not None:
            line_offers = [offer for offer in spread_offers if round(float(offer["home_point"]), 4) == spread_line]
            best_home = self._best_offer(line_offers, "home_decimal")
            best_away = self._best_offer(line_offers, "away_decimal")
            if best_home and best_away:
                markets["run_line"] = {
                    **best_home["source"],
                    "home": {
                        "point": float(spread_line),
                        "price": _decimal_to_american(best_home["home_decimal"]),
                        "decimal_odds": round(float(best_home["home_decimal"]), 4),
                        "source": best_home["source"],
                    },
                    "away": {
                        "point": -float(spread_line),
                        "price": _decimal_to_american(best_away["away_decimal"]),
                        "decimal_odds": round(float(best_away["away_decimal"]), 4),
                        "source": best_away["source"],
                    },
                    "home_source": best_home["source"],
                    "away_source": best_away["source"],
                    "offer_count": len(line_offers),
                    "bookmaker_count": len({offer["source"]["bookmaker"] for offer in line_offers}),
                    "available_lines": sorted({float(offer["home_point"]) for offer in spread_offers}),
                    "best_odds": True,
                }

        total_line = self._best_line(totals_offers, "total")
        if total_line is not None:
            line_offers = [offer for offer in totals_offers if round(float(offer["total"]), 4) == total_line]
            best_over = self._best_offer(line_offers, "over_decimal")
            best_under = self._best_offer(line_offers, "under_decimal")
            if best_over and best_under:
                markets["totals"] = {
                    **best_over["source"],
                    "total": float(total_line),
                    "over_price": _decimal_to_american(best_over["over_decimal"]),
                    "under_price": _decimal_to_american(best_under["under_decimal"]),
                    "over_decimal_odds": round(float(best_over["over_decimal"]), 4),
                    "under_decimal_odds": round(float(best_under["under_decimal"]), 4),
                    "over_source": best_over["source"],
                    "under_source": best_under["source"],
                    "offer_count": len(line_offers),
                    "bookmaker_count": len({offer["source"]["bookmaker"] for offer in line_offers}),
                    "available_lines": sorted({float(offer["total"]) for offer in totals_offers}),
                    "best_odds": True,
                }

        taipei = commence.astimezone(TAIPEI)
        league = event.get("league") if isinstance(event.get("league"), dict) else {}
        return {
            "event_id": event.get("id"),
            "sport_key": "baseball_cpbl",
            "provider_sport": (event.get("sport") or {}).get("slug") if isinstance(event.get("sport"), dict) else self.settings.odds_api_io_cpbl_sport,
            "provider_league": league.get("slug"),
            "commence_time": commence.astimezone(timezone.utc).isoformat().replace("+00:00", "Z"),
            "date_taiwan": taipei.date().isoformat(),
            "time_taiwan": taipei.strftime("%H:%M"),
            "away_team": away_name,
            "home_team": home_name,
            "markets": markets,
            "bookmaker_count": len(bookmakers),
            "raw_market_offer_counts": {
                "moneyline": len(moneyline_offers),
                "run_line": len(spread_offers),
                "totals": len(totals_offers),
            },
        }

    @staticmethod
    def _update_bookmaker_market_diagnostics(
        full_events: list[dict[str, Any]],
        diagnostics: dict[str, dict[str, Any]],
    ) -> None:
        market_aliases = {
            "ml": "moneyline",
            "moneyline": "moneyline",
            "money-line": "moneyline",
            "h2h": "moneyline",
            "spread": "run_line",
            "spreads": "run_line",
            "run-line": "run_line",
            "runline": "run_line",
            "asian-handicap": "run_line",
            "totals": "totals",
            "total": "totals",
            "over-under": "totals",
            "overunder": "totals",
        }
        for event in full_events:
            for bookmaker, raw_markets in _bookmaker_payload(event).items():
                diagnostic = diagnostics.get(bookmaker)
                if not diagnostic:
                    continue
                if _market_list(raw_markets):
                    diagnostic["events_returned_with_odds"] += 1
                seen_markets: set[str] = set()
                for market in _market_list(raw_markets):
                    canonical = market_aliases.get(_slug(market.get("name")))
                    if canonical and _market_rows(market):
                        seen_markets.add(canonical)
                for market in seen_markets:
                    diagnostic["markets"][market] += 1
        for diagnostic in diagnostics.values():
            if diagnostic["events_returned_with_odds"] > 0 and any(diagnostic["markets"].values()):
                diagnostic["status"] = "markets_available"
            elif diagnostic["events_found"] > 0 and not diagnostic["errors"]:
                diagnostic["status"] = "events_found_no_markets"
            elif diagnostic["status"] == "not_checked":
                diagnostic["status"] = "no_result"

    def _feed_cache_ttl(self, payload: dict[str, Any]) -> int:
        now = datetime.now(TAIPEI)
        starts: list[datetime] = []
        for item in payload.get("items") or []:
            if not isinstance(item, dict):
                continue
            parsed = _parse_datetime(
                item.get("commence_time") or item.get("game_date") or item.get("start_time")
            )
            if parsed is not None:
                starts.append(parsed.astimezone(TAIPEI))
        future = sorted(value for value in starts if value > now)
        if not future:
            return (
                self.settings.odds_api_io_feed_post_start_cache_seconds
                if starts
                else self.settings.odds_api_io_feed_far_cache_seconds
            )
        minutes = (future[0] - now).total_seconds() / 60.0
        if minutes <= 30:
            return self.settings.odds_api_io_feed_final_cache_seconds
        if minutes <= 90:
            return self.settings.odds_api_io_feed_near_cache_seconds
        return self.settings.odds_api_io_feed_far_cache_seconds

    def _feed_cache_payload(self, payload: dict[str, Any], state: str, stored_at: float | None = None) -> dict[str, Any]:
        result = deepcopy(payload)
        meta = result.setdefault("meta", {})
        meta["cache"] = state
        meta["feed_cache"] = {
            "state": state,
            "updated_at": _iso_utc(stored_at),
            "far_ttl_seconds": self.settings.odds_api_io_feed_far_cache_seconds,
            "near_ttl_seconds": self.settings.odds_api_io_feed_near_cache_seconds,
            "final_ttl_seconds": self.settings.odds_api_io_feed_final_cache_seconds,
            "post_start_ttl_seconds": self.settings.odds_api_io_feed_post_start_cache_seconds,
        }
        meta["quota"] = self._quota_snapshot()
        return result

    async def odds_for_cpbl_date(
        self,
        taiwan_date: date,
        *,
        priority: bool = False,
        force_refresh: bool = False,
    ) -> dict[str, Any]:
        feed_key = f"odds-api-io:cpbl-feed:{taiwan_date.isoformat()}"
        cached = self.feed_cache.get(feed_key)
        if cached and cached.is_fresh and not force_refresh:
            self.request_stats["cache_hits"] += 1
            return self._feed_cache_payload(cached.value, "hit", cached.stored_at)
        async with self.feed_cache.lock(feed_key):
            cached = self.feed_cache.get(feed_key)
            if cached and cached.is_fresh and not force_refresh:
                self.request_stats["cache_hits"] += 1
                return self._feed_cache_payload(cached.value, "hit", cached.stored_at)
            token = self._priority_context.set(bool(priority))
            try:
                payload = await self._build_odds_for_cpbl_date(taiwan_date)
            except OddsApiIoUpstreamError:
                if cached and cached.can_serve_stale:
                    self.request_stats["stale_served"] += 1
                    return self._feed_cache_payload(cached.value, "stale", cached.stored_at)
                raise
            finally:
                self._priority_context.reset(token)
            ttl = self._feed_cache_ttl(payload)
            entry = self.feed_cache.set(
                feed_key, payload, ttl, self.settings.odds_api_io_stale_ttl_seconds
            )
            return self._feed_cache_payload(payload, "miss", entry.stored_at)

    async def _build_odds_for_cpbl_date(self, taiwan_date: date) -> dict[str, Any]:
        checked_at = _iso_utc()
        stats_before = self._stats_snapshot()
        discovery = await self.discover_cpbl()
        zero_coverage = {"moneyline": 0, "run_line": 0, "totals": 0}
        if not discovery.get("supported"):
            self.last_check = {
                "checked_at": checked_at,
                "date": taiwan_date.isoformat(),
                "supported": False,
                "league": None,
                "events": 0,
                "count": 0,
                "coverage": zero_coverage,
            }
            return {
                "date": taiwan_date.isoformat(),
                "timezone": "Asia/Taipei",
                "configured": True,
                "count": 0,
                "items": [],
                "meta": {
                    "provider": "Odds-API.io",
                    "fresh_for_model": True,
                    "cache": "feed_cache",
                    "coverage": zero_coverage,
                    "coverage_status": "cpbl_not_listed",
                    "discovery": discovery,
                    "real_odds_only": True,
                },
            }

        league = discovery.get("league") or {}
        league_slug = str(league.get("slug") or "").strip()
        from_utc, to_utc = self._taipei_window(taiwan_date)
        events_payload = await self._get_json(
            "events",
            {
                "apiKey": self.settings.odds_api_io_key,
                "sport": self.settings.odds_api_io_cpbl_sport,
                "league": league_slug,
                "status": "pending",
                "from": from_utc,
                "to": to_utc,
            },
            ttl_seconds=self.settings.odds_api_io_events_cache_ttl_seconds,
        )
        general_events = self._matching_date_events(events_payload, taiwan_date)
        events_by_id = {_event_id(item): item for item in general_events if _event_id(item)}

        odds_errors: list[dict[str, Any]] = []
        batch_diagnostics: list[dict[str, Any]] = []
        try:
            bookmaker_info = await self._usable_bookmakers()
        except OddsApiIoUpstreamError as exc:
            bookmaker_info = {
                "requested": self.settings.odds_api_io_cpbl_bookmakers,
                "available_count": 0,
                "selected": [],
                "used": [],
                "request_values": [],
                "error": exc.diagnostic(),
            }
            odds_errors.append({"stage": "bookmakers", **exc.diagnostic()})

        refs = [
            item
            for item in bookmaker_info.get("used") or []
            if isinstance(item, dict) and item.get("request_value")
        ]
        bookmaker_diagnostics = {
            str(ref["request_value"]): self._bookmaker_diagnostic(ref)
            for ref in refs
        }
        probed_events, event_bookmakers = await self._events_by_bookmaker(
            taiwan_date,
            league_slug,
            from_utc,
            to_utc,
            refs,
            bookmaker_diagnostics,
        )
        for event_id, event in probed_events.items():
            events_by_id.setdefault(event_id, event)

        full_events, fetch_errors, first_batches, quota_allowed = (
            await self._fetch_grouped_odds(
                events_by_id,
                event_bookmakers,
                refs,
                bookmaker_diagnostics,
            )
        )
        odds_errors.extend(fetch_errors)
        batch_diagnostics.extend(first_batches)

        if quota_allowed:
            # Provider 403 is more authoritative than cached metadata. Retry once
            # using only the explicitly allowed bookmaker names and remember the
            # set for later refreshes in this process.
            self._quota_allowed_override = list(dict.fromkeys(quota_allowed))
            bookmaker_info["quota_guard_rejected_bookmaker_results"] = list(
                bookmaker_diagnostics.values()
            )
            previous_names = [str(ref.get("request_value")) for ref in refs]
            prior_refs = {
                str(ref.get("name") or ref.get("request_value")).casefold(): ref
                for ref in refs
            }
            refs = []
            for name in self._quota_allowed_override:
                existing = prior_refs.get(name.casefold()) or {}
                refs.append({
                    "name": name,
                    "request_value": name,
                    "provider_id": existing.get("provider_id") or name,
                    "provider_id_source": existing.get("provider_id_source")
                    or "provider_403_allowed",
                    "active": True,
                    "selected_for_account": True,
                    "requested_preference": name.casefold()
                    in {
                        value.casefold()
                        for value in self.settings.odds_api_io_cpbl_bookmakers
                    },
                })
            bookmaker_info["quota_guard_triggered"] = True
            bookmaker_info["quota_guard_previous_request_values"] = previous_names
            bookmaker_info["selected"] = list(self._quota_allowed_override)
            bookmaker_info["selected_source"] = "provider_403_allowed_retry"
            bookmaker_info["used"] = refs
            bookmaker_info["request_values"] = [
                str(ref["request_value"]) for ref in refs
            ]
            bookmaker_info["selection_policy"] = "provider_403_allowed_only"
            bookmaker_info["selected_endpoint_authoritative"] = True

            bookmaker_diagnostics = {
                str(ref["request_value"]): self._bookmaker_diagnostic(ref)
                for ref in refs
            }
            retry_events, event_bookmakers = await self._events_by_bookmaker(
                taiwan_date,
                league_slug,
                from_utc,
                to_utc,
                refs,
                bookmaker_diagnostics,
            )
            for event_id, event in retry_events.items():
                events_by_id.setdefault(event_id, event)
            full_events, retry_errors, retry_batches, second_quota_allowed = (
                await self._fetch_grouped_odds(
                    events_by_id,
                    event_bookmakers,
                    refs,
                    bookmaker_diagnostics,
                )
            )
            odds_errors.extend(retry_errors)
            batch_diagnostics.extend(retry_batches)
            bookmaker_info["quota_guard_retry_succeeded"] = not bool(
                second_quota_allowed
            )
            if second_quota_allowed:
                bookmaker_info["quota_guard_retry_allowed"] = second_quota_allowed
        else:
            bookmaker_info["quota_guard_triggered"] = False

        self._update_bookmaker_market_diagnostics(
            full_events,
            bookmaker_diagnostics,
        )

        refs_by_name = {str(ref["name"]).casefold(): ref for ref in refs}
        normalized_all = [self._normalize_odds_event(item, refs_by_name) for item in full_events]
        normalized_all = [item for item in normalized_all if item is not None]
        # A feed item is considered real odds only when at least one normalized
        # market exists. This prevents empty provider events from unlocking Pro.
        items = [item for item in normalized_all if item.get("markets")]
        items.sort(key=lambda item: item.get("commence_time") or "")
        coverage = {
            "moneyline": sum(1 for item in items if "moneyline" in (item.get("markets") or {})),
            "run_line": sum(1 for item in items if "run_line" in (item.get("markets") or {})),
            "totals": sum(1 for item in items if "totals" in (item.get("markets") or {})),
        }
        any_market = any(coverage.values())
        events_found = len(events_by_id)
        if any_market:
            coverage_status = "available"
        elif events_found and odds_errors:
            coverage_status = "odds_request_rejected"
        elif events_found:
            coverage_status = "events_found_no_odds"
        else:
            coverage_status = "no_events"

        stats_after = self._stats_snapshot()
        cache_diagnostics = {
            "policy": "full CPBL feeds use dynamic 5/10/30-minute cache; metadata uses six-hour cache; stale data is retained for quota protection",
            "odds_ttl_seconds": self.settings.odds_api_io_cache_ttl_seconds,
            "events_ttl_seconds": self.settings.odds_api_io_events_cache_ttl_seconds,
            "metadata_ttl_seconds": self.settings.odds_api_io_metadata_cache_ttl_seconds,
            "request_delta": self._stats_delta(stats_before, stats_after),
            "request_totals": stats_after,
        }
        last_error = odds_errors[-1] if odds_errors else None
        bookmaker_rows = list(bookmaker_diagnostics.values())
        self.last_check = {
            "checked_at": checked_at,
            "date": taiwan_date.isoformat(),
            "supported": True,
            "league": league,
            "events": events_found,
            "count": len(items),
            "coverage": coverage,
            "coverage_status": coverage_status,
            "bookmakers": bookmaker_info,
            "bookmaker_results": bookmaker_rows,
            "last_error": last_error,
            "cache": cache_diagnostics,
            "quota": self._quota_snapshot(),
        }
        return {
            "date": taiwan_date.isoformat(),
            "timezone": "Asia/Taipei",
            "configured": True,
            "count": len(items),
            "items": items,
            "meta": {
                "provider": "Odds-API.io",
                "fresh_for_model": True,
                "cache": "feed_cache",
                "cache_diagnostics": cache_diagnostics,
                "coverage": coverage,
                "coverage_status": coverage_status,
                "events_found": events_found,
                "events_with_provider_payload": len(full_events),
                "events_with_real_markets": len(items),
                "sport_key": "baseball_cpbl",
                "provider_league": league_slug,
                "bookmakers": bookmaker_info,
                "bookmaker_results": bookmaker_rows,
                "batch_results": batch_diagnostics,
                "odds_errors": odds_errors[-30:],
                "discovery": discovery,
                "query_window": {"from": from_utc, "to": to_utc},
                "updated_at": checked_at,
                "quota": self._quota_snapshot(),
                "real_odds_only": True,
                "best_odds": True,
                "pro_publish_gate": "at_least_one_normalized_real_bookmaker_market",
            },
        }
