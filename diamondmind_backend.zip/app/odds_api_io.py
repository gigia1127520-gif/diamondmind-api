from __future__ import annotations

import json
import re
from datetime import date, datetime, timezone
from typing import Any
from zoneinfo import ZoneInfo

import httpx

from .cache import AsyncTTLCache
from .config import Settings


TAIPEI = ZoneInfo("Asia/Taipei")


class OddsApiIoUpstreamError(RuntimeError):
    """Raised when Odds-API.io cannot return a usable response."""


def _iso_utc(timestamp: float | None = None) -> str:
    dt = datetime.fromtimestamp(timestamp, tz=timezone.utc) if timestamp else datetime.now(timezone.utc)
    return dt.isoformat().replace("+00:00", "Z")


def _parse_datetime(value: Any) -> datetime | None:
    if not isinstance(value, str) or not value.strip():
        return None
    try:
        parsed = datetime.fromisoformat(value.strip().replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed


def _number(value: Any) -> float | None:
    try:
        number = float(str(value).strip())
    except (TypeError, ValueError):
        return None
    return number


def _decimal_to_american(value: Any) -> int | None:
    decimal = _number(value)
    if decimal is None or decimal <= 1.0:
        return None
    if decimal >= 2.0:
        return round((decimal - 1.0) * 100.0)
    return round(-100.0 / (decimal - 1.0))


def _slug(value: Any) -> str:
    return re.sub(r"[^a-z0-9]+", "-", str(value or "").lower()).strip("-")


def _market_rows(market: dict[str, Any]) -> list[dict[str, Any]]:
    rows = market.get("odds")
    if isinstance(rows, dict):
        return [rows]
    if isinstance(rows, list):
        return [row for row in rows if isinstance(row, dict)]
    return []


class OddsApiIoService:
    """Server-only CPBL fallback adapter for Odds-API.io.

    The service discovers the live CPBL league slug from the provider instead
    of assuming one.  It then normalizes decimal sportsbook prices into the
    same DiamondMind event structure used by the existing The Odds API adapter.
    """

    def __init__(
        self,
        settings: Settings,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self.settings = settings
        self.enabled = settings.odds_api_io_enabled
        self.cache = AsyncTTLCache()
        self.last_check: dict[str, Any] = {}
        self.client = httpx.AsyncClient(
            timeout=settings.request_timeout_seconds,
            follow_redirects=True,
            trust_env=False,
            transport=transport,
            headers={"Accept": "application/json", "User-Agent": "DiamondMind-OddsApiIo/1.0"},
        )

    async def aclose(self) -> None:
        await self.client.aclose()

    def status(self) -> dict[str, Any]:
        return {
            "configured": self.enabled,
            "provider": "Odds-API.io",
            "base_url": self.settings.odds_api_io_base,
            "sport": self.settings.odds_api_io_cpbl_sport,
            "league_slug_override": self.settings.odds_api_io_cpbl_league_slug or None,
            "bookmakers": self.settings.odds_api_io_cpbl_bookmakers,
            "last_check": dict(self.last_check),
            "message": (
                "Odds-API.io 金鑰已設定；CPBL 會自動探索聯盟並只使用真實盤口。"
                if self.enabled
                else "尚未設定 ODDS_API_IO_KEY。"
            ),
        }

    async def _get_json(self, path: str, params: dict[str, Any]) -> Any:
        if not self.enabled:
            raise OddsApiIoUpstreamError("Odds-API.io is not configured")
        safe_params = {key: value for key, value in params.items() if key != "apiKey"}
        cache_key = f"odds-api-io:{path}:{json.dumps(safe_params, sort_keys=True, ensure_ascii=True)}"
        cached = self.cache.get(cache_key)
        if cached and cached.is_fresh:
            return cached.value
        async with self.cache.lock(cache_key):
            cached = self.cache.get(cache_key)
            if cached and cached.is_fresh:
                return cached.value
            try:
                response = await self.client.get(
                    f"{self.settings.odds_api_io_base}/{path.lstrip('/')}",
                    params=params,
                )
                response.raise_for_status()
                payload = response.json()
                self.cache.set(
                    cache_key,
                    payload,
                    self.settings.odds_api_io_cache_ttl_seconds,
                    self.settings.odds_api_io_stale_ttl_seconds,
                )
                return payload
            except (httpx.HTTPError, ValueError, json.JSONDecodeError) as exc:
                if cached and cached.can_serve_stale:
                    return cached.value
                status = getattr(getattr(exc, "response", None), "status_code", None)
                detail = f" HTTP {status}" if status else ""
                raise OddsApiIoUpstreamError(f"Odds-API.io temporarily unavailable.{detail}") from exc

    @staticmethod
    def _looks_like_cpbl(item: dict[str, Any]) -> bool:
        name = str(item.get("name") or "")
        slug = str(item.get("slug") or "")
        token = f"{name} {slug}".lower()
        canonical = _slug(token)
        if "cpbl" in canonical.split("-"):
            return True
        phrases = (
            "chinese-professional-baseball-league",
            "taiwan-professional-baseball",
            "taiwan-baseball-league",
        )
        return any(phrase in canonical for phrase in phrases)

    async def discover_cpbl(self) -> dict[str, Any]:
        if not self.enabled:
            return {"configured": False, "supported": False, "league": None, "leagues_checked": 0}
        override = self.settings.odds_api_io_cpbl_league_slug
        if override:
            league = {"name": "CPBL (configured override)", "slug": override, "eventsCount": None}
            return {"configured": True, "supported": True, "league": league, "leagues_checked": None, "source": "override"}
        payload = await self._get_json(
            "leagues",
            {
                "apiKey": self.settings.odds_api_io_key,
                "sport": self.settings.odds_api_io_cpbl_sport,
                "all": "true",
            },
        )
        leagues = [item for item in payload if isinstance(item, dict)] if isinstance(payload, list) else []
        matched = next((item for item in leagues if self._looks_like_cpbl(item)), None)
        return {
            "configured": True,
            "supported": matched is not None,
            "league": matched,
            "leagues_checked": len(leagues),
            "source": "discovery",
            "possible_taiwan_leagues": [
                {"name": item.get("name"), "slug": item.get("slug"), "eventsCount": item.get("eventsCount", item.get("eventCount"))}
                for item in leagues
                if "taiwan" in f"{item.get('name', '')} {item.get('slug', '')}".lower()
            ][:10],
        }

    def _market_source(self, bookmaker: str, market: dict[str, Any]) -> dict[str, Any]:
        return {
            "type": "real_bookmaker",
            "provider": "Odds-API.io",
            "bookmaker_key": _slug(bookmaker),
            "bookmaker": bookmaker,
            "last_update": market.get("updatedAt") or market.get("updated_at"),
        }

    def _normalize_odds_event(self, event: dict[str, Any]) -> dict[str, Any] | None:
        commence = _parse_datetime(event.get("date") or event.get("commence_time"))
        home_name = event.get("home") or event.get("home_team")
        away_name = event.get("away") or event.get("away_team")
        if commence is None or not home_name or not away_name:
            return None
        bookmakers = event.get("bookmakers")
        if not isinstance(bookmakers, dict):
            bookmakers = {}
        markets: dict[str, Any] = {}
        preferred = self.settings.odds_api_io_cpbl_bookmakers
        ordered_names = sorted(
            bookmakers,
            key=lambda name: preferred.index(name) if name in preferred else len(preferred),
        )
        for bookmaker in ordered_names:
            raw_markets = bookmakers.get(bookmaker)
            if not isinstance(raw_markets, list):
                continue
            for market in raw_markets:
                if not isinstance(market, dict):
                    continue
                market_name = _slug(market.get("name"))
                for row in _market_rows(market):
                    if market_name in {"ml", "moneyline", "money-line", "h2h"} and "moneyline" not in markets:
                        home_price = _decimal_to_american(row.get("home"))
                        away_price = _decimal_to_american(row.get("away"))
                        if home_price not in {None, 0} and away_price not in {None, 0}:
                            markets["moneyline"] = {
                                **self._market_source(bookmaker, market),
                                "home_price": home_price,
                                "away_price": away_price,
                            }
                    elif market_name in {"spread", "spreads", "run-line", "runline", "asian-handicap"} and "run_line" not in markets:
                        home_point = _number(row.get("hdp", row.get("handicap")))
                        home_price = _decimal_to_american(row.get("home"))
                        away_price = _decimal_to_american(row.get("away"))
                        if home_point is not None and home_price not in {None, 0} and away_price not in {None, 0}:
                            markets["run_line"] = {
                                **self._market_source(bookmaker, market),
                                "home": {"point": home_point, "price": home_price},
                                "away": {"point": -home_point, "price": away_price},
                            }
                    elif market_name in {"totals", "total", "over-under", "overunder"} and "totals" not in markets:
                        total = _number(row.get("hdp", row.get("total", row.get("line"))))
                        over_price = _decimal_to_american(row.get("over"))
                        under_price = _decimal_to_american(row.get("under"))
                        if total is not None and over_price not in {None, 0} and under_price not in {None, 0}:
                            markets["totals"] = {
                                **self._market_source(bookmaker, market),
                                "total": total,
                                "over_price": over_price,
                                "under_price": under_price,
                            }
        taipei = commence.astimezone(TAIPEI)
        league = event.get("league") if isinstance(event.get("league"), dict) else {}
        return {
            "event_id": event.get("id"),
            "sport_key": "baseball_cpbl",
            "provider_sport": (event.get("sport") or {}).get("slug") if isinstance(event.get("sport"), dict) else self.settings.odds_api_io_cpbl_sport,
            "provider_league": league.get("slug"),
            "commence_time": commence.astimezone(timezone.utc).isoformat().replace("+00:00", "Z"),
            "date_taiwan": taipei.date().isoformat(),
            "time_taiwan": taipei.strftime("%H:%M"),
            "away_team": away_name,
            "home_team": home_name,
            "markets": markets,
        }

    async def odds_for_cpbl_date(self, taiwan_date: date) -> dict[str, Any]:
        checked_at = _iso_utc()
        discovery = await self.discover_cpbl()
        if not discovery.get("supported"):
            self.last_check = {
                "checked_at": checked_at,
                "date": taiwan_date.isoformat(),
                "supported": False,
                "league": None,
                "count": 0,
                "coverage": {"moneyline": 0, "run_line": 0, "totals": 0},
            }
            return {
                "date": taiwan_date.isoformat(),
                "timezone": "Asia/Taipei",
                "configured": True,
                "count": 0,
                "items": [],
                "meta": {
                    "provider": "Odds-API.io",
                    "fresh_for_model": True,
                    "cache": "provider",
                    "coverage": {"moneyline": 0, "run_line": 0, "totals": 0},
                    "coverage_status": "cpbl_not_listed",
                    "discovery": discovery,
                },
            }
        league = discovery.get("league") or {}
        league_slug = str(league.get("slug") or "").strip()
        events_payload = await self._get_json(
            "events",
            {
                "apiKey": self.settings.odds_api_io_key,
                "sport": self.settings.odds_api_io_cpbl_sport,
                "league": league_slug,
                "status": "pending",
                "limit": 100,
            },
        )
        events = [item for item in events_payload if isinstance(item, dict)] if isinstance(events_payload, list) else []
        matching_events = []
        for event in events:
            commence = _parse_datetime(event.get("date"))
            if commence and commence.astimezone(TAIPEI).date() == taiwan_date:
                matching_events.append(event)
        full_events: list[dict[str, Any]] = []
        bookmaker_csv = ",".join(self.settings.odds_api_io_cpbl_bookmakers)
        for offset in range(0, len(matching_events), 10):
            batch = matching_events[offset : offset + 10]
            ids = ",".join(str(item.get("id")) for item in batch if item.get("id") is not None)
            if not ids:
                continue
            payload = await self._get_json(
                "odds/multi",
                {
                    "apiKey": self.settings.odds_api_io_key,
                    "eventIds": ids,
                    "bookmakers": bookmaker_csv,
                },
            )
            if isinstance(payload, list):
                full_events.extend(item for item in payload if isinstance(item, dict))
        normalized = [self._normalize_odds_event(item) for item in full_events]
        items = [item for item in normalized if item is not None]
        items.sort(key=lambda item: item.get("commence_time") or "")
        coverage = {
            "moneyline": sum(1 for item in items if "moneyline" in (item.get("markets") or {})),
            "run_line": sum(1 for item in items if "run_line" in (item.get("markets") or {})),
            "totals": sum(1 for item in items if "totals" in (item.get("markets") or {})),
        }
        self.last_check = {
            "checked_at": checked_at,
            "date": taiwan_date.isoformat(),
            "supported": True,
            "league": league,
            "events": len(matching_events),
            "count": len(items),
            "coverage": coverage,
            "last_error": None,
        }
        return {
            "date": taiwan_date.isoformat(),
            "timezone": "Asia/Taipei",
            "configured": True,
            "count": len(items),
            "items": items,
            "meta": {
                "provider": "Odds-API.io",
                "fresh_for_model": True,
                "cache": "provider",
                "coverage": coverage,
                "coverage_status": "available" if items else "no_events_or_odds",
                "sport_key": "baseball_cpbl",
                "provider_league": league_slug,
                "bookmakers": self.settings.odds_api_io_cpbl_bookmakers,
                "discovery": discovery,
                "updated_at": checked_at,
                "quota": {},
            },
        }
