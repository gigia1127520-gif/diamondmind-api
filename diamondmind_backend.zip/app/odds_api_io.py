from __future__ import annotations

import asyncio
import json
import re
from collections import Counter, defaultdict
from datetime import date, datetime, time, timedelta, timezone
from typing import Any, Iterable
from zoneinfo import ZoneInfo

import httpx

from .cache import AsyncTTLCache
from .config import Settings


TAIPEI = ZoneInfo("Asia/Taipei")


class OddsApiIoUpstreamError(RuntimeError):
    """Raised when Odds-API.io cannot return a usable response."""

    def __init__(
        self,
        message: str,
        *,
        status_code: int | None = None,
        path: str | None = None,
        provider_detail: str | None = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.path = path
        self.provider_detail = provider_detail

    def diagnostic(self) -> dict[str, Any]:
        return {
            "message": str(self),
            "status_code": self.status_code,
            "path": self.path,
            "provider_detail": self.provider_detail,
        }


def _iso_utc(timestamp: float | None = None) -> str:
    dt = datetime.fromtimestamp(timestamp, tz=timezone.utc) if timestamp else datetime.now(timezone.utc)
    return dt.isoformat().replace("+00:00", "Z")


def _parse_datetime(value: Any) -> datetime | None:
    if not isinstance(value, str) or not value.strip():
        return None
    try:
        parsed = datetime.fromisoformat(value.strip().replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed


def _number(value: Any) -> float | None:
    try:
        number = float(str(value).strip())
    except (TypeError, ValueError):
        return None
    return number


def _decimal_to_american(value: Any) -> int | None:
    decimal = _number(value)
    if decimal is None or decimal <= 1.0:
        return None
    if decimal >= 2.0:
        return round((decimal - 1.0) * 100.0)
    return round(-100.0 / (decimal - 1.0))


def _slug(value: Any) -> str:
    return re.sub(r"[^a-z0-9]+", "-", str(value or "").lower()).strip("-")


def _provider_error_text(response: httpx.Response) -> str | None:
    """Extract a short provider error without exposing request credentials."""

    try:
        payload = response.json()
    except (ValueError, json.JSONDecodeError):
        payload = None
    detail: Any = None
    if isinstance(payload, dict):
        for key in ("message", "error", "detail", "errors"):
            if payload.get(key) not in (None, "", [], {}):
                detail = payload.get(key)
                break
    elif isinstance(payload, list) and payload:
        detail = payload
    if detail is None:
        detail = response.text.strip()
    if not detail:
        return None
    if not isinstance(detail, str):
        detail = json.dumps(detail, ensure_ascii=False, separators=(",", ":"))
    detail = re.sub(r"apiKey=[^&\s]+", "apiKey=***", detail, flags=re.I)
    return detail[:600]


def _market_rows(market: dict[str, Any]) -> list[dict[str, Any]]:
    rows = market.get("odds")
    if isinstance(rows, dict):
        return [rows]
    if isinstance(rows, list):
        return [row for row in rows if isinstance(row, dict)]
    return []


def _market_list(raw: Any) -> list[dict[str, Any]]:
    if isinstance(raw, list):
        return [item for item in raw if isinstance(item, dict)]
    if isinstance(raw, dict):
        result: list[dict[str, Any]] = []
        for name, value in raw.items():
            if isinstance(value, dict):
                result.append({"name": value.get("name") or name, **value})
            elif isinstance(value, list):
                result.append({"name": name, "odds": value})
        return result
    return []


def _chunks(values: list[Any], size: int) -> Iterable[list[Any]]:
    step = max(1, int(size))
    for offset in range(0, len(values), step):
        yield values[offset : offset + step]


def _event_id(item: dict[str, Any]) -> str:
    value = item.get("id", item.get("event_id"))
    return str(value) if value not in (None, "") else ""


def _bookmaker_names_from_payload(payload: Any) -> list[str]:
    if isinstance(payload, list):
        values = payload
    elif isinstance(payload, dict):
        values = payload.get("bookmakers", payload.get("selected", payload))
        if isinstance(values, dict):
            return [
                str(key).strip()
                for key, enabled in values.items()
                if enabled not in (False, None, 0, "0", "false", "False") and str(key).strip()
            ]
        if not isinstance(values, list):
            values = []
    else:
        values = []
    result: list[str] = []
    for item in values:
        if isinstance(item, dict):
            value = item.get("name") or item.get("bookmaker") or item.get("slug") or item.get("id")
        else:
            value = item
        if str(value or "").strip():
            result.append(str(value).strip())
    return list(dict.fromkeys(result))


def _bookmaker_payload(event: dict[str, Any]) -> dict[str, Any]:
    bookmakers = event.get("bookmakers")
    return bookmakers if isinstance(bookmakers, dict) else {}


def _bookmaker_market_count(event: dict[str, Any], bookmaker: str) -> int:
    return len(_market_list(_bookmaker_payload(event).get(bookmaker)))


def _merge_event_payloads(payloads: list[dict[str, Any]], base_event: dict[str, Any] | None = None) -> dict[str, Any] | None:
    if not payloads and not base_event:
        return None
    merged: dict[str, Any] = dict(base_event or payloads[0])
    merged_bookmakers: dict[str, Any] = {}
    merged_urls: dict[str, Any] = {}
    for payload in payloads:
        for key, value in payload.items():
            if key not in {"bookmakers", "urls"} and value not in (None, "", [], {}):
                merged[key] = value
        merged_bookmakers.update(_bookmaker_payload(payload))
        if isinstance(payload.get("urls"), dict):
            merged_urls.update(payload["urls"])
    merged["bookmakers"] = merged_bookmakers
    if merged_urls:
        merged["urls"] = merged_urls
    return merged


class OddsApiIoService:
    """CPBL real-odds adapter with bookmaker discovery and safe degradation.

    Odds-API.io currently accepts the provider's exact bookmaker *name* in the
    `bookmakers` query parameter. V20.2 therefore resolves the official catalog
    entry automatically and records its provider identifier (numeric ID/slug/key
    when supplied, otherwise the exact official name) before sending requests.
    """

    def __init__(
        self,
        settings: Settings,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self.settings = settings
        self.enabled = settings.odds_api_io_enabled
        self.cache = AsyncTTLCache()
        self.last_check: dict[str, Any] = {}
        self.request_stats = {
            "network_requests": 0,
            "cache_hits": 0,
            "stale_served": 0,
            "errors": 0,
        }
        self.client = httpx.AsyncClient(
            timeout=settings.request_timeout_seconds,
            follow_redirects=True,
            trust_env=False,
            transport=transport,
            headers={"Accept": "application/json", "User-Agent": "DiamondMind-OddsApiIo/2.0"},
        )

    async def aclose(self) -> None:
        await self.client.aclose()

    def _stats_snapshot(self) -> dict[str, int]:
        return {key: int(value) for key, value in self.request_stats.items()}

    @staticmethod
    def _stats_delta(before: dict[str, int], after: dict[str, int]) -> dict[str, int]:
        return {key: int(after.get(key, 0)) - int(before.get(key, 0)) for key in after}

    def status(self) -> dict[str, Any]:
        return {
            "configured": self.enabled,
            "provider": "Odds-API.io",
            "base_url": self.settings.odds_api_io_base,
            "sport": self.settings.odds_api_io_cpbl_sport,
            "league_slug_override": self.settings.odds_api_io_cpbl_league_slug or None,
            "requested_bookmakers": self.settings.odds_api_io_cpbl_bookmakers,
            "odds_cache_ttl_seconds": self.settings.odds_api_io_cache_ttl_seconds,
            "request_stats": self._stats_snapshot(),
            "last_check": dict(self.last_check),
            "message": (
                "Odds-API.io 金鑰已設定；CPBL 只會使用供應商正式莊家識別值與真實盤口。"
                if self.enabled
                else "尚未設定 ODDS_API_IO_KEY。"
            ),
        }

    async def _get_json(
        self,
        path: str,
        params: dict[str, Any],
        *,
        ttl_seconds: int | None = None,
        stale_seconds: int | None = None,
    ) -> Any:
        if not self.enabled:
            raise OddsApiIoUpstreamError("Odds-API.io is not configured", path=path)
        safe_params = {key: value for key, value in params.items() if key != "apiKey"}
        cache_key = f"odds-api-io:{path}:{json.dumps(safe_params, sort_keys=True, ensure_ascii=True)}"
        cached = self.cache.get(cache_key)
        if cached and cached.is_fresh:
            self.request_stats["cache_hits"] += 1
            return cached.value
        async with self.cache.lock(cache_key):
            cached = self.cache.get(cache_key)
            if cached and cached.is_fresh:
                self.request_stats["cache_hits"] += 1
                return cached.value
            try:
                self.request_stats["network_requests"] += 1
                response = await self.client.get(
                    f"{self.settings.odds_api_io_base}/{path.lstrip('/')}",
                    params=params,
                )
            except httpx.RequestError as exc:
                self.request_stats["errors"] += 1
                if cached and cached.can_serve_stale:
                    self.request_stats["stale_served"] += 1
                    return cached.value
                raise OddsApiIoUpstreamError(
                    "Odds-API.io connection failed.",
                    path=path,
                    provider_detail=str(exc)[:300],
                ) from exc
            if response.status_code >= 400:
                self.request_stats["errors"] += 1
                if cached and cached.can_serve_stale:
                    self.request_stats["stale_served"] += 1
                    return cached.value
                detail = _provider_error_text(response)
                suffix = f" HTTP {response.status_code}"
                if detail:
                    suffix += f": {detail}"
                raise OddsApiIoUpstreamError(
                    f"Odds-API.io request rejected.{suffix}",
                    status_code=response.status_code,
                    path=path,
                    provider_detail=detail,
                )
            try:
                payload = response.json()
            except (ValueError, json.JSONDecodeError) as exc:
                self.request_stats["errors"] += 1
                if cached and cached.can_serve_stale:
                    self.request_stats["stale_served"] += 1
                    return cached.value
                raise OddsApiIoUpstreamError(
                    "Odds-API.io returned invalid JSON.",
                    status_code=response.status_code,
                    path=path,
                ) from exc
            ttl = self.settings.odds_api_io_cache_ttl_seconds if ttl_seconds is None else ttl_seconds
            stale = self.settings.odds_api_io_stale_ttl_seconds if stale_seconds is None else stale_seconds
            self.cache.set(cache_key, payload, ttl, stale)
            return payload

    @staticmethod
    def _looks_like_cpbl(item: dict[str, Any]) -> bool:
        name = str(item.get("name") or "")
        slug = str(item.get("slug") or "")
        canonical = _slug(f"{name} {slug}")
        if "cpbl" in canonical.split("-"):
            return True
        phrases = (
            "chinese-professional-baseball-league",
            "taiwan-professional-baseball",
            "taiwan-baseball-league",
        )
        return any(phrase in canonical for phrase in phrases)

    async def discover_cpbl(self) -> dict[str, Any]:
        if not self.enabled:
            return {"configured": False, "supported": False, "league": None, "leagues_checked": 0}
        override = self.settings.odds_api_io_cpbl_league_slug
        if override:
            league = {"name": "CPBL (configured override)", "slug": override, "eventsCount": None}
            return {"configured": True, "supported": True, "league": league, "leagues_checked": None, "source": "override"}
        payload = await self._get_json(
            "leagues",
            {
                "apiKey": self.settings.odds_api_io_key,
                "sport": self.settings.odds_api_io_cpbl_sport,
                "all": "true",
            },
            ttl_seconds=self.settings.odds_api_io_metadata_cache_ttl_seconds,
        )
        leagues = [item for item in payload if isinstance(item, dict)] if isinstance(payload, list) else []
        matched = next((item for item in leagues if self._looks_like_cpbl(item)), None)
        return {
            "configured": True,
            "supported": matched is not None,
            "league": matched,
            "leagues_checked": len(leagues),
            "source": "discovery",
            "possible_taiwan_leagues": [
                {
                    "name": item.get("name"),
                    "slug": item.get("slug"),
                    "eventsCount": item.get("eventsCount", item.get("eventCount")),
                }
                for item in leagues
                if "taiwan" in f"{item.get('name', '')} {item.get('slug', '')}".lower()
            ][:10],
        }

    @staticmethod
    def _catalog_ref(item: dict[str, Any]) -> dict[str, Any] | None:
        name = str(item.get("name") or "").strip()
        if not name:
            return None
        raw_id = item.get("id", item.get("key", item.get("slug")))
        provider_id = str(raw_id).strip() if raw_id not in (None, "") else name
        return {
            "name": name,
            "request_value": name,
            "provider_id": provider_id,
            "provider_id_source": "id" if item.get("id") not in (None, "") else "key" if item.get("key") not in (None, "") else "slug" if item.get("slug") not in (None, "") else "official_name",
            "active": item.get("active", True) is not False,
        }

    async def _usable_bookmakers(self) -> dict[str, Any]:
        """Resolve the provider's exact active bookmaker identifiers automatically."""

        preferred = list(dict.fromkeys(self.settings.odds_api_io_cpbl_bookmakers))
        available_payload = await self._get_json(
            "bookmakers",
            {},
            ttl_seconds=self.settings.odds_api_io_metadata_cache_ttl_seconds,
        )
        refs = [ref for item in (available_payload if isinstance(available_payload, list) else []) if isinstance(item, dict) and (ref := self._catalog_ref(item)) and ref["active"]]
        by_name = {str(ref["name"]).casefold(): ref for ref in refs}
        by_provider_id = {str(ref["provider_id"]).casefold(): ref for ref in refs}

        selected_names: list[str] = []
        selected_error: dict[str, Any] | None = None
        try:
            selected_payload = await self._get_json(
                "bookmakers/selected",
                {"apiKey": self.settings.odds_api_io_key},
                ttl_seconds=self.settings.odds_api_io_metadata_cache_ttl_seconds,
            )
            selected_names = _bookmaker_names_from_payload(selected_payload)
        except OddsApiIoUpstreamError as exc:
            selected_error = exc.diagnostic()

        def resolve(value: str) -> dict[str, Any] | None:
            token = value.casefold()
            return by_name.get(token) or by_provider_id.get(token)

        selected_refs = [ref for value in selected_names if (ref := resolve(value))]
        preferred_refs = [ref for value in preferred if (ref := resolve(value))]
        common = ["Bet365", "SingBet", "Pinnacle", "Unibet", "Betfair"]
        common_refs = [ref for value in common if (ref := resolve(value))]

        ordered: list[dict[str, Any]] = []
        seen: set[str] = set()
        # Selected books are most likely authorized for the account, then the
        # configured preferences, then common books, then the remaining catalog.
        for ref in [*selected_refs, *preferred_refs, *common_refs, *refs]:
            key = str(ref["name"]).casefold()
            if key not in seen:
                seen.add(key)
                ordered.append(dict(ref))
        max_books = max(1, int(self.settings.odds_api_io_cpbl_max_bookmakers))
        used = ordered[:max_books]
        selected_set = {value.casefold() for value in selected_names}
        for ref in used:
            ref["selected_for_account"] = str(ref["name"]).casefold() in selected_set or str(ref["provider_id"]).casefold() in selected_set
            ref["requested_preference"] = str(ref["name"]).casefold() in {value.casefold() for value in preferred}
        return {
            "requested": preferred,
            "available_count": len(refs),
            "selected": selected_names,
            "selected_error": selected_error,
            "used": used,
            "request_values": [ref["request_value"] for ref in used],
            "identifier_contract": "Odds-API.io /odds accepts exact bookmaker names; provider ID metadata is retained when the catalog supplies it.",
        }

    @staticmethod
    def _taipei_window(taiwan_date: date) -> tuple[str, str]:
        start = datetime.combine(taiwan_date, time.min, tzinfo=TAIPEI)
        end = start + timedelta(days=1)
        return (
            start.astimezone(timezone.utc).isoformat().replace("+00:00", "Z"),
            end.astimezone(timezone.utc).isoformat().replace("+00:00", "Z"),
        )

    @staticmethod
    def _matching_date_events(payload: Any, taiwan_date: date) -> list[dict[str, Any]]:
        rows = [item for item in payload if isinstance(item, dict)] if isinstance(payload, list) else []
        result: list[dict[str, Any]] = []
        for event in rows:
            commence = _parse_datetime(event.get("date") or event.get("commence_time"))
            if commence and commence.astimezone(TAIPEI).date() == taiwan_date:
                result.append(event)
        return result

    @staticmethod
    def _bookmaker_diagnostic(ref: dict[str, Any]) -> dict[str, Any]:
        return {
            "name": ref.get("name"),
            "provider_id": ref.get("provider_id"),
            "provider_id_source": ref.get("provider_id_source"),
            "selected_for_account": bool(ref.get("selected_for_account")),
            "requested_preference": bool(ref.get("requested_preference")),
            "events_found": 0,
            "events_returned_with_odds": 0,
            "markets": {"moneyline": 0, "run_line": 0, "totals": 0},
            "attempts": {"events_filter": 0, "multi": 0, "single_group": 0, "single_bookmaker": 0},
            "status": "not_checked",
            "errors": [],
        }

    @staticmethod
    def _record_error(target: dict[str, Any], *, stage: str, error: OddsApiIoUpstreamError, event_id: str | None = None) -> None:
        row = {"stage": stage, **error.diagnostic()}
        if event_id:
            row["event_id"] = event_id
        target.setdefault("errors", []).append(row)
        target["status"] = "error"

    async def _events_by_bookmaker(
        self,
        taiwan_date: date,
        league_slug: str,
        from_utc: str,
        to_utc: str,
        refs: list[dict[str, Any]],
        bookmaker_diagnostics: dict[str, dict[str, Any]],
    ) -> tuple[dict[str, dict[str, Any]], dict[str, set[str]]]:
        events_by_id: dict[str, dict[str, Any]] = {}
        event_bookmakers: dict[str, set[str]] = defaultdict(set)
        for ref in refs:
            name = str(ref["request_value"])
            diagnostic = bookmaker_diagnostics[name]
            diagnostic["attempts"]["events_filter"] += 1
            try:
                payload = await self._get_json(
                    "events",
                    {
                        "apiKey": self.settings.odds_api_io_key,
                        "sport": self.settings.odds_api_io_cpbl_sport,
                        "league": league_slug,
                        "status": "pending",
                        "from": from_utc,
                        "to": to_utc,
                        "bookmaker": name,
                    },
                    ttl_seconds=self.settings.odds_api_io_events_cache_ttl_seconds,
                )
            except OddsApiIoUpstreamError as exc:
                self._record_error(diagnostic, stage="events_filter", error=exc)
                continue
            events = self._matching_date_events(payload, taiwan_date)
            diagnostic["events_found"] = len(events)
            diagnostic["status"] = "events_found" if events else "no_cpbl_events"
            for event in events:
                event_key = _event_id(event)
                if not event_key:
                    continue
                events_by_id.setdefault(event_key, event)
                event_bookmakers[event_key].add(name)
        return events_by_id, event_bookmakers

    @staticmethod
    def _payloads_from_response(payload: Any) -> list[dict[str, Any]]:
        if isinstance(payload, dict):
            return [payload]
        if isinstance(payload, list):
            return [item for item in payload if isinstance(item, dict)]
        return []

    async def _single_event_odds(
        self,
        event_id: str,
        bookmakers: list[str],
        bookmaker_diagnostics: dict[str, dict[str, Any]],
    ) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
        errors: list[dict[str, Any]] = []
        payloads: list[dict[str, Any]] = []
        if not bookmakers:
            return payloads, errors
        for name in bookmakers:
            bookmaker_diagnostics[name]["attempts"]["single_group"] += 1
        try:
            payload = await self._get_json(
                "odds",
                {
                    "apiKey": self.settings.odds_api_io_key,
                    "eventId": event_id,
                    "bookmakers": ",".join(bookmakers),
                },
            )
            payloads.extend(self._payloads_from_response(payload))
        except OddsApiIoUpstreamError as exc:
            errors.append({"stage": "odds_single_group", "event_id": event_id, "bookmakers": bookmakers, **exc.diagnostic()})
            for name in bookmakers:
                self._record_error(bookmaker_diagnostics[name], stage="odds_single_group", error=exc, event_id=event_id)

        present = {
            name.casefold()
            for payload in payloads
            for name in _bookmaker_payload(payload)
        }
        missing = [name for name in bookmakers if name.casefold() not in present]
        for bookmaker in missing:
            diagnostic = bookmaker_diagnostics[bookmaker]
            diagnostic["attempts"]["single_bookmaker"] += 1
            try:
                payload = await self._get_json(
                    "odds",
                    {
                        "apiKey": self.settings.odds_api_io_key,
                        "eventId": event_id,
                        "bookmakers": bookmaker,
                    },
                )
                rows = self._payloads_from_response(payload)
                if rows:
                    payloads.extend(rows)
                else:
                    diagnostic["status"] = "empty_odds_response"
            except OddsApiIoUpstreamError as exc:
                errors.append({"stage": "odds_single_bookmaker", "event_id": event_id, "bookmaker": bookmaker, **exc.diagnostic()})
                self._record_error(diagnostic, stage="odds_single_bookmaker", error=exc, event_id=event_id)
        return payloads, errors

    async def _fetch_grouped_odds(
        self,
        events_by_id: dict[str, dict[str, Any]],
        event_bookmakers: dict[str, set[str]],
        refs: list[dict[str, Any]],
        bookmaker_diagnostics: dict[str, dict[str, Any]],
    ) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]]]:
        event_ids = list(events_by_id)
        if not event_ids or not refs:
            return [], [], []
        bookmaker_names = [str(ref["request_value"]) for ref in refs]
        by_event_payloads: dict[str, list[dict[str, Any]]] = defaultdict(list)
        errors: list[dict[str, Any]] = []
        batch_diagnostics: list[dict[str, Any]] = []
        group_size = max(1, min(30, int(self.settings.odds_api_io_bookmaker_group_size)))

        for id_batch in _chunks(event_ids, 10):
            for bookmaker_group in _chunks(bookmaker_names, group_size):
                expected_by_event = {
                    event_id: [
                        name
                        for name in bookmaker_group
                        if not event_bookmakers.get(event_id) or name in event_bookmakers[event_id]
                    ]
                    for event_id in id_batch
                }
                expected_names = sorted({name for values in expected_by_event.values() for name in values})
                if not expected_names:
                    continue
                for name in expected_names:
                    bookmaker_diagnostics[name]["attempts"]["multi"] += 1
                row = {
                    "event_ids": list(id_batch),
                    "bookmakers": expected_names,
                    "endpoint": "odds/multi",
                    "status": "pending",
                    "events_returned": 0,
                    "fallback_events": [],
                    "error": None,
                }
                returned_payloads: list[dict[str, Any]] = []
                try:
                    payload = await self._get_json(
                        "odds/multi",
                        {
                            "apiKey": self.settings.odds_api_io_key,
                            "eventIds": ",".join(id_batch),
                            "bookmakers": ",".join(expected_names),
                        },
                    )
                    returned_payloads = self._payloads_from_response(payload)
                    row["status"] = "ok" if returned_payloads else "empty"
                    row["events_returned"] = len(returned_payloads)
                except OddsApiIoUpstreamError as exc:
                    row["status"] = "error"
                    row["error"] = exc.diagnostic()
                    errors.append({"stage": "odds_multi", "event_ids": id_batch, "bookmakers": expected_names, **exc.diagnostic()})
                    for name in expected_names:
                        self._record_error(bookmaker_diagnostics[name], stage="odds_multi", error=exc)

                returned_by_id: dict[str, list[dict[str, Any]]] = defaultdict(list)
                for payload in returned_payloads:
                    key = _event_id(payload)
                    if key:
                        returned_by_id[key].append(payload)
                        by_event_payloads[key].append(payload)

                for event_id in id_batch:
                    expected_for_event = expected_by_event[event_id]
                    present_for_event = {
                        name.casefold()
                        for payload in returned_by_id.get(event_id, [])
                        for name in _bookmaker_payload(payload)
                    }
                    missing_for_event = [name for name in expected_for_event if name.casefold() not in present_for_event]
                    if not returned_by_id.get(event_id) or missing_for_event:
                        fallback_names = missing_for_event or expected_for_event
                        if fallback_names:
                            row["fallback_events"].append({"event_id": event_id, "bookmakers": fallback_names})
                            single_payloads, single_errors = await self._single_event_odds(
                                event_id,
                                fallback_names,
                                bookmaker_diagnostics,
                            )
                            errors.extend(single_errors)
                            by_event_payloads[event_id].extend(single_payloads)
                batch_diagnostics.append(row)

        full_events: list[dict[str, Any]] = []
        for event_id, base_event in events_by_id.items():
            merged = _merge_event_payloads(by_event_payloads.get(event_id, []), base_event)
            if merged:
                full_events.append(merged)
        return full_events, errors, batch_diagnostics

    @staticmethod
    def _source(bookmaker: str, market: dict[str, Any], bookmaker_ref: dict[str, Any] | None = None) -> dict[str, Any]:
        ref = bookmaker_ref or {}
        return {
            "type": "real_bookmaker",
            "provider": "Odds-API.io",
            "bookmaker_key": _slug(bookmaker),
            "bookmaker": bookmaker,
            "bookmaker_id": ref.get("provider_id") or bookmaker,
            "bookmaker_id_source": ref.get("provider_id_source") or "official_name",
            "last_update": market.get("updatedAt") or market.get("updated_at"),
        }

    @staticmethod
    def _best_offer(offers: list[dict[str, Any]], key: str) -> dict[str, Any] | None:
        usable = [offer for offer in offers if _number(offer.get(key)) is not None and float(offer[key]) > 1.0]
        return max(usable, key=lambda offer: float(offer[key])) if usable else None

    @staticmethod
    def _best_line(offers: list[dict[str, Any]], line_key: str, *, target: float | None = None) -> float | None:
        lines = [round(float(offer[line_key]), 4) for offer in offers if _number(offer.get(line_key)) is not None]
        if not lines:
            return None
        counts = Counter(lines)
        return max(
            counts,
            key=lambda line: (
                counts[line],
                -abs(abs(line) - target) if target is not None else 0,
                -abs(line),
            ),
        )

    def _normalize_odds_event(
        self,
        event: dict[str, Any],
        bookmaker_refs: dict[str, dict[str, Any]],
    ) -> dict[str, Any] | None:
        commence = _parse_datetime(event.get("date") or event.get("commence_time"))
        home_name = event.get("home") or event.get("home_team")
        away_name = event.get("away") or event.get("away_team")
        if commence is None or not home_name or not away_name:
            return None

        moneyline_offers: list[dict[str, Any]] = []
        spread_offers: list[dict[str, Any]] = []
        totals_offers: list[dict[str, Any]] = []
        bookmakers = _bookmaker_payload(event)
        preferred = [name.casefold() for name in self.settings.odds_api_io_cpbl_bookmakers]
        ordered_names = sorted(
            bookmakers,
            key=lambda name: preferred.index(name.casefold()) if name.casefold() in preferred else len(preferred),
        )
        for bookmaker in ordered_names:
            raw_markets = _market_list(bookmakers.get(bookmaker))
            ref = bookmaker_refs.get(bookmaker.casefold())
            for market in raw_markets:
                market_name = _slug(market.get("name"))
                source = self._source(bookmaker, market, ref)
                for row in _market_rows(market):
                    if market_name in {"ml", "moneyline", "money-line", "h2h", "match-winner"}:
                        home_decimal = _number(row.get("home"))
                        away_decimal = _number(row.get("away"))
                        if home_decimal and away_decimal and home_decimal > 1.0 and away_decimal > 1.0:
                            moneyline_offers.append({"home_decimal": home_decimal, "away_decimal": away_decimal, "source": source})
                    elif market_name in {"spread", "spreads", "run-line", "runline", "asian-handicap", "handicap"}:
                        home_point = _number(row.get("hdp", row.get("handicap", row.get("line"))))
                        home_decimal = _number(row.get("home"))
                        away_decimal = _number(row.get("away"))
                        if home_point is not None and home_decimal and away_decimal and home_decimal > 1.0 and away_decimal > 1.0:
                            spread_offers.append({
                                "home_point": home_point,
                                "away_point": -home_point,
                                "home_decimal": home_decimal,
                                "away_decimal": away_decimal,
                                "source": source,
                            })
                    elif market_name in {"totals", "total", "over-under", "overunder", "total-runs"}:
                        total = _number(row.get("hdp", row.get("total", row.get("line"))))
                        over_decimal = _number(row.get("over"))
                        under_decimal = _number(row.get("under"))
                        if total is not None and over_decimal and under_decimal and over_decimal > 1.0 and under_decimal > 1.0:
                            totals_offers.append({
                                "total": total,
                                "over_decimal": over_decimal,
                                "under_decimal": under_decimal,
                                "source": source,
                            })

        markets: dict[str, Any] = {}
        if moneyline_offers:
            best_home = self._best_offer(moneyline_offers, "home_decimal")
            best_away = self._best_offer(moneyline_offers, "away_decimal")
            if best_home and best_away:
                markets["moneyline"] = {
                    **best_home["source"],
                    "home_price": _decimal_to_american(best_home["home_decimal"]),
                    "away_price": _decimal_to_american(best_away["away_decimal"]),
                    "home_decimal_odds": round(float(best_home["home_decimal"]), 4),
                    "away_decimal_odds": round(float(best_away["away_decimal"]), 4),
                    "home_source": best_home["source"],
                    "away_source": best_away["source"],
                    "offer_count": len(moneyline_offers),
                    "bookmaker_count": len({offer["source"]["bookmaker"] for offer in moneyline_offers}),
                    "best_odds": True,
                }

        spread_line = self._best_line(spread_offers, "home_point", target=1.5)
        if spread_line is not None:
            line_offers = [offer for offer in spread_offers if round(float(offer["home_point"]), 4) == spread_line]
            best_home = self._best_offer(line_offers, "home_decimal")
            best_away = self._best_offer(line_offers, "away_decimal")
            if best_home and best_away:
                markets["run_line"] = {
                    **best_home["source"],
                    "home": {
                        "point": float(spread_line),
                        "price": _decimal_to_american(best_home["home_decimal"]),
                        "decimal_odds": round(float(best_home["home_decimal"]), 4),
                        "source": best_home["source"],
                    },
                    "away": {
                        "point": -float(spread_line),
                        "price": _decimal_to_american(best_away["away_decimal"]),
                        "decimal_odds": round(float(best_away["away_decimal"]), 4),
                        "source": best_away["source"],
                    },
                    "home_source": best_home["source"],
                    "away_source": best_away["source"],
                    "offer_count": len(line_offers),
                    "bookmaker_count": len({offer["source"]["bookmaker"] for offer in line_offers}),
                    "available_lines": sorted({float(offer["home_point"]) for offer in spread_offers}),
                    "best_odds": True,
                }

        total_line = self._best_line(totals_offers, "total")
        if total_line is not None:
            line_offers = [offer for offer in totals_offers if round(float(offer["total"]), 4) == total_line]
            best_over = self._best_offer(line_offers, "over_decimal")
            best_under = self._best_offer(line_offers, "under_decimal")
            if best_over and best_under:
                markets["totals"] = {
                    **best_over["source"],
                    "total": float(total_line),
                    "over_price": _decimal_to_american(best_over["over_decimal"]),
                    "under_price": _decimal_to_american(best_under["under_decimal"]),
                    "over_decimal_odds": round(float(best_over["over_decimal"]), 4),
                    "under_decimal_odds": round(float(best_under["under_decimal"]), 4),
                    "over_source": best_over["source"],
                    "under_source": best_under["source"],
                    "offer_count": len(line_offers),
                    "bookmaker_count": len({offer["source"]["bookmaker"] for offer in line_offers}),
                    "available_lines": sorted({float(offer["total"]) for offer in totals_offers}),
                    "best_odds": True,
                }

        taipei = commence.astimezone(TAIPEI)
        league = event.get("league") if isinstance(event.get("league"), dict) else {}
        return {
            "event_id": event.get("id"),
            "sport_key": "baseball_cpbl",
            "provider_sport": (event.get("sport") or {}).get("slug") if isinstance(event.get("sport"), dict) else self.settings.odds_api_io_cpbl_sport,
            "provider_league": league.get("slug"),
            "commence_time": commence.astimezone(timezone.utc).isoformat().replace("+00:00", "Z"),
            "date_taiwan": taipei.date().isoformat(),
            "time_taiwan": taipei.strftime("%H:%M"),
            "away_team": away_name,
            "home_team": home_name,
            "markets": markets,
            "bookmaker_count": len(bookmakers),
            "raw_market_offer_counts": {
                "moneyline": len(moneyline_offers),
                "run_line": len(spread_offers),
                "totals": len(totals_offers),
            },
        }

    @staticmethod
    def _update_bookmaker_market_diagnostics(
        full_events: list[dict[str, Any]],
        diagnostics: dict[str, dict[str, Any]],
    ) -> None:
        market_aliases = {
            "ml": "moneyline",
            "moneyline": "moneyline",
            "money-line": "moneyline",
            "h2h": "moneyline",
            "spread": "run_line",
            "spreads": "run_line",
            "run-line": "run_line",
            "runline": "run_line",
            "asian-handicap": "run_line",
            "totals": "totals",
            "total": "totals",
            "over-under": "totals",
            "overunder": "totals",
        }
        for event in full_events:
            for bookmaker, raw_markets in _bookmaker_payload(event).items():
                diagnostic = diagnostics.get(bookmaker)
                if not diagnostic:
                    continue
                if _market_list(raw_markets):
                    diagnostic["events_returned_with_odds"] += 1
                seen_markets: set[str] = set()
                for market in _market_list(raw_markets):
                    canonical = market_aliases.get(_slug(market.get("name")))
                    if canonical and _market_rows(market):
                        seen_markets.add(canonical)
                for market in seen_markets:
                    diagnostic["markets"][market] += 1
        for diagnostic in diagnostics.values():
            if diagnostic["events_returned_with_odds"] > 0 and any(diagnostic["markets"].values()):
                diagnostic["status"] = "markets_available"
            elif diagnostic["events_found"] > 0 and not diagnostic["errors"]:
                diagnostic["status"] = "events_found_no_markets"
            elif diagnostic["status"] == "not_checked":
                diagnostic["status"] = "no_result"

    async def odds_for_cpbl_date(self, taiwan_date: date) -> dict[str, Any]:
        checked_at = _iso_utc()
        stats_before = self._stats_snapshot()
        discovery = await self.discover_cpbl()
        zero_coverage = {"moneyline": 0, "run_line": 0, "totals": 0}
        if not discovery.get("supported"):
            self.last_check = {
                "checked_at": checked_at,
                "date": taiwan_date.isoformat(),
                "supported": False,
                "league": None,
                "events": 0,
                "count": 0,
                "coverage": zero_coverage,
            }
            return {
                "date": taiwan_date.isoformat(),
                "timezone": "Asia/Taipei",
                "configured": True,
                "count": 0,
                "items": [],
                "meta": {
                    "provider": "Odds-API.io",
                    "fresh_for_model": True,
                    "cache": "60_second_odds_cache",
                    "coverage": zero_coverage,
                    "coverage_status": "cpbl_not_listed",
                    "discovery": discovery,
                    "real_odds_only": True,
                },
            }

        league = discovery.get("league") or {}
        league_slug = str(league.get("slug") or "").strip()
        from_utc, to_utc = self._taipei_window(taiwan_date)
        events_payload = await self._get_json(
            "events",
            {
                "apiKey": self.settings.odds_api_io_key,
                "sport": self.settings.odds_api_io_cpbl_sport,
                "league": league_slug,
                "status": "pending",
                "from": from_utc,
                "to": to_utc,
            },
            ttl_seconds=self.settings.odds_api_io_events_cache_ttl_seconds,
        )
        general_events = self._matching_date_events(events_payload, taiwan_date)
        events_by_id = {_event_id(item): item for item in general_events if _event_id(item)}

        odds_errors: list[dict[str, Any]] = []
        batch_diagnostics: list[dict[str, Any]] = []
        try:
            bookmaker_info = await self._usable_bookmakers()
        except OddsApiIoUpstreamError as exc:
            bookmaker_info = {
                "requested": self.settings.odds_api_io_cpbl_bookmakers,
                "available_count": 0,
                "selected": [],
                "used": [],
                "request_values": [],
                "error": exc.diagnostic(),
            }
            odds_errors.append({"stage": "bookmakers", **exc.diagnostic()})

        refs = [item for item in bookmaker_info.get("used") or [] if isinstance(item, dict) and item.get("request_value")]
        bookmaker_diagnostics = {
            str(ref["request_value"]): self._bookmaker_diagnostic(ref)
            for ref in refs
        }
        probed_events, event_bookmakers = await self._events_by_bookmaker(
            taiwan_date,
            league_slug,
            from_utc,
            to_utc,
            refs,
            bookmaker_diagnostics,
        )
        for event_id, event in probed_events.items():
            events_by_id.setdefault(event_id, event)

        full_events, fetch_errors, batch_diagnostics = await self._fetch_grouped_odds(
            events_by_id,
            event_bookmakers,
            refs,
            bookmaker_diagnostics,
        )
        odds_errors.extend(fetch_errors)
        self._update_bookmaker_market_diagnostics(full_events, bookmaker_diagnostics)

        refs_by_name = {str(ref["name"]).casefold(): ref for ref in refs}
        normalized_all = [self._normalize_odds_event(item, refs_by_name) for item in full_events]
        normalized_all = [item for item in normalized_all if item is not None]
        # A feed item is considered real odds only when at least one normalized
        # market exists. This prevents empty provider events from unlocking Pro.
        items = [item for item in normalized_all if item.get("markets")]
        items.sort(key=lambda item: item.get("commence_time") or "")
        coverage = {
            "moneyline": sum(1 for item in items if "moneyline" in (item.get("markets") or {})),
            "run_line": sum(1 for item in items if "run_line" in (item.get("markets") or {})),
            "totals": sum(1 for item in items if "totals" in (item.get("markets") or {})),
        }
        any_market = any(coverage.values())
        events_found = len(events_by_id)
        if any_market:
            coverage_status = "available"
        elif events_found and odds_errors:
            coverage_status = "odds_request_rejected"
        elif events_found:
            coverage_status = "events_found_no_odds"
        else:
            coverage_status = "no_events"

        stats_after = self._stats_snapshot()
        cache_diagnostics = {
            "policy": "odds responses cached for 60 seconds; metadata and events use longer safe caches",
            "odds_ttl_seconds": self.settings.odds_api_io_cache_ttl_seconds,
            "events_ttl_seconds": self.settings.odds_api_io_events_cache_ttl_seconds,
            "metadata_ttl_seconds": self.settings.odds_api_io_metadata_cache_ttl_seconds,
            "request_delta": self._stats_delta(stats_before, stats_after),
            "request_totals": stats_after,
        }
        last_error = odds_errors[-1] if odds_errors else None
        bookmaker_rows = list(bookmaker_diagnostics.values())
        self.last_check = {
            "checked_at": checked_at,
            "date": taiwan_date.isoformat(),
            "supported": True,
            "league": league,
            "events": events_found,
            "count": len(items),
            "coverage": coverage,
            "coverage_status": coverage_status,
            "bookmakers": bookmaker_info,
            "bookmaker_results": bookmaker_rows,
            "last_error": last_error,
            "cache": cache_diagnostics,
        }
        return {
            "date": taiwan_date.isoformat(),
            "timezone": "Asia/Taipei",
            "configured": True,
            "count": len(items),
            "items": items,
            "meta": {
                "provider": "Odds-API.io",
                "fresh_for_model": True,
                "cache": "60_second_odds_cache",
                "cache_diagnostics": cache_diagnostics,
                "coverage": coverage,
                "coverage_status": coverage_status,
                "events_found": events_found,
                "events_with_provider_payload": len(full_events),
                "events_with_real_markets": len(items),
                "sport_key": "baseball_cpbl",
                "provider_league": league_slug,
                "bookmakers": bookmaker_info,
                "bookmaker_results": bookmaker_rows,
                "batch_results": batch_diagnostics,
                "odds_errors": odds_errors[-30:],
                "discovery": discovery,
                "query_window": {"from": from_utc, "to": to_utc},
                "updated_at": checked_at,
                "quota": {},
                "real_odds_only": True,
                "best_odds": True,
                "pro_publish_gate": "at_least_one_normalized_real_bookmaker_market",
            },
        }
