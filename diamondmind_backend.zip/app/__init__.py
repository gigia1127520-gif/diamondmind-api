"""DiamondMind API package."""

