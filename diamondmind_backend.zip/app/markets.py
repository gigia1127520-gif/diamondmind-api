from __future__ import annotations

import math
import re
from datetime import datetime, timezone
from typing import Any


def _number(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def american_implied_probability(price: Any) -> float | None:
    value = _number(price)
    if value is None or value == 0:
        return None
    if value < 0:
        return -value / (-value + 100.0)
    return 100.0 / (value + 100.0)


def american_to_decimal(price: Any) -> float | None:
    value = _number(price)
    if value is None or value == 0:
        return None
    if value < 0:
        return 1.0 + 100.0 / -value
    return 1.0 + value / 100.0


def decimal_to_american(decimal_odds: float) -> int | None:
    if decimal_odds <= 1.0:
        return None
    if decimal_odds >= 2.0:
        return round((decimal_odds - 1.0) * 100.0)
    return round(-100.0 / (decimal_odds - 1.0))


def _no_vig_pair(first_price: Any, second_price: Any) -> tuple[float, float] | None:
    first = american_implied_probability(first_price)
    second = american_implied_probability(second_price)
    if first is None or second is None or first + second <= 0:
        return None
    total = first + second
    return first / total, second / total


def _normal_cdf(value: float) -> float:
    return 0.5 * (1.0 + math.erf(value / math.sqrt(2.0)))


def _canonical_team(value: Any) -> str:
    normalized = re.sub(r"[^a-z0-9]+", " ", str(value or "").lower()).strip()
    aliases = {
        "oakland athletics": "athletics",
        "sacramento athletics": "athletics",
        "a s": "athletics",
    }
    return aliases.get(normalized, normalized)


def match_odds_event(
    analysis: dict[str, Any],
    odds_items: list[dict[str, Any]],
) -> dict[str, Any] | None:
    game = analysis.get("game") or {}
    away = _canonical_team((game.get("away") or {}).get("name"))
    home = _canonical_team((game.get("home") or {}).get("name"))
    for event in odds_items:
        if (
            _canonical_team(event.get("away_team")) == away
            and _canonical_team(event.get("home_team")) == home
        ):
            return event
    return None


def _source(market: dict[str, Any]) -> dict[str, Any]:
    return {
        "bookmaker_key": market.get("bookmaker_key"),
        "bookmaker": market.get("bookmaker"),
        "last_update": market.get("last_update"),
    }


def _team_for_side(analysis: dict[str, Any], side: str) -> tuple[dict[str, Any], dict[str, Any]]:
    game = analysis["game"]
    picked = game[side]
    opponent = game["away" if side == "home" else "home"]
    return picked, opponent


def _base_selection(
    analysis: dict[str, Any],
    *,
    market: str,
    pick: dict[str, Any],
    opponent: dict[str, Any] | None,
    probability: float,
    implied_probability: float,
    price: float | int,
    market_source: dict[str, Any],
    summary: str,
    model_version: str,
    minimum_probability: float,
    minimum_edge: float,
    minimum_projection_quality: float = 0.0,
) -> dict[str, Any]:
    edge_points = (probability - implied_probability) * 100.0
    projection_quality = float((analysis.get("projections") or {}).get("quality") or 0.0)
    qualifies = (
        probability * 100.0 >= minimum_probability
        and edge_points >= minimum_edge
        and projection_quality >= minimum_projection_quality
    )
    decimal_odds = american_to_decimal(price)
    return {
        "game_pk": analysis["game_pk"],
        "matchup": analysis["matchup"],
        "game_date": analysis["game_date"],
        "time_taiwan": analysis["time_taiwan"],
        "market": market,
        "pick": pick,
        "opponent": opponent,
        "confidence": round(probability * 100.0, 1),
        "model_probability": round(probability * 100.0, 1),
        "implied_probability": round(implied_probability * 100.0, 1),
        "edge": round(edge_points, 1),
        "price": int(price) if float(price).is_integer() else price,
        "decimal_odds": round(decimal_odds, 3) if decimal_odds is not None else None,
        "data_quality": analysis.get("data_quality"),
        "projection_quality": (analysis.get("projections") or {}).get("quality"),
        "factors": analysis.get("factors") or [],
        "projections": analysis.get("projections") or {},
        "summary": summary,
        "model_version": model_version,
        "odds_source": market_source,
        "game": analysis["game"],
        "meets_threshold": qualifies,
        "rank_score": round(edge_points + (probability - 0.5) * 20.0 + float(analysis.get("data_quality") or 0) * 2.0, 3),
    }


def moneyline_candidate(
    analysis: dict[str, Any],
    event: dict[str, Any],
    *,
    minimum_probability: float,
    minimum_edge: float,
) -> dict[str, Any] | None:
    market = (event.get("markets") or {}).get("moneyline") or {}
    away_price = _number(market.get("away_price"))
    home_price = _number(market.get("home_price"))
    no_vig = _no_vig_pair(away_price, home_price)
    if away_price is None or home_price is None or no_vig is None:
        return None

    side = "home" if float(analysis.get("home_probability") or 0) >= float(analysis.get("away_probability") or 0) else "away"
    probability = float(analysis[f"{side}_probability"]) / 100.0
    implied = no_vig[1] if side == "home" else no_vig[0]
    price = home_price if side == "home" else away_price
    picked, opponent_team = _team_for_side(analysis, side)
    pick = {
        "team_id": picked.get("id"),
        "team_name": picked.get("name"),
        "abbr": picked.get("abbr"),
        "market": "moneyline",
        "side": side,
        "line": None,
        "price": price,
        "label": f'{picked.get("abbr")} 獨贏',
    }
    opponent = {
        "team_id": opponent_team.get("id"),
        "team_name": opponent_team.get("name"),
        "abbr": opponent_team.get("abbr"),
    }
    edge = (probability - implied) * 100.0
    summary = f"模型勝率 {probability * 100:.1f}%，較無水位市場機率高 {edge:.1f} 個百分點。"
    return _base_selection(
        analysis,
        market="moneyline",
        pick=pick,
        opponent=opponent,
        probability=probability,
        implied_probability=implied,
        price=price,
        market_source=_source(market),
        summary=summary,
        model_version="dm-moneyline-value-v1.0",
        minimum_probability=minimum_probability,
        minimum_edge=minimum_edge,
    )


def run_line_candidate(
    analysis: dict[str, Any],
    event: dict[str, Any],
    *,
    minimum_probability: float,
    minimum_edge: float,
    minimum_projection_quality: float = 0.45,
) -> dict[str, Any] | None:
    market = (event.get("markets") or {}).get("run_line") or {}
    away = market.get("away") or {}
    home = market.get("home") or {}
    away_point = _number(away.get("point"))
    home_point = _number(home.get("point"))
    away_price = _number(away.get("price"))
    home_price = _number(home.get("price"))
    no_vig = _no_vig_pair(away_price, home_price)
    projected_margin = _number((analysis.get("projections") or {}).get("home_margin"))
    if None in {away_point, home_point, away_price, home_price, projected_margin} or no_vig is None:
        return None

    margin_sigma = 3.55
    home_cover = _normal_cdf((projected_margin + home_point) / margin_sigma)
    away_cover = _normal_cdf((-projected_margin + away_point) / margin_sigma)
    choices = [
        ("away", away_cover, no_vig[0], away_point, away_price),
        ("home", home_cover, no_vig[1], home_point, home_price),
    ]
    side, probability, implied, point, price = max(choices, key=lambda item: item[1] - item[2])
    picked, opponent_team = _team_for_side(analysis, side)
    point_label = f"{point:+g}"
    pick = {
        "team_id": picked.get("id"),
        "team_name": picked.get("name"),
        "abbr": picked.get("abbr"),
        "market": "run_line",
        "side": side,
        "line": point,
        "price": price,
        "label": f'{picked.get("abbr")} {point_label}',
    }
    opponent = {
        "team_id": opponent_team.get("id"),
        "team_name": opponent_team.get("name"),
        "abbr": opponent_team.get("abbr"),
    }
    edge = (probability - implied) * 100.0
    summary = f"模型預估主隊勝分差 {projected_margin:+.2f}，此讓分方向相對市場具 {edge:.1f} 個百分點優勢。"
    return _base_selection(
        analysis,
        market="run_line",
        pick=pick,
        opponent=opponent,
        probability=probability,
        implied_probability=implied,
        price=price,
        market_source=_source(market),
        summary=summary,
        model_version="dm-run-line-v1.0",
        minimum_probability=minimum_probability,
        minimum_edge=minimum_edge,
        minimum_projection_quality=minimum_projection_quality,
    )


def totals_candidate(
    analysis: dict[str, Any],
    event: dict[str, Any],
    *,
    minimum_probability: float,
    minimum_edge: float,
    minimum_projection_quality: float = 0.45,
) -> dict[str, Any] | None:
    market = (event.get("markets") or {}).get("totals") or {}
    total = _number(market.get("total"))
    over_price = _number(market.get("over_price"))
    under_price = _number(market.get("under_price"))
    projected_total = _number((analysis.get("projections") or {}).get("total_runs"))
    projection_quality = _number((analysis.get("projections") or {}).get("quality"))
    no_vig = _no_vig_pair(over_price, under_price)
    if None in {total, over_price, under_price, projected_total} or no_vig is None:
        return None

    total_sigma = 3.15 + (1.0 - (projection_quality or 0.0)) * 0.55
    under_probability = _normal_cdf((total - projected_total) / total_sigma)
    over_probability = 1.0 - under_probability
    choices = [
        ("over", over_probability, no_vig[0], over_price),
        ("under", under_probability, no_vig[1], under_price),
    ]
    side, probability, implied, price = max(choices, key=lambda item: item[1] - item[2])
    side_zh = "大" if side == "over" else "小"
    pick = {
        "team_id": None,
        "team_name": None,
        "abbr": None,
        "market": "totals",
        "side": side,
        "line": total,
        "price": price,
        "label": f"{side_zh} {total:g}",
    }
    edge = (probability - implied) * 100.0
    summary = f"模型預估總分 {projected_total:.2f}，相對 {total:g} 分盤口偏向{side_zh}分，市場優勢 {edge:.1f} 個百分點。"
    return _base_selection(
        analysis,
        market="totals",
        pick=pick,
        opponent=None,
        probability=probability,
        implied_probability=implied,
        price=price,
        market_source=_source(market),
        summary=summary,
        model_version="dm-totals-v1.0",
        minimum_probability=minimum_probability,
        minimum_edge=minimum_edge,
        minimum_projection_quality=minimum_projection_quality,
    )


def _public_moneyline(
    public_selection: dict[str, Any] | None,
    moneyline_candidates: list[dict[str, Any]],
) -> dict[str, Any] | None:
    if not public_selection:
        return None
    matched = next(
        (item for item in moneyline_candidates if item["game_pk"] == public_selection.get("game_pk")),
        None,
    )
    if not matched:
        return public_selection
    result = {**public_selection}
    result.update(
        {
            "price": matched.get("price"),
            "decimal_odds": matched.get("decimal_odds"),
            "implied_probability": matched.get("implied_probability"),
            "edge": matched.get("edge"),
            "odds_source": matched.get("odds_source"),
        }
    )
    result["pick"] = {**(public_selection.get("pick") or {}), **(matched.get("pick") or {})}
    return result


def _build_parlay(candidates: list[dict[str, Any]], size: int) -> dict[str, Any] | None:
    best_per_game: dict[int, dict[str, Any]] = {}
    for candidate in candidates:
        game_pk = int(candidate["game_pk"])
        existing = best_per_game.get(game_pk)
        if not existing or float(candidate["rank_score"]) > float(existing["rank_score"]):
            best_per_game[game_pk] = candidate
    legs = sorted(best_per_game.values(), key=lambda item: item["rank_score"], reverse=True)[:size]
    if len(legs) < size:
        return None

    combined_decimal = math.prod(float(leg["decimal_odds"]) for leg in legs if leg.get("decimal_odds"))
    combined_probability = math.prod(float(leg["model_probability"]) / 100.0 for leg in legs)
    return {
        "market": f"{size}_leg",
        "label": f"{size}關串關",
        "legs": legs,
        "combined_decimal_odds": round(combined_decimal, 2),
        "combined_american_odds": decimal_to_american(combined_decimal),
        "combined_model_probability": round(combined_probability * 100.0, 1),
        "risk": "高" if size == 3 else "中高",
        "summary": f"由 {size} 場不同賽事、且各自通過單場機率與市場優勢門檻的推薦組成。",
        "model_version": "dm-parlay-v1.0",
    }


def build_daily_market_package(
    recommendation_date: str,
    analyses: list[dict[str, Any]],
    odds_items: list[dict[str, Any]],
    public_selection: dict[str, Any] | None,
    *,
    minimum_probability: float = 53.0,
    minimum_edge: float = 3.0,
    minimum_projection_quality: float = 0.45,
    minimum_parlay_probability: float = 54.0,
) -> dict[str, Any]:
    moneylines: list[dict[str, Any]] = []
    run_lines: list[dict[str, Any]] = []
    totals: list[dict[str, Any]] = []

    for analysis in analyses:
        event = match_odds_event(analysis, odds_items)
        if not event:
            continue
        moneyline = moneyline_candidate(
            analysis,
            event,
            minimum_probability=max(56.0, minimum_probability),
            minimum_edge=max(1.5, minimum_edge / 2.0),
        )
        run_line = run_line_candidate(
            analysis,
            event,
            minimum_probability=minimum_probability,
            minimum_edge=minimum_edge,
            minimum_projection_quality=minimum_projection_quality,
        )
        total = totals_candidate(
            analysis,
            event,
            minimum_probability=minimum_probability,
            minimum_edge=minimum_edge,
            minimum_projection_quality=minimum_projection_quality,
        )
        if moneyline:
            moneylines.append(moneyline)
        if run_line:
            run_lines.append(run_line)
        if total:
            totals.append(total)

    qualified_run_lines = [item for item in run_lines if item["meets_threshold"]]
    qualified_totals = [item for item in totals if item["meets_threshold"]]
    best_run_line = max(qualified_run_lines, key=lambda item: item["rank_score"], default=None)
    best_total = max(qualified_totals, key=lambda item: item["rank_score"], default=None)

    parlay_candidates = [
        item
        for item in [*moneylines, *run_lines, *totals]
        if item["meets_threshold"]
        and float(item["model_probability"]) >= minimum_parlay_probability
        and item.get("decimal_odds") is not None
    ]
    two_leg = _build_parlay(parlay_candidates, 2)
    three_leg = _build_parlay(parlay_candidates, 3)
    published = bool(best_run_line or best_total or two_leg or three_leg)
    return {
        "date": recommendation_date,
        "published": published,
        "locked": False,
        "generated_at": _utc_now(),
        "moneyline": _public_moneyline(public_selection, moneylines),
        "run_line": best_run_line,
        "totals": best_total,
        "parlays": {"two_leg": two_leg, "three_leg": three_leg},
        "candidate_counts": {
            "matched_games": len({item["game_pk"] for item in [*moneylines, *run_lines, *totals]}),
            "moneyline": len(moneylines),
            "run_line_qualified": len(qualified_run_lines),
            "totals_qualified": len(qualified_totals),
            "parlay_qualified_legs": len(parlay_candidates),
        },
        "thresholds": {
            "minimum_probability": minimum_probability,
            "minimum_edge": minimum_edge,
            "minimum_projection_quality": minimum_projection_quality,
            "minimum_parlay_leg_probability": minimum_parlay_probability,
        },
        "model_version": "dm-markets-v1.0",
        "message": "正式玩法已完成並鎖定。" if published else "目前沒有盤口同時通過模型機率與市場優勢門檻。",
    }
