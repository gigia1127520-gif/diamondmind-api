from __future__ import annotations

import math
import re
from itertools import combinations
from datetime import datetime, timezone
from typing import Any


def _number(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def american_implied_probability(price: Any) -> float | None:
    value = _number(price)
    if value is None or value == 0:
        return None
    if value < 0:
        return -value / (-value + 100.0)
    return 100.0 / (value + 100.0)


def american_to_decimal(price: Any) -> float | None:
    value = _number(price)
    if value is None or value == 0:
        return None
    if value < 0:
        return 1.0 + 100.0 / -value
    return 1.0 + value / 100.0


def decimal_to_american(decimal_odds: float) -> int | None:
    if decimal_odds <= 1.0:
        return None
    if decimal_odds >= 2.0:
        return round((decimal_odds - 1.0) * 100.0)
    return round(-100.0 / (decimal_odds - 1.0))


def _no_vig_pair(first_price: Any, second_price: Any) -> tuple[float, float] | None:
    first = american_implied_probability(first_price)
    second = american_implied_probability(second_price)
    if first is None or second is None or first + second <= 0:
        return None
    total = first + second
    return first / total, second / total


def _normal_cdf(value: float) -> float:
    return 0.5 * (1.0 + math.erf(value / math.sqrt(2.0)))


def _canonical_team(value: Any) -> str:
    normalized = re.sub(r"[^a-z0-9]+", " ", str(value or "").lower()).strip()
    aliases = {
        "oakland athletics": "athletics",
        "sacramento athletics": "athletics",
        "a s": "athletics",
        "tokyo yakult swallows": "npb yakult",
        "yakult swallows": "npb yakult",
        "yomiuri giants": "npb yomiuri",
        "tokyo giants": "npb yomiuri",
        "yokohama dena baystars": "npb dena",
        "yokohama dena bay stars": "npb dena",
        "dena baystars": "npb dena",
        "chunichi dragons": "npb chunichi",
        "hanshin tigers": "npb hanshin",
        "hiroshima toyo carp": "npb hiroshima",
        "hiroshima carp": "npb hiroshima",
        "fukuoka softbank hawks": "npb softbank",
        "softbank hawks": "npb softbank",
        "hokkaido nippon ham fighters": "npb nippon ham",
        "nippon ham fighters": "npb nippon ham",
        "orix buffaloes": "npb orix",
        "tohoku rakuten golden eagles": "npb rakuten",
        "rakuten golden eagles": "npb rakuten",
        "saitama seibu lions": "npb seibu",
        "seibu lions": "npb seibu",
        "chiba lotte marines": "npb lotte",
        "lotte marines": "npb lotte",
        "uni president 7 eleven lions": "cpbl lions",
        "uni president lions": "cpbl lions",
        "uni lions": "cpbl lions",
        "rakuten monkeys": "cpbl monkeys",
        "ctbc brothers": "cpbl brothers",
        "chinatrust brothers": "cpbl brothers",
        "tsg hawks": "cpbl hawks",
        "taiwan steel group hawks": "cpbl hawks",
        "wei chuan dragons": "cpbl dragons",
        "weichuan dragons": "cpbl dragons",
        "fubon guardians": "cpbl guardians",
    }
    return aliases.get(normalized, normalized)


def _iso_datetime(value: Any) -> datetime | None:
    if not isinstance(value, str) or not value.strip():
        return None
    try:
        parsed = datetime.fromisoformat(value.strip().replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def match_odds_event(
    analysis: dict[str, Any],
    odds_items: list[dict[str, Any]],
) -> dict[str, Any] | None:
    """Match a schedule game to a real-odds event without mixing doubleheaders.

    Team identity is the primary key.  When a provider lists the same matchup
    twice, the closest official start time selects G1/G2.  A large time gap is
    rejected instead of silently attaching the wrong market.
    """

    game = analysis.get("game") or {}
    away = _canonical_team((game.get("away") or {}).get("name"))
    home = _canonical_team((game.get("home") or {}).get("name"))
    matches = [
        event
        for event in odds_items
        if isinstance(event, dict)
        and (
            _canonical_team(event.get("away_team")) == away
            and _canonical_team(event.get("home_team")) == home
        )
    ]
    if not matches:
        return None
    if len(matches) == 1:
        return matches[0]

    game_time = _iso_datetime(game.get("game_date") or analysis.get("game_date"))
    if game_time is None:
        # Ambiguous same-team events without an official start time must not be
        # guessed; doing so can publish G1 with G2's line.
        return None
    timed = [
        (abs((event_time - game_time).total_seconds()), event)
        for event in matches
        if (event_time := _iso_datetime(event.get("commence_time"))) is not None
    ]
    if not timed:
        return None
    seconds, matched = min(timed, key=lambda item: item[0])
    return matched if seconds <= 6 * 60 * 60 else None


def _source(market: dict[str, Any], side: str | None = None) -> dict[str, Any]:
    side_source = market.get(f"{side}_source") if side else None
    if not isinstance(side_source, dict):
        nested = market.get(side) if side else None
        side_source = nested.get("source") if isinstance(nested, dict) else None
    source = side_source if isinstance(side_source, dict) else market
    return {
        "type": source.get("type") or "real_bookmaker",
        "provider": source.get("provider") or "The Odds API",
        "bookmaker_key": source.get("bookmaker_key"),
        "bookmaker": source.get("bookmaker"),
        "bookmaker_id": source.get("bookmaker_id"),
        "bookmaker_id_source": source.get("bookmaker_id_source"),
        "last_update": source.get("last_update"),
    }


def is_real_odds_selection(selection: dict[str, Any]) -> bool:
    source = selection.get("odds_source") or {}
    return bool(
        selection.get("market_basis") == "real_odds"
        and source.get("type") == "real_bookmaker"
        and source.get("bookmaker_key")
        and selection.get("price") is not None
        and selection.get("decimal_odds") is not None
    )


def is_model_only_asian_moneyline(
    selection: dict[str, Any],
    league: str | None = None,
) -> bool:
    """Validate an odds-free NPB/KBO/CPBL winner recommendation.

    This is deliberately narrower than a generic model candidate: it only
    permits a single moneyline direction and requires every market-derived
    value to remain empty. Run lines, totals and parlays therefore keep their
    real-bookmaker-odds requirement.
    """

    code = str(selection.get("league") or (selection.get("game") or {}).get("league") or "").upper()
    if code not in {"NPB", "KBO", "CPBL"}:
        return False
    if league and code != str(league).upper():
        return False
    pick = selection.get("pick") or {}
    source = selection.get("odds_source") or {}
    return bool(
        str(selection.get("market") or pick.get("market") or "").lower() == "moneyline"
        and str(pick.get("side") or "").lower() in {"away", "home"}
        and selection.get("market_basis") == "model_only"
        and source.get("type") == "model_only"
        and selection.get("game_pk")
        and selection.get("candidate_id")
        and selection.get("price") is None
        and selection.get("decimal_odds") is None
        and selection.get("implied_probability") is None
        and selection.get("edge") is None
        and pick.get("price") is None
        and pick.get("line") is None
    )


def is_asian_baseball_pro_selection(selection: dict[str, Any], league: str | None = None) -> bool:
    """Validate Asian baseball Pro content without inventing market data.

    NPB/KBO/CPBL may fall back to one model-only moneyline direction when no
    valid bookmaker line can be matched. Run lines, totals and every parlay
    continue to require verified real odds.
    """

    if str(selection.get("market") or "") in {"2_leg", "3_leg", "two_leg", "three_leg"}:
        legs = [item for item in selection.get("legs") or [] if isinstance(item, dict)]
        return bool(legs) and all(
            is_real_odds_selection(item)
            and is_asian_baseball_pro_selection(item, league)
            for item in legs
        )
    code = str(selection.get("league") or "").upper()
    if code not in {"NPB", "KBO", "CPBL"}:
        return False
    if league and code != str(league).upper():
        return False
    pick = selection.get("pick") or {}
    market = str(selection.get("market") or "").lower()
    side = str(pick.get("side") or "").lower()
    valid_direction = side in {"over", "under"} if market == "totals" else side in {"away", "home"}
    if not valid_direction:
        return False
    if is_real_odds_selection(selection):
        return True
    return is_model_only_asian_moneyline(selection, code)


def is_npb_pro_selection(selection: dict[str, Any]) -> bool:
    """Backward-compatible alias for existing NPB callers."""
    return is_asian_baseball_pro_selection(selection, "NPB")


ASIAN_BASEBALL_DIRECTION_LEAGUES = {"NPB", "KBO", "CPBL"}


def _selection_league(selection: dict[str, Any]) -> str:
    return str(
        selection.get("league")
        or (selection.get("game") or {}).get("league")
        or ""
    ).upper()


def _selection_game_pk(selection: dict[str, Any]) -> str:
    return str(
        selection.get("game_pk")
        or (selection.get("game") or {}).get("game_pk")
        or (selection.get("game") or {}).get("external_game_id")
        or ""
    )


def _selection_team_token(selection: dict[str, Any]) -> str:
    pick = selection.get("pick") or {}
    team_id = str(pick.get("team_id") or "").strip()
    if team_id:
        return f"id:{team_id.casefold()}"
    team_name = pick.get("team_name") or pick.get("abbr")
    canonical = _canonical_team(team_name)
    return f"name:{canonical}" if canonical else ""


def asian_run_line_matches_moneyline(
    moneyline: dict[str, Any],
    run_line: dict[str, Any],
) -> bool:
    """Return whether one Asian run-line pick follows the model's ML team.

    Recommendations from another league/game are outside this policy. For the
    same NPB/KBO/CPBL game, a run-line direction must identify the same team as
    the official moneyline direction. Unknown direction data fails closed so a
    legacy or malformed candidate cannot be published accidentally.
    """

    league = _selection_league(moneyline)
    if (
        league not in ASIAN_BASEBALL_DIRECTION_LEAGUES
        or _selection_league(run_line) != league
        or _selection_game_pk(moneyline) != _selection_game_pk(run_line)
        or not _selection_game_pk(moneyline)
    ):
        return True
    if str(moneyline.get("market") or "").lower() != "moneyline":
        return True
    if str(run_line.get("market") or "").lower() != "run_line":
        return True

    moneyline_side = str((moneyline.get("pick") or {}).get("side") or "").lower()
    run_line_side = str((run_line.get("pick") or {}).get("side") or "").lower()
    if moneyline_side in {"home", "away"} and run_line_side in {"home", "away"}:
        return moneyline_side == run_line_side

    moneyline_team = _selection_team_token(moneyline)
    run_line_team = _selection_team_token(run_line)
    return bool(moneyline_team and moneyline_team == run_line_team)


def suppress_asian_run_line_conflicts(
    selections: list[dict[str, Any]],
    *,
    reference_moneylines: list[dict[str, Any]] | None = None,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    """Remove opposing Asian run lines while retaining audit metadata.

    The sportsbook still supplies both +1.5 and -1.5 sides. This policy does
    not manufacture or flip a line; it only prevents a formal run-line pick
    from opposing the model's moneyline team for the same game.
    """

    moneyline_by_game: dict[tuple[str, str], dict[str, Any]] = {}
    for item in [
        *(reference_moneylines or []),
        *selections,
    ]:
        if not isinstance(item, dict):
            continue
        league = _selection_league(item)
        game_pk = _selection_game_pk(item)
        if (
            league in ASIAN_BASEBALL_DIRECTION_LEAGUES
            and game_pk
            and str(item.get("market") or "").lower() == "moneyline"
        ):
            moneyline_by_game.setdefault((league, game_pk), item)

    kept: list[dict[str, Any]] = []
    suppressed: list[dict[str, Any]] = []
    for item in selections:
        if not isinstance(item, dict):
            continue
        league = _selection_league(item)
        game_pk = _selection_game_pk(item)
        reference = moneyline_by_game.get((league, game_pk))
        if (
            reference is not None
            and str(item.get("market") or "").lower() == "run_line"
            and not asian_run_line_matches_moneyline(reference, item)
        ):
            conflict = {
                **item,
                "meets_threshold": False,
                "candidate_tier": "direction_conflict",
                "counts_as_formal_record": False,
                "formal_publish_eligible": False,
                "direction_consistency": {
                    "status": "suppressed",
                    "policy": "same_team_as_moneyline",
                    "moneyline_candidate_id": reference.get("candidate_id"),
                    "moneyline_pick": (reference.get("pick") or {}).get("label"),
                    "run_line_pick": (item.get("pick") or {}).get("label"),
                    "reason": "讓分方向與同場獨贏模型方向不同",
                },
            }
            suppressed.append(conflict)
            continue
        kept.append(item)
    return kept, suppressed


def _team_for_side(analysis: dict[str, Any], side: str) -> tuple[dict[str, Any], dict[str, Any]]:
    game = analysis["game"]
    picked = game[side]
    opponent = game["away" if side == "home" else "home"]
    return picked, opponent


def _selection_candidate_id(market: str, game_pk: Any, pick: dict[str, Any]) -> str:
    side = str(pick.get("side") or "")
    line = pick.get("line")
    line_token = "" if line is None else f"{float(line):g}"
    price = pick.get("price")
    price_token = "" if price is None else f"{float(price):g}"
    return f"{market}:{str(game_pk)}:{side}:{line_token}:{price_token}"


def _base_selection(
    analysis: dict[str, Any],
    *,
    market: str,
    pick: dict[str, Any],
    opponent: dict[str, Any] | None,
    probability: float,
    implied_probability: float,
    price: float | int,
    market_source: dict[str, Any],
    summary: str,
    model_version: str,
    minimum_probability: float,
    minimum_edge: float,
    minimum_projection_quality: float = 0.0,
) -> dict[str, Any]:
    edge_points = (probability - implied_probability) * 100.0
    projection_quality = float((analysis.get("projections") or {}).get("quality") or 0.0)
    qualifies = (
        probability * 100.0 >= minimum_probability
        and edge_points >= minimum_edge
        and projection_quality >= minimum_projection_quality
    )
    decimal_odds = american_to_decimal(price)
    candidate_id = _selection_candidate_id(market, analysis["game_pk"], pick)
    return {
        "candidate_id": candidate_id,
        "league": str((analysis.get("game") or {}).get("league") or analysis.get("league") or "MLB").upper(),
        "game_pk": analysis["game_pk"],
        "matchup": analysis["matchup"],
        "game_date": analysis["game_date"],
        "time_taiwan": analysis["time_taiwan"],
        "display_time_taiwan": analysis.get("display_time_taiwan") or (analysis.get("game") or {}).get("display_time_taiwan"),
        "game_label": analysis.get("game_label") or (analysis.get("game") or {}).get("game_label") or "",
        "game_number": analysis.get("game_number") if analysis.get("game_number") is not None else (analysis.get("game") or {}).get("game_number"),
        "is_doubleheader": bool(analysis.get("is_doubleheader") or (analysis.get("game") or {}).get("is_doubleheader")),
        "market": market,
        "market_basis": "real_odds",
        "pick": pick,
        "opponent": opponent,
        "confidence": round(probability * 100.0, 1),
        "model_probability": round(probability * 100.0, 1),
        "implied_probability": round(implied_probability * 100.0, 1),
        "edge": round(edge_points, 1),
        "price": int(price) if float(price).is_integer() else price,
        "decimal_odds": round(decimal_odds, 3) if decimal_odds is not None else None,
        "data_quality": analysis.get("data_quality"),
        "projection_quality": (analysis.get("projections") or {}).get("quality"),
        "factors": analysis.get("factors") or [],
        "analysis_groups": analysis.get("analysis_groups") or {},
        "engine": analysis.get("engine") or {},
        "projections": analysis.get("projections") or {},
        "summary": summary,
        "model_version": model_version,
        "odds_source": market_source,
        "game": analysis["game"],
        "meets_threshold": qualifies,
        "candidate_tier": "formal" if qualifies else "unclassified",
        "qualification_thresholds": {
            "minimum_probability": round(float(minimum_probability), 2),
            "minimum_edge": round(float(minimum_edge), 2),
            "minimum_projection_quality": round(float(minimum_projection_quality), 3),
        },
        "rank_score": round(edge_points + (probability - 0.5) * 20.0 + float(analysis.get("data_quality") or 0) * 2.0, 3),
    }


def _watchlist_copy(selection: dict[str, Any]) -> dict[str, Any] | None:
    """Return a near-threshold Pro observation item, or None when it is too weak."""

    if selection.get("meets_threshold"):
        return None
    thresholds = selection.get("qualification_thresholds") or {}
    minimum_probability = float(thresholds.get("minimum_probability") or 0.0)
    minimum_edge = float(thresholds.get("minimum_edge") or 0.0)
    minimum_projection_quality = float(thresholds.get("minimum_projection_quality") or 0.0)
    probability = float(selection.get("model_probability") or 0.0)
    model_only = str(selection.get("market_basis") or "") == "model_only"
    edge = float(selection.get("edge") if selection.get("edge") is not None else -999.0)
    projection_quality = float(selection.get("projection_quality") or selection.get("data_quality") or 0.0)
    market = str(selection.get("market") or "")

    probability_floor = max(
        50.0,
        minimum_probability - (4.0 if model_only else 6.0 if market == "moneyline" else 3.0),
    )
    edge_floor = 0.0 if model_only else max(0.5, minimum_edge - 2.5)
    quality_floor = (
        max(0.50 if model_only else 0.25, minimum_projection_quality - 0.15)
        if minimum_projection_quality > 0
        else 0.0
    )
    if probability < probability_floor or (not model_only and edge < edge_floor):
        return None
    if minimum_projection_quality > 0 and projection_quality < quality_floor:
        return None

    reasons: list[str] = []
    if probability < minimum_probability:
        reasons.append(f"模型機率距正式門檻 {minimum_probability - probability:.1f}%")
    if not model_only and edge < minimum_edge:
        reasons.append(f"市場優勢距正式門檻 {minimum_edge - edge:.1f}%")
    if minimum_projection_quality > 0 and projection_quality < minimum_projection_quality:
        reasons.append(
            f"資料完整度距正式門檻 {(minimum_projection_quality - projection_quality) * 100:.0f}%"
        )
    if not reasons:
        reasons.append("接近正式門檻，等待盤口或名單更新")

    result = {
        **selection,
        "candidate_tier": "watchlist",
        "watchlist_reasons": reasons,
        "counts_as_formal_record": False,
    }
    result["summary"] = (
        f'{selection.get("summary") or ""} '
        "目前僅列入創辦人觀察名單，不計入正式推薦戰績。"
    ).strip()
    return result


def _formal_candidates(items: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return [
        {**item, "candidate_tier": "formal", "counts_as_formal_record": True}
        for item in items
        if item.get("meets_threshold")
    ]


def _watchlist_candidates(
    items: list[dict[str, Any]],
    *,
    limit: int = 5,
) -> list[dict[str, Any]]:
    result = [candidate for item in items if (candidate := _watchlist_copy(item))]
    result.sort(key=lambda item: float(item.get("rank_score") or 0), reverse=True)
    return result[:limit]


def _manual_parlay_candidates(items: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Return every pregame single with a complete real sportsbook line.

    Founder-built parlays intentionally do not use the AI formal/watchlist
    thresholds.  The hard gates remain: an explicit direction, a stable game
    reference and valid real bookmaker odds.
    """

    result: list[dict[str, Any]] = []
    for selection in items:
        if not isinstance(selection, dict) or not is_real_odds_selection(selection):
            continue
        market = str(selection.get("market") or "").lower()
        side = str((selection.get("pick") or {}).get("side") or "").lower()
        valid_direction = side in {"over", "under"} if market == "totals" else side in {"away", "home"}
        decimal_odds = _number(selection.get("decimal_odds"))
        if not valid_direction or not selection.get("candidate_id") or not selection.get("game_pk"):
            continue
        if decimal_odds is None or decimal_odds <= 1.0:
            continue
        tier = str(selection.get("candidate_tier") or "")
        result.append({
            **selection,
            "candidate_tier": tier if tier in {"formal", "watchlist"} else "founder_manual_available",
            "manual_parlay_eligible": True,
            "counts_as_formal_record": bool(selection.get("meets_threshold")),
        })
    result = _dedupe_candidates(result)
    result.sort(key=lambda item: float(item.get("rank_score") or 0), reverse=True)
    return result


def moneyline_candidate(
    analysis: dict[str, Any],
    event: dict[str, Any],
    *,
    minimum_probability: float,
    minimum_edge: float,
) -> dict[str, Any] | None:
    market = (event.get("markets") or {}).get("moneyline") or {}
    away_price = _number(market.get("away_price"))
    home_price = _number(market.get("home_price"))
    no_vig = _no_vig_pair(away_price, home_price)
    if away_price is None or home_price is None or no_vig is None:
        return None

    side = "home" if float(analysis.get("home_probability") or 0) >= float(analysis.get("away_probability") or 0) else "away"
    probability = float(analysis[f"{side}_probability"]) / 100.0
    implied = no_vig[1] if side == "home" else no_vig[0]
    price = home_price if side == "home" else away_price
    picked, opponent_team = _team_for_side(analysis, side)
    pick = {
        "team_id": picked.get("id"),
        "team_name": picked.get("name"),
        "abbr": picked.get("abbr"),
        "market": "moneyline",
        "side": side,
        "line": None,
        "price": price,
        "label": f'{picked.get("abbr")} 獨贏',
    }
    opponent = {
        "team_id": opponent_team.get("id"),
        "team_name": opponent_team.get("name"),
        "abbr": opponent_team.get("abbr"),
    }
    edge = (probability - implied) * 100.0
    summary = f"模型勝率 {probability * 100:.1f}%，較無水位市場機率高 {edge:.1f} 個百分點。"
    return _base_selection(
        analysis,
        market="moneyline",
        pick=pick,
        opponent=opponent,
        probability=probability,
        implied_probability=implied,
        price=price,
        market_source=_source(market, side),
        summary=summary,
        model_version="dm-moneyline-value-v2.0",
        minimum_probability=minimum_probability,
        minimum_edge=minimum_edge,
    )


def model_only_moneyline_candidate(
    game: dict[str, Any],
    analysis: dict[str, Any],
    *,
    minimum_probability: float = 56.0,
    minimum_data_quality: float = 0.65,
) -> dict[str, Any] | None:
    """Build a league-aware moneyline candidate without bookmaker odds.

    NPB can use a lower-certainty baseline before both probable starters are
    available.  That baseline may qualify only for a moneyline recommendation;
    starter-dependent run lines and totals remain locked to the full model.
    """

    pick_info = analysis.get("pick") or {}
    side = str(pick_info.get("side") or "").lower()
    if side not in {"away", "home"}:
        return None
    picked = game.get(side) or {}
    opponent_side = "home" if side == "away" else "away"
    opponent_team = game.get(opponent_side) or {}
    confidence = float(analysis.get("confidence") or 0.0)
    data_quality = float(analysis.get("data_quality") or 0.0)
    starter_group = (analysis.get("analysis_groups") or {}).get("starter") or {}
    both_starters_ready = bool(starter_group.get("both_starters_ready"))
    data_basis = analysis.get("data_basis") or {}
    model_stage = str(
        analysis.get("model_stage")
        or data_basis.get("model_stage")
        or ("full" if both_starters_ready else "base")
    ).lower()
    base_model = model_stage != "full"
    base_ready = bool(
        data_basis.get("base_recommendation_ready")
        if "base_recommendation_ready" in data_basis
        else analysis.get("official_recommendation_enabled") is True or data_quality >= 0.55
    )
    full_market_ready = bool(
        data_basis.get("full_market_ready")
        if "full_market_ready" in data_basis
        else both_starters_ready and data_quality >= float(minimum_data_quality)
    )
    effective_minimum_probability = 54.0 if base_model else float(minimum_probability)
    effective_minimum_data_quality = 0.55 if base_model else float(minimum_data_quality)
    stage_ready = base_ready if base_model else full_market_ready
    qualifies = (
        confidence >= effective_minimum_probability
        and data_quality >= effective_minimum_data_quality
        and stage_ready
    )
    game_pk = game.get("game_pk") or game.get("external_game_id")
    league = str(game.get("league") or analysis.get("league") or "NPB").upper()
    # Asian baseball free picks use completeness as advisory metadata. A valid
    # official game plus an explicit side is sufficient for publication.
    if league in {"NPB", "KBO", "CPBL"}:
        qualifies = bool(game_pk and side in {"away", "home"})
    if not game_pk:
        return None
    pick = {
        "team_id": picked.get("id"),
        "team_name": picked.get("name"),
        "abbr": picked.get("abbr"),
        "market": "moneyline",
        "side": side,
        "line": None,
        "price": None,
        "label": f'{picked.get("name_zh") or picked.get("abbr") or picked.get("name")} 獨贏',
    }
    opponent = {
        "team_id": opponent_team.get("id"),
        "team_name": opponent_team.get("name"),
        "abbr": opponent_team.get("abbr"),
    }
    groups = analysis.get("analysis_groups") or {}
    normalized_groups = {
        "team_strength": groups.get("team") or {},
        "starter": groups.get("starter") or {},
        "lineup": groups.get("offense") or {},
        "bullpen": groups.get("bullpen") or {},
        "advanced": groups.get("advanced") or {"available": False, "quality": 0.0, "metrics": []},
        "environment": groups.get("environment") or {"available": False, "quality": 0.0, "metrics": []},
    }
    summary = (
        f"{league} {'基礎' if base_model else '完整'}模型勝率 {confidence:.1f}%，資料完整度 {data_quality * 100:.0f}%"
        + ("，雙方預告先發與投手資料已確認。" if full_market_ready else "，尚未使用完整先發資料，僅評估獨贏。")
    )
    candidate_id = _selection_candidate_id("moneyline", game_pk, pick)
    return {
        "candidate_id": candidate_id,
        "league": league,
        "market_basis": "model_only",
        "qualification_policy": "model_direction",
        "model_direction_probability": round(confidence, 1),
        "minimum_probability_gate_enabled": False,
        "market_edge_gate_enabled": False,
        "model_stage": "base" if base_model else "full",
        "recommendation_stage": "base_moneyline" if base_model else "full_markets",
        "full_market_ready": full_market_ready,
        "requires_confirmation": base_model,
        "game_pk": str(game_pk),
        "matchup": f'{(game.get("away") or {}).get("abbr")} @ {(game.get("home") or {}).get("abbr")}',
        "game_date": game.get("game_date"),
        "time_taiwan": game.get("time_taiwan"),
        "display_time_taiwan": game.get("display_time_taiwan") or (f'台灣 {game.get("time_taiwan")}' if game.get("time_taiwan") else None),
        "game_label": game.get("game_label") or "",
        "game_number": game.get("game_number"),
        "is_doubleheader": bool(game.get("is_doubleheader")),
        "market": "moneyline",
        "pick": pick,
        "opponent": opponent,
        "confidence": round(confidence, 1),
        "model_probability": round(confidence, 1),
        "implied_probability": None,
        "edge": None,
        "price": None,
        "decimal_odds": None,
        "data_quality": round(data_quality, 2),
        "projection_quality": round(data_quality, 2),
        "factors": [],
        "analysis_groups": normalized_groups,
        "engine": {
            "weights": (analysis.get("model_weights") or {}).get("engine")
            or (analysis.get("model_weights") or {}).get("effective")
            or (analysis.get("model_weights") or {}).get("configured")
            or {}
        },
        "projections": {"quality": round(data_quality, 2)},
        "summary": summary,
        "model_version": analysis.get("model_version") or f"dm-{league.lower()}-moneyline-v1.0",
        "odds_source": {"type": "model_only", "league": league},
        "game": game,
        "meets_threshold": qualifies,
        "candidate_tier": "formal" if qualifies else "unclassified",
        "qualification_thresholds": {
            "policy": "higher_model_direction",
            "minimum_probability": None,
            "minimum_edge": None,
            "minimum_projection_quality": None,
        },
        "rank_score": round((confidence - 50.0) * 1.8 + data_quality * 10.0 + (2.0 if full_market_ready else 0.0), 3),
    }


def _dedupe_candidates(items: list[dict[str, Any]]) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    seen: set[str] = set()
    for item in items:
        candidate_id = str(item.get("candidate_id") or "")
        if not candidate_id or candidate_id in seen:
            continue
        seen.add(candidate_id)
        result.append(item)
    return result


def merge_market_candidates(
    bundle: dict[str, Any],
    selections: list[dict[str, Any]],
    *,
    minimum_parlay_probability: float = 54.0,
) -> dict[str, Any]:
    """Merge league candidates into the unified pool and rebuild parlays.

    MLB and NPB candidates share the same formal/watchlist thresholds once
    real sportsbook lines are present. Rebuilding parlays after the merge is
    what allows genuine cross-league two-leg and three-leg combinations.
    """

    candidates = bundle.setdefault("candidates", {})
    watchlist = bundle.setdefault("watchlist", {})
    manual_pool = bundle.setdefault("manual_pool", {})
    reference_moneylines = [
        item
        for pool in (candidates, watchlist, manual_pool)
        for item in (pool.get("moneylines") or [])
        if isinstance(item, dict)
    ]
    selections, direction_conflicts = suppress_asian_run_line_conflicts(
        selections,
        reference_moneylines=reference_moneylines,
    )
    if direction_conflicts:
        consistency = bundle.setdefault("direction_consistency", {})
        existing_conflicts = [
            item
            for item in consistency.get("conflicts") or []
            if isinstance(item, dict)
        ]
        conflict_rows = [
            {
                "candidate_id": item.get("candidate_id"),
                "league": _selection_league(item),
                "game_pk": _selection_game_pk(item),
                **(item.get("direction_consistency") or {}),
            }
            for item in direction_conflicts
        ]
        consistency.update(
            {
                "policy": "asian_run_line_same_team_as_moneyline",
                "leagues": sorted(ASIAN_BASEBALL_DIRECTION_LEAGUES),
                "suppressed_run_lines": len(existing_conflicts) + len(conflict_rows),
                "conflicts": [*existing_conflicts, *conflict_rows],
            }
        )

    group_for_market = {
        "moneyline": "moneylines",
        "run_line": "run_lines",
        "totals": "totals",
    }
    grouped: dict[str, list[dict[str, Any]]] = {key: [] for key in group_for_market.values()}
    for selection in selections:
        group = group_for_market.get(str(selection.get("market") or ""))
        if group:
            grouped[group].append(selection)

    for group, items in grouped.items():
        formal = sorted(
            _formal_candidates(items),
            key=lambda item: float(item.get("rank_score") or 0),
            reverse=True,
        )
        watch = _watchlist_candidates(items, limit=12)
        combined_formal = _dedupe_candidates([*(candidates.get(group) or []), *formal])
        combined_formal.sort(key=lambda item: float(item.get("rank_score") or 0), reverse=True)
        formal_ids = {str(item.get("candidate_id") or "") for item in combined_formal}
        combined_watch = _dedupe_candidates([*(watchlist.get(group) or []), *watch])
        combined_watch = [
            item for item in combined_watch
            if str(item.get("candidate_id") or "") not in formal_ids
        ]
        combined_watch.sort(key=lambda item: float(item.get("rank_score") or 0), reverse=True)
        candidates[group] = combined_formal
        watchlist[group] = combined_watch
        combined_manual = _dedupe_candidates([
            *(manual_pool.get(group) or []),
            *_manual_parlay_candidates(items),
        ])
        combined_manual.sort(key=lambda item: float(item.get("rank_score") or 0), reverse=True)
        manual_pool[group] = combined_manual

    parlay_legs = [
        item
        for group in ("moneylines", "run_lines", "totals")
        for item in candidates.get(group) or []
        if float(item.get("model_probability") or 0) >= float(minimum_parlay_probability)
        and item.get("decimal_odds") is not None
    ]
    two_leg_candidates = _build_parlay_candidates(parlay_legs, 2, limit=8)
    three_leg_candidates = _build_parlay_candidates(parlay_legs, 3, limit=6)
    candidates["parlays"] = {
        "two_leg": two_leg_candidates,
        "three_leg": three_leg_candidates,
    }

    public_pk = str((bundle.get("public_moneyline") or {}).get("game_pk") or "")
    recommended = bundle.setdefault("recommended", {})
    recommended["moneylines"] = [
        item.get("candidate_id")
        for item in candidates.get("moneylines") or []
        if str(item.get("game_pk") or "") != public_pk
    ]
    recommended["run_lines"] = [item.get("candidate_id") for item in candidates.get("run_lines") or []]
    recommended["totals"] = [item.get("candidate_id") for item in candidates.get("totals") or []]
    recommended["two_leg"] = [item.get("candidate_id") for item in two_leg_candidates[:2]]
    recommended["three_leg"] = [item.get("candidate_id") for item in three_leg_candidates[:1]]

    limits = bundle.setdefault("limits", {})
    for group in ("moneylines", "run_lines", "totals"):
        limits[group] = max(1, len(candidates.get(group) or []) + len(watchlist.get(group) or []))
    limits["two_leg"] = 2
    limits["three_leg"] = 1

    counts = bundle.setdefault("candidate_counts", {})
    counts.update({
        "moneyline_qualified": len(candidates.get("moneylines") or []),
        "run_line_qualified": len(candidates.get("run_lines") or []),
        "totals_qualified": len(candidates.get("totals") or []),
        "two_leg_candidates": len(two_leg_candidates),
        "three_leg_candidates": len(three_leg_candidates),
        "parlay_qualified_legs": len(parlay_legs),
        "watch_moneylines": len(watchlist.get("moneylines") or []),
        "watch_run_lines": len(watchlist.get("run_lines") or []),
        "watch_totals": len(watchlist.get("totals") or []),
        "manual_moneylines": len(manual_pool.get("moneylines") or []),
        "manual_run_lines": len(manual_pool.get("run_lines") or []),
        "manual_totals": len(manual_pool.get("totals") or []),
    })
    by_league: dict[str, dict[str, int]] = {}
    for group in ("moneylines", "run_lines", "totals"):
        for item in candidates.get(group) or []:
            league = str(item.get("league") or "MLB").upper()
            league_counts = by_league.setdefault(league, {"moneylines": 0, "run_lines": 0, "totals": 0, "total": 0})
            league_counts[group] += 1
            league_counts["total"] += 1
    counts["by_league"] = by_league
    thresholds = bundle.setdefault("thresholds", {})
    thresholds["minimum_parlay_leg_probability"] = minimum_parlay_probability
    bundle["model_version"] = "dm-multileague-markets-v1.3"
    return bundle


def merge_model_only_moneylines(
    bundle: dict[str, Any],
    selections: list[dict[str, Any]],
) -> dict[str, Any]:
    """Backward-compatible wrapper retained for older callers."""

    threshold = float((bundle.get("thresholds") or {}).get("minimum_parlay_leg_probability") or 54.0)
    return merge_market_candidates(
        bundle,
        selections,
        minimum_parlay_probability=threshold,
    )

def run_line_candidate(
    analysis: dict[str, Any],
    event: dict[str, Any],
    *,
    minimum_probability: float,
    minimum_edge: float,
    minimum_projection_quality: float = 0.45,
) -> dict[str, Any] | None:
    market = (event.get("markets") or {}).get("run_line") or {}
    away = market.get("away") or {}
    home = market.get("home") or {}
    away_point = _number(away.get("point"))
    home_point = _number(home.get("point"))
    away_price = _number(away.get("price"))
    home_price = _number(home.get("price"))
    no_vig = _no_vig_pair(away_price, home_price)
    projected_margin = _number((analysis.get("projections") or {}).get("home_margin"))
    if None in {away_point, home_point, away_price, home_price, projected_margin} or no_vig is None:
        return None

    margin_sigma = 3.55
    home_cover = _normal_cdf((projected_margin + home_point) / margin_sigma)
    away_cover = _normal_cdf((-projected_margin + away_point) / margin_sigma)
    choices = [
        ("away", away_cover, no_vig[0], away_point, away_price),
        ("home", home_cover, no_vig[1], home_point, home_price),
    ]
    side, probability, implied, point, price = max(choices, key=lambda item: item[1] - item[2])
    picked, opponent_team = _team_for_side(analysis, side)
    point_label = f"{point:+g}"
    pick = {
        "team_id": picked.get("id"),
        "team_name": picked.get("name"),
        "abbr": picked.get("abbr"),
        "market": "run_line",
        "side": side,
        "line": point,
        "price": price,
        "label": f'{picked.get("abbr")} {point_label}',
    }
    opponent = {
        "team_id": opponent_team.get("id"),
        "team_name": opponent_team.get("name"),
        "abbr": opponent_team.get("abbr"),
    }
    edge = (probability - implied) * 100.0
    summary = f"模型預估主隊勝分差 {projected_margin:+.2f}，此讓分方向相對市場具 {edge:.1f} 個百分點優勢。"
    return _base_selection(
        analysis,
        market="run_line",
        pick=pick,
        opponent=opponent,
        probability=probability,
        implied_probability=implied,
        price=price,
        market_source=_source(market, side),
        summary=summary,
        model_version="dm-run-line-v2.0",
        minimum_probability=minimum_probability,
        minimum_edge=minimum_edge,
        minimum_projection_quality=minimum_projection_quality,
    )


def totals_candidate(
    analysis: dict[str, Any],
    event: dict[str, Any],
    *,
    minimum_probability: float,
    minimum_edge: float,
    minimum_projection_quality: float = 0.45,
) -> dict[str, Any] | None:
    market = (event.get("markets") or {}).get("totals") or {}
    total = _number(market.get("total"))
    over_price = _number(market.get("over_price"))
    under_price = _number(market.get("under_price"))
    projected_total = _number((analysis.get("projections") or {}).get("total_runs"))
    projection_quality = _number((analysis.get("projections") or {}).get("quality"))
    no_vig = _no_vig_pair(over_price, under_price)
    if None in {total, over_price, under_price, projected_total} or no_vig is None:
        return None

    total_sigma = 3.15 + (1.0 - (projection_quality or 0.0)) * 0.55
    under_probability = _normal_cdf((total - projected_total) / total_sigma)
    over_probability = 1.0 - under_probability
    choices = [
        ("over", over_probability, no_vig[0], over_price),
        ("under", under_probability, no_vig[1], under_price),
    ]
    side, probability, implied, price = max(choices, key=lambda item: item[1] - item[2])
    side_zh = "大" if side == "over" else "小"
    pick = {
        "team_id": None,
        "team_name": None,
        "abbr": None,
        "market": "totals",
        "side": side,
        "line": total,
        "price": price,
        "label": f"{side_zh} {total:g}",
    }
    edge = (probability - implied) * 100.0
    summary = f"模型預估總分 {projected_total:.2f}，相對 {total:g} 分盤口偏向{side_zh}分，市場優勢 {edge:.1f} 個百分點。"
    return _base_selection(
        analysis,
        market="totals",
        pick=pick,
        opponent=None,
        probability=probability,
        implied_probability=implied,
        price=price,
        market_source=_source(market, side),
        summary=summary,
        model_version="dm-totals-v2.0",
        minimum_probability=minimum_probability,
        minimum_edge=minimum_edge,
        minimum_projection_quality=minimum_projection_quality,
    )


def _public_moneyline(
    public_selection: dict[str, Any] | None,
    moneyline_candidates: list[dict[str, Any]],
) -> dict[str, Any] | None:
    if not public_selection:
        return None
    matched = next(
        (item for item in moneyline_candidates if item["game_pk"] == public_selection.get("game_pk")),
        None,
    )
    if not matched:
        return public_selection
    result = {**public_selection}
    result.update(
        {
            "price": matched.get("price"),
            "decimal_odds": matched.get("decimal_odds"),
            "implied_probability": matched.get("implied_probability"),
            "edge": matched.get("edge"),
            "odds_source": matched.get("odds_source"),
        }
    )
    result["pick"] = {**(public_selection.get("pick") or {}), **(matched.get("pick") or {})}
    return result


def _parlay_candidate_id(size: int, legs: list[dict[str, Any]]) -> str:
    return f"{size}_leg:" + "+".join(str(leg.get("candidate_id") or "") for leg in legs)


def _build_parlay_candidates(
    candidates: list[dict[str, Any]],
    size: int,
    *,
    limit: int,
) -> list[dict[str, Any]]:
    # Limit the source pool before combinations so a full MLB slate remains
    # fast while still considering the strongest options across all markets.
    source = sorted(candidates, key=lambda item: float(item.get("rank_score") or 0), reverse=True)[:14]
    parlays: list[dict[str, Any]] = []
    seen: set[str] = set()
    for combo in combinations(source, size):
        game_ids = [str(leg["game_pk"]) for leg in combo]
        if len(set(game_ids)) != size:
            continue
        legs = sorted(combo, key=lambda item: float(item.get("rank_score") or 0), reverse=True)
        if any(leg.get("decimal_odds") is None for leg in legs):
            continue
        candidate_id = _parlay_candidate_id(size, legs)
        if candidate_id in seen:
            continue
        seen.add(candidate_id)
        combined_decimal = math.prod(float(leg["decimal_odds"]) for leg in legs)
        combined_probability = math.prod(float(leg["model_probability"]) / 100.0 for leg in legs)
        rank_score = sum(float(leg.get("rank_score") or 0) for leg in legs) + combined_probability * 10.0
        parlays.append(
            {
                "candidate_id": candidate_id,
                "market": f"{size}_leg",
                "label": f"{size}關串關",
                "legs": legs,
                "combined_decimal_odds": round(combined_decimal, 2),
                "combined_american_odds": decimal_to_american(combined_decimal),
                "combined_model_probability": round(combined_probability * 100.0, 1),
                "risk": "高" if size == 3 else "中高",
                "summary": f"由 {size} 場不同賽事、且各自通過單場機率與市場優勢門檻的推薦組成。",
                "model_version": "dm-parlay-v3.0",
                "rank_score": round(rank_score, 3),
            }
        )
    parlays.sort(key=lambda item: float(item.get("rank_score") or 0), reverse=True)
    return parlays[:limit]


_MANUAL_PARLAY_BLOCKED_STATUS_TOKENS = (
    "final", "completed", "game over", "live", "in progress", "playing",
    "postponed", "cancelled", "canceled", "suspended", "no game",
    "已結束", "比賽中", "進行中", "延期", "取消", "作廢",
    "종료", "진행", "취소", "연기", "노게임",
)


def _manual_parlay_game_status(selection: dict[str, Any]) -> str:
    game = selection.get("game") or {}
    values = [
        selection.get("status"),
        game.get("status"),
        game.get("status_detail"),
        game.get("detailed_state"),
        game.get("abstract_state"),
    ]
    return " ".join(str(value or "").strip().lower() for value in values if value)


def _manual_parlay_source_pool(bundle: dict[str, Any]) -> list[dict[str, Any]]:
    manual_pool = bundle.get("manual_pool") or {}
    candidates = bundle.get("candidates") or {}
    watchlist = bundle.get("watchlist") or {}
    return _dedupe_candidates([
        item
        for group in ("moneylines", "run_lines", "totals")
        for item in [
            *(manual_pool.get(group) or []),
            *(candidates.get(group) or []),
            *(watchlist.get(group) or []),
        ]
        if isinstance(item, dict)
    ])


def _founder_manual_parlay(
    bundle: dict[str, Any],
    selected_ids: list[str],
    *,
    size: int,
    slot: int,
) -> dict[str, Any]:
    if len(selected_ids) != size:
        raise ValueError(f"手動 {size} 關串關第 {slot} 組必須剛好選擇 {size} 腿")
    if len(set(str(value) for value in selected_ids)) != size:
        raise ValueError(f"手動 {size} 關串關第 {slot} 組不能重複同一推薦")

    by_id = {str(item.get("candidate_id") or ""): item for item in _manual_parlay_source_pool(bundle)}
    legs: list[dict[str, Any]] = []
    for candidate_id in selected_ids:
        selection = by_id.get(str(candidate_id))
        if selection is None:
            raise ValueError("手動串關所選單場已失效，請重新載入候選")
        if not is_real_odds_selection(selection):
            raise ValueError("手動串關只允許具備有效真實盤口的單場")
        status = _manual_parlay_game_status(selection)
        if status and any(token in status for token in _MANUAL_PARLAY_BLOCKED_STATUS_TOKENS):
            raise ValueError("手動串關包含已開始、已結束、延期或取消的賽事")
        legs.append(selection)

    game_refs = [f'{str(leg.get("league") or "").upper()}:{str(leg.get("game_pk") or "")}' for leg in legs]
    if len(set(game_refs)) != size:
        raise ValueError("同一組串關不能放入同一場比賽的不同玩法")

    combined_decimal = math.prod(float(leg["decimal_odds"]) for leg in legs)
    combined_probability = math.prod(
        max(0.0, min(1.0, float(leg.get("model_probability") or leg.get("confidence") or 0.0) / 100.0))
        for leg in legs
    )
    label = f"{size}關串關" + ("①" if size == 2 and slot == 1 else "②" if size == 2 and slot == 2 else "")
    candidate_id = f"founder_manual_{size}_{slot}:" + "+".join(str(leg.get("candidate_id")) for leg in legs)
    parlay = {
        "candidate_id": candidate_id,
        "market": f"{size}_leg",
        "label": label,
        "legs": legs,
        "combined_decimal_odds": round(combined_decimal, 2),
        "combined_american_odds": decimal_to_american(combined_decimal),
        "combined_model_probability": round(combined_probability * 100.0, 1),
        "risk": "高" if size == 3 else "中高",
        "summary": f"由創辦人從 {size} 場有效真實盤口單場手動組合；未套用 AI 串關合格門檻。",
        "model_version": "founder-manual-parlay-v1.0",
        "rank_score": round(sum(float(leg.get("rank_score") or 0.0) for leg in legs), 3),
        "candidate_tier": "founder_selected",
        "counts_as_formal_record": True,
        "manual_override": True,
        "publication": {
            "mode": "founder_manual_parlay",
            "origin_tier": "founder_manual_available",
            "selection_tier": "founder_selected",
            "promoted_from_watchlist": False,
            "counts_as_ai_formal": False,
            "manual_parlay": True,
            "slot": slot,
        },
    }
    return parlay


def build_daily_market_candidates(
    recommendation_date: str,
    analyses: list[dict[str, Any]],
    odds_items: list[dict[str, Any]],
    public_selection: dict[str, Any] | None,
    *,
    minimum_probability: float = 53.0,
    minimum_edge: float = 3.0,
    minimum_projection_quality: float = 0.45,
    minimum_parlay_probability: float = 54.0,
) -> dict[str, Any]:
    moneylines: list[dict[str, Any]] = []
    run_lines: list[dict[str, Any]] = []
    totals: list[dict[str, Any]] = []

    for analysis in analyses:
        event = match_odds_event(analysis, odds_items)
        if not event:
            continue
        moneyline = moneyline_candidate(
            analysis,
            event,
            minimum_probability=max(56.0, minimum_probability),
            minimum_edge=max(1.5, minimum_edge / 2.0),
        )
        run_line = run_line_candidate(
            analysis,
            event,
            minimum_probability=minimum_probability,
            minimum_edge=minimum_edge,
            minimum_projection_quality=minimum_projection_quality,
        )
        total = totals_candidate(
            analysis,
            event,
            minimum_probability=minimum_probability,
            minimum_edge=minimum_edge,
            minimum_projection_quality=minimum_projection_quality,
        )
        if moneyline:
            moneylines.append(moneyline)
        if run_line:
            run_lines.append(run_line)
        if total:
            totals.append(total)

    qualified_moneylines = sorted(
        _formal_candidates(moneylines),
        key=lambda item: float(item["rank_score"]),
        reverse=True,
    )
    qualified_run_lines = sorted(
        _formal_candidates(run_lines),
        key=lambda item: float(item["rank_score"]),
        reverse=True,
    )
    qualified_totals = sorted(
        _formal_candidates(totals),
        key=lambda item: float(item["rank_score"]),
        reverse=True,
    )
    watch_moneylines = _watchlist_candidates(moneylines, limit=12)
    watch_run_lines = _watchlist_candidates(run_lines, limit=12)
    watch_totals = _watchlist_candidates(totals, limit=12)

    parlay_legs = [
        item
        for item in [*qualified_moneylines, *qualified_run_lines, *qualified_totals]
        if float(item["model_probability"]) >= minimum_parlay_probability
        and item.get("decimal_odds") is not None
    ]
    two_leg_candidates = _build_parlay_candidates(parlay_legs, 2, limit=8)
    three_leg_candidates = _build_parlay_candidates(parlay_legs, 3, limit=6)

    public_game_pk = public_selection.get("game_pk") if public_selection else None
    suggested_moneylines = [
        item for item in qualified_moneylines if item.get("game_pk") != public_game_pk
    ]
    suggested_run_lines = qualified_run_lines
    suggested_totals = qualified_totals
    suggested_two_leg = two_leg_candidates[:2]
    suggested_three_leg = three_leg_candidates[:1]

    return {
        "date": recommendation_date,
        "generated_at": _utc_now(),
        "public_moneyline": _public_moneyline(public_selection, moneylines),
        "candidates": {
            "moneylines": qualified_moneylines,
            "run_lines": qualified_run_lines,
            "totals": qualified_totals,
            "parlays": {
                "two_leg": two_leg_candidates,
                "three_leg": three_leg_candidates,
            },
        },
        "watchlist": {
            "moneylines": watch_moneylines,
            "run_lines": watch_run_lines,
            "totals": watch_totals,
        },
        "manual_pool": {
            "moneylines": _manual_parlay_candidates(moneylines),
            "run_lines": _manual_parlay_candidates(run_lines),
            "totals": _manual_parlay_candidates(totals),
        },
        "recommended": {
            "moneylines": [item["candidate_id"] for item in suggested_moneylines],
            "run_lines": [item["candidate_id"] for item in suggested_run_lines],
            "totals": [item["candidate_id"] for item in suggested_totals],
            "two_leg": [item["candidate_id"] for item in suggested_two_leg],
            "three_leg": [item["candidate_id"] for item in suggested_three_leg],
        },
        "limits": {
            "moneylines": max(1, len(qualified_moneylines) + len(watch_moneylines)),
            "run_lines": max(1, len(qualified_run_lines) + len(watch_run_lines)),
            "totals": max(1, len(qualified_totals) + len(watch_totals)),
            "two_leg": 2,
            "three_leg": 1,
        },
        "candidate_counts": {
            "matched_games": len({item["game_pk"] for item in [*moneylines, *run_lines, *totals]}),
            "moneyline_qualified": len(qualified_moneylines),
            "run_line_qualified": len(qualified_run_lines),
            "totals_qualified": len(qualified_totals),
            "two_leg_candidates": len(two_leg_candidates),
            "three_leg_candidates": len(three_leg_candidates),
            "parlay_qualified_legs": len(parlay_legs),
            "watch_moneylines": len(watch_moneylines),
            "watch_run_lines": len(watch_run_lines),
            "watch_totals": len(watch_totals),
            "manual_moneylines": len(_manual_parlay_candidates(moneylines)),
            "manual_run_lines": len(_manual_parlay_candidates(run_lines)),
            "manual_totals": len(_manual_parlay_candidates(totals)),
        },
        "thresholds": {
            "minimum_probability": minimum_probability,
            "minimum_edge": minimum_edge,
            "minimum_projection_quality": minimum_projection_quality,
            "minimum_parlay_leg_probability": minimum_parlay_probability,
            "watchlist_probability_floor": max(50.0, minimum_probability - 3.0),
            "watchlist_edge_floor": max(0.5, minimum_edge - 2.5),
            "watchlist_projection_quality_floor": max(0.25, minimum_projection_quality - 0.15),
        },
        "model_version": "dm-markets-v3.4",
    }


def _pick_candidates(
    available: list[dict[str, Any]],
    selected_ids: list[str],
    *,
    maximum: int,
) -> list[dict[str, Any]]:
    if len(selected_ids) > maximum:
        raise ValueError(f"Selected candidate count exceeds maximum {maximum}")
    by_id = {str(item.get("candidate_id")): item for item in available}
    result: list[dict[str, Any]] = []
    seen: set[str] = set()
    for candidate_id in selected_ids:
        key = str(candidate_id)
        if key in seen:
            continue
        candidate = by_id.get(key)
        if candidate is None:
            raise ValueError("Selected candidate is no longer available")
        seen.add(key)
        result.append(candidate)
    return result


def _prepare_published_selection(
    selection: dict[str, Any],
    *,
    publication_mode: str,
) -> dict[str, Any]:
    origin_tier = str(selection.get("candidate_tier") or "formal")
    founder_selected = publication_mode == "founder_selected"
    publication = {
        **(selection.get("publication") or {}),
        "mode": publication_mode,
        "origin_tier": origin_tier,
        "selection_tier": "founder_selected" if founder_selected else "formal",
        "promoted_from_watchlist": origin_tier == "watchlist",
        "counts_as_ai_formal": not founder_selected,
    }
    return {
        **selection,
        "candidate_tier": "founder_selected" if founder_selected else "formal",
        "counts_as_formal_record": True,
        "publication": publication,
    }


def build_selected_market_package(
    bundle: dict[str, Any],
    selections: dict[str, Any] | None = None,
    *,
    publication_mode: str = "ai_auto",
) -> dict[str, Any]:
    candidates = bundle.get("candidates") or {}
    watchlist = bundle.get("watchlist") or {}
    parlays = candidates.get("parlays") or {}
    limits = bundle.get("limits") or {}
    selected = selections or bundle.get("recommended") or {}

    def available(group: str) -> list[dict[str, Any]]:
        return [
            *(candidates.get(group) or []),
            *(watchlist.get(group) or []),
        ]

    reference_moneylines = [
        item
        for item in [
            *(available("moneylines")),
            *((bundle.get("manual_pool") or {}).get("moneylines") or []),
            bundle.get("public_moneyline"),
        ]
        if isinstance(item, dict)
    ]
    moneylines = [
        _prepare_published_selection(item, publication_mode=publication_mode)
        for item in _pick_candidates(
            available("moneylines"),
            list(selected.get("moneylines") or []),
            maximum=int(limits.get("moneylines") or 3),
        )
    ]
    eligible_run_lines, suppressed_run_lines = suppress_asian_run_line_conflicts(
        available("run_lines"),
        reference_moneylines=reference_moneylines,
    )
    suppressed_run_line_ids = {
        str(item.get("candidate_id") or "")
        for item in suppressed_run_lines
    }
    run_lines = [
        _prepare_published_selection(item, publication_mode=publication_mode)
        for item in _pick_candidates(
            eligible_run_lines,
            [
                candidate_id
                for candidate_id in selected.get("run_lines") or []
                if str(candidate_id) not in suppressed_run_line_ids
            ],
            maximum=int(limits.get("run_lines") or 3),
        )
    ]
    totals = [
        _prepare_published_selection(item, publication_mode=publication_mode)
        for item in _pick_candidates(
            available("totals"),
            list(selected.get("totals") or []),
            maximum=int(limits.get("totals") or 3),
        )
    ]
    def direction_safe_parlays(items: list[dict[str, Any]]) -> tuple[list[dict[str, Any]], int]:
        safe: list[dict[str, Any]] = []
        suppressed_count = 0
        for item in items:
            _, conflicts = suppress_asian_run_line_conflicts(
                [
                    leg
                    for leg in item.get("legs") or []
                    if isinstance(leg, dict)
                ],
                reference_moneylines=reference_moneylines,
            )
            if conflicts:
                suppressed_count += 1
                continue
            safe.append(item)
        return safe, suppressed_count

    safe_two_leg, suppressed_two_leg = direction_safe_parlays(
        list(parlays.get("two_leg") or [])
    )
    safe_three_leg, suppressed_three_leg = direction_safe_parlays(
        list(parlays.get("three_leg") or [])
    )
    safe_two_leg_ids = {
        str(item.get("candidate_id") or "") for item in safe_two_leg
    }
    safe_three_leg_ids = {
        str(item.get("candidate_id") or "") for item in safe_three_leg
    }
    all_two_leg_ids = {
        str(item.get("candidate_id") or "")
        for item in parlays.get("two_leg") or []
    }
    all_three_leg_ids = {
        str(item.get("candidate_id") or "")
        for item in parlays.get("three_leg") or []
    }
    suppressed_two_leg_ids = all_two_leg_ids - safe_two_leg_ids
    suppressed_three_leg_ids = all_three_leg_ids - safe_three_leg_ids
    two_leg = [
        _prepare_published_selection(item, publication_mode=publication_mode)
        for item in _pick_candidates(
            safe_two_leg,
            [
                candidate_id
                for candidate_id in selected.get("two_leg") or []
                if str(candidate_id) not in suppressed_two_leg_ids
            ],
            maximum=int(limits.get("two_leg") or 2),
        )
    ]
    three_leg = [
        _prepare_published_selection(item, publication_mode=publication_mode)
        for item in _pick_candidates(
            safe_three_leg,
            [
                candidate_id
                for candidate_id in selected.get("three_leg") or []
                if str(candidate_id) not in suppressed_three_leg_ids
            ],
            maximum=int(limits.get("three_leg") or 1),
        )
    ]

    manual_two_specs = selected.get("manual_two_leg") or []
    manual_three_spec = selected.get("manual_three_leg") or []
    if not isinstance(manual_two_specs, list) or len(manual_two_specs) > 2:
        raise ValueError("手動二關串關最多只能建立 2 組")
    manual_two_leg = [
        _founder_manual_parlay(bundle, list(spec or []), size=2, slot=index + 1)
        for index, spec in enumerate(manual_two_specs)
        if spec
    ]
    manual_three_leg = (
        [_founder_manual_parlay(bundle, list(manual_three_spec), size=3, slot=1)]
        if manual_three_spec
        else []
    )
    for parlay in [*manual_two_leg, *manual_three_leg]:
        _, conflicts = suppress_asian_run_line_conflicts(
            [
                leg
                for leg in parlay.get("legs") or []
                if isinstance(leg, dict)
            ],
            reference_moneylines=reference_moneylines,
        )
        if conflicts:
            raise ValueError(
                "手動串關包含與同場獨贏模型方向相反的讓分，不能正式發布"
            )
    if len(two_leg) + len(manual_two_leg) > int(limits.get("two_leg") or 2):
        raise ValueError("二關串關合計最多只能發布 2 組")
    if len(three_leg) + len(manual_three_leg) > int(limits.get("three_leg") or 1):
        raise ValueError("三關串關合計最多只能發布 1 組")
    two_leg.extend(manual_two_leg)
    three_leg.extend(manual_three_leg)

    selected_ids = {
        str(item.get("candidate_id") or "")
        for item in [*moneylines, *run_lines, *totals]
    }
    remaining_watchlist = {
        group: [
            item
            for item in (watchlist.get(group) or [])
            if str(item.get("candidate_id") or "") not in selected_ids
        ]
        for group in ("moneylines", "run_lines", "totals")
    }

    published = bool(moneylines or run_lines or totals or two_leg or three_leg)
    watchlist_count = sum(len(items) for items in remaining_watchlist.values())
    promoted_count = sum(
        1
        for item in [*moneylines, *run_lines, *totals]
        if (item.get("publication") or {}).get("promoted_from_watchlist")
    )
    founder_count = (
        len(moneylines) + len(run_lines) + len(totals) + len(two_leg) + len(three_leg)
        if publication_mode == "founder_selected"
        else 0
    )
    recommendation_status = (
        "formal_published"
        if published
        else "watchlist_only"
        if watchlist_count
        else "no_recommendation"
    )
    return {
        "date": bundle.get("date"),
        "published": published,
        "locked": False,
        "generated_at": bundle.get("generated_at") or _utc_now(),
        "moneyline": bundle.get("public_moneyline"),
        "moneylines": moneylines,
        "run_lines": run_lines,
        "totals": totals,
        "parlays": {"two_leg": two_leg, "three_leg": three_leg},
        "watchlist": remaining_watchlist,
        "recommendation_status": recommendation_status,
        "run_line": run_lines[0] if run_lines else None,
        "total": totals[0] if totals else None,
        "candidate_counts": bundle.get("candidate_counts") or {},
        "thresholds": bundle.get("thresholds") or {},
        "limits": limits,
        "publication": {
            "mode": publication_mode,
            "direction_consistency": {
                "policy": "asian_run_line_same_team_as_moneyline",
                "suppressed_run_lines": len(suppressed_run_lines),
                "suppressed_two_leg": suppressed_two_leg,
                "suppressed_three_leg": suppressed_three_leg,
            },
            "selected_counts": {
                "moneylines": len(moneylines),
                "run_lines": len(run_lines),
                "totals": len(totals),
                "two_leg": len(two_leg),
                "three_leg": len(three_leg),
            },
            "founder_selected_count": founder_count,
            "promoted_watchlist_count": promoted_count,
            "ai_formal_count": 0 if publication_mode == "founder_selected" else (
                len(moneylines) + len(run_lines) + len(totals) + len(two_leg) + len(three_leg)
            ),
        },
        "model_version": bundle.get("model_version") or "dm-markets-v3.1",
        "message": (
            "正式會員玩法已完成並鎖定。"
            if published
            else "今日沒有正式推薦；已提供創辦人觀察名單。"
            if watchlist_count
            else "今日沒有通過門檻的正式推薦或觀察名單。"
        ),
    }


def build_daily_market_package(
    recommendation_date: str,
    analyses: list[dict[str, Any]],
    odds_items: list[dict[str, Any]],
    public_selection: dict[str, Any] | None,
    *,
    minimum_probability: float = 53.0,
    minimum_edge: float = 3.0,
    minimum_projection_quality: float = 0.45,
    minimum_parlay_probability: float = 54.0,
) -> dict[str, Any]:
    bundle = build_daily_market_candidates(
        recommendation_date,
        analyses,
        odds_items,
        public_selection,
        minimum_probability=minimum_probability,
        minimum_edge=minimum_edge,
        minimum_projection_quality=minimum_projection_quality,
        minimum_parlay_probability=minimum_parlay_probability,
    )
    return build_selected_market_package(bundle, publication_mode="ai_auto")
