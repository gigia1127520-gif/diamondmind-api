from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

import httpx

from .billing import iso_utc, parse_datetime
from .config import Settings

UTC = timezone.utc


class AnnouncementError(RuntimeError):
    pass


ALLOWED_AUDIENCES = {"all", "free", "pro"}
ALLOWED_SEVERITIES = {"general", "important", "emergency"}
ALLOWED_ACTION_PAGES = {
    "", "homePage", "gamesPage", "predictionPage", "recordsPage",
    "membershipPage", "morePage",
}
SEVERITY_PRIORITY = {"general": 10, "important": 50, "emergency": 100}


def _clean_text(value: Any, *, maximum: int = 5000) -> str:
    return str(value or "").strip()[:maximum]


def _safe_row(row: dict[str, Any]) -> dict[str, Any]:
    return {
        "id": row.get("id"),
        "title": row.get("title"),
        "body": row.get("body"),
        "summary": row.get("summary"),
        "severity": row.get("severity") or "general",
        "audience": row.get("audience") or "all",
        "show_home": bool(row.get("show_home")),
        "show_login_modal": bool(row.get("show_login_modal")),
        "dismissible_today": bool(row.get("dismissible_today", True)),
        "action_label": row.get("action_label"),
        "action_page": row.get("action_page"),
        "starts_at": row.get("starts_at"),
        "ends_at": row.get("ends_at"),
        "is_active": bool(row.get("is_active")),
        "priority": int(row.get("priority") or 0),
        "created_at": row.get("created_at"),
        "updated_at": row.get("updated_at"),
    }


class AnnouncementRepository:
    """Server-side Supabase announcement storage.

    The secret key remains on Render. Public browsers only receive the safe
    fields returned by the API routes in main.py.
    """

    def __init__(self, settings: Settings, transport: httpx.AsyncBaseTransport | None = None) -> None:
        self.enabled = settings.records_enabled
        key = settings.supabase_secret_key
        headers = {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "User-Agent": "DiamondMind-Announcements/17.6.0",
            "apikey": key,
        }
        if key and not key.startswith("sb_secret_"):
            headers["Authorization"] = f"Bearer {key}"
        base_url = (
            f"{settings.supabase_url}/rest/v1/"
            if settings.supabase_url
            else "https://announcements.invalid/rest/v1/"
        )
        self.client = httpx.AsyncClient(
            base_url=base_url,
            headers=headers,
            timeout=max(settings.request_timeout_seconds, 20.0),
            follow_redirects=True,
            trust_env=False,
            transport=transport,
        )

    async def aclose(self) -> None:
        await self.client.aclose()

    def _require(self) -> None:
        if not self.enabled:
            raise AnnouncementError("Announcement storage is not configured")

    async def _request(self, method: str, path: str, **kwargs: Any) -> Any:
        self._require()
        try:
            response = await self.client.request(method, path, **kwargs)
            response.raise_for_status()
            return response.json() if response.content else None
        except httpx.HTTPStatusError as exc:
            detail = exc.response.text[:350]
            if exc.response.status_code in {400, 404} and "announcements" in detail:
                raise AnnouncementError("Announcement database table has not been installed") from exc
            raise AnnouncementError(f"Announcement database request failed: HTTP {exc.response.status_code}") from exc
        except (httpx.HTTPError, ValueError) as exc:
            raise AnnouncementError("Announcement database is temporarily unavailable") from exc

    async def list_all(self, *, limit: int = 500) -> list[dict[str, Any]]:
        data = await self._request(
            "GET",
            "announcements",
            params={"select": "*", "order": "priority.desc,created_at.desc", "limit": limit},
        )
        if not isinstance(data, list):
            raise AnnouncementError("Announcement database returned an invalid list")
        return [item for item in data if isinstance(item, dict)]

    async def create(self, payload: dict[str, Any]) -> dict[str, Any]:
        data = await self._request(
            "POST",
            "announcements",
            headers={"Prefer": "return=representation"},
            json=payload,
        )
        if not isinstance(data, list) or not data:
            raise AnnouncementError("Announcement could not be created")
        return data[0]

    async def update(self, announcement_id: str, payload: dict[str, Any]) -> dict[str, Any]:
        data = await self._request(
            "PATCH",
            "announcements",
            params={"id": f"eq.{announcement_id}"},
            headers={"Prefer": "return=representation"},
            json=payload,
        )
        if not isinstance(data, list) or not data:
            raise AnnouncementError("Announcement was not found")
        return data[0]

    async def delete(self, announcement_id: str) -> None:
        await self._request(
            "DELETE",
            "announcements",
            params={"id": f"eq.{announcement_id}"},
            headers={"Prefer": "return=minimal"},
        )


class AnnouncementService:
    def __init__(self, repository: AnnouncementRepository) -> None:
        self.repository = repository

    @staticmethod
    def normalize_payload(payload: dict[str, Any], actor: dict[str, Any]) -> dict[str, Any]:
        title = _clean_text(payload.get("title"), maximum=120)
        body = _clean_text(payload.get("body"), maximum=6000)
        summary = _clean_text(payload.get("summary"), maximum=320)
        if not title:
            raise AnnouncementError("公告標題不能空白")
        if not body:
            raise AnnouncementError("公告內容不能空白")
        severity = _clean_text(payload.get("severity"), maximum=20).lower() or "general"
        audience = _clean_text(payload.get("audience"), maximum=20).lower() or "all"
        action_page = _clean_text(payload.get("action_page"), maximum=60)
        if severity not in ALLOWED_SEVERITIES:
            raise AnnouncementError("公告重要程度不正確")
        if audience not in ALLOWED_AUDIENCES:
            raise AnnouncementError("公告顯示對象不正確")
        if action_page not in ALLOWED_ACTION_PAGES:
            raise AnnouncementError("公告跳轉頁面不正確")
        starts_at = parse_datetime(payload.get("starts_at"))
        ends_at = parse_datetime(payload.get("ends_at"))
        if starts_at and ends_at and ends_at <= starts_at:
            raise AnnouncementError("公告結束時間必須晚於開始時間")
        dismissible = bool(payload.get("dismissible_today", True))
        if severity == "emergency":
            dismissible = bool(payload.get("dismissible_today", False))
        now = iso_utc()
        return {
            "title": title,
            "body": body,
            "summary": summary or body[:140],
            "severity": severity,
            "audience": audience,
            "show_home": bool(payload.get("show_home", True)),
            "show_login_modal": bool(payload.get("show_login_modal", True)),
            "dismissible_today": dismissible,
            "action_label": _clean_text(payload.get("action_label"), maximum=40) or None,
            "action_page": action_page or None,
            "starts_at": iso_utc(starts_at) if starts_at else now,
            "ends_at": iso_utc(ends_at) if ends_at else None,
            "is_active": bool(payload.get("is_active", True)),
            "priority": int(payload.get("priority") or SEVERITY_PRIORITY[severity]),
            "updated_by": actor.get("id"),
            "updated_by_email": actor.get("email"),
            "updated_at": now,
        }

    async def active(self, *, role: str, placement: str) -> list[dict[str, Any]]:
        rows = await self.repository.list_all(limit=200)
        now = datetime.now(UTC)
        output: list[dict[str, Any]] = []
        for row in rows:
            if not bool(row.get("is_active")):
                continue
            starts_at = parse_datetime(row.get("starts_at"))
            ends_at = parse_datetime(row.get("ends_at"))
            if starts_at and starts_at > now:
                continue
            if ends_at and ends_at <= now:
                continue
            if placement == "home" and not bool(row.get("show_home")):
                continue
            if placement == "login" and not bool(row.get("show_login_modal")):
                continue
            audience = str(row.get("audience") or "all").lower()
            allowed = audience == "all" or audience == role or (audience == "pro" and role == "admin")
            if not allowed:
                continue
            output.append(_safe_row(row))
        output.sort(key=lambda item: (int(item.get("priority") or 0), str(item.get("created_at") or "")), reverse=True)
        return output[:10 if placement == "home" else 1]

    async def admin_list(self) -> list[dict[str, Any]]:
        return [_safe_row(item) for item in await self.repository.list_all(limit=500)]

    async def create(self, payload: dict[str, Any], actor: dict[str, Any]) -> dict[str, Any]:
        normalized = self.normalize_payload(payload, actor)
        normalized.update({
            "created_by": actor.get("id"),
            "created_by_email": actor.get("email"),
            "created_at": iso_utc(),
        })
        return _safe_row(await self.repository.create(normalized))

    async def update(self, announcement_id: str, payload: dict[str, Any], actor: dict[str, Any]) -> dict[str, Any]:
        normalized = self.normalize_payload(payload, actor)
        return _safe_row(await self.repository.update(announcement_id, normalized))

    async def delete(self, announcement_id: str) -> None:
        await self.repository.delete(announcement_id)
