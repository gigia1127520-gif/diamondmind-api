from __future__ import annotations

import asyncio
import json
import re
from dataclasses import dataclass
from datetime import date, datetime, timedelta, timezone
from typing import Any, Iterable
from urllib.parse import urlencode
from zoneinfo import ZoneInfo

import httpx

from .advanced import StatcastService, aggregate_metrics
from .cache import AsyncTTLCache
from .config import Settings
from .model import analyze_matchup, clamp, pythagorean_win_pct
from .weather import WeatherService, environment_run_adjustment, fahrenheit_to_celsius
from .validation import aggregate_validation, game_timing, iso_utc, lineup_validation, validate_roster_member


TAIPEI = ZoneInfo("Asia/Taipei")

TEAM_ABBR = {
    "Arizona Diamondbacks": "ARI",
    "Atlanta Braves": "ATL",
    "Baltimore Orioles": "BAL",
    "Boston Red Sox": "BOS",
    "Chicago Cubs": "CHC",
    "Chicago White Sox": "CWS",
    "Cincinnati Reds": "CIN",
    "Cleveland Guardians": "CLE",
    "Colorado Rockies": "COL",
    "Detroit Tigers": "DET",
    "Houston Astros": "HOU",
    "Kansas City Royals": "KC",
    "Los Angeles Angels": "LAA",
    "Los Angeles Dodgers": "LAD",
    "Miami Marlins": "MIA",
    "Milwaukee Brewers": "MIL",
    "Minnesota Twins": "MIN",
    "New York Mets": "NYM",
    "New York Yankees": "NYY",
    "Athletics": "ATH",
    "Oakland Athletics": "OAK",
    "Philadelphia Phillies": "PHI",
    "Pittsburgh Pirates": "PIT",
    "San Diego Padres": "SD",
    "San Francisco Giants": "SF",
    "Seattle Mariners": "SEA",
    "St. Louis Cardinals": "STL",
    "Tampa Bay Rays": "TB",
    "Texas Rangers": "TEX",
    "Toronto Blue Jays": "TOR",
    "Washington Nationals": "WSH",
    "American League All-Stars": "AL",
    "National League All-Stars": "NL",
    "AL All-Stars": "AL",
    "NL All-Stars": "NL",
    "American League": "AL",
    "National League": "NL",
}

ALL_STAR_TEAMS = {
    159: {"name": "American League All-Stars", "abbr": "AL"},
    160: {"name": "National League All-Stars", "abbr": "NL"},
}

GAME_TYPE_META = {
    "R": ("regular_season", "例行賽", True),
    "F": ("postseason", "外卡系列賽", True),
    "D": ("postseason", "分區系列賽", True),
    "L": ("postseason", "聯盟冠軍賽", True),
    "W": ("postseason", "世界大賽", True),
    "P": ("postseason", "季後賽", True),
    "A": ("all_star", "明星賽", False),
    "E": ("exhibition", "表演賽", False),
    "S": ("spring_training", "春訓", False),
}


def game_type_metadata(value: Any) -> dict[str, Any]:
    code = str(value or "R").strip().upper() or "R"
    context, label, auto_eligible = GAME_TYPE_META.get(code, ("unsupported", "特殊賽事", False))
    return {
        "game_type": code,
        "season_context": context,
        "event_label": label,
        "special_event": context != "regular_season",
        "auto_recommendation_eligible": auto_eligible,
    }


class MLBUpstreamError(RuntimeError):
    pass


@dataclass
class FetchPayload:
    data: dict[str, Any]
    cache_status: str
    fetched_at: str


def _iso_utc(timestamp: float | None = None) -> str:
    dt = datetime.fromtimestamp(timestamp, tz=timezone.utc) if timestamp else datetime.now(timezone.utc)
    return dt.isoformat().replace("+00:00", "Z")


def _parse_game_datetime(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def _float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _int(value: Any) -> int | None:
    try:
        return int(float(value))
    except (TypeError, ValueError):
        return None


def _innings_to_outs(value: Any) -> int:
    if value in (None, ""):
        return 0
    text = str(value)
    if "." in text:
        whole, fraction = text.split(".", 1)
        return max(0, _int(whole) or 0) * 3 + min(2, max(0, _int(fraction[:1]) or 0))
    return max(0, _int(text) or 0) * 3


def _outs_to_innings(outs: int) -> str:
    return f"{max(0, outs) // 3}.{max(0, outs) % 3}"


def _safe_rate(numerator: Any, denominator: Any) -> float | None:
    num = _float(numerator)
    den = _float(denominator)
    if num is None or den is None or den == 0:
        return None
    return num / den


def _stats_type(group: dict[str, Any]) -> str:
    stat_type = group.get("type") or {}
    return str(stat_type.get("displayName") or stat_type.get("name") or group.get("type") or "").lower()


def _stats_groups(payload: dict[str, Any]) -> dict[str, list[dict[str, Any]]]:
    result: dict[str, list[dict[str, Any]]] = {}
    for group in payload.get("stats") or []:
        result.setdefault(_stats_type(group), []).extend(group.get("splits") or [])
    return result


def _first_stat(splits: list[dict[str, Any]]) -> dict[str, Any]:
    return (splits[0].get("stat") or {}) if splits else {}


def _pitching_summary(stat: dict[str, Any]) -> dict[str, Any]:
    strikeouts = _int(stat.get("strikeOuts"))
    walks = _int(stat.get("baseOnBalls"))
    innings = stat.get("inningsPitched")
    return {
        "era": _float(stat.get("era")),
        "whip": _float(stat.get("whip")),
        "k_bb": round(strikeouts / walks, 2) if strikeouts is not None and walks and walks > 0 else None,
        "avg_against": _float(stat.get("avg")),
        "wins": _int(stat.get("wins")),
        "losses": _int(stat.get("losses")),
        "games": _int(stat.get("gamesPlayed")) or _int(stat.get("gamesPitched")),
        "games_started": _int(stat.get("gamesStarted")),
        "games_finished": _int(stat.get("gamesFinished")),
        "saves": _int(stat.get("saves")),
        "save_opportunities": _int(stat.get("saveOpportunities")),
        "holds": _int(stat.get("holds")),
        "strikeouts": strikeouts,
        "walks": walks,
        "hits": _int(stat.get("hits")),
        "home_runs": _int(stat.get("homeRuns")),
        "earned_runs": _int(stat.get("earnedRuns")),
        "innings_pitched": innings,
        "outs": _innings_to_outs(innings),
        "pitches": _int(stat.get("numberOfPitches")) or _int(stat.get("pitchesThrown")),
    }


def _hitting_summary(stat: dict[str, Any]) -> dict[str, Any]:
    pa = _int(stat.get("plateAppearances"))
    at_bats = _int(stat.get("atBats"))
    home_runs = _int(stat.get("homeRuns"))
    return {
        "games": _int(stat.get("gamesPlayed")),
        "runs": _int(stat.get("runs")),
        "avg": _float(stat.get("avg")),
        "obp": _float(stat.get("obp")),
        "slg": _float(stat.get("slg")),
        "ops": _float(stat.get("ops")),
        "home_runs": home_runs,
        "plate_appearances": pa,
        "at_bats": at_bats,
        "hr_per_pa": round(home_runs / pa, 4) if home_runs is not None and pa and pa > 0 else None,
    }


def _aggregate_pitching_splits(splits: Iterable[dict[str, Any]]) -> dict[str, Any]:
    outs = hits = walks = strikeouts = earned_runs = pitches = games = 0
    used = 0
    for split in splits:
        stat = split.get("stat") or {}
        used += 1
        outs += _innings_to_outs(stat.get("inningsPitched"))
        hits += _int(stat.get("hits")) or 0
        walks += _int(stat.get("baseOnBalls")) or 0
        strikeouts += _int(stat.get("strikeOuts")) or 0
        earned_runs += _int(stat.get("earnedRuns")) or 0
        pitches += _int(stat.get("numberOfPitches")) or _int(stat.get("pitchesThrown")) or 0
        games += _int(stat.get("gamesPlayed")) or 1
    innings = outs / 3.0 if outs else 0.0
    return {
        "available": used > 0 and outs > 0,
        "games": games if used else 0,
        "era": round(earned_runs * 9 / innings, 2) if innings else None,
        "whip": round((hits + walks) / innings, 2) if innings else None,
        "k_bb": round(strikeouts / walks, 2) if walks else None,
        "strikeouts": strikeouts,
        "walks": walks,
        "hits": hits,
        "earned_runs": earned_runs,
        "innings_pitched": _outs_to_innings(outs),
        "outs": outs,
        "pitches": pitches,
    }


def _split_date(split: dict[str, Any]) -> date | None:
    raw = split.get("date") or (split.get("game") or {}).get("gameDate")
    if not raw:
        return None
    try:
        return date.fromisoformat(str(raw)[:10])
    except ValueError:
        return None


def _is_home_split(split: dict[str, Any]) -> bool | None:
    if isinstance(split.get("isHome"), bool):
        return split["isHome"]
    game = split.get("game") or {}
    if isinstance(game.get("isHome"), bool):
        return game["isHome"]
    split_info = split.get("split") or {}
    code = str(split_info.get("code") or split_info.get("description") or "").lower()
    if "home" in code:
        return True
    if "away" in code or "road" in code:
        return False
    return None


class MLBService:
    def __init__(self, settings: Settings, transport: httpx.AsyncBaseTransport | None = None) -> None:
        self.settings = settings
        self.cache = AsyncTTLCache()
        self.client = httpx.AsyncClient(
            timeout=settings.request_timeout_seconds,
            follow_redirects=True,
            trust_env=False,
            transport=transport,
            headers={"User-Agent": "DiamondMind/2.0"},
        )
        self.statcast = StatcastService(settings, transport=transport)
        self.weather = WeatherService(settings, transport=transport)
        self._enrichment_semaphore = asyncio.Semaphore(4)

    async def aclose(self) -> None:
        await asyncio.gather(
            self.client.aclose(),
            self.statcast.aclose(),
            self.weather.aclose(),
        )

    async def _get_json(
        self,
        path_or_url: str,
        params: dict[str, Any] | None = None,
        ttl_seconds: int | None = None,
    ) -> FetchPayload:
        params = {key: value for key, value in (params or {}).items() if value is not None}
        url = path_or_url if path_or_url.startswith("http") else f"{self.settings.mlb_api_base}{path_or_url}"
        key = f"{url}?{urlencode(sorted((str(key), str(value)) for key, value in params.items()))}"
        ttl = ttl_seconds or self.settings.cache_ttl_seconds
        cached = self.cache.get(key)
        if cached and cached.is_fresh:
            return FetchPayload(cached.value, "hit", _iso_utc(cached.stored_at))
        async with self.cache.lock(key):
            cached = self.cache.get(key)
            if cached and cached.is_fresh:
                return FetchPayload(cached.value, "hit", _iso_utc(cached.stored_at))
            try:
                response = await self.client.get(url, params=params)
                response.raise_for_status()
                data = response.json()
                if not isinstance(data, dict):
                    raise ValueError("Unexpected MLB response")
                entry = self.cache.set(key, data, ttl, self.settings.stale_ttl_seconds)
                return FetchPayload(data, "miss", _iso_utc(entry.stored_at))
            except (httpx.HTTPError, ValueError, json.JSONDecodeError) as exc:
                if cached and cached.can_serve_stale:
                    return FetchPayload(cached.value, "stale", _iso_utc(cached.stored_at))
                raise MLBUpstreamError("MLB data source is temporarily unavailable") from exc

    @staticmethod
    def _team(team_side: dict[str, Any]) -> dict[str, Any]:
        team = team_side.get("team") or {}
        team_id = _int(team.get("id"))
        all_star = ALL_STAR_TEAMS.get(team_id)
        name = all_star["name"] if all_star else (team.get("name") or "Unknown")
        abbr = all_star["abbr"] if all_star else TEAM_ABBR.get(name, (name.split(" ")[-1][:3] or "TBD").upper())
        record = team_side.get("leagueRecord") or {}
        pitcher = team_side.get("probablePitcher") or {}
        return {
            "id": team_id,
            "name": name,
            "abbr": abbr,
            "score": _int(team_side.get("score")),
            "record": {
                "wins": _int(record.get("wins")),
                "losses": _int(record.get("losses")),
                "pct": _float(record.get("pct")),
            },
            "probable_pitcher": {
                "id": _int(pitcher.get("id")),
                "name": pitcher.get("fullName") or "尚未公布",
            },
        }

    @classmethod
    def _normalize_game(cls, game: dict[str, Any]) -> dict[str, Any]:
        game_date = game.get("gameDate")
        dt = _parse_game_datetime(game_date)
        taipei_dt = dt.astimezone(TAIPEI)
        status = game.get("status") or {}
        abstract = str(status.get("abstractGameState") or "Preview").lower()
        state = "live" if abstract == "live" else "final" if abstract == "final" else "upcoming"
        linescore = game.get("linescore") or {}
        venue = game.get("venue") or {}
        return {
            **game_type_metadata(game.get("gameType")),
            "game_pk": _int(game.get("gamePk")),
            "game_date": game_date,
            "date_taiwan": taipei_dt.date().isoformat(),
            "time_taiwan": taipei_dt.strftime("%H:%M"),
            "status": state,
            "detailed_status": status.get("detailedState") or "",
            "inning": _int(linescore.get("currentInning")),
            "inning_state": linescore.get("inningState") or "",
            "venue_id": _int(venue.get("id")),
            "venue": venue.get("name") or "",
            "away": cls._team((game.get("teams") or {}).get("away") or {}),
            "home": cls._team((game.get("teams") or {}).get("home") or {}),
        }

    async def games_for_date(self, taiwan_date: date) -> dict[str, Any]:
        adjacent_dates = [taiwan_date - timedelta(days=1), taiwan_date, taiwan_date + timedelta(days=1)]
        payloads = await asyncio.gather(
            *[
                self._get_json(
                    "/schedule",
                    {
                        "sportId": 1,
                        "date": day.isoformat(),
                        "hydrate": "probablePitcher,linescore,team,venue",
                    },
                )
                for day in adjacent_dates
            ]
        )
        raw_games = [
            game
            for payload in payloads
            for day in payload.data.get("dates", [])
            for game in day.get("games", [])
        ]
        unique = {game.get("gamePk"): game for game in raw_games if game.get("gamePk")}
        items = [
            self._normalize_game(game)
            for game in unique.values()
            if _parse_game_datetime(game["gameDate"]).astimezone(TAIPEI).date() == taiwan_date
        ]
        items.sort(key=lambda game: game["game_date"])
        statuses = {payload.cache_status for payload in payloads}
        cache_status = "stale" if "stale" in statuses else "miss" if "miss" in statuses else "hit"
        return {
            "date": taiwan_date.isoformat(),
            "timezone": "Asia/Taipei",
            "count": len(items),
            "items": items,
            "meta": {
                "source": "MLB Stats API",
                "cache": cache_status,
                "updated_at": max(payload.fetched_at for payload in payloads),
            },
        }

    @staticmethod
    def _last_ten(record: dict[str, Any]) -> dict[str, int | None]:
        split_records = (record.get("records") or {}).get("splitRecords") or []
        for split in split_records:
            split_type = str(split.get("type") or "").lower().replace(" ", "")
            if split_type in {"lastten", "last10"}:
                return {"wins": _int(split.get("wins")), "losses": _int(split.get("losses"))}
        return {"wins": None, "losses": None}

    async def standings(self, season: int) -> tuple[dict[int, dict[str, Any]], dict[str, Any]]:
        payload = await self._get_json(
            "/standings",
            {
                "leagueId": "103,104",
                "season": season,
                "standingsTypes": "regularSeason",
                "hydrate": "team",
            },
            ttl_seconds=300,
        )
        teams: dict[int, dict[str, Any]] = {}
        for division in payload.data.get("records", []):
            for record in division.get("teamRecords", []):
                team = record.get("team") or {}
                team_id = _int(team.get("id"))
                if team_id is None:
                    continue
                league_record = record.get("leagueRecord") or {}
                wins = _int(record.get("wins"))
                losses = _int(record.get("losses"))
                if wins is None:
                    wins = _int(league_record.get("wins"))
                if losses is None:
                    losses = _int(league_record.get("losses"))
                winning_pct = _float(record.get("winningPercentage"))
                if winning_pct is None:
                    winning_pct = _float(league_record.get("pct"))
                runs_scored = _int(record.get("runsScored"))
                runs_allowed = _int(record.get("runsAllowed"))
                teams[team_id] = {
                    "team_id": team_id,
                    "team_name": team.get("name") or "Unknown",
                    "wins": wins,
                    "losses": losses,
                    "winning_pct": winning_pct,
                    "runs_scored": runs_scored,
                    "runs_allowed": runs_allowed,
                    "run_differential": _int(record.get("runDifferential")),
                    "pythagorean_pct": pythagorean_win_pct(runs_scored, runs_allowed),
                    "last_ten": self._last_ten(record),
                    "streak": (record.get("streak") or {}).get("streakCode"),
                }
        return teams, {"cache": payload.cache_status, "updated_at": payload.fetched_at}

    @staticmethod
    def _fallback_team(game_team: dict[str, Any]) -> dict[str, Any]:
        record = game_team.get("record") or {}
        return {
            "team_id": game_team.get("id"),
            "team_name": game_team.get("name"),
            "wins": record.get("wins"),
            "losses": record.get("losses"),
            "winning_pct": record.get("pct"),
            "runs_scored": None,
            "runs_allowed": None,
            "run_differential": None,
            "pythagorean_pct": None,
            "last_ten": {"wins": None, "losses": None},
            "streak": None,
        }

    async def _person_stats_payload(self, person_id: int, season: int) -> dict[str, Any]:
        """Load pitcher season and game-log data without making one failed subrequest fatal.

        MLB occasionally rejects the combined ``season,gameLog`` form for a
        player while the two individual stat types still work. V16.3 merges
        every successful response and only raises when none of them works.
        """

        collected: list[dict[str, Any]] = []
        try:
            combined = await self._get_json(
                f"/people/{person_id}/stats",
                {"stats": "season,gameLog", "group": "pitching", "season": season},
                ttl_seconds=300,
            )
            collected.extend(combined.data.get("stats") or [])
        except MLBUpstreamError:
            pass

        present_types = {_stats_type(group) for group in collected}
        requests = []
        if "season" not in present_types:
            requests.append(
                self._get_json(
                    f"/people/{person_id}/stats",
                    {"stats": "season", "group": "pitching", "season": season},
                    ttl_seconds=300,
                )
            )
        if not ({"gamelog", "game log"} & present_types):
            requests.append(
                self._get_json(
                    f"/people/{person_id}/stats",
                    {"stats": "gameLog", "group": "pitching", "season": season},
                    ttl_seconds=180,
                )
            )
        if requests:
            payloads = await asyncio.gather(*requests, return_exceptions=True)
            for payload in payloads:
                if isinstance(payload, FetchPayload):
                    collected.extend(payload.data.get("stats") or [])

        if not collected:
            raise MLBUpstreamError("Pitcher statistics are temporarily unavailable")
        return {"stats": collected}

    async def pitcher_profile(
        self,
        person_id: int | None,
        season: int,
        game_day: date,
        location: str,
        live_player: dict[str, Any] | None = None,
    ) -> dict[str, Any] | None:
        if not person_id:
            return None

        stats_payload: dict[str, Any] = {}
        person: dict[str, Any] = {}
        advanced: dict[str, Any] | None = None
        source_errors: list[str] = []

        results = await asyncio.gather(
            self._person_stats_payload(int(person_id), season),
            self._get_json(f"/people/{person_id}", ttl_seconds=21600),
            self.statcast.pitcher_metrics(int(person_id), season),
            return_exceptions=True,
        )
        stats_result, person_result, advanced_result = results
        if isinstance(stats_result, Exception):
            source_errors.append("season_stats")
        else:
            stats_payload = stats_result
        if isinstance(person_result, Exception):
            source_errors.append("person_profile")
        else:
            people = person_result.data.get("people") or []
            person = people[0] if people else {}
        if isinstance(advanced_result, Exception):
            source_errors.append("statcast")
        elif isinstance(advanced_result, dict):
            advanced = advanced_result

        groups = _stats_groups(stats_payload)
        season_splits = groups.get("season") or []
        game_logs = groups.get("gamelog") or groups.get("game log") or []
        live_stat = (((live_player or {}).get("seasonStats") or {}).get("pitching") or {})
        season_stat = _first_stat(season_splits) or live_stat
        season_summary = _pitching_summary(season_stat)

        prior_logs = [split for split in game_logs if (_split_date(split) or game_day) < game_day]
        prior_logs.sort(key=lambda split: _split_date(split) or date.min, reverse=True)
        recent_3 = _aggregate_pitching_splits(prior_logs[:3])
        home_logs = [split for split in prior_logs if _is_home_split(split) is True]
        away_logs = [split for split in prior_logs if _is_home_split(split) is False]
        pitch_hand = (
            ((live_player or {}).get("pitchHand") or {}).get("code")
            or ((person.get("pitchHand") or {}).get("code"))
            or None
        )

        core_fields = ("era", "whip", "k_bb", "avg_against")
        season_coverage = sum(season_summary.get(field) is not None for field in core_fields) / len(core_fields)
        recent_coverage = 1.0 if recent_3.get("available") else 0.0
        split_profile = _aggregate_pitching_splits(away_logs if location == "away" else home_logs)
        split_coverage = 1.0 if split_profile.get("available") else 0.0
        data_quality = clamp(season_coverage * 0.68 + recent_coverage * 0.20 + split_coverage * 0.12, 0.0, 1.0)
        available = season_coverage > 0

        return {
            "person_id": int(person_id),
            "name": person.get("fullName") or (live_player or {}).get("fullName"),
            "pitch_hand": pitch_hand,
            "season": season_summary,
            "recent_3": recent_3,
            "splits": {
                "home": _aggregate_pitching_splits(home_logs),
                "away": _aggregate_pitching_splits(away_logs),
            },
            "game_location": location,
            "advanced": advanced or {"available": False},
            "available": available,
            "data_quality": round(data_quality, 2),
            "source_errors": source_errors,
            "meta": {
                "sources": ["MLB Stats API", *( ["Baseball Savant"] if advanced and advanced.get("available") else [] )],
                "updated_at": max([value for value in [advanced.get("updated_at") if isinstance(advanced, dict) else None, iso_utc()] if value]),
            },
            # Backward-compatible flat keys.
            **season_summary,
        }

    async def pitcher_stats(self, person_id: int | None, season: int) -> dict[str, Any] | None:
        return await self.pitcher_profile(person_id, season, date.today() + timedelta(days=1), "unknown")

    @staticmethod
    def _live_player_map(payload: dict[str, Any]) -> dict[int, dict[str, Any]]:
        players = (payload.get("gameData") or {}).get("players") or {}
        mapped: dict[int, dict[str, Any]] = {}
        for key, value in players.items():
            player_id = _int((value or {}).get("id")) or _int(str(key).replace("ID", ""))
            if player_id:
                mapped[player_id] = value or {}
        return mapped

    @staticmethod
    def _box_player_entry(entry: dict[str, Any], game_player: dict[str, Any]) -> dict[str, Any]:
        person = entry.get("person") or game_player or {}
        player_id = _int(person.get("id"))
        hitting = ((entry.get("seasonStats") or {}).get("hitting") or {})
        pitching = ((entry.get("seasonStats") or {}).get("pitching") or {})
        position = entry.get("position") or game_player.get("primaryPosition") or {}
        return {
            "id": player_id,
            "name": person.get("fullName") or game_player.get("fullName") or "",
            "position": position.get("abbreviation") or position.get("code") or "",
            "bat_side": ((game_player.get("batSide") or {}).get("code")),
            "pitch_hand": ((game_player.get("pitchHand") or {}).get("code")),
            "hitting": _hitting_summary(hitting),
            "pitching": _pitching_summary(pitching),
            "raw": entry,
        }

    async def _live_context(self, game_pk: int) -> dict[str, Any]:
        try:
            payload = await self._get_json(
                f"{self.settings.mlb_live_base}/game/{game_pk}/feed/live",
                ttl_seconds=30,
            )
        except MLBUpstreamError:
            return {
                "available": False,
                "lineups": {"away": {}, "home": {}},
                "players": {},
                "weather": {},
                "roof_closed": False,
                "probable_pitchers": {"away": {}, "home": {}},
            }
        game_players = self._live_player_map(payload.data)
        box_teams = (((payload.data.get("liveData") or {}).get("boxscore") or {}).get("teams") or {})

        def side_context(side: str) -> dict[str, Any]:
            team = box_teams.get(side) or {}
            order = [_int(player_id) for player_id in team.get("battingOrder") or []]
            order_ids = [player_id for player_id in order if player_id]
            roster: list[dict[str, Any]] = []
            for key, entry in (team.get("players") or {}).items():
                player_id = _int((entry.get("person") or {}).get("id")) or _int(str(key).replace("ID", ""))
                game_player = game_players.get(player_id or -1, {})
                row = self._box_player_entry(entry or {}, game_player)
                if row.get("id"):
                    roster.append(row)
            roster_by_id = {int(row["id"]): row for row in roster if row.get("id")}
            batting_order = [roster_by_id[player_id] for player_id in order_ids if player_id in roster_by_id]
            return {
                "confirmed": len(batting_order) >= 8,
                "batting_order": batting_order,
                "roster": roster,
                "batting_order_ids": order_ids,
            }

        game_data = payload.data.get("gameData") or {}
        raw_weather = game_data.get("weather") or {}
        condition = str(raw_weather.get("condition") or "")
        wind = str(raw_weather.get("wind") or "")
        roof_closed = "roof closed" in condition.lower() or "closed roof" in condition.lower()
        probable = game_data.get("probablePitchers") or {}

        def probable_side(side: str) -> dict[str, Any]:
            person = probable.get(side) or {}
            return {
                "id": _int(person.get("id")),
                "name": person.get("fullName") or person.get("name"),
            }

        live_temp_f = _float(raw_weather.get("temp"))
        return {
            "available": True,
            "lineups": {"away": side_context("away"), "home": side_context("home")},
            "players": game_players,
            "probable_pitchers": {"away": probable_side("away"), "home": probable_side("home")},
            "weather": {
                "available": bool(raw_weather),
                "temperature_f": live_temp_f,
                "temperature_c": fahrenheit_to_celsius(live_temp_f),
                "condition": condition,
                "wind_text": wind,
                "wind_speed_mph": _float((match.group(1) if (match := re.search(r"([0-9]+(?:\.[0-9]+)?)\s*mph", wind, re.I)) else None)),
                "source": "MLB game feed",
            },
            "roof_closed": roof_closed,
            "cache": payload.cache_status,
        }

    @staticmethod
    def _official_lineup_profile(
        side: dict[str, Any],
        advanced_by_player: dict[int, dict[str, Any]],
        *,
        team_id: int,
        roster_date: str,
        active_roster_ids: set[int],
    ) -> dict[str, Any]:
        order = side.get("batting_order") or []
        roster = [
            row
            for row in side.get("roster") or []
            if str(row.get("position") or "").upper() != "P"
            and (_int((row.get("hitting") or {}).get("plate_appearances")) or 0) > 0
        ]

        def weighted(field: str, rows: list[dict[str, Any]]) -> float | None:
            values = []
            for row in rows:
                value = _float((row.get("hitting") or {}).get(field))
                if value is None:
                    continue
                weight = max(1, _int((row.get("hitting") or {}).get("plate_appearances")) or 1)
                values.append((value, weight))
            if not values:
                return None
            return sum(value * weight for value, weight in values) / sum(weight for _, weight in values)

        core = sorted(
            roster,
            key=lambda row: _int((row.get("hitting") or {}).get("plate_appearances")) or 0,
            reverse=True,
        )[:9]
        confirmed = bool(side.get("confirmed")) and len(order) >= 8
        profile_rows = order if confirmed else core
        order_ids = {int(row["id"]) for row in order if row.get("id")}
        missing = [row for row in core if int(row["id"]) not in order_ids] if confirmed else []
        missing_impact: float | None = None
        if confirmed:
            team_ops = weighted("ops", roster) or 0.72
            total_core_pa = sum(max(1, _int((row.get("hitting") or {}).get("plate_appearances")) or 1) for row in core) or 1
            value = 0.0
            for row in missing:
                stats = row.get("hitting") or {}
                pa = max(1, _int(stats.get("plate_appearances")) or 1)
                ops = _float(stats.get("ops")) or team_ops
                value += (pa / total_core_pa) * max(0.05, ops - team_ops + 0.08)
            missing_impact = round(clamp(value, 0.0, 0.4), 3)

        advanced_rows = [
            advanced_by_player[int(row["id"])]
            for row in profile_rows
            if row.get("id") and int(row["id"]) in advanced_by_player
        ]
        advanced = aggregate_metrics(advanced_rows)
        advanced["basis"] = "official_lineup" if confirmed else "projected_core"
        advanced["coverage_players"] = len(advanced_rows)
        profile_validation = lineup_validation(
            [row.get("id") for row in profile_rows],
            active_roster_ids,
            team_id=team_id,
            roster_date=roster_date,
            authoritative_ids=[row.get("id") for row in order] if confirmed else (),
        )
        players = [
            {
                "id": row.get("id"),
                "name": row.get("name"),
                "position": row.get("position"),
                "bat_side": row.get("bat_side"),
                "ops": (row.get("hitting") or {}).get("ops"),
                "obp": (row.get("hitting") or {}).get("obp"),
                "slg": (row.get("hitting") or {}).get("slg"),
                "advanced": advanced_by_player.get(int(row["id"])) if row.get("id") else None,
            }
            for row in profile_rows
        ]
        return {
            "confirmed": confirmed,
            "profile_type": "official" if confirmed else "projected_core",
            "players": players,
            "player_count": len(profile_rows),
            "ops": round(weighted("ops", profile_rows), 3) if weighted("ops", profile_rows) is not None else None,
            "obp": round(weighted("obp", profile_rows), 3) if weighted("obp", profile_rows) is not None else None,
            "slg": round(weighted("slg", profile_rows), 3) if weighted("slg", profile_rows) is not None else None,
            "missing_core": [
                {"id": row.get("id"), "name": row.get("name"), "ops": (row.get("hitting") or {}).get("ops")}
                for row in missing
            ],
            "missing_core_impact": missing_impact,
            "advanced": advanced,
            "validation": profile_validation,
            "meta": {
                "sources": ["MLB official lineup" if confirmed else "MLB date-aware active roster", "Baseball Savant"],
                "updated_at": advanced.get("updated_at") or iso_utc(),
                "roster_date": roster_date,
            },
            "data_quality": (1.0 if confirmed else (0.58 if profile_rows else 0.0)) * (1.0 if profile_validation.get("valid") else 0.55),
        }

    async def _active_roster_payload(self, team_id: int, season: int, group: str, game_day: date | None = None) -> dict[str, Any]:
        hydrates = [
            f"person(stats(group=[{group}],type=[season],season={season}))",
            f"person(stats(group={group},type=season,season={season}))",
        ]
        fallback: dict[str, Any] = {}
        date_options = [game_day.isoformat(), None] if game_day else [None]
        for roster_date in date_options:
            for hydrate in hydrates:
                try:
                    payload = await self._get_json(
                        f"/teams/{team_id}/roster",
                        {"rosterType": "active", "season": season, "date": roster_date, "hydrate": hydrate},
                        ttl_seconds=900,
                    )
                except MLBUpstreamError:
                    continue
                fallback = payload.data
                roster = payload.data.get("roster") or []
                if any((item.get("person") or {}).get("stats") for item in roster):
                    return payload.data
        return fallback

    async def _team_hitter_roster(self, team_id: int, season: int, game_day: date | None = None) -> list[dict[str, Any]]:
        """Return active non-pitchers with season hitting stats for projected lineups."""

        payload = await self._active_roster_payload(team_id, season, "hitting", game_day)
        rows: list[dict[str, Any]] = []
        for item in payload.get("roster") or []:
            person = item.get("person") or {}
            position = item.get("position") or {}
            abbreviation = str(position.get("abbreviation") or position.get("code") or "").upper()
            if abbreviation == "P":
                continue
            stats_payload = {"stats": person.get("stats") or []}
            groups = _stats_groups(stats_payload)
            summary = _hitting_summary(_first_stat(groups.get("season") or []))
            rows.append(
                {
                    "id": _int(person.get("id")),
                    "name": person.get("fullName") or "",
                    "position": abbreviation,
                    "bat_side": ((person.get("batSide") or {}).get("code")),
                    "pitch_hand": ((person.get("pitchHand") or {}).get("code")),
                    "hitting": summary,
                    "pitching": {},
                }
            )
        return [row for row in rows if row.get("id")]

    @staticmethod
    def _merge_roster(base: list[dict[str, Any]], enriched: list[dict[str, Any]]) -> list[dict[str, Any]]:
        rows = {int(row["id"]): dict(row) for row in base if row.get("id")}
        for row in enriched:
            player_id = int(row["id"])
            current = rows.get(player_id, {})
            merged = {**row, **current}
            if row.get("hitting"):
                merged["hitting"] = {
                    **(current.get("hitting") or {}),
                    **{key: value for key, value in (row.get("hitting") or {}).items() if value is not None},
                }
            rows[player_id] = merged
        return list(rows.values())

    async def _team_hitting_bundle(
        self,
        team_id: int,
        season: int,
        game_day: date,
    ) -> dict[str, list[dict[str, Any]]]:
        start = game_day - timedelta(days=7)
        end = game_day - timedelta(days=1)
        try:
            payload = await self._get_json(
                f"/teams/{team_id}/stats",
                {
                    "stats": "season,byDateRange",
                    "group": "hitting",
                    "season": season,
                    "startDate": start.isoformat(),
                    "endDate": end.isoformat(),
                },
                ttl_seconds=300,
            )
            groups = _stats_groups(payload.data)
            if groups:
                return groups
        except MLBUpstreamError:
            pass
        season_payload, recent_payload = await asyncio.gather(
            self._get_json(
                f"/teams/{team_id}/stats",
                {"stats": "season", "group": "hitting", "season": season},
                ttl_seconds=300,
            ),
            self._get_json(
                f"/teams/{team_id}/stats",
                {
                    "stats": "byDateRange",
                    "group": "hitting",
                    "season": season,
                    "startDate": start.isoformat(),
                    "endDate": end.isoformat(),
                },
                ttl_seconds=180,
            ),
        )
        return _stats_groups({"stats": [*(season_payload.data.get("stats") or []), *(recent_payload.data.get("stats") or [])]})

    async def team_hitting_profile(
        self,
        team_id: int,
        season: int,
        game_day: date,
        opponent_hand: str | None,
        official_lineup: dict[str, Any],
    ) -> dict[str, Any]:
        groups_task = self._team_hitting_bundle(team_id, season, game_day)
        sit_code = "vl" if str(opponent_hand or "").upper() == "L" else "vr" if opponent_hand else None
        platoon_task = (
            self._get_json(
                f"/teams/{team_id}/stats",
                {"stats": "season", "group": "hitting", "season": season, "sitCodes": sit_code},
                ttl_seconds=300,
            )
            if sit_code
            else None
        )
        groups = await groups_task
        season_summary = _hitting_summary(_first_stat(groups.get("season") or []))
        recent_splits = groups.get("bydaterange") or groups.get("by date range") or []
        recent_summary = _hitting_summary(_first_stat(recent_splits))
        platoon_summary: dict[str, Any] = {}
        if platoon_task:
            try:
                platoon_payload = await platoon_task
                platoon_groups = _stats_groups(platoon_payload.data)
                platoon_summary = _hitting_summary(_first_stat(platoon_groups.get("season") or next(iter(platoon_groups.values()), [])))
            except MLBUpstreamError:
                platoon_summary = {}
        power_values = [
            (_float(season_summary.get("slg")), 0.35),
            (_float(recent_summary.get("slg")), 0.20),
            (_float(platoon_summary.get("slg")), 0.15),
            (_float(official_lineup.get("slg")), 0.20),
            ((_float((official_lineup.get("advanced") or {}).get("hard_hit_pct")) or 0) / 100.0, 0.10),
        ]
        valid = [(value, weight) for value, weight in power_values if value is not None]
        power_index = sum(value * weight for value, weight in valid) / sum(weight for _, weight in valid) if valid else None
        return {
            "team_id": team_id,
            "opponent_pitch_hand": opponent_hand,
            "season": season_summary,
            "recent_7": recent_summary,
            "platoon": platoon_summary,
            "official_lineup": official_lineup,
            "power_index": round(power_index, 4) if power_index is not None else None,
            "meta": {
                "sources": ["MLB team hitting", "MLB date-aware roster", "Baseball Savant"],
                "updated_at": (official_lineup.get("meta") or {}).get("updated_at") or iso_utc(),
                "roster_date": game_day.isoformat(),
            },
            "data_quality": round((sum(bool(section) for section in (season_summary, recent_summary, platoon_summary, official_lineup)) / 4.0) * (1.0 if (official_lineup.get("validation") or {}).get("valid") else 0.65), 2),
        }

    async def _bullpen_stats_bundle(self, team_id: int, season: int, game_day: date) -> dict[str, list[dict[str, Any]]]:
        start = game_day - timedelta(days=3)
        end = game_day - timedelta(days=1)
        try:
            payload = await self._get_json(
                f"/teams/{team_id}/stats",
                {
                    "stats": "season,byDateRange",
                    "group": "pitching",
                    "season": season,
                    "sitCodes": "rp",
                    "startDate": start.isoformat(),
                    "endDate": end.isoformat(),
                },
                ttl_seconds=180,
            )
            groups = _stats_groups(payload.data)
            if groups:
                return groups
        except MLBUpstreamError:
            pass
        season_payload, recent_payload = await asyncio.gather(
            self._get_json(
                f"/teams/{team_id}/stats",
                {"stats": "season", "group": "pitching", "season": season, "sitCodes": "rp"},
                ttl_seconds=300,
            ),
            self._get_json(
                f"/teams/{team_id}/stats",
                {
                    "stats": "byDateRange",
                    "group": "pitching",
                    "season": season,
                    "sitCodes": "rp",
                    "startDate": start.isoformat(),
                    "endDate": end.isoformat(),
                },
                ttl_seconds=180,
            ),
        )
        return _stats_groups({"stats": [*(season_payload.data.get("stats") or []), *(recent_payload.data.get("stats") or [])]})

    async def _recent_team_bullpen_usage(
        self,
        team_id: int,
        game_day: date,
    ) -> dict[str, Any]:
        start = game_day - timedelta(days=3)
        end = game_day - timedelta(days=1)
        try:
            schedule = await self._get_json(
                "/schedule",
                {
                    "sportId": 1,
                    "teamId": team_id,
                    "startDate": start.isoformat(),
                    "endDate": end.isoformat(),
                    "hydrate": "team",
                },
                ttl_seconds=120,
            )
        except MLBUpstreamError:
            return {"available": False, "message": "近期賽事資料不可用", "players": {}}

        games = [
            game
            for day in schedule.data.get("dates", [])
            for game in day.get("games", [])
            if str(((game.get("status") or {}).get("abstractGameState") or "")).lower() == "final"
        ]
        if not games:
            return {
                "available": True,
                "source": "MLB recent game feeds",
                "games": 0,
                "coverage": 1.0,
                "outs": 0,
                "innings_pitched": "0.0",
                "pitches": 0,
                "players": {},
            }

        payloads = await asyncio.gather(
            *[
                self._get_json(
                    f"{self.settings.mlb_live_base}/game/{int(game['gamePk'])}/feed/live",
                    ttl_seconds=180,
                )
                for game in games
                if game.get("gamePk")
            ],
            return_exceptions=True,
        )
        total_outs = 0
        total_pitches = 0
        successful = 0
        players: dict[str, dict[str, Any]] = {}
        for game, payload in zip(games, payloads):
            if isinstance(payload, Exception):
                continue
            data = payload.data
            teams = (data.get("gameData") or {}).get("teams") or {}
            away_id = _int((teams.get("away") or {}).get("id"))
            side = "away" if away_id == team_id else "home"
            box = (((data.get("liveData") or {}).get("boxscore") or {}).get("teams") or {}).get(side) or {}
            pitcher_ids = [_int(value) for value in box.get("pitchers") or []]
            pitcher_ids = [value for value in pitcher_ids if value]
            if not pitcher_ids:
                continue
            successful += 1
            # The first pitcher listed is the game's starter/opener. Everything
            # after that is bullpen workload for availability purposes.
            for player_id in pitcher_ids[1:]:
                entry = (box.get("players") or {}).get(f"ID{player_id}") or {}
                stats = ((entry.get("stats") or {}).get("pitching") or {})
                outs = _innings_to_outs(stats.get("inningsPitched"))
                pitches = _int(stats.get("numberOfPitches")) or 0
                total_outs += outs
                total_pitches += pitches
                game_date = _parse_game_datetime(game.get("gameDate")).date() if game.get("gameDate") else end
                row = players.setdefault(
                    str(player_id),
                    {
                        "id": player_id,
                        "name": ((entry.get("person") or {}).get("fullName")),
                        "appearances": 0,
                        "outs": 0,
                        "pitches": 0,
                        "dates": [],
                        "pitches_by_date": {},
                    },
                )
                row["appearances"] += 1
                row["outs"] += outs
                row["pitches"] += pitches
                iso = game_date.isoformat()
                row["dates"].append(iso)
                row["pitches_by_date"][iso] = row["pitches_by_date"].get(iso, 0) + pitches

        if successful == 0:
            return {"available": False, "message": "近期牛棚比賽明細不可用", "players": {}}
        return {
            "available": True,
            "source": "MLB recent game feeds",
            "games": len(games),
            "coverage": round(successful / len(games), 2),
            "outs": total_outs,
            "innings_pitched": _outs_to_innings(total_outs),
            "pitches": total_pitches,
            "players": players,
        }

    @staticmethod
    def _usage_for_player(usage: dict[str, Any], player_id: int, game_day: date) -> dict[str, Any]:
        row = (usage.get("players") or {}).get(str(player_id)) or {}
        if not usage.get("available"):
            return {"available": False, "appearances_3_days": None, "consecutive_days": None, "pitches_2_days": None}
        dates = {date.fromisoformat(value) for value in row.get("dates") or []}
        appearances_3 = sum(1 for value in dates if 1 <= (game_day - value).days <= 3)
        pitches_by_date = row.get("pitches_by_date") or {}
        pitches_2 = sum(
            int(pitches_by_date.get((game_day - timedelta(days=days)).isoformat()) or 0)
            for days in (1, 2)
        )
        consecutive = 0
        cursor = game_day - timedelta(days=1)
        while cursor in dates:
            consecutive += 1
            cursor -= timedelta(days=1)
        return {
            "available": True,
            "appearances_3_days": appearances_3,
            "consecutive_days": consecutive,
            "pitches_2_days": pitches_2,
        }

    async def _closer_recent(self, player_id: int, season: int, game_day: date) -> dict[str, Any]:
        try:
            payload = await self._get_json(
                f"/people/{player_id}/stats",
                {"stats": "gameLog", "group": "pitching", "season": season},
                ttl_seconds=120,
            )
        except MLBUpstreamError:
            return {"available": False, "appearances_3_days": 0, "consecutive_days": 0, "pitches_2_days": 0}
        groups = _stats_groups(payload.data)
        logs = groups.get("gamelog") or groups.get("game log") or []
        prior = [split for split in logs if (_split_date(split) or game_day) < game_day]
        dates = {_split_date(split) for split in prior if _split_date(split)}
        appearances_3 = sum(1 for split in prior if _split_date(split) and 1 <= (game_day - _split_date(split)).days <= 3)
        pitches_2 = sum(
            _int((split.get("stat") or {}).get("numberOfPitches")) or 0
            for split in prior
            if _split_date(split) and 1 <= (game_day - _split_date(split)).days <= 2
        )
        consecutive = 0
        cursor = game_day - timedelta(days=1)
        while cursor in dates:
            consecutive += 1
            cursor -= timedelta(days=1)
        return {
            "available": True,
            "appearances_3_days": appearances_3,
            "consecutive_days": consecutive,
            "pitches_2_days": pitches_2,
        }

    async def _team_pitcher_roster(self, team_id: int, season: int, game_day: date | None = None) -> list[dict[str, Any]]:
        """Return active pitchers with individual season statistics.

        Future-game boxscores sometimes list every pitcher but omit usable
        season stats. The hydrated active-roster endpoint supplies the saves,
        holds, games finished and starts needed to avoid labeling a starter as
        the closer.
        """

        payload = await self._active_roster_payload(team_id, season, "pitching", game_day)
        rows: list[dict[str, Any]] = []
        for item in payload.get("roster") or []:
            person = item.get("person") or {}
            position = item.get("position") or {}
            if str(position.get("abbreviation") or position.get("code") or "").upper() != "P":
                continue
            stats_payload = {"stats": person.get("stats") or []}
            groups = _stats_groups(stats_payload)
            summary = _pitching_summary(_first_stat(groups.get("season") or []))
            rows.append(
                {
                    "id": _int(person.get("id")),
                    "name": person.get("fullName") or "",
                    "position": "P",
                    "pitch_hand": ((person.get("pitchHand") or {}).get("code")),
                    "pitching": summary,
                }
            )
        return [row for row in rows if row.get("id")]

    @staticmethod
    def _identify_closer(roster: list[dict[str, Any]]) -> tuple[dict[str, Any] | None, str]:
        """Choose a closer only when season relief-role evidence exists."""

        candidates: list[tuple[float, dict[str, Any]]] = []
        for row in roster:
            pitching = row.get("pitching") or {}
            games = _int(pitching.get("games")) or 0
            starts = _int(pitching.get("games_started")) or 0
            games_finished = _int(pitching.get("games_finished")) or 0
            saves = _int(pitching.get("saves")) or 0
            holds = _int(pitching.get("holds")) or 0
            relief_appearances = max(0, games - starts)
            if games <= 0:
                continue
            starter_share = starts / games if games else 1.0
            if starter_share > 0.45 and saves < 2:
                continue
            # Never pick the first pitcher in an unhydrated roster simply
            # because every saves/holds value is zero.
            if saves < 2 and games_finished < 5:
                continue
            score = saves * 12.0 + games_finished * 2.0 + holds * 0.55 + relief_appearances * 0.10
            candidates.append((score, row))

        if not candidates:
            return None, "unidentified"
        candidates.sort(key=lambda item: item[0], reverse=True)
        closer = candidates[0][1]
        pitching = closer.get("pitching") or {}
        saves = _int(pitching.get("saves")) or 0
        games_finished = _int(pitching.get("games_finished")) or 0
        confidence = "confirmed" if saves >= 5 or games_finished >= 10 else "probable"
        return closer, confidence

    async def bullpen_profile(
        self,
        team_id: int,
        season: int,
        game_day: date,
        live_side: dict[str, Any],
        hydrated_roster: list[dict[str, Any]] | None = None,
    ) -> dict[str, Any]:
        groups, workload = await asyncio.gather(
            self._bullpen_stats_bundle(team_id, season, game_day),
            self._recent_team_bullpen_usage(team_id, game_day),
        )
        if hydrated_roster is None:
            hydrated_roster = await self._team_pitcher_roster(team_id, season, game_day)
        season_summary = _pitching_summary(_first_stat(groups.get("season") or []))
        recent_summary = _pitching_summary(
            _first_stat(groups.get("bydaterange") or groups.get("by date range") or [])
        )
        if workload.get("available"):
            recent_summary = {
                **recent_summary,
                "games": workload.get("games"),
                "outs": workload.get("outs"),
                "innings_pitched": workload.get("innings_pitched"),
                "pitches": workload.get("pitches"),
                "workload_source": workload.get("source"),
                "coverage": workload.get("coverage"),
            }

        live_roster = [
            row for row in live_side.get("roster") or []
            if str(row.get("position") or "").upper() == "P"
        ]
        roster_by_id = {int(row["id"]): row for row in live_roster if row.get("id")}
        for row in hydrated_roster:
            player_id = int(row["id"])
            existing = roster_by_id.get(player_id)
            if existing:
                existing_pitching = existing.get("pitching") or {}
                hydrated_pitching = row.get("pitching") or {}
                existing["pitching"] = {
                    **existing_pitching,
                    **{key: value for key, value in hydrated_pitching.items() if value is not None},
                }
                if not existing.get("name"):
                    existing["name"] = row.get("name")
            else:
                roster_by_id[player_id] = row
        pitcher_roster = list(roster_by_id.values())
        closer, closer_role = self._identify_closer(pitcher_roster)

        relievers = []
        for row in pitcher_roster:
            pitching = row.get("pitching") or {}
            games = _int(pitching.get("games")) or 0
            starts = _int(pitching.get("games_started")) or 0
            saves = _int(pitching.get("saves")) or 0
            if games and starts / games > 0.55 and saves == 0:
                continue
            relievers.append(row)

        closer_recent: dict[str, Any]
        if closer and closer.get("id") and workload.get("available"):
            closer_recent = self._usage_for_player(workload, int(closer["id"]), game_day)
        elif closer and closer.get("id"):
            closer_recent = await self._closer_recent(int(closer["id"]), season, game_day)
        else:
            closer_recent = {"available": False, "appearances_3_days": None, "consecutive_days": None, "pitches_2_days": None}

        freshness: float | None = None
        if workload.get("available"):
            recent_innings = (_int(workload.get("outs")) or 0) / 3.0
            recent_pitches = _int(workload.get("pitches")) or 0
            freshness = 1.0
            freshness -= min(0.40, max(0.0, recent_innings - 7.0) * 0.04)
            freshness -= min(0.22, max(0, recent_pitches - 115) * 0.0015)
            freshness = clamp(freshness, 0.05, 1.0)

        closer_score: float | None = None
        if closer and closer_recent.get("available"):
            consecutive = int(closer_recent.get("consecutive_days") or 0)
            pitches_2 = int(closer_recent.get("pitches_2_days") or 0)
            if consecutive >= 3 or pitches_2 >= 55:
                closer_status = "高機率休息"
                closer_score = 0.15
            elif consecutive >= 2 or pitches_2 >= 35:
                closer_status = "可用性受限"
                closer_score = 0.50
            else:
                closer_status = "預計可用"
                closer_score = 0.90
        elif closer:
            closer_status = "近期用量資料不足"
        else:
            closer_status = "終結者尚未辨識（無足夠救援角色證據）"

        closer_validation = validate_roster_member(
            closer.get("id") if closer else None,
            [row.get("id") for row in hydrated_roster],
            team_id=team_id,
            role="終結者",
            roster_date=game_day.isoformat(),
            authoritative_ids=[row.get("id") for row in live_roster],
        ) if closer else {"status": "pending", "valid": False, "reason": "終結者尚未辨識", "team_id": team_id, "roster_date": game_day.isoformat()}
        return {
            "team_id": team_id,
            "season": season_summary,
            "recent_3_days": recent_summary,
            "availability": {
                "freshness_score": round(freshness, 2) if freshness is not None else None,
                "freshness_status": (
                    "休息充足" if freshness is not None and freshness >= 0.82
                    else "一般" if freshness is not None and freshness >= 0.58
                    else "負荷偏高" if freshness is not None
                    else "近期負荷資料不足"
                ),
                "closer_score": closer_score,
                "closer_status": closer_status,
                "closer_role_confidence": closer_role,
                "closer": {
                    "id": closer.get("id") if closer else None,
                    "name": closer.get("name") if closer else None,
                    "saves": (closer.get("pitching") or {}).get("saves") if closer else None,
                    "games_finished": (closer.get("pitching") or {}).get("games_finished") if closer else None,
                    "validation": closer_validation,
                },
                "workload_source": workload.get("source"),
                "workload_games": workload.get("games") if workload.get("available") else None,
                "workload_coverage": workload.get("coverage") if workload.get("available") else None,
                **closer_recent,
            },
            "reliever_count": len(relievers),
            "validation": closer_validation,
            "meta": {
                "sources": ["MLB relief pitching", "MLB recent game feeds", "MLB date-aware active roster"],
                "updated_at": iso_utc(),
                "roster_date": game_day.isoformat(),
            },
            "available": any(season_summary.get(key) is not None for key in ("era", "whip", "k_bb")),
            "data_quality": round(
                0.50 * any(season_summary.get(key) is not None for key in ("era", "whip", "k_bb"))
                + 0.30 * bool(workload.get("available"))
                + 0.20 * bool(closer and closer_recent.get("available")),
                2,
            ),
        }

    async def venue_profile(self, venue_id: int | None) -> dict[str, Any]:
        if not venue_id:
            return {"available": False}
        try:
            payload = await self._get_json(f"/venues/{venue_id}", {"hydrate": "location"}, ttl_seconds=21600)
        except MLBUpstreamError:
            return {"available": False, "venue_id": venue_id}
        venues = payload.data.get("venues") or []
        venue = venues[0] if venues else {}
        location = venue.get("location") or {}
        coordinates = location.get("defaultCoordinates") or {}
        field = venue.get("fieldInfo") or {}
        return {
            "available": bool(venue),
            "venue_id": venue_id,
            "name": venue.get("name"),
            "latitude": _float(coordinates.get("latitude")),
            "longitude": _float(coordinates.get("longitude")),
            "timezone": ((venue.get("timeZone") or {}).get("id")),
            "roof_type": field.get("roofType"),
            "turf_type": field.get("turfType"),
            "dimensions": {
                "left_line": _int(field.get("leftLine")),
                "left_center": _int(field.get("leftCenter")),
                "center": _int(field.get("center")),
                "right_center": _int(field.get("rightCenter")),
                "right_line": _int(field.get("rightLine")),
            },
            "cache": payload.cache_status,
        }

    @staticmethod
    def _home_away_split(splits: list[dict[str, Any]], target: str) -> dict[str, Any]:
        for split in splits:
            info = split.get("split") or {}
            text = str(info.get("code") or info.get("description") or info.get("name") or "").lower()
            if target in text or (target == "away" and "road" in text):
                return split.get("stat") or {}
        return {}

    async def park_factors(self, team_id: int, season: int) -> dict[str, Any]:
        try:
            hitting, pitching = await asyncio.gather(
                self._get_json(
                    f"/teams/{team_id}/stats",
                    {"stats": "statSplits", "group": "hitting", "season": season, "sitCodes": "home,away"},
                    ttl_seconds=21600,
                ),
                self._get_json(
                    f"/teams/{team_id}/stats",
                    {"stats": "statSplits", "group": "pitching", "season": season, "sitCodes": "home,away"},
                    ttl_seconds=21600,
                ),
            )
        except MLBUpstreamError:
            return {"available": False, "run_factor": 1.0, "hr_factor": 1.0}
        hit_splits = next(iter(_stats_groups(hitting.data).values()), [])
        pitch_splits = next(iter(_stats_groups(pitching.data).values()), [])
        home_hit = self._home_away_split(hit_splits, "home")
        away_hit = self._home_away_split(hit_splits, "away")
        home_pitch = self._home_away_split(pitch_splits, "home")
        away_pitch = self._home_away_split(pitch_splits, "away")
        home_games = _int(home_hit.get("gamesPlayed")) or _int(home_pitch.get("gamesPlayed")) or 0
        away_games = _int(away_hit.get("gamesPlayed")) or _int(away_pitch.get("gamesPlayed")) or 0
        if not home_games or not away_games:
            return {"available": False, "run_factor": 1.0, "hr_factor": 1.0}
        home_runs = (_int(home_hit.get("runs")) or 0) + (_int(home_pitch.get("runs")) or 0)
        away_runs = (_int(away_hit.get("runs")) or 0) + (_int(away_pitch.get("runs")) or 0)
        home_hr = (_int(home_hit.get("homeRuns")) or 0) + (_int(home_pitch.get("homeRuns")) or 0)
        away_hr = (_int(away_hit.get("homeRuns")) or 0) + (_int(away_pitch.get("homeRuns")) or 0)
        home_run_rate = home_runs / home_games
        away_run_rate = away_runs / away_games
        home_hr_rate = home_hr / home_games
        away_hr_rate = away_hr / away_games
        run_factor = home_run_rate / away_run_rate if away_run_rate else 1.0
        hr_factor = home_hr_rate / away_hr_rate if away_hr_rate else 1.0
        return {
            "available": True,
            "method": "current-season home-road scoring split",
            "run_factor": round(clamp(run_factor, 0.75, 1.25), 3),
            "hr_factor": round(clamp(hr_factor, 0.65, 1.40), 3),
            "home_games": home_games,
            "away_games": away_games,
        }

    async def environment_profile(
        self,
        game: dict[str, Any],
        away_lineup: dict[str, Any],
        home_lineup: dict[str, Any],
        live_context: dict[str, Any],
        season: int,
    ) -> dict[str, Any]:
        venue, park = await asyncio.gather(
            self.venue_profile(game.get("venue_id")),
            self.park_factors(int(game["home"]["id"]), season),
        )
        game_time = _parse_game_datetime(game["game_date"])
        forecast = await self.weather.forecast_for_game(
            venue.get("latitude"),
            venue.get("longitude"),
            game_time,
        )
        live_weather = live_context.get("weather") or {}
        weather = dict(live_weather if live_weather.get("available") else forecast)
        if weather.get("temperature_c") is None and weather.get("temperature_f") is not None:
            weather["temperature_c"] = fahrenheit_to_celsius(weather.get("temperature_f"))
        venue_timezone = venue.get("timezone")
        if weather.get("time_utc") and venue_timezone:
            try:
                local_time = _parse_game_datetime(weather["time_utc"]).astimezone(ZoneInfo(venue_timezone))
                weather["time_local"] = local_time.isoformat()
                weather["time_local_label"] = local_time.strftime("%m/%d %H:%M")
            except (ValueError, KeyError):
                pass
        relative_wind = live_weather.get("wind_text")
        adjustment = environment_run_adjustment(
            weather,
            roof_type=venue.get("roof_type"),
            roof_closed=bool(live_context.get("roof_closed")),
            relative_wind=relative_wind,
            park_run_factor=_float(park.get("run_factor")),
        )
        away_power = _float(away_lineup.get("power_index"))
        home_power = _float(home_lineup.get("power_index"))
        side_edge = None
        if away_power is not None and home_power is not None:
            side_edge = clamp((home_power - away_power) / 0.18 * abs(adjustment["run_adjustment"]) * 0.10, -0.20, 0.20)
        return {
            "available": bool(venue.get("available") or weather.get("available") or park.get("available")),
            "venue": venue,
            "weather": weather,
            "park_factors": park,
            "roof_closed": bool(live_context.get("roof_closed")),
            "relative_wind": relative_wind,
            "run_adjustment": adjustment["run_adjustment"],
            "weather_applied": adjustment["weather_applied"],
            "reasons": adjustment["reasons"],
            "quality": adjustment["quality"],
            "side_edge": round(side_edge, 4) if side_edge is not None else None,
            "meta": {
                "sources": [source for source in [weather.get("source") or "Open-Meteo", "MLB venue", "current-season park factor"] if source],
                "updated_at": weather.get("updated_at") or weather.get("fetched_at") or iso_utc(),
            },
        }

    async def _enrich_game(
        self,
        game: dict[str, Any],
        standings: dict[int, dict[str, Any]],
        season: int,
    ) -> dict[str, Any]:
        async with self._enrichment_semaphore:
            live_context = await self._live_context(int(game["game_pk"]))
            live_players = live_context.get("players") or {}
            live_probable = live_context.get("probable_pitchers") or {}
            game = {
                **game,
                "away": {
                    **game["away"],
                    "probable_pitcher": {
                        "id": game["away"]["probable_pitcher"].get("id") or (live_probable.get("away") or {}).get("id"),
                        "name": (
                            game["away"]["probable_pitcher"].get("name")
                            if game["away"]["probable_pitcher"].get("id")
                            else (live_probable.get("away") or {}).get("name") or "尚未公布"
                        ),
                    },
                },
                "home": {
                    **game["home"],
                    "probable_pitcher": {
                        "id": game["home"]["probable_pitcher"].get("id") or (live_probable.get("home") or {}).get("id"),
                        "name": (
                            game["home"]["probable_pitcher"].get("name")
                            if game["home"]["probable_pitcher"].get("id")
                            else (live_probable.get("home") or {}).get("name") or "尚未公布"
                        ),
                    },
                },
            }
            game_day = _parse_game_datetime(game["game_date"]).date()
            away_pitcher_id = game["away"]["probable_pitcher"]["id"]
            home_pitcher_id = game["home"]["probable_pitcher"]["id"]
            away_pitcher, home_pitcher = await asyncio.gather(
                self.pitcher_profile(
                    away_pitcher_id,
                    season,
                    game_day,
                    "away",
                    live_players.get(away_pitcher_id) if away_pitcher_id else None,
                ),
                self.pitcher_profile(
                    home_pitcher_id,
                    season,
                    game_day,
                    "home",
                    live_players.get(home_pitcher_id) if home_pitcher_id else None,
                ),
            )

            lineup_contexts = live_context.get("lineups") or {}
            away_context = lineup_contexts.get("away") or {}
            home_context = lineup_contexts.get("home") or {}
            away_active, home_active, away_pitcher_roster, home_pitcher_roster = await asyncio.gather(
                self._team_hitter_roster(int(game["away"]["id"]), season, game_day),
                self._team_hitter_roster(int(game["home"]["id"]), season, game_day),
                self._team_pitcher_roster(int(game["away"]["id"]), season, game_day),
                self._team_pitcher_roster(int(game["home"]["id"]), season, game_day),
            )
            away_context["roster"] = self._merge_roster(away_context.get("roster") or [], away_active)
            home_context["roster"] = self._merge_roster(home_context.get("roster") or [], home_active)
            lineup_contexts["away"] = away_context
            lineup_contexts["home"] = home_context
            live_context["lineups"] = lineup_contexts

            away_starter_validation = validate_roster_member(
                away_pitcher_id,
                [row.get("id") for row in away_pitcher_roster],
                team_id=game["away"]["id"],
                role="預計先發",
                roster_date=game_day.isoformat(),
                authoritative_ids=[row.get("id") for row in away_context.get("roster") or []],
            )
            home_starter_validation = validate_roster_member(
                home_pitcher_id,
                [row.get("id") for row in home_pitcher_roster],
                team_id=game["home"]["id"],
                role="預計先發",
                roster_date=game_day.isoformat(),
                authoritative_ids=[row.get("id") for row in home_context.get("roster") or []],
            )
            if away_pitcher is not None:
                away_pitcher["roster_validation"] = away_starter_validation
                away_pitcher["data_quality"] = round(float(away_pitcher.get("data_quality") or 0) * (1.0 if away_starter_validation["valid"] else 0.35), 2)
            if home_pitcher is not None:
                home_pitcher["roster_validation"] = home_starter_validation
                home_pitcher["data_quality"] = round(float(home_pitcher.get("data_quality") or 0) * (1.0 if home_starter_validation["valid"] else 0.35), 2)

            all_batter_ids = []
            for side in ("away", "home"):
                context = (live_context.get("lineups") or {}).get(side) or {}
                # Before official lineups are posted, use the active roster's
                # established hitters so the advanced module can provide a
                # clearly-labelled projected-core profile instead of 0%.
                all_batter_ids.extend(
                    row.get("id")
                    for row in context.get("roster") or []
                    if row.get("id")
                    and str(row.get("position") or "").upper() != "P"
                    and (_int((row.get("hitting") or {}).get("plate_appearances")) or 0) > 0
                )
            advanced_batters = await self.statcast.batter_metrics(all_batter_ids, season)
            away_official = self._official_lineup_profile(
                (live_context.get("lineups") or {}).get("away") or {}, advanced_batters,
                team_id=int(game["away"]["id"]), roster_date=game_day.isoformat(),
                active_roster_ids={int(row["id"]) for row in away_active if row.get("id")},
            )
            home_official = self._official_lineup_profile(
                (live_context.get("lineups") or {}).get("home") or {}, advanced_batters,
                team_id=int(game["home"]["id"]), roster_date=game_day.isoformat(),
                active_roster_ids={int(row["id"]) for row in home_active if row.get("id")},
            )
            away_lineup, home_lineup, away_bullpen, home_bullpen = await asyncio.gather(
                self.team_hitting_profile(
                    int(game["away"]["id"]),
                    season,
                    game_day,
                    (home_pitcher or {}).get("pitch_hand"),
                    away_official,
                ),
                self.team_hitting_profile(
                    int(game["home"]["id"]),
                    season,
                    game_day,
                    (away_pitcher or {}).get("pitch_hand"),
                    home_official,
                ),
                self.bullpen_profile(
                    int(game["away"]["id"]),
                    season,
                    game_day,
                    (live_context.get("lineups") or {}).get("away") or {},
                    away_pitcher_roster,
                ),
                self.bullpen_profile(
                    int(game["home"]["id"]),
                    season,
                    game_day,
                    (live_context.get("lineups") or {}).get("home") or {},
                    home_pitcher_roster,
                ),
            )
            environment = await self.environment_profile(
                game,
                away_lineup,
                home_lineup,
                live_context,
                season,
            )
            away_team = standings.get(game["away"]["id"]) or self._fallback_team(game["away"])
            home_team = standings.get(game["home"]["id"]) or self._fallback_team(game["home"])
            result = analyze_matchup(
                game,
                away_team,
                home_team,
                away_pitcher,
                home_pitcher,
                away_lineup,
                home_lineup,
                away_bullpen,
                home_bullpen,
                environment,
            )
            result["starting_pitchers"] = {
                "away": {**game["away"]["probable_pitcher"], "stats": away_pitcher},
                "home": {**game["home"]["probable_pitcher"], "stats": home_pitcher},
            }
            result["lineups"] = {"away": away_lineup, "home": home_lineup}
            result["bullpen"] = {"away": away_bullpen, "home": home_bullpen}
            result["environment"] = environment
            result["game"] = game
            lineup_away_validation = away_official.get("validation") or {}
            lineup_home_validation = home_official.get("validation") or {}
            result["roster_validation"] = {
                "starters": {"away": away_starter_validation, "home": home_starter_validation},
                "lineups": {"away": lineup_away_validation, "home": lineup_home_validation},
                "bullpen": {"away": away_bullpen.get("validation") or {}, "home": home_bullpen.get("validation") or {}},
                "overall": aggregate_validation(away_starter_validation, home_starter_validation, lineup_away_validation, lineup_home_validation),
            }
            result["timing"] = game_timing(
                game, lineup_watch_minutes=self.settings.pregame_lineup_watch_minutes,
                final_lock_minutes=self.settings.pregame_final_lock_minutes,
            )
            module_meta = {
                "starter": {"sources": ["MLB probable pitchers", "MLB pitcher stats", "Baseball Savant"], "updated_at": iso_utc(), "roster_date": game_day.isoformat()},
                "lineup": away_lineup.get("meta") or {"sources": ["MLB lineups"], "updated_at": iso_utc()},
                "bullpen": away_bullpen.get("meta") or {"sources": ["MLB bullpen"], "updated_at": iso_utc()},
                "environment": environment.get("meta") or {"sources": ["Open-Meteo", "MLB venue"], "updated_at": iso_utc()},
                "advanced": {"sources": sorted(set(((away_pitcher or {}).get("advanced") or {}).get("sources") or []) | set(((home_pitcher or {}).get("advanced") or {}).get("sources") or []) | set((away_official.get("advanced") or {}).get("sources") or []) | set((home_official.get("advanced") or {}).get("sources") or [])), "updated_at": iso_utc()},
            }
            for key, meta in module_meta.items():
                if key in result.get("analysis_groups", {}):
                    result["analysis_groups"][key]["meta"] = meta
            result["data_freshness"] = {"generated_at": iso_utc(), "modules": module_meta}
            return result

    async def matchup_analyses(
        self,
        taiwan_date: date,
        *,
        pitcher_limit: int | None = None,
    ) -> dict[str, Any]:
        schedule = await self.games_for_date(taiwan_date)
        candidates = [game for game in schedule["items"] if game["status"] == "upcoming"]
        if not candidates:
            return {
                "date": taiwan_date.isoformat(),
                "items": [],
                "message": "今天沒有尚未開賽且可分析的 MLB 賽事。",
                "meta": schedule["meta"],
            }
        season = taiwan_date.year
        try:
            standings, standings_meta = await self.standings(season)
        except MLBUpstreamError:
            standings, standings_meta = {}, {"cache": "unavailable", "updated_at": None}

        base_results: list[dict[str, Any]] = []
        for game in candidates:
            away_team = standings.get(game["away"]["id"]) or self._fallback_team(game["away"])
            home_team = standings.get(game["home"]["id"]) or self._fallback_team(game["home"])
            result = analyze_matchup(game, away_team, home_team)
            result["game"] = game
            base_results.append(result)
        ranked = sorted(base_results, key=lambda result: result["confidence"], reverse=True)
        selected = ranked if pitcher_limit is None else ranked[: max(0, pitcher_limit)]
        selected_ids = {result["game_pk"] for result in selected}

        async def safely_enrich(game: dict[str, Any]) -> dict[str, Any] | None:
            try:
                return await self._enrich_game(game, standings, season)
            except (MLBUpstreamError, TypeError, ValueError, KeyError):
                return None

        enriched_results = await asyncio.gather(
            *[safely_enrich(game) for game in candidates if game["game_pk"] in selected_ids]
        )
        enriched = {result["game_pk"]: result for result in enriched_results if result}
        analyses = [enriched.get(result["game_pk"], result) for result in base_results]
        return {
            "date": taiwan_date.isoformat(),
            "items": analyses,
            "message": f"已完成 {len(analyses)} 場賽事分析，其中 {len(enriched)} 場完成五大完整引擎。",
            "meta": {
                "schedule_cache": schedule["meta"]["cache"],
                "standings_cache": standings_meta["cache"],
                "updated_at": schedule["meta"]["updated_at"],
                "full_engine_enriched": len(enriched),
                "engine_version": "dm-complete-engine-v2.4",
                "score_simulation": False,
            },
        }

    async def top_prediction(self, taiwan_date: date) -> dict[str, Any]:
        analysis_set = await self.matchup_analyses(taiwan_date, pitcher_limit=None)
        analyses = analysis_set["items"]
        if not analyses:
            return {
                "date": taiwan_date.isoformat(),
                "published": False,
                "selection": None,
                "message": analysis_set["message"],
                "meta": analysis_set["meta"],
            }
        eligible = [
            result
            for result in analyses
            if (result.get("game") or {}).get("auto_recommendation_eligible") is True
            and ((result.get("analysis_groups") or {}).get("starter") or {}).get("both_starters_ready") is True
        ]
        if not eligible:
            selection = max(analyses, key=lambda result: result["confidence"])
            regular_games = [
                result for result in analyses
                if (result.get("game") or {}).get("auto_recommendation_eligible") is True
            ]
            if regular_games:
                return {
                    "date": taiwan_date.isoformat(),
                    "published": False,
                    "selection": None,
                    "candidate": selection,
                    "message": "兩隊先發投手資料尚未達自動發布標準；系統不會用高信心外觀掩蓋缺值。",
                    "meta": {
                        **analysis_set["meta"],
                        "model_version": selection["model_version"],
                        "minimum_confidence": self.settings.min_confidence,
                        "starter_guard": True,
                    },
                }
            event_labels = sorted(
                {
                    str((result.get("game") or {}).get("event_label") or "特殊賽事")
                    for result in analyses
                }
            )
            return {
                "date": taiwan_date.isoformat(),
                "published": False,
                "selection": None,
                "candidate": selection,
                "message": f"今日只有{'、'.join(event_labels)}，尚未啟用相符的專用模型，因此不會套用一般賽事模型發布。",
                "meta": {
                    **analysis_set["meta"],
                    "model_version": selection["model_version"],
                    "minimum_confidence": self.settings.min_confidence,
                    "blocked_special_events": len(analyses),
                },
            }
        selection = max(eligible, key=lambda result: result["confidence"])
        published = selection["confidence"] >= self.settings.min_confidence and selection["data_quality"] >= 0.45
        return {
            "date": taiwan_date.isoformat(),
            "published": published,
            "selection": selection if published else None,
            "candidate": None if published else selection,
            "message": (
                "今日最高信心場次已完成五大引擎分析。"
                if published
                else f"最高候選信心 {selection['confidence']}%，或資料完整度未達發布門檻。"
            ),
            "meta": {
                **analysis_set["meta"],
                "model_version": selection["model_version"],
                "minimum_confidence": self.settings.min_confidence,
            },
        }

    async def game_result(self, game_pk: int) -> dict[str, Any]:
        payload = await self._get_json(
            "/schedule",
            {"sportId": 1, "gamePk": game_pk, "hydrate": "linescore,team,venue"},
            ttl_seconds=30,
        )
        raw_games = [game for day in payload.data.get("dates", []) for game in day.get("games", [])]
        if not raw_games:
            raise KeyError("Game not found")
        return self._normalize_game(raw_games[0])

    @staticmethod
    def _extract_team_stats(payload: dict[str, Any]) -> dict[str, Any]:
        groups = payload.get("stats") or []
        splits = groups[0].get("splits", []) if groups else []
        return splits[0].get("stat", {}) if splits else {}

    async def _team_season_stats(self, team_id: int, season: int) -> dict[str, Any]:
        hitting, pitching = await asyncio.gather(
            self._get_json(
                f"/teams/{team_id}/stats",
                {"stats": "season", "group": "hitting", "season": season},
                ttl_seconds=300,
            ),
            self._get_json(
                f"/teams/{team_id}/stats",
                {"stats": "season", "group": "pitching", "season": season},
                ttl_seconds=300,
            ),
        )
        hit = self._extract_team_stats(hitting.data)
        pitch = self._extract_team_stats(pitching.data)
        return {
            "hitting": _hitting_summary(hit),
            "pitching": _pitching_summary(pitch),
            "cache": "stale" if "stale" in {hitting.cache_status, pitching.cache_status} else "hit",
        }

    async def _lineups(self, game_pk: int) -> dict[str, Any]:
        context = await self._live_context(game_pk)
        result = {"available": False, "away": [], "home": []}
        for side in ("away", "home"):
            side_context = (context.get("lineups") or {}).get(side) or {}
            result[side] = [row.get("name") for row in side_context.get("batting_order") or []]
            result[f"{side}_confirmed"] = bool(side_context.get("confirmed"))
        result["available"] = bool(result["away"] or result["home"])
        return result

    async def game_detail(self, game_pk: int) -> dict[str, Any]:
        payload = await self._get_json(
            "/schedule",
            {
                "sportId": 1,
                "gamePk": game_pk,
                "hydrate": "probablePitcher,linescore,team,venue",
            },
        )
        raw_games = [game for day in payload.data.get("dates", []) for game in day.get("games", [])]
        if not raw_games:
            raise KeyError("Game not found")
        game = self._normalize_game(raw_games[0])
        season = _parse_game_datetime(game["game_date"]).year
        away_id, home_id = game["away"]["id"], game["home"]["id"]
        if away_id is None or home_id is None:
            raise MLBUpstreamError("Team identifiers are unavailable")
        standings, standings_meta = await self.standings(season)
        analysis = await self._enrich_game(game, standings, season)
        return {
            "game": game,
            "analysis": analysis,
            "teams": {
                "away": {
                    "standing": standings.get(away_id),
                    "season_stats": {
                        "hitting": ((analysis.get("lineups") or {}).get("away") or {}).get("season"),
                        "pitching": None,
                    },
                },
                "home": {
                    "standing": standings.get(home_id),
                    "season_stats": {
                        "hitting": ((analysis.get("lineups") or {}).get("home") or {}).get("season"),
                        "pitching": None,
                    },
                },
            },
            "lineups": analysis.get("lineups"),
            "starting_pitchers": analysis.get("starting_pitchers"),
            "bullpen": analysis.get("bullpen"),
            "environment": analysis.get("environment"),
            "meta": {
                "source": "MLB Stats API + Baseball Savant + Open-Meteo",
                "cache": payload.cache_status,
                "standings_cache": standings_meta.get("cache"),
                "updated_at": payload.fetched_at,
                "engine_version": analysis.get("model_version"),
                "score_simulation": False,
            },
        }
