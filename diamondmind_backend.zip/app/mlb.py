from __future__ import annotations

import asyncio
import json
from dataclasses import dataclass
from datetime import date, datetime, timedelta, timezone
from typing import Any
from urllib.parse import urlencode
from zoneinfo import ZoneInfo

import httpx

from .cache import AsyncTTLCache
from .config import Settings
from .model import analyze_matchup, pythagorean_win_pct


TAIPEI = ZoneInfo("Asia/Taipei")

TEAM_ABBR = {
    "Arizona Diamondbacks": "ARI",
    "Atlanta Braves": "ATL",
    "Baltimore Orioles": "BAL",
    "Boston Red Sox": "BOS",
    "Chicago Cubs": "CHC",
    "Chicago White Sox": "CWS",
    "Cincinnati Reds": "CIN",
    "Cleveland Guardians": "CLE",
    "Colorado Rockies": "COL",
    "Detroit Tigers": "DET",
    "Houston Astros": "HOU",
    "Kansas City Royals": "KC",
    "Los Angeles Angels": "LAA",
    "Los Angeles Dodgers": "LAD",
    "Miami Marlins": "MIA",
    "Milwaukee Brewers": "MIL",
    "Minnesota Twins": "MIN",
    "New York Mets": "NYM",
    "New York Yankees": "NYY",
    "Athletics": "ATH",
    "Oakland Athletics": "OAK",
    "Philadelphia Phillies": "PHI",
    "Pittsburgh Pirates": "PIT",
    "San Diego Padres": "SD",
    "San Francisco Giants": "SF",
    "Seattle Mariners": "SEA",
    "St. Louis Cardinals": "STL",
    "Tampa Bay Rays": "TB",
    "Texas Rangers": "TEX",
    "Toronto Blue Jays": "TOR",
    "Washington Nationals": "WSH",
}


class MLBUpstreamError(RuntimeError):
    pass


@dataclass
class FetchPayload:
    data: dict[str, Any]
    cache_status: str
    fetched_at: str


def _iso_utc(timestamp: float | None = None) -> str:
    dt = datetime.fromtimestamp(timestamp, tz=timezone.utc) if timestamp else datetime.now(timezone.utc)
    return dt.isoformat().replace("+00:00", "Z")


def _parse_game_datetime(value: str) -> datetime:
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def _float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _int(value: Any) -> int | None:
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


class MLBService:
    def __init__(self, settings: Settings, transport: httpx.AsyncBaseTransport | None = None) -> None:
        self.settings = settings
        self.cache = AsyncTTLCache()
        self.client = httpx.AsyncClient(
            timeout=settings.request_timeout_seconds,
            follow_redirects=True,
            trust_env=False,
            transport=transport,
            headers={"User-Agent": "DiamondMind/1.0"},
        )

    async def aclose(self) -> None:
        await self.client.aclose()

    async def _get_json(
        self,
        path_or_url: str,
        params: dict[str, Any] | None = None,
        ttl_seconds: int | None = None,
    ) -> FetchPayload:
        params = {key: value for key, value in (params or {}).items() if value is not None}
        url = path_or_url if path_or_url.startswith("http") else f"{self.settings.mlb_api_base}{path_or_url}"
        key = f"{url}?{urlencode(sorted((str(key), str(value)) for key, value in params.items()))}"
        ttl = ttl_seconds or self.settings.cache_ttl_seconds
        cached = self.cache.get(key)
        if cached and cached.is_fresh:
            return FetchPayload(cached.value, "hit", _iso_utc(cached.stored_at))

        async with self.cache.lock(key):
            cached = self.cache.get(key)
            if cached and cached.is_fresh:
                return FetchPayload(cached.value, "hit", _iso_utc(cached.stored_at))
            try:
                response = await self.client.get(url, params=params)
                response.raise_for_status()
                data = response.json()
                if not isinstance(data, dict):
                    raise ValueError("Unexpected MLB response")
                entry = self.cache.set(key, data, ttl, self.settings.stale_ttl_seconds)
                return FetchPayload(data, "miss", _iso_utc(entry.stored_at))
            except (httpx.HTTPError, ValueError, json.JSONDecodeError) as exc:
                if cached and cached.can_serve_stale:
                    return FetchPayload(cached.value, "stale", _iso_utc(cached.stored_at))
                raise MLBUpstreamError("MLB data source is temporarily unavailable") from exc

    @staticmethod
    def _team(team_side: dict[str, Any]) -> dict[str, Any]:
        team = team_side.get("team") or {}
        name = team.get("name") or "Unknown"
        record = team_side.get("leagueRecord") or {}
        pitcher = team_side.get("probablePitcher") or {}
        return {
            "id": _int(team.get("id")),
            "name": name,
            "abbr": TEAM_ABBR.get(name, (name.split(" ")[-1][:3] or "TBD").upper()),
            "score": _int(team_side.get("score")),
            "record": {
                "wins": _int(record.get("wins")),
                "losses": _int(record.get("losses")),
                "pct": _float(record.get("pct")),
            },
            "probable_pitcher": {
                "id": _int(pitcher.get("id")),
                "name": pitcher.get("fullName") or "尚未公布",
            },
        }

    @classmethod
    def _normalize_game(cls, game: dict[str, Any]) -> dict[str, Any]:
        game_date = game.get("gameDate")
        dt = _parse_game_datetime(game_date)
        taipei_dt = dt.astimezone(TAIPEI)
        status = game.get("status") or {}
        abstract = str(status.get("abstractGameState") or "Preview").lower()
        state = "live" if abstract == "live" else "final" if abstract == "final" else "upcoming"
        linescore = game.get("linescore") or {}
        return {
            "game_pk": _int(game.get("gamePk")),
            "game_date": game_date,
            "date_taiwan": taipei_dt.date().isoformat(),
            "time_taiwan": taipei_dt.strftime("%H:%M"),
            "status": state,
            "detailed_status": status.get("detailedState") or "",
            "inning": _int(linescore.get("currentInning")),
            "inning_state": linescore.get("inningState") or "",
            "venue": (game.get("venue") or {}).get("name") or "",
            "away": cls._team((game.get("teams") or {}).get("away") or {}),
            "home": cls._team((game.get("teams") or {}).get("home") or {}),
        }

    async def games_for_date(self, taiwan_date: date) -> dict[str, Any]:
        adjacent_dates = [taiwan_date - timedelta(days=1), taiwan_date, taiwan_date + timedelta(days=1)]
        payloads = await asyncio.gather(
            *[
                self._get_json(
                    "/schedule",
                    {
                        "sportId": 1,
                        "date": day.isoformat(),
                        "hydrate": "probablePitcher,linescore,team,venue",
                    },
                )
                for day in adjacent_dates
            ]
        )
        raw_games = [
            game
            for payload in payloads
            for day in payload.data.get("dates", [])
            for game in day.get("games", [])
        ]
        unique = {game.get("gamePk"): game for game in raw_games if game.get("gamePk")}
        items = [
            self._normalize_game(game)
            for game in unique.values()
            if _parse_game_datetime(game["gameDate"]).astimezone(TAIPEI).date() == taiwan_date
        ]
        items.sort(key=lambda game: game["game_date"])
        statuses = {payload.cache_status for payload in payloads}
        cache_status = "stale" if "stale" in statuses else "miss" if "miss" in statuses else "hit"
        return {
            "date": taiwan_date.isoformat(),
            "timezone": "Asia/Taipei",
            "count": len(items),
            "items": items,
            "meta": {
                "source": "MLB Stats API",
                "cache": cache_status,
                "updated_at": max(payload.fetched_at for payload in payloads),
            },
        }

    @staticmethod
    def _last_ten(record: dict[str, Any]) -> dict[str, int | None]:
        split_records = (record.get("records") or {}).get("splitRecords") or []
        for split in split_records:
            split_type = str(split.get("type") or "").lower().replace(" ", "")
            if split_type in {"lastten", "last10"}:
                return {"wins": _int(split.get("wins")), "losses": _int(split.get("losses"))}
        return {"wins": None, "losses": None}

    async def standings(self, season: int) -> tuple[dict[int, dict[str, Any]], dict[str, Any]]:
        payload = await self._get_json(
            "/standings",
            {
                "leagueId": "103,104",
                "season": season,
                "standingsTypes": "regularSeason",
                "hydrate": "team",
            },
            ttl_seconds=300,
        )
        teams: dict[int, dict[str, Any]] = {}
        for division in payload.data.get("records", []):
            for record in division.get("teamRecords", []):
                team = record.get("team") or {}
                team_id = _int(team.get("id"))
                if team_id is None:
                    continue
                league_record = record.get("leagueRecord") or {}
                wins = _int(record.get("wins"))
                losses = _int(record.get("losses"))
                if wins is None:
                    wins = _int(league_record.get("wins"))
                if losses is None:
                    losses = _int(league_record.get("losses"))
                winning_pct = _float(record.get("winningPercentage"))
                if winning_pct is None:
                    winning_pct = _float(league_record.get("pct"))
                runs_scored = _int(record.get("runsScored"))
                runs_allowed = _int(record.get("runsAllowed"))
                teams[team_id] = {
                    "team_id": team_id,
                    "team_name": team.get("name") or "Unknown",
                    "wins": wins,
                    "losses": losses,
                    "winning_pct": winning_pct,
                    "runs_scored": runs_scored,
                    "runs_allowed": runs_allowed,
                    "run_differential": _int(record.get("runDifferential")),
                    "pythagorean_pct": pythagorean_win_pct(runs_scored, runs_allowed),
                    "last_ten": self._last_ten(record),
                    "streak": (record.get("streak") or {}).get("streakCode"),
                }
        return teams, {"cache": payload.cache_status, "updated_at": payload.fetched_at}

    @staticmethod
    def _fallback_team(game_team: dict[str, Any]) -> dict[str, Any]:
        record = game_team.get("record") or {}
        return {
            "team_id": game_team.get("id"),
            "team_name": game_team.get("name"),
            "wins": record.get("wins"),
            "losses": record.get("losses"),
            "winning_pct": record.get("pct"),
            "runs_scored": None,
            "runs_allowed": None,
            "run_differential": None,
            "pythagorean_pct": None,
            "last_ten": {"wins": None, "losses": None},
            "streak": None,
        }

    async def pitcher_stats(self, person_id: int | None, season: int) -> dict[str, Any] | None:
        if not person_id:
            return None
        try:
            payload = await self._get_json(
                f"/people/{person_id}/stats",
                {"stats": "season", "group": "pitching", "season": season},
                ttl_seconds=300,
            )
        except MLBUpstreamError:
            return None
        groups = payload.data.get("stats") or []
        splits = groups[0].get("splits", []) if groups else []
        stat = splits[0].get("stat", {}) if splits else {}
        return {
            "person_id": person_id,
            "era": _float(stat.get("era")),
            "whip": _float(stat.get("whip")),
            "wins": _int(stat.get("wins")),
            "losses": _int(stat.get("losses")),
            "strikeouts": _int(stat.get("strikeOuts")),
            "innings_pitched": stat.get("inningsPitched"),
        }

    async def matchup_analyses(
        self,
        taiwan_date: date,
        *,
        pitcher_limit: int | None = 5,
    ) -> dict[str, Any]:
        """Analyze every upcoming game while keeping pitcher traffic bounded.

        The public moneyline endpoint enriches only the strongest preliminary
        games. The protected daily job passes ``None`` so the paid spread and
        total models can evaluate every matchup using announced starters.
        """

        schedule = await self.games_for_date(taiwan_date)
        candidates = [game for game in schedule["items"] if game["status"] == "upcoming"]
        if not candidates:
            return {
                "date": taiwan_date.isoformat(),
                "items": [],
                "message": "今天沒有尚未開賽且可分析的 MLB 賽事。",
                "meta": schedule["meta"],
            }

        season = taiwan_date.year
        try:
            standings, standings_meta = await self.standings(season)
        except MLBUpstreamError:
            standings, standings_meta = {}, {"cache": "unavailable", "updated_at": None}

        base_results: list[dict[str, Any]] = []
        for game in candidates:
            away_team = standings.get(game["away"]["id"]) or self._fallback_team(game["away"])
            home_team = standings.get(game["home"]["id"]) or self._fallback_team(game["home"])
            result = analyze_matchup(game, away_team, home_team)
            result["game"] = game
            base_results.append(result)

        ranked = sorted(base_results, key=lambda result: result["confidence"], reverse=True)
        selected_for_pitchers = ranked if pitcher_limit is None else ranked[: max(0, pitcher_limit)]
        strongest_ids = {result["game_pk"] for result in selected_for_pitchers}

        async def enrich(game: dict[str, Any]) -> dict[str, Any]:
            away_pitcher, home_pitcher = await asyncio.gather(
                self.pitcher_stats(game["away"]["probable_pitcher"]["id"], season),
                self.pitcher_stats(game["home"]["probable_pitcher"]["id"], season),
            )
            away_team = standings.get(game["away"]["id"]) or self._fallback_team(game["away"])
            home_team = standings.get(game["home"]["id"]) or self._fallback_team(game["home"])
            result = analyze_matchup(game, away_team, home_team, away_pitcher, home_pitcher)
            result["starting_pitchers"] = {
                "away": {**game["away"]["probable_pitcher"], "stats": away_pitcher},
                "home": {**game["home"]["probable_pitcher"], "stats": home_pitcher},
            }
            result["game"] = game
            return result

        enriched = await asyncio.gather(
            *[enrich(game) for game in candidates if game["game_pk"] in strongest_ids]
        )

        enriched_by_game = {result["game_pk"]: result for result in enriched}
        analyses = [enriched_by_game.get(result["game_pk"], result) for result in base_results]
        return {
            "date": taiwan_date.isoformat(),
            "items": analyses,
            "message": f"已完成 {len(analyses)} 場賽事分析。",
            "meta": {
                "schedule_cache": schedule["meta"]["cache"],
                "standings_cache": standings_meta["cache"],
                "updated_at": schedule["meta"]["updated_at"],
                "pitcher_enriched": len(enriched),
            },
        }

    async def top_prediction(self, taiwan_date: date) -> dict[str, Any]:
        analysis_set = await self.matchup_analyses(taiwan_date, pitcher_limit=5)
        analyses = analysis_set["items"]
        if not analyses:
            return {
                "date": taiwan_date.isoformat(),
                "published": False,
                "selection": None,
                "message": analysis_set["message"],
                "meta": analysis_set["meta"],
            }

        selection = max(analyses, key=lambda result: result["confidence"])
        published = selection["confidence"] >= self.settings.min_confidence and selection["data_quality"] >= 0.45
        return {
            "date": taiwan_date.isoformat(),
            "published": published,
            "selection": selection if published else None,
            "candidate": None if published else selection,
            "message": (
                "今日最高信心場次已完成。"
                if published
                else f"最高候選信心 {selection['confidence']}%，未達發布門檻 {self.settings.min_confidence}%。"
            ),
            "meta": {
                **analysis_set["meta"],
                "model_version": selection["model_version"],
                "minimum_confidence": self.settings.min_confidence,
            },
        }

    async def game_result(self, game_pk: int) -> dict[str, Any]:
        """Return the normalized scoreboard without expensive detail calls."""

        payload = await self._get_json(
            "/schedule",
            {
                "sportId": 1,
                "gamePk": game_pk,
                "hydrate": "linescore,team,venue",
            },
            ttl_seconds=30,
        )
        raw_games = [game for day in payload.data.get("dates", []) for game in day.get("games", [])]
        if not raw_games:
            raise KeyError("Game not found")
        return self._normalize_game(raw_games[0])

    @staticmethod
    def _extract_team_stats(payload: dict[str, Any]) -> dict[str, Any]:
        groups = payload.get("stats") or []
        splits = groups[0].get("splits", []) if groups else []
        return splits[0].get("stat", {}) if splits else {}

    async def _team_season_stats(self, team_id: int, season: int) -> dict[str, Any]:
        hitting, pitching = await asyncio.gather(
            self._get_json(
                f"/teams/{team_id}/stats",
                {"stats": "season", "group": "hitting", "season": season},
                ttl_seconds=300,
            ),
            self._get_json(
                f"/teams/{team_id}/stats",
                {"stats": "season", "group": "pitching", "season": season},
                ttl_seconds=300,
            ),
        )
        hit = self._extract_team_stats(hitting.data)
        pitch = self._extract_team_stats(pitching.data)
        return {
            "hitting": {
                "runs": _int(hit.get("runs")),
                "avg": _float(hit.get("avg")),
                "obp": _float(hit.get("obp")),
                "slg": _float(hit.get("slg")),
                "ops": _float(hit.get("ops")),
                "home_runs": _int(hit.get("homeRuns")),
            },
            "pitching": {
                "era": _float(pitch.get("era")),
                "whip": _float(pitch.get("whip")),
                "runs_allowed": _int(pitch.get("runs")),
                "strikeouts": _int(pitch.get("strikeOuts")),
            },
            "cache": "stale" if "stale" in {hitting.cache_status, pitching.cache_status} else "hit",
        }

    async def _lineups(self, game_pk: int) -> dict[str, Any]:
        try:
            payload = await self._get_json(
                f"{self.settings.mlb_live_base}/game/{game_pk}/feed/live",
                ttl_seconds=30,
            )
        except MLBUpstreamError:
            return {"available": False, "away": [], "home": []}
        game_data = payload.data.get("gameData") or {}
        players = game_data.get("players") or {}
        box_teams = ((payload.data.get("liveData") or {}).get("boxscore") or {}).get("teams") or {}

        def names(side: str) -> list[str]:
            order = (box_teams.get(side) or {}).get("battingOrder") or []
            result = []
            for player_id in order:
                player = players.get(f"ID{player_id}") or players.get(str(player_id)) or {}
                if player.get("fullName"):
                    result.append(player["fullName"])
            return result

        away, home = names("away"), names("home")
        return {"available": bool(away or home), "away": away, "home": home, "cache": payload.cache_status}

    async def game_detail(self, game_pk: int) -> dict[str, Any]:
        payload = await self._get_json(
            "/schedule",
            {
                "sportId": 1,
                "gamePk": game_pk,
                "hydrate": "probablePitcher,linescore,team,venue",
            },
        )
        raw_games = [game for day in payload.data.get("dates", []) for game in day.get("games", [])]
        if not raw_games:
            raise KeyError("Game not found")
        game = self._normalize_game(raw_games[0])
        season = _parse_game_datetime(game["game_date"]).year
        away_id, home_id = game["away"]["id"], game["home"]["id"]
        if away_id is None or home_id is None:
            raise MLBUpstreamError("Team identifiers are unavailable")
        away_stats, home_stats, lineups, standings_result = await asyncio.gather(
            self._team_season_stats(away_id, season),
            self._team_season_stats(home_id, season),
            self._lineups(game_pk),
            self.standings(season),
        )
        standings, _ = standings_result
        return {
            "game": game,
            "teams": {
                "away": {"standing": standings.get(away_id), "season_stats": away_stats},
                "home": {"standing": standings.get(home_id), "season_stats": home_stats},
            },
            "lineups": lineups,
            "bullpen": {
                "available": False,
                "message": "精準牛棚近期用量將於 V10 第二階段加入，不使用球隊總投手數據冒充牛棚數據。",
            },
            "meta": {"source": "MLB Stats API", "cache": payload.cache_status, "updated_at": payload.fetched_at},
        }
