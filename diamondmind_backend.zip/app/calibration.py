from __future__ import annotations

import math
from collections import defaultdict
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Iterable

UTC = timezone.utc
EPS = 1e-6
TERMINAL = {"won", "lost"}
SUPPORTED_MARKETS = {"moneyline", "run_line", "totals"}
SUPPORTED_LEAGUES = {"MLB", "NPB", "KBO", "CPBL"}


def _float(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def clamp_probability(value: Any, *, default: float = 0.5) -> float:
    number = _float(value)
    if number is None:
        return default
    if number > 1.0:
        number /= 100.0
    return min(1.0 - EPS, max(EPS, number))


def probability_percent(value: Any) -> float:
    return round(clamp_probability(value) * 100.0, 1)


def _sigmoid(value: float) -> float:
    if value >= 0:
        z = math.exp(-value)
        return 1.0 / (1.0 + z)
    z = math.exp(value)
    return z / (1.0 + z)


def _logit(probability: float) -> float:
    p = min(1.0 - EPS, max(EPS, probability))
    return math.log(p / (1.0 - p))


def apply_platt(probability: Any, slope: Any = 1.0, intercept: Any = 0.0) -> float:
    p = clamp_probability(probability)
    a = _float(slope)
    b = _float(intercept)
    if a is None or b is None:
        return p
    return min(1.0 - EPS, max(EPS, _sigmoid(a * _logit(p) + b)))


def _label(row: dict[str, Any]) -> int | None:
    status = str(row.get("status") or "").lower()
    if status == "won":
        return 1
    if status == "lost":
        return 0
    return None


def _row_probability(row: dict[str, Any]) -> float | None:
    for key in ("raw_model_probability", "confidence", "model_probability"):
        value = row.get(key)
        if value is not None:
            return clamp_probability(value)
    result = row.get("result") or {}
    for key in ("raw_model_probability", "model_probability"):
        value = result.get(key)
        if value is not None:
            return clamp_probability(value)
    return None


def _date_key(row: dict[str, Any]) -> tuple[str, str]:
    return (
        str(row.get("recommendation_date") or ""),
        str(row.get("created_at") or row.get("published_at") or ""),
    )


def calibration_metrics(probabilities: Iterable[float], labels: Iterable[int], *, bins: int = 10) -> dict[str, Any]:
    pairs = [(clamp_probability(p), int(y)) for p, y in zip(probabilities, labels)]
    if not pairs:
        return {
            "sample": 0,
            "brier": None,
            "log_loss": None,
            "ece": None,
            "accuracy": None,
            "mean_probability": None,
            "observed_rate": None,
            "bins": [],
        }
    sample = len(pairs)
    brier = sum((p - y) ** 2 for p, y in pairs) / sample
    log_loss = -sum(y * math.log(p) + (1 - y) * math.log(1 - p) for p, y in pairs) / sample
    accuracy = sum((p >= 0.5) == bool(y) for p, y in pairs) / sample
    bucket_rows: list[dict[str, Any]] = []
    ece = 0.0
    for index in range(max(2, bins)):
        low = index / bins
        high = (index + 1) / bins
        bucket = [(p, y) for p, y in pairs if low <= p < high or (index == bins - 1 and p == 1.0)]
        if not bucket:
            continue
        mean_p = sum(p for p, _ in bucket) / len(bucket)
        observed = sum(y for _, y in bucket) / len(bucket)
        ece += len(bucket) / sample * abs(mean_p - observed)
        bucket_rows.append({
            "low": round(low * 100, 1),
            "high": round(high * 100, 1),
            "sample": len(bucket),
            "mean_probability": round(mean_p * 100, 2),
            "observed_rate": round(observed * 100, 2),
            "gap_points": round((mean_p - observed) * 100, 2),
        })
    return {
        "sample": sample,
        "brier": round(brier, 6),
        "log_loss": round(log_loss, 6),
        "ece": round(ece, 6),
        "accuracy": round(accuracy * 100, 2),
        "mean_probability": round(sum(p for p, _ in pairs) / sample * 100, 2),
        "observed_rate": round(sum(y for _, y in pairs) / sample * 100, 2),
        "bins": bucket_rows,
    }


def fit_platt(
    probabilities: list[float],
    labels: list[int],
    *,
    max_iter: int = 800,
    learning_rate: float = 0.08,
    l2: float = 0.08,
) -> tuple[float, float]:
    """Fit a strongly regularized Platt scaler without external dependencies.

    The regularization target is the identity mapping (slope=1, intercept=0),
    not zero. This makes small samples conservative and avoids violent daily
    probability swings.
    """
    if len(probabilities) != len(labels) or len(probabilities) < 8:
        return 1.0, 0.0
    xs = [_logit(clamp_probability(value)) for value in probabilities]
    ys = [int(value) for value in labels]
    slope, intercept = 1.0, 0.0
    n = float(len(xs))
    for step in range(max_iter):
        grad_a = 0.0
        grad_b = 0.0
        for x, y in zip(xs, ys):
            predicted = _sigmoid(slope * x + intercept)
            error = predicted - y
            grad_a += error * x
            grad_b += error
        grad_a = grad_a / n + l2 * (slope - 1.0)
        grad_b = grad_b / n + l2 * intercept
        rate = learning_rate / (1.0 + step / 220.0)
        next_a = min(2.5, max(0.25, slope - rate * grad_a))
        next_b = min(1.5, max(-1.5, intercept - rate * grad_b))
        if abs(next_a - slope) + abs(next_b - intercept) < 1e-8:
            slope, intercept = next_a, next_b
            break
        slope, intercept = next_a, next_b
    return round(slope, 8), round(intercept, 8)


def _split_rows(rows: list[dict[str, Any]], validation_fraction: float = 0.28) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    ordered = sorted(rows, key=_date_key)
    if len(ordered) < 20:
        return ordered, []
    validation_size = max(10, int(round(len(ordered) * validation_fraction)))
    validation_size = min(validation_size, max(1, len(ordered) // 2))
    return ordered[:-validation_size], ordered[-validation_size:]


def _metric_improvement(candidate: dict[str, Any], baseline: dict[str, Any]) -> dict[str, Any]:
    brier_base = _float(baseline.get("brier"))
    brier_new = _float(candidate.get("brier"))
    log_base = _float(baseline.get("log_loss"))
    log_new = _float(candidate.get("log_loss"))
    ece_base = _float(baseline.get("ece"))
    ece_new = _float(candidate.get("ece"))
    return {
        "brier_delta": round((brier_base - brier_new), 6) if None not in {brier_base, brier_new} else None,
        "log_loss_delta": round((log_base - log_new), 6) if None not in {log_base, log_new} else None,
        "ece_delta": round((ece_base - ece_new), 6) if None not in {ece_base, ece_new} else None,
    }


def build_calibration_candidate(
    rows: list[dict[str, Any]],
    *,
    league: str,
    market: str,
    minimum_sample: int = 60,
    minimum_validation_sample: int = 18,
) -> dict[str, Any]:
    clean: list[dict[str, Any]] = []
    for row in rows:
        label = _label(row)
        probability = _row_probability(row)
        if label is None or probability is None or bool(row.get("is_test")):
            continue
        row_league = str(row.get("league") or "").upper()
        row_market = str(row.get("market") or "").lower()
        if league != "GLOBAL" and row_league != league:
            continue
        if market != "all" and row_market != market:
            continue
        publication = row.get("publication_snapshot") or {}
        # Founder overrides are useful for public record keeping, but they are
        # not a clean sample of the automatic model's decision policy.
        if publication.get("counts_as_ai_formal") is False:
            continue
        clean.append({**row, "_label": label, "_probability": probability})

    train, validation = _split_rows(clean)
    train_probs = [float(row["_probability"]) for row in train]
    train_labels = [int(row["_label"]) for row in train]
    slope, intercept = fit_platt(train_probs, train_labels)

    validation_probs = [float(row["_probability"]) for row in validation]
    validation_labels = [int(row["_label"]) for row in validation]
    baseline = calibration_metrics(validation_probs, validation_labels)
    calibrated_probs = [apply_platt(value, slope, intercept) for value in validation_probs]
    candidate = calibration_metrics(calibrated_probs, validation_labels)
    improvement = _metric_improvement(candidate, baseline)

    enough = len(clean) >= minimum_sample and len(validation) >= minimum_validation_sample
    brier_delta = float(improvement.get("brier_delta") or 0.0)
    log_delta = float(improvement.get("log_loss_delta") or 0.0)
    ece_delta = float(improvement.get("ece_delta") or 0.0)
    # Promotion is deliberately conservative. Calibration may improve
    # probability honesty without changing picks; it must not be promoted on a
    # tiny numerical fluctuation.
    promote = bool(
        enough
        and (
            (brier_delta >= 0.002 and log_delta >= -0.001)
            or (ece_delta >= 0.012 and brier_delta >= -0.0005 and log_delta >= -0.001)
        )
    )
    return {
        "league": league,
        "market": market,
        "sample": len(clean),
        "train_sample": len(train),
        "validation_sample": len(validation),
        "minimum_sample": minimum_sample,
        "minimum_validation_sample": minimum_validation_sample,
        "ready": enough,
        "slope": slope,
        "intercept": intercept,
        "baseline_metrics": baseline,
        "candidate_metrics": candidate,
        "improvement": improvement,
        "promote": promote,
        "reason": (
            "validation_improved" if promote else
            "insufficient_sample" if not enough else
            "validation_not_improved"
        ),
    }


def build_scope_candidates(
    rows: list[dict[str, Any]],
    *,
    minimum_sample: int = 60,
    minimum_validation_sample: int = 18,
) -> list[dict[str, Any]]:
    scopes: list[tuple[str, str]] = [("GLOBAL", "all")]
    scopes.extend((league, "all") for league in sorted(SUPPORTED_LEAGUES))
    scopes.extend((league, market) for league in sorted(SUPPORTED_LEAGUES) for market in sorted(SUPPORTED_MARKETS))
    return [
        build_calibration_candidate(
            rows,
            league=league,
            market=market,
            minimum_sample=minimum_sample,
            minimum_validation_sample=minimum_validation_sample,
        )
        for league, market in scopes
    ]


@dataclass
class CalibrationRegistry:
    profiles: dict[tuple[str, str], dict[str, Any]]
    loaded_at: str | None = None

    @classmethod
    def empty(cls) -> "CalibrationRegistry":
        return cls(profiles={}, loaded_at=None)

    @classmethod
    def from_rows(cls, rows: Iterable[dict[str, Any]]) -> "CalibrationRegistry":
        profiles: dict[tuple[str, str], dict[str, Any]] = {}
        for row in rows:
            if str(row.get("status") or "active") != "active":
                continue
            league = str(row.get("league") or "GLOBAL").upper()
            market = str(row.get("market") or "all").lower()
            profiles[(league, market)] = dict(row)
        return cls(profiles=profiles, loaded_at=datetime.now(UTC).isoformat())

    def resolve(self, league: Any, market: Any) -> tuple[dict[str, Any] | None, str]:
        code = str(league or "GLOBAL").upper()
        market_key = str(market or "all").lower()
        for key, source in (
            ((code, market_key), "league_market"),
            ((code, "all"), "league"),
            (("GLOBAL", market_key), "global_market"),
            (("GLOBAL", "all"), "global"),
        ):
            profile = self.profiles.get(key)
            if profile:
                return profile, source
        return None, "identity"

    def calibrate(self, probability: Any, *, league: Any, market: Any) -> dict[str, Any]:
        raw = clamp_probability(probability)
        profile, source = self.resolve(league, market)
        if not profile:
            calibrated = raw
            return {
                "raw_probability": round(raw * 100.0, 2),
                "calibrated_probability": round(calibrated * 100.0, 2),
                "applied": False,
                "source": source,
                "profile_id": None,
                "profile_version": None,
            }
        calibrated = apply_platt(raw, profile.get("slope"), profile.get("intercept"))
        return {
            "raw_probability": round(raw * 100.0, 2),
            "calibrated_probability": round(calibrated * 100.0, 2),
            "applied": True,
            "source": source,
            "profile_id": profile.get("id"),
            "profile_version": profile.get("version") or profile.get("created_at"),
            "sample": profile.get("sample"),
            "validation_metrics": profile.get("validation_metrics") or profile.get("candidate_metrics"),
        }


def apply_registry_to_selection(
    selection: dict[str, Any],
    registry: CalibrationRegistry | None,
    *,
    minimum_probability: float | None = None,
    minimum_edge: float | None = None,
) -> dict[str, Any]:
    if not isinstance(selection, dict):
        return selection
    result = dict(selection)
    league = str(result.get("league") or (result.get("game") or {}).get("league") or "MLB").upper()
    market = str(result.get("market") or (result.get("pick") or {}).get("market") or "moneyline").lower()
    raw_value = result.get("model_probability")
    if raw_value is None:
        raw_value = result.get("confidence")
    if raw_value is None:
        return result
    calibration = (registry or CalibrationRegistry.empty()).calibrate(raw_value, league=league, market=market)
    calibrated_percent = float(calibration["calibrated_probability"])
    result["raw_model_probability"] = round(clamp_probability(raw_value) * 100.0, 1)
    result["model_probability"] = round(calibrated_percent, 1)
    result["confidence"] = round(calibrated_percent, 1)
    result["calibration"] = calibration
    game = result.get("game") or {}
    pick = result.get("pick") or {}
    data_integrity = {
        "official_game_id": bool(result.get("game_pk") or game.get("game_pk") or game.get("external_game_id")),
        "matchup": bool(result.get("matchup") or (game.get("away") and game.get("home"))),
        "game_date": bool(result.get("game_date") or game.get("game_date") or game.get("date_taiwan")),
        "valid_direction": str(pick.get("side") or "").lower() in {"away", "home", "over", "under"},
        "probability": True,
        "data_quality": result.get("data_quality") is not None,
        "real_odds": bool(
            result.get("market_basis") != "real_odds"
            or ((result.get("odds_source") or {}).get("type") == "real_bookmaker" and result.get("price") is not None)
        ),
    }
    data_integrity["publish_safe"] = all(data_integrity.values())
    result["data_integrity"] = data_integrity
    qualification_policy = str(result.get("qualification_policy") or "").lower()
    model_direction_policy = bool(
        qualification_policy == "model_direction"
        and league in {"NPB", "KBO", "CPBL"}
        and market == "moneyline"
        and str(pick.get("side") or "").lower() in {"away", "home"}
    )
    if model_direction_policy:
        direction_probability = result.get("model_direction_probability")
        if direction_probability is None:
            direction_probability = result["raw_model_probability"]
        result["model_direction_probability"] = round(
            clamp_probability(direction_probability) * 100.0,
            1,
        )
        qualification_thresholds = dict(result.get("qualification_thresholds") or {})
        qualification_thresholds.update({
            "policy": "higher_model_direction",
            "minimum_probability": None,
            "minimum_edge": None,
            "minimum_projection_quality": None,
        })
        result["qualification_thresholds"] = qualification_thresholds
        result["minimum_probability_gate_enabled"] = False
        result["market_edge_gate_enabled"] = False
        result["meets_threshold"] = bool(data_integrity["publish_safe"])
        result["candidate_tier"] = (
            "formal" if result["meets_threshold"] else "unclassified"
        )
        quality = float(result.get("data_quality") or 0.0)
        result["rank_score"] = round(
            float(result["model_direction_probability"]) - 50.0 + quality * 2.0,
            3,
        )
        implied_value = _float(result.get("implied_probability"))
        if implied_value is not None:
            implied_percent = implied_value * 100.0 if implied_value <= 1.0 else implied_value
            result["edge"] = round(calibrated_percent - implied_percent, 1)
        return result
    implied_value = _float(result.get("implied_probability"))
    if implied_value is not None:
        implied_percent = implied_value * 100.0 if implied_value <= 1.0 else implied_value
        edge = calibrated_percent - implied_percent
        result["edge"] = round(edge, 1)
        qualification_thresholds = dict(result.get("qualification_thresholds") or {})
        if minimum_probability is not None:
            qualification_thresholds["minimum_probability"] = round(
                float(minimum_probability), 2
            )
        if minimum_edge is not None:
            qualification_thresholds["minimum_edge"] = round(
                float(minimum_edge), 2
            )
        result["qualification_thresholds"] = qualification_thresholds
        qualifies = True
        if minimum_probability is not None:
            qualifies = qualifies and calibrated_percent >= float(minimum_probability)
        if minimum_edge is not None:
            qualifies = qualifies and edge >= float(minimum_edge)
        existing = result.get("meets_threshold")
        result["meets_threshold"] = qualifies if existing is not False else False
        quality = float(result.get("data_quality") or 0.0)
        result["rank_score"] = round(edge + (calibrated_percent / 100.0 - 0.5) * 20.0 + quality * 2.0, 3)
    return result


def apply_registry_to_bundle(
    bundle: dict[str, Any],
    registry: CalibrationRegistry | None,
    *,
    minimum_probability: float | None = None,
    minimum_edge: float | None = None,
    thresholds_by_league: dict[str, dict[str, float]] | None = None,
) -> dict[str, Any]:
    """Calibrate, re-rank and re-partition a market candidate bundle.

    A candidate that no longer clears the calibrated threshold is moved to the
    founder watchlist before publication. This is essential: merely changing
    the displayed percentage while leaving the old formal recommendation list
    untouched would not improve selection quality.
    """
    result = dict(bundle)
    original_candidates = dict(result.get("candidates") or {})
    original_watchlist = dict(result.get("watchlist") or {})
    candidates: dict[str, Any] = dict(original_candidates)
    watchlist: dict[str, Any] = dict(original_watchlist)
    formal_pool: list[dict[str, Any]] = []

    for group in ("moneylines", "run_lines", "totals"):
        combined = [
            item for item in [
                *(original_candidates.get(group) or []),
                *(original_watchlist.get(group) or []),
            ]
            if isinstance(item, dict)
        ]
        deduplicated: dict[str, dict[str, Any]] = {}
        for item in combined:
            league = str(
                item.get("league")
                or (item.get("game") or {}).get("league")
                or "MLB"
            ).upper()
            league_thresholds = (thresholds_by_league or {}).get(league) or {}
            calibrated = apply_registry_to_selection(
                item,
                registry,
                minimum_probability=league_thresholds.get(
                    "minimum_probability", minimum_probability
                ),
                minimum_edge=league_thresholds.get(
                    "minimum_edge", minimum_edge
                ),
            )
            key = str(calibrated.get("candidate_id") or id(item))
            existing = deduplicated.get(key)
            if existing is None or float(calibrated.get("rank_score") or -999) > float(existing.get("rank_score") or -999):
                deduplicated[key] = calibrated
        ordered = sorted(deduplicated.values(), key=lambda item: float(item.get("rank_score") or 0.0), reverse=True)
        formal = [item for item in ordered if item.get("meets_threshold") is True]
        observation = [item for item in ordered if item.get("meets_threshold") is not True]
        candidates[group] = formal
        watchlist[group] = observation
        formal_pool.extend(formal)

    # Rebuild parlays from calibrated formal legs so combined probability and
    # ranking never use the pre-calibration numbers.
    from .markets import _build_parlay_candidates
    minimum_parlay = float((result.get("thresholds") or {}).get("minimum_parlay_leg_probability") or 54.0)
    eligible_legs = [
        item for item in formal_pool
        if float(item.get("model_probability") or 0.0) >= minimum_parlay
        and item.get("decimal_odds") is not None
    ]
    candidates["parlays"] = {
        "two_leg": _build_parlay_candidates(eligible_legs, 2, limit=8),
        "three_leg": _build_parlay_candidates(eligible_legs, 3, limit=6),
    }
    result["candidates"] = candidates
    result["watchlist"] = watchlist

    # Founder manual-parlay choices use the same calibrated probabilities as
    # the displayed single candidates, but they are not filtered by the AI
    # formal/watchlist gates. Real-odds eligibility remains the hard gate.
    original_manual_pool = result.get("manual_pool") or {}
    calibrated_manual_pool: dict[str, list[dict[str, Any]]] = {}
    for group in ("moneylines", "run_lines", "totals"):
        deduplicated_manual: dict[str, dict[str, Any]] = {}
        for item in original_manual_pool.get(group) or []:
            if not isinstance(item, dict):
                continue
            calibrated = apply_registry_to_selection(
                item, registry, minimum_probability=None, minimum_edge=None
            )
            key = str(calibrated.get("candidate_id") or id(item))
            deduplicated_manual[key] = calibrated
        calibrated_manual_pool[group] = sorted(
            deduplicated_manual.values(),
            key=lambda item: float(item.get("rank_score") or 0.0),
            reverse=True,
        )
    result["manual_pool"] = calibrated_manual_pool

    if isinstance(result.get("public_moneyline"), dict):
        result["public_moneyline"] = apply_registry_to_selection(
            result["public_moneyline"], registry, minimum_probability=None, minimum_edge=None
        )

    public_pk = str((result.get("public_moneyline") or {}).get("game_pk") or "")
    recommended = dict(result.get("recommended") or {})
    recommended["moneylines"] = [
        item.get("candidate_id") for item in candidates.get("moneylines") or []
        if str(item.get("game_pk") or "") != public_pk
    ]
    recommended["run_lines"] = [item.get("candidate_id") for item in candidates.get("run_lines") or []]
    recommended["totals"] = [item.get("candidate_id") for item in candidates.get("totals") or []]
    recommended["two_leg"] = [item.get("candidate_id") for item in (candidates.get("parlays") or {}).get("two_leg") or []][:2]
    recommended["three_leg"] = [item.get("candidate_id") for item in (candidates.get("parlays") or {}).get("three_leg") or []][:1]
    result["recommended"] = recommended

    counts = dict(result.get("candidate_counts") or {})
    counts.update({
        "moneyline_qualified": len(candidates.get("moneylines") or []),
        "run_line_qualified": len(candidates.get("run_lines") or []),
        "totals_qualified": len(candidates.get("totals") or []),
        "two_leg_candidates": len((candidates.get("parlays") or {}).get("two_leg") or []),
        "three_leg_candidates": len((candidates.get("parlays") or {}).get("three_leg") or []),
        "parlay_qualified_legs": len(eligible_legs),
        "watch_moneylines": len(watchlist.get("moneylines") or []),
        "watch_run_lines": len(watchlist.get("run_lines") or []),
        "watch_totals": len(watchlist.get("totals") or []),
        "manual_moneylines": len(calibrated_manual_pool.get("moneylines") or []),
        "manual_run_lines": len(calibrated_manual_pool.get("run_lines") or []),
        "manual_totals": len(calibrated_manual_pool.get("totals") or []),
    })
    by_league: dict[str, dict[str, int]] = {}
    for group in ("moneylines", "run_lines", "totals"):
        for item in candidates.get(group) or []:
            league = str(item.get("league") or "MLB").upper()
            league_counts = by_league.setdefault(league, {"moneylines": 0, "run_lines": 0, "totals": 0, "total": 0})
            league_counts[group] += 1
            league_counts["total"] += 1
    counts["by_league"] = by_league
    result["candidate_counts"] = counts
    result["calibration"] = {
        "enabled": bool(registry and registry.profiles),
        "profiles_loaded": len(registry.profiles) if registry else 0,
        "loaded_at": registry.loaded_at if registry else None,
        "policy": "league_market_with_hierarchical_fallback",
        "selection_gate": "asian_moneyline_model_direction_else_calibrated_probability_and_edge",
    }
    result["model_version"] = "dm-v21-calibrated-markets"
    return result
