from __future__ import annotations

import asyncio
import csv
import io
import json
import re
from dataclasses import dataclass
from typing import Any, Iterable
from urllib.parse import urlencode

import httpx

from .cache import AsyncTTLCache
from .config import Settings


class StatcastUpstreamError(RuntimeError):
    pass


@dataclass
class CSVPayload:
    rows: list[dict[str, str]]
    cache_status: str
    fetched_at: str


@dataclass
class JSONPayload:
    data: dict[str, Any]
    cache_status: str
    fetched_at: str


def _number(value: Any) -> float | None:
    if value is None:
        return None
    text = str(value).strip().replace("%", "")
    if not text or text.lower() in {"nan", "none", "null", "--", "-"}:
        return None
    try:
        return float(text)
    except (TypeError, ValueError):
        return None


def _int(value: Any) -> int | None:
    try:
        return int(float(str(value).strip()))
    except (TypeError, ValueError):
        return None


def _key(value: str) -> str:
    text = (
        value.strip()
        .lower()
        .replace("%", " percent ")
        .replace("+", " plus ")
        .replace("/", " ")
        .replace("-", " ")
        .replace(".", " ")
        .replace(",", " ")
    )
    return re.sub(r"_+", "_", re.sub(r"[^a-z0-9]+", "_", text)).strip("_")


def _normalized_row(row: dict[str, Any]) -> dict[str, Any]:
    return {_key(str(key)): value for key, value in row.items() if key is not None}


def _first(row: dict[str, Any], aliases: Iterable[str]) -> Any:
    for alias in aliases:
        key = _key(alias)
        if key in row and row[key] not in (None, ""):
            return row[key]
    return None


def _percent(value: Any) -> float | None:
    number = _number(value)
    if number is None:
        return None
    # Savant CSVs sometimes return .425 and sometimes 42.5.
    if abs(number) <= 1.5:
        number *= 100.0
    return round(number, 1)


def _rate(value: Any) -> float | None:
    number = _number(value)
    if number is None:
        return None
    if number > 1.5:
        number /= 100.0
    return round(number, 4)


def _metric_row(row: dict[str, Any]) -> dict[str, Any] | None:
    normalized = _normalized_row(row)
    player_id = _int(
        _first(
            normalized,
            (
                "player_id",
                "playerid",
                "id",
                "mlbam_id",
                "mlb_id",
                "player_id_1",
                "player",
                "batter",
                "pitcher",
            ),
        )
    )
    if player_id is None:
        return None
    name = _first(
        normalized,
        ("player_name", "last_name_first_name", "name", "last_name_comma_first_name"),
    )
    return {
        "player_id": player_id,
        "player_name": str(name or ""),
        "pa": _number(_first(normalized, ("pa", "plate_appearances", "bf", "batters_faced", "bip", "batted_ball_events"))),
        "xwoba": _rate(_first(normalized, ("xwoba", "est_woba", "estimated_woba_using_speedangle"))),
        "woba": _rate(_first(normalized, ("woba",))),
        "xera": _number(_first(normalized, ("xera", "est_era", "estimated_era"))),
        "hard_hit_pct": _percent(
            _first(normalized, ("hard_hit_percent", "hard_hit_pct", "hardhit_percent"))
        ),
        "barrel_pct": _percent(
            _first(
                normalized,
                ("barrel_batted_rate", "barrel_percent", "barrel_pct", "barrels_per_bbe"),
            )
        ),
        "xba": _rate(_first(normalized, ("xba", "est_ba"))),
        "xslg": _rate(_first(normalized, ("xslg", "est_slg"))),
    }



def _statsapi_metric_row(
    split: dict[str, Any],
    stat_type: str = "",
    fallback_player_id: int | None = None,
) -> dict[str, Any] | None:
    """Normalize MLB StatsAPI expected/advanced-stat splits.

    MLB's official StatsAPI exposes ``expectedStatistics`` as a supported stat
    type. Field labels have changed over time, so this parser accepts both the
    long API names and the short labels used by Savant.
    """
    player = split.get("player") or split.get("person") or {}
    stat = split.get("stat") or split.get("stats") or {}
    normalized = _normalized_row(stat if isinstance(stat, dict) else {})
    split_norm = _normalized_row(split)

    player_id = _int(player.get("id")) or _int(
        _first(
            normalized,
            (
                "player_id", "playerid", "mlbam_id", "mlb_id", "batter_id",
                "pitcher_id", "person_id",
            ),
        )
    ) or _int(_first(split_norm, ("player_id", "person_id", "batter_id", "pitcher_id"))) or fallback_player_id
    if player_id is None:
        return None

    name = player.get("fullName") or player.get("name") or _first(
        normalized, ("player_name", "name", "last_name_first_name")
    )
    expected = "expected" in str(stat_type).lower()
    xera = _number(
        _first(
            normalized,
            (
                "xera", "expected_era", "expectedera", "expected_earned_run_average",
                "expectedearnedrunaverage", "est_era", "estimated_era",
            ),
        )
    )
    # On the expectedStatistics pitching feed MLB has also returned the
    # translated expected ERA under the generic ``era`` key.
    if xera is None and expected:
        xera = _number(_first(normalized, ("era",)))

    return {
        "player_id": player_id,
        "player_name": str(name or ""),
        "pa": _number(
            _first(
                normalized,
                (
                    "pa", "plate_appearances", "plateappearances", "bf", "batters_faced",
                    "battersfaced", "bip", "batted_ball_events", "battedballevents",
                ),
            )
        ),
        "xwoba": _rate(
            _first(
                normalized,
                (
                    "xwoba", "expected_weighted_on_base_average",
                    "expectedweightedonbaseaverage", "expected_woba", "est_woba",
                    "estimated_woba_using_speedangle",
                ),
            )
        ),
        "woba": _rate(_first(normalized, ("woba", "weighted_on_base_average", "weightedonbaseaverage"))),
        "xera": xera,
        "hard_hit_pct": _percent(
            _first(
                normalized,
                (
                    "hard_hit_percent", "hard_hit_percentage", "hardhitpercent",
                    "hardhitpercentage", "hard_hit_pct", "hardhitrate",
                ),
            )
        ),
        "barrel_pct": _percent(
            _first(
                normalized,
                (
                    "barrel_batted_rate", "barrel_percent", "barrel_percentage", "barrelpercentage",
                    "barrel_pct", "barrels_per_bbe", "barrelrate",
                ),
            )
        ),
        "xba": _rate(
            _first(
                normalized,
                ("xba", "expected_batting_average", "expectedbattingaverage", "est_ba"),
            )
        ),
        "xslg": _rate(
            _first(
                normalized,
                (
                    "xslg", "expected_slugging_percentage", "expectedsluggingpercentage",
                    "expected_slugging", "est_slg",
                ),
            )
        ),
    }


def _statsapi_splits(payload: dict[str, Any]) -> Iterable[tuple[dict[str, Any], str]]:
    for group in payload.get("stats") or []:
        if not isinstance(group, dict):
            continue
        type_info = group.get("type") or {}
        stat_type = str(type_info.get("displayName") or type_info.get("code") or "")
        for split in group.get("splits") or []:
            if isinstance(split, dict):
                yield split, stat_type


def _extract_json_array(text: str, variable_names: Iterable[str] = ("data", "leaderboardData", "leaderboard_data")) -> list[dict[str, Any]] | None:
    """Extract leaderboard rows embedded in a Savant HTML page."""
    for name in variable_names:
        match = re.search(rf"(?:var|let|const)?\s*{re.escape(name)}\s*=\s*", text, flags=re.I)
        if not match:
            continue
        start = text.find("[", match.end())
        if start < 0:
            continue
        depth = 0
        in_string = False
        escaped = False
        quote = ""
        for index in range(start, len(text)):
            char = text[index]
            if in_string:
                if escaped:
                    escaped = False
                elif char == "\\":
                    escaped = True
                elif char == quote:
                    in_string = False
                continue
            if char in {'"', "'"}:
                in_string = True
                quote = char
                continue
            if char == "[":
                depth += 1
            elif char == "]":
                depth -= 1
                if depth == 0:
                    candidate = text[start:index + 1]
                    try:
                        value = json.loads(candidate)
                    except json.JSONDecodeError:
                        break
                    if isinstance(value, list) and all(isinstance(row, dict) for row in value):
                        return value
                    break
    return None


def _parse_leaderboard_text(text: str) -> list[dict[str, Any]]:
    cleaned = text.lstrip("\ufeff").strip()
    if not cleaned:
        raise ValueError("Savant returned an empty response")
    prefix = cleaned[:500].lower()
    if "<html" not in prefix and "<!doctype" not in prefix:
        sample = cleaned[:4096]
        try:
            dialect = csv.Sniffer().sniff(sample, delimiters=",\t;")
        except csv.Error:
            dialect = csv.excel
        rows = list(csv.DictReader(io.StringIO(cleaned), dialect=dialect))
        if rows and any(any(str(value or "").strip() for value in row.values()) for row in rows):
            return rows
    embedded = _extract_json_array(cleaned)
    if embedded:
        return embedded
    raise ValueError("Savant response contained neither CSV nor embedded leaderboard data")


def aggregate_metrics(metrics: Iterable[dict[str, Any]]) -> dict[str, Any]:
    rows = [row for row in metrics if row]
    if not rows:
        return {
            "available": False,
            "players": 0,
            "coverage_pa": 0.0,
            "xwoba": None,
            "hard_hit_pct": None,
            "barrel_pct": None,
            "xba": None,
            "xslg": None,
        }

    def weighted(field: str) -> float | None:
        pairs = []
        for row in rows:
            value = _number(row.get(field))
            if value is None:
                continue
            weight = max(1.0, _number(row.get("pa")) or 1.0)
            pairs.append((value, weight))
        if not pairs:
            return None
        return sum(value * weight for value, weight in pairs) / sum(weight for _, weight in pairs)

    xwoba = weighted("xwoba")
    hard_hit = weighted("hard_hit_pct")
    barrel = weighted("barrel_pct")
    xba = weighted("xba")
    xslg = weighted("xslg")
    sources = sorted(
        {
            str(source)
            for row in rows
            for source in ([row.get("source")] if row.get("source") else (row.get("sources") or []))
            if source
        }
    )
    updated_values = sorted(str(row.get("updated_at")) for row in rows if row.get("updated_at"))
    return {
        "available": any(value is not None for value in (xwoba, hard_hit, barrel, xba, xslg)),
        "players": len(rows),
        "coverage_pa": round(sum(max(0.0, _number(row.get("pa")) or 0.0) for row in rows), 1),
        "xwoba": round(xwoba, 4) if xwoba is not None else None,
        "hard_hit_pct": round(hard_hit, 1) if hard_hit is not None else None,
        "barrel_pct": round(barrel, 1) if barrel is not None else None,
        "xba": round(xba, 4) if xba is not None else None,
        "xslg": round(xslg, 4) if xslg is not None else None,
        "sources": sources,
        "updated_at": updated_values[-1] if updated_values else None,
    }


class StatcastService:
    """Small, cached Baseball Savant adapter.

    Baseball Savant exposes CSV downloads from its expected-statistics and
    custom-leaderboard pages. This adapter deliberately accepts multiple
    column aliases because MLB occasionally changes display labels while the
    underlying metrics remain the same.
    """

    def __init__(
        self,
        settings: Settings,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self.settings = settings
        self.cache = AsyncTTLCache()
        self.client = httpx.AsyncClient(
            timeout=httpx.Timeout(max(settings.request_timeout_seconds, 24.0), connect=12.0),
            follow_redirects=True,
            transport=transport,
            headers={
                "User-Agent": (
                    "Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) "
                    "AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 "
                    "Mobile/15E148 Safari/604.1 DiamondMind/2.0"
                ),
                "Accept": "text/csv,text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8",
                "Accept-Language": "en-US,en;q=0.9",
                "Cache-Control": "no-cache",
                "Pragma": "no-cache",
                "Referer": "https://baseballsavant.mlb.com/leaderboard/expected_statistics",
            },
        )

    async def aclose(self) -> None:
        await self.client.aclose()

    @staticmethod
    def _iso(timestamp: float) -> str:
        from datetime import datetime, timezone

        return datetime.fromtimestamp(timestamp, tz=timezone.utc).isoformat().replace("+00:00", "Z")

    async def _get_csv(
        self,
        path: str,
        params: dict[str, Any],
        *,
        ttl_seconds: int | None = None,
    ) -> CSVPayload:
        cleaned = {key: value for key, value in params.items() if value is not None}
        url = f"{self.settings.savant_base.rstrip('/')}/{path.lstrip('/')}"
        key = f"csv:{url}?{urlencode(sorted((str(k), str(v)) for k, v in cleaned.items()))}"
        ttl = ttl_seconds or self.settings.advanced_cache_ttl_seconds
        cached = self.cache.get(key)
        if cached and cached.is_fresh:
            return CSVPayload(cached.value, "hit", self._iso(cached.stored_at))
        async with self.cache.lock(key):
            cached = self.cache.get(key)
            if cached and cached.is_fresh:
                return CSVPayload(cached.value, "hit", self._iso(cached.stored_at))
            last_error: Exception | None = None
            variants = [cleaned]
            if "csv" in cleaned:
                variants.extend([{**cleaned, "csv": 1}, {**cleaned, "csv": "True"}])
            for attempt, variant in enumerate(variants):
                try:
                    response = await self.client.get(url, params=variant)
                    response.raise_for_status()
                    rows = _parse_leaderboard_text(response.text)
                    entry = self.cache.set(key, rows, ttl, max(ttl + 60, self.settings.stale_ttl_seconds))
                    return CSVPayload(rows, "miss", self._iso(entry.stored_at))
                except (httpx.HTTPError, UnicodeError, csv.Error, ValueError, json.JSONDecodeError) as exc:
                    last_error = exc
                    if attempt + 1 < len(variants):
                        await asyncio.sleep(0.35 * (attempt + 1))
            if cached and cached.can_serve_stale:
                return CSVPayload(cached.value, "stale", self._iso(cached.stored_at))
            raise StatcastUpstreamError("Baseball Savant leaderboard is temporarily unavailable") from last_error

    async def _get_json(
        self,
        path: str,
        params: dict[str, Any],
        *,
        ttl_seconds: int | None = None,
    ) -> JSONPayload:
        cleaned = {key: value for key, value in params.items() if value is not None}
        base = self.settings.mlb_api_base.rstrip("/")
        url = path if path.startswith("http") else f"{base}/{path.lstrip('/')}"
        key = f"json:{url}?{urlencode(sorted((str(k), str(v)) for k, v in cleaned.items()))}"
        ttl = ttl_seconds or self.settings.advanced_cache_ttl_seconds
        cached = self.cache.get(key)
        if cached and cached.is_fresh:
            return JSONPayload(cached.value, "hit", self._iso(cached.stored_at))
        async with self.cache.lock(key):
            cached = self.cache.get(key)
            if cached and cached.is_fresh:
                return JSONPayload(cached.value, "hit", self._iso(cached.stored_at))
            try:
                response = await self.client.get(url, params=cleaned, headers={"Accept": "application/json"})
                response.raise_for_status()
                data = response.json()
                if not isinstance(data, dict):
                    raise ValueError("MLB StatsAPI did not return an object")
                entry = self.cache.set(
                    key,
                    data,
                    ttl,
                    max(ttl + 60, self.settings.stale_ttl_seconds),
                )
                return JSONPayload(data, "miss", self._iso(entry.stored_at))
            except (httpx.HTTPError, UnicodeError, ValueError) as exc:
                if cached and cached.can_serve_stale:
                    return JSONPayload(cached.value, "stale", self._iso(cached.stored_at))
                raise StatcastUpstreamError("MLB expected-statistics data is temporarily unavailable") from exc

    @staticmethod
    def _merge_metric(
        merged: dict[int, dict[str, Any]],
        parsed: dict[str, Any] | None,
        source: str,
        cache_status: str,
        fetched_at: str,
    ) -> bool:
        if not parsed:
            return False
        player_id = int(parsed["player_id"])
        current = merged.setdefault(player_id, {"player_id": player_id})
        for key, value in parsed.items():
            if value not in (None, ""):
                current[key] = value
        source_list = list(current.get("sources") or [])
        if source not in source_list:
            source_list.append(source)
        current["sources"] = source_list
        current["cache"] = cache_status
        current["updated_at"] = fetched_at
        return True

    async def _statsapi_leaderboard(self, season: int, player_type: str) -> dict[int, dict[str, Any]]:
        group = "pitching" if player_type == "pitcher" else "hitting"
        attempts = [
            ("mlb_expected_statistics", "expectedStatistics"),
            ("mlb_season_advanced", "seasonAdvanced"),
        ]
        merged: dict[int, dict[str, Any]] = {}
        for source, stat_name in attempts:
            try:
                payload = await self._get_json(
                    "/stats",
                    {
                        "stats": stat_name,
                        "group": group,
                        "season": season,
                        "sportIds": 1,
                        "limit": 2500,
                    },
                )
            except StatcastUpstreamError:
                continue
            for split, stat_type in _statsapi_splits(payload.data):
                self._merge_metric(
                    merged,
                    _statsapi_metric_row(split, stat_type or stat_name),
                    source,
                    payload.cache_status,
                    payload.fetched_at,
                )
        return merged

    async def _statsapi_player_metrics(
        self,
        player_id: int,
        season: int,
        player_type: str,
    ) -> dict[str, Any] | None:
        group = "pitching" if player_type == "pitcher" else "hitting"
        merged: dict[int, dict[str, Any]] = {}
        for source, stat_name in (
            ("mlb_expected_statistics_player", "expectedStatistics"),
            ("mlb_season_advanced_player", "seasonAdvanced"),
        ):
            try:
                payload = await self._get_json(
                    f"/people/{int(player_id)}/stats",
                    {"stats": stat_name, "group": group, "season": season},
                )
            except StatcastUpstreamError:
                continue
            for split, stat_type in _statsapi_splits(payload.data):
                parsed = _statsapi_metric_row(
                    split, stat_type or stat_name, fallback_player_id=int(player_id)
                )
                self._merge_metric(
                    merged,
                    parsed,
                    source,
                    payload.cache_status,
                    payload.fetched_at,
                )
        item = merged.get(int(player_id))
        if item:
            item["available"] = any(
                item.get(field) is not None
                for field in ("xera", "xwoba", "hard_hit_pct", "barrel_pct", "xba", "xslg")
            )
        return item if item and item.get("available") else None

    async def _leaderboard(self, season: int, player_type: str) -> dict[int, dict[str, Any]]:
        cache_key = f"leaderboard:v164:{player_type}:{season}"
        cached = self.cache.get(cache_key)
        if cached and cached.is_fresh:
            return cached.value
        expected_params = {
            "type": player_type, "year": season, "position": "", "team": "",
            "filterType": "pa", "min": 1, "csv": "true",
        }
        custom_params = {
            "year": season, "type": player_type, "filter": "", "sort": "xwoba",
            "sortDir": "desc", "min": 1,
            "selections": "pa,woba,xwoba,xba,xslg,barrel_batted_rate,hard_hit_percent",
            "chart": "false", "chartType": "beeswarm", "x": "pa", "y": "pa",
            "r": "no", "csv": "true",
        }
        contact_params = {
            "type": player_type, "year": season, "position": "", "team": "",
            "min": 1, "csv": "true",
        }
        attempts = [
            ("savant_expected_statistics", "/leaderboard/expected_statistics", expected_params),
            ("savant_custom_contact", "/leaderboard/custom", custom_params),
            ("savant_statcast_contact", "/leaderboard/statcast", contact_params),
        ]
        merged: dict[int, dict[str, Any]] = {}
        errors: list[str] = []
        for source, path, params in attempts:
            try:
                payload = await self._get_csv(path, params)
            except StatcastUpstreamError as exc:
                cause = type(exc.__cause__).__name__ if exc.__cause__ else type(exc).__name__
                errors.append(f"{source}:{cause}")
                continue
            source_rows = 0
            for raw in payload.rows:
                parsed = _metric_row(raw)
                if not parsed:
                    continue
                source_rows += 1
                self._merge_metric(merged, parsed, source, payload.cache_status, payload.fetched_at)
            if source_rows == 0:
                errors.append(f"{source}:no_parseable_rows")
        usable: dict[int, dict[str, Any]] = {}
        for player_id, item in merged.items():
            item["available"] = any(item.get(field) is not None for field in (
                "xera", "xwoba", "hard_hit_pct", "barrel_pct", "xba", "xslg"
            ))
            if item["available"]:
                usable[player_id] = item
        self.cache.set(cache_key, usable, self.settings.advanced_cache_ttl_seconds if usable else 120,
                       max(600, self.settings.stale_ttl_seconds))
        self.cache.set(f"leaderboard-status:{player_type}:{season}", {
            "ok": bool(usable), "players": len(usable),
            "sources": sorted({source for row in usable.values() for source in (row.get("sources") or [])}),
            "errors": errors,
        }, 300, 900)
        return usable

    async def diagnostics(self, season: int) -> dict[str, Any]:
        results = await asyncio.gather(self._leaderboard(season, "pitcher"),
                                       self._leaderboard(season, "batter"), return_exceptions=True)
        payload: dict[str, Any] = {"season": season, "ok": True}
        for player_type, result in zip(("pitcher", "batter"), results):
            status_entry = self.cache.get(f"leaderboard-status:{player_type}:{season}")
            status = dict(status_entry.value) if status_entry else {}
            if isinstance(result, Exception):
                status.update({"ok": False, "players": 0, "error": type(result).__name__})
            else:
                status.setdefault("ok", bool(result))
                status.setdefault("players", len(result))
                sample = next(iter(result.values()), None)
                if sample:
                    status["sample"] = {key: sample.get(key) for key in (
                        "player_id", "player_name", "xera", "xwoba", "hard_hit_pct", "barrel_pct"
                    ) if sample.get(key) is not None}
            payload[player_type] = status
            payload["ok"] = payload["ok"] and bool(status.get("ok"))
        return payload

    async def pitcher_metrics(self, player_id: int | None, season: int) -> dict[str, Any] | None:
        if not player_id:
            return None
        try:
            board = await self._leaderboard(season, "pitcher")
        except StatcastUpstreamError:
            board = {}
        item = board.get(int(player_id))
        if not item:
            item = await self._statsapi_player_metrics(int(player_id), season, "pitcher")
        return {**item, "available": True} if item else None

    async def batter_metrics(
        self,
        player_ids: Iterable[int],
        season: int,
    ) -> dict[int, dict[str, Any]]:
        ids = {int(player_id) for player_id in player_ids if player_id}
        if not ids:
            return {}
        try:
            board = await self._leaderboard(season, "batter")
        except StatcastUpstreamError:
            board = {}
        found = {player_id: board[player_id] for player_id in ids if player_id in board}
        # Global leaderboards can omit players below a minimum sample. Query
        # only the missing projected/official lineup players as a fallback.
        missing = sorted(ids - set(found))[:18]
        if missing:
            import asyncio

            semaphore = asyncio.Semaphore(6)

            async def load_one(player_id: int):
                async with semaphore:
                    return await self._statsapi_player_metrics(player_id, season, "batter")

            rows = await asyncio.gather(
                *(load_one(player_id) for player_id in missing),
                return_exceptions=True,
            )
            for player_id, row in zip(missing, rows):
                if isinstance(row, dict) and row.get("available"):
                    found[player_id] = row
        return found
