from __future__ import annotations

import csv
import io
import re
import time
from dataclasses import dataclass
from typing import Any, Iterable
from urllib.parse import urlencode

import httpx

from .cache import AsyncTTLCache
from .config import Settings


class StatcastUpstreamError(RuntimeError):
    pass


@dataclass
class CSVPayload:
    rows: list[dict[str, str]]
    cache_status: str
    fetched_at: str


def _number(value: Any) -> float | None:
    if value is None:
        return None
    text = str(value).strip().replace("%", "")
    if not text or text.lower() in {"nan", "none", "null", "--", "-"}:
        return None
    try:
        return float(text)
    except (TypeError, ValueError):
        return None


def _int(value: Any) -> int | None:
    try:
        return int(float(str(value).strip()))
    except (TypeError, ValueError):
        return None


def _key(value: str) -> str:
    text = (
        value.strip()
        .lower()
        .replace("%", " percent ")
        .replace("+", " plus ")
        .replace("/", " ")
        .replace("-", " ")
        .replace(".", " ")
        .replace(",", " ")
    )
    return re.sub(r"_+", "_", re.sub(r"[^a-z0-9]+", "_", text)).strip("_")


def _normalized_row(row: dict[str, Any]) -> dict[str, Any]:
    return {_key(str(key)): value for key, value in row.items() if key is not None}


def _first(row: dict[str, Any], aliases: Iterable[str]) -> Any:
    for alias in aliases:
        key = _key(alias)
        if key in row and row[key] not in (None, ""):
            return row[key]
    return None


def _percent(value: Any) -> float | None:
    number = _number(value)
    if number is None:
        return None
    # Savant CSVs sometimes return .425 and sometimes 42.5.
    if abs(number) <= 1.5:
        number *= 100.0
    return round(number, 1)


def _rate(value: Any) -> float | None:
    number = _number(value)
    if number is None:
        return None
    if number > 1.5:
        number /= 100.0
    return round(number, 4)


def _metric_row(row: dict[str, Any]) -> dict[str, Any] | None:
    normalized = _normalized_row(row)
    player_id = _int(
        _first(
            normalized,
            (
                "player_id",
                "playerid",
                "id",
                "mlbam_id",
                "mlb_id",
                "player_id_1",
                "player",
                "batter",
                "pitcher",
            ),
        )
    )
    if player_id is None:
        return None
    name = _first(
        normalized,
        ("player_name", "last_name_first_name", "name", "last_name_comma_first_name"),
    )
    return {
        "player_id": player_id,
        "player_name": str(name or ""),
        "pa": _number(_first(normalized, ("pa", "plate_appearances", "bf", "batters_faced", "bip", "batted_ball_events"))),
        "xwoba": _rate(_first(normalized, ("xwoba", "est_woba", "estimated_woba_using_speedangle"))),
        "woba": _rate(_first(normalized, ("woba",))),
        "xera": _number(_first(normalized, ("xera", "est_era", "estimated_era"))),
        "hard_hit_pct": _percent(
            _first(normalized, ("hard_hit_percent", "hard_hit_pct", "hardhit_percent"))
        ),
        "barrel_pct": _percent(
            _first(
                normalized,
                ("barrel_batted_rate", "barrel_percent", "barrel_pct", "barrels_per_bbe"),
            )
        ),
        "xba": _rate(_first(normalized, ("xba", "est_ba"))),
        "xslg": _rate(_first(normalized, ("xslg", "est_slg"))),
    }


def aggregate_metrics(metrics: Iterable[dict[str, Any]]) -> dict[str, Any]:
    rows = [row for row in metrics if row]
    if not rows:
        return {
            "available": False,
            "players": 0,
            "coverage_pa": 0.0,
            "xwoba": None,
            "hard_hit_pct": None,
            "barrel_pct": None,
            "xba": None,
            "xslg": None,
        }

    def weighted(field: str) -> float | None:
        pairs = []
        for row in rows:
            value = _number(row.get(field))
            if value is None:
                continue
            weight = max(1.0, _number(row.get("pa")) or 1.0)
            pairs.append((value, weight))
        if not pairs:
            return None
        return sum(value * weight for value, weight in pairs) / sum(weight for _, weight in pairs)

    xwoba = weighted("xwoba")
    hard_hit = weighted("hard_hit_pct")
    barrel = weighted("barrel_pct")
    xba = weighted("xba")
    xslg = weighted("xslg")
    sources = sorted(
        {
            str(source)
            for row in rows
            for source in ([row.get("source")] if row.get("source") else (row.get("sources") or []))
            if source
        }
    )
    updated_values = sorted(str(row.get("updated_at")) for row in rows if row.get("updated_at"))
    return {
        "available": any(value is not None for value in (xwoba, hard_hit, barrel, xba, xslg)),
        "players": len(rows),
        "coverage_pa": round(sum(max(0.0, _number(row.get("pa")) or 0.0) for row in rows), 1),
        "xwoba": round(xwoba, 4) if xwoba is not None else None,
        "hard_hit_pct": round(hard_hit, 1) if hard_hit is not None else None,
        "barrel_pct": round(barrel, 1) if barrel is not None else None,
        "xba": round(xba, 4) if xba is not None else None,
        "xslg": round(xslg, 4) if xslg is not None else None,
        "sources": sources,
        "updated_at": updated_values[-1] if updated_values else None,
    }


class StatcastService:
    """Small, cached Baseball Savant adapter.

    Baseball Savant exposes CSV downloads from its expected-statistics and
    custom-leaderboard pages. This adapter deliberately accepts multiple
    column aliases because MLB occasionally changes display labels while the
    underlying metrics remain the same.
    """

    def __init__(
        self,
        settings: Settings,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self.settings = settings
        self.cache = AsyncTTLCache()
        self.client = httpx.AsyncClient(
            timeout=max(settings.request_timeout_seconds, 18.0),
            follow_redirects=True,
            trust_env=False,
            transport=transport,
            headers={
                "User-Agent": "DiamondMind/2.0 (+https://gigia1127520-gif.github.io/diamondmind-web/)",
                "Accept": "text/csv,text/plain,*/*",
                "Accept-Language": "en-US,en;q=0.9",
                "Referer": "https://baseballsavant.mlb.com/leaderboard/custom",
            },
        )

    async def aclose(self) -> None:
        await self.client.aclose()

    @staticmethod
    def _iso(timestamp: float) -> str:
        from datetime import datetime, timezone

        return datetime.fromtimestamp(timestamp, tz=timezone.utc).isoformat().replace("+00:00", "Z")

    async def _get_csv(
        self,
        path: str,
        params: dict[str, Any],
        *,
        ttl_seconds: int | None = None,
    ) -> CSVPayload:
        cleaned = {key: value for key, value in params.items() if value is not None}
        url = f"{self.settings.savant_base.rstrip('/')}/{path.lstrip('/')}"
        key = f"csv:{url}?{urlencode(sorted((str(k), str(v)) for k, v in cleaned.items()))}"
        ttl = ttl_seconds or self.settings.advanced_cache_ttl_seconds
        cached = self.cache.get(key)
        if cached and cached.is_fresh:
            return CSVPayload(cached.value, "hit", self._iso(cached.stored_at))

        async with self.cache.lock(key):
            cached = self.cache.get(key)
            if cached and cached.is_fresh:
                return CSVPayload(cached.value, "hit", self._iso(cached.stored_at))
            try:
                response = await self.client.get(url, params=cleaned)
                response.raise_for_status()
                text = response.text.lstrip("\ufeff").strip()
                if not text or "<html" in text[:200].lower():
                    raise ValueError("Savant did not return CSV")
                sample = text[:4096]
                try:
                    dialect = csv.Sniffer().sniff(sample, delimiters=",\t;")
                except csv.Error:
                    dialect = csv.excel
                rows = list(csv.DictReader(io.StringIO(text), dialect=dialect))
                if not rows or not any(any(str(value or "").strip() for value in row.values()) for row in rows):
                    raise ValueError("Savant returned an empty CSV")
                entry = self.cache.set(
                    key,
                    rows,
                    ttl,
                    max(ttl + 60, self.settings.stale_ttl_seconds),
                )
                return CSVPayload(rows, "miss", self._iso(entry.stored_at))
            except (httpx.HTTPError, UnicodeError, csv.Error, ValueError) as exc:
                if cached and cached.can_serve_stale:
                    return CSVPayload(cached.value, "stale", self._iso(cached.stored_at))
                raise StatcastUpstreamError("Baseball Savant data is temporarily unavailable") from exc

    async def _leaderboard(self, season: int, player_type: str) -> dict[int, dict[str, Any]]:
        cache_key = f"leaderboard:v162:{player_type}:{season}"
        cached = self.cache.get(cache_key)
        if cached and cached.is_fresh:
            return cached.value

        expected_params = {
            "type": player_type,
            "year": season,
            "position": "",
            "team": "",
            "min": 1,
            "csv": "true",
        }
        selections = "pa,woba,xwoba,xba,xslg,barrel_batted_rate,hard_hit_percent"
        custom_params = {
            "year": season,
            "type": player_type,
            "filter": "",
            "sort": 4,
            "sortDir": "asc",
            "min": 1,
            "selections": selections,
            "chart": "false",
            "chartType": "beeswarm",
            "x": "pa",
            "y": "pa",
            "r": "no",
            "csv": "true",
        }
        statcast_params = {
            "type": player_type,
            "year": season,
            "position": "",
            "team": "",
            "min": 1,
            "sort": "barrels_per_pa",
            "sortDir": "desc",
            "csv": "true",
        }
        attempts: list[tuple[str, str, dict[str, Any]]] = [
            ("expected_statistics", "/leaderboard/expected_statistics", expected_params),
            ("custom_leaderboard", "/leaderboard/custom", custom_params),
            ("custom_leaderboard_csv_1", "/leaderboard/custom", {**custom_params, "csv": 1}),
            ("statcast_leaderboard", "/leaderboard/statcast", statcast_params),
        ]

        merged: dict[int, dict[str, Any]] = {}
        successful_sources: list[str] = []
        last_error: Exception | None = None
        for source, path, params in attempts:
            try:
                payload = await self._get_csv(path, params)
            except StatcastUpstreamError as exc:
                last_error = exc
                continue
            source_rows = 0
            for raw in payload.rows:
                parsed = _metric_row(raw)
                if not parsed:
                    continue
                source_rows += 1
                player_id = int(parsed["player_id"])
                current = merged.setdefault(player_id, {"player_id": player_id})
                for key, value in parsed.items():
                    if value not in (None, ""):
                        current[key] = value
                source_list = list(current.get("sources") or [])
                if source not in source_list:
                    source_list.append(source)
                current["sources"] = source_list
                current["cache"] = payload.cache_status
                current["updated_at"] = payload.fetched_at
            if source_rows:
                successful_sources.append(source)

        if merged:
            for item in merged.values():
                item["available"] = any(
                    item.get(field) is not None
                    for field in ("xera", "xwoba", "hard_hit_pct", "barrel_pct", "xba", "xslg")
                )
            self.cache.set(
                cache_key,
                merged,
                self.settings.advanced_cache_ttl_seconds,
                max(self.settings.advanced_cache_ttl_seconds + 60, self.settings.stale_ttl_seconds),
            )
            return merged

        self.cache.set(cache_key, {}, 180, max(600, self.settings.stale_ttl_seconds))
        if last_error:
            raise StatcastUpstreamError("Baseball Savant leaderboard is temporarily unavailable") from last_error
        return {}

    async def pitcher_metrics(self, player_id: int | None, season: int) -> dict[str, Any] | None:
        if not player_id:
            return None
        try:
            board = await self._leaderboard(season, "pitcher")
        except StatcastUpstreamError:
            return None
        item = board.get(int(player_id))
        return {**item, "available": True} if item else None

    async def batter_metrics(
        self,
        player_ids: Iterable[int],
        season: int,
    ) -> dict[int, dict[str, Any]]:
        ids = {int(player_id) for player_id in player_ids if player_id}
        if not ids:
            return {}
        try:
            board = await self._leaderboard(season, "batter")
        except StatcastUpstreamError:
            return {}
        return {player_id: board[player_id] for player_id in ids if player_id in board}
