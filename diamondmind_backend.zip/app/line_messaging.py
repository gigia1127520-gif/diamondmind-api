from __future__ import annotations

import asyncio
from dataclasses import dataclass
from typing import Any
from uuid import NAMESPACE_URL, uuid5

import httpx

from .config import Settings


class LineMessagingError(RuntimeError):
    """Raised when LINE Messaging API rejects or cannot accept a broadcast."""


@dataclass(frozen=True)
class LineBroadcastResult:
    status: str
    retry_key: str
    request_id: str | None
    accepted_request_id: str | None = None
    attempts: int = 1

    def as_dict(self) -> dict[str, Any]:
        return {
            "status": self.status,
            "retry_key": self.retry_key,
            "request_id": self.request_id,
            "accepted_request_id": self.accepted_request_id,
            "attempts": self.attempts,
        }


class LineMessagingService:
    """Small, idempotent LINE broadcast client.

    Every event receives a deterministic X-Line-Retry-Key. LINE accepts the
    request only once within the retry-key validity window, so a timeout, a
    Render restart, or a lost Supabase marker cannot create duplicate pushes.
    """

    def __init__(
        self,
        settings: Settings,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self.settings = settings
        self.enabled = settings.line_messaging_enabled
        self.client = httpx.AsyncClient(
            base_url=settings.line_api_base,
            timeout=httpx.Timeout(
                settings.line_request_timeout_seconds,
                connect=min(settings.line_request_timeout_seconds, 10.0),
            ),
            follow_redirects=True,
            trust_env=False,
            transport=transport,
        )

    async def aclose(self) -> None:
        await self.client.aclose()

    def status(self) -> dict[str, Any]:
        return {
            "enabled": bool(self.enabled),
            "configured": bool(self.settings.line_channel_access_token),
            "community_url_configured": bool(self.settings.line_community_url),
            "frontend_url": self.settings.frontend_base_url,
            "broadcast_endpoint": "/v2/bot/message/broadcast",
            "max_events_per_sync": self.settings.line_max_events_per_sync,
            "retry_lookback_days": self.settings.line_retry_lookback_days,
            "notification_max_age_hours": self.settings.line_notification_max_age_hours,
        }

    @staticmethod
    def retry_key(event_key: str) -> str:
        return str(uuid5(NAMESPACE_URL, f"diamondmind-line:{event_key}"))

    @staticmethod
    def _message_objects(text: str) -> list[dict[str, str]]:
        clean = str(text or "").strip()
        if not clean:
            raise LineMessagingError("LINE broadcast message is empty")
        # LINE text messages allow up to 5,000 characters. Keep a small safety
        # margin for future wording changes and avoid silently emitting an
        # invalid payload.
        if len(clean) > 4900:
            clean = clean[:4880].rstrip() + "\n…"
        return [{"type": "text", "text": clean}]

    async def broadcast_text(self, text: str, *, event_key: str) -> dict[str, Any]:
        if not self.enabled:
            raise LineMessagingError("LINE Messaging API is not configured")

        retry_key = self.retry_key(event_key)
        headers = {
            "Authorization": f"Bearer {self.settings.line_channel_access_token}",
            "Content-Type": "application/json",
            "X-Line-Retry-Key": retry_key,
        }
        payload = {"messages": self._message_objects(text)}
        retries = max(0, int(self.settings.line_request_retries))
        transient_statuses = {500, 502, 503, 504}
        last_error: Exception | None = None

        for attempt in range(retries + 1):
            try:
                response = await self.client.post(
                    "/v2/bot/message/broadcast",
                    headers=headers,
                    json=payload,
                )
                request_id = response.headers.get("x-line-request-id")
                accepted_request_id = response.headers.get("x-line-accepted-request-id")
                if 200 <= response.status_code < 300:
                    return LineBroadcastResult(
                        status="sent",
                        retry_key=retry_key,
                        request_id=request_id,
                        attempts=attempt + 1,
                    ).as_dict()
                if response.status_code == 409 and accepted_request_id:
                    # The same retry key was already accepted. This is a
                    # successful idempotent recovery, not a delivery failure.
                    return LineBroadcastResult(
                        status="already_accepted",
                        retry_key=retry_key,
                        request_id=request_id,
                        accepted_request_id=accepted_request_id,
                        attempts=attempt + 1,
                    ).as_dict()
                if response.status_code in transient_statuses and attempt < retries:
                    await asyncio.sleep(
                        self.settings.line_retry_backoff_seconds * (2 ** attempt)
                    )
                    continue
                detail = ""
                try:
                    body = response.json()
                    detail = str(body.get("message") or body)[:300]
                except ValueError:
                    detail = response.text[:300]
                raise LineMessagingError(
                    f"LINE broadcast rejected (HTTP {response.status_code}): {detail or 'unknown error'}"
                )
            except httpx.TransportError as exc:
                last_error = exc
                if attempt < retries:
                    await asyncio.sleep(
                        self.settings.line_retry_backoff_seconds * (2 ** attempt)
                    )
                    continue
                raise LineMessagingError(
                    f"LINE broadcast network failure: {type(exc).__name__}"
                ) from exc

        raise LineMessagingError(
            f"LINE broadcast failed: {type(last_error).__name__ if last_error else 'unknown'}"
        )
