from __future__ import annotations

import asyncio
import hashlib
import hmac
import io
import json
import math
import random
import shutil
import subprocess
import tempfile
import textwrap
import threading
import urllib.error
import urllib.request
from dataclasses import dataclass
from datetime import datetime, timezone
from functools import lru_cache
from pathlib import Path
from typing import Any
from urllib.parse import urlencode

import httpx
from PIL import Image, ImageDraw, ImageFilter, ImageFont


TERMINAL_STATUSES = {"won", "lost", "push", "void"}
ASSET_SOURCES = {"free", "pro"}
ASSET_PHASES = {"pregame", "teaser", "result"}
ASSET_SIZES = {"feed", "story"}


TEAM_ZH = {
    "Arizona Diamondbacks": "亞利桑那響尾蛇",
    "Atlanta Braves": "亞特蘭大勇士",
    "Baltimore Orioles": "巴爾的摩金鶯",
    "Boston Red Sox": "波士頓紅襪",
    "Chicago Cubs": "芝加哥小熊",
    "Chicago White Sox": "芝加哥白襪",
    "Cincinnati Reds": "辛辛那提紅人",
    "Cleveland Guardians": "克里夫蘭守護者",
    "Colorado Rockies": "科羅拉多洛磯",
    "Detroit Tigers": "底特律老虎",
    "Houston Astros": "休士頓太空人",
    "Kansas City Royals": "堪薩斯市皇家",
    "Los Angeles Angels": "洛杉磯天使",
    "Los Angeles Dodgers": "洛杉磯道奇",
    "Miami Marlins": "邁阿密馬林魚",
    "Milwaukee Brewers": "密爾瓦基釀酒人",
    "Minnesota Twins": "明尼蘇達雙城",
    "New York Mets": "紐約大都會",
    "New York Yankees": "紐約洋基",
    "Athletics": "運動家",
    "Oakland Athletics": "奧克蘭運動家",
    "Philadelphia Phillies": "費城費城人",
    "Pittsburgh Pirates": "匹茲堡海盜",
    "San Diego Padres": "聖地牙哥教士",
    "San Francisco Giants": "舊金山巨人",
    "Seattle Mariners": "西雅圖水手",
    "St. Louis Cardinals": "聖路易紅雀",
    "Tampa Bay Rays": "坦帕灣光芒",
    "Texas Rangers": "德州遊騎兵",
    "Toronto Blue Jays": "多倫多藍鳥",
    "Washington Nationals": "華盛頓國民",
    "Tokyo Yakult Swallows": "東京養樂多燕子",
    "Yomiuri Giants": "讀賣巨人",
    "YOKOHAMA DeNA BAYSTARS": "橫濱DeNA海灣之星",
    "Yokohama DeNA BayStars": "橫濱DeNA海灣之星",
    "Chunichi Dragons": "中日龍",
    "Hanshin Tigers": "阪神虎",
    "Hiroshima Toyo Carp": "廣島東洋鯉魚",
    "Fukuoka SoftBank Hawks": "福岡軟銀鷹",
    "Hokkaido Nippon-Ham Fighters": "北海道日本火腿鬥士",
    "ORIX Buffaloes": "歐力士猛牛",
    "Orix Buffaloes": "歐力士猛牛",
    "Tohoku Rakuten Golden Eagles": "東北樂天金鷲",
    "Saitama Seibu Lions": "埼玉西武獅",
    "Chiba Lotte Marines": "千葉羅德海洋",
    "American League All-Stars": "美聯明星隊",
    "National League All-Stars": "國聯明星隊",
    "Central League All-Stars": "中央聯盟明星隊",
    "Pacific League All-Stars": "太平洋聯盟明星隊",
}

TEAM_ZH_BY_ABBR = {
    "ARI": "亞利桑那響尾蛇", "ATL": "亞特蘭大勇士", "BAL": "巴爾的摩金鶯",
    "BOS": "波士頓紅襪", "CHC": "芝加哥小熊", "CWS": "芝加哥白襪",
    "CIN": "辛辛那提紅人", "CLE": "克里夫蘭守護者", "COL": "科羅拉多洛磯",
    "DET": "底特律老虎", "HOU": "休士頓太空人", "KC": "堪薩斯市皇家",
    "KCR": "堪薩斯市皇家", "LAA": "洛杉磯天使", "LAD": "洛杉磯道奇",
    "MIA": "邁阿密馬林魚", "MIL": "密爾瓦基釀酒人", "MIN": "明尼蘇達雙城",
    "NYM": "紐約大都會", "NYY": "紐約洋基", "ATH": "運動家", "OAK": "奧克蘭運動家",
    "PHI": "費城費城人", "PIT": "匹茲堡海盜", "SD": "聖地牙哥教士",
    "SDP": "聖地牙哥教士", "SF": "舊金山巨人", "SFG": "舊金山巨人",
    "SEA": "西雅圖水手", "STL": "聖路易紅雀", "TB": "坦帕灣光芒",
    "TBR": "坦帕灣光芒", "TEX": "德州遊騎兵", "TOR": "多倫多藍鳥",
    "WSH": "華盛頓國民", "WSN": "華盛頓國民", "AL": "美聯明星隊",
    "NL": "國聯明星隊", "S": "東京養樂多燕子", "G": "讀賣巨人",
    "DB": "橫濱DeNA海灣之星", "D": "中日龍", "T": "阪神虎",
    "C": "廣島東洋鯉魚", "H": "福岡軟銀鷹", "F": "北海道日本火腿鬥士",
    "B": "歐力士猛牛", "E": "東北樂天金鷲", "L": "埼玉西武獅",
    "M": "千葉羅德海洋", "CL": "中央聯盟明星隊", "PL": "太平洋聯盟明星隊",
}


class SocialPublishingError(RuntimeError):
    pass


@dataclass(frozen=True)
class SocialAssetSpec:
    source: str
    phase: str
    size: str
    recommendation_date: str
    league: str
    page: int = 1

    def validated(self) -> "SocialAssetSpec":
        source = self.source.lower()
        phase = self.phase.lower()
        size = self.size.lower()
        league = self.league.upper()
        try:
            page = int(self.page)
        except (TypeError, ValueError) as exc:
            raise ValueError("Unsupported social asset page") from exc
        if source not in ASSET_SOURCES:
            raise ValueError("Unsupported social asset source")
        if phase not in ASSET_PHASES:
            raise ValueError("Unsupported social asset phase")
        if size not in ASSET_SIZES:
            raise ValueError("Unsupported social asset size")
        if league not in {"MLB", "NPB", "ALL"}:
            raise ValueError("Unsupported social asset league")
        if page < 1 or page > 99:
            raise ValueError("Unsupported social asset page")
        datetime.strptime(self.recommendation_date, "%Y-%m-%d")
        return SocialAssetSpec(source, phase, size, self.recommendation_date, league, page)

    @property
    def signing_value(self) -> str:
        item = self.validated()
        return "|".join(
            (
                item.source,
                item.phase,
                item.size,
                item.recommendation_date,
                item.league,
                str(item.page),
            )
        )


@dataclass(frozen=True)
class SocialReelSpec:
    recommendation_date: str
    league: str

    def validated(self) -> "SocialReelSpec":
        league = str(self.league or "").upper()
        if league not in {"MLB", "NPB"}:
            raise ValueError("Unsupported social reel league")
        datetime.strptime(self.recommendation_date, "%Y-%m-%d")
        return SocialReelSpec(self.recommendation_date, league)

    @property
    def signing_value(self) -> str:
        item = self.validated()
        return f"reel|{item.recommendation_date}|{item.league}"


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def display_team(value: Any, abbr: Any = None) -> str:
    name = str(value or "").strip()
    short = str(abbr or "").strip().upper()
    return TEAM_ZH.get(name) or TEAM_ZH_BY_ABBR.get(short) or TEAM_ZH_BY_ABBR.get(name.upper()) or name or short or "待確認"


def decimal_price(value: Any) -> float | None:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    if 1.0 < number < 20.0:
        return round(number, 2)
    if number >= 100:
        return round(1.0 + number / 100.0, 2)
    if number <= -100:
        return round(1.0 + 100.0 / abs(number), 2)
    return None


def status_label(value: Any) -> str:
    return {
        "won": "命中",
        "lost": "未中",
        "push": "走水",
        "void": "作廢",
        "pending": "等待賽果",
        "live": "比賽進行中",
    }.get(str(value or "pending").lower(), "等待賽果")


def result_icon(value: Any) -> str:
    return {"won": "✓", "lost": "×", "push": "—", "void": "—"}.get(str(value or "").lower(), "•")


def normalize_market_label(value: Any) -> str:
    return {
        "moneyline": "獨贏",
        "moneylines": "獨贏",
        "run_line": "讓分",
        "run_lines": "讓分",
        "totals": "大小分",
        "two_leg": "二關串關",
        "three_leg": "三關串關",
    }.get(str(value or "").lower(), str(value or "推薦方向"))


def compact_pick_label(payload: dict[str, Any]) -> str:
    raw = str(payload.get("pick_label") or "").strip()
    market = str(payload.get("market") or "").lower()
    team = display_team(payload.get("pick_team_name"), payload.get("pick_team_abbr"))
    line = payload.get("line")
    side = str(payload.get("side") or "").lower()
    if market in {"moneyline", "moneylines"} and team != "待確認":
        return f"{team} 獨贏"
    if market in {"run_line", "run_lines"} and team != "待確認":
        suffix = ""
        try:
            number = float(line)
            suffix = f" {number:+g}"
        except (TypeError, ValueError):
            pass
        return f"{team}{suffix}"
    if market == "totals":
        direction = "大" if side == "over" else "小" if side == "under" else "大小分"
        try:
            return f"{direction} {float(line):g}"
        except (TypeError, ValueError):
            return direction
    return raw or normalize_market_label(market)


def event_key(source: str, phase: str, league: str, page: int = 1) -> str:
    base = f"{source.lower()}_{phase.lower()}_{league.upper()}"
    if source.lower() == "pro" and phase.lower() == "teaser":
        return f"{base}_p{max(1, int(page))}"
    return base


def _confidence_percent(value: Any) -> float | None:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    if 0 <= number <= 1:
        number *= 100
    return max(0.0, min(100.0, number))


def social_caption(spec: SocialAssetSpec, payload: dict[str, Any], website: str) -> str:
    spec = spec.validated()
    date_text = spec.recommendation_date.replace("-", "/")
    league = "MLB＋NPB" if spec.league == "ALL" else spec.league
    tags = "#DiamondMind #棒球分析 #AI預測"
    if spec.league == "MLB":
        tags += " #MLB"
    elif spec.league == "NPB":
        tags += " #NPB #日本職棒"
    else:
        tags += " #MLB #NPB"

    if spec.source == "free" and spec.phase == "pregame":
        matchup = str(payload.get("matchup") or "今日賽事")
        pick = compact_pick_label(payload)
        confidence = _confidence_percent(payload.get("confidence"))
        confidence_text = f"\nAI 信心：{confidence:.1f}%" if confidence is not None else ""
        return (
            f"⚾ {date_text}｜{league} 每日免費推薦\n\n"
            f"{matchup}\n推薦方向：{pick}{confidence_text}\n\n"
            f"更多數據與公開紀錄：{website}\n\n{tags} #每日免費推薦"
        )

    if spec.source == "pro" and spec.phase == "teaser":
        page = int(payload.get("page") or spec.page)
        total_pages = int(payload.get("total_pages") or 1)
        item_count = len(payload.get("items") or [])
        return (
            f"🔒 {date_text}｜{league} AI 推薦總覽（第 {page}/{total_pages} 組）\n\n"
            f"本篇收錄 {item_count} 場推薦賽事；公開貼文不顯示付費推薦方向。\n"
            f"Pro 會員登入後查看完整方向：{website}\n\n{tags} #DiamondMindPro"
        )

    if spec.source == "pro" and spec.phase == "result":
        totals = payload.get("overall") or payload.get("summary") or {}
        decided = int(totals.get("won") or 0) + int(totals.get("lost") or 0)
        hit_rate = (int(totals.get("won") or 0) / decided * 100.0) if decided else 0.0
        return (
            f"📊 {date_text}｜{league} 今日賽果 Reel\n\n"
            f"命中 {int(totals.get('won') or 0)}｜未中 {int(totals.get('lost') or 0)}｜"
            f"命中率 {hit_rate:.1f}%｜走水／作廢 {int(totals.get('neutral') or 0)}\n"
            f"前段免費場獨立呈現，Pro 賽果每 5 場一張；最後一張為今日總結。\n"
            f"完整紀錄：{website}\n\n{tags} #賽後戰績 #Reels"
        )

    status = str(payload.get("status") or "pending").lower()
    return (
        f"{result_icon(status)} {date_text}｜{league} 每日免費推薦賽果\n\n"
        f"{payload.get('matchup') or '今日賽事'}\n推薦方向：{compact_pick_label(payload)}\n"
        f"結果：{status_label(status)}\n\n{website}\n\n{tags} #賽果"
    )


class SocialCardRenderer:
    def __init__(
        self,
        font_path: str | None = None,
        logo_path: str | None = None,
        font_url: str | None = None,
        bold_font_path: str | None = None,
        bold_font_url: str | None = None,
    ):
        asset_dir = Path(__file__).resolve().parent / "assets"
        self.font_path = (
            Path(font_path).expanduser()
            if font_path
            else Path("/tmp/diamondmind-fonts/NotoSansCJKtc-Regular.otf")
        )
        self.font_url = str(font_url or "").strip()
        self.bold_font_path = (
            Path(bold_font_path).expanduser()
            if bold_font_path
            else Path("/tmp/diamondmind-fonts/NotoSansCJKtc-Bold.otf")
        )
        self.bold_font_url = str(bold_font_url or "").strip()
        self.logo_path = Path(logo_path).expanduser() if logo_path else asset_dir / "diamondmind-logo.png"
        self._logo: Image.Image | None = None
        self._font_download_lock = threading.Lock()

    def _download_font_if_needed(self, path: Path, url: str) -> Path | None:
        if path.exists():
            return path
        if not url:
            return None
        with self._font_download_lock:
            if path.exists():
                return path
            temporary = path.with_suffix(path.suffix + ".part")
            try:
                path.parent.mkdir(parents=True, exist_ok=True)
                request = urllib.request.Request(
                    url,
                    headers={"User-Agent": "DiamondMind/19.1.3 font-loader"},
                )
                with urllib.request.urlopen(request, timeout=45) as response, temporary.open("wb") as target:
                    shutil.copyfileobj(response, target, length=1024 * 1024)
                if temporary.stat().st_size < 500_000:
                    temporary.unlink(missing_ok=True)
                    return None
                temporary.replace(path)
                return path
            except (OSError, ValueError, urllib.error.URLError):
                temporary.unlink(missing_ok=True)
                return None

    @lru_cache(maxsize=256)
    def font(self, size: int, bold: bool = False) -> ImageFont.ImageFont:
        # V19.1.2: keep the real Bold face selected in V19.1.1. The previous renderer reused the
        # Regular OTF even when bold=True, which made IG cards look too thin.
        if bold:
            local_candidates = [
                self.bold_font_path if self.bold_font_path.exists() else None,
                Path("/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc"),
                Path("/usr/share/fonts/opentype/noto/NotoSansCJKtc-Bold.otf"),
                Path("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"),
                Path("/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf"),
            ]
            remote_font = None
            if not any(candidate and candidate.exists() for candidate in local_candidates):
                remote_font = self._download_font_if_needed(self.bold_font_path, self.bold_font_url)
            candidates = local_candidates + [remote_font]
        else:
            local_candidates = [
                self.font_path if self.font_path.exists() else None,
                Path("/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"),
                Path("/usr/share/fonts/opentype/noto/NotoSansCJKtc-Regular.otf"),
                Path("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"),
            ]
            remote_font = None
            if not any(candidate and candidate.exists() for candidate in local_candidates):
                remote_font = self._download_font_if_needed(self.font_path, self.font_url)
            candidates = local_candidates + [remote_font]

        for candidate in candidates:
            if not candidate or not candidate.exists():
                continue
            try:
                return ImageFont.truetype(str(candidate), size=size)
            except OSError:
                continue
        return ImageFont.load_default()

    def logo(self) -> Image.Image | None:
        if self._logo is None and self.logo_path.exists():
            try:
                self._logo = Image.open(self.logo_path).convert("RGBA")
            except OSError:
                self._logo = None
        return self._logo.copy() if self._logo is not None else None

    @staticmethod
    def _measure(draw: ImageDraw.ImageDraw, text: str, font: ImageFont.ImageFont) -> float:
        box = draw.textbbox((0, 0), text, font=font)
        return float(box[2] - box[0])

    def _fit_font(self, draw: ImageDraw.ImageDraw, text: str, width: int, preferred: int, minimum: int, bold: bool = False) -> ImageFont.ImageFont:
        for size in range(preferred, minimum - 1, -2):
            font = self.font(size, bold)
            if self._measure(draw, text, font) <= width:
                return font
        return self.font(minimum, bold)

    def _center_text(self, draw: ImageDraw.ImageDraw, y: int, text: str, font: ImageFont.ImageFont, fill: tuple[int, int, int, int] | str, width: int) -> None:
        box = draw.textbbox((0, 0), text, font=font)
        x = int((width - (box[2] - box[0])) / 2)
        draw.text((x, y), text, font=font, fill=fill)

    def _wrap(self, draw: ImageDraw.ImageDraw, text: str, font: ImageFont.ImageFont, width: int, max_lines: int = 2) -> list[str]:
        chars = list(str(text or ""))
        lines: list[str] = []
        current = ""
        for char in chars:
            candidate = current + char
            if current and self._measure(draw, candidate, font) > width:
                lines.append(current)
                current = char
                if len(lines) >= max_lines:
                    break
            else:
                current = candidate
        if len(lines) < max_lines and current:
            lines.append(current)
        if len(lines) == max_lines and "".join(lines) != str(text or ""):
            while lines[-1] and self._measure(draw, lines[-1] + "…", font) > width:
                lines[-1] = lines[-1][:-1]
            lines[-1] += "…"
        return lines

    def _background(self, width: int, height: int, seed: str) -> Image.Image:
        top = (2, 15, 23)
        bottom = (1, 6, 11)
        gradient = Image.new("RGB", (1, height))
        pixels = gradient.load()
        for y in range(height):
            ratio = y / max(1, height - 1)
            pixels[0, y] = tuple(int(top[i] * (1 - ratio) + bottom[i] * ratio) for i in range(3))
        image = gradient.resize((width, height)).convert("RGBA")
        glow = Image.new("RGBA", image.size, (0, 0, 0, 0))
        g = ImageDraw.Draw(glow)
        g.ellipse((width * 0.42, -height * 0.18, width * 1.22, height * 0.45), fill=(37, 244, 164, 72))
        g.ellipse((-width * 0.35, height * 0.58, width * 0.60, height * 1.22), fill=(0, 182, 255, 38))
        glow = glow.filter(ImageFilter.GaussianBlur(radius=max(width, height) // 8))
        image = Image.alpha_composite(image, glow)
        rng = random.Random(hashlib.sha256(seed.encode("utf-8")).digest())
        stars = Image.new("RGBA", image.size, (0, 0, 0, 0))
        d = ImageDraw.Draw(stars)
        for _ in range(120 if height > width else 85):
            x = rng.randrange(20, width - 20)
            y = rng.randrange(20, height - 20)
            r = rng.choice((1, 1, 1, 2))
            d.ellipse((x-r, y-r, x+r, y+r), fill=(155, 255, 218, rng.randrange(25, 105)))
        return Image.alpha_composite(image, stars)

    def _panel(self, draw: ImageDraw.ImageDraw, box: tuple[int, int, int, int], *, accent: tuple[int, int, int, int] = (55, 244, 164, 255), fill: tuple[int, int, int, int] = (5, 24, 31, 232), radius: int = 28) -> None:
        draw.rounded_rectangle(box, radius=radius, fill=fill, outline=(61, 146, 119, 120), width=2)
        x1, y1, _x2, y2 = box
        draw.rounded_rectangle((x1, y1, x1 + 9, y2), radius=5, fill=accent)

    def _brand_header(self, image: Image.Image, draw: ImageDraw.ImageDraw, *, margin: int, top: int, date_text: str, league: str, label: str) -> int:
        green = (55, 244, 164, 255)
        white = (244, 250, 252, 255)
        muted = (145, 166, 177, 255)
        logo = self.logo()
        if logo is not None:
            logo.thumbnail((78, 78), Image.Resampling.LANCZOS)
            image.alpha_composite(logo, (margin, top))
            brand_x = margin + 96
        else:
            brand_x = margin
        draw.text((brand_x, top + 6), "DIAMONDMIND AI", font=self.font(27, True), fill=green)
        draw.text((brand_x, top + 48), label, font=self.font(15, True), fill=muted)
        badge = f"●  {date_text} · {league}"
        badge_font = self.font(21, True)
        badge_w = int(self._measure(draw, badge, badge_font)) + 42
        right = image.width - margin
        draw.rounded_rectangle((right - badge_w, top + 8, right, top + 58), radius=25, fill=(4, 27, 34, 230), outline=(40, 174, 130, 180), width=2)
        draw.text((right - badge_w + 21, top + 18), badge, font=badge_font, fill=white)
        return top + 108

    def _export(self, image: Image.Image) -> bytes:
        output = io.BytesIO()
        image.convert("RGB").save(output, format="JPEG", quality=94, optimize=True, progressive=True)
        return output.getvalue()

    def render(self, spec: SocialAssetSpec, payload: dict[str, Any]) -> bytes:
        spec = spec.validated()
        if spec.source == "free" and spec.phase == "pregame":
            return self._render_free_card(spec, payload)
        if spec.source == "pro" and spec.phase == "teaser":
            return self._render_batch_card(spec, payload)
        if spec.source == "pro" and spec.phase == "result":
            return self._render_result_summary(spec, payload)
        return self._render_legacy_result(spec, payload)

    def _render_free_card(self, spec: SocialAssetSpec, payload: dict[str, Any]) -> bytes:
        """Render the locked daily free pick as the large hero card.

        V19.1.4 keeps the free pick as one dedicated Story and uses the same
        large-card visual language for its settled Reel frame. Pro cards,
        five-per-frame grouping, summary cards, and Reel sequencing are not
        changed by this renderer.
        """
        width, height = (1080, 1920) if spec.size == "story" else (1080, 1350)
        image = self._background(width, height, spec.signing_value)
        draw = ImageDraw.Draw(image)
        green = (55, 244, 164, 255)
        white = (244, 250, 252, 255)
        muted = (145, 166, 177, 255)
        gold = (255, 215, 106, 255)
        margin = 50 if spec.size == "story" else 42
        date_text = spec.recommendation_date[5:].replace("-", "/")

        if spec.size != "story":
            # Feed fallback keeps the existing compact composition.
            y = self._brand_header(
                image, draw, margin=margin, top=52, date_text=date_text,
                league=spec.league, label="LATEST PUBLISHED PICK",
            )
            confidence = _confidence_percent(payload.get("confidence")) or 0.0
            ring_size = 330
            ring_left = (width - ring_size) // 2
            ring_top = y + 58
            ring_box = (ring_left, ring_top, ring_left + ring_size, ring_top + ring_size)
            draw.ellipse(ring_box, outline=(18, 48, 56, 255), width=32)
            draw.arc(ring_box, start=-90, end=-90 + int(confidence * 3.6), fill=green, width=32)
            self._center_text(draw, ring_top + 112, f"{confidence:.1f}%", self.font(72, True), green, width)
            self._center_text(draw, ring_top + 205, "AI 信心", self.font(23, True), muted, width)
            matchup = str(payload.get("matchup") or "今日精選賽事")
            matchup_font = self._fit_font(draw, matchup, width - margin * 2, 47, 28, True)
            self._center_text(draw, ring_top + ring_size + 45, matchup, matchup_font, white, width)
            self._center_text(draw, ring_top + ring_size + 108, str(payload.get("time_label") or "台灣時間待確認"), self.font(22, True), muted, width)
            panel_top = ring_top + ring_size + 170
            self._panel(draw, (margin, panel_top, width - margin, panel_top + 230), accent=green)
            draw.text((margin + 38, panel_top + 35), "創辦人正式推薦", font=self.font(22, True), fill=muted)
            pick = compact_pick_label(payload)
            pick_font = self._fit_font(draw, pick, width - margin * 2 - 76, 50, 29, True)
            draw.text((margin + 38, panel_top + 92), pick, font=pick_font, fill=green)
            return self._export(image)

        # Outer poster header, matching the user's approved large-card sample.
        draw.text((margin + 4, 68), "DIAMONDMIND AI", font=self.font(25, True), fill=green)
        badge = f"●  {date_text} · {spec.league}"
        badge_font = self.font(20, True)
        badge_w = int(self._measure(draw, badge, badge_font)) + 44
        draw.rounded_rectangle(
            (width - margin - badge_w, 56, width - margin, 112),
            radius=28, fill=(3, 24, 31, 236), outline=(47, 170, 132, 185), width=2,
        )
        draw.text((width - margin - badge_w + 22, 70), badge, font=badge_font, fill=white)
        draw.text((margin + 4, 142), "FREE PICK RELEASE", font=self.font(18, True), fill=gold)
        draw.text((margin + 4, 184), f"{spec.league} 免費場正式發佈", font=self.font(47, True), fill=white)
        draw.text((margin + 4, 246), "今日公開推薦｜創辦人精選・已鎖定", font=self.font(21, True), fill=muted)

        card_left, card_top = 94, 324
        card_right, card_bottom = width - 94, 1395
        shadow = Image.new("RGBA", image.size, (0, 0, 0, 0))
        shadow_draw = ImageDraw.Draw(shadow)
        shadow_draw.rounded_rectangle(
            (card_left - 14, card_top - 14, card_right + 14, card_bottom + 14),
            radius=46, outline=(32, 255, 185, 58), width=16,
        )
        shadow = shadow.filter(ImageFilter.GaussianBlur(12))
        image.alpha_composite(shadow)
        draw = ImageDraw.Draw(image)
        draw.rounded_rectangle(
            (card_left, card_top, card_right, card_bottom), radius=42,
            fill=(2, 16, 24, 242), outline=(43, 143, 114, 230), width=3,
        )
        draw.rounded_rectangle(
            (card_left + 8, card_top + 8, card_right - 8, card_bottom - 8), radius=36,
            outline=(27, 89, 77, 190), width=2,
        )

        inner_x = card_left + 42
        draw.text((inner_x, card_top + 44), "LATEST PUBLISHED\nPICK", font=self.font(25, True), fill=green, spacing=5)
        lock_text = f"{spec.league} 創辦人精選・已鎖定"
        lock_font = self.font(18, True)
        lock_w = int(self._measure(draw, lock_text, lock_font)) + 44
        lock_x2 = card_right - 34
        draw.rounded_rectangle(
            (lock_x2 - lock_w, card_top + 45, lock_x2, card_top + 99),
            radius=27, fill=(34, 37, 30, 222), outline=(163, 136, 68, 185), width=2,
        )
        draw.text((lock_x2 - lock_w + 22, card_top + 59), lock_text, font=lock_font, fill=gold)

        confidence = _confidence_percent(payload.get("confidence")) or 0.0
        ring_size = 310
        ring_left = (width - ring_size) // 2
        ring_top = card_top + 185
        ring_box = (ring_left, ring_top, ring_left + ring_size, ring_top + ring_size)
        draw.ellipse(ring_box, outline=(18, 48, 56, 255), width=28)
        draw.arc(ring_box, start=-90, end=-90 + int(confidence * 3.6), fill=green, width=28)
        pct = f"{confidence:.1f}%"
        pct_font = self._fit_font(draw, pct, ring_size - 60, 72, 48, True)
        self._center_text(draw, ring_top + 92, pct, pct_font, green, width)
        self._center_text(draw, ring_top + 190, "AI 信心", self.font(20, True), muted, width)

        matchup = str(payload.get("matchup") or "今日精選賽事")
        matchup_y = ring_top + ring_size + 66
        matchup_font = self._fit_font(draw, matchup, card_right - card_left - 76, 43, 25, True)
        self._center_text(draw, matchup_y, matchup, matchup_font, white, width)
        time_label = str(payload.get("time_label") or "台灣時間待確認")
        self._center_text(draw, matchup_y + 62, time_label, self.font(23, True), muted, width)

        pick_panel_top = matchup_y + 128
        pick_panel_bottom = pick_panel_top + 190
        draw.rounded_rectangle(
            (card_left + 42, pick_panel_top, card_right - 42, pick_panel_bottom),
            radius=28, fill=(4, 31, 35, 234), outline=(47, 143, 116, 220), width=2,
        )
        draw.text((card_left + 72, pick_panel_top + 34), "創辦人正式推薦", font=self.font(21, True), fill=muted)
        pick = compact_pick_label(payload)
        pick_font = self._fit_font(draw, pick, card_right - card_left - 144, 43, 25, True)
        draw.text((card_left + 72, pick_panel_top + 88), pick, font=pick_font, fill=green)

        meta_y = card_bottom - 105
        metadata = [f"賽事日 {date_text}", "正式發布", "已發佈"]
        widths = [190, 245, 130]
        starts = [card_left + 42, card_left + 252, card_right - 172]
        for text, pill_w, pill_x in zip(metadata, widths, starts):
            draw.rounded_rectangle(
                (pill_x, meta_y, pill_x + pill_w, meta_y + 50), radius=25,
                fill=(2, 22, 29, 225), outline=(39, 99, 84, 180), width=2,
            )
            pill_font = self._fit_font(draw, text, pill_w - 24, 16, 12, True)
            text_w = self._measure(draw, text, pill_font)
            draw.text((pill_x + (pill_w - text_w) / 2, meta_y + 14), text, font=pill_font, fill=muted)

        # Lower information panel is part of the approved pregame Story only.
        panel_top = 1452
        panel_bottom = 1775
        self._panel(draw, (margin, panel_top, width - margin, panel_bottom), accent=green)
        draw.text((margin + 30, panel_top + 34), "TODAY'S FREE PICK", font=self.font(17, True), fill=gold)
        panel_pick_font = self._fit_font(draw, pick, width - margin * 2 - 60, 40, 24, True)
        draw.text((margin + 30, panel_top + 84), pick, font=panel_pick_font, fill=white)
        pill_y = panel_top + 170
        pills = [f"AI 信心 {confidence:.1f}%", time_label, "免費公開・已發佈"]
        x = margin + 28
        available_w = width - margin * 2 - 56
        gap = 18
        pill_w = int((available_w - gap * 2) / 3)
        for text in pills:
            draw.rounded_rectangle(
                (x, pill_y, x + pill_w, pill_y + 58), radius=29,
                fill=(3, 31, 36, 232), outline=(36, 103, 87, 185), width=2,
            )
            font = self._fit_font(draw, text, pill_w - 24, 16, 11, True)
            text_w = self._measure(draw, text, font)
            draw.text((x + (pill_w - text_w) / 2, pill_y + 17), text, font=font, fill=white)
            x += pill_w + gap
        draw.text((margin + 30, panel_bottom - 50), f"{date_text} 創辦人正式推薦｜完整紀錄公開留存", font=self.font(15, True), fill=muted)

        footer_y = 1848
        draw.line((margin, footer_y - 20, width - margin, footer_y - 20), fill=(31, 81, 71, 160), width=2)
        draw.text((margin, footer_y), "DIAMONDMIND AI · MLB INTELLIGENCE", font=self.font(13, True), fill=muted)
        right_footer = "免費場已正式發佈"
        footer_font = self.font(13, True)
        draw.text((width - margin - self._measure(draw, right_footer, footer_font), footer_y), right_footer, font=footer_font, fill=muted)
        return self._export(image)

    def _render_free_result_card(
        self,
        reel_spec: SocialReelSpec,
        payload: dict[str, Any],
    ) -> bytes:
        """Use the approved large free-pick card and show only its result below."""
        reel_spec = reel_spec.validated()
        width, height = 1080, 1920
        seed = f"{reel_spec.signing_value}|free-large-result|{payload.get('candidate_id') or payload.get('label')}"
        image = self._background(width, height, seed)
        draw = ImageDraw.Draw(image)
        green = (55, 244, 164, 255)
        white = (244, 250, 252, 255)
        muted = (145, 166, 177, 255)
        gold = (255, 215, 106, 255)
        red = (255, 111, 135, 255)
        margin = 50
        date_text = reel_spec.recommendation_date[5:].replace("-", "/")

        draw.text((margin + 4, 68), "DIAMONDMIND AI", font=self.font(25, True), fill=green)
        badge = f"●  {date_text} · {reel_spec.league}"
        badge_font = self.font(20, True)
        badge_w = int(self._measure(draw, badge, badge_font)) + 44
        draw.rounded_rectangle(
            (width - margin - badge_w, 56, width - margin, 112), radius=28,
            fill=(3, 24, 31, 236), outline=(47, 170, 132, 185), width=2,
        )
        draw.text((width - margin - badge_w + 22, 70), badge, font=badge_font, fill=white)
        draw.text((margin + 4, 142), "FREE PICK RESULT", font=self.font(18, True), fill=gold)
        draw.text((margin + 4, 184), f"{reel_spec.league} 免費場賽果", font=self.font(47, True), fill=white)
        draw.text((margin + 4, 246), "原始公開推薦｜正式結果已結算", font=self.font(21, True), fill=muted)

        card_left, card_top = 94, 324
        card_right, card_bottom = width - 94, 1395
        shadow = Image.new("RGBA", image.size, (0, 0, 0, 0))
        shadow_draw = ImageDraw.Draw(shadow)
        shadow_draw.rounded_rectangle(
            (card_left - 14, card_top - 14, card_right + 14, card_bottom + 14),
            radius=46, outline=(32, 255, 185, 58), width=16,
        )
        shadow = shadow.filter(ImageFilter.GaussianBlur(12))
        image.alpha_composite(shadow)
        draw = ImageDraw.Draw(image)
        draw.rounded_rectangle(
            (card_left, card_top, card_right, card_bottom), radius=42,
            fill=(2, 16, 24, 242), outline=(43, 143, 114, 230), width=3,
        )
        draw.rounded_rectangle(
            (card_left + 8, card_top + 8, card_right - 8, card_bottom - 8), radius=36,
            outline=(27, 89, 77, 190), width=2,
        )
        inner_x = card_left + 42
        draw.text((inner_x, card_top + 44), "LATEST PUBLISHED\nPICK", font=self.font(25, True), fill=green, spacing=5)
        lock_text = f"{reel_spec.league} 創辦人精選・已鎖定"
        lock_font = self.font(18, True)
        lock_w = int(self._measure(draw, lock_text, lock_font)) + 44
        lock_x2 = card_right - 34
        draw.rounded_rectangle(
            (lock_x2 - lock_w, card_top + 45, lock_x2, card_top + 99), radius=27,
            fill=(34, 37, 30, 222), outline=(163, 136, 68, 185), width=2,
        )
        draw.text((lock_x2 - lock_w + 22, card_top + 59), lock_text, font=lock_font, fill=gold)

        confidence = _confidence_percent(payload.get("confidence")) or 0.0
        ring_size = 310
        ring_left = (width - ring_size) // 2
        ring_top = card_top + 185
        ring_box = (ring_left, ring_top, ring_left + ring_size, ring_top + ring_size)
        draw.ellipse(ring_box, outline=(18, 48, 56, 255), width=28)
        draw.arc(ring_box, start=-90, end=-90 + int(confidence * 3.6), fill=green, width=28)
        pct_font = self._fit_font(draw, f"{confidence:.1f}%", ring_size - 60, 72, 48, True)
        self._center_text(draw, ring_top + 92, f"{confidence:.1f}%", pct_font, green, width)
        self._center_text(draw, ring_top + 190, "AI 信心", self.font(20, True), muted, width)

        matchup = str(payload.get("matchup") or "今日精選賽事")
        matchup_y = ring_top + ring_size + 66
        matchup_font = self._fit_font(draw, matchup, card_right - card_left - 76, 43, 25, True)
        self._center_text(draw, matchup_y, matchup, matchup_font, white, width)
        time_label = str(payload.get("time_label") or "台灣時間待確認")
        self._center_text(draw, matchup_y + 62, time_label, self.font(23, True), muted, width)

        pick_panel_top = matchup_y + 128
        pick_panel_bottom = pick_panel_top + 190
        draw.rounded_rectangle(
            (card_left + 42, pick_panel_top, card_right - 42, pick_panel_bottom), radius=28,
            fill=(4, 31, 35, 234), outline=(47, 143, 116, 220), width=2,
        )
        draw.text((card_left + 72, pick_panel_top + 34), "創辦人正式推薦", font=self.font(21, True), fill=muted)
        pick = str(payload.get("label") or "推薦方向待確認")
        pick_font = self._fit_font(draw, pick, card_right - card_left - 144, 43, 25, True)
        draw.text((card_left + 72, pick_panel_top + 88), pick, font=pick_font, fill=green)

        meta_y = card_bottom - 105
        metadata = [f"賽事日 {date_text}", "正式發布", "已結算"]
        widths = [190, 245, 130]
        starts = [card_left + 42, card_left + 252, card_right - 172]
        for text, pill_w, pill_x in zip(metadata, widths, starts):
            draw.rounded_rectangle(
                (pill_x, meta_y, pill_x + pill_w, meta_y + 50), radius=25,
                fill=(2, 22, 29, 225), outline=(39, 99, 84, 180), width=2,
            )
            pill_font = self._fit_font(draw, text, pill_w - 24, 16, 12, True)
            text_w = self._measure(draw, text, pill_font)
            draw.text((pill_x + (pill_w - text_w) / 2, meta_y + 14), text, font=pill_font, fill=muted)

        # The user requested only the settled status below the large card.
        status = str(payload.get("status") or "pending").lower()
        status_text = status_label(status)
        status_color = green if status == "won" else red if status == "lost" else gold
        result_top = 1460
        draw.rounded_rectangle(
            (margin, result_top, width - margin, 1768), radius=34,
            fill=(4, 25, 32, 236), outline=(42, 113, 94, 195), width=2,
        )
        self._center_text(draw, result_top + 38, "免費場賽果", self.font(20, True), muted, width)
        status_font = self._fit_font(draw, status_text, width - margin * 2 - 120, 96, 64, True)
        self._center_text(draw, result_top + 108, status_text, status_font, status_color, width)

        footer_y = 1848
        draw.line((margin, footer_y - 20, width - margin, footer_y - 20), fill=(31, 81, 71, 160), width=2)
        draw.text((margin, footer_y), "DIAMONDMIND AI · RESULT RECORD", font=self.font(13, True), fill=muted)
        return self._export(image)

    def _render_batch_card(self, spec: SocialAssetSpec, payload: dict[str, Any]) -> bytes:
        width, height = (1080, 1920) if spec.size == "story" else (1080, 1350)
        image = self._background(width, height, spec.signing_value)
        draw = ImageDraw.Draw(image)
        green = (55, 244, 164, 255)
        white = (244, 250, 252, 255)
        muted = (145, 166, 177, 255)
        gold = (255, 215, 106, 255)
        margin = 58
        top = 130 if spec.size == "story" else 52
        date_text = spec.recommendation_date[5:].replace("-", "/")
        y = self._brand_header(image, draw, margin=margin, top=top, date_text=date_text, league=spec.league, label="AI PUBLISHED PICKS")
        title = f"{date_text} {spec.league} AI 推薦總覽"
        draw.text((margin, y + 8), title, font=self.font(49 if spec.size == "story" else 44, True), fill=white)
        page = int(payload.get("page") or spec.page)
        total_pages = int(payload.get("total_pages") or 1)
        subtitle = f"第 {page}/{total_pages} 組 · 完整推薦方向僅限會員查看"
        draw.text((margin, y + 74), subtitle, font=self.font(22, True), fill=muted)
        y += 130

        items = list(payload.get("items") or [])[:5]
        available = height - y - (250 if spec.size == "story" else 150)
        row_h = min(235 if spec.size == "story" else 185, max(145, available // max(1, len(items))))
        for index, item in enumerate(items):
            row_top = y + index * (row_h + 16)
            row_bottom = row_top + row_h
            self._panel(draw, (margin, row_top, width - margin, row_bottom), accent=green)
            num = f"{(page - 1) * 5 + index + 1:02d}"
            draw.text((margin + 28, row_top + 28), num, font=self.font(31, True), fill=green)
            matchup = str(item.get("matchup") or "對戰待確認")
            matchup_font = self._fit_font(draw, matchup, width - margin * 2 - 205, 31 if spec.size == "story" else 28, 20, True)
            draw.text((margin + 105, row_top + 27), matchup, font=matchup_font, fill=white)
            meta = str(item.get("time_label") or "台灣時間待確認")
            draw.text((margin + 105, row_top + 83), meta, font=self.font(19 if spec.size == "story" else 17), fill=muted)
            conf = _confidence_percent(item.get("confidence"))
            conf_text = f"{conf:.1f}%" if conf is not None else "—"
            conf_font = self.font(34 if spec.size == "story" else 31, True)
            draw.text((width - margin - 30 - self._measure(draw, conf_text, conf_font), row_top + 30), conf_text, font=conf_font, fill=gold)
            draw.text((width - margin - 95, row_bottom - 48), "AI 信心", font=self.font(15, True), fill=muted)
        if not items:
            self._panel(draw, (margin, y, width - margin, y + 230))
            self._center_text(draw, y + 82, "今日推薦資料整理中", self.font(34, True), muted, width)

        footer_y = height - (190 if spec.size == "story" else 92)
        self._center_text(draw, footer_y, "推薦方向已鎖定 · Pro 會員登入查看", self.font(20, True), green, width)
        self._center_text(draw, footer_y + 40, "公開貼文不顯示獨贏、讓分、大小分或串關方向", self.font(15), muted, width)
        return self._export(image)

    def _render_result_summary(self, spec: SocialAssetSpec, payload: dict[str, Any]) -> bytes:
        """Render the final Reel summary card.

        V19.1.2 promotes the overall daily win rate to the primary visual. Pushes
        and voids are excluded from the denominator by the payload builder.
        """
        width, height = (1080, 1920) if spec.size == "story" else (1080, 1350)
        image = self._background(width, height, spec.signing_value)
        draw = ImageDraw.Draw(image)
        green = (55, 244, 164, 255)
        white = (244, 250, 252, 255)
        muted = (145, 166, 177, 255)
        gold = (255, 215, 106, 255)
        red = (255, 111, 135, 255)
        margin = 58
        top = 130 if spec.size == "story" else 52
        date_text = spec.recommendation_date[5:].replace("-", "/")
        y = self._brand_header(
            image, draw, margin=margin, top=top, date_text=date_text,
            league=spec.league, label="DAILY PERFORMANCE",
        )
        title = f"{date_text} {spec.league} 賽後戰績"
        draw.text((margin, y + 6), title, font=self.font(50 if spec.size == "story" else 44, True), fill=white)
        draw.text((margin, y + 73), "獨贏 · 讓分 · 大小分 · 串關｜正式推薦完整結算", font=self.font(20, True), fill=muted)
        y += 128

        overall = payload.get("overall") or payload.get("summary") or {}
        won = int(overall.get("won") or 0)
        lost = int(overall.get("lost") or 0)
        neutral = int(overall.get("neutral") or 0)
        decided = won + lost
        rate = overall.get("hit_rate")
        try:
            win_rate = float(rate) if rate is not None else (won / decided * 100.0 if decided else 0.0)
        except (TypeError, ValueError):
            win_rate = won / decided * 100.0 if decided else 0.0

        # B layout: the daily win rate is the dominant visual.
        hero_h = 270 if spec.size == "story" else 205
        self._panel(draw, (margin, y, width - margin, y + hero_h), accent=green)
        draw.text((margin + 38, y + 30), "今日勝率", font=self.font(29, True), fill=white)
        draw.text((margin + 38, y + 74), "TODAY WIN RATE", font=self.font(16, True), fill=muted)
        rate_text = f"{win_rate:.1f}%"
        rate_font = self._fit_font(draw, rate_text, 450, 108 if spec.size == "story" else 82, 62, True)
        draw.text((margin + 34, y + 116), rate_text, font=rate_font, fill=green)
        count_x = width - margin - 330
        draw.text((count_x, y + 54), "今日正式推薦", font=self.font(18, True), fill=muted)
        draw.text((count_x, y + 92), f"{won} 中  {lost} 未中", font=self.font(33 if spec.size == "story" else 27, True), fill=white)
        draw.text((count_x, y + 148), f"有效結算 {decided} 項", font=self.font(20, True), fill=gold)
        draw.text((count_x, y + 190), f"走水／作廢 {neutral} 項", font=self.font(18, True), fill=muted)
        y += hero_h + 22

        categories = payload.get("categories") or {}
        cards = [
            ("moneylines", "獨贏", "MONEYLINE"),
            ("run_lines", "讓分", "SPREAD"),
            ("totals", "大小分", "TOTALS"),
            ("parlays", "串關", "PARLAY"),
        ]
        gap = 18
        card_w = (width - margin * 2 - gap) // 2
        card_h = 182 if spec.size == "story" else 145
        for index, (key, zh, en) in enumerate(cards):
            row = index // 2
            col = index % 2
            x1 = margin + col * (card_w + gap)
            y1 = y + row * (card_h + gap)
            x2 = x1 + card_w
            y2 = y1 + card_h
            accent = green if index in {0, 3} else gold
            self._panel(draw, (x1, y1, x2, y2), accent=accent)
            stat = categories.get(key) or {}
            category_won = int(stat.get("won") or 0)
            category_lost = int(stat.get("lost") or 0)
            category_neutral = int(stat.get("neutral") or 0)
            category_rate = stat.get("hit_rate")
            draw.text((x1 + 28, y1 + 20), zh, font=self.font(27, True), fill=white)
            draw.text((x1 + 28, y1 + 57), en, font=self.font(13, True), fill=muted)
            draw.text((x1 + 28, y1 + 91), f"{category_won} 中", font=self.font(29, True), fill=green)
            draw.text((x1 + 136, y1 + 91), f"{category_lost} 未中", font=self.font(25, True), fill=red)
            rate_label = f"{float(category_rate):.1f}%" if category_rate is not None else "—"
            rate_font = self.font(22, True)
            draw.text((x2 - 24 - self._measure(draw, rate_label, rate_font), y2 - 42), rate_label, font=rate_font, fill=gold)
            if category_neutral:
                draw.text((x1 + 28, y2 - 40), f"中立 {category_neutral}", font=self.font(14, True), fill=muted)
        y += 2 * (card_h + gap) + 12

        parlay = payload.get("parlay") or {}
        parlay_h = 126 if spec.size == "story" else 102
        self._panel(draw, (margin, y, width - margin, y + parlay_h), accent=gold)
        draw.text((margin + 30, y + 20), "串關重點", font=self.font(21, True), fill=white)
        parlay_text = f"{int(parlay.get('won') or 0)} 中  {int(parlay.get('lost') or 0)} 未中"
        draw.text((margin + 30, y + 57), parlay_text, font=self.font(27, True), fill=green)
        odds_text = f"二關 {parlay.get('two_leg_odds') or '—'} 倍   三關 {parlay.get('three_leg_odds') or '—'} 倍"
        odds_font = self.font(19, True)
        draw.text((width - margin - 30 - self._measure(draw, odds_text, odds_font), y + 62), odds_text, font=odds_font, fill=gold)
        y += parlay_h + 16

        free_result = payload.get("free_result") or {}
        free_h = 116 if spec.size == "story" else 92
        self._panel(draw, (margin, y, width - margin, y + free_h), accent=green)
        draw.text((margin + 28, y + 18), "每日免費推薦", font=self.font(20, True), fill=white)
        free_label = str(free_result.get("label") or "當日未指定免費場")
        free_status = str(free_result.get("status_label") or "—")
        label_font = self._fit_font(draw, free_label, width - margin * 2 - 230, 20, 14, True)
        draw.text((margin + 28, y + 53), free_label, font=label_font, fill=muted)
        status_color = green if free_result.get("status") == "won" else red if free_result.get("status") == "lost" else gold
        status_font = self.font(24, True)
        draw.text((width - margin - 28 - self._measure(draw, free_status, status_font), y + 44), free_status, font=status_font, fill=status_color)
        y += free_h + 16

        note_bottom = height - (185 if spec.size == "story" else 74)
        note_height = 110 if spec.size == "story" else 86
        note_top = note_bottom - note_height
        if y < note_top - 14:
            draw.text((margin, y + 2), "RESULT PROOF  原始發布與結算紀錄", font=self.font(16, True), fill=green)
            draw.text((margin, y + 36), "每 5 場一張公開賽果，最後以本頁統計收尾。", font=self.font(15, True), fill=muted)
        draw.rounded_rectangle((margin, note_top, width - margin, note_bottom), radius=24, fill=(5, 24, 31, 225), outline=(139, 112, 46, 150), width=2)
        draw.text((margin + 28, note_top + 16), "SETTLEMENT NOTE", font=self.font(16, True), fill=gold)
        note = "今日勝率＝命中 ÷（命中＋未中）；走水與作廢不列入分母。"
        note_font = self._fit_font(draw, note, width - margin * 2 - 56, 17, 13, True)
        draw.text((margin + 28, note_top + 49), note, font=note_font, fill=white)
        return self._export(image)

    def render_result_card(
        self,
        reel_spec: SocialReelSpec,
        payload: dict[str, Any],
        *,
        index: int,
        total: int,
    ) -> bytes:
        reel_spec = reel_spec.validated()
        if str(payload.get("source") or "").lower() == "free":
            return self._render_free_result_card(reel_spec, payload)
        width, height = 1080, 1920
        seed = f"{reel_spec.signing_value}|result-card|{index}|{payload.get('candidate_id') or payload.get('label')}"
        image = self._background(width, height, seed)
        draw = ImageDraw.Draw(image)
        green = (55, 244, 164, 255)
        white = (244, 250, 252, 255)
        muted = (145, 166, 177, 255)
        gold = (255, 215, 106, 255)
        red = (255, 111, 135, 255)
        margin = 58
        date_text = reel_spec.recommendation_date[5:].replace("-", "/")
        y = self._brand_header(
            image, draw, margin=margin, top=130, date_text=date_text,
            league=reel_spec.league, label="SETTLED PICK",
        )
        position = f"RESULT {index:02d} / {max(1, total):02d}"
        draw.text((margin, y + 8), position, font=self.font(18, True), fill=green)
        market = normalize_market_label(payload.get("market"))
        source_label = "每日免費推薦" if payload.get("source") == "free" else "PRO 正式推薦"
        badge = f"{source_label} · {market}"
        badge_font = self.font(21, True)
        badge_w = int(self._measure(draw, badge, badge_font)) + 46
        draw.rounded_rectangle(
            (margin, y + 50, margin + badge_w, y + 106),
            radius=28, fill=(5, 31, 38, 232), outline=(55, 244, 164, 145), width=2,
        )
        draw.text((margin + 23, y + 64), badge, font=badge_font, fill=gold if payload.get("source") == "free" else green)

        matchup = str(payload.get("matchup") or "賽事對戰")
        matchup_lines = self._wrap(draw, matchup, self.font(54, True), width - margin * 2, max_lines=2)
        matchup_y = y + 166
        for line in matchup_lines:
            line_font = self._fit_font(draw, line, width - margin * 2, 54, 30, True)
            self._center_text(draw, matchup_y, line, line_font, white, width)
            matchup_y += 72

        score = str(payload.get("score") or "最終比分已確認")
        score_font = self._fit_font(draw, score, width - margin * 2 - 60, 42, 25, True)
        self._center_text(draw, matchup_y + 24, score, score_font, muted, width)

        panel_top = matchup_y + 124
        panel_bottom = panel_top + 350
        self._panel(draw, (margin, panel_top, width - margin, panel_bottom), accent=green)
        draw.text((margin + 42, panel_top + 38), "原始推薦方向", font=self.font(22, True), fill=muted)
        pick = str(payload.get("label") or "推薦方向待確認")
        pick_lines = self._wrap(draw, pick, self.font(48, True), width - margin * 2 - 84, max_lines=2)
        pick_y = panel_top + 88
        for line in pick_lines:
            line_font = self._fit_font(draw, line, width - margin * 2 - 84, 48, 27, True)
            draw.text((margin + 42, pick_y), line, font=line_font, fill=white)
            pick_y += 64

        status = str(payload.get("status") or "pending").lower()
        status_text = status_label(status)
        status_color = green if status == "won" else red if status == "lost" else gold
        status_font = self.font(70, True)
        status_y = panel_bottom + 120
        self._center_text(draw, status_y, f"{result_icon(status)}  {status_text}", status_font, status_color, width)
        note = (
            "走水／作廢不列入命中率"
            if status in {"push", "void"}
            else "已依正式發布的純模型方向完成結算"
            if str(payload.get("analysis_mode") or "") == "model_only"
            else "已依正式發布盤口完成結算"
        )
        self._center_text(draw, status_y + 110, note, self.font(21, True), muted, width)

        footer_top = height - 300
        draw.line((margin, footer_top, width - margin, footer_top), fill=(55, 244, 164, 100), width=2)
        self._center_text(draw, footer_top + 58, "下一張繼續查看單場賽果", self.font(20, True), green, width)
        self._center_text(draw, footer_top + 106, "最後一張為當日完整戰績總結", self.font(17), muted, width)
        return self._export(image)

    def render_result_batch_card(
        self,
        reel_spec: SocialReelSpec,
        items: list[dict[str, Any]],
        *,
        page: int,
        total_pages: int,
        item_offset: int = 0,
    ) -> bytes:
        """Render up to five settled Pro recommendations on one Reel frame."""
        reel_spec = reel_spec.validated()
        width, height = 1080, 1920
        seed_ids = "|".join(str(item.get("candidate_id") or item.get("label") or "") for item in items)
        seed = f"{reel_spec.signing_value}|result-batch|{page}|{seed_ids}"
        image = self._background(width, height, seed)
        draw = ImageDraw.Draw(image)
        green = (55, 244, 164, 255)
        white = (244, 250, 252, 255)
        muted = (145, 166, 177, 255)
        gold = (255, 215, 106, 255)
        red = (255, 111, 135, 255)
        margin = 58
        date_text = reel_spec.recommendation_date[5:].replace("-", "/")
        y = self._brand_header(
            image, draw, margin=margin, top=130, date_text=date_text,
            league=reel_spec.league, label="PRO SETTLED PICKS",
        )
        title = f"{date_text} {reel_spec.league} PRO 賽果"
        draw.text((margin, y + 8), title, font=self.font(48, True), fill=white)
        subtitle = f"第 {page}/{max(1, total_pages)} 組 · 每 5 場一張"
        draw.text((margin, y + 72), subtitle, font=self.font(21, True), fill=muted)
        y += 128

        rows = list(items or [])[:5]
        available = height - y - 220
        row_gap = 16
        row_h = min(245, max(190, (available - row_gap * max(0, len(rows) - 1)) // max(1, len(rows))))
        for index, item in enumerate(rows):
            row_top = y + index * (row_h + row_gap)
            row_bottom = row_top + row_h
            status = str(item.get("status") or "pending").lower()
            status_color = green if status == "won" else red if status == "lost" else gold
            self._panel(draw, (margin, row_top, width - margin, row_bottom), accent=status_color)

            number = f"{item_offset + index + 1:02d}"
            draw.text((margin + 27, row_top + 25), number, font=self.font(30, True), fill=status_color)
            matchup = str(item.get("matchup") or "對戰待確認")
            matchup_font = self._fit_font(draw, matchup, 630, 29, 18, True)
            draw.text((margin + 102, row_top + 24), matchup, font=matchup_font, fill=white)

            label = str(item.get("label") or "推薦方向待確認")
            label_font = self._fit_font(draw, label, 660, 27, 17, True)
            draw.text((margin + 102, row_top + 77), label, font=label_font, fill=green if status == "won" else white)

            score = str(item.get("score") or "官方最終賽果已確認")
            score_font = self._fit_font(draw, score, 680, 18, 13, True)
            draw.text((margin + 102, row_top + 128), score, font=score_font, fill=muted)

            market = normalize_market_label(item.get("market"))
            draw.text((margin + 102, row_bottom - 47), market, font=self.font(15, True), fill=gold)

            status_text = status_label(status)
            badge_font = self.font(27, True)
            badge_w = int(self._measure(draw, status_text, badge_font)) + 48
            badge_x2 = width - margin - 24
            badge_x1 = badge_x2 - badge_w
            draw.rounded_rectangle(
                (badge_x1, row_top + 24, badge_x2, row_top + 78),
                radius=27, fill=(5, 31, 38, 238), outline=status_color, width=2,
            )
            draw.text((badge_x1 + 24, row_top + 35), status_text, font=badge_font, fill=status_color)

        if not rows:
            self._panel(draw, (margin, y, width - margin, y + 250), accent=gold)
            self._center_text(draw, y + 92, "今日 Pro 賽果整理中", self.font(34, True), muted, width)

        footer_y = height - 168
        draw.line((margin, footer_y - 26, width - margin, footer_y - 26), fill=(55, 244, 164, 100), width=2)
        self._center_text(draw, footer_y, "原始推薦方向與正式賽果如實公開", self.font(19, True), green, width)
        self._center_text(draw, footer_y + 40, "最後一張為今日勝率與完整戰績總結", self.font(16, True), muted, width)
        return self._export(image)

    def _render_legacy_result(self, spec: SocialAssetSpec, payload: dict[str, Any]) -> bytes:
        width, height = (1080, 1920) if spec.size == "story" else (1080, 1350)
        image = self._background(width, height, spec.signing_value)
        draw = ImageDraw.Draw(image)
        green = (55, 244, 164, 255)
        white = (244, 250, 252, 255)
        muted = (145, 166, 177, 255)
        red = (255, 111, 135, 255)
        margin = 58
        top = 130 if spec.size == "story" else 52
        date_text = spec.recommendation_date[5:].replace("-", "/")
        y = self._brand_header(image, draw, margin=margin, top=top, date_text=date_text, league=spec.league, label="PUBLISHED RESULT")
        matchup = str(payload.get("matchup") or "每日免費推薦")
        title_font = self._fit_font(draw, matchup, width - margin * 2, 48, 28, True)
        self._center_text(draw, y + 35, matchup, title_font, white, width)
        status = str(payload.get("status") or "pending").lower()
        color = green if status == "won" else red
        self._center_text(draw, y + 180, f"{result_icon(status)} {status_label(status)}", self.font(72, True), color, width)
        self._center_text(draw, y + 300, compact_pick_label(payload), self.font(38, True), white, width)
        self._center_text(draw, height - 140, "DiamondMind 公開紀錄", self.font(20, True), muted, width)
        return self._export(image)


class SocialReelRenderer:
    def __init__(self, card_renderer: SocialCardRenderer, cache_dir: str | None = None):
        self.card_renderer = card_renderer
        self.cache_dir = Path(cache_dir or "/tmp/diamondmind-social-reels")
        self.cache_dir.mkdir(parents=True, exist_ok=True)

    @staticmethod
    def _ffmpeg_executable() -> str:
        try:
            import imageio_ffmpeg
            return imageio_ffmpeg.get_ffmpeg_exe()
        except (ImportError, RuntimeError, OSError):
            executable = shutil.which("ffmpeg")
            if executable:
                return executable
        raise SocialPublishingError("找不到 FFmpeg，無法產生 Instagram Reel。")

    @staticmethod
    def payload_digest(payload: dict[str, Any]) -> str:
        normalized = json.dumps(payload, ensure_ascii=False, sort_keys=True, default=str, separators=(",", ":"))
        return hashlib.sha256(normalized.encode("utf-8")).hexdigest()[:16]

    def output_path(self, spec: SocialReelSpec, payload: dict[str, Any]) -> Path:
        spec = spec.validated()
        digest = self.payload_digest(payload)
        return self.cache_dir / f"diamondmind-{spec.recommendation_date}-{spec.league}-{digest}.mp4"

    def _write_frame(self, path: Path, content: bytes) -> None:
        path.write_bytes(content)

    def render_to_file(self, spec: SocialReelSpec, payload: dict[str, Any]) -> Path:
        spec = spec.validated()
        output_path = self.output_path(spec, payload)
        if output_path.exists() and output_path.stat().st_size > 50_000:
            return output_path

        items = [item for item in payload.get("items") or [] if isinstance(item, dict)]
        max_results = max(1, min(int(payload.get("max_cards") or 30), 100))
        items = items[:max_results]
        free_items = [item for item in items if str(item.get("source") or "").lower() == "free"]
        pro_items = [item for item in items if str(item.get("source") or "").lower() != "free"]
        batch_size = max(1, min(int(payload.get("result_batch_size") or 5), 5))
        pro_batches = [pro_items[index:index + batch_size] for index in range(0, len(pro_items), batch_size)]
        summary_spec = SocialAssetSpec("pro", "result", "story", spec.recommendation_date, spec.league)

        with tempfile.TemporaryDirectory(prefix="diamondmind-reel-") as temp_dir_name:
            temp_dir = Path(temp_dir_name)
            frames: list[Path] = []

            # The free pick remains its own result frame, matching the separate
            # pregame Story. Pro results are grouped five per frame.
            for free_index, item in enumerate(free_items, start=1):
                frame = temp_dir / f"frame-free-{free_index:02d}.jpg"
                self._write_frame(
                    frame,
                    self.card_renderer.render_result_card(spec, item, index=free_index, total=len(free_items)),
                )
                frames.append(frame)

            for page, batch in enumerate(pro_batches, start=1):
                frame = temp_dir / f"frame-pro-{page:02d}.jpg"
                self._write_frame(
                    frame,
                    self.card_renderer.render_result_batch_card(
                        spec,
                        batch,
                        page=page,
                        total_pages=max(1, len(pro_batches)),
                        item_offset=(page - 1) * batch_size,
                    ),
                )
                frames.append(frame)

            summary_frame = temp_dir / "frame-summary.jpg"
            self._write_frame(summary_frame, self.card_renderer.render(summary_spec, payload))
            frames.append(summary_frame)

            ffmpeg = self._ffmpeg_executable()
            single_seconds = max(1.4, min(float(payload.get("card_seconds") or 2.2), 5.0))
            batch_seconds = max(2.4, min(float(payload.get("batch_seconds") or 3.2), 6.0))
            summary_seconds = max(3.0, min(float(payload.get("summary_seconds") or 4.5), 9.0))
            durations = ([single_seconds] * len(free_items)) + ([batch_seconds] * len(pro_batches)) + [summary_seconds]
            fps = 30

            # V19.1.4 adds restrained motion and transitions without building a
            # large xfade graph. Each still becomes a short H.264 clip with a
            # subtle Ken Burns push/pan plus a brief fade. The clips are then
            # concatenated and the brand audio is added in one final pass. This
            # remains memory-safe on Render even when there are many result pages.
            transition_seconds = max(0.18, min(float(payload.get("transition_seconds") or 0.32), 0.60))
            motion_zoom = max(1.025, min(float(payload.get("motion_zoom") or 1.055), 1.10))
            clip_files: list[Path] = []

            for clip_index, (frame, duration) in enumerate(zip(frames, durations)):
                clip_path = temp_dir / f"clip-{clip_index:02d}.mp4"
                clip_files.append(clip_path)
                fade_duration = min(transition_seconds, max(0.12, duration / 4.0))
                fade_out_start = max(0.0, duration - fade_duration)
                total_frames = max(1, int(round(duration * fps)))
                denominator = max(1, total_frames - 1)
                zoom_step = max(0.00005, (motion_zoom - 1.0) / denominator)

                # Alternate the pan direction so consecutive cards do not feel
                # identical. The summary uses a slower centered push-in.
                is_summary = clip_index == len(frames) - 1
                if is_summary:
                    zoom_expr = f"min(zoom+{zoom_step * 0.55:.8f},{motion_zoom:.5f})"
                    x_expr = "iw/2-(iw/zoom/2)"
                    y_expr = "ih/2-(ih/zoom/2)"
                elif clip_index % 2 == 0:
                    zoom_expr = f"min(zoom+{zoom_step:.8f},{motion_zoom:.5f})"
                    x_expr = f"(iw-iw/zoom)*on/{denominator}"
                    y_expr = "ih/2-(ih/zoom/2)"
                else:
                    zoom_expr = f"min(zoom+{zoom_step:.8f},{motion_zoom:.5f})"
                    x_expr = f"(iw-iw/zoom)*(1-on/{denominator})"
                    y_expr = "ih/2-(ih/zoom/2)"

                clip_filter = (
                    "scale=1200:2134:force_original_aspect_ratio=increase,"
                    "crop=1200:2134,setsar=1,"
                    f"zoompan=z='{zoom_expr}':x='{x_expr}':y='{y_expr}':"
                    f"d=1:s=1080x1920:fps={fps},"
                    f"fade=t=in:st=0:d={fade_duration:.3f},"
                    f"fade=t=out:st={fade_out_start:.3f}:d={fade_duration:.3f},"
                    "format=yuv420p"
                )
                clip_command = [
                    ffmpeg, "-y", "-hide_banner", "-loglevel", "error",
                    "-loop", "1", "-framerate", str(fps), "-i", str(frame),
                    "-t", f"{duration:.3f}", "-vf", clip_filter,
                    "-an", "-c:v", "libx264", "-preset", "veryfast",
                    "-crf", "21", "-pix_fmt", "yuv420p", "-g", str(fps),
                    "-keyint_min", str(fps), "-sc_threshold", "0", str(clip_path),
                ]
                try:
                    clip_completed = subprocess.run(
                        clip_command, capture_output=True, text=True, timeout=120, check=False
                    )
                except (OSError, subprocess.SubprocessError) as exc:
                    raise SocialPublishingError(f"Reel 轉場片段產生失敗：{type(exc).__name__}") from exc
                if clip_completed.returncode != 0 or not clip_path.exists():
                    detail = (clip_completed.stderr or clip_completed.stdout or "FFmpeg clip failed").strip()[-700:]
                    raise SocialPublishingError(f"Reel 轉場片段產生失敗：{detail}")

            concat_file = temp_dir / "clips.txt"
            concat_lines: list[str] = []
            for clip in clip_files:
                escaped = str(clip).replace("'", "'\''")
                concat_lines.append(f"file '{escaped}'")
            concat_file.write_text("\n".join(concat_lines) + "\n", encoding="utf-8")

            silent_video = temp_dir / "reel-silent.mp4"
            concat_command = [
                ffmpeg, "-y", "-hide_banner", "-loglevel", "error",
                "-f", "concat", "-safe", "0", "-i", str(concat_file),
                "-c", "copy", "-movflags", "+faststart", str(silent_video),
            ]
            concat_completed = subprocess.run(
                concat_command, capture_output=True, text=True, timeout=180, check=False
            )
            if concat_completed.returncode != 0 or not silent_video.exists():
                detail = (concat_completed.stderr or concat_completed.stdout or "FFmpeg concat failed").strip()[-700:]
                raise SocialPublishingError(f"Reel 轉場合併失敗：{detail}")

            temp_output = temp_dir / "reel.mp4"
            total_duration = max(1.0, sum(durations))
            audio_enabled = bool(payload.get("audio_enabled", True))
            command: list[str] = [
                ffmpeg, "-y", "-hide_banner", "-loglevel", "error",
                "-i", str(silent_video),
            ]
            if audio_enabled:
                fade_out_start = max(0.0, total_duration - 0.9)
                command.extend([
                    "-f", "lavfi", "-t", f"{total_duration:.3f}",
                    "-i", "sine=frequency=88:sample_rate=44100",
                    "-filter_complex",
                    f"[1:a]volume=0.028,tremolo=f=2:d=0.82,"
                    f"afade=t=in:st=0:d=0.45,"
                    f"afade=t=out:st={fade_out_start:.3f}:d=0.9[a]",
                    "-map", "0:v:0", "-map", "[a]",
                    "-c:v", "copy", "-c:a", "aac", "-b:a", "96k", "-shortest",
                ])
            else:
                command.extend(["-map", "0:v:0", "-c:v", "copy", "-an"])
            command.extend(["-movflags", "+faststart", str(temp_output)])
            try:
                completed = subprocess.run(command, capture_output=True, text=True, timeout=240, check=False)
            except (OSError, subprocess.SubprocessError) as exc:
                raise SocialPublishingError(f"Reel 影片產生失敗：{type(exc).__name__}") from exc
            if completed.returncode != 0 or not temp_output.exists():
                detail = (completed.stderr or completed.stdout or "FFmpeg failed").strip()[-700:]
                raise SocialPublishingError(f"Reel 影片產生失敗：{detail}")
            output_path.parent.mkdir(parents=True, exist_ok=True)
            temp_output.replace(output_path)
        return output_path


class DiamondMindSocialService:
    def __init__(self, settings: Any):
        self.settings = settings
        self.renderer = SocialCardRenderer(
            getattr(settings, "social_font_path", "") or None,
            getattr(settings, "social_logo_path", "") or None,
            getattr(settings, "social_font_url", "") or None,
            getattr(settings, "social_font_bold_path", "") or None,
            getattr(settings, "social_font_bold_url", "") or None,
        )
        self.reel_renderer = SocialReelRenderer(
            self.renderer,
            getattr(settings, "social_reel_cache_dir", "") or None,
        )
        self.client = httpx.AsyncClient(
            timeout=httpx.Timeout(max(15.0, float(getattr(settings, "request_timeout_seconds", 12.0)) * 2.0)),
            follow_redirects=True,
            trust_env=False,
        )

    async def aclose(self) -> None:
        await self.client.aclose()

    @property
    def asset_secret(self) -> str:
        return str(getattr(self.settings, "instagram_asset_secret", "") or getattr(self.settings, "cron_secret", "")).strip()

    @property
    def missing_configuration(self) -> list[str]:
        missing: list[str] = []
        if not str(getattr(self.settings, "instagram_user_id", "")).strip():
            missing.append("INSTAGRAM_USER_ID")
        if not str(getattr(self.settings, "instagram_access_token", "")).strip():
            missing.append("INSTAGRAM_ACCESS_TOKEN")
        if not self.asset_secret:
            missing.append("INSTAGRAM_ASSET_SECRET")
        if not str(getattr(self.settings, "public_api_base", "")).strip():
            missing.append("PUBLIC_API_BASE")
        return missing

    @property
    def configured(self) -> bool:
        return not self.missing_configuration

    @property
    def enabled(self) -> bool:
        return bool(getattr(self.settings, "instagram_auto_publish_enabled", False) and self.configured)

    def status(self) -> dict[str, Any]:
        requested = bool(getattr(self.settings, "instagram_auto_publish_enabled", False))
        return {
            "requested": requested,
            "enabled": self.enabled,
            "configured": self.configured,
            "missing_configuration": self.missing_configuration,
            "graph_version": str(getattr(self.settings, "instagram_graph_version", "v25.0")),
            "graph_base": str(getattr(self.settings, "instagram_graph_base", "https://graph.facebook.com")),
            "account_id_configured": bool(str(getattr(self.settings, "instagram_user_id", "")).strip()),
            "token_configured": bool(str(getattr(self.settings, "instagram_access_token", "")).strip()),
            "destinations": {
                "pregame_story": bool(getattr(self.settings, "instagram_publish_story", True)),
                "result_reel": bool(getattr(self.settings, "instagram_publish_result_reels", True)),
                "auto_comment": bool(getattr(self.settings, "instagram_auto_comment", True)),
            },
            "policy": {
                "free_pregame": bool(getattr(self.settings, "instagram_post_free_pregame", True)),
                "free_result": False,
                "pro_teaser": bool(getattr(self.settings, "instagram_post_pro_teaser", True)),
                "pro_result": bool(getattr(self.settings, "instagram_post_pro_result", True)),
                "free_pick_is_separate_post": True,
                "free_pick_direction_is_public": True,
                "pro_batch_size": int(getattr(self.settings, "instagram_pro_batch_size", 5)),
                "pro_picks_hidden_before_settlement": True,
                "automatic_leagues": [
                    league
                    for league, enabled in (
                        ("MLB", bool(getattr(self.settings, "instagram_auto_mlb_enabled", True))),
                        ("NPB", bool(getattr(self.settings, "instagram_auto_npb_enabled", True))),
                    )
                    if enabled
                ],
                "pregame_destination": "story_only",
                "result_destination": "reel_and_feed",
                "result_auto_comment": bool(getattr(self.settings, "instagram_auto_comment", True)),
                "result_brand_audio": bool(getattr(self.settings, "instagram_reel_audio_enabled", True)),
                "result_layout": "free_single_then_pro_five_per_frame_then_summary",
                "summary_primary_metric": "today_win_rate",
            },
        }

    def sign_asset(self, spec: SocialAssetSpec, expires: int) -> str:
        message = f"{spec.signing_value}|{int(expires)}".encode("utf-8")
        return hmac.new(self.asset_secret.encode("utf-8"), message, hashlib.sha256).hexdigest()

    def verify_asset(self, spec: SocialAssetSpec, expires: int, signature: str) -> bool:
        if not self.asset_secret or int(expires) < int(datetime.now(timezone.utc).timestamp()):
            return False
        expected = self.sign_asset(spec, int(expires))
        return bool(signature and hmac.compare_digest(expected, str(signature)))

    def asset_url(self, spec: SocialAssetSpec, *, lifetime_seconds: int = 1800) -> str:
        spec = spec.validated()
        expires = int(datetime.now(timezone.utc).timestamp()) + max(300, min(int(lifetime_seconds), 86400))
        signature = self.sign_asset(spec, expires)
        base = str(getattr(self.settings, "public_api_base", "")).rstrip("/")
        prefix = str(getattr(self.settings, "api_prefix", "/api/v1"))
        path = f"{prefix}/social/assets/{spec.source}/{spec.recommendation_date}/{spec.league}/{spec.phase}/{spec.size}.jpg"
        return f"{base}{path}?{urlencode({'page': spec.page, 'expires': expires, 'signature': signature})}"

    def sign_reel(self, spec: SocialReelSpec, expires: int) -> str:
        message = f"{spec.signing_value}|{int(expires)}".encode("utf-8")
        return hmac.new(self.asset_secret.encode("utf-8"), message, hashlib.sha256).hexdigest()

    def verify_reel(self, spec: SocialReelSpec, expires: int, signature: str) -> bool:
        if not self.asset_secret or int(expires) < int(datetime.now(timezone.utc).timestamp()):
            return False
        expected = self.sign_reel(spec.validated(), int(expires))
        return bool(signature and hmac.compare_digest(expected, str(signature)))

    def reel_url(self, spec: SocialReelSpec, *, lifetime_seconds: int = 3600) -> str:
        spec = spec.validated()
        expires = int(datetime.now(timezone.utc).timestamp()) + max(600, min(int(lifetime_seconds), 86400))
        signature = self.sign_reel(spec, expires)
        base = str(getattr(self.settings, "public_api_base", "")).rstrip("/")
        prefix = str(getattr(self.settings, "api_prefix", "/api/v1"))
        path = f"{prefix}/social/reels/{spec.recommendation_date}/{spec.league}.mp4"
        return f"{base}{path}?{urlencode({'expires': expires, 'signature': signature})}"

    def render(self, spec: SocialAssetSpec, payload: dict[str, Any]) -> bytes:
        return self.renderer.render(spec, payload)

    def render_reel_file(self, spec: SocialReelSpec, payload: dict[str, Any]) -> Path:
        return self.reel_renderer.render_to_file(spec, payload)

    async def _graph_request(self, method: str, path: str, *, data: dict[str, Any] | None = None, params: dict[str, Any] | None = None) -> dict[str, Any]:
        version = str(getattr(self.settings, "instagram_graph_version", "v25.0")).strip().strip("/")
        graph_base = str(getattr(self.settings, "instagram_graph_base", "https://graph.facebook.com")).strip().rstrip("/")
        url = f"{graph_base}/{version}/{path.lstrip('/')}"
        token = str(getattr(self.settings, "instagram_access_token", ""))
        request_data = dict(data or {})
        request_params = dict(params or {})
        if method.upper() == "GET":
            request_params["access_token"] = token
        else:
            request_data["access_token"] = token
        try:
            response = await self.client.request(method, url, data=request_data or None, params=request_params or None)
            payload = response.json()
        except (httpx.HTTPError, ValueError) as exc:
            raise SocialPublishingError(f"Instagram API 連線失敗：{type(exc).__name__}") from exc
        if response.is_error or not isinstance(payload, dict) or payload.get("error"):
            error = payload.get("error") if isinstance(payload, dict) else {}
            message = str((error or {}).get("message") or f"HTTP {response.status_code}")
            code = (error or {}).get("code")
            subcode = (error or {}).get("error_subcode")
            suffix = " / ".join(str(value) for value in (code, subcode) if value is not None)
            raise SocialPublishingError(f"Instagram API 拒絕發佈：{message}{f'（{suffix}）' if suffix else ''}")
        return payload

    async def _wait_for_container(
        self,
        creation_id: str,
        *,
        attempts: int = 10,
        interval_seconds: float = 1.0,
    ) -> dict[str, Any]:
        last: dict[str, Any] = {}
        for _ in range(max(1, attempts)):
            last = await self._graph_request("GET", creation_id, params={"fields": "status_code,status"})
            state = str(last.get("status_code") or "").upper()
            if state in {"FINISHED", "PUBLISHED"}:
                return last
            if state in {"ERROR", "EXPIRED"}:
                raise SocialPublishingError(f"Instagram 媒體處理失敗：{last.get('status') or state}")
            await asyncio.sleep(max(0.5, interval_seconds))
        raise SocialPublishingError("Instagram 媒體處理逾時，稍後會自動重試。")

    async def publish_story(self, image_url: str) -> dict[str, Any]:
        if not self.enabled:
            return {"status": "disabled", "channel": "story"}
        user_id = str(getattr(self.settings, "instagram_user_id", "")).strip()
        container = await self._graph_request(
            "POST",
            f"{user_id}/media",
            data={"image_url": image_url, "media_type": "STORIES"},
        )
        creation_id = str(container.get("id") or "")
        if not creation_id:
            raise SocialPublishingError("Instagram 未回傳限時動態容器編號。")
        await self._wait_for_container(creation_id, attempts=20, interval_seconds=1.0)
        published = await self._graph_request(
            "POST", f"{user_id}/media_publish", data={"creation_id": creation_id}
        )
        media_id = str(published.get("id") or "")
        if not media_id:
            raise SocialPublishingError("Instagram 未回傳限時動態媒體編號。")
        return {
            "status": "published",
            "channel": "story",
            "creation_id": creation_id,
            "media_id": media_id,
            "published_at": utc_now(),
        }

    async def publish_comment(self, media_id: str, message: str) -> dict[str, Any]:
        if not media_id or not message.strip():
            return {"status": "skipped", "reason": "empty_media_or_message"}
        payload = await self._graph_request(
            "POST", f"{media_id}/comments", data={"message": message.strip()}
        )
        comment_id = str(payload.get("id") or "")
        if not comment_id:
            raise SocialPublishingError("Instagram 未回傳留言編號。")
        return {
            "status": "published",
            "channel": "comment",
            "comment_id": comment_id,
            "published_at": utc_now(),
        }

    async def publish_reel(
        self,
        video_url: str,
        caption: str,
        *,
        auto_comment: str | None = None,
    ) -> dict[str, Any]:
        if not self.enabled:
            return {"status": "disabled", "channel": "reel"}
        user_id = str(getattr(self.settings, "instagram_user_id", "")).strip()
        data: dict[str, Any] = {
            "media_type": "REELS",
            "video_url": video_url,
            "caption": caption,
            "share_to_feed": "true" if bool(getattr(self.settings, "instagram_reel_share_to_feed", True)) else "false",
        }
        container = await self._graph_request("POST", f"{user_id}/media", data=data)
        creation_id = str(container.get("id") or "")
        if not creation_id:
            raise SocialPublishingError("Instagram 未回傳 Reel 容器編號。")
        await self._wait_for_container(
            creation_id,
            attempts=max(20, int(getattr(self.settings, "instagram_reel_processing_attempts", 60))),
            interval_seconds=max(1.0, float(getattr(self.settings, "instagram_reel_processing_interval_seconds", 2.0))),
        )
        published = await self._graph_request(
            "POST", f"{user_id}/media_publish", data={"creation_id": creation_id}
        )
        media_id = str(published.get("id") or "")
        if not media_id:
            raise SocialPublishingError("Instagram 未回傳 Reel 媒體編號。")
        result: dict[str, Any] = {
            "status": "published",
            "channel": "reel",
            "creation_id": creation_id,
            "media_id": media_id,
            "published_at": utc_now(),
        }
        if auto_comment and bool(getattr(self.settings, "instagram_auto_comment", True)):
            try:
                result["comment"] = await self.publish_comment(media_id, auto_comment)
            except SocialPublishingError as exc:
                result["comment"] = {"status": "failed", "error": str(exc), "checked_at": utc_now()}
        return result

    def result_comment(self) -> str:
        website = str(getattr(self.settings, "frontend_base_url", "")).strip()
        return (
            "📊 完整推薦紀錄已更新\n"
            f"🔗 點擊個人檔案連結查看：{website}\n"
            "⚾ DiamondMind AI｜理性投注，量力而為"
        )

    async def publish_pair(
        self,
        spec: SocialAssetSpec,
        payload: dict[str, Any],
        *,
        existing_destinations: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Publish according to V19.1 policy.

        Pregame assets are story-only. Settled league results are one Reel that
        is also shown in the profile feed, followed by an automatic comment.
        """
        spec = spec.validated()
        if not self.enabled:
            return {
                "status": "disabled",
                "reason": "not_configured" if not self.configured else "disabled",
                "checked_at": utc_now(),
            }
        destinations: dict[str, Any] = dict(existing_destinations or {})
        errors: list[str] = []

        if spec.phase in {"pregame", "teaser"}:
            if not bool(getattr(self.settings, "instagram_publish_story", True)):
                return {"status": "disabled", "reason": "story_policy", "checked_at": utc_now()}
            story_done = str((destinations.get("story") or {}).get("status") or "") == "published"
            if not story_done:
                try:
                    story_spec = SocialAssetSpec(
                        spec.source, spec.phase, "story", spec.recommendation_date, spec.league, spec.page
                    )
                    destinations["story"] = await self.publish_story(self.asset_url(story_spec))
                except SocialPublishingError as exc:
                    destinations["story"] = {"status": "failed", "error": str(exc), "checked_at": utc_now()}
                    errors.append(str(exc))
            story = destinations.get("story") or {}
            status = "published" if story.get("status") == "published" else "failed"
        else:
            if not bool(getattr(self.settings, "instagram_publish_result_reels", True)):
                return {"status": "disabled", "reason": "reel_policy", "checked_at": utc_now()}
            reel_done = str((destinations.get("reel") or {}).get("status") or "") == "published"
            if not reel_done:
                try:
                    reel_spec = SocialReelSpec(spec.recommendation_date, spec.league)
                    await asyncio.to_thread(self.render_reel_file, reel_spec, payload)
                    website = str(getattr(self.settings, "frontend_base_url", "")).strip()
                    destinations["reel"] = await self.publish_reel(
                        self.reel_url(reel_spec),
                        social_caption(spec, payload, website),
                        auto_comment=self.result_comment(),
                    )
                    comment = (destinations.get("reel") or {}).get("comment")
                    if isinstance(comment, dict):
                        destinations["comment"] = comment
                except SocialPublishingError as exc:
                    destinations["reel"] = {"status": "failed", "error": str(exc), "checked_at": utc_now()}
                    errors.append(str(exc))
            reel = destinations.get("reel") or {}
            reel_ok = reel.get("status") == "published"
            comment_required = bool(getattr(self.settings, "instagram_auto_comment", True))
            comment = destinations.get("comment") or (reel.get("comment") if isinstance(reel, dict) else {}) or {}

            # A Reel may publish successfully while the first comment call fails.
            # Retry only the missing comment on the next scheduler pass instead of
            # creating a duplicate Reel.
            if reel_ok and comment_required and comment.get("status") != "published":
                media_id = str(reel.get("media_id") or "")
                if media_id:
                    try:
                        comment = await self.publish_comment(media_id, self.result_comment())
                    except SocialPublishingError as exc:
                        comment = {"status": "failed", "error": str(exc), "checked_at": utc_now()}
                    destinations["comment"] = comment

            comment_ok = (not comment_required) or comment.get("status") == "published"
            status = "published" if reel_ok and comment_ok else "partial" if reel_ok else "failed"
            if reel_ok and not comment_ok and comment.get("error"):
                errors.append(str(comment.get("error")))

        return {
            "status": status,
            "event": event_key(spec.source, spec.phase, spec.league, spec.page),
            "page": spec.page,
            "destinations": destinations,
            "errors": errors,
            "checked_at": utc_now(),
        }
