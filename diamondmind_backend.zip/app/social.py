from __future__ import annotations

import asyncio
import hashlib
import hmac
import io
import math
import random
import textwrap
from dataclasses import dataclass
from datetime import datetime, timezone
from functools import lru_cache
from pathlib import Path
from typing import Any
from urllib.parse import urlencode

import httpx
from PIL import Image, ImageDraw, ImageFilter, ImageFont


TERMINAL_STATUSES = {"won", "lost", "push", "void"}
ASSET_SOURCES = {"free", "pro"}
ASSET_PHASES = {"pregame", "teaser", "result"}
ASSET_SIZES = {"feed", "story"}


TEAM_ZH = {
    "Arizona Diamondbacks": "亞利桑那響尾蛇",
    "Atlanta Braves": "亞特蘭大勇士",
    "Baltimore Orioles": "巴爾的摩金鶯",
    "Boston Red Sox": "波士頓紅襪",
    "Chicago Cubs": "芝加哥小熊",
    "Chicago White Sox": "芝加哥白襪",
    "Cincinnati Reds": "辛辛那提紅人",
    "Cleveland Guardians": "克里夫蘭守護者",
    "Colorado Rockies": "科羅拉多洛磯",
    "Detroit Tigers": "底特律老虎",
    "Houston Astros": "休士頓太空人",
    "Kansas City Royals": "堪薩斯市皇家",
    "Los Angeles Angels": "洛杉磯天使",
    "Los Angeles Dodgers": "洛杉磯道奇",
    "Miami Marlins": "邁阿密馬林魚",
    "Milwaukee Brewers": "密爾瓦基釀酒人",
    "Minnesota Twins": "明尼蘇達雙城",
    "New York Mets": "紐約大都會",
    "New York Yankees": "紐約洋基",
    "Athletics": "運動家",
    "Oakland Athletics": "奧克蘭運動家",
    "Philadelphia Phillies": "費城費城人",
    "Pittsburgh Pirates": "匹茲堡海盜",
    "San Diego Padres": "聖地牙哥教士",
    "San Francisco Giants": "舊金山巨人",
    "Seattle Mariners": "西雅圖水手",
    "St. Louis Cardinals": "聖路易紅雀",
    "Tampa Bay Rays": "坦帕灣光芒",
    "Texas Rangers": "德州遊騎兵",
    "Toronto Blue Jays": "多倫多藍鳥",
    "Washington Nationals": "華盛頓國民",
    "Tokyo Yakult Swallows": "東京養樂多燕子",
    "Yomiuri Giants": "讀賣巨人",
    "YOKOHAMA DeNA BAYSTARS": "橫濱DeNA海灣之星",
    "Yokohama DeNA BayStars": "橫濱DeNA海灣之星",
    "Chunichi Dragons": "中日龍",
    "Hanshin Tigers": "阪神虎",
    "Hiroshima Toyo Carp": "廣島東洋鯉魚",
    "Fukuoka SoftBank Hawks": "福岡軟銀鷹",
    "Hokkaido Nippon-Ham Fighters": "北海道日本火腿鬥士",
    "ORIX Buffaloes": "歐力士猛牛",
    "Orix Buffaloes": "歐力士猛牛",
    "Tohoku Rakuten Golden Eagles": "東北樂天金鷲",
    "Saitama Seibu Lions": "埼玉西武獅",
    "Chiba Lotte Marines": "千葉羅德海洋",
    "American League All-Stars": "美聯明星隊",
    "National League All-Stars": "國聯明星隊",
    "Central League All-Stars": "中央聯盟明星隊",
    "Pacific League All-Stars": "太平洋聯盟明星隊",
}

TEAM_ZH_BY_ABBR = {
    "ARI": "亞利桑那響尾蛇", "ATL": "亞特蘭大勇士", "BAL": "巴爾的摩金鶯",
    "BOS": "波士頓紅襪", "CHC": "芝加哥小熊", "CWS": "芝加哥白襪",
    "CIN": "辛辛那提紅人", "CLE": "克里夫蘭守護者", "COL": "科羅拉多洛磯",
    "DET": "底特律老虎", "HOU": "休士頓太空人", "KC": "堪薩斯市皇家",
    "KCR": "堪薩斯市皇家", "LAA": "洛杉磯天使", "LAD": "洛杉磯道奇",
    "MIA": "邁阿密馬林魚", "MIL": "密爾瓦基釀酒人", "MIN": "明尼蘇達雙城",
    "NYM": "紐約大都會", "NYY": "紐約洋基", "ATH": "運動家", "OAK": "奧克蘭運動家",
    "PHI": "費城費城人", "PIT": "匹茲堡海盜", "SD": "聖地牙哥教士",
    "SDP": "聖地牙哥教士", "SF": "舊金山巨人", "SFG": "舊金山巨人",
    "SEA": "西雅圖水手", "STL": "聖路易紅雀", "TB": "坦帕灣光芒",
    "TBR": "坦帕灣光芒", "TEX": "德州遊騎兵", "TOR": "多倫多藍鳥",
    "WSH": "華盛頓國民", "WSN": "華盛頓國民", "AL": "美聯明星隊",
    "NL": "國聯明星隊", "S": "東京養樂多燕子", "G": "讀賣巨人",
    "DB": "橫濱DeNA海灣之星", "D": "中日龍", "T": "阪神虎",
    "C": "廣島東洋鯉魚", "H": "福岡軟銀鷹", "F": "北海道日本火腿鬥士",
    "B": "歐力士猛牛", "E": "東北樂天金鷲", "L": "埼玉西武獅",
    "M": "千葉羅德海洋", "CL": "中央聯盟明星隊", "PL": "太平洋聯盟明星隊",
}


class SocialPublishingError(RuntimeError):
    pass


@dataclass(frozen=True)
class SocialAssetSpec:
    source: str
    phase: str
    size: str
    recommendation_date: str
    league: str

    def validated(self) -> "SocialAssetSpec":
        source = self.source.lower()
        phase = self.phase.lower()
        size = self.size.lower()
        league = self.league.upper()
        if source not in ASSET_SOURCES:
            raise ValueError("Unsupported social asset source")
        if phase not in ASSET_PHASES:
            raise ValueError("Unsupported social asset phase")
        if size not in ASSET_SIZES:
            raise ValueError("Unsupported social asset size")
        if league not in {"MLB", "NPB", "ALL"}:
            raise ValueError("Unsupported social asset league")
        datetime.strptime(self.recommendation_date, "%Y-%m-%d")
        return SocialAssetSpec(source, phase, size, self.recommendation_date, league)

    @property
    def signing_value(self) -> str:
        item = self.validated()
        return "|".join((item.source, item.phase, item.size, item.recommendation_date, item.league))


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def display_team(value: Any, abbr: Any = None) -> str:
    name = str(value or "").strip()
    short = str(abbr or "").strip().upper()
    return TEAM_ZH.get(name) or TEAM_ZH_BY_ABBR.get(short) or TEAM_ZH_BY_ABBR.get(name.upper()) or name or short or "待確認"


def decimal_price(value: Any) -> float | None:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    if 1.0 < number < 20.0:
        return round(number, 2)
    if number >= 100:
        return round(1.0 + number / 100.0, 2)
    if number <= -100:
        return round(1.0 + 100.0 / abs(number), 2)
    return None


def status_label(value: Any) -> str:
    return {
        "won": "命中",
        "lost": "未中",
        "push": "走水",
        "void": "作廢",
        "pending": "等待賽果",
        "live": "比賽進行中",
    }.get(str(value or "pending").lower(), "等待賽果")


def result_icon(value: Any) -> str:
    return {"won": "✓", "lost": "×", "push": "—", "void": "—"}.get(str(value or "").lower(), "•")


def normalize_market_label(value: Any) -> str:
    return {
        "moneyline": "獨贏",
        "moneylines": "獨贏",
        "run_line": "讓分",
        "run_lines": "讓分",
        "totals": "大小分",
        "two_leg": "二關串關",
        "three_leg": "三關串關",
    }.get(str(value or "").lower(), str(value or "推薦方向"))


def compact_pick_label(payload: dict[str, Any]) -> str:
    raw = str(payload.get("pick_label") or "").strip()
    market = str(payload.get("market") or "").lower()
    team = display_team(payload.get("pick_team_name"), payload.get("pick_team_abbr"))
    line = payload.get("line")
    side = str(payload.get("side") or "").lower()
    if market in {"moneyline", "moneylines"} and team != "待確認":
        return f"{team} 獨贏"
    if market in {"run_line", "run_lines"} and team != "待確認":
        suffix = ""
        try:
            number = float(line)
            suffix = f" {number:+g}"
        except (TypeError, ValueError):
            pass
        return f"{team}{suffix}"
    if market == "totals":
        direction = "大分" if side == "over" else "小分" if side == "under" else "大小分"
        return f"{direction} {line:g}" if isinstance(line, (int, float)) else direction
    return raw or normalize_market_label(market)


def event_key(source: str, phase: str, league: str) -> str:
    return f"{source.lower()}_{phase.lower()}_{league.upper()}"


def social_caption(spec: SocialAssetSpec, payload: dict[str, Any], website: str) -> str:
    spec = spec.validated()
    date_text = spec.recommendation_date.replace("-", "/")
    league = "MLB＋NPB" if spec.league == "ALL" else spec.league
    tags = "#DiamondMind #棒球分析 #AI預測"
    if spec.league == "MLB":
        tags += " #MLB"
    elif spec.league == "NPB":
        tags += " #NPB #日本職棒"
    else:
        tags += " #MLB #NPB"

    if spec.source == "free" and spec.phase == "pregame":
        matchup = str(payload.get("matchup") or "今日賽事")
        pick = compact_pick_label(payload)
        confidence = payload.get("confidence")
        confidence_text = f"\n模型信心：{float(confidence):.0f}%" if confidence is not None else ""
        return (
            f"⚾ {date_text}｜{league} 每日免費推薦\n\n"
            f"{matchup}\n推薦方向：{pick}{confidence_text}\n\n"
            f"完整數據與賽後紀錄：{website}\n\n{tags} #每日免費推薦"
        )
    if spec.source == "free" and spec.phase == "result":
        status = str(payload.get("status") or "pending").lower()
        score = payload.get("score")
        score_text = f"\n最終比分：{score}" if score else ""
        return (
            f"{result_icon(status)} {date_text}｜{league} 每日免費推薦賽果\n\n"
            f"{payload.get('matchup') or '今日賽事'}\n"
            f"推薦方向：{compact_pick_label(payload)}\n"
            f"結果：{status_label(status)}{score_text}\n\n"
            f"所有推薦皆保留公開紀錄：{website}\n\n{tags} #賽果"
        )
    if spec.source == "pro" and spec.phase == "teaser":
        counts = payload.get("counts") or {}
        total = int(counts.get("total") or 0)
        return (
            f"🔒 {date_text}｜{league} Pro 推薦已正式發布\n\n"
            f"今日共 {total} 項正式玩法，賽前不公開付費會員選項。\n"
            f"Pro 會員登入後即可查看完整推薦：{website}\n\n{tags} #DiamondMindPro"
        )

    summary = payload.get("summary") or {}
    return (
        f"📊 {date_text}｜{league} Pro 賽果\n\n"
        f"命中 {int(summary.get('won') or 0)}｜未中 {int(summary.get('lost') or 0)}｜"
        f"走水／作廢 {int(summary.get('neutral') or 0)}\n"
        f"完整推薦與結果皆已更新：{website}\n\n{tags} #DiamondMindPro #賽果"
    )


class SocialCardRenderer:
    def __init__(self, font_path: str | None = None, logo_path: str | None = None):
        asset_dir = Path(__file__).resolve().parent / "assets"
        self.font_path = Path(font_path).expanduser() if font_path else asset_dir / "NotoSansTC.ttf"
        self.logo_path = Path(logo_path).expanduser() if logo_path else asset_dir / "diamondmind-logo.png"
        self._logo: Image.Image | None = None

    @lru_cache(maxsize=96)
    def font(self, size: int, bold: bool = False) -> ImageFont.ImageFont:
        candidates = [
            self.font_path,
            Path("/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"),
            Path("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"),
        ]
        for candidate in candidates:
            if not candidate or not candidate.exists():
                continue
            try:
                font = ImageFont.truetype(str(candidate), size=size)
                if bold and hasattr(font, "set_variation_by_axes"):
                    try:
                        font.set_variation_by_axes([700])
                    except (OSError, TypeError, ValueError):
                        pass
                elif not bold and hasattr(font, "set_variation_by_axes"):
                    try:
                        font.set_variation_by_axes([400])
                    except (OSError, TypeError, ValueError):
                        pass
                return font
            except OSError:
                continue
        return ImageFont.load_default()

    def logo(self) -> Image.Image | None:
        if self._logo is None and self.logo_path.exists():
            try:
                self._logo = Image.open(self.logo_path).convert("RGBA")
            except OSError:
                self._logo = None
        return self._logo.copy() if self._logo is not None else None

    @staticmethod
    def _measure(draw: ImageDraw.ImageDraw, text: str, font: ImageFont.ImageFont) -> float:
        box = draw.textbbox((0, 0), text, font=font)
        return float(box[2] - box[0])

    def _fit_font(self, draw: ImageDraw.ImageDraw, text: str, width: int, preferred: int, minimum: int, bold: bool = False) -> ImageFont.ImageFont:
        for size in range(preferred, minimum - 1, -2):
            font = self.font(size, bold)
            if self._measure(draw, text, font) <= width:
                return font
        return self.font(minimum, bold)

    def _center_text(self, draw: ImageDraw.ImageDraw, y: int, text: str, font: ImageFont.ImageFont, fill: tuple[int, int, int, int] | str, width: int) -> int:
        box = draw.textbbox((0, 0), text, font=font)
        x = int((width - (box[2] - box[0])) / 2)
        draw.text((x, y), text, font=font, fill=fill)
        return int(box[3] - box[1])

    def _background(self, width: int, height: int, seed: str) -> Image.Image:
        top = (3, 12, 19)
        bottom = (1, 5, 10)
        gradient = Image.new("RGB", (1, height))
        pixels = gradient.load()
        for y in range(height):
            ratio = y / max(1, height - 1)
            pixels[0, y] = tuple(int(top[i] * (1 - ratio) + bottom[i] * ratio) for i in range(3))
        image = gradient.resize((width, height)).convert("RGBA")

        glow = Image.new("RGBA", image.size, (0, 0, 0, 0))
        glow_draw = ImageDraw.Draw(glow)
        glow_draw.ellipse((width * 0.42, -height * 0.12, width * 1.18, height * 0.34), fill=(118, 255, 39, 70))
        glow_draw.ellipse((-width * 0.42, height * 0.50, width * 0.42, height * 1.12), fill=(0, 196, 255, 42))
        glow = glow.filter(ImageFilter.GaussianBlur(radius=max(width, height) // 9))
        image = Image.alpha_composite(image, glow)

        rng = random.Random(hashlib.sha256(seed.encode("utf-8")).digest())
        stars = Image.new("RGBA", image.size, (0, 0, 0, 0))
        star_draw = ImageDraw.Draw(stars)
        for _ in range(110 if height > width else 75):
            x = rng.randrange(24, max(25, width - 24))
            y = rng.randrange(24, max(25, height - 24))
            radius = rng.choice((1, 1, 1, 2))
            alpha = rng.randrange(35, 125)
            star_draw.ellipse((x - radius, y - radius, x + radius, y + radius), fill=(190, 255, 221, alpha))
        return Image.alpha_composite(image, stars)

    def _glass_panel(self, image: Image.Image, box: tuple[int, int, int, int], accent: tuple[int, int, int, int] = (104, 255, 74, 160)) -> None:
        overlay = Image.new("RGBA", image.size, (0, 0, 0, 0))
        draw = ImageDraw.Draw(overlay)
        draw.rounded_rectangle(box, radius=34, fill=(6, 21, 28, 220), outline=(255, 255, 255, 24), width=2)
        x1, y1, x2, _y2 = box
        draw.rounded_rectangle((x1 + 2, y1 + 2, x2 - 2, y1 + 10), radius=5, fill=accent)
        image.alpha_composite(overlay)

    def render(self, spec: SocialAssetSpec, payload: dict[str, Any]) -> bytes:
        spec = spec.validated()
        width, height = (1080, 1920) if spec.size == "story" else (1080, 1350)
        image = self._background(width, height, spec.signing_value)
        draw = ImageDraw.Draw(image)
        green = (185, 255, 54, 255)
        white = (242, 249, 246, 255)
        muted = (157, 178, 184, 255)
        gold = (255, 215, 106, 255)
        red = (255, 110, 126, 255)
        margin = 74
        safe_top = 150 if spec.size == "story" else 70
        safe_bottom = 230 if spec.size == "story" else 70

        logo = self.logo()
        if logo is not None:
            logo_size = 128 if spec.size == "story" else 104
            logo.thumbnail((logo_size, logo_size), Image.Resampling.LANCZOS)
            image.alpha_composite(logo, (margin, safe_top))
        brand_x = margin + (154 if spec.size == "story" else 126)
        draw.text((brand_x, safe_top + 12), "DIAMONDMIND", font=self.font(38 if spec.size == "story" else 32, True), fill=white)
        draw.text((brand_x, safe_top + 62), "GRAND SLAM AI · BASEBALL INTELLIGENCE", font=self.font(17 if spec.size == "story" else 15), fill=muted)
        draw.line((margin, safe_top + (142 if spec.size == "story" else 118), width - margin, safe_top + (142 if spec.size == "story" else 118)), fill=(105, 158, 48, 255), width=2)

        badge_text = (
            "每日免費推薦" if spec.source == "free" and spec.phase == "pregame"
            else "每日免費推薦 · 賽果" if spec.source == "free"
            else "PRO 已正式發布" if spec.phase == "teaser"
            else "PRO 賽果"
        )
        badge_y = safe_top + (196 if spec.size == "story" else 160)
        badge_font = self.font(24 if spec.size == "story" else 21, True)
        badge_w = int(self._measure(draw, badge_text, badge_font)) + 48
        draw.rounded_rectangle((margin, badge_y, margin + badge_w, badge_y + 52), radius=26, fill=(20, 49, 27, 255), outline=(130, 206, 49, 255), width=2)
        draw.text((margin + 24, badge_y + 9), badge_text, font=badge_font, fill=green)
        date_text = spec.recommendation_date.replace("-", ".")
        league_text = "MLB＋NPB" if spec.league == "ALL" else spec.league
        meta = f"{date_text}  ·  {league_text}"
        meta_font = self.font(22 if spec.size == "story" else 19, True)
        draw.text((width - margin - self._measure(draw, meta, meta_font), badge_y + 11), meta, font=meta_font, fill=muted)

        title_y = badge_y + (112 if spec.size == "story" else 92)
        if spec.source == "free":
            matchup = str(payload.get("matchup") or "今日精選賽事")
            title_font = self._fit_font(draw, matchup, width - margin * 2, 57 if spec.size == "story" else 48, 30, True)
            self._center_text(draw, title_y, matchup, title_font, white, width)
            sub_text = "賽前模型正式推薦" if spec.phase == "pregame" else "官方最終賽果已完成結算"
        elif spec.phase == "teaser":
            title_font = self.font(65 if spec.size == "story" else 54, True)
            self._center_text(draw, title_y, f"{league_text} PRO 已上線", title_font, white, width)
            sub_text = "正式推薦已鎖定 · 付費選項不會在賽前公開"
        else:
            title_font = self.font(65 if spec.size == "story" else 54, True)
            self._center_text(draw, title_y, "今日 PRO 戰績", title_font, white, width)
            sub_text = "所有正式推薦已完成賽後結算"
        self._center_text(draw, title_y + (84 if spec.size == "story" else 70), sub_text, self.font(24 if spec.size == "story" else 21), muted, width)

        panel_top = title_y + (162 if spec.size == "story" else 135)
        panel_bottom = height - safe_bottom - (185 if spec.size == "story" else 135)
        self._glass_panel(image, (margin, panel_top, width - margin, panel_bottom))
        draw = ImageDraw.Draw(image)

        if spec.source == "free":
            self._render_free_panel(draw, spec, payload, (margin, panel_top, width - margin, panel_bottom), green, white, muted, gold, red)
        elif spec.phase == "teaser":
            self._render_pro_teaser(draw, spec, payload, (margin, panel_top, width - margin, panel_bottom), green, white, muted, gold)
        else:
            self._render_pro_result(draw, spec, payload, (margin, panel_top, width - margin, panel_bottom), green, white, muted, gold, red)

        footer_y = panel_bottom + (72 if spec.size == "story" else 54)
        footer_font = self.font(22 if spec.size == "story" else 19, True)
        self._center_text(draw, footer_y, "完整分析與公開紀錄 · DiamondMind", footer_font, green, width)
        note = "模型資訊僅供研究參考，不保證任何賽果；請遵守所在地法律並理性判斷。"
        note_font = self.font(17 if spec.size == "story" else 15)
        self._center_text(draw, footer_y + 46, note, note_font, muted, width)

        output = io.BytesIO()
        image.convert("RGB").save(output, format="JPEG", quality=94, optimize=True, progressive=True)
        return output.getvalue()

    def _render_free_panel(self, draw: ImageDraw.ImageDraw, spec: SocialAssetSpec, payload: dict[str, Any], box: tuple[int, int, int, int], green: tuple, white: tuple, muted: tuple, gold: tuple, red: tuple) -> None:
        x1, y1, x2, y2 = box
        content_w = x2 - x1 - 100
        y = y1 + 70
        draw.text((x1 + 50, y), "推薦方向", font=self.font(23, True), fill=muted)
        pick = compact_pick_label(payload)
        pick_font = self._fit_font(draw, pick, content_w, 66 if spec.size == "story" else 55, 30, True)
        draw.text((x1 + 50, y + 44), pick, font=pick_font, fill=white)
        y += 154 if spec.size == "story" else 130
        draw.line((x1 + 50, y, x2 - 50, y), fill=(52, 68, 72, 255), width=2)
        y += 48

        if spec.phase == "pregame":
            confidence = payload.get("confidence")
            price = decimal_price(payload.get("price"))
            left = f"{float(confidence):.0f}%" if confidence is not None else "—"
            right = f"{price:.2f}" if price else "—"
            draw.text((x1 + 50, y), "模型信心", font=self.font(22, True), fill=muted)
            draw.text((x1 + 50, y + 38), left, font=self.font(67 if spec.size == "story" else 54, True), fill=green)
            right_w = self._measure(draw, right, self.font(58 if spec.size == "story" else 48, True))
            draw.text((x2 - 50 - right_w, y + 45), right, font=self.font(58 if spec.size == "story" else 48, True), fill=gold)
            label_w = self._measure(draw, "台灣小數賠率", self.font(22, True))
            draw.text((x2 - 50 - label_w, y), "台灣小數賠率", font=self.font(22, True), fill=muted)
            detail = str(payload.get("time_label") or payload.get("venue") or "正式發布後推薦永久鎖定")
            y = min(y2 - 120, y + (170 if spec.size == "story" else 140))
            detail_font = self._fit_font(draw, detail, content_w, 24, 17)
            draw.text((x1 + 50, y), detail, font=detail_font, fill=muted)
            return

        status = str(payload.get("status") or "pending").lower()
        color = green if status == "won" else red if status == "lost" else gold
        label = status_label(status)
        score = str(payload.get("score") or "官方最終比分")
        draw.text((x1 + 50, y), "推薦結果", font=self.font(22, True), fill=muted)
        draw.text((x1 + 50, y + 42), f"{result_icon(status)} {label}", font=self.font(76 if spec.size == "story" else 62, True), fill=color)
        score_font = self._fit_font(draw, score, content_w, 42 if spec.size == "story" else 35, 22, True)
        draw.text((x1 + 50, min(y2 - 105, y + 165)), score, font=score_font, fill=white)

    def _render_pro_teaser(self, draw: ImageDraw.ImageDraw, spec: SocialAssetSpec, payload: dict[str, Any], box: tuple[int, int, int, int], green: tuple, white: tuple, muted: tuple, gold: tuple) -> None:
        x1, y1, x2, y2 = box
        counts = payload.get("counts") or {}
        rows = [
            ("獨贏精選", int(counts.get("moneylines") or 0)),
            ("讓分精選", int(counts.get("run_lines") or 0)),
            ("大小分精選", int(counts.get("totals") or 0)),
            ("二／三關串關", int(counts.get("parlays") or 0)),
        ]
        y = y1 + 55
        for index, (label, count) in enumerate(rows):
            row_y = y + index * (118 if spec.size == "story" else 94)
            draw.rounded_rectangle((x1 + 45, row_y, x2 - 45, row_y + (88 if spec.size == "story" else 72)), radius=20, fill=(10, 31, 38, 255), outline=(44, 63, 68, 255), width=1)
            draw.text((x1 + 72, row_y + (25 if spec.size == "story" else 18)), label, font=self.font(27 if spec.size == "story" else 23, True), fill=white)
            count_text = str(count)
            count_font = self.font(38 if spec.size == "story" else 32, True)
            draw.text((x2 - 75 - self._measure(draw, count_text, count_font), row_y + (18 if spec.size == "story" else 13)), count_text, font=count_font, fill=green if count else muted)
        total = int(counts.get("total") or sum(item[1] for item in rows))
        total_y = min(y2 - 105, y + len(rows) * (118 if spec.size == "story" else 94) + 28)
        draw.text((x1 + 50, total_y), f"今日共 {total} 項正式玩法", font=self.font(31 if spec.size == "story" else 27, True), fill=gold)

    def _render_pro_result(self, draw: ImageDraw.ImageDraw, spec: SocialAssetSpec, payload: dict[str, Any], box: tuple[int, int, int, int], green: tuple, white: tuple, muted: tuple, gold: tuple, red: tuple) -> None:
        x1, y1, x2, y2 = box
        summary = payload.get("summary") or {}
        stats = [
            ("命中", int(summary.get("won") or 0), green),
            ("未中", int(summary.get("lost") or 0), red),
            ("走水／作廢", int(summary.get("neutral") or 0), gold),
        ]
        col_w = (x2 - x1 - 120) / 3
        for index, (label, count, color) in enumerate(stats):
            cx = x1 + 50 + index * col_w
            draw.text((cx, y1 + 52), label, font=self.font(21 if spec.size == "story" else 18, True), fill=muted)
            draw.text((cx, y1 + 88), str(count), font=self.font(63 if spec.size == "story" else 50, True), fill=color)
        separator_y = y1 + (180 if spec.size == "story" else 150)
        draw.line((x1 + 50, separator_y, x2 - 50, separator_y), fill=(52, 68, 72, 255), width=2)
        items = list(payload.get("items") or [])
        max_items = 6 if spec.size == "story" else 5
        row_height = 78 if spec.size == "story" else 62
        y = separator_y + 28
        for item in items[:max_items]:
            status = str(item.get("status") or "pending").lower()
            color = green if status == "won" else red if status == "lost" else gold
            label = str(item.get("label") or normalize_market_label(item.get("market")))
            label_font = self._fit_font(draw, label, x2 - x1 - 230, 23 if spec.size == "story" else 19, 15, True)
            draw.text((x1 + 52, y + 10), label, font=label_font, fill=white)
            result = f"{result_icon(status)} {status_label(status)}"
            result_font = self.font(21 if spec.size == "story" else 18, True)
            draw.text((x2 - 52 - self._measure(draw, result, result_font), y + 10), result, font=result_font, fill=color)
            y += row_height
        remaining = max(0, len(items) - max_items)
        if remaining:
            draw.text((x1 + 52, min(y2 - 62, y + 8)), f"另有 {remaining} 項結果已收錄於網站", font=self.font(19 if spec.size == "story" else 16), fill=muted)


class DiamondMindSocialService:
    def __init__(self, settings: Any):
        self.settings = settings
        self.renderer = SocialCardRenderer(
            getattr(settings, "social_font_path", "") or None,
            getattr(settings, "social_logo_path", "") or None,
        )
        self.client = httpx.AsyncClient(
            timeout=httpx.Timeout(max(15.0, float(getattr(settings, "request_timeout_seconds", 12.0)) * 2.0)),
            follow_redirects=True,
            trust_env=False,
        )

    async def aclose(self) -> None:
        await self.client.aclose()

    @property
    def asset_secret(self) -> str:
        return str(getattr(self.settings, "instagram_asset_secret", "") or getattr(self.settings, "cron_secret", "")).strip()

    @property
    def missing_configuration(self) -> list[str]:
        missing: list[str] = []
        if not str(getattr(self.settings, "instagram_user_id", "")).strip():
            missing.append("INSTAGRAM_USER_ID")
        if not str(getattr(self.settings, "instagram_access_token", "")).strip():
            missing.append("INSTAGRAM_ACCESS_TOKEN")
        if not self.asset_secret:
            missing.append("INSTAGRAM_ASSET_SECRET")
        if not str(getattr(self.settings, "public_api_base", "")).strip():
            missing.append("PUBLIC_API_BASE")
        return missing

    @property
    def configured(self) -> bool:
        return not self.missing_configuration

    @property
    def enabled(self) -> bool:
        return bool(getattr(self.settings, "instagram_auto_publish_enabled", False) and self.configured)

    def status(self) -> dict[str, Any]:
        requested = bool(getattr(self.settings, "instagram_auto_publish_enabled", False))
        return {
            "requested": requested,
            "enabled": self.enabled,
            "configured": self.configured,
            "missing_configuration": self.missing_configuration,
            "graph_version": str(getattr(self.settings, "instagram_graph_version", "v25.0")),
            "graph_base": str(getattr(self.settings, "instagram_graph_base", "https://graph.facebook.com")),
            "account_id_configured": bool(str(getattr(self.settings, "instagram_user_id", "")).strip()),
            "token_configured": bool(str(getattr(self.settings, "instagram_access_token", "")).strip()),
            "destinations": {
                "feed": bool(getattr(self.settings, "instagram_publish_feed", True)),
                "story": bool(getattr(self.settings, "instagram_publish_story", True)),
            },
            "policy": {
                "free_pregame": bool(getattr(self.settings, "instagram_post_free_pregame", True)),
                "free_result": bool(getattr(self.settings, "instagram_post_free_result", True)),
                "pro_teaser": bool(getattr(self.settings, "instagram_post_pro_teaser", True)),
                "pro_result": bool(getattr(self.settings, "instagram_post_pro_result", True)),
                "pro_picks_hidden_before_settlement": True,
            },
        }

    def sign_asset(self, spec: SocialAssetSpec, expires: int) -> str:
        message = f"{spec.signing_value}|{int(expires)}".encode("utf-8")
        return hmac.new(self.asset_secret.encode("utf-8"), message, hashlib.sha256).hexdigest()

    def verify_asset(self, spec: SocialAssetSpec, expires: int, signature: str) -> bool:
        if not self.asset_secret or int(expires) < int(datetime.now(timezone.utc).timestamp()):
            return False
        expected = self.sign_asset(spec, int(expires))
        return bool(signature and hmac.compare_digest(expected, str(signature)))

    def asset_url(self, spec: SocialAssetSpec, *, lifetime_seconds: int = 1800) -> str:
        spec = spec.validated()
        expires = int(datetime.now(timezone.utc).timestamp()) + max(300, min(int(lifetime_seconds), 86400))
        signature = self.sign_asset(spec, expires)
        base = str(getattr(self.settings, "public_api_base", "")).rstrip("/")
        prefix = str(getattr(self.settings, "api_prefix", "/api/v1"))
        path = f"{prefix}/social/assets/{spec.source}/{spec.recommendation_date}/{spec.league}/{spec.phase}/{spec.size}.jpg"
        return f"{base}{path}?{urlencode({'expires': expires, 'signature': signature})}"

    def render(self, spec: SocialAssetSpec, payload: dict[str, Any]) -> bytes:
        return self.renderer.render(spec, payload)

    async def _graph_request(self, method: str, path: str, *, data: dict[str, Any] | None = None, params: dict[str, Any] | None = None) -> dict[str, Any]:
        version = str(getattr(self.settings, "instagram_graph_version", "v25.0")).strip().strip("/")
        graph_base = str(getattr(self.settings, "instagram_graph_base", "https://graph.facebook.com")).strip().rstrip("/")
        url = f"{graph_base}/{version}/{path.lstrip('/')}"
        token = str(getattr(self.settings, "instagram_access_token", ""))
        request_data = dict(data or {})
        request_params = dict(params or {})
        if method.upper() == "GET":
            request_params["access_token"] = token
        else:
            request_data["access_token"] = token
        try:
            response = await self.client.request(method, url, data=request_data or None, params=request_params or None)
            payload = response.json()
        except (httpx.HTTPError, ValueError) as exc:
            raise SocialPublishingError(f"Instagram API 連線失敗：{type(exc).__name__}") from exc
        if response.is_error or not isinstance(payload, dict) or payload.get("error"):
            error = payload.get("error") if isinstance(payload, dict) else {}
            message = str((error or {}).get("message") or f"HTTP {response.status_code}")
            code = (error or {}).get("code")
            subcode = (error or {}).get("error_subcode")
            suffix = " / ".join(str(value) for value in (code, subcode) if value is not None)
            raise SocialPublishingError(f"Instagram API 拒絕發佈：{message}{f'（{suffix}）' if suffix else ''}")
        return payload

    async def _wait_for_container(self, creation_id: str) -> dict[str, Any]:
        last: dict[str, Any] = {}
        for _ in range(10):
            last = await self._graph_request("GET", creation_id, params={"fields": "status_code,status"})
            state = str(last.get("status_code") or "").upper()
            if state in {"FINISHED", "PUBLISHED"}:
                return last
            if state in {"ERROR", "EXPIRED"}:
                raise SocialPublishingError(f"Instagram 媒體處理失敗：{last.get('status') or state}")
            await asyncio.sleep(1)
        raise SocialPublishingError("Instagram 媒體處理逾時，稍後會自動重試。")

    async def publish_image(self, image_url: str, caption: str, *, story: bool = False) -> dict[str, Any]:
        if not self.enabled:
            return {"status": "disabled", "channel": "story" if story else "feed"}
        user_id = str(getattr(self.settings, "instagram_user_id", "")).strip()
        data: dict[str, Any] = {"image_url": image_url}
        if story:
            data["media_type"] = "STORIES"
        else:
            data["caption"] = caption
        container = await self._graph_request("POST", f"{user_id}/media", data=data)
        creation_id = str(container.get("id") or "")
        if not creation_id:
            raise SocialPublishingError("Instagram 未回傳媒體容器編號。")
        await self._wait_for_container(creation_id)
        published = await self._graph_request("POST", f"{user_id}/media_publish", data={"creation_id": creation_id})
        media_id = str(published.get("id") or "")
        if not media_id:
            raise SocialPublishingError("Instagram 未回傳發佈媒體編號。")
        return {
            "status": "published",
            "channel": "story" if story else "feed",
            "creation_id": creation_id,
            "media_id": media_id,
            "published_at": utc_now(),
        }

    async def publish_pair(
        self,
        spec: SocialAssetSpec,
        payload: dict[str, Any],
        *,
        existing_destinations: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        if not self.enabled:
            return {"status": "disabled", "reason": "not_configured" if not self.configured else "disabled", "checked_at": utc_now()}
        website = str(getattr(self.settings, "frontend_base_url", "")).strip()
        caption = social_caption(spec, payload, website)
        destinations: dict[str, Any] = dict(existing_destinations or {})
        errors: list[str] = []
        feed_done = str((destinations.get("feed") or {}).get("status") or "") == "published"
        story_done = str((destinations.get("story") or {}).get("status") or "") == "published"
        if bool(getattr(self.settings, "instagram_publish_feed", True)) and not feed_done:
            try:
                feed_spec = SocialAssetSpec(spec.source, spec.phase, "feed", spec.recommendation_date, spec.league)
                destinations["feed"] = await self.publish_image(self.asset_url(feed_spec), caption, story=False)
            except SocialPublishingError as exc:
                destinations["feed"] = {"status": "failed", "error": str(exc), "checked_at": utc_now()}
                errors.append(str(exc))
        if bool(getattr(self.settings, "instagram_publish_story", True)) and not story_done:
            try:
                story_spec = SocialAssetSpec(spec.source, spec.phase, "story", spec.recommendation_date, spec.league)
                destinations["story"] = await self.publish_image(self.asset_url(story_spec), caption, story=True)
            except SocialPublishingError as exc:
                destinations["story"] = {"status": "failed", "error": str(exc), "checked_at": utc_now()}
                errors.append(str(exc))
        required_channels = [
            channel
            for channel, enabled in (
                ("feed", bool(getattr(self.settings, "instagram_publish_feed", True))),
                ("story", bool(getattr(self.settings, "instagram_publish_story", True))),
            )
            if enabled
        ]
        attempted = [destinations.get(channel) or {} for channel in required_channels]
        success_count = sum(1 for item in attempted if item.get("status") == "published")
        status = "published" if attempted and success_count == len(attempted) else "partial" if success_count else "failed"
        return {
            "status": status,
            "event": event_key(spec.source, spec.phase, spec.league),
            "destinations": destinations,
            "errors": errors,
            "checked_at": utc_now(),
        }
