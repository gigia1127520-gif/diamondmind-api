from __future__ import annotations

import re
import secrets
from typing import Any

from .billing import BillingRepository, iso_utc


TEMPORARY_PASSWORD_ALPHABET = (
    "ABCDEFGHJKLMNPQRSTUVWXYZ"
    "abcdefghijkmnopqrstuvwxyz"
    "23456789"
)


class PasswordSecurityError(RuntimeError):
    pass


def validate_new_password(password: str) -> str:
    if len(password) < 8:
        raise PasswordSecurityError("新密碼至少需要 8 個字元")
    if len(password) > 72:
        raise PasswordSecurityError("新密碼不可超過 72 個字元")
    if password != password.strip() or any(character.isspace() for character in password):
        raise PasswordSecurityError("新密碼不可包含空白")
    if not re.search(r"[A-Za-z]", password) or not re.search(r"\d", password):
        raise PasswordSecurityError("新密碼必須同時包含英文字母與數字")
    return password


def generate_temporary_password() -> str:
    while True:
        body = "".join(secrets.choice(TEMPORARY_PASSWORD_ALPHABET) for _ in range(12))
        if re.search(r"[A-Z]", body) and re.search(r"[a-z]", body) and re.search(r"\d", body):
            return f"DM-{body[:4]}-{body[4:8]}-{body[8:]}"


def _is_admin(user: dict[str, Any]) -> bool:
    role = str((user.get("app_metadata") or {}).get("role") or "free").lower()
    return role in {"admin", "founder"}


class PasswordSecurityService:
    """Server-side password reset and forced-change workflow."""

    def __init__(self, repository: BillingRepository) -> None:
        self.repository = repository

    async def reset_by_founder(
        self,
        *,
        actor: dict[str, Any],
        target_user_id: str,
    ) -> dict[str, Any]:
        target = await self.repository.admin_user(target_user_id)
        if _is_admin(target):
            raise PasswordSecurityError("創辦人或管理員帳號不可由會員後台重置密碼")
        if str(actor.get("id")) == str(target_user_id):
            raise PasswordSecurityError("不可從會員後台重置自己的創辦人密碼")

        # Confirm the audit table is installed before changing credentials.
        await self.repository.list_admin_events(limit=1)

        temporary_password = generate_temporary_password()
        issued_at = iso_utc()
        updated = await self.repository.set_user_password(
            target_user_id,
            temporary_password,
            {
                "must_change_password": True,
                "temporary_password_issued_at": issued_at,
                "temporary_password_issued_by": actor.get("id"),
            },
        )
        await self.repository.record_admin_event(
            {
                "actor_user_id": actor.get("id"),
                "actor_email": actor.get("email"),
                "target_user_id": target_user_id,
                "target_email": target.get("email"),
                "action": "password_reset",
                "plan_code": None,
                "note": "已產生一次性臨時密碼；密碼內容未寫入稽核紀錄",
                "before_state": {
                    "must_change_password": bool(
                        (target.get("app_metadata") or {}).get("must_change_password")
                    )
                },
                "after_state": {"must_change_password": True},
            }
        )
        return {
            "ok": True,
            "member_id": target_user_id,
            "email": target.get("email"),
            "temporary_password": temporary_password,
            "must_change_password": True,
            "issued_at": issued_at,
            "updated_user_id": updated.get("id") or target_user_id,
        }

    async def change_for_member(
        self,
        *,
        member: dict[str, Any],
        new_password: str,
    ) -> dict[str, Any]:
        password = validate_new_password(new_password)
        user_id = str(member.get("id") or "")
        if not user_id:
            raise PasswordSecurityError("會員登入狀態無效")
        changed_at = iso_utc()
        await self.repository.set_user_password(
            user_id,
            password,
            {
                "must_change_password": False,
                "temporary_password_issued_at": None,
                "temporary_password_issued_by": None,
                "password_changed_at": changed_at,
            },
        )
        return {
            "ok": True,
            "member_id": user_id,
            "must_change_password": False,
            "password_changed_at": changed_at,
        }
