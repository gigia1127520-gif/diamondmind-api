from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable
from datetime import datetime, timezone
from typing import Any


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


class WorkerRegistry:
    """Supervise long-running in-process workers and expose lightweight state.

    A worker that unexpectedly returns or raises is restarted after a bounded
    delay.  The registry never performs external I/O, so health endpoints can
    read its snapshot without waiting on MLB, odds, Supabase, or settlement.
    """

    def __init__(self, *, restart_delay_seconds: float = 5.0) -> None:
        self.restart_delay_seconds = max(1.0, float(restart_delay_seconds))
        self._tasks: dict[str, asyncio.Task[Any]] = {}
        self._status: dict[str, dict[str, Any]] = {}
        self._closing = False

    def start(self, name: str, worker_factory: Callable[[], Awaitable[None]]) -> asyncio.Task[Any]:
        current = self._tasks.get(name)
        if current is not None and not current.done():
            return current
        self._status[name] = {
            "state": "starting",
            "started_at": utc_now(),
            "last_heartbeat": None,
            "last_error": None,
            "restart_count": 0,
        }
        task = asyncio.create_task(self._supervise(name, worker_factory), name=f"diamondmind-supervisor-{name}")
        self._tasks[name] = task
        return task

    async def _supervise(self, name: str, worker_factory: Callable[[], Awaitable[None]]) -> None:
        while not self._closing:
            status = self._status[name]
            status.update({"state": "running", "last_started_at": utc_now(), "last_error": None})
            try:
                await worker_factory()
                if self._closing:
                    break
                status.update({"state": "restarting", "last_error": "worker_returned_unexpectedly"})
            except asyncio.CancelledError:
                status["state"] = "stopped"
                raise
            except Exception as exc:  # pragma: no cover - defensive supervisor
                status.update({
                    "state": "restarting",
                    "last_error": f"{type(exc).__name__}: {str(exc)[:300]}",
                })
            status["restart_count"] = int(status.get("restart_count") or 0) + 1
            await asyncio.sleep(self.restart_delay_seconds)
        self._status[name]["state"] = "stopped"

    def heartbeat(self, name: str, **details: Any) -> None:
        status = self._status.setdefault(name, {"state": "running", "restart_count": 0})
        status.update(details)
        status["last_heartbeat"] = utc_now()
        if status.get("state") not in {"restarting", "stopped"}:
            status["state"] = "running"

    def snapshot(self) -> dict[str, dict[str, Any]]:
        return {name: dict(value) for name, value in self._status.items()}

    async def close(self) -> None:
        self._closing = True
        tasks = [task for task in self._tasks.values() if not task.done()]
        for task in tasks:
            task.cancel()
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)
        for status in self._status.values():
            status["state"] = "stopped"
