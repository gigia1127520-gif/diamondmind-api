from __future__ import annotations

import asyncio
from collections import Counter, deque
from collections.abc import Awaitable, Callable
from datetime import datetime, timezone
from math import ceil
from typing import Any


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


class RequestMetrics:
    """Bounded in-memory request telemetry for the founder monitor.

    This intentionally stores no headers, query strings, request bodies,
    member IDs, or credentials.  It is process-local operational telemetry,
    while provider quota counters remain the source of truth for paid APIs.
    """

    def __init__(self, *, max_events: int = 5000) -> None:
        self.started_at = utc_now()
        self.max_events = max(100, int(max_events))
        self._events: deque[dict[str, Any]] = deque(maxlen=self.max_events)

    def record(
        self,
        *,
        method: str,
        route: str,
        status_code: int,
        duration_ms: float,
    ) -> None:
        self._events.append({
            "at": datetime.now(timezone.utc).timestamp(),
            "method": str(method or "GET").upper(),
            "route": str(route or "unmatched")[:180],
            "status_code": int(status_code),
            "duration_ms": max(0.0, round(float(duration_ms), 2)),
        })

    def snapshot(self, *, window_seconds: int = 3600) -> dict[str, Any]:
        now = datetime.now(timezone.utc).timestamp()
        recent = [
            event
            for event in self._events
            if now - float(event["at"]) <= max(60, int(window_seconds))
        ]
        durations = sorted(float(event["duration_ms"]) for event in recent)
        statuses = Counter(str(int(event["status_code"]) // 100) + "xx" for event in recent)
        routes = Counter(f'{event["method"]} {event["route"]}' for event in recent)
        p95 = None
        if durations:
            p95 = durations[max(0, ceil(len(durations) * 0.95) - 1)]
        return {
            "scope": "render_process_local",
            "started_at": self.started_at,
            "stored_events": len(self._events),
            "window_seconds": max(60, int(window_seconds)),
            "requests": len(recent),
            "errors": sum(int(event["status_code"]) >= 500 for event in recent),
            "client_errors": sum(400 <= int(event["status_code"]) < 500 for event in recent),
            "average_ms": (
                round(sum(durations) / len(durations), 2)
                if durations else None
            ),
            "p95_ms": round(p95, 2) if p95 is not None else None,
            "status_classes": dict(sorted(statuses.items())),
            "top_routes": [
                {"route": route, "requests": count}
                for route, count in routes.most_common(10)
            ],
        }


class WorkerRegistry:
    """Supervise long-running in-process workers and expose lightweight state.

    A worker that unexpectedly returns or raises is restarted after a bounded
    delay.  The registry never performs external I/O, so health endpoints can
    read its snapshot without waiting on MLB, odds, Supabase, or settlement.
    """

    def __init__(self, *, restart_delay_seconds: float = 5.0) -> None:
        self.restart_delay_seconds = max(1.0, float(restart_delay_seconds))
        self._tasks: dict[str, asyncio.Task[Any]] = {}
        self._status: dict[str, dict[str, Any]] = {}
        self._closing = False

    def start(self, name: str, worker_factory: Callable[[], Awaitable[None]]) -> asyncio.Task[Any]:
        current = self._tasks.get(name)
        if current is not None and not current.done():
            return current
        self._status[name] = {
            "state": "starting",
            "started_at": utc_now(),
            "last_heartbeat": None,
            "last_error": None,
            "restart_count": 0,
        }
        task = asyncio.create_task(self._supervise(name, worker_factory), name=f"diamondmind-supervisor-{name}")
        self._tasks[name] = task
        return task

    async def _supervise(self, name: str, worker_factory: Callable[[], Awaitable[None]]) -> None:
        while not self._closing:
            status = self._status[name]
            status.update({"state": "running", "last_started_at": utc_now(), "last_error": None})
            try:
                await worker_factory()
                if self._closing:
                    break
                status.update({"state": "restarting", "last_error": "worker_returned_unexpectedly"})
            except asyncio.CancelledError:
                status["state"] = "stopped"
                raise
            except Exception as exc:  # pragma: no cover - defensive supervisor
                status.update({
                    "state": "restarting",
                    "last_error": f"{type(exc).__name__}: {str(exc)[:300]}",
                })
            status["restart_count"] = int(status.get("restart_count") or 0) + 1
            await asyncio.sleep(self.restart_delay_seconds)
        self._status[name]["state"] = "stopped"

    def heartbeat(self, name: str, **details: Any) -> None:
        status = self._status.setdefault(name, {"state": "running", "restart_count": 0})
        status.update(details)
        status["last_heartbeat"] = utc_now()
        if status.get("state") not in {"restarting", "stopped"}:
            status["state"] = "running"

    def snapshot(self) -> dict[str, dict[str, Any]]:
        return {name: dict(value) for name, value in self._status.items()}

    async def close(self) -> None:
        self._closing = True
        tasks = [task for task in self._tasks.values() if not task.done()]
        for task in tasks:
            task.cancel()
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)
        for status in self._status.values():
            status["state"] = "stopped"
