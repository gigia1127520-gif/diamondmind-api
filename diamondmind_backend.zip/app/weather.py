from __future__ import annotations

import math
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Any
from urllib.parse import urlencode

import httpx

from .cache import AsyncTTLCache
from .config import Settings


class WeatherUpstreamError(RuntimeError):
    pass


@dataclass
class WeatherPayload:
    data: dict[str, Any]
    cache_status: str
    fetched_at: str


def _number(value: Any) -> float | None:
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _iso(timestamp: float) -> str:
    return datetime.fromtimestamp(timestamp, tz=timezone.utc).isoformat().replace("+00:00", "Z")


def cardinal_direction(degrees: float | None) -> str | None:
    if degrees is None:
        return None
    labels = ("北", "東北", "東", "東南", "南", "西南", "西", "西北")
    return labels[int((degrees % 360 + 22.5) // 45) % 8]


def weather_code_text(code: int | None) -> str:
    labels = {
        0: "晴朗",
        1: "大致晴朗",
        2: "局部多雲",
        3: "陰天",
        45: "霧",
        48: "霧凇",
        51: "毛毛雨",
        53: "毛毛雨",
        55: "強毛毛雨",
        61: "小雨",
        63: "中雨",
        65: "大雨",
        80: "陣雨",
        81: "陣雨",
        82: "強陣雨",
        95: "雷雨",
        96: "雷雨伴冰雹",
        99: "強雷雨伴冰雹",
    }
    return labels.get(code, "天氣資料")


class WeatherService:
    def __init__(
        self,
        settings: Settings,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self.settings = settings
        self.cache = AsyncTTLCache()
        self.client = httpx.AsyncClient(
            timeout=max(settings.request_timeout_seconds, 14.0),
            follow_redirects=True,
            trust_env=False,
            transport=transport,
            headers={"User-Agent": "DiamondMind/2.0"},
        )

    async def aclose(self) -> None:
        await self.client.aclose()

    async def _get_json(self, params: dict[str, Any]) -> WeatherPayload:
        cleaned = {key: value for key, value in params.items() if value is not None}
        url = self.settings.weather_api_base
        key = f"weather:{url}?{urlencode(sorted((str(k), str(v)) for k, v in cleaned.items()))}"
        ttl = self.settings.weather_cache_ttl_seconds
        cached = self.cache.get(key)
        if cached and cached.is_fresh:
            return WeatherPayload(cached.value, "hit", _iso(cached.stored_at))
        async with self.cache.lock(key):
            cached = self.cache.get(key)
            if cached and cached.is_fresh:
                return WeatherPayload(cached.value, "hit", _iso(cached.stored_at))
            try:
                response = await self.client.get(url, params=cleaned)
                response.raise_for_status()
                data = response.json()
                if not isinstance(data, dict):
                    raise ValueError("Unexpected weather response")
                entry = self.cache.set(
                    key,
                    data,
                    ttl,
                    max(ttl + 60, self.settings.stale_ttl_seconds),
                )
                return WeatherPayload(data, "miss", _iso(entry.stored_at))
            except (httpx.HTTPError, ValueError) as exc:
                if cached and cached.can_serve_stale:
                    return WeatherPayload(cached.value, "stale", _iso(cached.stored_at))
                raise WeatherUpstreamError("Weather data is temporarily unavailable") from exc

    async def forecast_for_game(
        self,
        latitude: float | None,
        longitude: float | None,
        game_time_utc: datetime,
    ) -> dict[str, Any]:
        if latitude is None or longitude is None:
            return {"available": False, "message": "球場座標不可用"}
        target = game_time_utc.astimezone(timezone.utc).replace(minute=0, second=0, microsecond=0)
        start = (target - timedelta(hours=2)).date().isoformat()
        end = (target + timedelta(hours=3)).date().isoformat()
        try:
            payload = await self._get_json(
                {
                    "latitude": round(latitude, 5),
                    "longitude": round(longitude, 5),
                    "hourly": (
                        "temperature_2m,relative_humidity_2m,precipitation_probability,"
                        "precipitation,weather_code,wind_speed_10m,wind_direction_10m,wind_gusts_10m"
                    ),
                    "temperature_unit": "fahrenheit",
                    "wind_speed_unit": "mph",
                    "precipitation_unit": "inch",
                    "timezone": "UTC",
                    "start_date": start,
                    "end_date": end,
                }
            )
        except WeatherUpstreamError:
            return {"available": False, "message": "天氣服務暫時不可用"}

        hourly = payload.data.get("hourly") or {}
        times = hourly.get("time") or []
        if not times:
            return {"available": False, "message": "找不到比賽時段天氣"}

        parsed: list[tuple[int, datetime]] = []
        for index, value in enumerate(times):
            try:
                dt = datetime.fromisoformat(str(value)).replace(tzinfo=timezone.utc)
            except ValueError:
                continue
            parsed.append((index, dt))
        if not parsed:
            return {"available": False, "message": "天氣時間格式不可用"}
        index, matched = min(parsed, key=lambda item: abs((item[1] - target).total_seconds()))

        def value(name: str) -> Any:
            values = hourly.get(name) or []
            return values[index] if index < len(values) else None

        code = int(value("weather_code")) if _number(value("weather_code")) is not None else None
        wind_direction = _number(value("wind_direction_10m"))
        return {
            "available": True,
            "time_utc": matched.isoformat().replace("+00:00", "Z"),
            "temperature_f": _number(value("temperature_2m")),
            "humidity_pct": _number(value("relative_humidity_2m")),
            "precipitation_probability_pct": _number(value("precipitation_probability")),
            "precipitation_in": _number(value("precipitation")),
            "weather_code": code,
            "condition": weather_code_text(code),
            "wind_speed_mph": _number(value("wind_speed_10m")),
            "wind_gust_mph": _number(value("wind_gusts_10m")),
            "wind_direction_deg": wind_direction,
            "wind_direction_text": cardinal_direction(wind_direction),
            "cache": payload.cache_status,
            "source": "Open-Meteo",
            "updated_at": payload.fetched_at,
        }


def environment_run_adjustment(
    weather: dict[str, Any],
    *,
    roof_type: str | None,
    roof_closed: bool,
    relative_wind: str | None,
    park_run_factor: float | None,
) -> dict[str, Any]:
    """Estimate run-environment movement without producing an exact score."""

    roof = str(roof_type or "").lower()
    weather_applied = not roof_closed and "dome" not in roof and "fixed" not in roof
    adjustment = 0.0
    reasons: list[str] = []

    factor = park_run_factor if park_run_factor and park_run_factor > 0 else 1.0
    park_delta = max(-0.75, min(0.75, (factor - 1.0) * 8.5))
    if abs(park_delta) >= 0.05:
        adjustment += park_delta
        reasons.append("球場偏打者" if park_delta > 0 else "球場偏投手")

    if weather.get("available") and weather_applied:
        temperature = _number(weather.get("temperature_f"))
        if temperature is not None:
            temp_delta = max(-0.45, min(0.45, (temperature - 70.0) * 0.015))
            adjustment += temp_delta
            if temp_delta >= 0.12:
                reasons.append("高溫有利飛行距離")
            elif temp_delta <= -0.12:
                reasons.append("低溫壓低長打")

        wind_speed = _number(weather.get("wind_speed_mph")) or 0.0
        wind = str(relative_wind or "").lower()
        if wind_speed >= 6:
            wind_delta = max(0.0, min(0.8, (wind_speed - 5.0) * 0.045))
            if "out" in wind or "順風" in wind:
                adjustment += wind_delta
                reasons.append("外野順風")
            elif "in" in wind or "逆風" in wind:
                adjustment -= wind_delta
                reasons.append("外野逆風")

        rain = _number(weather.get("precipitation_probability_pct")) or 0.0
        if rain >= 50:
            reasons.append("降雨風險")
    elif roof_closed:
        reasons.append("屋頂關閉，戶外天氣不計權重")
    elif "dome" in roof or "fixed" in roof:
        reasons.append("室內球場，戶外天氣不計權重")

    return {
        "run_adjustment": round(max(-1.25, min(1.25, adjustment)), 2),
        "weather_applied": weather_applied,
        "reasons": reasons,
        "quality": 1.0 if weather.get("available") or not weather_applied else 0.55,
    }
