from __future__ import annotations

from typing import Any

import httpx

from .config import Settings


class MemberAccessError(RuntimeError):
    pass


class SupabaseMemberAuth:
    """Validate a browser session with Supabase before returning paid data."""

    def __init__(
        self,
        settings: Settings,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self.enabled = settings.records_enabled
        key = settings.supabase_secret_key
        base_url = (
            f"{settings.supabase_url}/auth/v1/"
            if settings.supabase_url
            else "https://auth.invalid/auth/v1/"
        )
        self.client = httpx.AsyncClient(
            base_url=base_url,
            headers={"Accept": "application/json", "apikey": key},
            timeout=settings.request_timeout_seconds,
            follow_redirects=True,
            trust_env=False,
            transport=transport,
        )

    async def aclose(self) -> None:
        await self.client.aclose()

    async def member(self, access_token: str | None) -> dict[str, Any]:
        if not self.enabled:
            raise MemberAccessError("Member authentication is not configured")
        if not access_token:
            raise MemberAccessError("Member login is required")
        try:
            response = await self.client.get(
                "user",
                headers={"Authorization": f"Bearer {access_token}"},
            )
            response.raise_for_status()
            payload = response.json()
        except (httpx.HTTPError, ValueError) as exc:
            raise MemberAccessError("Member session is invalid or expired") from exc

        if not isinstance(payload, dict) or not payload.get("id"):
            raise MemberAccessError("Member session is invalid or expired")
        role_value = str((payload.get("app_metadata") or {}).get("role") or "free").lower()
        role = "admin" if role_value in {"admin", "founder"} else "pro" if role_value == "pro" else "free"
        return {
            "id": payload["id"],
            "email": payload.get("email"),
            "role": role,
            "has_pro_access": role in {"pro", "admin"},
        }
