from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

import httpx

from .config import Settings


class MemberAccessError(RuntimeError):
    pass


class SupabaseMemberAuth:
    """Validate a browser session with Supabase before returning paid data."""

    def __init__(
        self,
        settings: Settings,
        transport: httpx.AsyncBaseTransport | None = None,
    ) -> None:
        self.enabled = settings.records_enabled
        key = settings.supabase_secret_key
        base_url = (
            f"{settings.supabase_url}/auth/v1/"
            if settings.supabase_url
            else "https://auth.invalid/auth/v1/"
        )
        self.client = httpx.AsyncClient(
            base_url=base_url,
            headers={"Accept": "application/json", "apikey": key},
            timeout=settings.request_timeout_seconds,
            follow_redirects=True,
            trust_env=False,
            transport=transport,
        )

    async def aclose(self) -> None:
        await self.client.aclose()

    async def member(self, access_token: str | None) -> dict[str, Any]:
        if not self.enabled:
            raise MemberAccessError("Member authentication is not configured")
        if not access_token:
            raise MemberAccessError("Member login is required")
        try:
            response = await self.client.get(
                "user",
                headers={"Authorization": f"Bearer {access_token}"},
            )
            response.raise_for_status()
            payload = response.json()
        except (httpx.HTTPError, ValueError) as exc:
            raise MemberAccessError("Member session is invalid or expired") from exc

        if not isinstance(payload, dict) or not payload.get("id"):
            raise MemberAccessError("Member session is invalid or expired")
        app_metadata = payload.get("app_metadata") or {}
        role_value = str(app_metadata.get("role") or "free").lower()
        role = "admin" if role_value in {"admin", "founder"} else "pro" if role_value == "pro" else "free"
        expires_at = app_metadata.get("pro_expires_at")
        if role == "pro" and expires_at:
            try:
                expiry = datetime.fromisoformat(str(expires_at).replace("Z", "+00:00"))
                if expiry.tzinfo is None:
                    expiry = expiry.replace(tzinfo=timezone.utc)
                if expiry <= datetime.now(timezone.utc):
                    role = "free"
            except ValueError:
                role = "free"
        return {
            "id": payload["id"],
            "email": payload.get("email"),
            "role": role,
            "has_pro_access": role in {"pro", "admin"},
            "plan": app_metadata.get("plan"),
            "pro_expires_at": expires_at,
            "billing_status": app_metadata.get("billing_status"),
            "billing_auto_renew": app_metadata.get("billing_auto_renew"),
            "must_change_password": bool(app_metadata.get("must_change_password")),
        }
