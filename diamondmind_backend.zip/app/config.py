from __future__ import annotations

import os
from dataclasses import dataclass


def _as_float(name: str, default: float) -> float:
    try:
        return float(os.getenv(name, default))
    except (TypeError, ValueError):
        return default


def _as_int(name: str, default: int) -> int:
    try:
        return int(os.getenv(name, default))
    except (TypeError, ValueError):
        return default


@dataclass(frozen=True)
class Settings:
    app_name: str = os.getenv("APP_NAME", "DiamondMind API")
    app_env: str = os.getenv("APP_ENV", "development")
    api_prefix: str = "/api/v1"
    mlb_api_base: str = os.getenv("MLB_API_BASE", "https://statsapi.mlb.com/api/v1")
    mlb_live_base: str = os.getenv("MLB_LIVE_BASE", "https://statsapi.mlb.com/api/v1.1")
    request_timeout_seconds: float = _as_float("REQUEST_TIMEOUT_SECONDS", 12.0)
    cache_ttl_seconds: int = _as_int("CACHE_TTL_SECONDS", 60)
    stale_ttl_seconds: int = _as_int("STALE_TTL_SECONDS", 1800)
    min_confidence: float = _as_float("MIN_CONFIDENCE", 56.0)
    odds_api_base: str = os.getenv(
        "ODDS_API_BASE", "https://api.the-odds-api.com/v4"
    ).strip().rstrip("/")
    odds_api_key: str = os.getenv("ODDS_API_KEY", "").strip()
    odds_sport_key: str = os.getenv("ODDS_SPORT_KEY", "baseball_mlb").strip()
    odds_bookmakers_raw: str = os.getenv(
        "ODDS_BOOKMAKERS", "draftkings,fanduel,betmgm,caesars"
    )
    odds_markets_raw: str = os.getenv("ODDS_MARKETS", "h2h,spreads,totals")
    odds_cache_ttl_seconds: int = _as_int("ODDS_CACHE_TTL_SECONDS", 900)
    odds_stale_ttl_seconds: int = _as_int("ODDS_STALE_TTL_SECONDS", 3600)
    cron_secret: str = os.getenv("CRON_SECRET", "").strip()
    supabase_url: str = os.getenv("SUPABASE_URL", "").strip().rstrip("/")
    supabase_secret_key: str = (
        os.getenv("SUPABASE_SECRET_KEY")
        or os.getenv("SUPABASE_SERVICE_ROLE_KEY")
        or ""
    ).strip()
    records_limit: int = _as_int("RECORDS_LIMIT", 500)
    cors_origins_raw: str = os.getenv(
        "CORS_ORIGINS",
        "https://gigia1127520-gif.github.io,http://localhost:8000,http://127.0.0.1:8000",
    )

    @property
    def cors_origins(self) -> list[str]:
        values = [value.strip() for value in self.cors_origins_raw.split(",") if value.strip()]
        return values or ["*"]

    @property
    def records_enabled(self) -> bool:
        return bool(self.supabase_url and self.supabase_secret_key)

    @property
    def odds_enabled(self) -> bool:
        return bool(self.odds_api_key)

    @property
    def scheduler_enabled(self) -> bool:
        return bool(self.cron_secret)

    @property
    def odds_bookmakers(self) -> list[str]:
        # The provider counts each group of ten bookmakers as one region.
        # Keeping this capped at ten makes every three-market refresh cost
        # exactly three usage credits.
        values = [
            value.strip().lower()
            for value in self.odds_bookmakers_raw.split(",")
            if value.strip()
        ]
        return list(dict.fromkeys(values))[:10]

    @property
    def odds_markets(self) -> list[str]:
        supported = {"h2h", "spreads", "totals"}
        values = [
            value.strip().lower()
            for value in self.odds_markets_raw.split(",")
            if value.strip().lower() in supported
        ]
        return list(dict.fromkeys(values)) or ["h2h", "spreads", "totals"]


settings = Settings()
