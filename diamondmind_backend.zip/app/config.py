from __future__ import annotations

import os
from dataclasses import dataclass


def _as_float(name: str, default: float) -> float:
    try:
        return float(os.getenv(name, default))
    except (TypeError, ValueError):
        return default


def _as_int(name: str, default: int) -> int:
    try:
        return int(os.getenv(name, default))
    except (TypeError, ValueError):
        return default


@dataclass(frozen=True)
class Settings:
    app_name: str = os.getenv("APP_NAME", "DiamondMind API")
    app_env: str = os.getenv("APP_ENV", "development")
    api_prefix: str = "/api/v1"
    mlb_api_base: str = os.getenv("MLB_API_BASE", "https://statsapi.mlb.com/api/v1")
    mlb_live_base: str = os.getenv("MLB_LIVE_BASE", "https://statsapi.mlb.com/api/v1.1")
    savant_base: str = os.getenv("SAVANT_BASE", "https://baseballsavant.mlb.com").strip().rstrip("/")
    weather_api_base: str = os.getenv("WEATHER_API_BASE", "https://api.open-meteo.com/v1/forecast").strip()
    request_timeout_seconds: float = _as_float("REQUEST_TIMEOUT_SECONDS", 12.0)
    cache_ttl_seconds: int = _as_int("CACHE_TTL_SECONDS", 60)
    weather_cache_ttl_seconds: int = _as_int("WEATHER_CACHE_TTL_SECONDS", 1800)
    advanced_cache_ttl_seconds: int = _as_int("ADVANCED_CACHE_TTL_SECONDS", 21600)
    stale_ttl_seconds: int = _as_int("STALE_TTL_SECONDS", 1800)
    pregame_refresh_interval_seconds: int = _as_int("PREGAME_REFRESH_INTERVAL_SECONDS", 900)
    pregame_lineup_watch_minutes: int = _as_int("PREGAME_LINEUP_WATCH_MINUTES", 90)
    pregame_final_lock_minutes: int = _as_int("PREGAME_FINAL_LOCK_MINUTES", 30)
    minimum_publish_data_quality: float = _as_float("MINIMUM_PUBLISH_DATA_QUALITY", 0.55)
    minimum_lineup_validation_rate: float = _as_float("MINIMUM_LINEUP_VALIDATION_RATE", 0.90)
    min_confidence: float = _as_float("MIN_CONFIDENCE", 56.0)
    min_market_probability: float = _as_float("MIN_MARKET_PROBABILITY", 53.0)
    min_market_edge: float = _as_float("MIN_MARKET_EDGE", 3.0)
    min_projection_quality: float = _as_float("MIN_PROJECTION_QUALITY", 0.45)
    min_parlay_leg_probability: float = _as_float("MIN_PARLAY_LEG_PROBABILITY", 54.0)
    odds_api_base: str = os.getenv(
        "ODDS_API_BASE", "https://api.the-odds-api.com/v4"
    ).strip().rstrip("/")
    odds_api_key: str = os.getenv("ODDS_API_KEY", "").strip()
    odds_sport_key: str = os.getenv("ODDS_SPORT_KEY", "baseball_mlb").strip()
    odds_bookmakers_raw: str = os.getenv(
        "ODDS_BOOKMAKERS", "draftkings,fanduel,betmgm,caesars"
    )
    odds_markets_raw: str = os.getenv("ODDS_MARKETS", "h2h,spreads,totals")
    odds_cache_ttl_seconds: int = _as_int("ODDS_CACHE_TTL_SECONDS", 900)
    odds_stale_ttl_seconds: int = _as_int("ODDS_STALE_TTL_SECONDS", 3600)
    cron_secret: str = os.getenv("CRON_SECRET", "").strip()
    supabase_url: str = os.getenv("SUPABASE_URL", "").strip().rstrip("/")
    supabase_secret_key: str = (
        os.getenv("SUPABASE_SECRET_KEY")
        or os.getenv("SUPABASE_SERVICE_ROLE_KEY")
        or ""
    ).strip()
    records_limit: int = _as_int("RECORDS_LIMIT", 500)
    cors_origins_raw: str = os.getenv(
        "CORS_ORIGINS",
        "https://gigia1127520-gif.github.io,http://localhost:8000,http://127.0.0.1:8000",
    )

    @property
    def cors_origins(self) -> list[str]:
        values = [value.strip() for value in self.cors_origins_raw.split(",") if value.strip()]
        return values or ["*"]

    @property
    def records_enabled(self) -> bool:
        return bool(self.supabase_url and self.supabase_secret_key)

    @property
    def odds_enabled(self) -> bool:
        return bool(self.odds_api_key)

    @property
    def scheduler_enabled(self) -> bool:
        return bool(self.cron_secret)

    @property
    def odds_bookmakers(self) -> list[str]:
        # The provider counts each group of ten bookmakers as one region.
        # Keeping this capped at ten makes every three-market refresh cost
        # exactly three usage credits.
        values = [
            value.strip().lower()
            for value in self.odds_bookmakers_raw.split(",")
            if value.strip()
        ]
        return list(dict.fromkeys(values))[:10]

    @property
    def odds_markets(self) -> list[str]:
        supported = {"h2h", "spreads", "totals"}
        values = [
            value.strip().lower()
            for value in self.odds_markets_raw.split(",")
            if value.strip().lower() in supported
        ]
        return list(dict.fromkeys(values)) or ["h2h", "spreads", "totals"]


settings = Settings()
