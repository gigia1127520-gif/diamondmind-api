from __future__ import annotations

import os
from dataclasses import dataclass


def _as_float(name: str, default: float) -> float:
    try:
        return float(os.getenv(name, default))
    except (TypeError, ValueError):
        return default


def _as_int(name: str, default: int) -> int:
    try:
        return int(os.getenv(name, default))
    except (TypeError, ValueError):
        return default


@dataclass(frozen=True)
class Settings:
    app_name: str = os.getenv("APP_NAME", "DiamondMind API")
    app_env: str = os.getenv("APP_ENV", "development")
    # "all" keeps the current single Render service fully compatible.  Paid
    # deployments can split the same release into api/publish/settlement/model
    # processes without changing member-facing routes or business rules.
    process_role: str = os.getenv("DIAMONDMIND_PROCESS_ROLE", "all").strip().lower()
    api_prefix: str = "/api/v1"
    mlb_api_base: str = os.getenv("MLB_API_BASE", "https://statsapi.mlb.com/api/v1")
    mlb_live_base: str = os.getenv("MLB_LIVE_BASE", "https://statsapi.mlb.com/api/v1.1")
    npb_official_base: str = os.getenv("NPB_OFFICIAL_BASE", "https://npb.jp").strip().rstrip("/")
    npb_cache_ttl_seconds: int = _as_int("NPB_CACHE_TTL_SECONDS", 120)
    npb_stale_ttl_seconds: int = _as_int("NPB_STALE_TTL_SECONDS", 3600)
    kbo_schedule_url: str = os.getenv("KBO_SCHEDULE_URL", "https://eng.koreabaseball.com/Schedule/DailySchedule.aspx").strip()
    kbo_scoreboard_url: str = os.getenv("KBO_SCOREBOARD_URL", "https://eng.koreabaseball.com/Schedule/Scoreboard.aspx").strip()
    cpbl_schedule_url: str = os.getenv("CPBL_SCHEDULE_URL", "https://stats.cpbl.com.tw/schedule").strip()
    asian_baseball_cache_ttl_seconds: int = _as_int("ASIAN_BASEBALL_CACHE_TTL_SECONDS", 120)
    kbo_scoreboard_cache_ttl_seconds: int = max(30, _as_int("KBO_SCOREBOARD_CACHE_TTL_SECONDS", 60))
    asian_baseball_stale_ttl_seconds: int = _as_int("ASIAN_BASEBALL_STALE_TTL_SECONDS", 3600)
    savant_base: str = os.getenv("SAVANT_BASE", "https://baseballsavant.mlb.com").strip().rstrip("/")
    weather_api_base: str = os.getenv("WEATHER_API_BASE", "https://api.open-meteo.com/v1/forecast").strip()
    request_timeout_seconds: float = _as_float("REQUEST_TIMEOUT_SECONDS", 12.0)
    # Supabase writes are more important than upstream stat refreshes and may
    # occasionally take longer while Render/Supabase connections are warming.
    # These settings are optional; the defaults work without adding env vars.
    records_request_timeout_seconds: float = _as_float("RECORDS_REQUEST_TIMEOUT_SECONDS", 25.0)
    records_request_retries: int = max(0, _as_int("RECORDS_REQUEST_RETRIES", 2))
    records_retry_backoff_seconds: float = max(0.1, _as_float("RECORDS_RETRY_BACKOFF_SECONDS", 0.8))
    # Read-only member APIs must stay responsive even when Supabase or a free
    # Render instance is warming. Successful GET responses are cached briefly
    # and may be served stale during a transient outage.
    read_api_cache_ttl_seconds: int = max(5, _as_int("READ_API_CACHE_TTL_SECONDS", 45))
    read_api_stale_ttl_seconds: int = max(60, _as_int("READ_API_STALE_TTL_SECONDS", 900))
    read_api_timeout_seconds: float = max(3.0, _as_float("READ_API_TIMEOUT_SECONDS", 12.0))
    # Automatic settlement is background-only. A cooldown prevents overlapping
    # cron calls from repeatedly scanning MLB/NPB/KBO/CPBL and triggering Render
    # health notifications.
    settlement_min_interval_seconds: int = max(60, _as_int("SETTLEMENT_MIN_INTERVAL_SECONDS", 300))
    settlement_phase_timeout_seconds: float = max(30.0, _as_float("SETTLEMENT_PHASE_TIMEOUT_SECONDS", 150.0))
    settlement_internal_scheduler_enabled: bool = os.getenv(
        "SETTLEMENT_INTERNAL_SCHEDULER_ENABLED", "true"
    ).strip().lower() not in {"0", "false", "no", "off"}
    settlement_internal_interval_seconds: int = max(120, _as_int("SETTLEMENT_INTERNAL_INTERVAL_SECONDS", 300))
    settlement_internal_startup_delay_seconds: int = max(15, _as_int("SETTLEMENT_INTERNAL_STARTUP_DELAY_SECONDS", 45))
    settlement_source_probe_enabled: bool = os.getenv(
        "SETTLEMENT_SOURCE_PROBE_ENABLED", "false"
    ).strip().lower() not in {"0", "false", "no", "off"}
    social_sync_min_interval_seconds: int = max(60, _as_int("SOCIAL_SYNC_MIN_INTERVAL_SECONDS", 600))
    cache_ttl_seconds: int = _as_int("CACHE_TTL_SECONDS", 60)
    weather_cache_ttl_seconds: int = _as_int("WEATHER_CACHE_TTL_SECONDS", 1800)
    advanced_cache_ttl_seconds: int = _as_int("ADVANCED_CACHE_TTL_SECONDS", 21600)
    stale_ttl_seconds: int = _as_int("STALE_TTL_SECONDS", 1800)
    pregame_refresh_interval_seconds: int = _as_int("PREGAME_REFRESH_INTERVAL_SECONDS", 900)
    pregame_lineup_watch_minutes: int = _as_int("PREGAME_LINEUP_WATCH_MINUTES", 90)
    pregame_final_lock_minutes: int = _as_int("PREGAME_FINAL_LOCK_MINUTES", 30)
    npb_auto_publish_enabled: bool = os.getenv("NPB_AUTO_PUBLISH_ENABLED", "true").strip().lower() not in {"0", "false", "no", "off"}
    npb_pro_auto_publish_enabled: bool = os.getenv("NPB_PRO_AUTO_PUBLISH_ENABLED", "true").strip().lower() not in {"0", "false", "no", "off"}
    # Asian baseball odds collection and official publication use separate
    # windows. Providers may be probed and persisted from 12 hours before first
    # pitch, while immutable Free/Pro publication waits until the final 3-hour
    # window so the model can use a newer market and more complete team data.
    npb_odds_refresh_lead_minutes: int = _as_int(
        "NPB_ODDS_REFRESH_LEAD_MINUTES", 720
    )
    npb_auto_publish_lead_minutes: int = _as_int(
        "NPB_AUTO_PUBLISH_LEAD_MINUTES", 180
    )
    npb_auto_publish_scheduler_grace_minutes: int = _as_int(
        "NPB_AUTO_PUBLISH_SCHEDULER_GRACE_MINUTES", 0
    )
    kbo_auto_publish_enabled: bool = os.getenv("KBO_AUTO_PUBLISH_ENABLED", "true").strip().lower() not in {"0", "false", "no", "off"}
    kbo_pro_auto_publish_enabled: bool = os.getenv("KBO_PRO_AUTO_PUBLISH_ENABLED", "true").strip().lower() not in {"0", "false", "no", "off"}
    kbo_odds_refresh_lead_minutes: int = _as_int(
        "KBO_ODDS_REFRESH_LEAD_MINUTES", 720
    )
    kbo_auto_publish_lead_minutes: int = _as_int(
        "KBO_AUTO_PUBLISH_LEAD_MINUTES", 180
    )
    kbo_auto_publish_scheduler_grace_minutes: int = _as_int(
        "KBO_AUTO_PUBLISH_SCHEDULER_GRACE_MINUTES", 0
    )
    cpbl_auto_publish_enabled: bool = os.getenv("CPBL_AUTO_PUBLISH_ENABLED", "true").strip().lower() not in {"0", "false", "no", "off"}
    cpbl_pro_auto_publish_enabled: bool = os.getenv("CPBL_PRO_AUTO_PUBLISH_ENABLED", "true").strip().lower() not in {"0", "false", "no", "off"}
    cpbl_odds_refresh_lead_minutes: int = _as_int(
        "CPBL_ODDS_REFRESH_LEAD_MINUTES", 720
    )
    cpbl_auto_publish_lead_minutes: int = _as_int(
        "CPBL_AUTO_PUBLISH_LEAD_MINUTES", 180
    )
    cpbl_auto_publish_scheduler_grace_minutes: int = _as_int(
        "CPBL_AUTO_PUBLISH_SCHEDULER_GRACE_MINUTES", 0
    )
    monitor_data_stale_minutes: int = _as_int("MONITOR_DATA_STALE_MINUTES", 60)
    monitor_odds_stale_minutes: int = _as_int("MONITOR_ODDS_STALE_MINUTES", 360)
    monitor_odds_window_minutes: int = _as_int("MONITOR_ODDS_WINDOW_MINUTES", 180)
    monitor_settlement_grace_hours: int = _as_int("MONITOR_SETTLEMENT_GRACE_HOURS", 8)
    monitor_failure_threshold: int = _as_int("MONITOR_FAILURE_THRESHOLD", 2)
    minimum_publish_data_quality: float = _as_float("MINIMUM_PUBLISH_DATA_QUALITY", 0.55)
    minimum_lineup_validation_rate: float = _as_float("MINIMUM_LINEUP_VALIDATION_RATE", 0.90)
    min_confidence: float = _as_float("MIN_CONFIDENCE", 56.0)
    min_market_probability: float = _as_float("MIN_MARKET_PROBABILITY", 53.0)
    min_market_edge: float = _as_float("MIN_MARKET_EDGE", 3.0)
    min_projection_quality: float = _as_float("MIN_PROJECTION_QUALITY", 0.45)
    min_parlay_leg_probability: float = _as_float("MIN_PARLAY_LEG_PROBABILITY", 54.0)
    # V22.2 probability calibration uses a Champion/Challenger lifecycle.
    # Scheduled optimization may create TEST challengers, but production
    # promotion always requires an explicit founder confirmation.
    model_calibration_enabled: bool = os.getenv(
        "MODEL_CALIBRATION_ENABLED", "true"
    ).strip().lower() not in {"0", "false", "no", "off"}
    model_calibration_auto_promote: bool = os.getenv(
        "MODEL_CALIBRATION_AUTO_PROMOTE", "false"
    ).strip().lower() not in {"0", "false", "no", "off"}
    model_calibration_interval_seconds: int = max(
        1800, _as_int("MODEL_CALIBRATION_INTERVAL_SECONDS", 21600)
    )
    model_calibration_startup_delay_seconds: int = max(
        30, _as_int("MODEL_CALIBRATION_STARTUP_DELAY_SECONDS", 120)
    )
    model_calibration_minimum_sample: int = max(
        40, _as_int("MODEL_CALIBRATION_MINIMUM_SAMPLE", 60)
    )
    model_calibration_minimum_validation_sample: int = max(
        12, _as_int("MODEL_CALIBRATION_MINIMUM_VALIDATION_SAMPLE", 18)
    )
    model_calibration_lookback_days: int = max(
        90, _as_int("MODEL_CALIBRATION_LOOKBACK_DAYS", 365)
    )
    retry_queue_enabled: bool = os.getenv(
        "RETRY_QUEUE_ENABLED", "true"
    ).strip().lower() not in {"0", "false", "no", "off"}
    retry_queue_poll_seconds: int = max(
        15, _as_int("RETRY_QUEUE_POLL_SECONDS", 30)
    )
    retry_queue_max_attempts: int = max(
        1, _as_int("RETRY_QUEUE_MAX_ATTEMPTS", 5)
    )
    # Render exposes these automatically when available. They are operational
    # identifiers only; no API key or secret is returned to the founder UI.
    render_service_name: str = os.getenv("RENDER_SERVICE_NAME", "").strip()
    render_service_id: str = os.getenv("RENDER_SERVICE_ID", "").strip()
    render_instance_id: str = os.getenv("RENDER_INSTANCE_ID", "").strip()
    render_git_commit: str = os.getenv("RENDER_GIT_COMMIT", "").strip()
    odds_api_base: str = os.getenv(
        "ODDS_API_BASE", "https://api.the-odds-api.com/v4"
    ).strip().rstrip("/")
    odds_api_key: str = os.getenv("ODDS_API_KEY", "").strip()
    odds_sport_key: str = os.getenv("ODDS_SPORT_KEY", "baseball_mlb").strip()
    npb_odds_sport_key: str = os.getenv("NPB_ODDS_SPORT_KEY", "baseball_npb").strip()
    kbo_odds_sport_key: str = os.getenv("KBO_ODDS_SPORT_KEY", "baseball_kbo").strip()
    cpbl_odds_sport_key: str = os.getenv("CPBL_ODDS_SPORT_KEY", "baseball_cpbl").strip()
    odds_bookmakers_raw: str = os.getenv(
        "ODDS_BOOKMAKERS", "draftkings,fanduel,betmgm,williamhill_us"
    )
    npb_odds_bookmakers_raw: str = os.getenv(
        "NPB_ODDS_BOOKMAKERS", "pinnacle,betonlineag,bovada,betus,mybookieag"
    )
    kbo_odds_bookmakers_raw: str = os.getenv(
        "KBO_ODDS_BOOKMAKERS", "pinnacle,betonlineag,bovada,betus,mybookieag"
    )
    cpbl_odds_bookmakers_raw: str = os.getenv(
        "CPBL_ODDS_BOOKMAKERS", "pinnacle,betonlineag,bovada,betus,mybookieag"
    )
    odds_markets_raw: str = os.getenv("ODDS_MARKETS", "h2h,spreads,totals")
    odds_cache_ttl_seconds: int = _as_int("ODDS_CACHE_TTL_SECONDS", 900)
    odds_stale_ttl_seconds: int = _as_int("ODDS_STALE_TTL_SECONDS", 3600)
    # Free-plan routing protects The Odds API's monthly 500-credit allowance.
    # NPB/KBO receive limited primary probes, MLB prefers the high-daily-limit
    # fallback, and CPBL avoids a primary sport that is normally unavailable.
    odds_free_optimization_enabled: bool = os.getenv(
        "ODDS_FREE_OPTIMIZATION_ENABLED", "true"
    ).strip().lower() not in {"0", "false", "no", "off"}
    odds_primary_probe_cooldown_minutes: int = max(
        60, _as_int("ODDS_PRIMARY_PROBE_COOLDOWN_MINUTES", 360)
    )
    odds_primary_quota_retry_minutes: int = max(
        360, _as_int("ODDS_PRIMARY_QUOTA_RETRY_MINUTES", 1440)
    )
    odds_fallback_probe_cooldown_minutes: int = max(
        10, _as_int("ODDS_FALLBACK_PROBE_COOLDOWN_MINUTES", 30)
    )
    # The latest verified bookmaker payload is stored in Supabase. It remains
    # visible during a provider outage, while new Pro publication is allowed
    # only inside the bounded freshness window.
    odds_snapshot_enabled: bool = os.getenv(
        "ODDS_SNAPSHOT_ENABLED", "true"
    ).strip().lower() not in {"0", "false", "no", "off"}
    odds_snapshot_publish_fresh_minutes: int = max(
        30, _as_int("ODDS_SNAPSHOT_PUBLISH_FRESH_MINUTES", 360)
    )
    odds_snapshot_display_hours: int = max(
        6, _as_int("ODDS_SNAPSHOT_DISPLAY_HOURS", 36)
    )
    # Daily-limit baseball provider. Keep this key separate from ODDS_API_KEY;
    # the free-plan router prefers it for MLB/CPBL and uses it as the NPB/KBO
    # fallback after a bounded monthly-primary probe.
    odds_api_io_base: str = os.getenv("ODDS_API_IO_BASE", "https://api.odds-api.io/v3").strip().rstrip("/")
    odds_api_io_key: str = os.getenv("ODDS_API_IO_KEY", "").strip()
    odds_api_io_cpbl_sport: str = os.getenv("ODDS_API_IO_CPBL_SPORT", "baseball").strip() or "baseball"
    odds_api_io_cpbl_league_slug: str = os.getenv("ODDS_API_IO_CPBL_LEAGUE_SLUG", "").strip()
    odds_api_io_cpbl_bookmakers_raw: str = os.getenv(
        "ODDS_API_IO_CPBL_BOOKMAKERS", "Bet365,Unibet"
    )
    odds_api_io_mlb_sport: str = os.getenv("ODDS_API_IO_MLB_SPORT", "baseball").strip() or "baseball"
    odds_api_io_mlb_league_slug: str = os.getenv("ODDS_API_IO_MLB_LEAGUE_SLUG", "").strip()
    odds_api_io_mlb_bookmakers_raw: str = os.getenv(
        "ODDS_API_IO_MLB_BOOKMAKERS", "Bet365,Unibet"
    )
    odds_api_io_npb_sport: str = os.getenv("ODDS_API_IO_NPB_SPORT", "baseball").strip() or "baseball"
    odds_api_io_npb_league_slug: str = os.getenv("ODDS_API_IO_NPB_LEAGUE_SLUG", "").strip()
    odds_api_io_npb_bookmakers_raw: str = os.getenv(
        "ODDS_API_IO_NPB_BOOKMAKERS", "Bet365,Unibet"
    )
    odds_api_io_kbo_sport: str = os.getenv("ODDS_API_IO_KBO_SPORT", "baseball").strip() or "baseball"
    odds_api_io_kbo_league_slug: str = os.getenv("ODDS_API_IO_KBO_LEAGUE_SLUG", "").strip()
    odds_api_io_kbo_bookmakers_raw: str = os.getenv(
        "ODDS_API_IO_KBO_BOOKMAKERS", "Bet365,Unibet"
    )
    # Odds-API.io free-plan protection (effective 2026-07-26): only use
    # explicitly recreational/free bookmakers, cache full feeds aggressively,
    # and reserve part of the daily/hourly allowance for automatic final checks.
    odds_api_io_free_plan_only: bool = os.getenv(
        "ODDS_API_IO_FREE_PLAN_ONLY", "true"
    ).strip().lower() not in {"0", "false", "no", "off"}
    odds_api_io_free_bookmakers_raw: str = os.getenv(
        "ODDS_API_IO_FREE_BOOKMAKERS", "Bet365,Unibet,DraftKings,FanDuel"
    )
    odds_api_io_cache_ttl_seconds: int = max(300, _as_int("ODDS_API_IO_CACHE_TTL_SECONDS", 900))
    odds_api_io_events_cache_ttl_seconds: int = max(300, _as_int("ODDS_API_IO_EVENTS_CACHE_TTL_SECONDS", 900))
    odds_api_io_metadata_cache_ttl_seconds: int = max(3600, _as_int("ODDS_API_IO_METADATA_CACHE_TTL_SECONDS", 21600))
    odds_api_io_stale_ttl_seconds: int = max(3600, _as_int("ODDS_API_IO_STALE_TTL_SECONDS", 86400))
    odds_api_io_feed_far_cache_seconds: int = max(600, _as_int("ODDS_API_IO_FEED_FAR_CACHE_SECONDS", 1800))
    odds_api_io_feed_near_cache_seconds: int = max(300, _as_int("ODDS_API_IO_FEED_NEAR_CACHE_SECONDS", 600))
    odds_api_io_feed_final_cache_seconds: int = max(180, _as_int("ODDS_API_IO_FEED_FINAL_CACHE_SECONDS", 300))
    odds_api_io_feed_post_start_cache_seconds: int = max(1800, _as_int("ODDS_API_IO_FEED_POST_START_CACHE_SECONDS", 21600))
    odds_api_io_daily_limit: int = max(1, _as_int("ODDS_API_IO_DAILY_LIMIT", 500))
    odds_api_io_daily_soft_limit: int = max(1, _as_int("ODDS_API_IO_DAILY_SOFT_LIMIT", 450))
    odds_api_io_hourly_limit: int = max(1, _as_int("ODDS_API_IO_HOURLY_LIMIT", 100))
    odds_api_io_hourly_soft_limit: int = max(1, _as_int("ODDS_API_IO_HOURLY_SOFT_LIMIT", 90))
    odds_api_io_quota_ledger_path: str = os.getenv(
        "ODDS_API_IO_QUOTA_LEDGER_PATH", "/tmp/diamondmind_odds_api_io_quota.json"
    ).strip() or "/tmp/diamondmind_odds_api_io_quota.json"
    odds_api_io_bookmaker_group_size: int = max(1, _as_int("ODDS_API_IO_BOOKMAKER_GROUP_SIZE", 2))
    odds_api_io_cpbl_max_bookmakers: int = max(1, _as_int("ODDS_API_IO_CPBL_MAX_BOOKMAKERS", 2))
    odds_api_io_mlb_max_bookmakers: int = max(1, _as_int("ODDS_API_IO_MLB_MAX_BOOKMAKERS", 2))
    odds_api_io_npb_max_bookmakers: int = max(1, _as_int("ODDS_API_IO_NPB_MAX_BOOKMAKERS", 2))
    odds_api_io_kbo_max_bookmakers: int = max(1, _as_int("ODDS_API_IO_KBO_MAX_BOOKMAKERS", 2))
    # When the provider cannot return the account-selected bookmaker list,
    # probe only a small preference set instead of scanning the full catalog.
    # This protects free-plan bookmaker slots and request quota.
    odds_api_io_safe_fallback_bookmakers: int = _as_int(
        "ODDS_API_IO_SAFE_FALLBACK_BOOKMAKERS", 2
    )
    cron_secret: str = os.getenv("CRON_SECRET", "").strip()
    # LINE Messaging API broadcasts. The token must be stored only in Render
    # environment variables and is never returned by any status endpoint.
    line_messaging_enabled_raw: bool = os.getenv(
        "LINE_MESSAGING_ENABLED", "false"
    ).strip().lower() not in {"0", "false", "no", "off"}
    line_channel_access_token: str = os.getenv("LINE_CHANNEL_ACCESS_TOKEN", "").strip()
    line_api_base: str = os.getenv("LINE_API_BASE", "https://api.line.me").strip().rstrip("/")
    line_community_url: str = os.getenv("LINE_COMMUNITY_URL", "").strip()
    line_sync_min_interval_seconds: int = max(10, _as_int("LINE_SYNC_MIN_INTERVAL_SECONDS", 30))
    line_retry_lookback_days: int = max(1, min(_as_int("LINE_RETRY_LOOKBACK_DAYS", 2), 7))
    line_max_events_per_sync: int = max(1, min(_as_int("LINE_MAX_EVENTS_PER_SYNC", 8), 20))
    line_notification_max_age_hours: int = max(1, min(_as_int("LINE_NOTIFICATION_MAX_AGE_HOURS", 24), 168))
    line_request_timeout_seconds: float = max(3.0, _as_float("LINE_REQUEST_TIMEOUT_SECONDS", 12.0))
    line_request_retries: int = max(0, min(_as_int("LINE_REQUEST_RETRIES", 2), 5))
    line_retry_backoff_seconds: float = max(0.2, _as_float("LINE_RETRY_BACKOFF_SECONDS", 1.0))
    line_notify_free_publish: bool = os.getenv(
        "LINE_NOTIFY_FREE_PUBLISH", "true"
    ).strip().lower() not in {"0", "false", "no", "off"}
    line_notify_pro_publish: bool = os.getenv(
        "LINE_NOTIFY_PRO_PUBLISH", "true"
    ).strip().lower() not in {"0", "false", "no", "off"}
    line_notify_settlement: bool = os.getenv(
        "LINE_NOTIFY_SETTLEMENT", "true"
    ).strip().lower() not in {"0", "false", "no", "off"}
    instagram_auto_publish_enabled: bool = os.getenv(
        "INSTAGRAM_AUTO_PUBLISH_ENABLED", "false"
    ).strip().lower() not in {"0", "false", "no", "off"}
    instagram_user_id: str = os.getenv("INSTAGRAM_USER_ID", "").strip()
    instagram_access_token: str = os.getenv("INSTAGRAM_ACCESS_TOKEN", "").strip()
    instagram_graph_version: str = os.getenv("INSTAGRAM_GRAPH_VERSION", "v25.0").strip() or "v25.0"
    instagram_graph_base: str = os.getenv(
        "INSTAGRAM_GRAPH_BASE", "https://graph.facebook.com"
    ).strip().rstrip("/")
    instagram_asset_secret: str = os.getenv("INSTAGRAM_ASSET_SECRET", "").strip()
    # V19.1 publishing policy: pregame content is Story-only; settled results are Reels shared to Feed.
    instagram_publish_feed: bool = os.getenv(
        "INSTAGRAM_PUBLISH_FEED", "false"
    ).strip().lower() not in {"0", "false", "no", "off"}
    instagram_publish_story: bool = os.getenv(
        "INSTAGRAM_PUBLISH_STORY", "true"
    ).strip().lower() not in {"0", "false", "no", "off"}
    instagram_publish_result_reels: bool = os.getenv(
        "INSTAGRAM_PUBLISH_RESULT_REELS", "true"
    ).strip().lower() not in {"0", "false", "no", "off"}
    instagram_reel_share_to_feed: bool = os.getenv(
        "INSTAGRAM_REEL_SHARE_TO_FEED", "true"
    ).strip().lower() not in {"0", "false", "no", "off"}
    instagram_auto_comment: bool = os.getenv(
        "INSTAGRAM_AUTO_COMMENT", "true"
    ).strip().lower() not in {"0", "false", "no", "off"}
    instagram_auto_mlb_enabled: bool = os.getenv(
        "INSTAGRAM_AUTO_MLB_ENABLED", "true"
    ).strip().lower() not in {"0", "false", "no", "off"}
    instagram_auto_npb_enabled: bool = os.getenv(
        "INSTAGRAM_AUTO_NPB_ENABLED", "true"
    ).strip().lower() not in {"0", "false", "no", "off"}
    instagram_auto_kbo_enabled: bool = os.getenv(
        "INSTAGRAM_AUTO_KBO_ENABLED", "true"
    ).strip().lower() not in {"0", "false", "no", "off"}
    instagram_auto_cpbl_enabled: bool = os.getenv(
        "INSTAGRAM_AUTO_CPBL_ENABLED", "true"
    ).strip().lower() not in {"0", "false", "no", "off"}
    instagram_post_free_pregame: bool = os.getenv(
        "INSTAGRAM_POST_FREE_PREGAME", "true"
    ).strip().lower() not in {"0", "false", "no", "off"}
    instagram_post_free_result: bool = os.getenv(
        "INSTAGRAM_POST_FREE_RESULT", "false"
    ).strip().lower() not in {"0", "false", "no", "off"}
    instagram_post_pro_teaser: bool = os.getenv(
        "INSTAGRAM_POST_PRO_TEASER", "true"
    ).strip().lower() not in {"0", "false", "no", "off"}
    instagram_post_pro_result: bool = os.getenv(
        "INSTAGRAM_POST_PRO_RESULT", "true"
    ).strip().lower() not in {"0", "false", "no", "off"}
    instagram_retry_lookback_days: int = _as_int("INSTAGRAM_RETRY_LOOKBACK_DAYS", 2)
    instagram_max_events_per_sync: int = _as_int("INSTAGRAM_MAX_EVENTS_PER_SYNC", 6)
    instagram_pro_batch_size: int = _as_int("INSTAGRAM_PRO_BATCH_SIZE", 5)
    instagram_story_lead_minutes: int = _as_int("INSTAGRAM_STORY_LEAD_MINUTES", 60)
    instagram_reel_processing_attempts: int = _as_int("INSTAGRAM_REEL_PROCESSING_ATTEMPTS", 60)
    instagram_reel_processing_interval_seconds: float = _as_float("INSTAGRAM_REEL_PROCESSING_INTERVAL_SECONDS", 2.0)
    instagram_reel_max_cards: int = _as_int("INSTAGRAM_REEL_MAX_CARDS", 30)
    instagram_reel_card_seconds: float = _as_float("INSTAGRAM_REEL_CARD_SECONDS", 2.2)
    instagram_reel_batch_seconds: float = _as_float("INSTAGRAM_REEL_BATCH_SECONDS", 3.2)
    instagram_reel_summary_seconds: float = _as_float("INSTAGRAM_REEL_SUMMARY_SECONDS", 4.5)
    instagram_reel_transition_seconds: float = _as_float("INSTAGRAM_REEL_TRANSITION_SECONDS", 0.24)
    instagram_reel_audio_enabled: bool = os.getenv(
        "INSTAGRAM_REEL_AUDIO_ENABLED", "true"
    ).strip().lower() not in {"0", "false", "no", "off"}
    social_font_path: str = os.getenv("SOCIAL_FONT_PATH", "").strip()
    social_font_url: str = os.getenv(
        "SOCIAL_FONT_URL",
        "https://raw.githubusercontent.com/notofonts/noto-cjk/main/Sans/OTF/TraditionalChinese/NotoSansCJKtc-Regular.otf",
    ).strip()
    social_font_bold_path: str = os.getenv("SOCIAL_FONT_BOLD_PATH", "").strip()
    social_font_bold_url: str = os.getenv(
        "SOCIAL_FONT_BOLD_URL",
        "https://raw.githubusercontent.com/notofonts/noto-cjk/main/Sans/OTF/TraditionalChinese/NotoSansCJKtc-Bold.otf",
    ).strip()
    social_logo_path: str = os.getenv("SOCIAL_LOGO_PATH", "").strip()
    social_reel_cache_dir: str = os.getenv("SOCIAL_REEL_CACHE_DIR", "/tmp/diamondmind-social-reels").strip()
    supabase_url: str = os.getenv("SUPABASE_URL", "").strip().rstrip("/")
    supabase_secret_key: str = (
        os.getenv("SUPABASE_SECRET_KEY")
        or os.getenv("SUPABASE_SERVICE_ROLE_KEY")
        or ""
    ).strip()
    records_limit: int = _as_int("RECORDS_LIMIT", 500)
    public_api_base: str = os.getenv(
        "PUBLIC_API_BASE", "https://diamondmind-api.onrender.com"
    ).strip().rstrip("/")
    frontend_base_url: str = os.getenv(
        "FRONTEND_BASE_URL", "https://gigia1127520-gif.github.io/diamondmind-web"
    ).strip().rstrip("/")
    support_email: str = os.getenv("SUPPORT_EMAIL", "").strip()
    legal_effective_date: str = os.getenv("LEGAL_EFFECTIVE_DATE", "2026-07-15").strip()
    new_member_trial_enabled: bool = os.getenv("NEW_MEMBER_TRIAL_ENABLED", "true").strip().lower() not in {"0", "false", "no", "off"}
    new_member_trial_hours: int = _as_int("NEW_MEMBER_TRIAL_HOURS", 24)
    new_member_trial_start_at: str = os.getenv("NEW_MEMBER_TRIAL_START_AT", "2026-07-15T00:00:00+08:00").strip()
    ecpay_mode: str = os.getenv("ECPAY_MODE", "stage").strip().lower()
    ecpay_merchant_id: str = os.getenv(
        "ECPAY_MERCHANT_ID",
        "3002607" if os.getenv("ECPAY_MODE", "stage").strip().lower() == "stage" else "",
    ).strip()
    ecpay_hash_key: str = os.getenv(
        "ECPAY_HASH_KEY",
        "pwFHCqoQZGmho4w6" if os.getenv("ECPAY_MODE", "stage").strip().lower() == "stage" else "",
    ).strip()
    ecpay_hash_iv: str = os.getenv(
        "ECPAY_HASH_IV",
        "EkRm7iFT261dpevs" if os.getenv("ECPAY_MODE", "stage").strip().lower() == "stage" else "",
    ).strip()
    ecpay_test_emails_raw: str = os.getenv("ECPAY_TEST_EMAILS", "")
    cors_origins_raw: str = os.getenv(
        "CORS_ORIGINS",
        "https://gigia1127520-gif.github.io,http://localhost:8000,http://127.0.0.1:8000",
    )

    @property
    def cors_origins(self) -> list[str]:
        values = [value.strip() for value in self.cors_origins_raw.split(",") if value.strip()]
        return values or ["*"]

    @property
    def records_enabled(self) -> bool:
        return bool(self.supabase_url and self.supabase_secret_key)

    @property
    def odds_enabled(self) -> bool:
        return bool(self.odds_api_key)

    @property
    def odds_api_io_enabled(self) -> bool:
        return bool(self.odds_api_io_key)

    @property
    def odds_api_io_free_bookmakers(self) -> list[str]:
        values = [
            value.strip()
            for value in self.odds_api_io_free_bookmakers_raw.split(",")
            if value.strip()
        ]
        return list(dict.fromkeys(values)) or ["Bet365", "Unibet", "DraftKings", "FanDuel"]

    @property
    def odds_api_io_cpbl_bookmakers(self) -> list[str]:
        values = [
            value.strip()
            for value in self.odds_api_io_cpbl_bookmakers_raw.split(",")
            if value.strip()
        ]
        values = list(dict.fromkeys(values))
        if self.odds_api_io_free_plan_only:
            allowed = {value.casefold() for value in self.odds_api_io_free_bookmakers}
            values = [value for value in values if value.casefold() in allowed]
        return values[: max(1, self.odds_api_io_cpbl_max_bookmakers)] or ["Bet365", "Unibet"]

    @property
    def odds_api_io_mlb_bookmakers(self) -> list[str]:
        values = [
            value.strip()
            for value in self.odds_api_io_mlb_bookmakers_raw.split(",")
            if value.strip()
        ]
        values = list(dict.fromkeys(values))
        if self.odds_api_io_free_plan_only:
            allowed = {value.casefold() for value in self.odds_api_io_free_bookmakers}
            values = [value for value in values if value.casefold() in allowed]
        return values[: max(1, self.odds_api_io_mlb_max_bookmakers)] or ["Bet365", "Unibet"]

    @property
    def odds_api_io_npb_bookmakers(self) -> list[str]:
        values = [
            value.strip()
            for value in self.odds_api_io_npb_bookmakers_raw.split(",")
            if value.strip()
        ]
        values = list(dict.fromkeys(values))
        if self.odds_api_io_free_plan_only:
            allowed = {value.casefold() for value in self.odds_api_io_free_bookmakers}
            values = [value for value in values if value.casefold() in allowed]
        return values[: max(1, self.odds_api_io_npb_max_bookmakers)] or ["Bet365", "Unibet"]

    @property
    def odds_api_io_kbo_bookmakers(self) -> list[str]:
        values = [
            value.strip()
            for value in self.odds_api_io_kbo_bookmakers_raw.split(",")
            if value.strip()
        ]
        values = list(dict.fromkeys(values))
        if self.odds_api_io_free_plan_only:
            allowed = {value.casefold() for value in self.odds_api_io_free_bookmakers}
            values = [value for value in values if value.casefold() in allowed]
        return values[: max(1, self.odds_api_io_kbo_max_bookmakers)] or ["Bet365", "Unibet"]

    @property
    def scheduler_enabled(self) -> bool:
        return bool(self.cron_secret)

    @property
    def odds_bookmakers(self) -> list[str]:
        # The provider counts each group of ten bookmakers as one region.
        # Keeping this capped at ten makes every three-market refresh cost
        # exactly three usage credits.
        values = [
            value.strip().lower()
            for value in self.odds_bookmakers_raw.split(",")
            if value.strip()
        ]
        return list(dict.fromkeys(values))[:10]

    @property
    def npb_odds_bookmakers(self) -> list[str]:
        values = [
            value.strip().lower()
            for value in self.npb_odds_bookmakers_raw.split(",")
            if value.strip()
        ]
        return list(dict.fromkeys(values))[:10]

    @property
    def kbo_odds_bookmakers(self) -> list[str]:
        values = [
            value.strip().lower()
            for value in self.kbo_odds_bookmakers_raw.split(",")
            if value.strip()
        ]
        return list(dict.fromkeys(values))[:10]

    @property
    def cpbl_odds_bookmakers(self) -> list[str]:
        values = [
            value.strip().lower()
            for value in self.cpbl_odds_bookmakers_raw.split(",")
            if value.strip()
        ]
        return list(dict.fromkeys(values))[:10]

    @property
    def odds_markets(self) -> list[str]:
        supported = {"h2h", "spreads", "totals"}
        values = [
            value.strip().lower()
            for value in self.odds_markets_raw.split(",")
            if value.strip().lower() in supported
        ]
        return list(dict.fromkeys(values)) or ["h2h", "spreads", "totals"]

    @property
    def line_messaging_enabled(self) -> bool:
        return bool(self.line_messaging_enabled_raw and self.line_channel_access_token)

    @property
    def billing_enabled(self) -> bool:
        return bool(
            self.records_enabled
            and self.ecpay_mode in {"stage", "production"}
            and self.ecpay_merchant_id
            and self.ecpay_hash_key
            and self.ecpay_hash_iv
            and self.public_api_base
            and self.frontend_base_url
        )

    @property
    def ecpay_checkout_url(self) -> str:
        return (
            "https://payment.ecpay.com.tw/Cashier/AioCheckOut/V5"
            if self.ecpay_mode == "production"
            else "https://payment-stage.ecpay.com.tw/Cashier/AioCheckOut/V5"
        )

    @property
    def ecpay_period_action_url(self) -> str:
        return (
            "https://payment.ecpay.com.tw/Cashier/CreditCardPeriodAction"
            if self.ecpay_mode == "production"
            else "https://payment-stage.ecpay.com.tw/Cashier/CreditCardPeriodAction"
        )

    @property
    def ecpay_test_emails(self) -> set[str]:
        return {
            value.strip().lower()
            for value in self.ecpay_test_emails_raw.split(",")
            if value.strip()
        }


settings = Settings()
