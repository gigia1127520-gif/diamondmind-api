from __future__ import annotations

import os
from dataclasses import dataclass


def _as_float(name: str, default: float) -> float:
    try:
        return float(os.getenv(name, default))
    except (TypeError, ValueError):
        return default


def _as_int(name: str, default: int) -> int:
    try:
        return int(os.getenv(name, default))
    except (TypeError, ValueError):
        return default


@dataclass(frozen=True)
class Settings:
    app_name: str = os.getenv("APP_NAME", "DiamondMind API")
    app_env: str = os.getenv("APP_ENV", "development")
    api_prefix: str = "/api/v1"
    mlb_api_base: str = os.getenv("MLB_API_BASE", "https://statsapi.mlb.com/api/v1")
    mlb_live_base: str = os.getenv("MLB_LIVE_BASE", "https://statsapi.mlb.com/api/v1.1")
    request_timeout_seconds: float = _as_float("REQUEST_TIMEOUT_SECONDS", 12.0)
    cache_ttl_seconds: int = _as_int("CACHE_TTL_SECONDS", 60)
    stale_ttl_seconds: int = _as_int("STALE_TTL_SECONDS", 1800)
    min_confidence: float = _as_float("MIN_CONFIDENCE", 56.0)
    cors_origins_raw: str = os.getenv(
        "CORS_ORIGINS",
        "https://gigia1127520-gif.github.io,http://localhost:8000,http://127.0.0.1:8000",
    )

    @property
    def cors_origins(self) -> list[str]:
        values = [value.strip() for value in self.cors_origins_raw.split(",") if value.strip()]
        return values or ["*"]


settings = Settings()

