from __future__ import annotations

import asyncio
from datetime import timedelta
from typing import Any

from .billing import BillingError, BillingRepository, iso_utc, parse_datetime, utc_now
from .config import Settings


class NewMemberTrialError(RuntimeError):
    pass


class NewMemberTrialService:
    """Grant one verified 24-hour Pro trial to registrations after rollout.

    A normalized-email claim table prevents a deleted account from registering
    again with the same email to receive another trial. Paid members, founders,
    unverified emails and pre-rollout accounts are never auto-granted.
    """

    def __init__(self, settings: Settings, repository: BillingRepository) -> None:
        self.settings = settings
        self.repository = repository
        self.enabled = bool(settings.records_enabled and settings.new_member_trial_enabled and settings.new_member_trial_hours > 0)
        self._locks: dict[str, asyncio.Lock] = {}

    def _lock(self, user_id: str) -> asyncio.Lock:
        lock = self._locks.get(user_id)
        if lock is None:
            lock = asyncio.Lock()
            self._locks[user_id] = lock
        return lock

    async def claim(self, member: dict[str, Any]) -> dict[str, Any]:
        if not self.enabled:
            return {"ok": True, "granted": False, "reason": "disabled"}
        user_id = str(member.get("id") or "").strip()
        if not user_id:
            raise NewMemberTrialError("會員資料不完整")

        async with self._lock(user_id):
            user = await self.repository.admin_user(user_id)
            email = str(user.get("email") or "").strip()
            normalized_email = email.lower()
            if not normalized_email:
                return {"ok": True, "granted": False, "reason": "missing_email"}
            if not (user.get("email_confirmed_at") or user.get("confirmed_at")):
                return {"ok": True, "granted": False, "reason": "email_not_verified"}

            created_at = parse_datetime(user.get("created_at"))
            rollout_at = parse_datetime(self.settings.new_member_trial_start_at)
            if rollout_at and (not created_at or created_at < rollout_at):
                return {"ok": True, "granted": False, "reason": "pre_rollout_account"}

            metadata = user.get("app_metadata") or {}
            role = str(metadata.get("role") or "free").lower()
            if role in {"admin", "founder"}:
                return {"ok": True, "granted": False, "reason": "founder"}

            now = utc_now()
            subscription = await self.repository.subscription_for_user(user_id)
            current_end = parse_datetime((subscription or {}).get("current_period_end"))
            if (subscription or {}).get("status") == "active" and current_end and current_end > now:
                return {"ok": True, "granted": False, "reason": "already_pro", "expires_at": iso_utc(current_end)}
            # Never overwrite a pending payment or a founder/manual membership record.
            # Automatic trials are only for accounts that have never had a membership row.
            if subscription and str(subscription.get("provider") or "").lower() != "trial":
                return {"ok": True, "granted": False, "reason": "existing_membership_record"}

            successful = [row for row in await self.repository.list_payment_events(user_id=user_id, limit=50) if bool(row.get("success"))]
            if successful:
                return {"ok": True, "granted": False, "reason": "previous_payment"}

            existing = await self.repository.trial_claim_for_user(user_id=user_id, normalized_email=normalized_email)
            if existing and str(existing.get("status") or "") == "active":
                return {"ok": True, "granted": False, "reason": "already_claimed", "expires_at": existing.get("expires_at")}

            expires_at = now + timedelta(hours=max(1, int(self.settings.new_member_trial_hours)))
            claim = existing
            if claim:
                claim = await self.repository.update_trial_claim(claim["id"], {
                    "user_id": user_id,
                    "email": email,
                    "status": "pending",
                    "duration_hours": int(self.settings.new_member_trial_hours),
                    "granted_at": iso_utc(now),
                    "expires_at": iso_utc(expires_at),
                    "last_error": None,
                })
            else:
                try:
                    claim = await self.repository.create_trial_claim({
                        "user_id": user_id,
                        "email": email,
                        "normalized_email": normalized_email,
                        "status": "pending",
                        "source": "new_registration",
                        "duration_hours": int(self.settings.new_member_trial_hours),
                        "granted_at": iso_utc(now),
                        "expires_at": iso_utc(expires_at),
                    })
                except BillingError:
                    duplicate = await self.repository.trial_claim_for_user(user_id=user_id, normalized_email=normalized_email)
                    if duplicate:
                        return {"ok": True, "granted": False, "reason": "already_claimed", "expires_at": duplicate.get("expires_at")}
                    raise

            try:
                updated_subscription = await self.repository.upsert_manual_subscription(
                    user_id=user_id,
                    email=email,
                    plan_code="trial_1d",
                    period_start=now,
                    period_end=expires_at,
                    status="active",
                    provider="trial",
                    message="Verified new-member 24-hour Pro trial",
                )
                await self.repository.update_app_metadata(user_id, {
                    "role": "pro",
                    "plan": "trial_1d",
                    "billing_provider": "trial",
                    "billing_status": "active",
                    "billing_auto_renew": False,
                    "billing_trade_no": None,
                    "pro_expires_at": iso_utc(expires_at),
                    "trial_claimed_at": iso_utc(now),
                    "trial_expires_at": iso_utc(expires_at),
                    "trial_source": "new_registration",
                })
                await self.repository.update_trial_claim(claim["id"], {"status": "active", "last_error": None})
            except Exception as exc:
                try:
                    await self.repository.update_trial_claim(claim["id"], {"status": "failed", "last_error": str(exc)[:300]})
                except Exception:
                    pass
                raise

            return {
                "ok": True,
                "granted": True,
                "plan": "trial_1d",
                "hours": int(self.settings.new_member_trial_hours),
                "expires_at": updated_subscription.get("current_period_end") or iso_utc(expires_at),
            }
