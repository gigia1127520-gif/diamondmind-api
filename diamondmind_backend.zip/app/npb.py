from __future__ import annotations

import asyncio
import html
import math
import re
from dataclasses import dataclass
from datetime import date, datetime, time, timedelta
from html.parser import HTMLParser
from typing import Any
from urllib.parse import urljoin
from zoneinfo import ZoneInfo

import httpx

from .cache import AsyncTTLCache
from .config import Settings


TAIPEI = ZoneInfo("Asia/Taipei")
TOKYO = ZoneInfo("Asia/Tokyo")


class NPBUpstreamError(RuntimeError):
    pass


@dataclass
class HtmlPayload:
    text: str
    cache_status: str
    fetched_at: str
    source_url: str


@dataclass(frozen=True)
class TeamInfo:
    canonical: str
    short: str
    abbr: str
    zh: str


TEAM_BY_SHORT: dict[str, TeamInfo] = {
    "Yakult": TeamInfo("Tokyo Yakult Swallows", "Yakult", "S", "東京養樂多燕子"),
    "Yomiuri": TeamInfo("Yomiuri Giants", "Yomiuri", "G", "讀賣巨人"),
    "DeNA": TeamInfo("YOKOHAMA DeNA BAYSTARS", "DeNA", "DB", "橫濱DeNA海灣之星"),
    "Chunichi": TeamInfo("Chunichi Dragons", "Chunichi", "D", "中日龍"),
    "Hanshin": TeamInfo("Hanshin Tigers", "Hanshin", "T", "阪神虎"),
    "Hiroshima": TeamInfo("Hiroshima Toyo Carp", "Hiroshima", "C", "廣島東洋鯉魚"),
    "SoftBank": TeamInfo("Fukuoka SoftBank Hawks", "SoftBank", "H", "福岡軟銀鷹"),
    "Nippon-Ham": TeamInfo("Hokkaido Nippon-Ham Fighters", "Nippon-Ham", "F", "北海道日本火腿鬥士"),
    "ORIX": TeamInfo("ORIX Buffaloes", "ORIX", "B", "歐力士猛牛"),
    "Rakuten": TeamInfo("Tohoku Rakuten Golden Eagles", "Rakuten", "E", "東北樂天金鷲"),
    "Seibu": TeamInfo("Saitama Seibu Lions", "Seibu", "L", "埼玉西武獅"),
    "Lotte": TeamInfo("Chiba Lotte Marines", "Lotte", "M", "千葉羅德海洋"),
    "CL": TeamInfo("Central League All-Stars", "CL", "CL", "中央聯盟明星隊"),
    "PL": TeamInfo("Pacific League All-Stars", "PL", "PL", "太平洋聯盟明星隊"),
}

TEAM_NAMES = sorted(TEAM_BY_SHORT, key=len, reverse=True)
TEAM_ALT = "|".join(re.escape(name) for name in TEAM_NAMES)

URL_CODE_TO_SHORT: dict[str, str] = {
    "s": "Yakult",
    "g": "Yomiuri",
    "db": "DeNA",
    "d": "Chunichi",
    "t": "Hanshin",
    "c": "Hiroshima",
    "h": "SoftBank",
    "f": "Nippon-Ham",
    "b": "ORIX",
    "e": "Rakuten",
    "l": "Seibu",
    "m": "Lotte",
}
SHORT_TO_URL_CODE: dict[str, str] = {value: key for key, value in URL_CODE_TO_SHORT.items()}
JAPANESE_TEAM_TO_SHORT: dict[str, str] = {
    "東京ヤクルトスワローズ": "Yakult",
    "ヤクルト": "Yakult",
    "読売ジャイアンツ": "Yomiuri",
    "巨人": "Yomiuri",
    "横浜DeNAベイスターズ": "DeNA",
    "横浜ＤｅＮＡベイスターズ": "DeNA",
    "DeNA": "DeNA",
    "中日ドラゴンズ": "Chunichi",
    "中日": "Chunichi",
    "阪神タイガース": "Hanshin",
    "阪神": "Hanshin",
    "広島東洋カープ": "Hiroshima",
    "広島": "Hiroshima",
    "福岡ソフトバンクホークス": "SoftBank",
    "ソフトバンク": "SoftBank",
    "北海道日本ハムファイターズ": "Nippon-Ham",
    "日本ハム": "Nippon-Ham",
    "オリックス・バファローズ": "ORIX",
    "オリックス": "ORIX",
    "東北楽天ゴールデンイーグルス": "Rakuten",
    "楽天": "Rakuten",
    "埼玉西武ライオンズ": "Seibu",
    "西武": "Seibu",
    "千葉ロッテマリーンズ": "Lotte",
    "ロッテ": "Lotte",
}
CENTRAL_TEAMS = {"Hanshin", "Yomiuri", "Yakult", "DeNA", "Hiroshima", "Chunichi"}
PACIFIC_TEAMS = {"SoftBank", "Seibu", "Nippon-Ham", "ORIX", "Lotte", "Rakuten"}
STANDINGS_RE = re.compile(
    rf"(?P<team>{TEAM_ALT})\s+(?P=team)\s+(?P<games>\d{{1,3}})\s+"
    rf"(?P<wins>\d{{1,3}})\s+(?P<losses>\d{{1,3}})\s+(?P<ties>\d{{1,3}})\s+"
    rf"(?P<pct>\.\d{{3}})\s+(?P<gb>-|\d+(?:\.\d+)?)",
    re.IGNORECASE,
)
STARTER_HEADING_RE = re.compile(r"(?P<month>\d{1,2})月(?P<day>\d{1,2})日の予告先発投手")
STARTER_VENUE_TIME_RE = re.compile(r"^[（(].+[）)]\s*\d{1,2}:\d{2}$")
JAPANESE_SCORE_HREF_RE = re.compile(
    r"/scores/(?P<year>\d{4})/(?P<mmdd>\d{4})/(?P<home>[a-z]+)-(?P<away>[a-z]+)-(?P<series>\d+)(?:/|$)",
    re.IGNORECASE,
)
JAPANESE_SCORE_RE = re.compile(r"(?P<home_score>\d+)\s*[-－]\s*(?P<away_score>\d+)")
JAPANESE_VENUE_RE = re.compile(r"[（(](?P<venue>[^）)]+)[）)]")
JAPANESE_INNING_RE = re.compile(r"(?P<inning>\d+)\s*回\s*(?P<half>表|裏)")
TIME_RE = re.compile(r"^(?:[01]?\d|2[0-3]):[0-5]\d$")
SCORE_RE = re.compile(
    rf"^(?P<home>{TEAM_ALT})\s+(?P<home_score>\d+)\s+Game\s+\d+\s+(?P<venue>.+?)\s+(?P<away_score>\d+)\s+(?P<away>{TEAM_ALT})$",
    re.IGNORECASE,
)
POSTPONED_RE = re.compile(
    rf"^(?P<home>{TEAM_ALT})\s+(?P<reason>Rained Out|Cancelled|Canceled|Postponed)\s+(?P<away>{TEAM_ALT})$",
    re.IGNORECASE,
)


class _NPBHtmlParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.tokens: list[str] = []
        self.links: list[tuple[str, str]] = []
        self._href: str | None = None
        self._anchor_parts: list[str] = []

    @staticmethod
    def _clean(value: str) -> str:
        return re.sub(r"\s+", " ", html.unescape(value or "")).strip()

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag.lower() == "a":
            self._href = dict(attrs).get("href") or ""
            self._anchor_parts = []

    def handle_data(self, data: str) -> None:
        cleaned = self._clean(data)
        if not cleaned:
            return
        self.tokens.append(cleaned)
        if self._href is not None:
            self._anchor_parts.append(cleaned)

    def handle_endtag(self, tag: str) -> None:
        if tag.lower() == "a" and self._href is not None:
            text = self._clean(" ".join(self._anchor_parts))
            if text:
                self.links.append((self._href, text))
            self._href = None
            self._anchor_parts = []


class _NPBStarterHtmlParser(_NPBHtmlParser):
    """HTML parser that also captures team names stored in image alt attributes."""

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        super().handle_starttag(tag, attrs)
        if tag.lower() != "img":
            return
        alt = self._clean(dict(attrs).get("alt") or "")
        if alt:
            self.tokens.append(alt)


class _NPBTableParser(HTMLParser):
    """Collect HTML table rows while retaining links embedded in each cell."""

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.rows: list[list[dict[str, Any]]] = []
        self._row: list[dict[str, Any]] | None = None
        self._cell: dict[str, Any] | None = None
        self._link: str | None = None

    @staticmethod
    def _clean(value: str) -> str:
        return re.sub(r"\s+", " ", html.unescape(value or "")).strip()

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        tag = tag.lower()
        if tag == "tr":
            self._row = []
        elif tag in {"th", "td"} and self._row is not None:
            self._cell = {"parts": [], "links": []}
        elif tag == "a" and self._cell is not None:
            self._link = dict(attrs).get("href") or ""

    def handle_data(self, data: str) -> None:
        if self._cell is None:
            return
        cleaned = self._clean(data)
        if not cleaned:
            return
        self._cell["parts"].append(cleaned)
        if self._link is not None:
            self._cell["links"].append({"href": self._link, "text": cleaned})

    def handle_endtag(self, tag: str) -> None:
        tag = tag.lower()
        if tag == "a":
            self._link = None
        elif tag in {"th", "td"} and self._row is not None and self._cell is not None:
            text = self._clean(" ".join(self._cell["parts"]))
            self._row.append({"text": text, "links": list(self._cell["links"])})
            self._cell = None
        elif tag == "tr" and self._row is not None:
            if any(cell.get("text") for cell in self._row):
                self.rows.append(self._row)
            self._row = None


def parse_npb_probable_starters(
    page_html: str,
    target_date: date,
    source_url: str,
) -> dict[str, Any]:
    parser = _NPBStarterHtmlParser()
    parser.feed(page_html)
    tokens = parser.tokens
    year = target_date.year
    for token in tokens[:30]:
        if re.fullmatch(r"20\d{2}", token):
            year = int(token)
            break
    heading_index = -1
    announced_date: date | None = None
    for index, token in enumerate(tokens):
        match = STARTER_HEADING_RE.search(token)
        if not match:
            continue
        try:
            announced_date = date(year, int(match.group("month")), int(match.group("day")))
        except ValueError:
            announced_date = None
        heading_index = index
        break
    if heading_index < 0 or announced_date != target_date:
        return {"date": announced_date.isoformat() if announced_date else None, "by_team": {}, "source_url": source_url}

    by_team: dict[str, dict[str, Any]] = {}
    ignored = {
        "セントラル・リーグ", "パシフィック・リーグ", "侍ジャパン",
        "日本野球機構", "公示", "サブメニュー", "予告先発投手",
    }
    i = heading_index + 1
    while i < len(tokens):
        token = tokens[i]
        if token.startswith("Copyright"):
            break
        short = JAPANESE_TEAM_TO_SHORT.get(token)
        if not short:
            i += 1
            continue
        pitcher = ""
        j = i + 1
        while j < len(tokens):
            candidate = tokens[j].strip()
            if JAPANESE_TEAM_TO_SHORT.get(candidate):
                break
            if candidate.startswith("Copyright"):
                break
            if candidate in ignored or STARTER_HEADING_RE.search(candidate) or STARTER_VENUE_TIME_RE.match(candidate):
                j += 1
                continue
            if re.fullmatch(r"\d{1,2}:\d{2}", candidate) or candidate.startswith("Image:"):
                j += 1
                continue
            if len(candidate) <= 80:
                pitcher = candidate
                break
            j += 1
        if pitcher and short not in by_team:
            player_id = None
            for href, link_text in parser.links:
                if link_text.strip() != pitcher.strip():
                    continue
                id_match = re.search(r"/(?:eng/)?players/(?P<id>\d+)\.html", href or "")
                if id_match:
                    player_id = id_match.group("id")
                    break
            by_team[short] = {
                "name": pitcher,
                "player_id": player_id,
                "announced": True,
                "source": "NPB official probable starters",
                "source_url": source_url,
            }
        i += 1
    return {"date": announced_date.isoformat(), "by_team": by_team, "source_url": source_url}


def parse_npb_standings(page_html: str, source_url: str) -> dict[str, Any]:
    parser = _NPBHtmlParser()
    parser.feed(page_html)
    flattened = " ".join(parser.tokens)
    leagues: dict[str, list[dict[str, Any]]] = {"Central League": [], "Pacific League": []}
    by_team: dict[str, dict[str, Any]] = {}
    for match in STANDINGS_RE.finditer(flattened):
        raw_team = match.group("team")
        short = next((name for name in TEAM_NAMES if name.lower() == raw_team.lower()), None)
        if not short or short in by_team:
            continue
        league = "Central League" if short in CENTRAL_TEAMS else "Pacific League"
        row = {
            "team": short,
            "team_name": TEAM_BY_SHORT[short].canonical,
            "team_name_zh": TEAM_BY_SHORT[short].zh,
            "abbr": TEAM_BY_SHORT[short].abbr,
            "league": league,
            "games": int(match.group("games")),
            "wins": int(match.group("wins")),
            "losses": int(match.group("losses")),
            "ties": int(match.group("ties")),
            "pct": float(match.group("pct")),
            "pct_display": match.group("pct"),
            "games_back": match.group("gb"),
            "source_url": source_url,
        }
        leagues[league].append(row)
        by_team[short] = row
    for league_rows in leagues.values():
        for rank, row in enumerate(league_rows, start=1):
            row["rank"] = rank
    return {"leagues": leagues, "by_team": by_team, "source_url": source_url}



def _safe_float(value: Any) -> float | None:
    if value is None:
        return None
    text = str(value).strip().replace(",", "")
    if not text or text in {"-", "—", "---", "***"}:
        return None
    try:
        return float(text)
    except ValueError:
        return None


def _safe_int(value: Any) -> int | None:
    number = _safe_float(value)
    return int(number) if number is not None else None


def _innings_to_outs(value: Any) -> int | None:
    number = _safe_float(value)
    if number is None:
        return None
    whole = int(number)
    decimal = round((number - whole) * 10)
    if decimal not in {0, 1, 2}:
        return None
    return whole * 3 + decimal


def _outs_to_innings(outs: int) -> float:
    return round(outs / 3.0, 3)


def _player_id_from_cell(cell: dict[str, Any]) -> str | None:
    for link in cell.get("links") or []:
        match = re.search(r"/(?:eng/)?players/(?P<id>\d+)\.html", link.get("href") or "")
        if match:
            return match.group("id")
    return None


def _table_rows(page_html: str) -> list[list[dict[str, Any]]]:
    parser = _NPBTableParser()
    parser.feed(page_html)
    return parser.rows


def _find_header(rows: list[list[dict[str, Any]]], required: set[str]) -> tuple[int, list[str]] | None:
    for index, row in enumerate(rows):
        headers = [re.sub(r"\s+", " ", str(cell.get("text") or "")).strip() for cell in row]
        normalized = {header.upper() for header in headers}
        if required.issubset(normalized):
            return index, headers
    return None


def parse_npb_pitching_stats(page_html: str, source_url: str) -> dict[str, Any]:
    """Parse the official player-pitching table for one NPB club.

    The official English table columns are stable and include Pitcher, G, W, L,
    SV, CG, SHO, BF, IP, H, HR, BB, HB, SO, R, ER and ERA. WHIP and K/BB are
    calculated locally so the model can compare announced starters and relievers.
    """

    rows = _table_rows(page_html)
    header_info = _find_header(rows, {"PITCHER", "G", "IP", "ERA"})
    players: list[dict[str, Any]] = []
    if not header_info:
        return {"players": [], "by_id": {}, "by_name": {}, "source_url": source_url}
    header_index, headers = header_info
    header_keys = [header.upper().replace(" ", "") for header in headers]
    for row in rows[header_index + 1 :]:
        if len(row) < min(8, len(headers)):
            continue
        values = [str(cell.get("text") or "").strip() for cell in row]
        name = values[0] if values else ""
        if not name or name.upper() in {"PITCHER", "TOTAL"}:
            continue
        data: dict[str, Any] = {}
        for idx, key in enumerate(header_keys):
            if idx < len(values):
                data[key] = values[idx]
        games = _safe_int(data.get("G")) or 0
        outs = _innings_to_outs(data.get("IP"))
        hits = _safe_int(data.get("H")) or 0
        walks = _safe_int(data.get("BB")) or 0
        strikeouts = _safe_int(data.get("SO")) or 0
        earned_runs = _safe_int(data.get("ER")) or 0
        innings = _outs_to_innings(outs) if outs is not None else None
        whip = ((hits + walks) * 3 / outs) if outs and outs > 0 else None
        k_bb = strikeouts / walks if walks > 0 else (float(strikeouts) if strikeouts > 0 else None)
        era = _safe_float(data.get("ERA"))
        if era is None and outs and outs > 0:
            era = earned_runs * 27 / outs
        player = {
            "player_id": _player_id_from_cell(row[0]),
            "name": name,
            "games": games,
            "wins": _safe_int(data.get("W")) or 0,
            "losses": _safe_int(data.get("L")) or 0,
            "saves": _safe_int(data.get("SV")) or 0,
            "complete_games": _safe_int(data.get("CG")) or 0,
            "shutouts": _safe_int(data.get("SHO")) or 0,
            "batters_faced": _safe_int(data.get("BF")) or 0,
            "outs": outs,
            "innings": innings,
            "hits": hits,
            "home_runs": _safe_int(data.get("HR")) or 0,
            "walks": walks,
            "hit_batters": _safe_int(data.get("HB")) or 0,
            "strikeouts": strikeouts,
            "runs": _safe_int(data.get("R")) or 0,
            "earned_runs": earned_runs,
            "era": round(era, 2) if era is not None else None,
            "whip": round(whip, 3) if whip is not None else None,
            "k_bb": round(k_bb, 2) if k_bb is not None else None,
            "source_url": source_url,
        }
        if games or outs:
            players.append(player)
    by_id = {item["player_id"]: item for item in players if item.get("player_id")}
    by_name = {re.sub(r"\s+", " ", item["name"]).strip().lower(): item for item in players}
    return {"players": players, "by_id": by_id, "by_name": by_name, "source_url": source_url}



def parse_npb_player_pitching_profile(page_html: str, season: int, source_url: str) -> dict[str, Any] | None:
    """Parse one player's official Japanese career table for the requested season."""

    rows = _table_rows(page_html)
    required = {"年度", "登板", "投球回", "防御率"}
    header_info: tuple[int, list[str]] | None = None
    for index, row in enumerate(rows):
        headers = [str(cell.get("text") or "").strip() for cell in row]
        if required.issubset(set(headers)):
            header_info = index, headers
            break
    if not header_info:
        return None
    header_index, headers = header_info
    for row in rows[header_index + 1 :]:
        values = [str(cell.get("text") or "").strip() for cell in row]
        if not values or values[0] != str(season):
            continue
        data = {headers[idx]: values[idx] for idx in range(min(len(headers), len(values)))}
        outs = _innings_to_outs(data.get("投球回"))
        hits = _safe_int(data.get("安打")) or 0
        walks = _safe_int(data.get("四球")) or 0
        strikeouts = _safe_int(data.get("三振")) or 0
        earned_runs = _safe_int(data.get("自責点")) or 0
        era = _safe_float(data.get("防御率"))
        if era is None and outs:
            era = earned_runs * 27 / outs
        whip = (hits + walks) * 3 / outs if outs else None
        k_bb = strikeouts / walks if walks else (float(strikeouts) if strikeouts else None)
        return {
            "player_id": None,
            "name": "",
            "games": _safe_int(data.get("登板")) or 0,
            "wins": _safe_int(data.get("勝利")) or 0,
            "losses": _safe_int(data.get("敗北")) or 0,
            "saves": _safe_int(data.get("セーブ")) or 0,
            "complete_games": _safe_int(data.get("完投")) or 0,
            "shutouts": _safe_int(data.get("完封勝")) or 0,
            "batters_faced": _safe_int(data.get("打者")) or 0,
            "outs": outs,
            "innings": _outs_to_innings(outs) if outs is not None else None,
            "hits": hits,
            "home_runs": _safe_int(data.get("本塁打")) or 0,
            "walks": walks,
            "hit_batters": _safe_int(data.get("死球")) or 0,
            "strikeouts": strikeouts,
            "runs": _safe_int(data.get("失点")) or 0,
            "earned_runs": earned_runs,
            "era": round(era, 2) if era is not None else None,
            "whip": round(whip, 3) if whip is not None else None,
            "k_bb": round(k_bb, 2) if k_bb is not None else None,
            "source_url": source_url,
        }
    return None


def parse_npb_batting_stats(page_html: str, source_url: str) -> dict[str, Any]:
    """Aggregate official player batting rows into a club offensive profile."""

    rows = _table_rows(page_html)
    header_info = _find_header(rows, {"BATTER", "AB", "H", "SLG", "OBP"})
    totals = {
        "games": 0,
        "plate_appearances": 0,
        "at_bats": 0,
        "runs": 0,
        "hits": 0,
        "doubles": 0,
        "triples": 0,
        "home_runs": 0,
        "total_bases": 0,
        "rbi": 0,
        "walks": 0,
        "intentional_walks": 0,
        "hit_by_pitch": 0,
        "sac_flies": 0,
        "strikeouts": 0,
    }
    if not header_info:
        return {**totals, "avg": None, "obp": None, "slg": None, "ops": None, "source_url": source_url}
    header_index, headers = header_info
    header_keys = [header.upper().replace(" ", "") for header in headers]
    for row in rows[header_index + 1 :]:
        values = [str(cell.get("text") or "").strip() for cell in row]
        if not values or values[0].upper() in {"BATTER", "TOTAL"}:
            continue
        data = {key: values[idx] for idx, key in enumerate(header_keys) if idx < len(values)}
        at_bats = _safe_int(data.get("AB")) or 0
        plate_appearances = _safe_int(data.get("PA")) or 0
        if at_bats == 0 and plate_appearances == 0:
            continue
        totals["games"] = max(totals["games"], _safe_int(data.get("G")) or 0)
        totals["plate_appearances"] += plate_appearances
        totals["at_bats"] += at_bats
        totals["runs"] += _safe_int(data.get("R")) or 0
        totals["hits"] += _safe_int(data.get("H")) or 0
        totals["doubles"] += _safe_int(data.get("2B")) or 0
        totals["triples"] += _safe_int(data.get("3B")) or 0
        totals["home_runs"] += _safe_int(data.get("HR")) or 0
        totals["total_bases"] += _safe_int(data.get("TB")) or 0
        totals["rbi"] += _safe_int(data.get("RBI")) or 0
        totals["walks"] += _safe_int(data.get("BB")) or 0
        totals["intentional_walks"] += _safe_int(data.get("IBB")) or 0
        totals["hit_by_pitch"] += _safe_int(data.get("HP")) or _safe_int(data.get("HBP")) or 0
        totals["sac_flies"] += _safe_int(data.get("SF")) or 0
        totals["strikeouts"] += _safe_int(data.get("SO")) or 0
    ab = totals["at_bats"]
    hits = totals["hits"]
    tb = totals["total_bases"]
    walks = totals["walks"]
    hbp = totals["hit_by_pitch"]
    sf = totals["sac_flies"]
    avg = hits / ab if ab else None
    slg = tb / ab if ab else None
    obp_denom = ab + walks + hbp + sf
    obp = (hits + walks + hbp) / obp_denom if obp_denom else None
    ops = obp + slg if obp is not None and slg is not None else None
    return {
        **totals,
        "avg": round(avg, 3) if avg is not None else None,
        "obp": round(obp, 3) if obp is not None else None,
        "slg": round(slg, 3) if slg is not None else None,
        "ops": round(ops, 3) if ops is not None else None,
        "source_url": source_url,
    }


def aggregate_npb_bullpen(pitching: dict[str, Any]) -> dict[str, Any]:
    """Build a conservative bullpen proxy from official pitcher season totals."""

    candidates: list[dict[str, Any]] = []
    for player in pitching.get("players") or []:
        games = int(player.get("games") or 0)
        outs = int(player.get("outs") or 0)
        innings_per_game = (outs / 3) / games if games else 99.0
        if games >= 5 and int(player.get("complete_games") or 0) == 0 and innings_per_game <= 2.2:
            candidates.append(player)
    if not candidates:
        return {"available": False, "pitchers": 0, "era": None, "whip": None, "k_bb": None}
    outs = sum(int(item.get("outs") or 0) for item in candidates)
    hits = sum(int(item.get("hits") or 0) for item in candidates)
    walks = sum(int(item.get("walks") or 0) for item in candidates)
    strikeouts = sum(int(item.get("strikeouts") or 0) for item in candidates)
    earned_runs = sum(int(item.get("earned_runs") or 0) for item in candidates)
    era = earned_runs * 27 / outs if outs else None
    whip = (hits + walks) * 3 / outs if outs else None
    k_bb = strikeouts / walks if walks else (float(strikeouts) if strikeouts else None)
    return {
        "available": bool(outs),
        "pitchers": len(candidates),
        "innings": _outs_to_innings(outs),
        "era": round(era, 2) if era is not None else None,
        "whip": round(whip, 3) if whip is not None else None,
        "k_bb": round(k_bb, 2) if k_bb is not None else None,
        "saves": sum(int(item.get("saves") or 0) for item in candidates),
    }


def parse_npb_month_scoreboard(page_html: str, season: int, source_url: str) -> list[dict[str, Any]]:
    """Parse every final/postponed game listed on an official monthly schedule page."""

    parser = _NPBHtmlParser()
    parser.feed(page_html)
    games: list[dict[str, Any]] = []
    seen: set[str] = set()
    for href, label in parser.links:
        match = JAPANESE_SCORE_HREF_RE.search(href or "")
        if not match or int(match.group("year")) != season:
            continue
        try:
            game_date = date(season, int(match.group("mmdd")[:2]), int(match.group("mmdd")[2:]))
        except ValueError:
            continue
        home = URL_CODE_TO_SHORT.get(match.group("home").lower())
        away = URL_CODE_TO_SHORT.get(match.group("away").lower())
        if not home or not away:
            continue
        game_id = _stable_game_id(game_date, away, home)
        if game_id in seen:
            continue
        cleaned = re.sub(r"\s+", " ", label or "").strip()
        score_match = JAPANESE_SCORE_RE.search(cleaned)
        status = "final" if "試合終了" in cleaned else "postponed" if any(word in cleaned for word in ("中止", "雨天中止", "延期")) else ""
        if not status:
            continue
        games.append(
            {
                "game_pk": game_id,
                "date": game_date.isoformat(),
                "away": away,
                "home": home,
                "away_score": int(score_match.group("away_score")) if score_match else None,
                "home_score": int(score_match.group("home_score")) if score_match else None,
                "status": status,
                "source_url": urljoin(source_url, href),
            }
        )
        seen.add(game_id)
    return games


def npb_team_form(team: str, games: list[dict[str, Any]]) -> dict[str, Any]:
    finals = [game for game in games if game.get("status") == "final" and team in {game.get("away"), game.get("home")}]
    finals.sort(key=lambda item: (item.get("date") or "", item.get("game_pk") or ""))
    wins = losses = ties = runs_for = runs_against = 0
    home_w = home_l = home_t = road_w = road_l = road_t = 0
    results: list[dict[str, Any]] = []
    for game in finals:
        is_home = game.get("home") == team
        team_score = game.get("home_score") if is_home else game.get("away_score")
        opponent_score = game.get("away_score") if is_home else game.get("home_score")
        if team_score is None or opponent_score is None:
            continue
        runs_for += int(team_score)
        runs_against += int(opponent_score)
        if team_score > opponent_score:
            result = "W"
            wins += 1
            if is_home:
                home_w += 1
            else:
                road_w += 1
        elif team_score < opponent_score:
            result = "L"
            losses += 1
            if is_home:
                home_l += 1
            else:
                road_l += 1
        else:
            result = "T"
            ties += 1
            if is_home:
                home_t += 1
            else:
                road_t += 1
        results.append({"date": game.get("date"), "result": result, "runs_for": team_score, "runs_against": opponent_score, "home": is_home})
    recent = results[-10:]
    recent_w = sum(item["result"] == "W" for item in recent)
    recent_l = sum(item["result"] == "L" for item in recent)
    recent_t = sum(item["result"] == "T" for item in recent)
    decisions = wins + losses
    recent_decisions = recent_w + recent_l
    games_count = len(results)
    exponent = 1.83
    rf_power = math.pow(max(runs_for, 0), exponent)
    ra_power = math.pow(max(runs_against, 0), exponent)
    pyth = rf_power / (rf_power + ra_power) if rf_power + ra_power else None
    return {
        "games": games_count,
        "wins": wins,
        "losses": losses,
        "ties": ties,
        "winning_pct": round(wins / decisions, 3) if decisions else None,
        "runs_for": runs_for,
        "runs_against": runs_against,
        "run_diff": runs_for - runs_against,
        "runs_per_game": round(runs_for / games_count, 2) if games_count else None,
        "runs_allowed_per_game": round(runs_against / games_count, 2) if games_count else None,
        "pythagorean_pct": round(pyth, 3) if pyth is not None else None,
        "home": {"wins": home_w, "losses": home_l, "ties": home_t, "pct": round(home_w / (home_w + home_l), 3) if home_w + home_l else None},
        "road": {"wins": road_w, "losses": road_l, "ties": road_t, "pct": round(road_w / (road_w + road_l), 3) if road_w + road_l else None},
        "recent_10": {
            "wins": recent_w,
            "losses": recent_l,
            "ties": recent_t,
            "pct": round(recent_w / recent_decisions, 3) if recent_decisions else None,
            "runs_per_game": round(sum(int(item["runs_for"]) for item in recent) / len(recent), 2) if recent else None,
            "runs_allowed_per_game": round(sum(int(item["runs_against"]) for item in recent) / len(recent), 2) if recent else None,
            "results": recent,
        },
    }


def _clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def _normalized_advantage(home: Any, away: Any, scale: float, *, lower_is_better: bool = False) -> float | None:
    home_value = _safe_float(home)
    away_value = _safe_float(away)
    if home_value is None or away_value is None or scale <= 0:
        return None
    raw = (away_value - home_value) / scale if lower_is_better else (home_value - away_value) / scale
    return _clamp(raw, -1.0, 1.0)


def _weighted_advantage(metrics: list[tuple[str, Any, Any, float, bool, float]]) -> dict[str, Any]:
    weighted = 0.0
    used = 0.0
    rows: list[dict[str, Any]] = []
    total_weight = sum(item[5] for item in metrics) or 1.0
    for label, away, home, scale, lower_is_better, weight in metrics:
        edge = _normalized_advantage(home, away, scale, lower_is_better=lower_is_better)
        available = edge is not None
        if available:
            weighted += edge * weight
            used += weight
        rows.append({"label": label, "away": away, "home": home, "available": available, "edge_home": round(edge, 3) if edge is not None else None})
    return {
        "edge_home": round(weighted / used, 3) if used else None,
        "quality": round(used / total_weight, 2),
        "metrics": rows,
        "available": bool(used),
    }


def build_npb_analysis(
    game: dict[str, Any],
    away_form: dict[str, Any],
    home_form: dict[str, Any],
    away_batting: dict[str, Any],
    home_batting: dict[str, Any],
    away_pitching: dict[str, Any],
    home_pitching: dict[str, Any],
) -> dict[str, Any]:
    away_team = game.get("away") or {}
    home_team = game.get("home") or {}
    away_starter_info = away_team.get("probable_pitcher") or {}
    home_starter_info = home_team.get("probable_pitcher") or {}

    def starter_stats(info: dict[str, Any], pitching: dict[str, Any]) -> dict[str, Any] | None:
        player_id = str(info.get("player_id") or "")
        if player_id and player_id in (pitching.get("by_id") or {}):
            return (pitching.get("by_id") or {})[player_id]
        name = re.sub(r"\s+", " ", str(info.get("name") or "")).strip().lower()
        return (pitching.get("by_name") or {}).get(name)

    away_starter = starter_stats(away_starter_info, away_pitching)
    home_starter = starter_stats(home_starter_info, home_pitching)
    away_bullpen = aggregate_npb_bullpen(away_pitching)
    home_bullpen = aggregate_npb_bullpen(home_pitching)

    away_record = away_team.get("record") or {}
    home_record = home_team.get("record") or {}
    team_group = _weighted_advantage([
        ("畢氏預期勝率", away_form.get("pythagorean_pct"), home_form.get("pythagorean_pct"), 0.18, False, 0.30),
        ("官方戰績勝率", away_record.get("pct"), home_record.get("pct"), 0.18, False, 0.25),
        ("近十場勝率", (away_form.get("recent_10") or {}).get("pct"), (home_form.get("recent_10") or {}).get("pct"), 0.35, False, 0.25),
        ("本場主客場勝率", (away_form.get("road") or {}).get("pct"), (home_form.get("home") or {}).get("pct"), 0.30, False, 0.20),
    ])
    team_group.update({"label": "球隊實力", "note": "官方戰績、得失分、畢氏預期勝率、近十場與主客場"})

    starter_group = _weighted_advantage([
        ("ERA", (away_starter or {}).get("era"), (home_starter or {}).get("era"), 3.0, True, 0.45),
        ("WHIP", (away_starter or {}).get("whip"), (home_starter or {}).get("whip"), 0.65, True, 0.30),
        ("K/BB", (away_starter or {}).get("k_bb"), (home_starter or {}).get("k_bb"), 3.5, False, 0.25),
    ])
    starter_group.update({
        "label": "先發投手",
        "note": "NPB 官方球季 ERA、WHIP 與 K/BB；未找到同一球員代碼時不納入模型",
        "away_pitcher": {**away_starter_info, "stats": away_starter},
        "home_pitcher": {**home_starter_info, "stats": home_starter},
        "both_starters_ready": bool(away_starter and home_starter),
    })

    offense_group = _weighted_advantage([
        ("球季 OPS", away_batting.get("ops"), home_batting.get("ops"), 0.18, False, 0.40),
        ("球季場均得分", away_form.get("runs_per_game"), home_form.get("runs_per_game"), 2.2, False, 0.30),
        ("近十場場均得分", (away_form.get("recent_10") or {}).get("runs_per_game"), (home_form.get("recent_10") or {}).get("runs_per_game"), 2.5, False, 0.30),
    ])
    offense_group.update({"label": "打線火力", "note": "官方球員打擊累計整合為球隊 OPS，並結合球季及近十場得分"})

    bullpen_group = _weighted_advantage([
        ("牛棚 ERA", away_bullpen.get("era"), home_bullpen.get("era"), 3.2, True, 0.45),
        ("牛棚 WHIP", away_bullpen.get("whip"), home_bullpen.get("whip"), 0.70, True, 0.30),
        ("牛棚 K/BB", away_bullpen.get("k_bb"), home_bullpen.get("k_bb"), 3.2, False, 0.25),
    ])
    bullpen_group.update({"label": "牛棚狀態", "note": "以官方投手球季資料估算後援群；目前尚未納入最近三日用量", "away": away_bullpen, "home": home_bullpen})

    groups = {
        "team": team_group,
        "starter": starter_group,
        "offense": offense_group,
        "bullpen": bullpen_group,
    }
    weights = {"team": 0.28, "starter": 0.32, "offense": 0.24, "bullpen": 0.16}
    weighted_edge = 0.0
    used_weight = 0.0
    quality_weight = 0.0
    for key, weight in weights.items():
        group = groups[key]
        edge = group.get("edge_home")
        quality = float(group.get("quality") or 0)
        quality_weight += quality * weight
        if edge is not None:
            weighted_edge += float(edge) * weight
            used_weight += weight
    normalized_edge = weighted_edge / used_weight if used_weight else 0.0
    home_probability = _clamp(50.0 + normalized_edge * 18.0 + 1.8, 35.0, 65.0)
    away_probability = 100.0 - home_probability
    home_pick = home_probability >= 50.0
    confidence = max(home_probability, away_probability)
    data_quality = _clamp(quality_weight, 0.0, 1.0)

    away_rpg = _safe_float(away_form.get("runs_per_game")) or 3.6
    home_rpg = _safe_float(home_form.get("runs_per_game")) or 3.6
    away_ra = _safe_float(away_form.get("runs_allowed_per_game")) or 3.6
    home_ra = _safe_float(home_form.get("runs_allowed_per_game")) or 3.6
    projected_total = _clamp((away_rpg + home_ra + home_rpg + away_ra) / 2.0, 4.5, 11.5)
    home_share = home_probability / 100.0
    projected_home_runs = projected_total * home_share
    projected_away_runs = projected_total - projected_home_runs
    projected_margin = projected_home_runs - projected_away_runs
    projection_quality = _clamp(
        data_quality * (1.0 if starter_group.get("both_starters_ready") else 0.82),
        0.0,
        1.0,
    )
    home_score = max(1, round(projected_home_runs))
    away_score = max(1, round(projected_away_runs))
    if home_score == away_score:
        if home_pick:
            home_score += 1
        else:
            away_score += 1

    return {
        "league": "NPB",
        "model_version": "dm-npb-markets-v1.1",
        "status": "prediction_markets",
        "official_recommendation_enabled": True,
        "message": "NPB 官方數據模型已支援獨贏、讓分與大小分；正式發布仍需真實盤口、資料完整度與雙方先發均通過門檻。",
        "pick": {
            "side": "home" if home_pick else "away",
            "team": home_team.get("name") if home_pick else away_team.get("name"),
            "team_name_zh": home_team.get("name_zh") if home_pick else away_team.get("name_zh"),
            "label": f"{home_team.get('abbr') if home_pick else away_team.get('abbr')} 獨贏觀察",
        },
        "home_probability": round(home_probability, 1),
        "away_probability": round(away_probability, 1),
        "confidence": round(confidence, 1),
        "data_quality": round(data_quality, 2),
        "projections": {
            "away_runs": round(projected_away_runs, 2),
            "home_runs": round(projected_home_runs, 2),
            "total_runs": round(projected_total, 2),
            "home_margin": round(projected_margin, 2),
            "quality": round(projection_quality, 2),
            "score": {"away": away_score, "home": home_score},
        },
        "analysis_groups": groups,
        "team_profiles": {
            "away": {"form": away_form, "batting": away_batting, "bullpen": away_bullpen},
            "home": {"form": home_form, "batting": home_batting, "bullpen": home_bullpen},
        },
    }


def _apply_probable_starters(items: list[dict[str, Any]], starter_data: dict[str, Any]) -> None:
    by_team = starter_data.get("by_team") or {}
    for game in items:
        for side in ("away", "home"):
            team = game.get(side) or {}
            short = team.get("short_name")
            starter = by_team.get(short)
            if starter:
                team["probable_pitcher"] = {"id": None, **starter}


def _apply_standings(items: list[dict[str, Any]], standings_data: dict[str, Any]) -> None:
    by_team = standings_data.get("by_team") or {}
    for game in items:
        for side in ("away", "home"):
            team = game.get(side) or {}
            short = team.get("short_name")
            record = by_team.get(short)
            if record:
                team["record"] = {key: value for key, value in record.items() if key != "source_url"}


def _iso_timestamp(epoch: float) -> str:
    return datetime.fromtimestamp(epoch, tz=TAIPEI).isoformat()


def _team_payload(short_name: str, score: int | None = None) -> dict[str, Any]:
    team = TEAM_BY_SHORT[short_name]
    return {
        "id": team.abbr,
        "name": team.canonical,
        "short_name": team.short,
        "name_zh": team.zh,
        "abbr": team.abbr,
        "score": score,
        "probable_pitcher": {"id": None, "name": "尚未公布"},
    }


def _stable_game_id(target_date: date, away: str, home: str) -> str:
    return f"npb_{target_date:%Y%m%d}_{TEAM_BY_SHORT[away].abbr}_{TEAM_BY_SHORT[home].abbr}"


def _start_datetime(target_date: date, japan_time: str | None) -> datetime | None:
    if not japan_time or not TIME_RE.match(japan_time):
        return None
    hour, minute = map(int, japan_time.split(":"))
    return datetime.combine(target_date, time(hour, minute), tzinfo=TOKYO)


def _status_from_schedule(start: datetime | None, now: datetime) -> tuple[str, str]:
    if start is None:
        return "upcoming", "Scheduled"
    now_tokyo = now.astimezone(TOKYO)
    if now_tokyo < start:
        return "upcoming", "Scheduled"
    if now_tokyo <= start + timedelta(hours=5):
        return "live", "In Progress"
    return "upcoming", "Awaiting official result"


def _game_payload(
    target_date: date,
    away: str,
    home: str,
    *,
    venue: str = "",
    japan_time: str | None = None,
    away_score: int | None = None,
    home_score: int | None = None,
    status: str = "upcoming",
    detailed_status: str = "Scheduled",
    source_url: str,
    detail_url: str | None = None,
) -> dict[str, Any]:
    start = _start_datetime(target_date, japan_time)
    taipei_start = start.astimezone(TAIPEI) if start else None
    return {
        "league": "NPB",
        "season": target_date.year,
        "game_pk": _stable_game_id(target_date, away, home),
        "external_game_id": _stable_game_id(target_date, away, home),
        "game_date": start.isoformat() if start else f"{target_date.isoformat()}T12:00:00+09:00",
        "date_taiwan": taipei_start.date().isoformat() if taipei_start else target_date.isoformat(),
        "time_taiwan": taipei_start.strftime("%H:%M") if taipei_start else "",
        "time_japan": japan_time or "",
        "status": status,
        "detailed_status": detailed_status,
        "inning": None,
        "inning_state": "",
        "venue_id": None,
        "venue": venue,
        "game_type": "regular_season",
        "season_context": "regular_season",
        "event_label": "NPB 例行賽",
        "is_special_event": False,
        "analysis_available": True,
        "analysis_status": "full_markets",
        "away": _team_payload(away, away_score),
        "home": _team_payload(home, home_score),
        "source_url": detail_url or source_url,
        "official_schedule_url": source_url,
    }


def _parse_score_links(parser: _NPBHtmlParser, target_date: date, source_url: str) -> list[dict[str, Any]]:
    games: list[dict[str, Any]] = []
    seen: set[str] = set()
    for href, label in parser.links:
        cleaned = re.sub(r"\s+", " ", label).strip()
        match = SCORE_RE.match(cleaned)
        if match:
            away = next(name for name in TEAM_NAMES if name.lower() == match.group("away").lower())
            home = next(name for name in TEAM_NAMES if name.lower() == match.group("home").lower())
            game_id = _stable_game_id(target_date, away, home)
            if game_id in seen:
                continue
            seen.add(game_id)
            games.append(
                _game_payload(
                    target_date,
                    away,
                    home,
                    venue=match.group("venue").strip(),
                    away_score=int(match.group("away_score")),
                    home_score=int(match.group("home_score")),
                    status="final",
                    detailed_status="Final",
                    source_url=source_url,
                    detail_url=urljoin(source_url, href),
                )
            )
            continue
        postponed = POSTPONED_RE.match(cleaned)
        if postponed:
            away = next(name for name in TEAM_NAMES if name.lower() == postponed.group("away").lower())
            home = next(name for name in TEAM_NAMES if name.lower() == postponed.group("home").lower())
            game_id = _stable_game_id(target_date, away, home)
            if game_id in seen:
                continue
            seen.add(game_id)
            games.append(
                _game_payload(
                    target_date,
                    away,
                    home,
                    status="postponed",
                    detailed_status=postponed.group("reason"),
                    source_url=source_url,
                    detail_url=urljoin(source_url, href),
                )
            )
    return games


def parse_npb_japanese_scoreboard(
    page_html: str,
    target_date: date,
    source_url: str,
) -> list[dict[str, Any]]:
    parser = _NPBHtmlParser()
    parser.feed(page_html)
    games: list[dict[str, Any]] = []
    seen: set[str] = set()
    for href, label in parser.links:
        href_match = JAPANESE_SCORE_HREF_RE.search(href or "")
        if not href_match:
            continue
        try:
            link_date = date(
                int(href_match.group("year")),
                int(href_match.group("mmdd")[:2]),
                int(href_match.group("mmdd")[2:]),
            )
        except ValueError:
            continue
        if link_date != target_date:
            continue
        home = URL_CODE_TO_SHORT.get(href_match.group("home").lower())
        away = URL_CODE_TO_SHORT.get(href_match.group("away").lower())
        if not home or not away:
            continue
        game_id = _stable_game_id(target_date, away, home)
        if game_id in seen:
            continue
        cleaned = re.sub(r"\s+", " ", label or "").strip()
        score_match = JAPANESE_SCORE_RE.search(cleaned)
        venue_match = JAPANESE_VENUE_RE.search(cleaned)
        inning_match = JAPANESE_INNING_RE.search(cleaned)
        status = "upcoming"
        detailed_status = cleaned or "Scheduled"
        inning: int | None = None
        inning_state = ""
        if "試合終了" in cleaned:
            status = "final"
            detailed_status = "Final"
        elif any(word in cleaned for word in ("中止", "雨天中止", "延期")):
            status = "postponed"
            detailed_status = "Postponed"
        elif score_match or inning_match:
            status = "live"
            detailed_status = cleaned or "In Progress"
            if inning_match:
                inning = int(inning_match.group("inning"))
                inning_state = "Top" if inning_match.group("half") == "表" else "Bottom"
        games.append(
            {
                "league": "NPB",
                "game_pk": game_id,
                "external_game_id": game_id,
                "status": status,
                "detailed_status": detailed_status,
                "inning": inning,
                "inning_state": inning_state,
                "venue": venue_match.group("venue").strip() if venue_match else "",
                "away": _team_payload(away, int(score_match.group("away_score")) if score_match else None),
                "home": _team_payload(home, int(score_match.group("home_score")) if score_match else None),
                "source_url": urljoin(source_url, href),
            }
        )
        seen.add(game_id)
    return games


def _merge_scoreboard(
    scheduled: list[dict[str, Any]],
    scoreboard: list[dict[str, Any]],
    target_date: date,
    source_url: str,
) -> list[dict[str, Any]]:
    overlays = {item["game_pk"]: item for item in scoreboard}
    merged: list[dict[str, Any]] = []
    scheduled_ids: set[str] = set()
    for game in scheduled:
        game_id = game.get("game_pk")
        scheduled_ids.add(game_id)
        overlay = overlays.get(game_id)
        if overlay:
            game["status"] = overlay.get("status") or game.get("status")
            game["detailed_status"] = overlay.get("detailed_status") or game.get("detailed_status")
            game["inning"] = overlay.get("inning")
            game["inning_state"] = overlay.get("inning_state") or ""
            if overlay.get("venue"):
                game["venue"] = overlay["venue"]
            game["away"]["score"] = overlay.get("away", {}).get("score")
            game["home"]["score"] = overlay.get("home", {}).get("score")
            game["source_url"] = overlay.get("source_url") or game.get("source_url")
        merged.append(game)
    for game_id, overlay in overlays.items():
        if game_id in scheduled_ids:
            continue
        away = overlay["away"]["short_name"]
        home = overlay["home"]["short_name"]
        merged.append(
            _game_payload(
                target_date,
                away,
                home,
                venue=overlay.get("venue", ""),
                away_score=overlay["away"].get("score"),
                home_score=overlay["home"].get("score"),
                status=overlay.get("status", "upcoming"),
                detailed_status=overlay.get("detailed_status", "Scheduled"),
                source_url=source_url,
                detail_url=overlay.get("source_url"),
            )
        )
        merged[-1]["inning"] = overlay.get("inning")
        merged[-1]["inning_state"] = overlay.get("inning_state") or ""
    return merged


def _schedule_tokens(parser: _NPBHtmlParser) -> list[str]:
    marker = next(
        (index for index, token in enumerate(parser.tokens) if "Regular Season (Schedules)" in token),
        -1,
    )
    if marker < 0:
        return []
    tokens = parser.tokens[marker + 1 :]
    for index, token in enumerate(tokens):
        if token.startswith("Copyright"):
            return tokens[:index]
    return tokens


def _parse_schedule_tokens(
    parser: _NPBHtmlParser,
    target_date: date,
    source_url: str,
    now: datetime,
) -> list[dict[str, Any]]:
    tokens = _schedule_tokens(parser)
    games: list[dict[str, Any]] = []
    seen: set[str] = set()
    headings = {
        "CENTRAL LEAGUE",
        "PACIFIC LEAGUE",
        "Prev. Games",
        "Next Games",
        "Regular Season",
        "Schedules/Scores",
    }
    i = 0
    while i < len(tokens):
        token = tokens[i]
        if token not in TEAM_BY_SHORT:
            i += 1
            continue
        home = token
        venue_parts: list[str] = []
        japan_time: str | None = None
        postponed_reason: str | None = None
        j = i + 1
        while j < len(tokens) and j <= i + 12:
            current = tokens[j]
            if current in TEAM_BY_SHORT:
                break
            if TIME_RE.match(current):
                japan_time = current
                j += 1
                break
            if current.lower() in {"rained out", "cancelled", "canceled", "postponed"}:
                postponed_reason = current
            elif current not in headings and not current.startswith("Image:") and not re.match(r"^[A-Z][a-z]+day,", current):
                venue_parts.append(current)
            j += 1
        while j < len(tokens) and tokens[j] not in TEAM_BY_SHORT:
            j += 1
        if j >= len(tokens):
            i += 1
            continue
        away = tokens[j]
        game_id = _stable_game_id(target_date, away, home)
        if game_id not in seen:
            seen.add(game_id)
            start = _start_datetime(target_date, japan_time)
            if postponed_reason:
                status, detail = "postponed", postponed_reason
            else:
                status, detail = _status_from_schedule(start, now)
            games.append(
                _game_payload(
                    target_date,
                    away,
                    home,
                    venue=" ".join(venue_parts).strip(),
                    japan_time=japan_time,
                    status=status,
                    detailed_status=detail,
                    source_url=source_url,
                )
            )
        i = j + 1
    return games


def parse_npb_daily_page(
    page_html: str,
    target_date: date,
    source_url: str,
    *,
    now: datetime | None = None,
) -> list[dict[str, Any]]:
    parser = _NPBHtmlParser()
    parser.feed(page_html)
    completed = _parse_score_links(parser, target_date, source_url)
    if completed:
        return sorted(completed, key=lambda game: game["game_pk"])
    return _parse_schedule_tokens(parser, target_date, source_url, now or datetime.now(TAIPEI))


class NPBService:
    def __init__(self, settings: Settings, transport: httpx.AsyncBaseTransport | None = None) -> None:
        self.settings = settings
        self.cache = AsyncTTLCache()
        self.client = httpx.AsyncClient(
            timeout=settings.request_timeout_seconds,
            follow_redirects=True,
            trust_env=False,
            transport=transport,
            headers={
                "User-Agent": "DiamondMind/18.6.0 (+MLB/NPB real-market recommendations; contact via configured support email)",
                "Accept": "text/html,application/xhtml+xml",
                "Accept-Language": "en-US,en;q=0.9",
            },
        )

    async def aclose(self) -> None:
        await self.client.aclose()

    def daily_url(self, target_date: date) -> str:
        return f"{self.settings.npb_official_base}/bis/eng/{target_date.year}/games/gm{target_date:%Y%m%d}.html"

    def monthly_url(self, target_date: date) -> str:
        return f"{self.settings.npb_official_base}/games/{target_date.year}/schedule_{target_date:%m}_detail.html"

    def starter_url(self) -> str:
        return f"{self.settings.npb_official_base}/announcement/starter/"

    def standings_url(self, season: int) -> str:
        return f"{self.settings.npb_official_base}/bis/eng/{season}/stats/"

    def team_batting_url(self, season: int, short_name: str) -> str:
        code = SHORT_TO_URL_CODE[short_name]
        return f"{self.settings.npb_official_base}/bis/eng/{season}/stats/idb1_{code}.html"

    def team_pitching_url(self, season: int, short_name: str) -> str:
        code = SHORT_TO_URL_CODE[short_name]
        return f"{self.settings.npb_official_base}/bis/eng/{season}/stats/idp1_{code}.html"

    def player_url(self, player_id: str) -> str:
        return f"{self.settings.npb_official_base}/bis/players/{player_id}.html"

    async def _get_html(self, url: str) -> HtmlPayload:
        cached = self.cache.get(url)
        if cached and cached.is_fresh:
            return HtmlPayload(cached.value, "hit", _iso_timestamp(cached.stored_at), url)
        async with self.cache.lock(url):
            cached = self.cache.get(url)
            if cached and cached.is_fresh:
                return HtmlPayload(cached.value, "hit", _iso_timestamp(cached.stored_at), url)
            try:
                response = await self.client.get(url)
                response.raise_for_status()
                body = response.text
                expected_markers = ("Nippon Professional Baseball", "Regular Season", "日本野球機構", "予告先発")
                if not any(marker in body for marker in expected_markers):
                    raise ValueError("Unexpected NPB response")
                entry = self.cache.set(
                    url,
                    body,
                    self.settings.npb_cache_ttl_seconds,
                    self.settings.npb_stale_ttl_seconds,
                )
                return HtmlPayload(body, "miss", _iso_timestamp(entry.stored_at), url)
            except (httpx.HTTPError, ValueError) as exc:
                if cached and cached.can_serve_stale:
                    return HtmlPayload(cached.value, "stale", _iso_timestamp(cached.stored_at), url)
                raise NPBUpstreamError("NPB 官方賽程目前暫時無法連線") from exc

    async def standings_for_season(self, season: int) -> dict[str, Any]:
        url = self.standings_url(season)
        payload = await self._get_html(url)
        parsed = parse_npb_standings(payload.text, url)
        return {
            "league": "NPB",
            "season": season,
            "leagues": parsed["leagues"],
            "count": len(parsed["by_team"]),
            "meta": {
                "source": "NPB.jp official standings",
                "source_url": url,
                "cache": payload.cache_status,
                "updated_at": payload.fetched_at,
            },
        }

    async def season_results(self, target_date: date) -> dict[str, Any]:
        start_month = 3
        months = list(range(start_month, target_date.month + 1))
        urls = [f"{self.settings.npb_official_base}/games/{target_date.year}/schedule_{month:02d}_detail.html" for month in months]

        async def optional_fetch(url: str) -> HtmlPayload | None:
            try:
                return await self._get_html(url)
            except NPBUpstreamError:
                return None

        payloads = await asyncio.gather(*(optional_fetch(url) for url in urls))
        games: list[dict[str, Any]] = []
        seen: set[str] = set()
        for url, payload in zip(urls, payloads):
            if not payload:
                continue
            for game in parse_npb_month_scoreboard(payload.text, target_date.year, url):
                if game["game_pk"] in seen or str(game.get("date") or "") > target_date.isoformat():
                    continue
                seen.add(game["game_pk"])
                games.append(game)
        games.sort(key=lambda item: (item.get("date") or "", item.get("game_pk") or ""))
        return {
            "season": target_date.year,
            "through": target_date.isoformat(),
            "items": games,
            "count": len(games),
            "sources": [url for url, payload in zip(urls, payloads) if payload],
        }

    async def team_analysis_data(self, season: int, short_name: str) -> dict[str, Any]:
        batting_url = self.team_batting_url(season, short_name)
        pitching_url = self.team_pitching_url(season, short_name)
        batting_payload, pitching_payload = await asyncio.gather(
            self._get_html(batting_url),
            self._get_html(pitching_url),
        )
        return {
            "team": short_name,
            "batting": parse_npb_batting_stats(batting_payload.text, batting_url),
            "pitching": parse_npb_pitching_stats(pitching_payload.text, pitching_url),
            "meta": {
                "batting_source_url": batting_url,
                "pitching_source_url": pitching_url,
                "updated_at": max(batting_payload.fetched_at, pitching_payload.fetched_at),
                "cache": "stale" if "stale" in {batting_payload.cache_status, pitching_payload.cache_status} else "hit" if batting_payload.cache_status == pitching_payload.cache_status == "hit" else "miss",
            },
        }

    async def starter_profile(self, starter: dict[str, Any], season: int) -> dict[str, Any] | None:
        player_id = str(starter.get("player_id") or "")
        if not player_id:
            return None
        url = self.player_url(player_id)
        try:
            payload = await self._get_html(url)
        except NPBUpstreamError:
            return None
        parsed = parse_npb_player_pitching_profile(payload.text, season, url)
        if not parsed:
            return None
        parsed["player_id"] = player_id
        parsed["name"] = starter.get("name") or ""
        return parsed

    async def game_detail(self, game_pk: str) -> dict[str, Any]:
        match = re.fullmatch(r"npb_(?P<date>\d{8})_(?P<away>[A-Z]+)_(?P<home>[A-Z]+)", game_pk or "")
        if not match:
            raise NPBUpstreamError("無效的 NPB 賽事編號")
        try:
            target_date = datetime.strptime(match.group("date"), "%Y%m%d").date()
        except ValueError as exc:
            raise NPBUpstreamError("無效的 NPB 賽事日期") from exc
        schedule, history = await asyncio.gather(
            self.games_for_date(target_date),
            self.season_results(target_date),
        )
        game = next((item for item in schedule.get("items") or [] if item.get("game_pk") == game_pk), None)
        if not game:
            raise NPBUpstreamError("找不到指定的 NPB 賽事")
        away_short = (game.get("away") or {}).get("short_name")
        home_short = (game.get("home") or {}).get("short_name")
        if not away_short or not home_short:
            raise NPBUpstreamError("NPB 球隊資料不完整")
        away_starter_info = (game.get("away") or {}).get("probable_pitcher") or {}
        home_starter_info = (game.get("home") or {}).get("probable_pitcher") or {}
        away_data, home_data, away_profile, home_profile = await asyncio.gather(
            self.team_analysis_data(target_date.year, away_short),
            self.team_analysis_data(target_date.year, home_short),
            self.starter_profile(away_starter_info, target_date.year),
            self.starter_profile(home_starter_info, target_date.year),
        )
        if away_profile and away_profile.get("player_id"):
            away_data["pitching"].setdefault("by_id", {})[away_profile["player_id"]] = away_profile
        if home_profile and home_profile.get("player_id"):
            home_data["pitching"].setdefault("by_id", {})[home_profile["player_id"]] = home_profile
        away_form = npb_team_form(away_short, history.get("items") or [])
        home_form = npb_team_form(home_short, history.get("items") or [])
        analysis = build_npb_analysis(
            game,
            away_form,
            home_form,
            away_data["batting"],
            home_data["batting"],
            away_data["pitching"],
            home_data["pitching"],
        )
        return {
            "game": game,
            "analysis": analysis,
            "access": {"required_plan": "pro"},
            "meta": {
                "source": "NPB.jp official schedule, standings and player stats",
                "updated_at": max(str((schedule.get("meta") or {}).get("updated_at") or ""), str((away_data.get("meta") or {}).get("updated_at") or ""), str((home_data.get("meta") or {}).get("updated_at") or "")),
                "phase": "V18.6 NPB market integration",
                "official_recommendation_enabled": True,
            },
        }

    async def game_result(self, game_pk: str) -> dict[str, Any]:
        match = re.fullmatch(r"npb_(?P<date>\d{8})_(?P<away>[A-Z]+)_(?P<home>[A-Z]+)", str(game_pk or ""))
        if not match:
            raise NPBUpstreamError("無效的 NPB 賽事編號")
        try:
            target_date = datetime.strptime(match.group("date"), "%Y%m%d").date()
        except ValueError as exc:
            raise NPBUpstreamError("無效的 NPB 賽事日期") from exc
        payload = await self.games_for_date(target_date)
        game = next((item for item in payload.get("items") or [] if str(item.get("game_pk")) == str(game_pk)), None)
        if not game:
            raise NPBUpstreamError("找不到指定的 NPB 賽事結果")
        return game

    async def games_for_date(self, target_date: date) -> dict[str, Any]:
        source_url = self.daily_url(target_date)
        result_url = self.monthly_url(target_date)
        starter_url = self.starter_url()
        standings_url = self.standings_url(target_date.year)

        payload = await self._get_html(source_url)
        items = parse_npb_daily_page(payload.text, target_date, source_url)
        result_payload: HtmlPayload | None = None
        starter_payload: HtmlPayload | None = None
        standings_payload: HtmlPayload | None = None
        starter_data: dict[str, Any] = {"date": None, "by_team": {}, "source_url": starter_url}
        standings_data: dict[str, Any] = {"leagues": {}, "by_team": {}, "source_url": standings_url}

        async def optional_fetch(url: str) -> HtmlPayload | None:
            try:
                return await self._get_html(url)
            except NPBUpstreamError:
                return None

        result_payload, starter_payload, standings_payload = await asyncio.gather(
            optional_fetch(result_url),
            optional_fetch(starter_url),
            optional_fetch(standings_url),
        )
        if result_payload:
            scoreboard = parse_npb_japanese_scoreboard(result_payload.text, target_date, result_url)
            items = _merge_scoreboard(items, scoreboard, target_date, source_url)
        if starter_payload:
            starter_data = parse_npb_probable_starters(starter_payload.text, target_date, starter_url)
            _apply_probable_starters(items, starter_data)
        if standings_payload:
            standings_data = parse_npb_standings(standings_payload.text, standings_url)
            _apply_standings(items, standings_data)

        items.sort(key=lambda item: (item.get("game_date") or "", item.get("game_pk") or ""))
        payloads = [item for item in (payload, result_payload, starter_payload, standings_payload) if item]
        cache_states = [item.cache_status for item in payloads]
        cache_status = "stale" if "stale" in cache_states else ("hit" if cache_states and all(state == "hit" for state in cache_states) else "miss")
        announced_count = sum(
            1
            for game in items
            for side in ("away", "home")
            if (game.get(side) or {}).get("probable_pitcher", {}).get("announced")
        )
        return {
            "league": "NPB",
            "date": target_date.isoformat(),
            "timezone": "Asia/Taipei",
            "count": len(items),
            "items": items,
            "standings": standings_data.get("leagues") or {},
            "capabilities": {
                "schedule": True,
                "scores": True,
                "live_status": "beta",
                "probable_pitchers": announced_count > 0,
                "standings": bool(standings_data.get("by_team")),
                "analysis": "beta",
                "predictions": "moneyline_runline_totals",
                "odds": "real_market_when_configured",
                "settlement": "multi_market",
            },
            "meta": {
                "source": "NPB.jp official schedule, live scoreboard, probable starters and standings",
                "source_url": source_url,
                "result_source_url": result_url,
                "starter_source_url": starter_url,
                "standings_source_url": standings_url,
                "starter_date": starter_data.get("date"),
                "announced_starters": announced_count,
                "cache": cache_status,
                "updated_at": max((item.fetched_at for item in payloads), default=payload.fetched_at),
                "phase": "V18.6 NPB market integration",
            },
        }

