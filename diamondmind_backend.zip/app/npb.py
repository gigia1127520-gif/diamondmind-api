from __future__ import annotations

import asyncio
import html
import math
import re
from dataclasses import dataclass
from datetime import date, datetime, time, timedelta, timezone
from html.parser import HTMLParser
from typing import Any
from urllib.parse import urljoin
from zoneinfo import ZoneInfo

import httpx

from .cache import AsyncTTLCache
from .config import Settings
from .weather import WeatherService, environment_run_adjustment


TAIPEI = ZoneInfo("Asia/Taipei")
TOKYO = ZoneInfo("Asia/Tokyo")


class NPBUpstreamError(RuntimeError):
    pass


@dataclass
class HtmlPayload:
    text: str
    cache_status: str
    fetched_at: str
    source_url: str


@dataclass(frozen=True)
class TeamInfo:
    canonical: str
    short: str
    abbr: str
    zh: str


@dataclass(frozen=True)
class NPBVenueInfo:
    canonical: str
    aliases: tuple[str, ...]
    latitude: float
    longitude: float
    roof_type: str
    default_roof_closed: bool
    surface: str = "turf"


NPB_VENUES: tuple[NPBVenueInfo, ...] = (
    NPBVenueInfo("明治神宮野球場", ("Jingu", "神宮", "Meiji Jingu"), 35.6745, 139.7170, "open", False, "grass"),
    NPBVenueInfo("東京巨蛋", ("Tokyo Dome", "東京ドーム"), 35.7056, 139.7519, "fixed_dome", True),
    NPBVenueInfo("橫濱球場", ("Yokohama", "横浜", "Yokohama Stadium"), 35.4433, 139.6401, "open", False),
    NPBVenueInfo("Vantelin Dome 名古屋", ("Vantelin Dome", "バンテリン", "Nagoya Dome"), 35.1859, 136.9474, "fixed_dome", True),
    NPBVenueInfo("阪神甲子園球場", ("Koshien", "甲子園", "Hanshin Koshien"), 34.7214, 135.3616, "open", False, "grass"),
    NPBVenueInfo("MAZDA Zoom-Zoom 廣島球場", ("Mazda Stadium", "マツダ", "MAZDA"), 34.3918, 132.4847, "open", False, "grass"),
    NPBVenueInfo("みずほPayPay Dome福岡", ("PayPay Dome", "Mizuho PayPay", "みずほPayPay", "福岡ドーム"), 33.5953, 130.3620, "retractable_dome", True),
    NPBVenueInfo("ES CON FIELD HOKKAIDO", ("ES CON FIELD", "エスコン", "Es Con"), 43.0154, 141.5492, "retractable_dome", True, "grass"),
    NPBVenueInfo("京瓷巨蛋大阪", ("Kyocera Dome", "京セラ", "大阪ドーム"), 34.6694, 135.4764, "fixed_dome", True),
    NPBVenueInfo("樂天Mobile Park宮城", ("Rakuten Mobile", "楽天モバイル", "宮城"), 38.2564, 140.9026, "open", False),
    NPBVenueInfo("Belluna Dome", ("Belluna Dome", "ベルーナ", "Seibu Dome"), 35.7685, 139.4205, "covered_open_sides", False),
    NPBVenueInfo("ZOZO海洋球場", ("ZOZO Marine", "ZOZOマリン", "Marine Stadium"), 35.6453, 140.0308, "open", False),
    NPBVenueInfo("Hotto Motto Field神戶", ("Hotto Motto", "ほっともっと", "Kobe"), 34.6810, 135.0730, "open", False, "grass"),
    NPBVenueInfo("倉敷Muscat Stadium", ("Kurashiki", "マスカット"), 34.6017, 133.7684, "open", False, "grass"),
    NPBVenueInfo("沖繩Cellular Stadium那霸", ("Okinawa Cellular", "セルラー", "那覇"), 26.2030, 127.6750, "open", False),
)


TEAM_BY_SHORT: dict[str, TeamInfo] = {
    "Yakult": TeamInfo("Tokyo Yakult Swallows", "Yakult", "S", "東京養樂多燕子"),
    "Yomiuri": TeamInfo("Yomiuri Giants", "Yomiuri", "G", "讀賣巨人"),
    "DeNA": TeamInfo("YOKOHAMA DeNA BAYSTARS", "DeNA", "DB", "橫濱DeNA海灣之星"),
    "Chunichi": TeamInfo("Chunichi Dragons", "Chunichi", "D", "中日龍"),
    "Hanshin": TeamInfo("Hanshin Tigers", "Hanshin", "T", "阪神虎"),
    "Hiroshima": TeamInfo("Hiroshima Toyo Carp", "Hiroshima", "C", "廣島東洋鯉魚"),
    "SoftBank": TeamInfo("Fukuoka SoftBank Hawks", "SoftBank", "H", "福岡軟銀鷹"),
    "Nippon-Ham": TeamInfo("Hokkaido Nippon-Ham Fighters", "Nippon-Ham", "F", "北海道日本火腿鬥士"),
    "ORIX": TeamInfo("ORIX Buffaloes", "ORIX", "B", "歐力士猛牛"),
    "Rakuten": TeamInfo("Tohoku Rakuten Golden Eagles", "Rakuten", "E", "東北樂天金鷲"),
    "Seibu": TeamInfo("Saitama Seibu Lions", "Seibu", "L", "埼玉西武獅"),
    "Lotte": TeamInfo("Chiba Lotte Marines", "Lotte", "M", "千葉羅德海洋"),
    "CL": TeamInfo("Central League All-Stars", "CL", "CL", "中央聯盟明星隊"),
    "PL": TeamInfo("Pacific League All-Stars", "PL", "PL", "太平洋聯盟明星隊"),
}

TEAM_NAMES = sorted(TEAM_BY_SHORT, key=len, reverse=True)
TEAM_ALT = "|".join(re.escape(name) for name in TEAM_NAMES)

URL_CODE_TO_SHORT: dict[str, str] = {
    "s": "Yakult",
    "g": "Yomiuri",
    "db": "DeNA",
    "d": "Chunichi",
    "t": "Hanshin",
    "c": "Hiroshima",
    "h": "SoftBank",
    "f": "Nippon-Ham",
    "b": "ORIX",
    "e": "Rakuten",
    "l": "Seibu",
    "m": "Lotte",
}
SHORT_TO_URL_CODE: dict[str, str] = {value: key for key, value in URL_CODE_TO_SHORT.items()}
JAPANESE_TEAM_TO_SHORT: dict[str, str] = {
    "東京ヤクルトスワローズ": "Yakult",
    "ヤクルト": "Yakult",
    "読売ジャイアンツ": "Yomiuri",
    "巨人": "Yomiuri",
    "横浜DeNAベイスターズ": "DeNA",
    "横浜ＤｅＮＡベイスターズ": "DeNA",
    "DeNA": "DeNA",
    "中日ドラゴンズ": "Chunichi",
    "中日": "Chunichi",
    "阪神タイガース": "Hanshin",
    "阪神": "Hanshin",
    "広島東洋カープ": "Hiroshima",
    "広島": "Hiroshima",
    "福岡ソフトバンクホークス": "SoftBank",
    "ソフトバンク": "SoftBank",
    "北海道日本ハムファイターズ": "Nippon-Ham",
    "日本ハム": "Nippon-Ham",
    "オリックス・バファローズ": "ORIX",
    "オリックス": "ORIX",
    "東北楽天ゴールデンイーグルス": "Rakuten",
    "楽天": "Rakuten",
    "埼玉西武ライオンズ": "Seibu",
    "西武": "Seibu",
    "千葉ロッテマリーンズ": "Lotte",
    "ロッテ": "Lotte",
}
CENTRAL_TEAMS = {"Hanshin", "Yomiuri", "Yakult", "DeNA", "Hiroshima", "Chunichi"}
PACIFIC_TEAMS = {"SoftBank", "Seibu", "Nippon-Ham", "ORIX", "Lotte", "Rakuten"}
STANDINGS_RE = re.compile(
    rf"(?P<team>{TEAM_ALT})\s+(?P=team)\s+(?P<games>\d{{1,3}})\s+"
    rf"(?P<wins>\d{{1,3}})\s+(?P<losses>\d{{1,3}})\s+(?P<ties>\d{{1,3}})\s+"
    rf"(?P<pct>\.\d{{3}})\s+(?P<gb>-|\d+(?:\.\d+)?)",
    re.IGNORECASE,
)
STARTER_HEADING_RE = re.compile(r"(?P<month>\d{1,2})月(?P<day>\d{1,2})日の予告先発投手")
STARTER_VENUE_TIME_RE = re.compile(r"^[（(].+[）)]\s*\d{1,2}:\d{2}$")
JAPANESE_SCORE_HREF_RE = re.compile(
    r"/scores/(?P<year>\d{4})/(?P<mmdd>\d{4})/(?P<home>[a-z]+)-(?P<away>[a-z]+)-(?P<series>\d+)(?:/|$)",
    re.IGNORECASE,
)
JAPANESE_SCORE_RE = re.compile(r"(?P<home_score>\d+)\s*[-－]\s*(?P<away_score>\d+)")
JAPANESE_VENUE_RE = re.compile(r"[（(](?P<venue>[^）)]+)[）)]")
JAPANESE_INNING_RE = re.compile(r"(?P<inning>\d+)\s*回\s*(?P<half>表|裏)")
TIME_RE = re.compile(r"^(?:[01]?\d|2[0-3]):[0-5]\d$")
SCORE_RE = re.compile(
    rf"^(?P<home>{TEAM_ALT})\s+(?P<home_score>\d+)\s+Game\s+\d+\s+(?P<venue>.+?)\s+(?P<away_score>\d+)\s+(?P<away>{TEAM_ALT})$",
    re.IGNORECASE,
)
POSTPONED_RE = re.compile(
    rf"^(?P<home>{TEAM_ALT})\s+(?P<reason>Rained Out|Cancelled|Canceled|Postponed)\s+(?P<away>{TEAM_ALT})$",
    re.IGNORECASE,
)


class _NPBHtmlParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.tokens: list[str] = []
        self.links: list[tuple[str, str]] = []
        self._href: str | None = None
        self._anchor_parts: list[str] = []

    @staticmethod
    def _clean(value: str) -> str:
        return re.sub(r"\s+", " ", html.unescape(value or "")).strip()

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag.lower() == "a":
            self._href = dict(attrs).get("href") or ""
            self._anchor_parts = []

    def handle_data(self, data: str) -> None:
        cleaned = self._clean(data)
        if not cleaned:
            return
        self.tokens.append(cleaned)
        if self._href is not None:
            self._anchor_parts.append(cleaned)

    def handle_endtag(self, tag: str) -> None:
        if tag.lower() == "a" and self._href is not None:
            text = self._clean(" ".join(self._anchor_parts))
            if text:
                self.links.append((self._href, text))
            self._href = None
            self._anchor_parts = []


class _NPBStarterHtmlParser(_NPBHtmlParser):
    """HTML parser that also captures team names stored in image alt attributes."""

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        super().handle_starttag(tag, attrs)
        if tag.lower() != "img":
            return
        alt = self._clean(dict(attrs).get("alt") or "")
        if alt:
            self.tokens.append(alt)


class _NPBTableParser(HTMLParser):
    """Collect HTML table rows while retaining links embedded in each cell."""

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.rows: list[list[dict[str, Any]]] = []
        self._row: list[dict[str, Any]] | None = None
        self._cell: dict[str, Any] | None = None
        self._link: str | None = None

    @staticmethod
    def _clean(value: str) -> str:
        return re.sub(r"\s+", " ", html.unescape(value or "")).strip()

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        tag = tag.lower()
        if tag == "tr":
            self._row = []
        elif tag in {"th", "td"} and self._row is not None:
            self._cell = {"parts": [], "links": []}
        elif tag == "a" and self._cell is not None:
            self._link = dict(attrs).get("href") or ""

    def handle_data(self, data: str) -> None:
        if self._cell is None:
            return
        cleaned = self._clean(data)
        if not cleaned:
            return
        self._cell["parts"].append(cleaned)
        if self._link is not None:
            self._cell["links"].append({"href": self._link, "text": cleaned})

    def handle_endtag(self, tag: str) -> None:
        tag = tag.lower()
        if tag == "a":
            self._link = None
        elif tag in {"th", "td"} and self._row is not None and self._cell is not None:
            text = self._clean(" ".join(self._cell["parts"]))
            self._row.append({"text": text, "links": list(self._cell["links"])})
            self._cell = None
        elif tag == "tr" and self._row is not None:
            if any(cell.get("text") for cell in self._row):
                self.rows.append(self._row)
            self._row = None



class _NPBStructuredTableParser(HTMLParser):
    """Capture table/row/cell attributes for lineup and box-score parsing."""

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.tables: list[dict[str, Any]] = []
        self._table: dict[str, Any] | None = None
        self._row: dict[str, Any] | None = None
        self._cell: dict[str, Any] | None = None
        self._link: str | None = None

    @staticmethod
    def _clean(value: str) -> str:
        return re.sub(r"\s+", " ", html.unescape(value or "")).strip()

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        tag = tag.lower()
        attr_map = {key: value or "" for key, value in attrs}
        if tag == "table":
            self._table = {"attrs": attr_map, "rows": []}
        elif tag == "tr" and self._table is not None:
            self._row = {"attrs": attr_map, "cells": []}
        elif tag in {"th", "td"} and self._row is not None:
            self._cell = {"attrs": attr_map, "parts": [], "links": []}
        elif tag == "a" and self._cell is not None:
            self._link = attr_map.get("href") or ""
        elif tag == "img" and self._cell is not None:
            alt = self._clean(attr_map.get("alt") or "")
            if alt:
                self._cell["parts"].append(alt)

    def handle_data(self, data: str) -> None:
        if self._cell is None:
            return
        cleaned = self._clean(data)
        if not cleaned:
            return
        self._cell["parts"].append(cleaned)
        if self._link is not None:
            self._cell["links"].append({"href": self._link, "text": cleaned})

    def handle_endtag(self, tag: str) -> None:
        tag = tag.lower()
        if tag == "a":
            self._link = None
        elif tag in {"th", "td"} and self._row is not None and self._cell is not None:
            self._row["cells"].append(
                {
                    "text": self._clean(" ".join(self._cell["parts"])),
                    "links": list(self._cell["links"]),
                    "attrs": dict(self._cell["attrs"]),
                }
            )
            self._cell = None
        elif tag == "tr" and self._table is not None and self._row is not None:
            if any(cell.get("text") for cell in self._row["cells"]):
                self._table["rows"].append(self._row)
            self._row = None
        elif tag == "table" and self._table is not None:
            if self._table["rows"]:
                self.tables.append(self._table)
            self._table = None


def _normalize_header(value: str) -> str:
    aliases = {
        "守備": "POS", "選手": "PLAYER", "打順": "ORDER", "投手": "PITCHER",
        "打数": "AB", "得点": "R", "安打": "H", "打点": "RBI", "盗塁": "SB",
        "四球": "BB", "死球": "HP", "三振": "SO", "奪三振": "SO", "本塁打": "HR",
        "投球数": "PITCHES", "球数": "PITCHES", "投球回": "IP", "打者": "BF", "失点": "R", "自責点": "ER",
        "被安打": "H", "被本塁打": "HR", "与四球": "BB", "与死球": "HB",
    }
    text = re.sub(r"\s+", "", str(value or "")).upper()
    return aliases.get(text, text)


def _attrs_text(*values: Any) -> str:
    parts: list[str] = []
    for value in values:
        if isinstance(value, dict):
            parts.extend(str(item) for item in value.values())
        elif value is not None:
            parts.append(str(value))
    return " ".join(parts).lower()


def _player_id_from_links(links: list[dict[str, Any]]) -> str | None:
    for link in links or []:
        match = re.search(r"/(?:eng/)?players/(?P<id>\d+)\.html", str(link.get("href") or ""))
        if match:
            return match.group("id")
    return None


def _split_player_position(value: str) -> tuple[str, str]:
    text = re.sub(r"\s+", " ", str(value or "")).strip()
    if not text:
        return "", ""
    # English box scores use “Player, CF”; Japanese pages may use “Player（中）”.
    match = re.match(r"^(?P<name>.+?),\s*(?P<position>[A-Z0-9\-]+)$", text, re.IGNORECASE)
    if match:
        return match.group("name").strip(), match.group("position").upper().strip()
    match = re.match(r"^(?P<name>.+?)[（(](?P<position>[^）)]+)[）)]$", text)
    if match:
        return match.group("name").strip(), match.group("position").strip()
    return text, ""


def _clean_pitcher_name(value: str) -> str:
    text = re.sub(r"\s+", " ", str(value or "")).strip()
    text = re.sub(r",?\s*[（(](?:W|L|S|H|勝|敗|Ｓ|Ｈ)[^）)]*[）)]", "", text, flags=re.IGNORECASE)
    text = re.sub(r",\s*$", "", text)
    return text.strip()


def _parse_batting_table(table: dict[str, Any]) -> dict[str, Any]:
    """Parse both the English season-style and Japanese live batting tables.

    The Japanese live box score publishes ``守備 / 選手 / 打数 / 安打 / 打点``
    but does not include BB and SO in the batting table. Older logic required
    BB and SO, so a game could already be live while the site still reported
    that the official lineup was unavailable.
    """

    rows = table.get("rows") or []
    header_index = -1
    headers: list[str] = []
    for index, row in enumerate(rows):
        values = [_normalize_header(cell.get("text") or "") for cell in row.get("cells") or []]
        normalized = set(values)
        if {"AB", "H", "RBI"}.issubset(normalized) and ({"PLAYER", "POS"} & normalized or len(values) >= 5):
            header_index, headers = index, values
            break
    if header_index < 0:
        return {"players": [], "lineup": [], "available": False, "validation_rate": 0.0}

    def header_index_for(*keys: str) -> int | None:
        for key in keys:
            if key in headers:
                return headers.index(key)
        return None

    player_index = header_index_for("PLAYER", "BATTER")
    position_index = header_index_for("POS")
    order_index = header_index_for("ORDER")
    # The Japanese table's first heading is intentionally blank and contains
    # batting-order numbers in the body.
    if order_index is None and headers and headers[0] == "" and (position_index == 1 or player_index == 2):
        order_index = 0
    if player_index is None:
        player_index = 0

    players: list[dict[str, Any]] = []
    for row in rows[header_index + 1 :]:
        cells = row.get("cells") or []
        if not cells:
            continue
        values = [str(cell.get("text") or "").strip() for cell in cells]
        if player_index >= len(values):
            continue
        player_cell = cells[player_index]
        name_value = values[player_index]
        position = values[position_index] if position_index is not None and position_index < len(values) else ""
        name, combined_position = _split_player_position(name_value)
        if not position:
            position = combined_position
        if not name or name.upper() in {"TOTAL", "BATTER", "PLAYER", "TEAM", "選手"}:
            continue

        data = {headers[idx]: values[idx] for idx in range(min(len(headers), len(values))) if headers[idx]}
        ab = _safe_int(data.get("AB"))
        if ab is None and all(_safe_int(data.get(key)) is None for key in ("H", "RBI", "BB", "SO")):
            continue

        batting_order = None
        if order_index is not None and order_index < len(values):
            order_value = re.sub(r"[^0-9]", "", values[order_index])
            if order_value:
                parsed_order = int(order_value)
                if 1 <= parsed_order <= 9:
                    batting_order = parsed_order

        attr_text = _attrs_text(row.get("attrs"), player_cell.get("attrs"), table.get("attrs"))
        explicit_sub = any(token in attr_text for token in ("sub", "change", "replace", "bench", "indent", "koukai"))
        pos_upper = position.upper().strip("()（）")
        players.append({
            "player_id": _player_id_from_links(player_cell.get("links") or []),
            "name": name,
            "position": position.strip("()（）"),
            "batting_order": batting_order,
            "ab": ab or 0,
            "hits": _safe_int(data.get("H")) or 0,
            "rbi": _safe_int(data.get("RBI")) or 0,
            "walks": _safe_int(data.get("BB")) or 0,
            "hit_by_pitch": _safe_int(data.get("HP")) or _safe_int(data.get("HB")) or 0,
            "strikeouts": _safe_int(data.get("SO")) or 0,
            "explicit_substitute": explicit_sub,
            "pinch_role": "PH" in pos_upper or "PR" in pos_upper or any(mark in position for mark in ("打", "走")),
        })

    explicit_lineup: dict[int, dict[str, Any]] = {}
    for player in players:
        order = player.get("batting_order")
        if isinstance(order, int) and 1 <= order <= 9 and order not in explicit_lineup and not player.get("explicit_substitute"):
            explicit_lineup[order] = {**player, "is_starter": True}
    if len(explicit_lineup) == 9:
        lineup = [explicit_lineup[index] for index in range(1, 10)]
        return {"players": players, "lineup": lineup, "available": True, "validation_rate": 1.0}

    lineup: list[dict[str, Any]] = []
    active_slot = 0
    substitution_chain = False
    last_starter_position = ""
    for player in players:
        position = str(player.get("position") or "").upper()
        is_pinch = bool(player.get("pinch_role"))
        is_pitcher = position == "P" or position.endswith("-P") or position.startswith("投")
        is_sub = bool(player.get("explicit_substitute")) or is_pinch
        if active_slot == 0:
            active_slot = 1
        elif is_sub or substitution_chain or (is_pitcher and ("P" in last_starter_position or active_slot >= 9)):
            is_sub = True
        elif active_slot < 9:
            active_slot += 1
        else:
            is_sub = True
        if not is_sub and len(lineup) < 9:
            last_starter_position = position
            lineup.append({**player, "batting_order": len(lineup) + 1, "is_starter": True})
            substitution_chain = False
        else:
            substitution_chain = is_pinch or (substitution_chain and is_pitcher)
    if len(lineup) < 9:
        fallback = [player for player in players if not player.get("pinch_role")][:9]
        lineup = [{**player, "batting_order": idx + 1, "is_starter": True} for idx, player in enumerate(fallback)]
    return {
        "players": players,
        "lineup": lineup[:9],
        "available": len(lineup) >= 9,
        "validation_rate": round(min(9, len(lineup)) / 9, 3),
    }


def _parse_pitching_table(table: dict[str, Any]) -> dict[str, Any]:
    rows = table.get("rows") or []
    required = {"IP", "H", "BB", "SO", "ER"}
    header_end = -1
    headers: list[str] = []
    for index, row in enumerate(rows):
        values = [_normalize_header(cell.get("text") or "") for cell in row.get("cells") or []]
        if required.issubset(set(values)):
            header_end, headers = index, values
            break
    if header_end < 0:
        # A few legacy pages split one header over adjacent rows. Retain a
        # permissive fallback so historical box scores still load.
        for index in range(len(rows)):
            combined: set[str] = set()
            candidate_headers: list[str] = []
            for offset, probe in enumerate(rows[index : index + 3]):
                probe_headers = [_normalize_header(cell.get("text") or "") for cell in probe.get("cells") or []]
                combined.update(probe_headers)
                if len(probe_headers) > len(candidate_headers):
                    candidate_headers = probe_headers
                if required.issubset(combined):
                    header_end = index + offset
                    headers = candidate_headers
                    break
            if header_end >= 0:
                break
    if header_end < 0:
        return {"pitchers": [], "available": False}

    def column(*keys: str) -> int | None:
        for key in keys:
            if key in headers:
                return headers.index(key)
        return None

    name_index = column("PITCHER", "PLAYER")
    ip_index = column("IP")
    bf_index = column("BF")
    hits_index = column("H")
    walks_index = column("BB")
    hb_index = column("HB", "HP")
    so_index = column("SO")
    er_index = column("ER")
    if name_index is None:
        name_index = 0

    pitchers: list[dict[str, Any]] = []
    pending: dict[str, Any] | None = None

    def append_pitcher(
        name_cell: dict[str, Any],
        name_value: str,
        ip_value: Any,
        *,
        bf: Any = None,
        hits: Any = None,
        walks: Any = None,
        hit_batters: Any = None,
        strikeouts: Any = None,
        earned_runs: Any = None,
    ) -> None:
        name = _clean_pitcher_name(name_value)
        if not name or name.upper() in {"TOTAL", "PITCHER", "PLAYER"}:
            return
        outs = _innings_to_outs(ip_value)
        if outs is None:
            return
        pitchers.append({
            "player_id": _player_id_from_links(name_cell.get("links") or []),
            "name": name,
            "outs": outs,
            "innings": _outs_to_innings(outs),
            "batters_faced": _safe_int(bf) or 0,
            "hits": _safe_int(hits) or 0,
            "walks": _safe_int(walks) or 0,
            "hit_batters": _safe_int(hit_batters) or 0,
            "strikeouts": _safe_int(strikeouts) or 0,
            "earned_runs": _safe_int(earned_runs) or 0,
            "is_starter": len(pitchers) == 0,
        })

    def value_at(values: list[str], index: int | None) -> Any:
        return values[index] if index is not None and index < len(values) else None

    for row in rows[header_end + 1 :]:
        cells = row.get("cells") or []
        if not cells:
            continue
        values = [str(cell.get("text") or "").strip() for cell in cells]
        normalized = {_normalize_header(value) for value in values}
        if required.intersection(normalized) and not any(re.search(r"[A-Za-z一-龥ぁ-んァ-ン]", value) for value in values):
            continue

        if pending and len(values) >= 6 and all(_safe_float(value) is not None for value in values[:6]):
            japanese_tail = len(values) >= 9
            append_pitcher(
                pending["cell"], pending["name"], pending["ip"],
                bf=pending.get("bf") if japanese_tail else values[0],
                hits=values[0] if japanese_tail else values[1],
                walks=values[2] if japanese_tail else values[2],
                hit_batters=values[3] if japanese_tail else values[3],
                strikeouts=values[4] if japanese_tail else values[4],
                earned_runs=values[8] if japanese_tail else values[5],
            )
            pending = None
            continue

        # Current Japanese live box scores expose named columns such as
        # 投手 / 打者 / 投球回 / 安打 / 四球 / 死球 / 三振 / 自責点.
        if ip_index is not None and name_index < len(values) and ip_index < len(values):
            name_value = values[name_index]
            complete_named_row = all(
                column_index is None or column_index < len(values)
                for column_index in (bf_index, hits_index, walks_index, hb_index, so_index, er_index)
            )
            if complete_named_row and re.search(r"[A-Za-z一-龥ぁ-んァ-ン]", name_value) and _innings_to_outs(values[ip_index]) is not None:
                append_pitcher(
                    cells[name_index],
                    name_value,
                    values[ip_index],
                    bf=value_at(values, bf_index),
                    hits=value_at(values, hits_index),
                    walks=value_at(values, walks_index),
                    hit_batters=value_at(values, hb_index),
                    strikeouts=value_at(values, so_index),
                    earned_runs=value_at(values, er_index),
                )
                pending = None
                continue

        # English/legacy standard layout: Pitcher | IP | BF | H | BB | HB | SO | ER
        if len(values) >= 8 and _innings_to_outs(values[1]) is not None:
            append_pitcher(
                cells[0], values[0], values[1],
                bf=values[2], hits=values[3], walks=values[4], hit_batters=values[5],
                strikeouts=values[6], earned_runs=values[7],
            )
            pending = None
            continue

        # Mobile/legacy tables can split Pitcher+IP and the result columns into two rows.
        if len(values) >= 2 and re.search(r"[A-Za-z一-龥ぁ-んァ-ン]", values[0]):
            # Current Japanese pages split each pitcher over two rows:
            # name / pitches / batters faced / innings, followed by
            # H / HR / BB / HB / SO / WP / BK / R / ER.  On some pages the
            # inning fraction is a separate cell/text node (``5`` + ``.2``).
            ip_value = values[-1]
            bf_value = values[-2] if len(values) >= 3 else None
            if (
                len(values) >= 5
                and re.fullmatch(r"(?:\.[12]|[12]/3|⅓|⅔)", values[-1].replace(" ", ""))
                and re.fullmatch(r"\d+", values[-2].strip())
            ):
                fraction = values[-1].replace(" ", "").replace("1/3", ".1").replace("2/3", ".2").replace("⅓", ".1").replace("⅔", ".2")
                ip_value = f"{values[-2]}{fraction}"
                bf_value = values[-3]
            if _innings_to_outs(ip_value) is not None:
                pending = {
                    "cell": cells[0],
                    "name": values[0],
                    "ip": ip_value,
                    "bf": bf_value,
                }
                continue

        if values:
            match = re.match(r"^(?P<name>.*?[A-Za-z一-龥ぁ-んァ-ン][^0-9]*?)(?P<ip>\d+(?:\.[012])?|\+)$", values[0])
            if match:
                stat_values = values[1:7] + [None] * 6
                append_pitcher(
                    cells[0], match.group("name"), match.group("ip"),
                    bf=stat_values[0], hits=stat_values[1], walks=stat_values[2],
                    hit_batters=stat_values[3], strikeouts=stat_values[4], earned_runs=stat_values[5],
                )

    return {"pitchers": pitchers, "available": bool(pitchers)}


def parse_npb_boxscore(page_html: str, away_short: str, home_short: str, source_url: str) -> dict[str, Any]:
    parser = _NPBStructuredTableParser()
    parser.feed(page_html)
    batting_tables: list[dict[str, Any]] = []
    pitching_tables: list[dict[str, Any]] = []
    for table in parser.tables:
        normalized_rows = [
            {_normalize_header(cell.get("text") or "") for cell in row.get("cells") or []}
            for row in table.get("rows") or []
        ]
        batting_header = any(
            {"AB", "H", "RBI"}.issubset(row_headers)
            and ({"PLAYER", "POS"} & row_headers or len(row_headers) >= 5)
            for row_headers in normalized_rows
        )
        pitching_header = any(
            {"IP", "H", "BB", "SO", "ER"}.issubset(row_headers)
            for row_headers in normalized_rows
        )
        # Current NPB live pages put batting and pitching sections inside the
        # same team table. A table may therefore belong to both collections.
        if batting_header:
            batting_tables.append(table)
        if pitching_header:
            pitching_tables.append(table)
    sides = ("away", "home")
    teams = {"away": away_short, "home": home_short}
    lineups: dict[str, Any] = {}
    pitching: dict[str, Any] = {}
    for index, side in enumerate(sides):
        batting = _parse_batting_table(batting_tables[index]) if index < len(batting_tables) else {"players": [], "lineup": [], "available": False, "validation_rate": 0.0}
        pitching_side = _parse_pitching_table(pitching_tables[index]) if index < len(pitching_tables) else {"pitchers": [], "available": False}
        lineups[side] = {
            "team": teams[side],
            "team_name_zh": TEAM_BY_SHORT.get(teams[side], TeamInfo("", "", "", teams[side])).zh,
            "official": bool(batting.get("available")),
            "status": "official" if batting.get("available") else "not_announced",
            "validation_rate": batting.get("validation_rate") or 0.0,
            "batting_order": batting.get("lineup") or [],
            "all_batters": batting.get("players") or [],
            "source_url": source_url,
        }
        pitching[side] = {
            "team": teams[side],
            "available": bool(pitching_side.get("available")),
            "pitchers": pitching_side.get("pitchers") or [],
            "source_url": source_url,
        }
    return {
        "available": any(item.get("official") for item in lineups.values()) or any(item.get("available") for item in pitching.values()),
        "lineups": lineups,
        "pitching": pitching,
        "source_url": source_url,
    }


def _npb_live_detail_urls(source_url: str) -> list[str]:
    """Return canonical NPB detail URLs in data-rich priority order.

    NPB's schedule pages usually link to a *directory* such as
    ``/scores/2026/0717/g-d-15/`` rather than to ``box.html``.  The previous
    implementation only recognised URLs that already ended in ``index.html``
    or ``roster.html``; as a result it kept requesting the lightweight game
    top page and never reached the official batting/pitching table.  Accept
    both directory and filename forms and always query ``box.html`` first.
    """

    cleaned = str(source_url or "").strip()
    if not cleaned:
        return []
    without_fragment = cleaned.split("#", 1)[0].split("?", 1)[0]
    match = re.match(
        r"^(?P<base>https?://[^?#]+/scores/\d{4}/\d{4}/[^/]+/)(?:(?:index|playbyplay|box|roster)\.html)?$",
        without_fragment,
        flags=re.IGNORECASE,
    )
    if not match and re.match(r"^https?://[^?#]+/scores/\d{4}/\d{4}/[^/]+$", without_fragment, flags=re.IGNORECASE):
        without_fragment = f"{without_fragment}/"
        match = re.match(
            r"^(?P<base>https?://[^?#]+/scores/\d{4}/\d{4}/[^/]+/)$",
            without_fragment,
            flags=re.IGNORECASE,
        )
    if not match:
        return [cleaned]
    base = match.group("base")
    return list(dict.fromkeys([
        f"{base}box.html",
        f"{base}index.html",
        f"{base}roster.html",
        cleaned,
    ]))


def _strip_html_lines(page_html: str) -> list[str]:
    text = re.sub(r"<(?:br|/p|/li|/tr|/h[1-6]|/div|/section|/dl|/dd|/dt)[^>]*>", "\n", page_html, flags=re.IGNORECASE)
    text = re.sub(r"<[^>]+>", " ", text)
    text = html.unescape(text)
    return [re.sub(r"\s+", " ", line).strip() for line in text.splitlines() if re.sub(r"\s+", " ", line).strip()]


def parse_npb_roster_transactions(page_html: str, target_date: date, source_url: str) -> dict[str, Any]:
    lines = _strip_html_lines(page_html)
    start = next((idx for idx, line in enumerate(lines) if f"{target_date.year}年{target_date.month}月{target_date.day}日" in line and "出場選手" in line), -1)
    if start < 0:
        return {"date": None, "registered": [], "deregistered": [], "source_url": source_url}
    team_alt = "|".join(re.escape(name) for name in sorted(JAPANESE_TEAM_TO_SHORT, key=len, reverse=True))
    entry_re = re.compile(rf"^(?P<team>{team_alt})\s+(?P<position>投手|捕手|内野手|外野手)\s+(?P<number>\d{{1,3}}|00)\s+(?P<name>.+)$")
    mode: str | None = None
    registered: list[dict[str, Any]] = []
    deregistered: list[dict[str, Any]] = []
    for line in lines[start + 1 :]:
        if line == "出場選手一覧" or line.startswith("出場選手一覧"):
            break
        if line == "出場選手登録":
            mode = "registered"
            continue
        if line == "出場選手登録抹消":
            mode = "deregistered"
            continue
        match = entry_re.match(line)
        if not match or mode is None:
            continue
        short = JAPANESE_TEAM_TO_SHORT.get(match.group("team"))
        if not short:
            continue
        entry = {
            "team": short,
            "team_name_zh": TEAM_BY_SHORT[short].zh,
            "position": match.group("position"),
            "number": match.group("number"),
            "name": match.group("name").strip(),
            "date": target_date.isoformat(),
            "source_url": source_url,
        }
        (registered if mode == "registered" else deregistered).append(entry)
    return {"date": target_date.isoformat(), "registered": registered, "deregistered": deregistered, "source_url": source_url}


def _venue_profile(venue_name: str) -> dict[str, Any]:
    text = re.sub(r"\s+", " ", str(venue_name or "")).strip().lower()
    for venue in NPB_VENUES:
        if any(alias.lower() in text or text in alias.lower() for alias in venue.aliases if text):
            return {
                "available": True,
                "name": venue.canonical,
                "official_name_raw": venue_name,
                "latitude": venue.latitude,
                "longitude": venue.longitude,
                "roof_type": venue.roof_type,
                "roof_closed": venue.default_roof_closed,
                "surface": venue.surface,
                "park_run_factor": 1.0,
                "park_factor_basis": "neutral_baseline_no_official_npb_park_factor",
            }
    return {
        "available": False,
        "name": venue_name or "球場尚未確認",
        "official_name_raw": venue_name,
        "latitude": None,
        "longitude": None,
        "roof_type": "unknown",
        "roof_closed": False,
        "surface": "unknown",
        "park_run_factor": 1.0,
        "park_factor_basis": "unknown",
    }


def _pitching_advanced(profile: dict[str, Any] | None, fip_constant: float = 3.10) -> dict[str, Any]:
    value = profile or {}
    outs = int(value.get("outs") or 0)
    bf = int(value.get("batters_faced") or 0)
    innings = outs / 3 if outs else 0.0
    strikeouts = int(value.get("strikeouts") or 0)
    walks = int(value.get("walks") or 0)
    hit_batters = int(value.get("hit_batters") or 0)
    homers = int(value.get("home_runs") or 0)
    fip = ((13 * homers + 3 * (walks + hit_batters) - 2 * strikeouts) / innings + fip_constant) if innings else None
    return {
        "fip_estimate": round(fip, 2) if fip is not None else None,
        "fip_constant": fip_constant,
        "k_pct": round(strikeouts / bf, 3) if bf else None,
        "bb_pct": round(walks / bf, 3) if bf else None,
        "basis": "NPB official season totals; DiamondMind calculated",
    }


def _batting_advanced(profile: dict[str, Any] | None) -> dict[str, Any]:
    value = profile or {}
    pa = int(value.get("plate_appearances") or 0)
    walks = int(value.get("walks") or 0)
    strikeouts = int(value.get("strikeouts") or 0)
    avg = _safe_float(value.get("avg"))
    slg = _safe_float(value.get("slg"))
    return {
        "iso": round(slg - avg, 3) if avg is not None and slg is not None else None,
        "k_pct": round(strikeouts / pa, 3) if pa else None,
        "bb_pct": round(walks / pa, 3) if pa else None,
        "basis": "NPB official season totals; DiamondMind calculated",
    }


def _normalized_player_name(value: str) -> str:
    return re.sub(r"[^0-9a-zA-Z一-龥ぁ-んァ-ン]+", "", str(value or "")).lower()


def aggregate_npb_lineup(lineup: dict[str, Any], batting: dict[str, Any]) -> dict[str, Any]:
    by_id = batting.get("by_id") or {}
    by_name = batting.get("by_name") or {}
    matched: list[dict[str, Any]] = []
    for player in lineup.get("batting_order") or []:
        stats = None
        player_id = str(player.get("player_id") or "")
        if player_id:
            stats = by_id.get(player_id)
        if not stats:
            stats = by_name.get(_normalized_player_name(player.get("name") or ""))
        if stats:
            matched.append(stats)
    pa = sum(int(item.get("plate_appearances") or 0) for item in matched)
    if not matched:
        return {"available": False, "matched": 0, "lineup_size": len(lineup.get("batting_order") or []), "ops": None, "iso": None, "k_pct": None, "bb_pct": None}
    def weighted(field: str) -> float | None:
        values = [(float(item[field]), max(1, int(item.get("plate_appearances") or 0))) for item in matched if item.get(field) is not None]
        total = sum(weight for _, weight in values)
        return sum(value * weight for value, weight in values) / total if total else None
    return {
        "available": True,
        "official": bool(lineup.get("official")),
        "matched": len(matched),
        "lineup_size": len(lineup.get("batting_order") or []),
        "validation_rate": round(len(matched) / max(1, len(lineup.get("batting_order") or [])), 3),
        "ops": round(weighted("ops"), 3) if weighted("ops") is not None else None,
        "iso": round(weighted("iso"), 3) if weighted("iso") is not None else None,
        "k_pct": round(sum(int(item.get("strikeouts") or 0) for item in matched) / pa, 3) if pa else None,
        "bb_pct": round(sum(int(item.get("walks") or 0) for item in matched) / pa, 3) if pa else None,
    }


def summarize_starter_recent(boxscores: list[dict[str, Any]], side_team: str, starter_info: dict[str, Any], limit: int = 3) -> dict[str, Any]:
    player_id = str(starter_info.get("player_id") or "")
    name_key = _normalized_player_name(starter_info.get("name") or "")
    starts: list[dict[str, Any]] = []
    for item in sorted(boxscores, key=lambda value: str(value.get("date") or ""), reverse=True):
        side = "away" if item.get("away") == side_team else "home" if item.get("home") == side_team else ""
        if not side:
            continue
        pitchers = (((item.get("boxscore") or {}).get("pitching") or {}).get(side) or {}).get("pitchers") or []
        if not pitchers:
            continue
        starter = pitchers[0]
        matches = bool(player_id and str(starter.get("player_id") or "") == player_id) or bool(name_key and _normalized_player_name(starter.get("name") or "") == name_key)
        if not matches:
            continue
        starts.append({"date": item.get("date"), **starter, "source_url": item.get("source_url")})
        if len(starts) >= limit:
            break
    outs = sum(int(item.get("outs") or 0) for item in starts)
    hits = sum(int(item.get("hits") or 0) for item in starts)
    walks = sum(int(item.get("walks") or 0) for item in starts)
    strikeouts = sum(int(item.get("strikeouts") or 0) for item in starts)
    earned_runs = sum(int(item.get("earned_runs") or 0) for item in starts)
    bf = sum(int(item.get("batters_faced") or 0) for item in starts)
    return {
        "available": bool(starts),
        "starts": len(starts),
        "innings": _outs_to_innings(outs) if outs else 0,
        "era": round(earned_runs * 27 / outs, 2) if outs else None,
        "whip": round((hits + walks) * 3 / outs, 3) if outs else None,
        "k_bb": round(strikeouts / walks, 2) if walks else (float(strikeouts) if strikeouts else None),
        "k_pct": round(strikeouts / bf, 3) if bf else None,
        "bb_pct": round(walks / bf, 3) if bf else None,
        "game_logs": starts,
    }


def summarize_bullpen_usage(boxscores: list[dict[str, Any]], team: str, target_date: date) -> dict[str, Any]:
    cutoff = target_date - timedelta(days=3)
    appearances: list[dict[str, Any]] = []
    for item in boxscores:
        try:
            game_date = date.fromisoformat(str(item.get("date")))
        except ValueError:
            continue
        if not cutoff <= game_date < target_date:
            continue
        side = "away" if item.get("away") == team else "home" if item.get("home") == team else ""
        if not side:
            continue
        pitchers = (((item.get("boxscore") or {}).get("pitching") or {}).get(side) or {}).get("pitchers") or []
        for pitcher in pitchers[1:]:
            appearances.append({"date": game_date.isoformat(), **pitcher, "source_url": item.get("source_url")})
    outs = sum(int(item.get("outs") or 0) for item in appearances)
    bf = sum(int(item.get("batters_faced") or 0) for item in appearances)
    by_pitcher: dict[str, dict[str, Any]] = {}
    for appearance in appearances:
        key = str(appearance.get("player_id") or _normalized_player_name(appearance.get("name") or ""))
        row = by_pitcher.setdefault(key, {"name": appearance.get("name"), "appearances": 0, "outs": 0, "batters_faced": 0, "dates": []})
        row["appearances"] += 1
        row["outs"] += int(appearance.get("outs") or 0)
        row["batters_faced"] += int(appearance.get("batters_faced") or 0)
        row["dates"].append(appearance.get("date"))
    heavy = []
    back_to_back = 0
    for row in by_pitcher.values():
        unique_dates = sorted(set(row["dates"]))
        consecutive = any((date.fromisoformat(unique_dates[idx]) - date.fromisoformat(unique_dates[idx - 1])).days == 1 for idx in range(1, len(unique_dates)))
        if consecutive:
            back_to_back += 1
        if row["appearances"] >= 2 or row["outs"] >= 6 or row["batters_faced"] >= 10:
            heavy.append({**row, "innings": _outs_to_innings(row["outs"]), "back_to_back": consecutive})
    fatigue_score = min(100, round(outs * 3.0 + max(0, len(appearances) - 5) * 5 + back_to_back * 12))
    return {
        "available": bool(appearances),
        "window_days": 3,
        "appearances": len(appearances),
        "pitchers_used": len(by_pitcher),
        "innings": _outs_to_innings(outs) if outs else 0,
        "batters_faced": bf,
        "back_to_back_pitchers": back_to_back,
        "heavy_usage": sorted(heavy, key=lambda item: (item["appearances"], item["outs"]), reverse=True),
        "fatigue_score": fatigue_score,
        "fatigue_level": "高" if fatigue_score >= 65 else "中" if fatigue_score >= 35 else "低",
        "basis": "NPB official box scores; reliever innings and batters faced",
    }


def parse_npb_probable_starters(
    page_html: str,
    target_date: date,
    source_url: str,
) -> dict[str, Any]:
    parser = _NPBStarterHtmlParser()
    parser.feed(page_html)
    tokens = parser.tokens
    year = target_date.year
    for token in tokens[:30]:
        if re.fullmatch(r"20\d{2}", token):
            year = int(token)
            break
    heading_index = -1
    announced_date: date | None = None
    for index, token in enumerate(tokens):
        match = STARTER_HEADING_RE.search(token)
        if not match:
            continue
        try:
            announced_date = date(year, int(match.group("month")), int(match.group("day")))
        except ValueError:
            announced_date = None
        heading_index = index
        break
    if heading_index < 0 or announced_date != target_date:
        return {"date": announced_date.isoformat() if announced_date else None, "by_team": {}, "source_url": source_url}

    by_team: dict[str, dict[str, Any]] = {}
    ignored = {
        "セントラル・リーグ", "パシフィック・リーグ", "侍ジャパン",
        "日本野球機構", "公示", "サブメニュー", "予告先発投手",
    }
    i = heading_index + 1
    while i < len(tokens):
        token = tokens[i]
        if token.startswith("Copyright"):
            break
        short = JAPANESE_TEAM_TO_SHORT.get(token)
        if not short:
            i += 1
            continue
        pitcher = ""
        j = i + 1
        while j < len(tokens):
            candidate = tokens[j].strip()
            if JAPANESE_TEAM_TO_SHORT.get(candidate):
                break
            if candidate.startswith("Copyright"):
                break
            if candidate in ignored or STARTER_HEADING_RE.search(candidate) or STARTER_VENUE_TIME_RE.match(candidate):
                j += 1
                continue
            if re.fullmatch(r"\d{1,2}:\d{2}", candidate) or candidate.startswith("Image:"):
                j += 1
                continue
            if len(candidate) <= 80:
                pitcher = candidate
                break
            j += 1
        if pitcher and short not in by_team:
            player_id = None
            for href, link_text in parser.links:
                if link_text.strip() != pitcher.strip():
                    continue
                id_match = re.search(r"/(?:eng/)?players/(?P<id>\d+)\.html", href or "")
                if id_match:
                    player_id = id_match.group("id")
                    break
            by_team[short] = {
                "name": pitcher,
                "player_id": player_id,
                "announced": True,
                "source": "NPB official probable starters",
                "source_url": source_url,
            }
        i += 1
    return {"date": announced_date.isoformat(), "by_team": by_team, "source_url": source_url}


def parse_npb_standings(page_html: str, source_url: str) -> dict[str, Any]:
    parser = _NPBHtmlParser()
    parser.feed(page_html)
    flattened = " ".join(parser.tokens)
    leagues: dict[str, list[dict[str, Any]]] = {"Central League": [], "Pacific League": []}
    by_team: dict[str, dict[str, Any]] = {}
    for match in STANDINGS_RE.finditer(flattened):
        raw_team = match.group("team")
        short = next((name for name in TEAM_NAMES if name.lower() == raw_team.lower()), None)
        if not short or short in by_team:
            continue
        league = "Central League" if short in CENTRAL_TEAMS else "Pacific League"
        row = {
            "team": short,
            "team_name": TEAM_BY_SHORT[short].canonical,
            "team_name_zh": TEAM_BY_SHORT[short].zh,
            "abbr": TEAM_BY_SHORT[short].abbr,
            "league": league,
            "games": int(match.group("games")),
            "wins": int(match.group("wins")),
            "losses": int(match.group("losses")),
            "ties": int(match.group("ties")),
            "pct": float(match.group("pct")),
            "pct_display": match.group("pct"),
            "games_back": match.group("gb"),
            "source_url": source_url,
        }
        leagues[league].append(row)
        by_team[short] = row
    for league_rows in leagues.values():
        for rank, row in enumerate(league_rows, start=1):
            row["rank"] = rank
    return {"leagues": leagues, "by_team": by_team, "source_url": source_url}



def _safe_float(value: Any) -> float | None:
    if value is None:
        return None
    text = str(value).strip().replace(",", "")
    if not text or text in {"-", "—", "---", "***"}:
        return None
    try:
        return float(text)
    except ValueError:
        return None


def _safe_int(value: Any) -> int | None:
    number = _safe_float(value)
    return int(number) if number is not None else None


def _innings_to_outs(value: Any) -> int | None:
    """Convert NPB innings notation to outs.

    Current Japanese live box scores sometimes render the fractional inning in
    a nested element, producing text such as ``5 .2`` or ``5 2/3`` after HTML
    parsing.  Accept those forms in addition to the conventional ``5.2``.
    """

    text = str(value or "").strip()
    text = text.translate(str.maketrans({"．": ".", "＋": "+", "⅓": " 1/3", "⅔": " 2/3"}))
    text = re.sub(r"\s+", " ", text).strip()
    if text in {"+", "0+", "0.0+"}:
        return 0

    fraction_match = re.fullmatch(r"(?P<whole>\d+)?\s*(?:\.|\+|\s)?\s*(?P<fraction>[12])(?:/3)?", text)
    if fraction_match and ("/3" in text or "." in text or " " in text or "+" in text):
        whole = int(fraction_match.group("whole") or 0)
        return whole * 3 + int(fraction_match.group("fraction"))

    compact = re.sub(r"\s+", "", text)
    number = _safe_float(compact)
    if number is None:
        return None
    whole = int(number)
    decimal = round((number - whole) * 10)
    if decimal not in {0, 1, 2}:
        return None
    return whole * 3 + decimal


def _outs_to_innings(outs: int) -> float:
    return round(outs / 3.0, 3)


def _player_id_from_cell(cell: dict[str, Any]) -> str | None:
    for link in cell.get("links") or []:
        match = re.search(r"/(?:eng/)?players/(?P<id>\d+)\.html", link.get("href") or "")
        if match:
            return match.group("id")
    return None


def _table_rows(page_html: str) -> list[list[dict[str, Any]]]:
    parser = _NPBTableParser()
    parser.feed(page_html)
    return parser.rows


def _find_header(rows: list[list[dict[str, Any]]], required: set[str]) -> tuple[int, list[str]] | None:
    for index, row in enumerate(rows):
        headers = [re.sub(r"\s+", " ", str(cell.get("text") or "")).strip() for cell in row]
        normalized = {header.upper() for header in headers}
        if required.issubset(normalized):
            return index, headers
    return None


def parse_npb_pitching_stats(page_html: str, source_url: str) -> dict[str, Any]:
    """Parse the official player-pitching table for one NPB club.

    The official English table columns are stable and include Pitcher, G, W, L,
    SV, CG, SHO, BF, IP, H, HR, BB, HB, SO, R, ER and ERA. WHIP and K/BB are
    calculated locally so the model can compare announced starters and relievers.
    """

    rows = _table_rows(page_html)
    header_info = _find_header(rows, {"PITCHER", "G", "IP", "ERA"})
    players: list[dict[str, Any]] = []
    if not header_info:
        return {"players": [], "by_id": {}, "by_name": {}, "source_url": source_url}
    header_index, headers = header_info
    header_keys = [header.upper().replace(" ", "") for header in headers]
    for row in rows[header_index + 1 :]:
        if len(row) < min(8, len(headers)):
            continue
        values = [str(cell.get("text") or "").strip() for cell in row]
        name = values[0] if values else ""
        if not name or name.upper() in {"PITCHER", "TOTAL"}:
            continue
        data: dict[str, Any] = {}
        for idx, key in enumerate(header_keys):
            if idx < len(values):
                data[key] = values[idx]
        games = _safe_int(data.get("G")) or 0
        outs = _innings_to_outs(data.get("IP"))
        hits = _safe_int(data.get("H")) or 0
        walks = _safe_int(data.get("BB")) or 0
        strikeouts = _safe_int(data.get("SO")) or 0
        earned_runs = _safe_int(data.get("ER")) or 0
        innings = _outs_to_innings(outs) if outs is not None else None
        whip = ((hits + walks) * 3 / outs) if outs and outs > 0 else None
        k_bb = strikeouts / walks if walks > 0 else (float(strikeouts) if strikeouts > 0 else None)
        era = _safe_float(data.get("ERA"))
        if era is None and outs and outs > 0:
            era = earned_runs * 27 / outs
        player = {
            "player_id": _player_id_from_cell(row[0]),
            "name": name,
            "games": games,
            "wins": _safe_int(data.get("W")) or 0,
            "losses": _safe_int(data.get("L")) or 0,
            "saves": _safe_int(data.get("SV")) or 0,
            "complete_games": _safe_int(data.get("CG")) or 0,
            "shutouts": _safe_int(data.get("SHO")) or 0,
            "batters_faced": _safe_int(data.get("BF")) or 0,
            "outs": outs,
            "innings": innings,
            "hits": hits,
            "home_runs": _safe_int(data.get("HR")) or 0,
            "walks": walks,
            "hit_batters": _safe_int(data.get("HB")) or 0,
            "strikeouts": strikeouts,
            "runs": _safe_int(data.get("R")) or 0,
            "earned_runs": earned_runs,
            "era": round(era, 2) if era is not None else None,
            "whip": round(whip, 3) if whip is not None else None,
            "k_bb": round(k_bb, 2) if k_bb is not None else None,
            "source_url": source_url,
        }
        player.update(_pitching_advanced(player))
        if games or outs:
            players.append(player)
    by_id = {item["player_id"]: item for item in players if item.get("player_id")}
    by_name = {re.sub(r"\s+", " ", item["name"]).strip().lower(): item for item in players}
    return {"players": players, "by_id": by_id, "by_name": by_name, "source_url": source_url}



def parse_npb_player_pitching_profile(page_html: str, season: int, source_url: str) -> dict[str, Any] | None:
    """Parse one player's official Japanese career table for the requested season."""

    rows = _table_rows(page_html)
    required = {"年度", "登板", "投球回", "防御率"}
    header_info: tuple[int, list[str]] | None = None
    for index, row in enumerate(rows):
        headers = [str(cell.get("text") or "").strip() for cell in row]
        if required.issubset(set(headers)):
            header_info = index, headers
            break
    if not header_info:
        return None
    header_index, headers = header_info
    for row in rows[header_index + 1 :]:
        values = [str(cell.get("text") or "").strip() for cell in row]
        if not values or values[0] != str(season):
            continue
        data = {headers[idx]: values[idx] for idx in range(min(len(headers), len(values)))}
        outs = _innings_to_outs(data.get("投球回"))
        hits = _safe_int(data.get("安打")) or 0
        walks = _safe_int(data.get("四球")) or 0
        strikeouts = _safe_int(data.get("三振")) or 0
        earned_runs = _safe_int(data.get("自責点")) or 0
        era = _safe_float(data.get("防御率"))
        if era is None and outs:
            era = earned_runs * 27 / outs
        whip = (hits + walks) * 3 / outs if outs else None
        k_bb = strikeouts / walks if walks else (float(strikeouts) if strikeouts else None)
        return {
            "player_id": None,
            "name": "",
            "games": _safe_int(data.get("登板")) or 0,
            "wins": _safe_int(data.get("勝利")) or 0,
            "losses": _safe_int(data.get("敗北")) or 0,
            "saves": _safe_int(data.get("セーブ")) or 0,
            "complete_games": _safe_int(data.get("完投")) or 0,
            "shutouts": _safe_int(data.get("完封勝")) or 0,
            "batters_faced": _safe_int(data.get("打者")) or 0,
            "outs": outs,
            "innings": _outs_to_innings(outs) if outs is not None else None,
            "hits": hits,
            "home_runs": _safe_int(data.get("本塁打")) or 0,
            "walks": walks,
            "hit_batters": _safe_int(data.get("死球")) or 0,
            "strikeouts": strikeouts,
            "runs": _safe_int(data.get("失点")) or 0,
            "earned_runs": earned_runs,
            "era": round(era, 2) if era is not None else None,
            "whip": round(whip, 3) if whip is not None else None,
            "k_bb": round(k_bb, 2) if k_bb is not None else None,
            "source_url": source_url,
            **_pitching_advanced({
                "outs": outs, "batters_faced": _safe_int(data.get("打者")) or 0,
                "strikeouts": strikeouts, "walks": walks,
                "hit_batters": _safe_int(data.get("死球")) or 0,
                "home_runs": _safe_int(data.get("本塁打")) or 0,
            }),
        }
    return None


def parse_npb_batting_stats(page_html: str, source_url: str) -> dict[str, Any]:
    """Parse official NPB club batting rows and calculate advanced rate stats."""

    rows = _table_rows(page_html)
    header_info = _find_header(rows, {"BATTER", "AB", "H", "SLG", "OBP"})
    totals = {
        "games": 0,
        "plate_appearances": 0,
        "at_bats": 0,
        "runs": 0,
        "hits": 0,
        "doubles": 0,
        "triples": 0,
        "home_runs": 0,
        "total_bases": 0,
        "rbi": 0,
        "walks": 0,
        "intentional_walks": 0,
        "hit_by_pitch": 0,
        "sac_flies": 0,
        "strikeouts": 0,
    }
    players: list[dict[str, Any]] = []
    if not header_info:
        return {**totals, "avg": None, "obp": None, "slg": None, "ops": None, "iso": None, "k_pct": None, "bb_pct": None, "players": [], "by_id": {}, "by_name": {}, "source_url": source_url}
    header_index, headers = header_info
    header_keys = [header.upper().replace(" ", "") for header in headers]
    for row in rows[header_index + 1 :]:
        values = [str(cell.get("text") or "").strip() for cell in row]
        if not values or values[0].upper() in {"BATTER", "TOTAL"}:
            continue
        data = {key: values[idx] for idx, key in enumerate(header_keys) if idx < len(values)}
        at_bats = _safe_int(data.get("AB")) or 0
        plate_appearances = _safe_int(data.get("PA")) or 0
        if at_bats == 0 and plate_appearances == 0:
            continue
        hits = _safe_int(data.get("H")) or 0
        doubles = _safe_int(data.get("2B")) or 0
        triples = _safe_int(data.get("3B")) or 0
        home_runs = _safe_int(data.get("HR")) or 0
        total_bases = _safe_int(data.get("TB"))
        if total_bases is None:
            singles = max(0, hits - doubles - triples - home_runs)
            total_bases = singles + doubles * 2 + triples * 3 + home_runs * 4
        walks = _safe_int(data.get("BB")) or 0
        hbp = _safe_int(data.get("HP")) or _safe_int(data.get("HBP")) or 0
        sf = _safe_int(data.get("SF")) or 0
        strikeouts = _safe_int(data.get("SO")) or 0
        avg = _safe_float(data.get("AVG"))
        slg = _safe_float(data.get("SLG"))
        obp = _safe_float(data.get("OBP"))
        if avg is None and at_bats:
            avg = hits / at_bats
        if slg is None and at_bats:
            slg = total_bases / at_bats
        obp_denom = at_bats + walks + hbp + sf
        if obp is None and obp_denom:
            obp = (hits + walks + hbp) / obp_denom
        ops = obp + slg if obp is not None and slg is not None else None
        player = {
            "player_id": _player_id_from_cell(row[0]),
            "name": values[0],
            "games": _safe_int(data.get("G")) or 0,
            "plate_appearances": plate_appearances,
            "at_bats": at_bats,
            "runs": _safe_int(data.get("R")) or 0,
            "hits": hits,
            "doubles": doubles,
            "triples": triples,
            "home_runs": home_runs,
            "total_bases": total_bases,
            "rbi": _safe_int(data.get("RBI")) or 0,
            "walks": walks,
            "hit_by_pitch": hbp,
            "sac_flies": sf,
            "strikeouts": strikeouts,
            "avg": round(avg, 3) if avg is not None else None,
            "obp": round(obp, 3) if obp is not None else None,
            "slg": round(slg, 3) if slg is not None else None,
            "ops": round(ops, 3) if ops is not None else None,
            "iso": round(slg - avg, 3) if slg is not None and avg is not None else None,
            "k_pct": round(strikeouts / plate_appearances, 3) if plate_appearances else None,
            "bb_pct": round(walks / plate_appearances, 3) if plate_appearances else None,
            "source_url": source_url,
        }
        players.append(player)
        totals["games"] = max(totals["games"], player["games"])
        for key in ("plate_appearances", "at_bats", "runs", "hits", "doubles", "triples", "home_runs", "total_bases", "rbi", "walks", "hit_by_pitch", "sac_flies", "strikeouts"):
            totals[key] += int(player.get(key) or 0)
        totals["intentional_walks"] += _safe_int(data.get("IBB")) or 0
    ab = totals["at_bats"]
    hits = totals["hits"]
    tb = totals["total_bases"]
    walks = totals["walks"]
    hbp = totals["hit_by_pitch"]
    sf = totals["sac_flies"]
    pa = totals["plate_appearances"]
    avg = hits / ab if ab else None
    slg = tb / ab if ab else None
    obp_denom = ab + walks + hbp + sf
    obp = (hits + walks + hbp) / obp_denom if obp_denom else None
    ops = obp + slg if obp is not None and slg is not None else None
    by_id = {item["player_id"]: item for item in players if item.get("player_id")}
    by_name = {_normalized_player_name(item["name"]): item for item in players}
    return {
        **totals,
        "avg": round(avg, 3) if avg is not None else None,
        "obp": round(obp, 3) if obp is not None else None,
        "slg": round(slg, 3) if slg is not None else None,
        "ops": round(ops, 3) if ops is not None else None,
        "iso": round(slg - avg, 3) if slg is not None and avg is not None else None,
        "k_pct": round(totals["strikeouts"] / pa, 3) if pa else None,
        "bb_pct": round(walks / pa, 3) if pa else None,
        "players": players,
        "by_id": by_id,
        "by_name": by_name,
        "source_url": source_url,
    }


def aggregate_npb_bullpen(pitching: dict[str, Any]) -> dict[str, Any]:
    """Build a conservative bullpen proxy from official pitcher season totals."""

    candidates: list[dict[str, Any]] = []
    for player in pitching.get("players") or []:
        games = int(player.get("games") or 0)
        outs = int(player.get("outs") or 0)
        innings_per_game = (outs / 3) / games if games else 99.0
        if games >= 5 and int(player.get("complete_games") or 0) == 0 and innings_per_game <= 2.2:
            candidates.append(player)
    if not candidates:
        return {"available": False, "pitchers": 0, "era": None, "whip": None, "k_bb": None}
    outs = sum(int(item.get("outs") or 0) for item in candidates)
    hits = sum(int(item.get("hits") or 0) for item in candidates)
    walks = sum(int(item.get("walks") or 0) for item in candidates)
    strikeouts = sum(int(item.get("strikeouts") or 0) for item in candidates)
    earned_runs = sum(int(item.get("earned_runs") or 0) for item in candidates)
    era = earned_runs * 27 / outs if outs else None
    whip = (hits + walks) * 3 / outs if outs else None
    k_bb = strikeouts / walks if walks else (float(strikeouts) if strikeouts else None)
    return {
        "available": bool(outs),
        "pitchers": len(candidates),
        "innings": _outs_to_innings(outs),
        "era": round(era, 2) if era is not None else None,
        "whip": round(whip, 3) if whip is not None else None,
        "k_bb": round(k_bb, 2) if k_bb is not None else None,
        "saves": sum(int(item.get("saves") or 0) for item in candidates),
    }


def parse_npb_month_scoreboard(page_html: str, season: int, source_url: str) -> list[dict[str, Any]]:
    """Parse every final/postponed game listed on an official monthly schedule page."""

    parser = _NPBHtmlParser()
    parser.feed(page_html)
    games: list[dict[str, Any]] = []
    seen: set[str] = set()
    for href, label in parser.links:
        match = JAPANESE_SCORE_HREF_RE.search(href or "")
        if not match or int(match.group("year")) != season:
            continue
        try:
            game_date = date(season, int(match.group("mmdd")[:2]), int(match.group("mmdd")[2:]))
        except ValueError:
            continue
        home = URL_CODE_TO_SHORT.get(match.group("home").lower())
        away = URL_CODE_TO_SHORT.get(match.group("away").lower())
        if not home or not away:
            continue
        game_id = _stable_game_id(game_date, away, home)
        if game_id in seen:
            continue
        cleaned = re.sub(r"\s+", " ", label or "").strip()
        score_match = JAPANESE_SCORE_RE.search(cleaned)
        status = "final" if "試合終了" in cleaned else "postponed" if any(word in cleaned for word in ("中止", "雨天中止", "延期")) else ""
        if not status:
            continue
        games.append(
            {
                "game_pk": game_id,
                "date": game_date.isoformat(),
                "away": away,
                "home": home,
                "away_score": int(score_match.group("away_score")) if score_match else None,
                "home_score": int(score_match.group("home_score")) if score_match else None,
                "status": status,
                "source_url": urljoin(source_url, href),
            }
        )
        seen.add(game_id)
    return games


def npb_team_form(team: str, games: list[dict[str, Any]]) -> dict[str, Any]:
    finals = [game for game in games if game.get("status") == "final" and team in {game.get("away"), game.get("home")}]
    finals.sort(key=lambda item: (item.get("date") or "", item.get("game_pk") or ""))
    wins = losses = ties = runs_for = runs_against = 0
    home_w = home_l = home_t = road_w = road_l = road_t = 0
    results: list[dict[str, Any]] = []
    for game in finals:
        is_home = game.get("home") == team
        team_score = game.get("home_score") if is_home else game.get("away_score")
        opponent_score = game.get("away_score") if is_home else game.get("home_score")
        if team_score is None or opponent_score is None:
            continue
        runs_for += int(team_score)
        runs_against += int(opponent_score)
        if team_score > opponent_score:
            result = "W"
            wins += 1
            if is_home:
                home_w += 1
            else:
                road_w += 1
        elif team_score < opponent_score:
            result = "L"
            losses += 1
            if is_home:
                home_l += 1
            else:
                road_l += 1
        else:
            result = "T"
            ties += 1
            if is_home:
                home_t += 1
            else:
                road_t += 1
        results.append({"date": game.get("date"), "result": result, "runs_for": team_score, "runs_against": opponent_score, "home": is_home})
    recent = results[-10:]
    recent_w = sum(item["result"] == "W" for item in recent)
    recent_l = sum(item["result"] == "L" for item in recent)
    recent_t = sum(item["result"] == "T" for item in recent)
    decisions = wins + losses
    recent_decisions = recent_w + recent_l
    games_count = len(results)
    exponent = 1.83
    rf_power = math.pow(max(runs_for, 0), exponent)
    ra_power = math.pow(max(runs_against, 0), exponent)
    pyth = rf_power / (rf_power + ra_power) if rf_power + ra_power else None
    return {
        "games": games_count,
        "wins": wins,
        "losses": losses,
        "ties": ties,
        "winning_pct": round(wins / decisions, 3) if decisions else None,
        "runs_for": runs_for,
        "runs_against": runs_against,
        "run_diff": runs_for - runs_against,
        "runs_per_game": round(runs_for / games_count, 2) if games_count else None,
        "runs_allowed_per_game": round(runs_against / games_count, 2) if games_count else None,
        "pythagorean_pct": round(pyth, 3) if pyth is not None else None,
        "home": {"wins": home_w, "losses": home_l, "ties": home_t, "pct": round(home_w / (home_w + home_l), 3) if home_w + home_l else None},
        "road": {"wins": road_w, "losses": road_l, "ties": road_t, "pct": round(road_w / (road_w + road_l), 3) if road_w + road_l else None},
        "recent_10": {
            "wins": recent_w,
            "losses": recent_l,
            "ties": recent_t,
            "pct": round(recent_w / recent_decisions, 3) if recent_decisions else None,
            "runs_per_game": round(sum(int(item["runs_for"]) for item in recent) / len(recent), 2) if recent else None,
            "runs_allowed_per_game": round(sum(int(item["runs_against"]) for item in recent) / len(recent), 2) if recent else None,
            "results": recent,
        },
    }


def _clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def _normalized_advantage(home: Any, away: Any, scale: float, *, lower_is_better: bool = False) -> float | None:
    home_value = _safe_float(home)
    away_value = _safe_float(away)
    if home_value is None or away_value is None or scale <= 0:
        return None
    raw = (away_value - home_value) / scale if lower_is_better else (home_value - away_value) / scale
    return _clamp(raw, -1.0, 1.0)


def _weighted_advantage(metrics: list[tuple[str, Any, Any, float, bool, float]]) -> dict[str, Any]:
    weighted = 0.0
    used = 0.0
    rows: list[dict[str, Any]] = []
    total_weight = sum(item[5] for item in metrics) or 1.0
    for label, away, home, scale, lower_is_better, weight in metrics:
        edge = _normalized_advantage(home, away, scale, lower_is_better=lower_is_better)
        available = edge is not None
        if available:
            weighted += edge * weight
            used += weight
        rows.append({"label": label, "away": away, "home": home, "available": available, "edge_home": round(edge, 3) if edge is not None else None})
    return {
        "edge_home": round(weighted / used, 3) if used else None,
        "quality": round(used / total_weight, 2),
        "metrics": rows,
        "available": bool(used),
    }


def build_npb_analysis(
    game: dict[str, Any],
    away_form: dict[str, Any],
    home_form: dict[str, Any],
    away_batting: dict[str, Any],
    home_batting: dict[str, Any],
    away_pitching: dict[str, Any],
    home_pitching: dict[str, Any],
    *,
    lineups: dict[str, Any] | None = None,
    starter_recent: dict[str, Any] | None = None,
    bullpen_usage: dict[str, Any] | None = None,
    roster_status: dict[str, Any] | None = None,
    environment: dict[str, Any] | None = None,
) -> dict[str, Any]:
    away_team = game.get("away") or {}
    home_team = game.get("home") or {}
    away_starter_info = away_team.get("probable_pitcher") or {}
    home_starter_info = home_team.get("probable_pitcher") or {}
    lineups = lineups or {"away": {}, "home": {}}
    starter_recent = starter_recent or {"away": {}, "home": {}}
    bullpen_usage = bullpen_usage or {"away": {}, "home": {}}
    roster_status = roster_status or {"away": {}, "home": {}}
    environment = environment or {}

    def starter_stats(info: dict[str, Any], pitching: dict[str, Any]) -> dict[str, Any] | None:
        player_id = str(info.get("player_id") or "")
        if player_id and player_id in (pitching.get("by_id") or {}):
            return (pitching.get("by_id") or {})[player_id]
        name = re.sub(r"\s+", " ", str(info.get("name") or "")).strip().lower()
        direct = (pitching.get("by_name") or {}).get(name)
        if direct:
            return direct
        normalized = _normalized_player_name(info.get("name") or "")
        return next((item for item in pitching.get("players") or [] if _normalized_player_name(item.get("name") or "") == normalized), None)

    away_starter = starter_stats(away_starter_info, away_pitching)
    home_starter = starter_stats(home_starter_info, home_pitching)
    away_bullpen = aggregate_npb_bullpen(away_pitching)
    home_bullpen = aggregate_npb_bullpen(home_pitching)
    away_lineup_profile = aggregate_npb_lineup(lineups.get("away") or {}, away_batting)
    home_lineup_profile = aggregate_npb_lineup(lineups.get("home") or {}, home_batting)
    away_batting_adv = _batting_advanced(away_batting)
    home_batting_adv = _batting_advanced(home_batting)
    away_pitching_adv = _pitching_advanced(away_starter)
    home_pitching_adv = _pitching_advanced(home_starter)

    away_record = away_team.get("record") or {}
    home_record = home_team.get("record") or {}
    team_group = _weighted_advantage([
        ("畢氏預期勝率", away_form.get("pythagorean_pct"), home_form.get("pythagorean_pct"), 0.18, False, 0.30),
        ("官方戰績勝率", away_record.get("pct"), home_record.get("pct"), 0.18, False, 0.25),
        ("近十場勝率", (away_form.get("recent_10") or {}).get("pct"), (home_form.get("recent_10") or {}).get("pct"), 0.35, False, 0.25),
        ("本場主客場勝率", (away_form.get("road") or {}).get("pct"), (home_form.get("home") or {}).get("pct"), 0.30, False, 0.20),
    ])
    team_group.update({"label": "球隊實力", "note": "官方戰績、得失分、畢氏預期勝率、近十場與主客場"})

    starter_group = _weighted_advantage([
        ("球季 ERA", (away_starter or {}).get("era"), (home_starter or {}).get("era"), 3.0, True, 0.25),
        ("球季 WHIP", (away_starter or {}).get("whip"), (home_starter or {}).get("whip"), 0.65, True, 0.16),
        ("球季 K/BB", (away_starter or {}).get("k_bb"), (home_starter or {}).get("k_bb"), 3.5, False, 0.14),
        ("近三場 ERA", (starter_recent.get("away") or {}).get("era"), (starter_recent.get("home") or {}).get("era"), 3.5, True, 0.20),
        ("近三場 WHIP", (starter_recent.get("away") or {}).get("whip"), (starter_recent.get("home") or {}).get("whip"), 0.75, True, 0.13),
        ("FIP估算", away_pitching_adv.get("fip_estimate"), home_pitching_adv.get("fip_estimate"), 3.0, True, 0.12),
    ])
    starter_group.update({
        "label": "先發投手",
        "note": "NPB 官方球季數據＋最近三次先發；FIP、K%與BB%由官方累計數據計算",
        "away_pitcher": {**away_starter_info, "stats": away_starter, "recent_3": starter_recent.get("away") or {}, "advanced": away_pitching_adv},
        "home_pitcher": {**home_starter_info, "stats": home_starter, "recent_3": starter_recent.get("home") or {}, "advanced": home_pitching_adv},
        "both_starters_ready": bool(away_starter and home_starter),
    })

    away_ops = away_lineup_profile.get("ops") if away_lineup_profile.get("available") else away_batting.get("ops")
    home_ops = home_lineup_profile.get("ops") if home_lineup_profile.get("available") else home_batting.get("ops")
    away_iso = away_lineup_profile.get("iso") if away_lineup_profile.get("available") else away_batting_adv.get("iso")
    home_iso = home_lineup_profile.get("iso") if home_lineup_profile.get("available") else home_batting_adv.get("iso")
    away_k_pct = away_lineup_profile.get("k_pct") if away_lineup_profile.get("available") else away_batting_adv.get("k_pct")
    home_k_pct = home_lineup_profile.get("k_pct") if home_lineup_profile.get("available") else home_batting_adv.get("k_pct")
    away_bb_pct = away_lineup_profile.get("bb_pct") if away_lineup_profile.get("available") else away_batting_adv.get("bb_pct")
    home_bb_pct = home_lineup_profile.get("bb_pct") if home_lineup_profile.get("available") else home_batting_adv.get("bb_pct")
    offense_group = _weighted_advantage([
        ("正式打線 OPS", away_ops, home_ops, 0.18, False, 0.34),
        ("ISO 長打率差", away_iso, home_iso, 0.10, False, 0.18),
        ("打線 K%", away_k_pct, home_k_pct, 0.10, True, 0.12),
        ("打線 BB%", away_bb_pct, home_bb_pct, 0.08, False, 0.10),
        ("球季場均得分", away_form.get("runs_per_game"), home_form.get("runs_per_game"), 2.2, False, 0.13),
        ("近十場場均得分", (away_form.get("recent_10") or {}).get("runs_per_game"), (home_form.get("recent_10") or {}).get("runs_per_game"), 2.5, False, 0.13),
    ])
    official_lineups = bool((lineups.get("away") or {}).get("official") and (lineups.get("home") or {}).get("official"))
    offense_group.update({
        "label": "正式先發打線",
        "note": "已公布時採用第1至9棒逐棒名單與球員球季數據；未公布時退回球隊球季基準",
        "away_lineup": {**(lineups.get("away") or {}), "aggregate": away_lineup_profile},
        "home_lineup": {**(lineups.get("home") or {}), "aggregate": home_lineup_profile},
        "official_lineups_ready": official_lineups,
    })

    bullpen_group = _weighted_advantage([
        ("牛棚 ERA", away_bullpen.get("era"), home_bullpen.get("era"), 3.2, True, 0.30),
        ("牛棚 WHIP", away_bullpen.get("whip"), home_bullpen.get("whip"), 0.70, True, 0.18),
        ("牛棚 K/BB", away_bullpen.get("k_bb"), home_bullpen.get("k_bb"), 3.2, False, 0.17),
        ("近3日後援局數", (bullpen_usage.get("away") or {}).get("innings"), (bullpen_usage.get("home") or {}).get("innings"), 8.0, True, 0.15),
        ("近3日面對打者", (bullpen_usage.get("away") or {}).get("batters_faced"), (bullpen_usage.get("home") or {}).get("batters_faced"), 35.0, True, 0.10),
        ("牛棚疲勞分數", (bullpen_usage.get("away") or {}).get("fatigue_score"), (bullpen_usage.get("home") or {}).get("fatigue_score"), 60.0, True, 0.10),
    ])
    bullpen_group.update({
        "label": "牛棚近三日用量",
        "note": "球季後援品質加上最近3日官方 box score 的後援局數、BF、連投與重度使用",
        "away": {**away_bullpen, "recent_3_days": bullpen_usage.get("away") or {}},
        "home": {**home_bullpen, "recent_3_days": bullpen_usage.get("home") or {}},
    })

    availability_group = _weighted_advantage([
        ("近7日註冊人數", len((roster_status.get("away") or {}).get("registered") or []), len((roster_status.get("home") or {}).get("registered") or []), 4.0, False, 0.35),
        ("近7日抹消人數", len((roster_status.get("away") or {}).get("deregistered") or []), len((roster_status.get("home") or {}).get("deregistered") or []), 4.0, True, 0.65),
    ])
    availability_group.update({
        "label": "登錄異動與缺陣",
        "note": "NPB 官方只公告一軍註冊／抹消，不公開統一傷病原因；抹消球員視為本場不可用，不猜測傷勢",
        "away": roster_status.get("away") or {},
        "home": roster_status.get("home") or {},
    })

    env_adjustment = environment.get("run_environment") or {}
    environment_group = {
        "label": "球場與天氣",
        "note": "球場屋頂、溫度、降雨、風速與風向；固定巨蛋不套用戶外天氣權重",
        "edge_home": 0.0,
        "quality": float(env_adjustment.get("quality") or 0.55),
        "available": bool((environment.get("venue") or {}).get("available")),
        "metrics": [
            {"label": "溫度 °C", "away": (environment.get("weather") or {}).get("temperature_c"), "home": (environment.get("weather") or {}).get("temperature_c"), "available": bool((environment.get("weather") or {}).get("available")), "edge_home": 0.0},
            {"label": "風速 mph", "away": (environment.get("weather") or {}).get("wind_speed_mph"), "home": (environment.get("weather") or {}).get("wind_speed_mph"), "available": bool((environment.get("weather") or {}).get("available")), "edge_home": 0.0},
            {"label": "降雨機率 %", "away": (environment.get("weather") or {}).get("precipitation_probability_pct"), "home": (environment.get("weather") or {}).get("precipitation_probability_pct"), "available": bool((environment.get("weather") or {}).get("available")), "edge_home": 0.0},
        ],
        **environment,
    }

    advanced_group = _weighted_advantage([
        ("打線 ISO", away_iso, home_iso, 0.10, False, 0.24),
        ("打線 K%", away_k_pct, home_k_pct, 0.10, True, 0.16),
        ("打線 BB%", away_bb_pct, home_bb_pct, 0.08, False, 0.14),
        ("先發 FIP估算", away_pitching_adv.get("fip_estimate"), home_pitching_adv.get("fip_estimate"), 3.0, True, 0.24),
        ("先發 K%", away_pitching_adv.get("k_pct"), home_pitching_adv.get("k_pct"), 0.12, False, 0.12),
        ("先發 BB%", away_pitching_adv.get("bb_pct"), home_pitching_adv.get("bb_pct"), 0.08, True, 0.10),
    ])
    advanced_group.update({
        "label": "NPB 進階數據",
        "note": "ISO、K%、BB%與FIP由 NPB 官方累計欄位計算；不是 Statcast，不顯示不存在的 xERA/xwOBA",
        "away": {"batting": away_batting_adv, "starter": away_pitching_adv},
        "home": {"batting": home_batting_adv, "starter": home_pitching_adv},
    })

    groups = {
        "team": team_group,
        "starter": starter_group,
        "offense": offense_group,
        "bullpen": bullpen_group,
        "availability": availability_group,
        "environment": environment_group,
        "advanced": advanced_group,
    }
    starter_names_ready = all(
        str(info.get("name") or "").strip() not in {"", "尚未公布"}
        for info in (away_starter_info, home_starter_info)
    )
    starter_stats_ready = bool(starter_group.get("both_starters_ready"))
    full_starter_model = bool(starter_names_ready and starter_stats_ready)
    model_stage = "full" if full_starter_model else "base"

    # NPB probable starters are often published later than the schedule.  The
    # old model assigned 28% to starters and then blocked the whole matchup
    # whenever either pitcher was unavailable.  The staged model instead uses
    # a team/offense/bullpen baseline and redistributes the starter weight until
    # both official pitcher profiles can be matched.
    weights = (
        {"team": 0.22, "starter": 0.28, "offense": 0.22, "bullpen": 0.14, "availability": 0.06, "advanced": 0.08}
        if full_starter_model
        else {"team": 0.30, "starter": 0.00, "offense": 0.27, "bullpen": 0.22, "availability": 0.09, "advanced": 0.12}
    )
    weighted_edge = 0.0
    used_weight = 0.0
    quality_weight = 0.0
    for key, weight in weights.items():
        group = groups[key]
        edge = group.get("edge_home")
        quality = float(group.get("quality") or 0)
        quality_weight += quality * weight
        if edge is not None:
            weighted_edge += float(edge) * weight
            used_weight += weight
    normalized_edge = weighted_edge / used_weight if used_weight else 0.0
    home_probability = _clamp(50.0 + normalized_edge * 18.0 + 1.8, 35.0, 65.0)
    confidence_cap = 65.0 if full_starter_model else 59.5
    if not full_starter_model:
        # Missing starters lower certainty; they must never make the baseline
        # model look more confident than the starter-confirmed model.
        home_probability = _clamp(home_probability, 100.0 - confidence_cap, confidence_cap)
    away_probability = 100.0 - home_probability
    home_pick = home_probability >= 50.0
    confidence = max(home_probability, away_probability)
    data_quality = _clamp(quality_weight, 0.0, 1.0)

    away_rpg = _safe_float(away_form.get("runs_per_game")) or 3.6
    home_rpg = _safe_float(home_form.get("runs_per_game")) or 3.6
    away_ra = _safe_float(away_form.get("runs_allowed_per_game")) or 3.6
    home_ra = _safe_float(home_form.get("runs_allowed_per_game")) or 3.6
    raw_total = (away_rpg + home_ra + home_rpg + away_ra) / 2.0
    projected_total = _clamp(raw_total + float(env_adjustment.get("run_adjustment") or 0.0), 4.5, 11.5)
    home_share = home_probability / 100.0
    projected_home_runs = projected_total * home_share
    projected_away_runs = projected_total - projected_home_runs
    projected_margin = projected_home_runs - projected_away_runs
    projection_quality = _clamp(
        data_quality * (1.0 if starter_group.get("both_starters_ready") else 0.82) * (1.0 if official_lineups else 0.92),
        0.0,
        1.0,
    )
    home_score = max(1, round(projected_home_runs))
    away_score = max(1, round(projected_away_runs))
    if home_score == away_score:
        if home_pick:
            home_score += 1
        else:
            away_score += 1

    # NPB source coverage is uneven and probable starters/lineups are often
    # published late.  Missing enrichment data therefore lowers confidence and
    # remains visible in ``data_quality``/``missing_core``, but it must not turn
    # an otherwise valid, unstarted matchup into an analysis-only item.
    pick_direction_ready = bool(
        (game.get("game_pk") or game.get("external_game_id"))
        and (away_team.get("name") or away_team.get("abbr"))
        and (home_team.get("name") or home_team.get("abbr"))
    )
    base_modules_ready = bool(team_group.get("available") and offense_group.get("available"))
    base_recommendation_ready = pick_direction_ready
    # This flag describes model completeness only.  Publication policy no longer
    # treats it as a hard gate for NPB.
    full_market_ready = bool(full_starter_model)
    recommendation_ready = pick_direction_ready
    effective_weights = {
        key: round(weight / used_weight, 4)
        for key, weight in weights.items()
        if weight > 0 and groups[key].get("edge_home") is not None and used_weight > 0
    }
    engine_weights = {
        "team_strength": round(weights.get("team", 0.0) + weights.get("availability", 0.0), 4),
        "starter": round(weights.get("starter", 0.0), 4),
        "lineup": round(weights.get("offense", 0.0), 4),
        "bullpen": round(weights.get("bullpen", 0.0), 4),
        "advanced": round(weights.get("advanced", 0.0), 4),
        "environment": 0.0,
    }
    used_modules = [
        "官方戰績／畢氏勝率／近十場",
        "先發投手球季數據與近三場" if starter_stats_ready else "球隊投手基準（先發資料不足）",
        "正式第1～9棒" if official_lineups else "球隊球季打擊基準（正式打線未公布）",
        "牛棚球季品質與近三日用量",
        "一軍登錄異動",
        "球場與天氣",
        "ISO／K%／BB%／FIP估算",
    ]
    missing_core = []
    if not starter_names_ready:
        missing_core.append("先發投手姓名")
    if not starter_stats_ready:
        missing_core.append("先發投手可配對數據")
    if not official_lineups:
        missing_core.append("正式先發打線")

    return {
        "league": "NPB",
        "model_version": "dm-npb-staged-v4.0",
        "model_stage": model_stage,
        "status": (
            "prediction_markets"
            if full_market_ready
            else "prediction_moneyline"
            if base_recommendation_ready
            else "analysis_only"
        ),
        "official_recommendation_enabled": recommendation_ready,
        "full_market_recommendation_enabled": full_market_ready,
        "message": (
            "NPB 完整模型已就緒，可評估獨贏、讓分與大小分。"
            if full_market_ready
            else "NPB 可用模型已就緒；缺少先發、打線或進階資料時會降低信心並顯示警告，但不阻擋推薦。"
            if base_recommendation_ready
            else "目前缺少有效賽事或推薦方向，暫時無法建立新推薦。"
        ),
        "data_basis": {
            "model_stage": model_stage,
            "base_modules_ready": base_modules_ready,
            "pick_direction_ready": pick_direction_ready,
            "base_recommendation_ready": base_recommendation_ready,
            "full_market_ready": full_market_ready,
            "starter_names_ready": starter_names_ready,
            "starter_stats_ready": starter_stats_ready,
            "official_lineups_ready": official_lineups,
            "recommendation_ready": recommendation_ready,
            "used_modules": used_modules,
            "missing_core": missing_core,
            "data_quality": round(data_quality, 2),
        },
        "model_weights": {
            "configured": {key: round(value, 4) for key, value in weights.items()},
            "effective": effective_weights,
            "engine": engine_weights,
            "redistributed_for_missing_starters": not full_starter_model,
        },
        "confidence_cap": confidence_cap,
        "pick": {
            "side": "home" if home_pick else "away",
            "team": home_team.get("name") if home_pick else away_team.get("name"),
            "team_name_zh": home_team.get("name_zh") if home_pick else away_team.get("name_zh"),
            "label": f"{home_team.get('abbr') if home_pick else away_team.get('abbr')} 獨贏觀察",
        },
        "home_probability": round(home_probability, 1),
        "away_probability": round(away_probability, 1),
        "confidence": round(confidence, 1),
        "data_quality": round(data_quality, 2),
        "projections": {
            "away_runs": round(projected_away_runs, 2),
            "home_runs": round(projected_home_runs, 2),
            "total_runs": round(projected_total, 2),
            "base_total_runs": round(raw_total, 2),
            "environment_adjustment": round(float(env_adjustment.get("run_adjustment") or 0.0), 2),
            "home_margin": round(projected_margin, 2),
            "quality": round(projection_quality, 2),
            "score": {"away": away_score, "home": home_score},
        },
        "analysis_groups": groups,
        "lineups": lineups,
        "bullpen_usage": bullpen_usage,
        "roster_status": roster_status,
        "environment": environment,
        "team_profiles": {
            "away": {"form": away_form, "batting": away_batting, "bullpen": away_bullpen, "lineup": away_lineup_profile},
            "home": {"form": home_form, "batting": home_batting, "bullpen": home_bullpen, "lineup": home_lineup_profile},
        },
    }


def _apply_probable_starters(items: list[dict[str, Any]], starter_data: dict[str, Any]) -> None:
    by_team = starter_data.get("by_team") or {}
    for game in items:
        for side in ("away", "home"):
            team = game.get(side) or {}
            short = team.get("short_name")
            starter = by_team.get(short)
            if starter:
                team["probable_pitcher"] = {"id": None, **starter}


def _apply_standings(items: list[dict[str, Any]], standings_data: dict[str, Any]) -> None:
    by_team = standings_data.get("by_team") or {}
    for game in items:
        for side in ("away", "home"):
            team = game.get(side) or {}
            short = team.get("short_name")
            record = by_team.get(short)
            if record:
                team["record"] = {key: value for key, value in record.items() if key != "source_url"}


def _iso_timestamp(epoch: float) -> str:
    return datetime.fromtimestamp(epoch, tz=TAIPEI).isoformat()


def _team_payload(short_name: str, score: int | None = None) -> dict[str, Any]:
    team = TEAM_BY_SHORT[short_name]
    return {
        "id": team.abbr,
        "name": team.canonical,
        "short_name": team.short,
        "name_zh": team.zh,
        "abbr": team.abbr,
        "score": score,
        "probable_pitcher": {"id": None, "name": "尚未公布"},
    }


def _stable_game_id(target_date: date, away: str, home: str) -> str:
    return f"npb_{target_date:%Y%m%d}_{TEAM_BY_SHORT[away].abbr}_{TEAM_BY_SHORT[home].abbr}"


def _start_datetime(target_date: date, japan_time: str | None) -> datetime | None:
    if not japan_time or not TIME_RE.match(japan_time):
        return None
    hour, minute = map(int, japan_time.split(":"))
    return datetime.combine(target_date, time(hour, minute), tzinfo=TOKYO)


def _status_from_schedule(start: datetime | None, now: datetime) -> tuple[str, str]:
    if start is None:
        return "upcoming", "Scheduled"
    now_tokyo = now.astimezone(TOKYO)
    if now_tokyo < start:
        return "upcoming", "Scheduled"
    if now_tokyo <= start + timedelta(hours=5):
        return "live", "In Progress"
    return "upcoming", "Awaiting official result"


def _game_payload(
    target_date: date,
    away: str,
    home: str,
    *,
    venue: str = "",
    japan_time: str | None = None,
    away_score: int | None = None,
    home_score: int | None = None,
    status: str = "upcoming",
    detailed_status: str = "Scheduled",
    source_url: str,
    detail_url: str | None = None,
) -> dict[str, Any]:
    start = _start_datetime(target_date, japan_time)
    taipei_start = start.astimezone(TAIPEI) if start else None
    return {
        "league": "NPB",
        "season": target_date.year,
        "game_pk": _stable_game_id(target_date, away, home),
        "external_game_id": _stable_game_id(target_date, away, home),
        "game_date": start.isoformat() if start else f"{target_date.isoformat()}T12:00:00+09:00",
        "date_taiwan": taipei_start.date().isoformat() if taipei_start else target_date.isoformat(),
        "time_taiwan": taipei_start.strftime("%H:%M") if taipei_start else "",
        "time_japan": japan_time or "",
        "status": status,
        "detailed_status": detailed_status,
        "inning": None,
        "inning_state": "",
        "venue_id": None,
        "venue": venue,
        "game_type": "regular_season",
        "season_context": "regular_season",
        "event_label": "NPB 例行賽",
        "is_special_event": False,
        "analysis_available": True,
        "analysis_status": "full_markets",
        "away": _team_payload(away, away_score),
        "home": _team_payload(home, home_score),
        "source_url": detail_url or source_url,
        "official_schedule_url": source_url,
    }


def _parse_score_links(parser: _NPBHtmlParser, target_date: date, source_url: str) -> list[dict[str, Any]]:
    games: list[dict[str, Any]] = []
    seen: set[str] = set()
    for href, label in parser.links:
        cleaned = re.sub(r"\s+", " ", label).strip()
        match = SCORE_RE.match(cleaned)
        if match:
            away = next(name for name in TEAM_NAMES if name.lower() == match.group("away").lower())
            home = next(name for name in TEAM_NAMES if name.lower() == match.group("home").lower())
            game_id = _stable_game_id(target_date, away, home)
            if game_id in seen:
                continue
            seen.add(game_id)
            games.append(
                _game_payload(
                    target_date,
                    away,
                    home,
                    venue=match.group("venue").strip(),
                    away_score=int(match.group("away_score")),
                    home_score=int(match.group("home_score")),
                    status="final",
                    detailed_status="Final",
                    source_url=source_url,
                    detail_url=urljoin(source_url, href),
                )
            )
            continue
        postponed = POSTPONED_RE.match(cleaned)
        if postponed:
            away = next(name for name in TEAM_NAMES if name.lower() == postponed.group("away").lower())
            home = next(name for name in TEAM_NAMES if name.lower() == postponed.group("home").lower())
            game_id = _stable_game_id(target_date, away, home)
            if game_id in seen:
                continue
            seen.add(game_id)
            games.append(
                _game_payload(
                    target_date,
                    away,
                    home,
                    status="postponed",
                    detailed_status=postponed.group("reason"),
                    source_url=source_url,
                    detail_url=urljoin(source_url, href),
                )
            )
    return games


def parse_npb_japanese_scoreboard(
    page_html: str,
    target_date: date,
    source_url: str,
) -> list[dict[str, Any]]:
    parser = _NPBHtmlParser()
    parser.feed(page_html)
    games: list[dict[str, Any]] = []
    seen: set[str] = set()
    for href, label in parser.links:
        href_match = JAPANESE_SCORE_HREF_RE.search(href or "")
        if not href_match:
            continue
        try:
            link_date = date(
                int(href_match.group("year")),
                int(href_match.group("mmdd")[:2]),
                int(href_match.group("mmdd")[2:]),
            )
        except ValueError:
            continue
        if link_date != target_date:
            continue
        home = URL_CODE_TO_SHORT.get(href_match.group("home").lower())
        away = URL_CODE_TO_SHORT.get(href_match.group("away").lower())
        if not home or not away:
            continue
        game_id = _stable_game_id(target_date, away, home)
        if game_id in seen:
            continue
        cleaned = re.sub(r"\s+", " ", label or "").strip()
        score_match = JAPANESE_SCORE_RE.search(cleaned)
        venue_match = JAPANESE_VENUE_RE.search(cleaned)
        inning_match = JAPANESE_INNING_RE.search(cleaned)
        status = "upcoming"
        detailed_status = cleaned or "Scheduled"
        inning: int | None = None
        inning_state = ""
        if "試合終了" in cleaned:
            status = "final"
            detailed_status = "Final"
        elif any(word in cleaned for word in ("中止", "雨天中止", "延期")):
            status = "postponed"
            detailed_status = "Postponed"
        elif score_match or inning_match:
            status = "live"
            detailed_status = cleaned or "In Progress"
            if inning_match:
                inning = int(inning_match.group("inning"))
                inning_state = "Top" if inning_match.group("half") == "表" else "Bottom"
        games.append(
            {
                "league": "NPB",
                "game_pk": game_id,
                "external_game_id": game_id,
                "status": status,
                "detailed_status": detailed_status,
                "inning": inning,
                "inning_state": inning_state,
                "venue": venue_match.group("venue").strip() if venue_match else "",
                "away": _team_payload(away, int(score_match.group("away_score")) if score_match else None),
                "home": _team_payload(home, int(score_match.group("home_score")) if score_match else None),
                "source_url": urljoin(source_url, href),
            }
        )
        seen.add(game_id)
    return games


def _merge_scoreboard(
    scheduled: list[dict[str, Any]],
    scoreboard: list[dict[str, Any]],
    target_date: date,
    source_url: str,
) -> list[dict[str, Any]]:
    """Merge the Japanese scoreboard without downgrading official results.

    The English daily page explicitly labels completed games as ``Final``.
    The monthly Japanese schedule, however, often contains only the score and
    no ``試合終了`` marker.  The latter is consequently parsed as ``live``.  A
    blind overlay used to replace a correct final result with that ambiguous
    live row, leaving yesterday's NPB recommendations permanently pending.

    Statuses are therefore merged monotonically: an overlay may advance a
    game from scheduled to live/final (or postponed), but it may never move a
    final game backwards.  Scores and inning data follow the source whose
    status wins the merge.
    """

    def status_priority(value: Any) -> int:
        status = str(value or "").strip().lower()
        if status == "final":
            return 4
        if status in {"postponed", "cancelled", "canceled"}:
            return 3
        if status in {"live", "in progress", "in_progress"}:
            return 2
        return 1

    overlays = {item["game_pk"]: item for item in scoreboard}
    merged: list[dict[str, Any]] = []
    scheduled_ids: set[str] = set()
    for game in scheduled:
        game_id = game.get("game_pk")
        scheduled_ids.add(game_id)
        overlay = overlays.get(game_id)
        if overlay:
            base_priority = status_priority(game.get("status"))
            overlay_priority = status_priority(overlay.get("status"))
            overlay_wins = overlay_priority >= base_priority
            if overlay_wins:
                game["status"] = overlay.get("status") or game.get("status")
                game["detailed_status"] = overlay.get("detailed_status") or game.get("detailed_status")
                game["inning"] = overlay.get("inning")
                game["inning_state"] = overlay.get("inning_state") or ""
            if overlay.get("venue"):
                game["venue"] = overlay["venue"]
            if overlay_wins:
                game["away"]["score"] = overlay.get("away", {}).get("score")
                game["home"]["score"] = overlay.get("home", {}).get("score")
                game["source_url"] = overlay.get("source_url") or game.get("source_url")
        merged.append(game)
    for game_id, overlay in overlays.items():
        if game_id in scheduled_ids:
            continue
        away = overlay["away"]["short_name"]
        home = overlay["home"]["short_name"]
        merged.append(
            _game_payload(
                target_date,
                away,
                home,
                venue=overlay.get("venue", ""),
                away_score=overlay["away"].get("score"),
                home_score=overlay["home"].get("score"),
                status=overlay.get("status", "upcoming"),
                detailed_status=overlay.get("detailed_status", "Scheduled"),
                source_url=source_url,
                detail_url=overlay.get("source_url"),
            )
        )
        merged[-1]["inning"] = overlay.get("inning")
        merged[-1]["inning_state"] = overlay.get("inning_state") or ""
    return merged


def _schedule_tokens(parser: _NPBHtmlParser) -> list[str]:
    marker = next(
        (index for index, token in enumerate(parser.tokens) if "Regular Season (Schedules)" in token),
        -1,
    )
    if marker < 0:
        return []
    tokens = parser.tokens[marker + 1 :]
    for index, token in enumerate(tokens):
        if token.startswith("Copyright"):
            return tokens[:index]
    return tokens


def _parse_schedule_tokens(
    parser: _NPBHtmlParser,
    target_date: date,
    source_url: str,
    now: datetime,
) -> list[dict[str, Any]]:
    tokens = _schedule_tokens(parser)
    games: list[dict[str, Any]] = []
    seen: set[str] = set()
    headings = {
        "CENTRAL LEAGUE",
        "PACIFIC LEAGUE",
        "Prev. Games",
        "Next Games",
        "Regular Season",
        "Schedules/Scores",
    }
    i = 0
    while i < len(tokens):
        token = tokens[i]
        if token not in TEAM_BY_SHORT:
            i += 1
            continue
        home = token
        venue_parts: list[str] = []
        japan_time: str | None = None
        postponed_reason: str | None = None
        j = i + 1
        while j < len(tokens) and j <= i + 12:
            current = tokens[j]
            if current in TEAM_BY_SHORT:
                break
            if TIME_RE.match(current):
                japan_time = current
                j += 1
                break
            if current.lower() in {"rained out", "cancelled", "canceled", "postponed"}:
                postponed_reason = current
            elif current not in headings and not current.startswith("Image:") and not re.match(r"^[A-Z][a-z]+day,", current):
                venue_parts.append(current)
            j += 1
        while j < len(tokens) and tokens[j] not in TEAM_BY_SHORT:
            j += 1
        if j >= len(tokens):
            i += 1
            continue
        away = tokens[j]
        game_id = _stable_game_id(target_date, away, home)
        if game_id not in seen:
            seen.add(game_id)
            start = _start_datetime(target_date, japan_time)
            if postponed_reason:
                status, detail = "postponed", postponed_reason
            else:
                status, detail = _status_from_schedule(start, now)
            games.append(
                _game_payload(
                    target_date,
                    away,
                    home,
                    venue=" ".join(venue_parts).strip(),
                    japan_time=japan_time,
                    status=status,
                    detailed_status=detail,
                    source_url=source_url,
                )
            )
        i = j + 1
    return games


def parse_npb_daily_page(
    page_html: str,
    target_date: date,
    source_url: str,
    *,
    now: datetime | None = None,
) -> list[dict[str, Any]]:
    parser = _NPBHtmlParser()
    parser.feed(page_html)
    completed = _parse_score_links(parser, target_date, source_url)
    if completed:
        return sorted(completed, key=lambda game: game["game_pk"])
    return _parse_schedule_tokens(parser, target_date, source_url, now or datetime.now(TAIPEI))


class NPBService:
    def __init__(self, settings: Settings, transport: httpx.AsyncBaseTransport | None = None) -> None:
        self.settings = settings
        self.cache = AsyncTTLCache()
        self.client = httpx.AsyncClient(
            timeout=settings.request_timeout_seconds,
            follow_redirects=True,
            trust_env=False,
            transport=transport,
            headers={
                "User-Agent": "DiamondMind/NPB-complete (+official lineups, recent pitching, roster and weather)",
                "Accept": "text/html,application/xhtml+xml",
                "Accept-Language": "ja-JP,ja;q=0.9,en-US;q=0.7,en;q=0.5",
            },
        )
        self.weather = WeatherService(settings, transport=transport)
        self._detail_semaphore = asyncio.Semaphore(6)
        # The official starter page switches to the next day's announcement
        # after games begin. Preserve each successfully parsed date so today's
        # announced starters do not disappear from the schedule after the page
        # rolls forward.
        self._starter_by_date: dict[str, dict[str, Any]] = {}

    async def aclose(self) -> None:
        await asyncio.gather(self.client.aclose(), self.weather.aclose())

    def daily_url(self, target_date: date) -> str:
        return f"{self.settings.npb_official_base}/bis/eng/{target_date.year}/games/gm{target_date:%Y%m%d}.html"

    def monthly_url(self, target_date: date) -> str:
        return f"{self.settings.npb_official_base}/games/{target_date.year}/schedule_{target_date:%m}_detail.html"

    def starter_url(self) -> str:
        return f"{self.settings.npb_official_base}/announcement/starter/"

    def roster_url(self, target_date: date) -> str:
        return f"{self.settings.npb_official_base}/announcement/roster/roster_{target_date:%m%d}.html"

    def standings_url(self, season: int) -> str:
        return f"{self.settings.npb_official_base}/bis/eng/{season}/stats/"

    def team_batting_url(self, season: int, short_name: str) -> str:
        code = SHORT_TO_URL_CODE[short_name]
        return f"{self.settings.npb_official_base}/bis/eng/{season}/stats/idb1_{code}.html"

    def team_pitching_url(self, season: int, short_name: str) -> str:
        code = SHORT_TO_URL_CODE[short_name]
        return f"{self.settings.npb_official_base}/bis/eng/{season}/stats/idp1_{code}.html"

    def player_url(self, player_id: str) -> str:
        return f"{self.settings.npb_official_base}/bis/players/{player_id}.html"

    async def _get_html(self, url: str) -> HtmlPayload:
        cached = self.cache.get(url)
        if cached and cached.is_fresh:
            return HtmlPayload(cached.value, "hit", _iso_timestamp(cached.stored_at), url)
        async with self.cache.lock(url):
            cached = self.cache.get(url)
            if cached and cached.is_fresh:
                return HtmlPayload(cached.value, "hit", _iso_timestamp(cached.stored_at), url)
            try:
                response = await self.client.get(url)
                response.raise_for_status()
                body = response.text
                expected_markers = ("Nippon Professional Baseball", "Regular Season", "日本野球機構", "予告先発")
                if not any(marker in body for marker in expected_markers):
                    raise ValueError("Unexpected NPB response")
                # Live NPB score/box pages change every inning. Keep those
                # pages much fresher than season tables so a game that has
                # already started does not continue showing pre-game blanks.
                cache_ttl = self.settings.npb_cache_ttl_seconds
                if "/scores/" in url:
                    cache_ttl = min(cache_ttl, 30)
                entry = self.cache.set(
                    url,
                    body,
                    cache_ttl,
                    self.settings.npb_stale_ttl_seconds,
                )
                return HtmlPayload(body, "miss", _iso_timestamp(entry.stored_at), url)
            except (httpx.HTTPError, ValueError) as exc:
                if cached and cached.can_serve_stale:
                    return HtmlPayload(cached.value, "stale", _iso_timestamp(cached.stored_at), url)
                raise NPBUpstreamError("NPB 官方賽程目前暫時無法連線") from exc

    async def standings_for_season(self, season: int) -> dict[str, Any]:
        url = self.standings_url(season)
        payload = await self._get_html(url)
        parsed = parse_npb_standings(payload.text, url)
        return {
            "league": "NPB",
            "season": season,
            "leagues": parsed["leagues"],
            "count": len(parsed["by_team"]),
            "meta": {
                "source": "NPB.jp official standings",
                "source_url": url,
                "cache": payload.cache_status,
                "updated_at": payload.fetched_at,
            },
        }

    async def season_results(self, target_date: date) -> dict[str, Any]:
        start_month = 3
        months = list(range(start_month, target_date.month + 1))
        urls = [f"{self.settings.npb_official_base}/games/{target_date.year}/schedule_{month:02d}_detail.html" for month in months]

        async def optional_fetch(url: str) -> HtmlPayload | None:
            try:
                return await self._get_html(url)
            except NPBUpstreamError:
                return None

        payloads = await asyncio.gather(*(optional_fetch(url) for url in urls))
        games: list[dict[str, Any]] = []
        seen: set[str] = set()
        for url, payload in zip(urls, payloads):
            if not payload:
                continue
            for game in parse_npb_month_scoreboard(payload.text, target_date.year, url):
                if game["game_pk"] in seen or str(game.get("date") or "") > target_date.isoformat():
                    continue
                seen.add(game["game_pk"])
                games.append(game)
        games.sort(key=lambda item: (item.get("date") or "", item.get("game_pk") or ""))
        return {
            "season": target_date.year,
            "through": target_date.isoformat(),
            "items": games,
            "count": len(games),
            "sources": [url for url, payload in zip(urls, payloads) if payload],
        }

    async def team_analysis_data(self, season: int, short_name: str) -> dict[str, Any]:
        batting_url = self.team_batting_url(season, short_name)
        pitching_url = self.team_pitching_url(season, short_name)
        batting_payload, pitching_payload = await asyncio.gather(
            self._get_html(batting_url),
            self._get_html(pitching_url),
        )
        return {
            "team": short_name,
            "batting": parse_npb_batting_stats(batting_payload.text, batting_url),
            "pitching": parse_npb_pitching_stats(pitching_payload.text, pitching_url),
            "meta": {
                "batting_source_url": batting_url,
                "pitching_source_url": pitching_url,
                "updated_at": max(batting_payload.fetched_at, pitching_payload.fetched_at),
                "cache": "stale" if "stale" in {batting_payload.cache_status, pitching_payload.cache_status} else "hit" if batting_payload.cache_status == pitching_payload.cache_status == "hit" else "miss",
            },
        }

    async def starter_profile(self, starter: dict[str, Any], season: int) -> dict[str, Any] | None:
        player_id = str(starter.get("player_id") or "")
        if not player_id:
            return None
        url = self.player_url(player_id)
        try:
            payload = await self._get_html(url)
        except NPBUpstreamError:
            return None
        parsed = parse_npb_player_pitching_profile(payload.text, season, url)
        if not parsed:
            return None
        parsed["player_id"] = player_id
        parsed["name"] = starter.get("name") or ""
        return parsed

    async def _optional_html(self, url: str | None) -> HtmlPayload | None:
        if not url:
            return None
        try:
            return await self._get_html(url)
        except NPBUpstreamError:
            return None

    async def _boxscore_for_game(self, game: dict[str, Any], away_short: str, home_short: str) -> dict[str, Any]:
        source_url = str(game.get("source_url") or "")
        empty = {
            "available": False,
            "lineups": {"away": {}, "home": {}},
            "pitching": {"away": {}, "home": {}},
            "source_url": source_url,
            "attempted_urls": _npb_live_detail_urls(source_url),
        }
        if not source_url:
            return empty

        best = empty
        for detail_url in _npb_live_detail_urls(source_url):
            async with self._detail_semaphore:
                payload = await self._optional_html(detail_url)
            if not payload:
                continue
            parsed = parse_npb_boxscore(payload.text, away_short, home_short, detail_url)
            parsed["cache"] = payload.cache_status
            parsed["updated_at"] = payload.fetched_at
            parsed["attempted_urls"] = _npb_live_detail_urls(source_url)
            if parsed.get("available"):
                best = parsed
                away_ready = bool((parsed.get("lineups") or {}).get("away", {}).get("official"))
                home_ready = bool((parsed.get("lineups") or {}).get("home", {}).get("official"))
                away_pitching = bool((parsed.get("pitching") or {}).get("away", {}).get("available"))
                home_pitching = bool((parsed.get("pitching") or {}).get("home", {}).get("available"))
                if away_ready and home_ready and away_pitching and home_pitching:
                    break
        return best

    async def _enrich_live_game(self, game: dict[str, Any]) -> None:
        """Attach official starters and lineups around first pitch.

        NPB publishes the official order shortly before the game.  Enrich live
        games and upcoming games inside the configured lineup-watch window so
        Pro members can see the announced lineup before first pitch, not only
        after the scoreboard changes to live.
        """

        status = str(game.get("status") or "").lower()
        if status != "live":
            if status not in {"upcoming", "scheduled", "preview"}:
                return
            try:
                start = datetime.fromisoformat(str(game.get("game_date") or ""))
                if start.tzinfo is None:
                    start = start.replace(tzinfo=TOKYO)
                minutes_to_start = (start.astimezone(TAIPEI) - datetime.now(TAIPEI)).total_seconds() / 60.0
            except (TypeError, ValueError):
                return
            if minutes_to_start > float(self.settings.pregame_lineup_watch_minutes) or minutes_to_start < -45:
                return
        away_short = str((game.get("away") or {}).get("short_name") or "")
        home_short = str((game.get("home") or {}).get("short_name") or "")
        if not away_short or not home_short:
            return
        boxscore = await self._boxscore_for_game(game, away_short, home_short)
        lineups = boxscore.get("lineups") or {}
        pitching = boxscore.get("pitching") or {}
        for side in ("away", "home"):
            pitchers = ((pitching.get(side) or {}).get("pitchers") or [])
            starter = next((item for item in pitchers if item.get("is_starter")), pitchers[0] if pitchers else None)
            if starter and starter.get("name"):
                game[side]["probable_pitcher"] = {
                    "id": starter.get("player_id"),
                    "player_id": starter.get("player_id"),
                    "name": starter.get("name"),
                    "announced": True,
                    "official": True,
                    "source": "NPB official live box score",
                    "source_url": boxscore.get("source_url"),
                }
        game["official_lineups_ready"] = bool(
            (lineups.get("away") or {}).get("official")
            and (lineups.get("home") or {}).get("official")
        )
        game["live_detail_source_url"] = boxscore.get("source_url")
        game["live_detail_updated_at"] = boxscore.get("updated_at")
        game["live_detail_attempted_urls"] = boxscore.get("attempted_urls") or _npb_live_detail_urls(str(game.get("source_url") or ""))
        starters_ready = all(
            bool(((game.get(side) or {}).get("probable_pitcher") or {}).get("announced"))
            for side in ("away", "home")
        )
        game["formal_recommendation_ready"] = True
        game["data_completeness_advisory"] = not starters_ready
        game["analysis_status"] = "full_markets" if starters_ready else "advisory_markets"

    async def _recent_boxscores(
        self,
        history_items: list[dict[str, Any]],
        teams: set[str],
        target_date: date,
        *,
        per_team_limit: int = 18,
    ) -> list[dict[str, Any]]:
        candidates: list[dict[str, Any]] = []
        counts = {team: 0 for team in teams}
        for item in sorted(history_items, key=lambda value: str(value.get("date") or ""), reverse=True):
            if item.get("status") != "final":
                continue
            try:
                game_day = date.fromisoformat(str(item.get("date") or ""))
            except ValueError:
                continue
            if game_day >= target_date:
                continue
            involved = teams.intersection({str(item.get("away") or ""), str(item.get("home") or "")})
            if not involved or all(counts[team] >= per_team_limit for team in involved):
                continue
            source_url = str(item.get("source_url") or "")
            if not source_url:
                continue
            candidates.append(item)
            for team in involved:
                counts[team] += 1
            if all(value >= per_team_limit for value in counts.values()):
                break

        async def fetch(item: dict[str, Any]) -> dict[str, Any] | None:
            source_url = str(item.get("source_url") or "")
            for detail_url in _npb_live_detail_urls(source_url):
                async with self._detail_semaphore:
                    payload = await self._optional_html(detail_url)
                if not payload:
                    continue
                boxscore = parse_npb_boxscore(
                    payload.text,
                    str(item.get("away") or ""),
                    str(item.get("home") or ""),
                    detail_url,
                )
                if not boxscore.get("available"):
                    continue
                return {
                    **item,
                    "boxscore": boxscore,
                    "cache": payload.cache_status,
                    "updated_at": payload.fetched_at,
                }
            return None

        results = await asyncio.gather(*(fetch(item) for item in candidates)) if candidates else []
        return [item for item in results if item]

    async def _roster_activity(
        self,
        target_date: date,
        away_short: str,
        home_short: str,
        *,
        lookback_days: int = 7,
    ) -> dict[str, Any]:
        dates = [target_date - timedelta(days=offset) for offset in range(lookback_days)]

        async def fetch(day: date) -> dict[str, Any] | None:
            url = self.roster_url(day)
            async with self._detail_semaphore:
                payload = await self._optional_html(url)
            if not payload:
                return None
            parsed = parse_npb_roster_transactions(payload.text, day, url)
            if not parsed.get("date"):
                return None
            parsed["cache"] = payload.cache_status
            parsed["updated_at"] = payload.fetched_at
            return parsed

        daily = [item for item in await asyncio.gather(*(fetch(day) for day in dates)) if item]
        result: dict[str, Any] = {
            "window_days": lookback_days,
            "away": {"team": away_short, "registered": [], "deregistered": []},
            "home": {"team": home_short, "registered": [], "deregistered": []},
            "sources": [],
            "official_injury_reason_available": False,
            "note": "NPB 官方公示提供一軍註冊與抹消；未統一公開傷病原因，系統不推測診斷。",
        }
        side_by_team = {away_short: "away", home_short: "home"}
        for item in daily:
            result["sources"].append(item.get("source_url"))
            for bucket in ("registered", "deregistered"):
                for player in item.get(bucket) or []:
                    side = side_by_team.get(player.get("team"))
                    if side:
                        result[side][bucket].append(player)
        for side in ("away", "home"):
            for bucket in ("registered", "deregistered"):
                result[side][bucket].sort(key=lambda player: str(player.get("date") or ""), reverse=True)
            result[side]["available"] = bool(result[side]["registered"] or result[side]["deregistered"])
        result["available"] = bool(daily)
        return result

    async def _environment_for_game(self, game: dict[str, Any]) -> dict[str, Any]:
        venue = _venue_profile(str(game.get("venue") or ""))
        game_time_raw = str(game.get("game_date") or "")
        try:
            game_time = datetime.fromisoformat(game_time_raw.replace("Z", "+00:00"))
            if game_time.tzinfo is None:
                game_time = game_time.replace(tzinfo=TOKYO)
        except ValueError:
            game_time = datetime.combine(date.today(), time(18, 0), tzinfo=TOKYO)
        weather = await self.weather.forecast_for_game(
            venue.get("latitude"),
            venue.get("longitude"),
            game_time.astimezone(timezone.utc),
        )
        roof_closed = bool(venue.get("roof_closed"))
        adjustment = environment_run_adjustment(
            weather,
            roof_type=str(venue.get("roof_type") or ""),
            roof_closed=roof_closed,
            relative_wind=None,
            park_run_factor=float(venue.get("park_run_factor") or 1.0),
        )
        return {
            "available": bool(venue.get("available")),
            "venue": venue,
            "weather": weather,
            "roof_closed": roof_closed,
            "run_environment": adjustment,
            "note": "固定巨蛋與預設關閉屋頂不套用戶外天氣權重；無可靠官方球場係數時採中性基準。",
        }

    async def game_detail(self, game_pk: str) -> dict[str, Any]:
        match = re.fullmatch(r"npb_(?P<date>\d{8})_(?P<away>[A-Z]+)_(?P<home>[A-Z]+)", game_pk or "")
        if not match:
            raise NPBUpstreamError("無效的 NPB 賽事編號")
        try:
            target_date = datetime.strptime(match.group("date"), "%Y%m%d").date()
        except ValueError as exc:
            raise NPBUpstreamError("無效的 NPB 賽事日期") from exc

        schedule = await self.games_for_date(target_date)
        try:
            history = await self.season_results(target_date)
        except Exception:
            # Historical results improve form, but today's schedule is enough to
            # keep an NPB matchup available for the baseline model.
            history = {"items": [], "count": 0, "sources": [], "advisory": "歷史賽果暫時無法載入。"}
        game = next((item for item in schedule.get("items") or [] if item.get("game_pk") == game_pk), None)
        if not game:
            raise NPBUpstreamError("找不到指定的 NPB 賽事")
        away_short = str((game.get("away") or {}).get("short_name") or "")
        home_short = str((game.get("home") or {}).get("short_name") or "")
        if not away_short or not home_short:
            raise NPBUpstreamError("NPB 球隊資料不完整")

        async def optional_team_data(short_name: str) -> dict[str, Any]:
            try:
                return await self.team_analysis_data(target_date.year, short_name)
            except Exception:
                # Team statistics are optional enrichment for NPB publication.
                return {
                    "team": short_name,
                    "batting": {},
                    "pitching": {},
                    "meta": {
                        "updated_at": (schedule.get("meta") or {}).get("updated_at"),
                        "cache": "unavailable",
                        "advisory": "NPB 球隊統計暫時無法載入，使用基礎模型。",
                    },
                }

        async def optional_roster_status() -> dict[str, Any]:
            try:
                return await self._roster_activity(target_date, away_short, home_short)
            except Exception:
                # Roster announcements are advisory and must not remove a game.
                return {"away": {}, "home": {}, "available": False, "sources": []}

        async def optional_environment() -> dict[str, Any]:
            try:
                return await self._environment_for_game(game)
            except Exception:
                # Weather/venue enrichment falls back to a neutral environment.
                return {
                    "available": False,
                    "venue": {"available": False, "name": game.get("venue")},
                    "weather": {"available": False},
                    "run_environment": {"quality": 0.0, "run_adjustment": 0.0},
                    "note": "球場或天氣資料暫時無法載入，採中性環境。",
                }

        away_data, home_data, current_boxscore, roster_status, environment = await asyncio.gather(
            optional_team_data(away_short),
            optional_team_data(home_short),
            self._boxscore_for_game(game, away_short, home_short),
            optional_roster_status(),
            optional_environment(),
        )

        def resolved_starter(side: str) -> dict[str, Any]:
            scheduled = (game.get(side) or {}).get("probable_pitcher") or {}
            pitchers = (((current_boxscore.get("pitching") or {}).get(side) or {}).get("pitchers") or [])
            official = next((item for item in pitchers if item.get("is_starter")), pitchers[0] if pitchers else None)
            if official and official.get("name"):
                return {
                    "id": official.get("player_id"),
                    "player_id": official.get("player_id"),
                    "name": official.get("name"),
                    "announced": True,
                    "official": True,
                    "source": "NPB official live box score",
                    "source_url": current_boxscore.get("source_url"),
                }
            return scheduled

        away_starter_info = resolved_starter("away")
        home_starter_info = resolved_starter("home")
        game["away"]["probable_pitcher"] = {**((game.get("away") or {}).get("probable_pitcher") or {}), **away_starter_info}
        game["home"]["probable_pitcher"] = {**((game.get("home") or {}).get("probable_pitcher") or {}), **home_starter_info}

        async def optional_starter_profile(starter: dict[str, Any]) -> dict[str, Any] | None:
            try:
                return await self.starter_profile(starter, target_date.year)
            except Exception:
                return None

        away_profile, home_profile = await asyncio.gather(
            optional_starter_profile(away_starter_info),
            optional_starter_profile(home_starter_info),
        )
        if away_profile and away_profile.get("player_id"):
            away_data["pitching"].setdefault("by_id", {})[away_profile["player_id"]] = away_profile
        if home_profile and home_profile.get("player_id"):
            home_data["pitching"].setdefault("by_id", {})[home_profile["player_id"]] = home_profile

        try:
            recent_boxscores = await self._recent_boxscores(
                history.get("items") or [],
                {away_short, home_short},
                target_date,
            )
        except Exception:
            recent_boxscores = []
        lineups = current_boxscore.get("lineups") or {"away": {}, "home": {}}
        starter_recent = {
            "away": summarize_starter_recent(recent_boxscores, away_short, away_starter_info),
            "home": summarize_starter_recent(recent_boxscores, home_short, home_starter_info),
        }
        bullpen_usage = {
            "away": summarize_bullpen_usage(recent_boxscores, away_short, target_date),
            "home": summarize_bullpen_usage(recent_boxscores, home_short, target_date),
        }
        away_form = npb_team_form(away_short, history.get("items") or [])
        home_form = npb_team_form(home_short, history.get("items") or [])
        analysis = build_npb_analysis(
            game,
            away_form,
            home_form,
            away_data["batting"],
            home_data["batting"],
            away_data["pitching"],
            home_data["pitching"],
            lineups=lineups,
            starter_recent=starter_recent,
            bullpen_usage=bullpen_usage,
            roster_status=roster_status,
            environment=environment,
        )
        timestamps = [
            str((schedule.get("meta") or {}).get("updated_at") or ""),
            str((away_data.get("meta") or {}).get("updated_at") or ""),
            str((home_data.get("meta") or {}).get("updated_at") or ""),
            str(current_boxscore.get("updated_at") or ""),
            str((environment.get("weather") or {}).get("updated_at") or ""),
        ]
        return {
            "game": game,
            "analysis": analysis,
            "lineups": lineups,
            "starter_recent": starter_recent,
            "bullpen_usage": bullpen_usage,
            "roster_status": roster_status,
            "environment": environment,
            "access": {"required_plan": "pro"},
            "meta": {
                "source": "NPB.jp official schedule, box scores, player stats and roster announcements; Open-Meteo weather",
                "updated_at": max(timestamps),
                "phase": "NPB complete analysis modules",
                "official_recommendation_enabled": bool(analysis.get("official_recommendation_enabled")),
                "recent_boxscores_loaded": len(recent_boxscores),
                "official_lineups_ready": bool((lineups.get("away") or {}).get("official") and (lineups.get("home") or {}).get("official")),
            },
        }

    async def game_result(self, game_pk: str) -> dict[str, Any]:
        match = re.fullmatch(r"npb_(?P<date>\d{8})_(?P<away>[A-Z]+)_(?P<home>[A-Z]+)", str(game_pk or ""))
        if not match:
            raise NPBUpstreamError("無效的 NPB 賽事編號")
        try:
            target_date = datetime.strptime(match.group("date"), "%Y%m%d").date()
        except ValueError as exc:
            raise NPBUpstreamError("無效的 NPB 賽事日期") from exc
        payload = await self.games_for_date(target_date)
        game = next((item for item in payload.get("items") or [] if str(item.get("game_pk")) == str(game_pk)), None)
        if not game:
            raise NPBUpstreamError("找不到指定的 NPB 賽事結果")
        return game

    async def games_for_date(self, target_date: date) -> dict[str, Any]:
        source_url = self.daily_url(target_date)
        result_url = self.monthly_url(target_date)
        starter_url = self.starter_url()
        standings_url = self.standings_url(target_date.year)

        payload = await self._get_html(source_url)
        items = parse_npb_daily_page(payload.text, target_date, source_url)
        result_payload: HtmlPayload | None = None
        starter_payload: HtmlPayload | None = None
        standings_payload: HtmlPayload | None = None
        starter_data: dict[str, Any] = {"date": None, "by_team": {}, "source_url": starter_url}
        standings_data: dict[str, Any] = {"leagues": {}, "by_team": {}, "source_url": standings_url}

        async def optional_fetch(url: str) -> HtmlPayload | None:
            try:
                return await self._get_html(url)
            except NPBUpstreamError:
                return None

        result_payload, starter_payload, standings_payload = await asyncio.gather(
            optional_fetch(result_url),
            optional_fetch(starter_url),
            optional_fetch(standings_url),
        )
        if result_payload:
            scoreboard = parse_npb_japanese_scoreboard(result_payload.text, target_date, result_url)
            items = _merge_scoreboard(items, scoreboard, target_date, source_url)
        if starter_payload:
            parsed_starters = parse_npb_probable_starters(starter_payload.text, target_date, starter_url)
            parsed_date = str(parsed_starters.get("date") or "")
            if parsed_date and (parsed_starters.get("by_team") or {}):
                self._starter_by_date[parsed_date] = parsed_starters
            starter_data = (
                parsed_starters
                if parsed_date == target_date.isoformat()
                else self._starter_by_date.get(target_date.isoformat(), starter_data)
            )
            _apply_probable_starters(items, starter_data)
        if standings_payload:
            standings_data = parse_npb_standings(standings_payload.text, standings_url)
            _apply_standings(items, standings_data)

        # The NPB box-score tab contains the official batting order and actual
        # starting pitcher.  Enrich live games and games approaching first
        # pitch so the schedule and Pro detail page stay aligned with NPB.jp.
        detail_games = [
            item for item in items
            if str(item.get("status") or "").lower() in {"live", "upcoming", "scheduled", "preview"}
        ]
        if detail_games:
            await asyncio.gather(*(self._enrich_live_game(game) for game in detail_games))

        items.sort(key=lambda item: (item.get("game_date") or "", item.get("game_pk") or ""))
        payloads = [item for item in (payload, result_payload, starter_payload, standings_payload) if item]
        cache_states = [item.cache_status for item in payloads]
        cache_status = "stale" if "stale" in cache_states else ("hit" if cache_states and all(state == "hit" for state in cache_states) else "miss")
        announced_count = sum(
            1
            for game in items
            for side in ("away", "home")
            if (game.get(side) or {}).get("probable_pitcher", {}).get("announced")
        )
        return {
            "league": "NPB",
            "date": target_date.isoformat(),
            "timezone": "Asia/Taipei",
            "count": len(items),
            "items": items,
            "standings": standings_data.get("leagues") or {},
            "capabilities": {
                "schedule": True,
                "scores": True,
                "live_status": "beta",
                "probable_pitchers": announced_count > 0,
                "standings": bool(standings_data.get("by_team")),
                "analysis": "complete",
                "official_lineups": True,
                "starter_recent_3": True,
                "bullpen_recent_3_days": True,
                "roster_transactions": True,
                "venue_weather": True,
                "advanced_stats": ["FIP", "K%", "BB%", "ISO"],
                "predictions": "moneyline_runline_totals",
                "odds": "real_market_when_configured",
                "settlement": "multi_market",
            },
            "meta": {
                "source": "NPB.jp official schedule, live scoreboard, probable starters and standings",
                "source_url": source_url,
                "result_source_url": result_url,
                "starter_source_url": starter_url,
                "standings_source_url": standings_url,
                "starter_date": starter_data.get("date"),
                "announced_starters": announced_count,
                "cache": cache_status,
                "updated_at": max((item.fetched_at for item in payloads), default=payload.fetched_at),
                "phase": "NPB complete analysis modules",
            },
        }
