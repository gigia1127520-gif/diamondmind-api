from __future__ import annotations

import html
import re
from dataclasses import dataclass
from datetime import date, datetime, time, timedelta
from html.parser import HTMLParser
from typing import Any
from urllib.parse import urljoin
from zoneinfo import ZoneInfo

import httpx

from .cache import AsyncTTLCache
from .config import Settings


TAIPEI = ZoneInfo("Asia/Taipei")
TOKYO = ZoneInfo("Asia/Tokyo")


class NPBUpstreamError(RuntimeError):
    pass


@dataclass
class HtmlPayload:
    text: str
    cache_status: str
    fetched_at: str
    source_url: str


@dataclass(frozen=True)
class TeamInfo:
    canonical: str
    short: str
    abbr: str
    zh: str


TEAM_BY_SHORT: dict[str, TeamInfo] = {
    "Yakult": TeamInfo("Tokyo Yakult Swallows", "Yakult", "S", "東京養樂多燕子"),
    "Yomiuri": TeamInfo("Yomiuri Giants", "Yomiuri", "G", "讀賣巨人"),
    "DeNA": TeamInfo("YOKOHAMA DeNA BAYSTARS", "DeNA", "DB", "橫濱DeNA海灣之星"),
    "Chunichi": TeamInfo("Chunichi Dragons", "Chunichi", "D", "中日龍"),
    "Hanshin": TeamInfo("Hanshin Tigers", "Hanshin", "T", "阪神虎"),
    "Hiroshima": TeamInfo("Hiroshima Toyo Carp", "Hiroshima", "C", "廣島東洋鯉魚"),
    "SoftBank": TeamInfo("Fukuoka SoftBank Hawks", "SoftBank", "H", "福岡軟銀鷹"),
    "Nippon-Ham": TeamInfo("Hokkaido Nippon-Ham Fighters", "Nippon-Ham", "F", "北海道日本火腿鬥士"),
    "ORIX": TeamInfo("ORIX Buffaloes", "ORIX", "B", "歐力士猛牛"),
    "Rakuten": TeamInfo("Tohoku Rakuten Golden Eagles", "Rakuten", "E", "東北樂天金鷲"),
    "Seibu": TeamInfo("Saitama Seibu Lions", "Seibu", "L", "埼玉西武獅"),
    "Lotte": TeamInfo("Chiba Lotte Marines", "Lotte", "M", "千葉羅德海洋"),
    "CL": TeamInfo("Central League All-Stars", "CL", "CL", "中央聯盟明星隊"),
    "PL": TeamInfo("Pacific League All-Stars", "PL", "PL", "太平洋聯盟明星隊"),
}

TEAM_NAMES = sorted(TEAM_BY_SHORT, key=len, reverse=True)
TEAM_ALT = "|".join(re.escape(name) for name in TEAM_NAMES)
TIME_RE = re.compile(r"^(?:[01]?\d|2[0-3]):[0-5]\d$")
SCORE_RE = re.compile(
    rf"^(?P<away>{TEAM_ALT})\s+(?P<away_score>\d+)\s+Game\s+\d+\s+(?P<venue>.+?)\s+(?P<home_score>\d+)\s+(?P<home>{TEAM_ALT})$",
    re.IGNORECASE,
)
POSTPONED_RE = re.compile(
    rf"^(?P<away>{TEAM_ALT})\s+(?P<reason>Rained Out|Cancelled|Canceled|Postponed)\s+(?P<home>{TEAM_ALT})$",
    re.IGNORECASE,
)


class _NPBHtmlParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.tokens: list[str] = []
        self.links: list[tuple[str, str]] = []
        self._href: str | None = None
        self._anchor_parts: list[str] = []

    @staticmethod
    def _clean(value: str) -> str:
        return re.sub(r"\s+", " ", html.unescape(value or "")).strip()

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag.lower() == "a":
            self._href = dict(attrs).get("href") or ""
            self._anchor_parts = []

    def handle_data(self, data: str) -> None:
        cleaned = self._clean(data)
        if not cleaned:
            return
        self.tokens.append(cleaned)
        if self._href is not None:
            self._anchor_parts.append(cleaned)

    def handle_endtag(self, tag: str) -> None:
        if tag.lower() == "a" and self._href is not None:
            text = self._clean(" ".join(self._anchor_parts))
            if text:
                self.links.append((self._href, text))
            self._href = None
            self._anchor_parts = []


def _iso_timestamp(epoch: float) -> str:
    return datetime.fromtimestamp(epoch, tz=TAIPEI).isoformat()


def _team_payload(short_name: str, score: int | None = None) -> dict[str, Any]:
    team = TEAM_BY_SHORT[short_name]
    return {
        "id": team.abbr,
        "name": team.canonical,
        "short_name": team.short,
        "name_zh": team.zh,
        "abbr": team.abbr,
        "score": score,
        "probable_pitcher": {"id": None, "name": "尚未公布"},
    }


def _stable_game_id(target_date: date, away: str, home: str) -> str:
    return f"npb_{target_date:%Y%m%d}_{TEAM_BY_SHORT[away].abbr}_{TEAM_BY_SHORT[home].abbr}"


def _start_datetime(target_date: date, japan_time: str | None) -> datetime | None:
    if not japan_time or not TIME_RE.match(japan_time):
        return None
    hour, minute = map(int, japan_time.split(":"))
    return datetime.combine(target_date, time(hour, minute), tzinfo=TOKYO)


def _status_from_schedule(start: datetime | None, now: datetime) -> tuple[str, str]:
    if start is None:
        return "upcoming", "Scheduled"
    now_tokyo = now.astimezone(TOKYO)
    if now_tokyo < start:
        return "upcoming", "Scheduled"
    if now_tokyo <= start + timedelta(hours=5):
        return "live", "In Progress"
    return "upcoming", "Awaiting official result"


def _game_payload(
    target_date: date,
    away: str,
    home: str,
    *,
    venue: str = "",
    japan_time: str | None = None,
    away_score: int | None = None,
    home_score: int | None = None,
    status: str = "upcoming",
    detailed_status: str = "Scheduled",
    source_url: str,
    detail_url: str | None = None,
) -> dict[str, Any]:
    start = _start_datetime(target_date, japan_time)
    taipei_start = start.astimezone(TAIPEI) if start else None
    return {
        "league": "NPB",
        "season": target_date.year,
        "game_pk": _stable_game_id(target_date, away, home),
        "external_game_id": _stable_game_id(target_date, away, home),
        "game_date": start.isoformat() if start else f"{target_date.isoformat()}T12:00:00+09:00",
        "date_taiwan": taipei_start.date().isoformat() if taipei_start else target_date.isoformat(),
        "time_taiwan": taipei_start.strftime("%H:%M") if taipei_start else "",
        "time_japan": japan_time or "",
        "status": status,
        "detailed_status": detailed_status,
        "inning": None,
        "inning_state": "",
        "venue_id": None,
        "venue": venue,
        "game_type": "regular_season",
        "season_context": "regular_season",
        "event_label": "NPB 例行賽",
        "is_special_event": False,
        "analysis_available": False,
        "analysis_status": "schedule_only",
        "away": _team_payload(away, away_score),
        "home": _team_payload(home, home_score),
        "source_url": detail_url or source_url,
        "official_schedule_url": source_url,
    }


def _parse_score_links(parser: _NPBHtmlParser, target_date: date, source_url: str) -> list[dict[str, Any]]:
    games: list[dict[str, Any]] = []
    seen: set[str] = set()
    for href, label in parser.links:
        cleaned = re.sub(r"\s+", " ", label).strip()
        match = SCORE_RE.match(cleaned)
        if match:
            away = next(name for name in TEAM_NAMES if name.lower() == match.group("away").lower())
            home = next(name for name in TEAM_NAMES if name.lower() == match.group("home").lower())
            game_id = _stable_game_id(target_date, away, home)
            if game_id in seen:
                continue
            seen.add(game_id)
            games.append(
                _game_payload(
                    target_date,
                    away,
                    home,
                    venue=match.group("venue").strip(),
                    away_score=int(match.group("away_score")),
                    home_score=int(match.group("home_score")),
                    status="final",
                    detailed_status="Final",
                    source_url=source_url,
                    detail_url=urljoin(source_url, href),
                )
            )
            continue
        postponed = POSTPONED_RE.match(cleaned)
        if postponed:
            away = next(name for name in TEAM_NAMES if name.lower() == postponed.group("away").lower())
            home = next(name for name in TEAM_NAMES if name.lower() == postponed.group("home").lower())
            game_id = _stable_game_id(target_date, away, home)
            if game_id in seen:
                continue
            seen.add(game_id)
            games.append(
                _game_payload(
                    target_date,
                    away,
                    home,
                    status="postponed",
                    detailed_status=postponed.group("reason"),
                    source_url=source_url,
                    detail_url=urljoin(source_url, href),
                )
            )
    return games


def _schedule_tokens(parser: _NPBHtmlParser) -> list[str]:
    marker = next(
        (index for index, token in enumerate(parser.tokens) if "Regular Season (Schedules)" in token),
        -1,
    )
    if marker < 0:
        return []
    tokens = parser.tokens[marker + 1 :]
    for index, token in enumerate(tokens):
        if token.startswith("Copyright"):
            return tokens[:index]
    return tokens


def _parse_schedule_tokens(
    parser: _NPBHtmlParser,
    target_date: date,
    source_url: str,
    now: datetime,
) -> list[dict[str, Any]]:
    tokens = _schedule_tokens(parser)
    games: list[dict[str, Any]] = []
    seen: set[str] = set()
    headings = {
        "CENTRAL LEAGUE",
        "PACIFIC LEAGUE",
        "Prev. Games",
        "Next Games",
        "Regular Season",
        "Schedules/Scores",
    }
    i = 0
    while i < len(tokens):
        token = tokens[i]
        if token not in TEAM_BY_SHORT:
            i += 1
            continue
        away = token
        venue_parts: list[str] = []
        japan_time: str | None = None
        postponed_reason: str | None = None
        j = i + 1
        while j < len(tokens) and j <= i + 12:
            current = tokens[j]
            if current in TEAM_BY_SHORT:
                break
            if TIME_RE.match(current):
                japan_time = current
                j += 1
                break
            if current.lower() in {"rained out", "cancelled", "canceled", "postponed"}:
                postponed_reason = current
            elif current not in headings and not current.startswith("Image:") and not re.match(r"^[A-Z][a-z]+day,", current):
                venue_parts.append(current)
            j += 1
        while j < len(tokens) and tokens[j] not in TEAM_BY_SHORT:
            j += 1
        if j >= len(tokens):
            i += 1
            continue
        home = tokens[j]
        game_id = _stable_game_id(target_date, away, home)
        if game_id not in seen:
            seen.add(game_id)
            start = _start_datetime(target_date, japan_time)
            if postponed_reason:
                status, detail = "postponed", postponed_reason
            else:
                status, detail = _status_from_schedule(start, now)
            games.append(
                _game_payload(
                    target_date,
                    away,
                    home,
                    venue=" ".join(venue_parts).strip(),
                    japan_time=japan_time,
                    status=status,
                    detailed_status=detail,
                    source_url=source_url,
                )
            )
        i = j + 1
    return games


def parse_npb_daily_page(
    page_html: str,
    target_date: date,
    source_url: str,
    *,
    now: datetime | None = None,
) -> list[dict[str, Any]]:
    parser = _NPBHtmlParser()
    parser.feed(page_html)
    completed = _parse_score_links(parser, target_date, source_url)
    if completed:
        return sorted(completed, key=lambda game: game["game_pk"])
    return _parse_schedule_tokens(parser, target_date, source_url, now or datetime.now(TAIPEI))


class NPBService:
    def __init__(self, settings: Settings, transport: httpx.AsyncBaseTransport | None = None) -> None:
        self.settings = settings
        self.cache = AsyncTTLCache()
        self.client = httpx.AsyncClient(
            timeout=settings.request_timeout_seconds,
            follow_redirects=True,
            trust_env=False,
            transport=transport,
            headers={
                "User-Agent": "DiamondMind/18.2 (+schedule adapter; contact via configured support email)",
                "Accept": "text/html,application/xhtml+xml",
                "Accept-Language": "en-US,en;q=0.9",
            },
        )

    async def aclose(self) -> None:
        await self.client.aclose()

    def daily_url(self, target_date: date) -> str:
        return f"{self.settings.npb_official_base}/bis/eng/{target_date.year}/games/gm{target_date:%Y%m%d}.html"

    async def _get_html(self, url: str) -> HtmlPayload:
        cached = self.cache.get(url)
        if cached and cached.is_fresh:
            return HtmlPayload(cached.value, "hit", _iso_timestamp(cached.stored_at), url)
        async with self.cache.lock(url):
            cached = self.cache.get(url)
            if cached and cached.is_fresh:
                return HtmlPayload(cached.value, "hit", _iso_timestamp(cached.stored_at), url)
            try:
                response = await self.client.get(url)
                response.raise_for_status()
                body = response.text
                if "Nippon Professional Baseball" not in body and "Regular Season" not in body:
                    raise ValueError("Unexpected NPB response")
                entry = self.cache.set(
                    url,
                    body,
                    self.settings.npb_cache_ttl_seconds,
                    self.settings.npb_stale_ttl_seconds,
                )
                return HtmlPayload(body, "miss", _iso_timestamp(entry.stored_at), url)
            except (httpx.HTTPError, ValueError) as exc:
                if cached and cached.can_serve_stale:
                    return HtmlPayload(cached.value, "stale", _iso_timestamp(cached.stored_at), url)
                raise NPBUpstreamError("NPB 官方賽程目前暫時無法連線") from exc

    async def games_for_date(self, target_date: date) -> dict[str, Any]:
        source_url = self.daily_url(target_date)
        payload = await self._get_html(source_url)
        items = parse_npb_daily_page(payload.text, target_date, source_url)
        items.sort(key=lambda item: (item.get("game_date") or "", item.get("game_pk") or ""))
        return {
            "league": "NPB",
            "date": target_date.isoformat(),
            "timezone": "Asia/Taipei",
            "count": len(items),
            "items": items,
            "capabilities": {
                "schedule": True,
                "scores": True,
                "live_status": "beta",
                "probable_pitchers": False,
                "analysis": False,
                "predictions": False,
                "settlement": False,
            },
            "meta": {
                "source": "NPB.jp official Schedules/Scores",
                "source_url": source_url,
                "cache": payload.cache_status,
                "updated_at": payload.fetched_at,
                "phase": "V18.2 NPB schedule beta",
            },
        }
