from __future__ import annotations

import asyncio
import html
import re
from dataclasses import dataclass
from datetime import date, datetime, time, timedelta
from html.parser import HTMLParser
from typing import Any
from urllib.parse import urljoin
from zoneinfo import ZoneInfo

import httpx

from .cache import AsyncTTLCache
from .config import Settings


TAIPEI = ZoneInfo("Asia/Taipei")
TOKYO = ZoneInfo("Asia/Tokyo")


class NPBUpstreamError(RuntimeError):
    pass


@dataclass
class HtmlPayload:
    text: str
    cache_status: str
    fetched_at: str
    source_url: str


@dataclass(frozen=True)
class TeamInfo:
    canonical: str
    short: str
    abbr: str
    zh: str


TEAM_BY_SHORT: dict[str, TeamInfo] = {
    "Yakult": TeamInfo("Tokyo Yakult Swallows", "Yakult", "S", "東京養樂多燕子"),
    "Yomiuri": TeamInfo("Yomiuri Giants", "Yomiuri", "G", "讀賣巨人"),
    "DeNA": TeamInfo("YOKOHAMA DeNA BAYSTARS", "DeNA", "DB", "橫濱DeNA海灣之星"),
    "Chunichi": TeamInfo("Chunichi Dragons", "Chunichi", "D", "中日龍"),
    "Hanshin": TeamInfo("Hanshin Tigers", "Hanshin", "T", "阪神虎"),
    "Hiroshima": TeamInfo("Hiroshima Toyo Carp", "Hiroshima", "C", "廣島東洋鯉魚"),
    "SoftBank": TeamInfo("Fukuoka SoftBank Hawks", "SoftBank", "H", "福岡軟銀鷹"),
    "Nippon-Ham": TeamInfo("Hokkaido Nippon-Ham Fighters", "Nippon-Ham", "F", "北海道日本火腿鬥士"),
    "ORIX": TeamInfo("ORIX Buffaloes", "ORIX", "B", "歐力士猛牛"),
    "Rakuten": TeamInfo("Tohoku Rakuten Golden Eagles", "Rakuten", "E", "東北樂天金鷲"),
    "Seibu": TeamInfo("Saitama Seibu Lions", "Seibu", "L", "埼玉西武獅"),
    "Lotte": TeamInfo("Chiba Lotte Marines", "Lotte", "M", "千葉羅德海洋"),
    "CL": TeamInfo("Central League All-Stars", "CL", "CL", "中央聯盟明星隊"),
    "PL": TeamInfo("Pacific League All-Stars", "PL", "PL", "太平洋聯盟明星隊"),
}

TEAM_NAMES = sorted(TEAM_BY_SHORT, key=len, reverse=True)
TEAM_ALT = "|".join(re.escape(name) for name in TEAM_NAMES)

URL_CODE_TO_SHORT: dict[str, str] = {
    "s": "Yakult",
    "g": "Yomiuri",
    "db": "DeNA",
    "d": "Chunichi",
    "t": "Hanshin",
    "c": "Hiroshima",
    "h": "SoftBank",
    "f": "Nippon-Ham",
    "b": "ORIX",
    "e": "Rakuten",
    "l": "Seibu",
    "m": "Lotte",
}
JAPANESE_TEAM_TO_SHORT: dict[str, str] = {
    "東京ヤクルトスワローズ": "Yakult",
    "ヤクルト": "Yakult",
    "読売ジャイアンツ": "Yomiuri",
    "巨人": "Yomiuri",
    "横浜DeNAベイスターズ": "DeNA",
    "横浜ＤｅＮＡベイスターズ": "DeNA",
    "DeNA": "DeNA",
    "中日ドラゴンズ": "Chunichi",
    "中日": "Chunichi",
    "阪神タイガース": "Hanshin",
    "阪神": "Hanshin",
    "広島東洋カープ": "Hiroshima",
    "広島": "Hiroshima",
    "福岡ソフトバンクホークス": "SoftBank",
    "ソフトバンク": "SoftBank",
    "北海道日本ハムファイターズ": "Nippon-Ham",
    "日本ハム": "Nippon-Ham",
    "オリックス・バファローズ": "ORIX",
    "オリックス": "ORIX",
    "東北楽天ゴールデンイーグルス": "Rakuten",
    "楽天": "Rakuten",
    "埼玉西武ライオンズ": "Seibu",
    "西武": "Seibu",
    "千葉ロッテマリーンズ": "Lotte",
    "ロッテ": "Lotte",
}
CENTRAL_TEAMS = {"Hanshin", "Yomiuri", "Yakult", "DeNA", "Hiroshima", "Chunichi"}
PACIFIC_TEAMS = {"SoftBank", "Seibu", "Nippon-Ham", "ORIX", "Lotte", "Rakuten"}
STANDINGS_RE = re.compile(
    rf"(?P<team>{TEAM_ALT})\s+(?P=team)\s+(?P<games>\d{{1,3}})\s+"
    rf"(?P<wins>\d{{1,3}})\s+(?P<losses>\d{{1,3}})\s+(?P<ties>\d{{1,3}})\s+"
    rf"(?P<pct>\.\d{{3}})\s+(?P<gb>-|\d+(?:\.\d+)?)",
    re.IGNORECASE,
)
STARTER_HEADING_RE = re.compile(r"(?P<month>\d{1,2})月(?P<day>\d{1,2})日の予告先発投手")
STARTER_VENUE_TIME_RE = re.compile(r"^[（(].+[）)]\s*\d{1,2}:\d{2}$")
JAPANESE_SCORE_HREF_RE = re.compile(
    r"/scores/(?P<year>\d{4})/(?P<mmdd>\d{4})/(?P<home>[a-z]+)-(?P<away>[a-z]+)-(?P<series>\d+)(?:/|$)",
    re.IGNORECASE,
)
JAPANESE_SCORE_RE = re.compile(r"(?P<home_score>\d+)\s*[-－]\s*(?P<away_score>\d+)")
JAPANESE_VENUE_RE = re.compile(r"[（(](?P<venue>[^）)]+)[）)]")
JAPANESE_INNING_RE = re.compile(r"(?P<inning>\d+)\s*回\s*(?P<half>表|裏)")
TIME_RE = re.compile(r"^(?:[01]?\d|2[0-3]):[0-5]\d$")
SCORE_RE = re.compile(
    rf"^(?P<home>{TEAM_ALT})\s+(?P<home_score>\d+)\s+Game\s+\d+\s+(?P<venue>.+?)\s+(?P<away_score>\d+)\s+(?P<away>{TEAM_ALT})$",
    re.IGNORECASE,
)
POSTPONED_RE = re.compile(
    rf"^(?P<home>{TEAM_ALT})\s+(?P<reason>Rained Out|Cancelled|Canceled|Postponed)\s+(?P<away>{TEAM_ALT})$",
    re.IGNORECASE,
)


class _NPBHtmlParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.tokens: list[str] = []
        self.links: list[tuple[str, str]] = []
        self._href: str | None = None
        self._anchor_parts: list[str] = []

    @staticmethod
    def _clean(value: str) -> str:
        return re.sub(r"\s+", " ", html.unescape(value or "")).strip()

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag.lower() == "a":
            self._href = dict(attrs).get("href") or ""
            self._anchor_parts = []

    def handle_data(self, data: str) -> None:
        cleaned = self._clean(data)
        if not cleaned:
            return
        self.tokens.append(cleaned)
        if self._href is not None:
            self._anchor_parts.append(cleaned)

    def handle_endtag(self, tag: str) -> None:
        if tag.lower() == "a" and self._href is not None:
            text = self._clean(" ".join(self._anchor_parts))
            if text:
                self.links.append((self._href, text))
            self._href = None
            self._anchor_parts = []


class _NPBStarterHtmlParser(_NPBHtmlParser):
    """HTML parser that also captures team names stored in image alt attributes."""

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        super().handle_starttag(tag, attrs)
        if tag.lower() != "img":
            return
        alt = self._clean(dict(attrs).get("alt") or "")
        if alt:
            self.tokens.append(alt)


def parse_npb_probable_starters(
    page_html: str,
    target_date: date,
    source_url: str,
) -> dict[str, Any]:
    parser = _NPBStarterHtmlParser()
    parser.feed(page_html)
    tokens = parser.tokens
    year = target_date.year
    for token in tokens[:30]:
        if re.fullmatch(r"20\d{2}", token):
            year = int(token)
            break
    heading_index = -1
    announced_date: date | None = None
    for index, token in enumerate(tokens):
        match = STARTER_HEADING_RE.search(token)
        if not match:
            continue
        try:
            announced_date = date(year, int(match.group("month")), int(match.group("day")))
        except ValueError:
            announced_date = None
        heading_index = index
        break
    if heading_index < 0 or announced_date != target_date:
        return {"date": announced_date.isoformat() if announced_date else None, "by_team": {}, "source_url": source_url}

    by_team: dict[str, dict[str, Any]] = {}
    ignored = {
        "セントラル・リーグ", "パシフィック・リーグ", "侍ジャパン",
        "日本野球機構", "公示", "サブメニュー", "予告先発投手",
    }
    i = heading_index + 1
    while i < len(tokens):
        token = tokens[i]
        if token.startswith("Copyright"):
            break
        short = JAPANESE_TEAM_TO_SHORT.get(token)
        if not short:
            i += 1
            continue
        pitcher = ""
        j = i + 1
        while j < len(tokens):
            candidate = tokens[j].strip()
            if JAPANESE_TEAM_TO_SHORT.get(candidate):
                break
            if candidate.startswith("Copyright"):
                break
            if candidate in ignored or STARTER_HEADING_RE.search(candidate) or STARTER_VENUE_TIME_RE.match(candidate):
                j += 1
                continue
            if re.fullmatch(r"\d{1,2}:\d{2}", candidate) or candidate.startswith("Image:"):
                j += 1
                continue
            if len(candidate) <= 80:
                pitcher = candidate
                break
            j += 1
        if pitcher and short not in by_team:
            by_team[short] = {
                "name": pitcher,
                "announced": True,
                "source": "NPB official probable starters",
                "source_url": source_url,
            }
        i += 1
    return {"date": announced_date.isoformat(), "by_team": by_team, "source_url": source_url}


def parse_npb_standings(page_html: str, source_url: str) -> dict[str, Any]:
    parser = _NPBHtmlParser()
    parser.feed(page_html)
    flattened = " ".join(parser.tokens)
    leagues: dict[str, list[dict[str, Any]]] = {"Central League": [], "Pacific League": []}
    by_team: dict[str, dict[str, Any]] = {}
    for match in STANDINGS_RE.finditer(flattened):
        raw_team = match.group("team")
        short = next((name for name in TEAM_NAMES if name.lower() == raw_team.lower()), None)
        if not short or short in by_team:
            continue
        league = "Central League" if short in CENTRAL_TEAMS else "Pacific League"
        row = {
            "team": short,
            "team_name": TEAM_BY_SHORT[short].canonical,
            "team_name_zh": TEAM_BY_SHORT[short].zh,
            "abbr": TEAM_BY_SHORT[short].abbr,
            "league": league,
            "games": int(match.group("games")),
            "wins": int(match.group("wins")),
            "losses": int(match.group("losses")),
            "ties": int(match.group("ties")),
            "pct": float(match.group("pct")),
            "pct_display": match.group("pct"),
            "games_back": match.group("gb"),
            "source_url": source_url,
        }
        leagues[league].append(row)
        by_team[short] = row
    for league_rows in leagues.values():
        for rank, row in enumerate(league_rows, start=1):
            row["rank"] = rank
    return {"leagues": leagues, "by_team": by_team, "source_url": source_url}


def _apply_probable_starters(items: list[dict[str, Any]], starter_data: dict[str, Any]) -> None:
    by_team = starter_data.get("by_team") or {}
    for game in items:
        for side in ("away", "home"):
            team = game.get(side) or {}
            short = team.get("short_name")
            starter = by_team.get(short)
            if starter:
                team["probable_pitcher"] = {"id": None, **starter}


def _apply_standings(items: list[dict[str, Any]], standings_data: dict[str, Any]) -> None:
    by_team = standings_data.get("by_team") or {}
    for game in items:
        for side in ("away", "home"):
            team = game.get(side) or {}
            short = team.get("short_name")
            record = by_team.get(short)
            if record:
                team["record"] = {key: value for key, value in record.items() if key != "source_url"}


def _iso_timestamp(epoch: float) -> str:
    return datetime.fromtimestamp(epoch, tz=TAIPEI).isoformat()


def _team_payload(short_name: str, score: int | None = None) -> dict[str, Any]:
    team = TEAM_BY_SHORT[short_name]
    return {
        "id": team.abbr,
        "name": team.canonical,
        "short_name": team.short,
        "name_zh": team.zh,
        "abbr": team.abbr,
        "score": score,
        "probable_pitcher": {"id": None, "name": "尚未公布"},
    }


def _stable_game_id(target_date: date, away: str, home: str) -> str:
    return f"npb_{target_date:%Y%m%d}_{TEAM_BY_SHORT[away].abbr}_{TEAM_BY_SHORT[home].abbr}"


def _start_datetime(target_date: date, japan_time: str | None) -> datetime | None:
    if not japan_time or not TIME_RE.match(japan_time):
        return None
    hour, minute = map(int, japan_time.split(":"))
    return datetime.combine(target_date, time(hour, minute), tzinfo=TOKYO)


def _status_from_schedule(start: datetime | None, now: datetime) -> tuple[str, str]:
    if start is None:
        return "upcoming", "Scheduled"
    now_tokyo = now.astimezone(TOKYO)
    if now_tokyo < start:
        return "upcoming", "Scheduled"
    if now_tokyo <= start + timedelta(hours=5):
        return "live", "In Progress"
    return "upcoming", "Awaiting official result"


def _game_payload(
    target_date: date,
    away: str,
    home: str,
    *,
    venue: str = "",
    japan_time: str | None = None,
    away_score: int | None = None,
    home_score: int | None = None,
    status: str = "upcoming",
    detailed_status: str = "Scheduled",
    source_url: str,
    detail_url: str | None = None,
) -> dict[str, Any]:
    start = _start_datetime(target_date, japan_time)
    taipei_start = start.astimezone(TAIPEI) if start else None
    return {
        "league": "NPB",
        "season": target_date.year,
        "game_pk": _stable_game_id(target_date, away, home),
        "external_game_id": _stable_game_id(target_date, away, home),
        "game_date": start.isoformat() if start else f"{target_date.isoformat()}T12:00:00+09:00",
        "date_taiwan": taipei_start.date().isoformat() if taipei_start else target_date.isoformat(),
        "time_taiwan": taipei_start.strftime("%H:%M") if taipei_start else "",
        "time_japan": japan_time or "",
        "status": status,
        "detailed_status": detailed_status,
        "inning": None,
        "inning_state": "",
        "venue_id": None,
        "venue": venue,
        "game_type": "regular_season",
        "season_context": "regular_season",
        "event_label": "NPB 例行賽",
        "is_special_event": False,
        "analysis_available": False,
        "analysis_status": "schedule_only",
        "away": _team_payload(away, away_score),
        "home": _team_payload(home, home_score),
        "source_url": detail_url or source_url,
        "official_schedule_url": source_url,
    }


def _parse_score_links(parser: _NPBHtmlParser, target_date: date, source_url: str) -> list[dict[str, Any]]:
    games: list[dict[str, Any]] = []
    seen: set[str] = set()
    for href, label in parser.links:
        cleaned = re.sub(r"\s+", " ", label).strip()
        match = SCORE_RE.match(cleaned)
        if match:
            away = next(name for name in TEAM_NAMES if name.lower() == match.group("away").lower())
            home = next(name for name in TEAM_NAMES if name.lower() == match.group("home").lower())
            game_id = _stable_game_id(target_date, away, home)
            if game_id in seen:
                continue
            seen.add(game_id)
            games.append(
                _game_payload(
                    target_date,
                    away,
                    home,
                    venue=match.group("venue").strip(),
                    away_score=int(match.group("away_score")),
                    home_score=int(match.group("home_score")),
                    status="final",
                    detailed_status="Final",
                    source_url=source_url,
                    detail_url=urljoin(source_url, href),
                )
            )
            continue
        postponed = POSTPONED_RE.match(cleaned)
        if postponed:
            away = next(name for name in TEAM_NAMES if name.lower() == postponed.group("away").lower())
            home = next(name for name in TEAM_NAMES if name.lower() == postponed.group("home").lower())
            game_id = _stable_game_id(target_date, away, home)
            if game_id in seen:
                continue
            seen.add(game_id)
            games.append(
                _game_payload(
                    target_date,
                    away,
                    home,
                    status="postponed",
                    detailed_status=postponed.group("reason"),
                    source_url=source_url,
                    detail_url=urljoin(source_url, href),
                )
            )
    return games


def parse_npb_japanese_scoreboard(
    page_html: str,
    target_date: date,
    source_url: str,
) -> list[dict[str, Any]]:
    parser = _NPBHtmlParser()
    parser.feed(page_html)
    games: list[dict[str, Any]] = []
    seen: set[str] = set()
    for href, label in parser.links:
        href_match = JAPANESE_SCORE_HREF_RE.search(href or "")
        if not href_match:
            continue
        try:
            link_date = date(
                int(href_match.group("year")),
                int(href_match.group("mmdd")[:2]),
                int(href_match.group("mmdd")[2:]),
            )
        except ValueError:
            continue
        if link_date != target_date:
            continue
        home = URL_CODE_TO_SHORT.get(href_match.group("home").lower())
        away = URL_CODE_TO_SHORT.get(href_match.group("away").lower())
        if not home or not away:
            continue
        game_id = _stable_game_id(target_date, away, home)
        if game_id in seen:
            continue
        cleaned = re.sub(r"\s+", " ", label or "").strip()
        score_match = JAPANESE_SCORE_RE.search(cleaned)
        venue_match = JAPANESE_VENUE_RE.search(cleaned)
        inning_match = JAPANESE_INNING_RE.search(cleaned)
        status = "upcoming"
        detailed_status = cleaned or "Scheduled"
        inning: int | None = None
        inning_state = ""
        if "試合終了" in cleaned:
            status = "final"
            detailed_status = "Final"
        elif any(word in cleaned for word in ("中止", "雨天中止", "延期")):
            status = "postponed"
            detailed_status = "Postponed"
        elif score_match or inning_match:
            status = "live"
            detailed_status = cleaned or "In Progress"
            if inning_match:
                inning = int(inning_match.group("inning"))
                inning_state = "Top" if inning_match.group("half") == "表" else "Bottom"
        games.append(
            {
                "league": "NPB",
                "game_pk": game_id,
                "external_game_id": game_id,
                "status": status,
                "detailed_status": detailed_status,
                "inning": inning,
                "inning_state": inning_state,
                "venue": venue_match.group("venue").strip() if venue_match else "",
                "away": _team_payload(away, int(score_match.group("away_score")) if score_match else None),
                "home": _team_payload(home, int(score_match.group("home_score")) if score_match else None),
                "source_url": urljoin(source_url, href),
            }
        )
        seen.add(game_id)
    return games


def _merge_scoreboard(
    scheduled: list[dict[str, Any]],
    scoreboard: list[dict[str, Any]],
    target_date: date,
    source_url: str,
) -> list[dict[str, Any]]:
    overlays = {item["game_pk"]: item for item in scoreboard}
    merged: list[dict[str, Any]] = []
    scheduled_ids: set[str] = set()
    for game in scheduled:
        game_id = game.get("game_pk")
        scheduled_ids.add(game_id)
        overlay = overlays.get(game_id)
        if overlay:
            game["status"] = overlay.get("status") or game.get("status")
            game["detailed_status"] = overlay.get("detailed_status") or game.get("detailed_status")
            game["inning"] = overlay.get("inning")
            game["inning_state"] = overlay.get("inning_state") or ""
            if overlay.get("venue"):
                game["venue"] = overlay["venue"]
            game["away"]["score"] = overlay.get("away", {}).get("score")
            game["home"]["score"] = overlay.get("home", {}).get("score")
            game["source_url"] = overlay.get("source_url") or game.get("source_url")
        merged.append(game)
    for game_id, overlay in overlays.items():
        if game_id in scheduled_ids:
            continue
        away = overlay["away"]["short_name"]
        home = overlay["home"]["short_name"]
        merged.append(
            _game_payload(
                target_date,
                away,
                home,
                venue=overlay.get("venue", ""),
                away_score=overlay["away"].get("score"),
                home_score=overlay["home"].get("score"),
                status=overlay.get("status", "upcoming"),
                detailed_status=overlay.get("detailed_status", "Scheduled"),
                source_url=source_url,
                detail_url=overlay.get("source_url"),
            )
        )
        merged[-1]["inning"] = overlay.get("inning")
        merged[-1]["inning_state"] = overlay.get("inning_state") or ""
    return merged


def _schedule_tokens(parser: _NPBHtmlParser) -> list[str]:
    marker = next(
        (index for index, token in enumerate(parser.tokens) if "Regular Season (Schedules)" in token),
        -1,
    )
    if marker < 0:
        return []
    tokens = parser.tokens[marker + 1 :]
    for index, token in enumerate(tokens):
        if token.startswith("Copyright"):
            return tokens[:index]
    return tokens


def _parse_schedule_tokens(
    parser: _NPBHtmlParser,
    target_date: date,
    source_url: str,
    now: datetime,
) -> list[dict[str, Any]]:
    tokens = _schedule_tokens(parser)
    games: list[dict[str, Any]] = []
    seen: set[str] = set()
    headings = {
        "CENTRAL LEAGUE",
        "PACIFIC LEAGUE",
        "Prev. Games",
        "Next Games",
        "Regular Season",
        "Schedules/Scores",
    }
    i = 0
    while i < len(tokens):
        token = tokens[i]
        if token not in TEAM_BY_SHORT:
            i += 1
            continue
        home = token
        venue_parts: list[str] = []
        japan_time: str | None = None
        postponed_reason: str | None = None
        j = i + 1
        while j < len(tokens) and j <= i + 12:
            current = tokens[j]
            if current in TEAM_BY_SHORT:
                break
            if TIME_RE.match(current):
                japan_time = current
                j += 1
                break
            if current.lower() in {"rained out", "cancelled", "canceled", "postponed"}:
                postponed_reason = current
            elif current not in headings and not current.startswith("Image:") and not re.match(r"^[A-Z][a-z]+day,", current):
                venue_parts.append(current)
            j += 1
        while j < len(tokens) and tokens[j] not in TEAM_BY_SHORT:
            j += 1
        if j >= len(tokens):
            i += 1
            continue
        away = tokens[j]
        game_id = _stable_game_id(target_date, away, home)
        if game_id not in seen:
            seen.add(game_id)
            start = _start_datetime(target_date, japan_time)
            if postponed_reason:
                status, detail = "postponed", postponed_reason
            else:
                status, detail = _status_from_schedule(start, now)
            games.append(
                _game_payload(
                    target_date,
                    away,
                    home,
                    venue=" ".join(venue_parts).strip(),
                    japan_time=japan_time,
                    status=status,
                    detailed_status=detail,
                    source_url=source_url,
                )
            )
        i = j + 1
    return games


def parse_npb_daily_page(
    page_html: str,
    target_date: date,
    source_url: str,
    *,
    now: datetime | None = None,
) -> list[dict[str, Any]]:
    parser = _NPBHtmlParser()
    parser.feed(page_html)
    completed = _parse_score_links(parser, target_date, source_url)
    if completed:
        return sorted(completed, key=lambda game: game["game_pk"])
    return _parse_schedule_tokens(parser, target_date, source_url, now or datetime.now(TAIPEI))


class NPBService:
    def __init__(self, settings: Settings, transport: httpx.AsyncBaseTransport | None = None) -> None:
        self.settings = settings
        self.cache = AsyncTTLCache()
        self.client = httpx.AsyncClient(
            timeout=settings.request_timeout_seconds,
            follow_redirects=True,
            trust_env=False,
            transport=transport,
            headers={
                "User-Agent": "DiamondMind/18.3.0 (+NPB starters and standings; contact via configured support email)",
                "Accept": "text/html,application/xhtml+xml",
                "Accept-Language": "en-US,en;q=0.9",
            },
        )

    async def aclose(self) -> None:
        await self.client.aclose()

    def daily_url(self, target_date: date) -> str:
        return f"{self.settings.npb_official_base}/bis/eng/{target_date.year}/games/gm{target_date:%Y%m%d}.html"

    def monthly_url(self, target_date: date) -> str:
        return f"{self.settings.npb_official_base}/games/{target_date.year}/schedule_{target_date:%m}_detail.html"

    def starter_url(self) -> str:
        return f"{self.settings.npb_official_base}/announcement/starter/"

    def standings_url(self, season: int) -> str:
        return f"{self.settings.npb_official_base}/bis/eng/{season}/stats/"

    async def _get_html(self, url: str) -> HtmlPayload:
        cached = self.cache.get(url)
        if cached and cached.is_fresh:
            return HtmlPayload(cached.value, "hit", _iso_timestamp(cached.stored_at), url)
        async with self.cache.lock(url):
            cached = self.cache.get(url)
            if cached and cached.is_fresh:
                return HtmlPayload(cached.value, "hit", _iso_timestamp(cached.stored_at), url)
            try:
                response = await self.client.get(url)
                response.raise_for_status()
                body = response.text
                expected_markers = ("Nippon Professional Baseball", "Regular Season", "日本野球機構", "予告先発")
                if not any(marker in body for marker in expected_markers):
                    raise ValueError("Unexpected NPB response")
                entry = self.cache.set(
                    url,
                    body,
                    self.settings.npb_cache_ttl_seconds,
                    self.settings.npb_stale_ttl_seconds,
                )
                return HtmlPayload(body, "miss", _iso_timestamp(entry.stored_at), url)
            except (httpx.HTTPError, ValueError) as exc:
                if cached and cached.can_serve_stale:
                    return HtmlPayload(cached.value, "stale", _iso_timestamp(cached.stored_at), url)
                raise NPBUpstreamError("NPB 官方賽程目前暫時無法連線") from exc

    async def standings_for_season(self, season: int) -> dict[str, Any]:
        url = self.standings_url(season)
        payload = await self._get_html(url)
        parsed = parse_npb_standings(payload.text, url)
        return {
            "league": "NPB",
            "season": season,
            "leagues": parsed["leagues"],
            "count": len(parsed["by_team"]),
            "meta": {
                "source": "NPB.jp official standings",
                "source_url": url,
                "cache": payload.cache_status,
                "updated_at": payload.fetched_at,
            },
        }

    async def games_for_date(self, target_date: date) -> dict[str, Any]:
        source_url = self.daily_url(target_date)
        result_url = self.monthly_url(target_date)
        starter_url = self.starter_url()
        standings_url = self.standings_url(target_date.year)

        payload = await self._get_html(source_url)
        items = parse_npb_daily_page(payload.text, target_date, source_url)
        result_payload: HtmlPayload | None = None
        starter_payload: HtmlPayload | None = None
        standings_payload: HtmlPayload | None = None
        starter_data: dict[str, Any] = {"date": None, "by_team": {}, "source_url": starter_url}
        standings_data: dict[str, Any] = {"leagues": {}, "by_team": {}, "source_url": standings_url}

        async def optional_fetch(url: str) -> HtmlPayload | None:
            try:
                return await self._get_html(url)
            except NPBUpstreamError:
                return None

        result_payload, starter_payload, standings_payload = await asyncio.gather(
            optional_fetch(result_url),
            optional_fetch(starter_url),
            optional_fetch(standings_url),
        )
        if result_payload:
            scoreboard = parse_npb_japanese_scoreboard(result_payload.text, target_date, result_url)
            items = _merge_scoreboard(items, scoreboard, target_date, source_url)
        if starter_payload:
            starter_data = parse_npb_probable_starters(starter_payload.text, target_date, starter_url)
            _apply_probable_starters(items, starter_data)
        if standings_payload:
            standings_data = parse_npb_standings(standings_payload.text, standings_url)
            _apply_standings(items, standings_data)

        items.sort(key=lambda item: (item.get("game_date") or "", item.get("game_pk") or ""))
        payloads = [item for item in (payload, result_payload, starter_payload, standings_payload) if item]
        cache_states = [item.cache_status for item in payloads]
        cache_status = "stale" if "stale" in cache_states else ("hit" if cache_states and all(state == "hit" for state in cache_states) else "miss")
        announced_count = sum(
            1
            for game in items
            for side in ("away", "home")
            if (game.get(side) or {}).get("probable_pitcher", {}).get("announced")
        )
        return {
            "league": "NPB",
            "date": target_date.isoformat(),
            "timezone": "Asia/Taipei",
            "count": len(items),
            "items": items,
            "standings": standings_data.get("leagues") or {},
            "capabilities": {
                "schedule": True,
                "scores": True,
                "live_status": "beta",
                "probable_pitchers": announced_count > 0,
                "standings": bool(standings_data.get("by_team")),
                "analysis": False,
                "predictions": False,
                "settlement": False,
            },
            "meta": {
                "source": "NPB.jp official schedule, live scoreboard, probable starters and standings",
                "source_url": source_url,
                "result_source_url": result_url,
                "starter_source_url": starter_url,
                "standings_source_url": standings_url,
                "starter_date": starter_data.get("date"),
                "announced_starters": announced_count,
                "cache": cache_status,
                "updated_at": max((item.fetched_at for item in payloads), default=payload.fetched_at),
                "phase": "V18.3 NPB starters and standings",
            },
        }

