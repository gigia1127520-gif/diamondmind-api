from __future__ import annotations

import asyncio
from datetime import date, datetime, time, timedelta
from typing import Any, Awaitable
from zoneinfo import ZoneInfo

from .config import Settings
from .mlb import MLBService, MLBUpstreamError
from .npb import NPBService, NPBUpstreamError
from .odds import OddsService
from .records import RecordsStorageError, SupabaseRecordsRepository, package_from_record


TAIPEI = ZoneInfo("Asia/Taipei")


def _parse_datetime(value: Any) -> datetime | None:
    if not isinstance(value, str) or not value.strip():
        return None
    try:
        parsed = datetime.fromisoformat(value.strip().replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=TAIPEI)
    return parsed.astimezone(TAIPEI)


def _parse_date(value: Any) -> date | None:
    if not isinstance(value, str) or not value.strip():
        return None
    try:
        return date.fromisoformat(value.strip()[:10])
    except ValueError:
        return None


def _age_minutes(value: Any, now: datetime) -> float | None:
    parsed = _parse_datetime(value)
    if parsed is None:
        return None
    return max(0.0, (now - parsed).total_seconds() / 60.0)


def _game_start(value: dict[str, Any]) -> datetime | None:
    return _parse_datetime(value.get("game_date") or value.get("game_datetime"))


def _package_selections(record: dict[str, Any]) -> list[dict[str, Any]]:
    package = package_from_record(record)
    selections: list[dict[str, Any]] = []
    for key in ("moneylines", "run_lines", "totals"):
        selections.extend(item for item in (package.get(key) or []) if isinstance(item, dict))
    for key in ("two_leg", "three_leg"):
        for parlay in (package.get("parlays") or {}).get(key) or []:
            selections.extend(item for item in (parlay.get("legs") or []) if isinstance(item, dict))
    return selections


def _fallback_deadline(recommendation_date: Any, grace_hours: int) -> datetime | None:
    parsed = _parse_date(recommendation_date)
    if parsed is None:
        return None
    # A baseball day can extend past midnight. 08:00 the following morning is
    # deliberately conservative before the additional settlement grace period.
    return datetime.combine(parsed + timedelta(days=1), time(8, 0), TAIPEI) + timedelta(hours=grace_hours)


def _record_deadline(record: dict[str, Any], grace_hours: int) -> datetime | None:
    start = _parse_datetime(record.get("game_datetime"))
    return start + timedelta(hours=grace_hours) if start else _fallback_deadline(record.get("recommendation_date"), grace_hours)


def _package_deadline(record: dict[str, Any], grace_hours: int) -> datetime | None:
    starts = [start for start in (_game_start(item) for item in _package_selections(record)) if start]
    if starts:
        return max(starts) + timedelta(hours=grace_hours)
    return _fallback_deadline(record.get("recommendation_date"), grace_hours)


def _upcoming_within(items: list[dict[str, Any]], now: datetime, minutes: int) -> list[dict[str, Any]]:
    limit = now + timedelta(minutes=max(1, minutes))
    upcoming: list[dict[str, Any]] = []
    for game in items:
        if str(game.get("status") or "").lower() == "final":
            continue
        start = _game_start(game)
        if start and now - timedelta(minutes=30) <= start <= limit:
            upcoming.append(game)
    return upcoming


def _bump_failure(counters: dict[str, int], key: str, failed: bool) -> int:
    value = int(counters.get(key, 0) or 0)
    counters[key] = value + 1 if failed else 0
    return counters[key]


async def _probe(name: str, call: Awaitable[dict[str, Any]]) -> tuple[str, dict[str, Any]]:
    try:
        payload = await call
        return name, {"ok": True, "payload": payload}
    except (MLBUpstreamError, NPBUpstreamError, TimeoutError, OSError) as exc:
        return name, {"ok": False, "error": type(exc).__name__, "detail": str(exc)[:240]}
    except Exception as exc:  # Operational monitor must report, not crash the API.
        return name, {"ok": False, "error": type(exc).__name__, "detail": str(exc)[:240]}


async def probe_league_sources(
    mlb: MLBService,
    npb: NPBService,
    target_date: date,
) -> dict[str, dict[str, Any]]:
    results = await asyncio.gather(
        _probe("MLB", mlb.games_for_date(target_date)),
        _probe("NPB", npb.games_for_date(target_date)),
    )
    return dict(results)


async def build_operations_report(
    *,
    repository: SupabaseRecordsRepository,
    odds: OddsService,
    source_probes: dict[str, dict[str, Any]],
    failure_counters: dict[str, int],
    settings: Settings,
    now: datetime | None = None,
) -> dict[str, Any]:
    now = (now or datetime.now(TAIPEI)).astimezone(TAIPEI)
    checks: list[dict[str, Any]] = []
    critical_issues: list[dict[str, Any]] = []
    warnings: list[dict[str, Any]] = []

    try:
        pending_free, pending_packages, today_package = await asyncio.gather(
            repository.list_records(status="pending"),
            repository.list_pending_prediction_packages(),
            repository.get_prediction_package_for_date(now.date().isoformat()),
        )
        database_error = None
    except RecordsStorageError as exc:
        pending_free, pending_packages, today_package = [], [], None
        database_error = str(exc)

    if database_error:
        check = {
            "key": "records_database",
            "label": "推薦紀錄資料庫",
            "status": "critical",
            "detail": f"Supabase 查詢失敗：{database_error[:180]}",
        }
        checks.append(check)
        critical_issues.append(check)
    else:
        checks.append({
            "key": "records_database",
            "label": "推薦紀錄資料庫",
            "status": "pass",
            "detail": f"可正常查詢；免費待結算 {len(pending_free)}、Pro 待結算 {len(pending_packages)}。",
        })

    today_package_data = package_from_record(today_package) if today_package else None
    today_package_mode = str(((today_package_data or {}).get("publication") or {}).get("mode") or "")
    today_package_locked = bool(
        today_package
        and today_package_mode != "ai_auto"
        and (today_package_data or {}).get("locked")
    )

    active_packages: list[dict[str, Any]] = []
    for record in pending_packages:
        package = package_from_record(record)
        mode = str((package.get("publication") or {}).get("mode") or "")
        if mode != "ai_auto":
            active_packages.append(record)

    pending_leagues = {"MLB"} if pending_free else set()
    for record in active_packages:
        for selection in _package_selections(record):
            pending_leagues.add(str(selection.get("league") or "MLB").upper())

    for league in ("MLB", "NPB"):
        probe = source_probes.get(league) or {"ok": False, "error": "MissingProbe"}
        payload = probe.get("payload") if probe.get("ok") else None
        meta = (payload or {}).get("meta") or {}
        items = list((payload or {}).get("items") or [])
        stale = str(meta.get("cache") or "").lower() == "stale"
        age = _age_minutes(meta.get("updated_at"), now)
        age_stale = bool(items) and age is not None and age > settings.monitor_data_stale_minutes
        failed = not probe.get("ok") or stale or age_stale
        consecutive = _bump_failure(failure_counters, f"source:{league}", failed)
        needs_source = bool(items) or league in pending_leagues
        critical = failed and needs_source and consecutive >= settings.monitor_failure_threshold

        if not probe.get("ok"):
            detail = f"官方資料抓取失敗：{probe.get('error') or 'UnknownError'}。"
        elif stale:
            detail = f"目前使用過期快取；今日取得 {len(items)} 場。"
        elif age_stale:
            detail = f"資料已 {age:.0f} 分鐘未更新；今日取得 {len(items)} 場。"
        else:
            detail = f"官方資料正常；今日取得 {len(items)} 場，快取狀態 {meta.get('cache') or 'unknown'}。"

        status = "critical" if critical else "warning" if failed else "pass"
        check = {
            "key": f"{league.lower()}_source",
            "label": f"{league} 官方資料",
            "status": status,
            "detail": detail,
            "consecutive_failures": consecutive,
            "updated_at": meta.get("updated_at"),
            "games": len(items),
        }
        checks.append(check)
        if critical:
            critical_issues.append(check)
        elif status == "warning":
            warnings.append(check)

    overdue_free: list[dict[str, Any]] = []
    for record in pending_free:
        deadline = _record_deadline(record, settings.monitor_settlement_grace_hours)
        if deadline and now > deadline:
            overdue_free.append({
                "id": record.get("id"),
                "date": record.get("recommendation_date"),
                "matchup": record.get("matchup"),
                "deadline": deadline.isoformat(),
            })

    overdue_packages: list[dict[str, Any]] = []
    for record in active_packages:
        deadline = _package_deadline(record, settings.monitor_settlement_grace_hours)
        if deadline and now > deadline:
            overdue_packages.append({
                "id": record.get("id"),
                "date": record.get("recommendation_date"),
                "deadline": deadline.isoformat(),
            })

    overdue_total = len(overdue_free) + len(overdue_packages)
    settlement_check = {
        "key": "overdue_settlement",
        "label": "逾時未結算",
        "status": "critical" if overdue_total else "pass",
        "detail": (
            f"有 {len(overdue_free)} 筆免費與 {len(overdue_packages)} 包 Pro 推薦超過比賽後 "
            f"{settings.monitor_settlement_grace_hours} 小時仍未結算。"
            if overdue_total
            else "沒有超過結算寬限時間的正式推薦。"
        ),
        "free": overdue_free[:10],
        "packages": overdue_packages[:10],
    }
    checks.append(settlement_check)
    if overdue_total:
        critical_issues.append(settlement_check)

    odds_status = odds.status()
    last_checks = odds_status.get("last_checks") or {}
    for league in ("MLB", "NPB"):
        probe_payload = (source_probes.get(league) or {}).get("payload") or {}
        upcoming = _upcoming_within(
            list(probe_payload.get("items") or []),
            now,
            settings.monitor_odds_window_minutes,
        )
        last = last_checks.get(league) or {}
        checked_age = _age_minutes(last.get("checked_at"), now)
        last_failed = bool(last.get("last_error"))
        stale = last.get("fresh_for_model") is False or str(last.get("cache") or "").lower() == "stale"
        too_old = checked_age is None or checked_age > settings.monitor_odds_stale_minutes
        failed = bool(upcoming) and (last_failed or stale or too_old)
        consecutive = _bump_failure(failure_counters, f"odds:{league}", failed)
        critical = failed and consecutive >= settings.monitor_failure_threshold

        if not odds.enabled:
            status = "warning"
            detail = "尚未設定盤口來源；讓分與大小分不會發布。"
        elif today_package_locked:
            status = "pass"
            detail = "今日正式 Pro 玩法已鎖定；發布後保留原盤口，不再要求即時刷新。"
            _bump_failure(failure_counters, f"odds:{league}", False)
        elif not upcoming:
            status = "pass"
            detail = f"未來 {settings.monitor_odds_window_minutes} 分鐘沒有 {league} 開賽，暫不要求更新盤口。"
            _bump_failure(failure_counters, f"odds:{league}", False)
        elif not last:
            status = "critical" if critical else "warning"
            detail = f"{league} 即將開賽，但本次服務啟動後尚無盤口更新紀錄。"
        elif last_failed:
            status = "critical" if critical else "warning"
            detail = f"最近盤口更新失敗：{last.get('last_error')}。"
        elif stale:
            status = "critical" if critical else "warning"
            detail = "最近只有過期備援盤口，禁止發布新的正式玩法。"
        elif too_old:
            status = "critical" if critical else "warning"
            detail = f"盤口已超過 {settings.monitor_odds_stale_minutes} 分鐘未檢查。"
        else:
            status = "pass"
            detail = f"盤口最近於 {last.get('checked_at')} 檢查，資料可供模型使用。"

        check = {
            "key": f"{league.lower()}_odds",
            "label": f"{league} 盤口時效",
            "status": status,
            "detail": detail,
            "upcoming_games": len(upcoming),
            "consecutive_failures": int(failure_counters.get(f"odds:{league}", 0) or 0),
            "last_check": last or None,
        }
        checks.append(check)
        if status == "critical":
            critical_issues.append(check)
        elif status == "warning":
            warnings.append(check)

    overall = "critical" if critical_issues else "degraded" if warnings else "healthy"
    return {
        "ok": not bool(critical_issues),
        "status": overall,
        "checked_at": now.isoformat(),
        "checks": checks,
        "critical_issues": critical_issues,
        "warnings": warnings,
        "pending": {
            "free": len(pending_free),
            "packages": len(active_packages),
            "overdue_free": len(overdue_free),
            "overdue_packages": len(overdue_packages),
        },
        "failure_counters": dict(failure_counters),
    }
