from __future__ import annotations

import argparse
import asyncio
import os
from contextlib import suppress


VALID_ROLES = ("publish", "settlement", "model", "monitor")


async def _run(role: str) -> None:
    # Settings are created at import time, so the process role must be selected
    # before importing the FastAPI application.
    os.environ["DIAMONDMIND_PROCESS_ROLE"] = role
    from .main import app

    stop = asyncio.Event()
    async with app.router.lifespan_context(app):
        try:
            await stop.wait()
        except asyncio.CancelledError:
            raise


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Run one DiamondMind background process role.",
    )
    parser.add_argument("--role", required=True, choices=VALID_ROLES)
    args = parser.parse_args()
    with suppress(KeyboardInterrupt):
        asyncio.run(_run(args.role))


if __name__ == "__main__":
    main()
