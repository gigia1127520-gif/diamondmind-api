from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any

from .billing import (
    PLANS,
    BillingError,
    BillingRepository,
    add_months,
    iso_utc,
    parse_datetime,
    utc_now,
)

UTC = timezone.utc


class AdminMembershipError(RuntimeError):
    pass


def _role_from_metadata(user: dict[str, Any]) -> str:
    app_metadata = user.get("app_metadata") or {}
    raw = str(app_metadata.get("role") or "free").lower()
    if raw in {"admin", "founder"}:
        return "admin"
    if raw == "pro":
        expiry = parse_datetime(app_metadata.get("pro_expires_at"))
        if expiry and expiry > utc_now():
            return "pro"
    return "free"


def _display_name(user: dict[str, Any]) -> str:
    metadata = user.get("user_metadata") or {}
    for key in ("nickname", "display_name", "full_name", "name"):
        value = str(metadata.get(key) or "").strip()
        if value:
            return value
    email = str(user.get("email") or "").strip()
    return email.split("@", 1)[0] if email else "DiamondMind 會員"


def _subscription_status(subscription: dict[str, Any] | None, role: str) -> str:
    if role == "admin":
        return "founder"
    if not subscription:
        return "active" if role == "pro" else "free"
    status = str(subscription.get("status") or "free")
    end = parse_datetime(subscription.get("current_period_end"))
    if status == "active" and end and end <= utc_now():
        return "expired"
    return status


def _safe_member(user: dict[str, Any], subscription: dict[str, Any] | None) -> dict[str, Any]:
    app_metadata = user.get("app_metadata") or {}
    role = _role_from_metadata(user)
    status = _subscription_status(subscription, role)
    expires_at = app_metadata.get("pro_expires_at") or (subscription or {}).get("current_period_end")
    plan = app_metadata.get("plan") or (subscription or {}).get("plan_code")
    return {
        "id": user.get("id"),
        "email": user.get("email"),
        "name": _display_name(user),
        "role": role,
        "status": status,
        "plan": plan,
        "pro_expires_at": expires_at,
        "created_at": user.get("created_at"),
        "last_sign_in_at": user.get("last_sign_in_at"),
        "email_confirmed_at": user.get("email_confirmed_at") or user.get("confirmed_at"),
        "provider": (subscription or {}).get("provider"),
        "amount": (subscription or {}).get("amount"),
        "currency": (subscription or {}).get("currency") or "TWD",
        "merchant_trade_no": (subscription or {}).get("merchant_trade_no"),
        "current_period_start": (subscription or {}).get("current_period_start"),
        "current_period_end": (subscription or {}).get("current_period_end"),
        "billing_status": app_metadata.get("billing_status") or status,
        "auto_renew": bool((subscription or {}).get("auto_renew", False)),
    }


@dataclass
class AdminMemberCommand:
    action: str
    plan: str | None = None
    note: str | None = None


class AdminMembershipService:
    """Founder-only membership and transaction operations.

    All Supabase secret-key calls remain server-side. The browser only receives
    a deliberately reduced member/transaction view.
    """

    def __init__(self, repository: BillingRepository) -> None:
        self.repository = repository

    async def _members_snapshot(self) -> tuple[list[dict[str, Any]], dict[str, dict[str, Any]]]:
        users = await self.repository.list_all_auth_users(max_users=2000)
        subscriptions = await self.repository.list_subscriptions(limit=5000)
        by_user = {str(row.get("user_id")): row for row in subscriptions if row.get("user_id")}
        return users, by_user

    async def overview(
        self,
        *,
        query: str = "",
        role: str = "all",
        status: str = "all",
        limit: int = 50,
        offset: int = 0,
    ) -> dict[str, Any]:
        users, subscriptions = await self._members_snapshot()
        members = [_safe_member(user, subscriptions.get(str(user.get("id")))) for user in users]

        payments = await self.repository.list_payment_events(limit=5000)
        successful = [row for row in payments if bool(row.get("success"))]
        summary = {
            "total_members": len(members),
            "free_members": sum(1 for item in members if item["role"] == "free"),
            "active_pro": sum(1 for item in members if item["role"] == "pro" and item["status"] == "active"),
            "founders": sum(1 for item in members if item["role"] == "admin"),
            "expired_or_canceled": sum(1 for item in members if item["status"] in {"expired", "canceled", "refunded"}),
            "successful_payments": len(successful),
            "revenue_twd": sum(int(row.get("amount") or 0) for row in successful),
        }

        needle = query.strip().lower()
        if needle:
            members = [
                item for item in members
                if needle in str(item.get("email") or "").lower()
                or needle in str(item.get("name") or "").lower()
                or needle in str(item.get("merchant_trade_no") or "").lower()
            ]
        if role != "all":
            members = [item for item in members if item.get("role") == role]
        if status != "all":
            members = [item for item in members if item.get("status") == status]

        def sort_key(item: dict[str, Any]) -> tuple[int, str]:
            priority = 0 if item.get("role") == "admin" else 1 if item.get("role") == "pro" else 2
            return priority, str(item.get("created_at") or "")

        members.sort(key=sort_key)
        total_filtered = len(members)
        paged = members[offset: offset + limit]
        return {
            "summary": summary,
            "members": paged,
            "pagination": {
                "total": total_filtered,
                "limit": limit,
                "offset": offset,
                "has_more": offset + limit < total_filtered,
            },
            "updated_at": iso_utc(),
        }

    async def member_detail(self, user_id: str) -> dict[str, Any]:
        user = await self.repository.admin_user(user_id)
        subscription = await self.repository.subscription_for_user(user_id)
        payments = await self.repository.list_payment_events(user_id=user_id, limit=100)
        admin_events = await self.repository.list_admin_events(user_id=user_id, limit=100)
        return {
            "member": _safe_member(user, subscription),
            "subscription": subscription,
            "payments": [self._safe_payment(row) for row in payments],
            "admin_events": [self._safe_admin_event(row) for row in admin_events],
        }

    async def transactions(
        self,
        *,
        query: str = "",
        result: str = "all",
        limit: int = 100,
        offset: int = 0,
    ) -> dict[str, Any]:
        users, _ = await self._members_snapshot()
        emails = {str(user.get("id")): str(user.get("email") or "") for user in users}
        rows = await self.repository.list_payment_events(limit=5000)
        items = []
        for row in rows:
            item = self._safe_payment(row)
            item["email"] = emails.get(str(row.get("user_id")), "")
            items.append(item)

        needle = query.strip().lower()
        if needle:
            items = [
                item for item in items
                if needle in str(item.get("email") or "").lower()
                or needle in str(item.get("merchant_trade_no") or "").lower()
                or needle in str(item.get("provider_trade_no") or "").lower()
            ]
        if result == "success":
            items = [item for item in items if item.get("success") is True]
        elif result == "failed":
            items = [item for item in items if item.get("success") is False]
        total = len(items)
        return {
            "transactions": items[offset: offset + limit],
            "pagination": {"total": total, "limit": limit, "offset": offset, "has_more": offset + limit < total},
            "updated_at": iso_utc(),
        }

    async def export_members(
        self,
        *,
        query: str = "",
        role: str = "all",
        status: str = "all",
    ) -> list[dict[str, Any]]:
        payload = await self.overview(
            query=query, role=role, status=status, limit=5000, offset=0
        )
        return list(payload.get("members") or [])

    async def export_transactions(
        self,
        *,
        query: str = "",
        result: str = "all",
    ) -> list[dict[str, Any]]:
        payload = await self.transactions(
            query=query, result=result, limit=5000, offset=0
        )
        return list(payload.get("transactions") or [])

    async def apply_command(
        self,
        *,
        actor: dict[str, Any],
        target_user_id: str,
        command: AdminMemberCommand,
    ) -> dict[str, Any]:
        target = await self.repository.admin_user(target_user_id)
        target_role = _role_from_metadata(target)
        if target_role == "admin":
            raise AdminMembershipError("創辦人或管理員帳號不可由此頁修改")
        if str(actor.get("id")) == str(target_user_id):
            raise AdminMembershipError("不可修改自己的創辦人權限")

        # Verify the audit table before changing any membership data so a
        # missing SQL migration can never cause a partially applied action.
        await self.repository.list_admin_events(limit=1)
        subscription = await self.repository.subscription_for_user(target_user_id)
        before = _safe_member(target, subscription)
        action = command.action.strip().lower()
        note = (command.note or "").strip()[:300] or None

        if action in {"grant", "extend"}:
            if command.plan not in PLANS:
                raise AdminMembershipError("請選擇有效的月、季或年方案")
            plan = PLANS[command.plan]
            now = utc_now()
            current_end = parse_datetime((subscription or {}).get("current_period_end"))
            if action == "extend" and current_end and current_end > now:
                period_start = current_end
            else:
                period_start = now
            period_end = add_months(period_start, plan.months)
            updated_subscription = await self.repository.upsert_manual_subscription(
                user_id=target_user_id,
                email=str(target.get("email") or "") or None,
                plan_code=plan.code,
                period_start=period_start,
                period_end=period_end,
                status="active",
            )
            await self.repository.update_app_metadata(target_user_id, {
                "role": "pro",
                "plan": plan.code,
                "billing_provider": "admin",
                "billing_status": "active",
                "billing_auto_renew": False,
                "billing_trade_no": None,
                "pro_expires_at": iso_utc(period_end),
            })
        elif action == "cancel":
            now = utc_now()
            updated_subscription = await self.repository.upsert_manual_subscription(
                user_id=target_user_id,
                email=str(target.get("email") or "") or None,
                plan_code=(subscription or {}).get("plan_code") if (subscription or {}).get("plan_code") in PLANS else "monthly",
                period_start=parse_datetime((subscription or {}).get("current_period_start")) or now,
                period_end=now,
                status="canceled",
            )
            await self.repository.update_app_metadata(target_user_id, {
                "role": "free",
                "plan": None,
                "billing_provider": "admin",
                "billing_status": "canceled",
                "billing_auto_renew": False,
                "billing_trade_no": None,
                "pro_expires_at": None,
            })
        else:
            raise AdminMembershipError("不支援的會員管理操作")

        refreshed = await self.repository.admin_user(target_user_id)
        after = _safe_member(refreshed, updated_subscription)
        await self.repository.record_admin_event({
            "actor_user_id": actor.get("id"),
            "actor_email": actor.get("email"),
            "target_user_id": target_user_id,
            "target_email": target.get("email"),
            "action": action,
            "plan_code": command.plan,
            "note": note,
            "before_state": before,
            "after_state": after,
        })
        return {"ok": True, "action": action, "member": after}

    @staticmethod
    def _safe_payment(row: dict[str, Any]) -> dict[str, Any]:
        raw = row.get("raw_payload") if isinstance(row.get("raw_payload"), dict) else {}
        return {
            "id": row.get("id"),
            "user_id": row.get("user_id"),
            "event_type": row.get("event_type"),
            "success": bool(row.get("success")),
            "amount": row.get("amount"),
            "provider": row.get("provider"),
            "merchant_trade_no": row.get("merchant_trade_no"),
            "provider_trade_no": raw.get("TradeNo"),
            "rtn_msg": raw.get("RtnMsg"),
            "payment_type": raw.get("PaymentType"),
            "created_at": row.get("created_at"),
        }

    @staticmethod
    def _safe_admin_event(row: dict[str, Any]) -> dict[str, Any]:
        return {
            "id": row.get("id"),
            "actor_email": row.get("actor_email"),
            "target_email": row.get("target_email"),
            "action": row.get("action"),
            "plan_code": row.get("plan_code"),
            "note": row.get("note"),
            "created_at": row.get("created_at"),
        }
