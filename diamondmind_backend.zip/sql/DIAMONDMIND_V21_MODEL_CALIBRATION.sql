-- DiamondMind V21.0 model performance and automatic probability calibration
-- Safe to run more than once in Supabase SQL Editor.

create extension if not exists pgcrypto;

create table if not exists public.model_snapshots (
  id uuid primary key default gen_random_uuid(),
  source_type text not null,
  source_record_id text not null,
  candidate_id text not null,
  recommendation_date date not null,
  league text not null default 'MLB',
  game_pk text,
  market text not null default 'moneyline',
  pick_label text,
  pick_side text,
  pick_team_id text,
  line numeric,
  price numeric,
  confidence numeric,
  raw_model_probability numeric,
  calibrated_probability numeric,
  calibration_profile_id uuid,
  data_quality numeric,
  data_integrity jsonb not null default '{}'::jsonb,
  model_version text,
  weights jsonb not null default '{}'::jsonb,
  module_scores jsonb not null default '{}'::jsonb,
  odds_snapshot jsonb not null default '{}'::jsonb,
  publication_snapshot jsonb not null default '{}'::jsonb,
  status text not null default 'pending',
  result jsonb not null default '{}'::jsonb,
  is_test boolean not null default false,
  settled_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint model_snapshots_source_candidate_key unique (source_type, source_record_id, candidate_id)
);

alter table public.model_snapshots add column if not exists raw_model_probability numeric;
alter table public.model_snapshots add column if not exists calibrated_probability numeric;
alter table public.model_snapshots add column if not exists calibration_profile_id uuid;
alter table public.model_snapshots add column if not exists data_integrity jsonb not null default '{}'::jsonb;
alter table public.model_snapshots add column if not exists updated_at timestamptz not null default now();

update public.model_snapshots
set raw_model_probability = coalesce(raw_model_probability, confidence),
    calibrated_probability = coalesce(calibrated_probability, confidence),
    updated_at = coalesce(updated_at, created_at, now())
where raw_model_probability is null
   or calibrated_probability is null
   or updated_at is null;

create index if not exists model_snapshots_date_idx
  on public.model_snapshots (recommendation_date desc, created_at desc);
create index if not exists model_snapshots_scope_idx
  on public.model_snapshots (league, market, status, recommendation_date desc);
create index if not exists model_snapshots_pending_idx
  on public.model_snapshots (status, recommendation_date)
  where status = 'pending';

create table if not exists public.model_weight_profiles (
  id uuid primary key default gen_random_uuid(),
  weights jsonb not null,
  status text not null default 'active',
  note text,
  created_by text,
  activated_at timestamptz,
  created_at timestamptz not null default now()
);
create index if not exists model_weight_profiles_status_idx
  on public.model_weight_profiles (status, activated_at desc);

create table if not exists public.model_calibration_profiles (
  id uuid primary key default gen_random_uuid(),
  league text not null default 'GLOBAL',
  market text not null default 'all',
  slope numeric not null default 1.0,
  intercept numeric not null default 0.0,
  sample integer not null default 0,
  train_sample integer not null default 0,
  validation_sample integer not null default 0,
  baseline_metrics jsonb not null default '{}'::jsonb,
  validation_metrics jsonb not null default '{}'::jsonb,
  improvement jsonb not null default '{}'::jsonb,
  status text not null default 'active',
  promotion_reason text,
  version text not null,
  created_by text,
  auto_promoted boolean not null default false,
  activated_at timestamptz,
  created_at timestamptz not null default now(),
  constraint model_calibration_profiles_scope_status_check
    check (status in ('active','superseded','rejected','shadow'))
);
create index if not exists model_calibration_profiles_scope_idx
  on public.model_calibration_profiles (league, market, status, activated_at desc);
create unique index if not exists model_calibration_profiles_one_active_scope
  on public.model_calibration_profiles (league, market)
  where status = 'active';

create table if not exists public.model_calibration_runs (
  id uuid primary key default gen_random_uuid(),
  started_at timestamptz not null default now(),
  completed_at timestamptz,
  status text not null default 'running',
  rows_scanned integer not null default 0,
  candidates jsonb not null default '[]'::jsonb,
  promoted jsonb not null default '[]'::jsonb,
  error text,
  created_at timestamptz not null default now(),
  constraint model_calibration_runs_status_check
    check (status in ('running','completed','failed'))
);
create index if not exists model_calibration_runs_started_idx
  on public.model_calibration_runs (started_at desc);

-- Service-role requests from the Render backend bypass RLS. No member browser
-- should directly read or write the training data.
alter table public.model_snapshots enable row level security;
alter table public.model_weight_profiles enable row level security;
alter table public.model_calibration_profiles enable row level security;
alter table public.model_calibration_runs enable row level security;

revoke all on table public.model_snapshots from anon, authenticated;
revoke all on table public.model_weight_profiles from anon, authenticated;
revoke all on table public.model_calibration_profiles from anon, authenticated;
revoke all on table public.model_calibration_runs from anon, authenticated;

grant all on table public.model_snapshots to service_role;
grant all on table public.model_weight_profiles to service_role;
grant all on table public.model_calibration_profiles to service_role;
grant all on table public.model_calibration_runs to service_role;

-- Automatically maintain updated_at when Postgres writes directly.
create or replace function public.diamondmind_set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists model_snapshots_set_updated_at on public.model_snapshots;
create trigger model_snapshots_set_updated_at
before update on public.model_snapshots
for each row execute function public.diamondmind_set_updated_at();
