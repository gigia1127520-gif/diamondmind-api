
    const API_BASE=(window.DIAMONDMIND_API_BASE||"https://diamondmind-api.onrender.com/api/v1").replace(/\/$/,"");
    const SUPABASE_URL=(window.DIAMONDMIND_SUPABASE_URL||"https://ywttcnxulfyhdfzzrnwt.supabase.co").replace(/\/$/,"");
    const SUPABASE_PUBLISHABLE_KEY=window.DIAMONDMIND_SUPABASE_PUBLISHABLE_KEY||"sb_publishable__JivOxRrvBQdYHTlVWmJug_Uh0Cc79g";
    const AUTH_STORAGE_KEY="diamondmind.auth.session.v1";
    const AUTH_REDIRECT_URL=/^https?:$/.test(location.protocol)?`${location.origin}${location.pathname}`:"https://gigia1127520-gif.github.io/diamondmind-web/";
    const pages = ["homePage","gamesPage","predictionPage","recordsPage","membershipPage","adminMembersPage","adminAnnouncementsPage","adminSettlementPage","adminModelPage","adminOperationsPage","morePage"];
    const state = {
      games:[],gameFilter:"all",gamesLoaded:false,activeLeague:"MLB",predictionDate:"",predictionRole:"",
      records:[],marketRecords:[],proPerformance:null,recordStats:null,recordFilter:"all",marketRecordFilter:"all",recordsLoaded:false,recordsLoading:false,recordsError:"",recordsAccessRole:"",
      founderCandidateDate:"",founderCandidatesLoading:false,
      founderMarketDate:"",founderMarketsLoading:false,founderMarketBundle:null,
      upgradeReturnGame:null,billingConfig:null,billingStatus:null,selectedPlan:null,paymentHandled:false,
      paymentSuccessTimer:null,paymentSuccessInterval:null,
      adminTab:"members",adminMembers:null,adminTransactions:null,adminMembersOffset:0,adminTransactionsOffset:0,adminPageSize:30,adminSelectedMember:null,adminSelectedTransaction:null,adminPendingAction:null,adminLoading:false,
      homeAnnouncements:[],homeAnnouncementRole:"",adminAnnouncements:[],editingAnnouncementId:null,announcementModalItem:null,announcementModalPreview:false,announcementLoginChecked:"",
      settlementDate:"",settlementDashboard:null,settlementLoading:false,
      modelPerformance:null,modelSnapshots:null,modelLoading:false,modelSuggestedWeights:null,operationsStatus:null,operationsLoading:false
    };
    const authState={session:null,user:null,ready:false,role:"free",trialJustGranted:false};

    const teamZh = {
      "Arizona Diamondbacks":"亞利桑那響尾蛇","Atlanta Braves":"亞特蘭大勇士","Baltimore Orioles":"巴爾的摩金鶯",
      "Boston Red Sox":"波士頓紅襪","Chicago Cubs":"芝加哥小熊","Chicago White Sox":"芝加哥白襪",
      "Cincinnati Reds":"辛辛那提紅人","Cleveland Guardians":"克里夫蘭守護者","Colorado Rockies":"科羅拉多洛磯",
      "Detroit Tigers":"底特律老虎","Houston Astros":"休士頓太空人","Kansas City Royals":"堪薩斯市皇家",
      "Los Angeles Angels":"洛杉磯天使","Los Angeles Dodgers":"洛杉磯道奇","Miami Marlins":"邁阿密馬林魚",
      "Milwaukee Brewers":"密爾瓦基釀酒人","Minnesota Twins":"明尼蘇達雙城","New York Mets":"紐約大都會",
      "New York Yankees":"紐約洋基","Athletics":"運動家","Oakland Athletics":"奧克蘭運動家",
      "Philadelphia Phillies":"費城費城人","Pittsburgh Pirates":"匹茲堡海盜","San Diego Padres":"聖地牙哥教士",
      "San Francisco Giants":"舊金山巨人","Seattle Mariners":"西雅圖水手","St. Louis Cardinals":"聖路易紅雀",
      "Tampa Bay Rays":"坦帕灣光芒","Texas Rangers":"德州遊騎兵","Toronto Blue Jays":"多倫多藍鳥",
      "Washington Nationals":"華盛頓國民",
      "American League All-Stars":"美聯明星隊","National League All-Stars":"國聯明星隊",
      "AL All-Stars":"美聯明星隊","NL All-Stars":"國聯明星隊",
      "American League":"美聯明星隊","National League":"國聯明星隊",
      "AL":"美聯明星隊","NL":"國聯明星隊"
    };
    const teamAbbr = {
      "Arizona Diamondbacks":"ARI","Atlanta Braves":"ATL","Baltimore Orioles":"BAL","Boston Red Sox":"BOS",
      "Chicago Cubs":"CHC","Chicago White Sox":"CWS","Cincinnati Reds":"CIN","Cleveland Guardians":"CLE",
      "Colorado Rockies":"COL","Detroit Tigers":"DET","Houston Astros":"HOU","Kansas City Royals":"KC",
      "Los Angeles Angels":"LAA","Los Angeles Dodgers":"LAD","Miami Marlins":"MIA","Milwaukee Brewers":"MIL",
      "Minnesota Twins":"MIN","New York Mets":"NYM","New York Yankees":"NYY","Athletics":"ATH","Oakland Athletics":"OAK",
      "Philadelphia Phillies":"PHI","Pittsburgh Pirates":"PIT","San Diego Padres":"SD","San Francisco Giants":"SF",
      "Seattle Mariners":"SEA","St. Louis Cardinals":"STL","Tampa Bay Rays":"TB","Texas Rangers":"TEX",
      "Toronto Blue Jays":"TOR","Washington Nationals":"WSH",
      "American League All-Stars":"AL","National League All-Stars":"NL",
      "AL All-Stars":"AL","NL All-Stars":"NL",
      "American League":"AL","National League":"NL","AL":"AL","NL":"NL"
    };
    const npbTeamZh={
      "Tokyo Yakult Swallows":"東京養樂多燕子","Yomiuri Giants":"讀賣巨人","YOKOHAMA DeNA BAYSTARS":"橫濱DeNA海灣之星",
      "Chunichi Dragons":"中日龍","Hanshin Tigers":"阪神虎","Hiroshima Toyo Carp":"廣島東洋鯉魚",
      "Fukuoka SoftBank Hawks":"福岡軟銀鷹","Hokkaido Nippon-Ham Fighters":"北海道日本火腿鬥士","ORIX Buffaloes":"歐力士猛牛",
      "Tohoku Rakuten Golden Eagles":"東北樂天金鷲","Saitama Seibu Lions":"埼玉西武獅","Chiba Lotte Marines":"千葉羅德海洋",
      "Central League All-Stars":"中央聯盟明星隊","Pacific League All-Stars":"太平洋聯盟明星隊"
    };
    const teamZhByAbbr={
      ARI:"亞利桑那響尾蛇",ATL:"亞特蘭大勇士",BAL:"巴爾的摩金鶯",BOS:"波士頓紅襪",CHC:"芝加哥小熊",CWS:"芝加哥白襪",
      CIN:"辛辛那提紅人",CLE:"克里夫蘭守護者",COL:"科羅拉多洛磯",DET:"底特律老虎",HOU:"休士頓太空人",KC:"堪薩斯市皇家",KCR:"堪薩斯市皇家",
      LAA:"洛杉磯天使",LAD:"洛杉磯道奇",MIA:"邁阿密馬林魚",MIL:"密爾瓦基釀酒人",MIN:"明尼蘇達雙城",NYM:"紐約大都會",NYY:"紐約洋基",
      ATH:"運動家",OAK:"奧克蘭運動家",PHI:"費城費城人",PIT:"匹茲堡海盜",SD:"聖地牙哥教士",SDP:"聖地牙哥教士",SF:"舊金山巨人",SFG:"舊金山巨人",
      SEA:"西雅圖水手",STL:"聖路易紅雀",TB:"坦帕灣光芒",TBR:"坦帕灣光芒",TEX:"德州遊騎兵",TOR:"多倫多藍鳥",WSH:"華盛頓國民",WSN:"華盛頓國民",
      AL:"美聯明星隊",NL:"國聯明星隊",S:"東京養樂多燕子",G:"讀賣巨人",DB:"橫濱DeNA海灣之星",D:"中日龍",T:"阪神虎",C:"廣島東洋鯉魚",
      H:"福岡軟銀鷹",F:"北海道日本火腿鬥士",B:"歐力士猛牛",E:"東北樂天金鷲",L:"埼玉西武獅",M:"千葉羅德海洋",CL:"中央聯盟明星隊",PL:"太平洋聯盟明星隊"
    };
    function displayTeamAny(value){
      const raw=String(value||"").trim();
      if(!raw)return raw;
      return teamZhByAbbr[raw.toUpperCase()]||teamZh[raw]||npbTeamZh[raw]||raw;
    }
    function localizeMatchup(value){
      const raw=String(value||"").trim();
      if(!raw)return raw;
      return raw.split(/\s*\/\s*/).map(segment=>{
        const match=segment.match(/^\s*(.+?)\s+(@|VS|vs|v\.?)\s+(.+?)\s*$/);
        if(!match)return segment;
        const separator=match[2].toLowerCase().startsWith("v")?"VS":"@";
        return `${displayTeamAny(match[1])} ${separator} ${displayTeamAny(match[3])}`;
      }).join(" / ");
    }
    function localizePickLabel(value,selection=null){
      const raw=String(value||selection?.pick?.label||selection?.label||"").trim();
      const pick=selection?.pick||selection||{};
      const market=String(pick.market||selection?.market||"").toLowerCase();
      const teamValue=pick.team_name_zh||pick.name_zh||pick.team_name||pick.team||pick.abbr;
      const teamName=displayTeamAny(teamValue);
      if(teamName&&market==="moneyline")return `${teamName} ${raw.includes("觀察")?"獨贏觀察":"獨贏"}`;
      if(teamName&&market==="run_line"){
        const numeric=Number(pick.line??selection?.line);
        const rawLine=raw.match(/([+-]\d+(?:\.\d+)?)\s*$/)?.[1];
        const line=rawLine||(Number.isFinite(numeric)?`${numeric>0?"+":""}${numeric}`:"");
        return `${teamName}${line?` ${line}`:""}`;
      }
      return raw.split(/\s*＋\s*/).map(part=>{
        const match=part.trim().match(/^([A-Za-z]{1,4})(?=\s|[+-]|$)(.*)$/);
        if(!match)return part.trim();
        const localized=teamZhByAbbr[match[1].toUpperCase()];
        if(!localized)return part.trim();
        const suffix=match[2].trim();
        return `${localized}${suffix?` ${suffix}`:""}`;
      }).join(" ＋ ");
    }

    const leagueUi={
      MLB:{kicker:"TODAY'S MLB",description:"依台灣日期載入 MLB 全部賽事，點擊任一場查看比賽資料。",connection:"MLB 資料連線"},
      NPB:{kicker:"TODAY'S NPB",description:"日本職棒三大玩法：整合官方賽程、比分、預告先發、球隊戰績、畢氏勝率、打線、牛棚與真實盤口。",connection:"NPB 官方資料＋真實盤口"}
    };

    const allStarTeamById={
      159:{abbr:"AL",zh:"美聯明星隊",name:"American League All-Stars"},
      160:{abbr:"NL",zh:"國聯明星隊",name:"National League All-Stars"}
    };
    function allStarLeague(name,teamId){
      const byId=allStarTeamById[Number(teamId)];
      if(byId)return byId.abbr;
      const value=String(name||"").trim().toLowerCase().replace(/[._-]+/g," ");
      if((value.includes("american league")||/^(al)(\s|$)/.test(value))&&(value.includes("all star")||value==="american league"||value==="al"))return "AL";
      if((value.includes("national league")||/^(nl)(\s|$)/.test(value))&&(value.includes("all star")||value==="national league"||value==="nl"))return "NL";
      return "";
    }
    function displayTeamName(name,teamId){
      const special=allStarLeague(name,teamId);
      if(special==="AL")return "美聯明星隊";
      if(special==="NL")return "國聯明星隊";
      return teamZh[name]||name;
    }
    function resolvedTeamAbbr(name,provided,teamId,fallback){
      const special=allStarLeague(name,teamId);
      if(special)return special;
      const supplied=String(provided||"").trim().toUpperCase();
      if(supplied&&supplied!=="ALL")return supplied;
      return teamAbbr[name]||(String(name||"").split(" ").pop()||fallback).slice(0,3).toUpperCase();
    }

    function taiwanToday(){
      const parts = new Intl.DateTimeFormat("en-CA",{timeZone:"Asia/Taipei",year:"numeric",month:"2-digit",day:"2-digit"}).formatToParts(new Date());
      const obj = Object.fromEntries(parts.map(p=>[p.type,p.value]));
      return `${obj.year}-${obj.month}-${obj.day}`;
    }

    function showPage(pageId){
      if(!pages.includes(pageId)) pageId="homePage";
      document.querySelectorAll(".page").forEach(page=>page.classList.toggle("active",page.id===pageId));
      document.querySelectorAll("[data-page]").forEach(btn=>btn.classList.toggle("active",btn.dataset.page===pageId));
      history.replaceState(null,"",`#${pageId.replace("Page","")}`);
      window.scrollTo({top:0,behavior:"smooth"});
      if(pageId==="gamesPage"&&!state.gamesLoaded) loadLeagueGames();
      if(pageId==="predictionPage"){
        renderPredictionAccess();
        if(isSignedIn()){
          loadTopPrediction();
          if(isAdminMember()){loadFounderCandidates();loadFounderMarkets();}
        }
      }
      if(pageId==="recordsPage"&&(!state.recordsLoaded||state.recordsAccessRole!==authState.role)) loadRecords(true);
      if(pageId==="adminMembersPage"){
        if(!isAdminMember()){showPage("morePage");showToast("此功能僅限創辦人使用");return}
        loadAdminMembers();
      }
      if(pageId==="adminAnnouncementsPage"){
        if(!isAdminMember()){showPage("morePage");showToast("此功能僅限創辦人使用");return}
        loadAdminAnnouncements();
      }
      if(pageId==="adminSettlementPage"){
        if(!isAdminMember()){showPage("morePage");showToast("此功能僅限創辦人使用");return}
        loadSettlementDashboard();
      }
      if(pageId==="adminModelPage"){
        if(!isAdminMember()){showPage("morePage");showToast("此功能僅限創辦人使用");return}
        loadModelPerformance();
      }
      if(pageId==="adminOperationsPage"){
        if(!isAdminMember()){showPage("morePage");showToast("此功能僅限創辦人使用");return}
        loadOperationsStatus();
      }
    }

    function focusMembershipPlans(){
      closeModals();
      showPage("membershipPage");
      window.setTimeout(()=>{
        const plans=document.getElementById("pricingPlans");
        if(!plans)return;
        plans.classList.remove("plan-focus");
        void plans.offsetWidth;
        plans.classList.add("plan-focus");
        plans.scrollIntoView({behavior:"smooth",block:"start"});
        window.setTimeout(()=>plans.classList.remove("plan-focus"),1800);
      },180);
    }

    document.querySelectorAll("[data-page]").forEach(btn=>btn.addEventListener("click",()=>showPage(btn.dataset.page)));
    document.querySelectorAll("[data-page-link]").forEach(link=>link.addEventListener("click",e=>{e.preventDefault();showPage(link.dataset.pageLink)}));

    const backdrop = document.getElementById("modalBackdrop");
    function openModal(id){
      closeModals();
      const modal=document.getElementById(id);
      if(!modal)return;
      backdrop.classList.add("open");
      modal.classList.add("open");
      document.body.style.overflow="hidden";
    }
    function clearPaymentSuccessTimers(){
      clearTimeout(state.paymentSuccessTimer);
      clearInterval(state.paymentSuccessInterval);
      state.paymentSuccessTimer=null;
      state.paymentSuccessInterval=null;
    }
    function closeModals(){
      if(document.getElementById("announcementModal")?.classList.contains("open")&&!state.announcementModalPreview)rememberAnnouncementDismissal(state.announcementModalItem);
      clearPaymentSuccessTimers();
      backdrop.classList.remove("open");
      document.querySelectorAll(".modal.open").forEach(m=>m.classList.remove("open"));
      document.body.style.overflow="";
    }
    document.querySelectorAll("[data-modal]").forEach(btn=>btn.addEventListener("click",()=>openModal(btn.dataset.modal)));
    document.querySelectorAll("[data-switch-modal]").forEach(btn=>btn.addEventListener("click",()=>openModal(btn.dataset.switchModal)));
    document.querySelectorAll("[data-close-modal]").forEach(btn=>btn.addEventListener("click",closeModals));
    backdrop.addEventListener("click",closeModals);
    document.addEventListener("keydown",e=>{if(e.key==="Escape")closeModals()});

    document.querySelectorAll("[data-plan-select]").forEach(button=>button.addEventListener("click",async()=>{
      if(!isSignedIn()){
        openModal("loginModal");
        showToast("請先登入免費會員，再選擇 Pro 方案");
        return;
      }
      if(isAdminMember()){
        showToast("創辦人帳號已永久開放全部權限，不需要購買");
        return;
      }
      if(isProMember()){
        showToast("你的 Pro 方案目前仍在有效期間內");
        return;
      }
      state.selectedPlan=button.dataset.planSelect||"monthly";
      document.getElementById("checkoutPlanName").textContent=button.dataset.planName||"DiamondMind Pro";
      document.getElementById("checkoutPlanPrice").textContent=button.dataset.planPrice||"—";
      document.getElementById("checkoutAgree").checked=false;
      setCheckoutNote("正在確認付款服務…");
      openModal("checkoutPreviewModal");
      await loadBillingConfig();
      renderCheckoutMode();
    }));

    function setCheckoutNote(message,type=""){
      const note=document.getElementById("checkoutNote");
      if(!note)return;
      note.textContent=message;
      note.classList.toggle("error",type==="error");
      note.classList.toggle("success",type==="success");
    }
    async function billingRequest(path,{method="GET",body,timeout=20000}={}){
      if(!authState.session?.access_token)throw new Error("請先登入會員");
      const controller=new AbortController();
      const timer=setTimeout(()=>controller.abort(),timeout);
      try{
        const response=await fetch(`${API_BASE}${path}`,{
          method,
          headers:{Accept:"application/json","Content-Type":"application/json",Authorization:`Bearer ${authState.session.access_token}`},
          body:body===undefined?undefined:JSON.stringify(body),signal:controller.signal,cache:"no-store"
        });
        const raw=await response.text();
        let payload={};
        if(raw){try{payload=JSON.parse(raw)}catch{payload={detail:raw}}}
        if(!response.ok){const error=new Error(payload.detail||payload.message||`HTTP ${response.status}`);error.status=response.status;throw error}
        return payload;
      }finally{clearTimeout(timer)}
    }
    async function loadBillingConfig(force=false){
      if(state.billingConfig&&!force)return state.billingConfig;
      try{
        const response=await fetch(`${API_BASE}/billing/config`,{headers:{Accept:"application/json"},cache:"no-store"});
        if(!response.ok)throw new Error(`HTTP ${response.status}`);
        state.billingConfig=await response.json();
      }catch{state.billingConfig={enabled:false,mode:"unavailable",live:false,plans:[]}}
      return state.billingConfig;
    }
    function renderCheckoutMode(){
      const badge=document.getElementById("checkoutPaymentMode");
      const config=state.billingConfig||{};
      if(!badge)return;
      badge.classList.toggle("stage",!config.live);
      badge.textContent=!config.enabled?"付款服務尚未完成設定":config.live?"綠界正式付款｜固定期間，不自動續扣":"綠界測試模式｜不會產生真實扣款";
      setCheckoutNote(!config.enabled?"付款服務目前尚未完成設定，請稍後再試。":config.live?"付款成功後，系統會驗證綠界通知並自動開通 Pro。":"目前僅限指定測試帳號使用；測試交易不會產生真實費用。",!config.enabled?"error":"");
      const supportEmail=config.support_email||"diamondmind.support@gmail.com";
      const supportText=document.getElementById("contactSupportEmail");
      if(supportText){supportText.textContent=supportEmail;supportText.href=`mailto:${supportEmail}`;}
      const footerSupport=document.getElementById("footerSupportEmail");
      if(footerSupport){footerSupport.textContent=supportEmail;footerSupport.href=`mailto:${supportEmail}`;}
    }
    function submitPaymentForm(checkout){
      const form=document.createElement("form");
      form.method="POST";form.action=checkout.action;form.style.display="none";
      Object.entries(checkout.fields||{}).forEach(([name,value])=>{const input=document.createElement("input");input.type="hidden";input.name=name;input.value=String(value);form.append(input)});
      document.body.append(form);form.submit();
    }
    document.getElementById("checkoutPayButton").addEventListener("click",async()=>{
      const button=document.getElementById("checkoutPayButton");
      if(!document.getElementById("checkoutAgree").checked){setCheckoutNote("請先勾選確認方案與政策。","error");return}
      if(!document.getElementById("checkoutDigitalConsent").checked){setCheckoutNote("請先確認同意付款後立即提供數位服務。","error");return}
      if(!state.selectedPlan){setCheckoutNote("請重新選擇方案。","error");return}
      button.disabled=true;button.textContent="建立安全付款中…";setCheckoutNote("正在建立付款訂單，請勿重複點擊。");
      try{
        const checkout=await billingRequest("/billing/checkout",{method:"POST",body:{plan:state.selectedPlan},timeout:30000});
        setCheckoutNote("即將前往綠界安全付款頁面。","success");
        submitPaymentForm(checkout);
      }catch(error){
        setCheckoutNote(error.message||"付款訂單建立失敗，請稍後重試。","error");
        button.disabled=false;button.textContent="前往綠界安全付款";
      }
    });
    function formatMembershipDate(value){
      if(!value)return "—";
      const date=new Date(value);if(Number.isNaN(date.getTime()))return "—";
      return new Intl.DateTimeFormat("zh-TW",{timeZone:"Asia/Taipei",year:"numeric",month:"2-digit",day:"2-digit"}).format(date);
    }
    async function loadBillingStatus(){
      if(!isSignedIn()){state.billingStatus=null;renderBillingMeta();return null}
      try{state.billingStatus=await billingRequest("/billing/status",{timeout:20000})}catch{state.billingStatus=null}
      renderBillingMeta();return state.billingStatus;
    }
    function renderBillingMeta(){
      const target=document.getElementById("membershipBillingMeta");if(!target)return;
      const status=state.billingStatus;
      if(!isSignedIn()){target.innerHTML="";return}
      if(isAdminMember()){target.innerHTML="<span>永久權限</span>";return}
      if(status?.active){
        const plan=({trial_1d:"新會員 1 天試用",gift_3d:"3 天贈送",gift_7d:"7 天贈送",monthly:"月方案",quarterly:"季方案",annual:"年方案",custom:"自訂期限"})[status.plan]||"Pro";
        target.innerHTML=`<span>${plan}</span><span>有效至 ${formatMembershipDate(status.current_period_end)}</span><span>不自動續扣</span>`;
      }else if(status?.status==="pending")target.innerHTML="<span>付款確認中</span>";
      else target.innerHTML="<span>免費方案</span><span>可選月／季／年</span>";
    }
    const billingPlanPresentation={
      monthly:{label:"月方案",amount:"NT$399"},
      quarterly:{label:"季方案",amount:"NT$999"},
      annual:{label:"年方案",amount:"NT$2,999"}
    };
    function paymentPlanPresentation(status){
      const fallback=billingPlanPresentation[status?.plan]||{label:"",amount:"—"};
      const configured=(state.billingConfig?.plans||[]).find(plan=>plan.code===status?.plan);
      const amount=Number(configured?.amount);
      return {
        label:fallback.label,
        amount:Number.isFinite(amount)?`NT$${amount.toLocaleString("zh-TW")}`:fallback.amount
      };
    }
    function previewExpiryForPlan(plan){
      const months=({monthly:1,quarterly:3,annual:12})[plan]||12;
      const date=new Date();
      date.setMonth(date.getMonth()+months);
      return date.toISOString();
    }
    function finishPaymentSuccess(destination="membership"){
      closeModals();
      if(destination==="content"){
        if(state.upgradeReturnGame){const game=state.upgradeReturnGame;state.upgradeReturnGame=null;openGame(game)}
        else showPage("predictionPage");
      }else showPage("membershipPage");
    }
    function showPaymentSuccess(status,tradeNo="",options={}){
      clearPaymentSuccessTimers();
      const preview=Boolean(options.preview);
      const presentation=paymentPlanPresentation(status);
      document.getElementById("paymentSuccessKicker").textContent=preview?"FOUNDER PREVIEW":"PAYMENT VERIFIED";
      document.getElementById("paymentSuccessTitle").textContent=preview?"付款成功畫面預覽":"付款成功，Pro 已開通";
      document.getElementById("paymentSuccessCopy").textContent=preview?"這是創辦人介面預覽，不會呼叫綠界、不會新增付款紀錄，也不會變更會員期限。":"交易已由綠界與 DiamondMind 後端完成驗證。你的 Pro 權限已立即生效。";
      document.getElementById("paymentSuccessPlan").textContent=presentation.label?`DiamondMind Pro ${presentation.label}`:"DiamondMind Pro";
      document.getElementById("paymentSuccessAmount").textContent=presentation.amount;
      document.getElementById("paymentSuccessExpiry").textContent=formatMembershipDate(status?.current_period_end);
      document.getElementById("paymentSuccessTradeNo").textContent=tradeNo||status?.merchant_trade_no||"已完成後端驗證";
      const progress=document.getElementById("paymentSuccessProgress");
      if(progress){progress.style.animation="none";void progress.offsetWidth;progress.style.animation="paymentSuccessCountdown 5s linear forwards"}
      let seconds=5;
      const countdown=document.getElementById("paymentSuccessCountdown");
      if(countdown)countdown.textContent=`${seconds} 秒後返回會員中心`;
      openModal("paymentSuccessModal");
      state.paymentSuccessInterval=setInterval(()=>{
        seconds=Math.max(0,seconds-1);
        if(countdown)countdown.textContent=seconds?`${seconds} 秒後返回會員中心`:"正在返回會員中心…";
      },1000);
      state.paymentSuccessTimer=setTimeout(()=>finishPaymentSuccess("membership"),5000);
    }
    document.getElementById("paymentSuccessMemberButton").addEventListener("click",()=>finishPaymentSuccess("membership"));
    document.getElementById("paymentSuccessContinueButton").addEventListener("click",()=>finishPaymentSuccess("content"));
    document.getElementById("paymentSuccessPreviewButton")?.addEventListener("click",()=>{
      if(!isAdminMember()){showToast("只有創辦人可以使用付款成功畫面預覽");return}
      const plan=document.getElementById("paymentSuccessPreviewPlan")?.value||"annual";
      const expiry=previewExpiryForPlan(plan);
      state.upgradeReturnGame=null;
      showPaymentSuccess({plan,current_period_end:expiry,active:true},"PREVIEW · NO CHARGE",{preview:true});
    });

    async function handlePaymentReturn(){
      if(state.paymentHandled||!authState.ready)return;
      const params=new URLSearchParams(location.search);const result=params.get("payment");
      if(!result)return;
      state.paymentHandled=true;showPage("membershipPage");
      if(result==="cancelled"){showToast("已返回 DiamondMind，未完成付款");cleanPaymentQuery();return}
      if(result==="failed"){showToast("付款未完成，Pro 權限沒有變更");cleanPaymentQuery();return}
      if(result==="success"){
        showToast("付款結果驗證中，正在更新 Pro 權限");
        let activated=false;
        for(let i=0;i<8;i++){
          await new Promise(resolve=>setTimeout(resolve,i?1600:500));
          const status=await loadBillingStatus();
          if(status?.active){
            activated=true;
            if(authState.session?.refresh_token){try{await refreshAuthSession(authState.session.refresh_token)}catch{}}
            const finalStatus=await loadBillingStatus()||status;
            await loadBillingConfig();
            renderAuthState();
            cleanPaymentQuery();
            showPaymentSuccess(finalStatus,params.get("trade_no")||"");
            break;
          }
        }
        if(!activated){
          showToast("付款結果仍在同步，請稍後重新整理會員方案");
          cleanPaymentQuery();
        }
      }
    }
    function cleanPaymentQuery(){
      const url=new URL(location.href);url.searchParams.delete("payment");url.searchParams.delete("trade_no");history.replaceState(null,"",`${url.pathname}${url.search}#membership`);
    }


    let toastTimer;
    function showToast(message){
      const toast=document.getElementById("toast");
      toast.textContent=message;
      toast.classList.add("show");
      clearTimeout(toastTimer);
      toastTimer=setTimeout(()=>toast.classList.remove("show"),2600);
    }
    document.getElementById("themeInfo").addEventListener("click",()=>showToast("DiamondMind 前端運作正常 · MLB／NPB 多聯盟資料按需求載入"));

    let authRefreshTimer;
    let appHeartbeatTimer=null;
    let appWakePromise=null;
    let appHiddenAt=0;
    const APP_HEARTBEAT_MS=5*60*1000;
    const APP_RESUME_REFRESH_MS=60*1000;

    async function warmDiamondMindBackend(timeout=70000){
      const controller=new AbortController();
      const timer=setTimeout(()=>controller.abort(),timeout);
      try{
        const response=await fetch(`${API_BASE}/health`,{
          method:"GET",
          headers:{Accept:"application/json"},
          cache:"no-store",
          signal:controller.signal
        });
        return response.ok;
      }catch{
        return false;
      }finally{
        clearTimeout(timer);
      }
    }

    async function refreshSessionAfterResume(){
      const session=authState.session;
      if(!session?.refresh_token)return;
      const secondsLeft=Number(session.expires_at||0)-Math.floor(Date.now()/1000);
      try{
        if(secondsLeft<=300){
          await refreshAuthSession(session.refresh_token);
          return;
        }
        const user=await fetchAuthUser(session);
        authState.user=user;
        authState.session.user=user;
        authState.role=memberRole(user);
        saveAuthSession(authState.session);
        renderAuthState();
      }catch(error){
        if(error?.status===401||error?.status===403)clearAuthSession();
      }
    }

    async function wakeAndRefreshDiamondMind(showStatus=false){
      if(document.visibilityState==="hidden")return false;
      if(appWakePromise)return appWakePromise;
      appWakePromise=(async()=>{
        if(showStatus)showToast("正在同步會員與最新資料…");
        const backendReady=await warmDiamondMindBackend();
        if(authState.ready&&isSignedIn())await refreshSessionAfterResume();
        if(backendReady&&showStatus)showToast("同步完成");
        return backendReady;
      })().finally(()=>{appWakePromise=null});
      return appWakePromise;
    }

    function startAppHeartbeat(){
      clearInterval(appHeartbeatTimer);
      appHeartbeatTimer=setInterval(()=>{
        if(document.visibilityState==="visible")warmDiamondMindBackend(15000);
      },APP_HEARTBEAT_MS);
    }

    document.addEventListener("visibilitychange",()=>{
      if(document.visibilityState==="hidden"){
        appHiddenAt=Date.now();
        return;
      }
      const hiddenFor=appHiddenAt?Date.now()-appHiddenAt:APP_RESUME_REFRESH_MS;
      appHiddenAt=0;
      wakeAndRefreshDiamondMind(hiddenFor>=APP_RESUME_REFRESH_MS);
    });

    window.addEventListener("pageshow",event=>{
      if(event.persisted)wakeAndRefreshDiamondMind(true);
      else warmDiamondMindBackend();
    });
    window.addEventListener("online",()=>wakeAndRefreshDiamondMind(true));
    warmDiamondMindBackend();
    startAppHeartbeat();

    async function authRequest(path,{method="GET",body,accessToken,timeout=12000}={}){
      const controller=new AbortController();
      const timer=setTimeout(()=>controller.abort(),timeout);
      const headers={apikey:SUPABASE_PUBLISHABLE_KEY,Accept:"application/json"};
      if(body!==undefined)headers["Content-Type"]="application/json";
      if(accessToken)headers.Authorization=`Bearer ${accessToken}`;
      try{
        const response=await fetch(`${SUPABASE_URL}/auth/v1${path}`,{
          method,headers,body:body===undefined?undefined:JSON.stringify(body),signal:controller.signal
        });
        const raw=await response.text();
        let payload={};
        if(raw){try{payload=JSON.parse(raw)}catch{payload={message:raw}}}
        if(!response.ok){
          const error=new Error(payload.msg||payload.message||payload.error_description||payload.error||`HTTP ${response.status}`);
          error.status=response.status;
          error.code=payload.error_code||payload.code||payload.error||"";
          throw error;
        }
        return payload;
      }catch(error){
        if(error.name==="AbortError"){
          const timeoutError=new Error("request_timeout");
          timeoutError.code="request_timeout";
          throw timeoutError;
        }
        throw error;
      }finally{clearTimeout(timer)}
    }

    function normalizeSession(payload){
      if(!payload?.access_token)return null;
      const expiresIn=Number(payload.expires_in||3600);
      return {
        access_token:payload.access_token,
        refresh_token:payload.refresh_token||"",
        token_type:payload.token_type||"bearer",
        expires_in:expiresIn,
        expires_at:Number(payload.expires_at)||Math.floor(Date.now()/1000)+expiresIn,
        user:payload.user||null
      };
    }
    function saveAuthSession(session){
      try{
        if(session)localStorage.setItem(AUTH_STORAGE_KEY,JSON.stringify(session));
        else localStorage.removeItem(AUTH_STORAGE_KEY);
      }catch{}
    }
    function loadAuthSession(){
      try{
        const parsed=JSON.parse(localStorage.getItem(AUTH_STORAGE_KEY)||"null");
        return parsed?.access_token?parsed:null;
      }catch{
        saveAuthSession(null);
        return null;
      }
    }
    function memberDisplayName(user){
      const metadata=user?.user_metadata||{};
      return String(metadata.nickname||metadata.full_name||user?.email?.split("@")[0]||"DiamondMind 會員").trim()||"DiamondMind 會員";
    }
    function isSignedIn(){
      return Boolean(authState.session?.access_token&&authState.user);
    }
    function memberRole(user){
      const role=String(user?.app_metadata?.role||"free").toLowerCase();
      if(role==="admin"||role==="founder")return "admin";
      if(role!=="pro")return "free";
      const expires=user?.app_metadata?.pro_expires_at;
      if(!expires)return "free";
      const time=new Date(expires).getTime();
      return Number.isFinite(time)&&time>Date.now()?"pro":"free";
    }
    function isAdminMember(){
      return isSignedIn()&&authState.role==="admin";
    }
    function isProMember(){
      return isSignedIn()&&(authState.role==="pro"||authState.role==="admin");
    }
    function renderMembershipState(){
      const signedIn=isSignedIn();
      const admin=isAdminMember();
      const entitled=isProMember();
      const currentPlan=document.getElementById("membershipCurrentPlan");
      const currentCopy=document.getElementById("membershipCurrentCopy");
      const memberBadge=document.getElementById("memberPlanBadge");
      const memberPlanAction=document.getElementById("memberPlanAction");
      const predictionPlanCopy=document.getElementById("predictionPlanCopy");
      const predictionPlanButton=document.getElementById("predictionPlanButton");
      const predictionUpgradeButton=document.getElementById("predictionUpgradeButton");
      if(memberBadge){
        memberBadge.textContent=admin?"創辦人":entitled?"Pro 會員":"免費會員";
        memberBadge.dataset.tier=admin?"FOUNDER":entitled?"PRO":"FREE";
        memberBadge.classList.toggle("founder",admin);
      }
      if(memberPlanAction)memberPlanAction.textContent=admin?"查看完整權限":entitled?"管理方案":"升級 Pro";
      if(predictionPlanCopy)predictionPlanCopy.textContent=admin?"創辦人權限已啟用，不需訂閱 Pro；所有正式發布的會員玩法都可查看。":entitled?"你的 Pro 會員權限已啟用；正式玩法資料會依發布門檻顯示。":"目前為免費會員，可查看每日一場合格獨贏精選。升級 Pro 後可解鎖完整玩法區。";
      if(predictionPlanButton)predictionPlanButton.hidden=admin;
      if(predictionUpgradeButton)predictionUpgradeButton.hidden=entitled;
      document.querySelectorAll("[data-pro-feature]").forEach(card=>{
        card.classList.toggle("locked",!entitled);
        card.classList.toggle("open",entitled);
        const chip=card.querySelector("[data-pro-access-chip]");
        const lock=card.querySelector("[data-pro-lock]");
        if(chip){
          chip.textContent=admin?"創辦人":entitled?"已開放":"PRO";
          chip.classList.toggle("lock",!entitled);
        }
        if(lock)lock.hidden=entitled;
      });
      if(!entitled)renderLockedProPredictions();
      document.querySelectorAll("[data-plan-select]").forEach(button=>{
        if(!button.dataset.defaultText)button.dataset.defaultText=button.textContent;
        button.disabled=admin||entitled;
        button.textContent=admin?"創辦人免訂閱":entitled?"目前已是 Pro":button.dataset.defaultText;
      });
      if(!currentPlan||!currentCopy)return;
      if(!signedIn){
        currentPlan.textContent="尚未登入";
        currentCopy.textContent="登入後即可查看會員狀態";
      }else if(admin){
        currentPlan.textContent="創辦人／管理員";
        currentCopy.textContent="永久開放所有會員與管理權限";
      }else if(entitled){
        currentPlan.textContent="DiamondMind Pro";
        currentCopy.textContent=`完整權限已啟用${authState.user?.app_metadata?.pro_expires_at?`，有效至 ${formatMembershipDate(authState.user.app_metadata.pro_expires_at)}`:""}`;
      }else{
        currentPlan.textContent="免費會員";
        currentCopy.textContent="每日最多一場獨贏精選";
      }
    }
    function renderPredictionAccess(){
      const apiStatus=document.getElementById("predictionApiStatus");
      if(!apiStatus)return;
      if(!isSignedIn()){
        apiStatus.textContent="登入後查看";
        apiStatus.classList.remove("demo-pill");
      }else if(!state.predictionDate){
        apiStatus.textContent="模型 API 準備連線";
        apiStatus.classList.remove("demo-pill");
      }
    }
    function scheduleAuthRefresh(){
      clearTimeout(authRefreshTimer);
      const session=authState.session;
      if(!session?.refresh_token||!session.expires_at)return;
      const delay=Math.max(5000,(Number(session.expires_at)-Math.floor(Date.now()/1000)-90)*1000);
      authRefreshTimer=setTimeout(async()=>{
        try{await refreshAuthSession(session.refresh_token)}catch{clearAuthSession()}
      },Math.min(delay,2147483647));
    }
    function renderAuthState(){
      const signedIn=isSignedIn();
      authState.role=signedIn?memberRole(authState.user):"free";
      document.querySelectorAll("[data-auth-guest]").forEach(element=>element.hidden=signedIn);
      document.querySelectorAll("[data-auth-user]").forEach(element=>element.hidden=!signedIn);
      document.querySelectorAll("[data-auth-admin]").forEach(element=>element.hidden=!isAdminMember());
      if(signedIn){
        const name=memberDisplayName(authState.user);
        document.getElementById("headerMemberName").textContent=name;
        document.getElementById("memberNickname").textContent=name;
        document.getElementById("memberEmail").textContent=authState.user.email||"會員帳號";
        scheduleAuthRefresh();
      }else clearTimeout(authRefreshTimer);
      renderMembershipState();
      renderBillingMeta();
      if(signedIn)loadBillingStatus();
      renderPredictionAccess();
      renderRecords();
      if(document.getElementById("recordsPage")?.classList.contains("active")&&state.recordsAccessRole!==authState.role)loadRecords(true);
      if(signedIn&&document.getElementById("predictionPage")?.classList.contains("active")){
        loadTopPrediction();
        if(isAdminMember()){loadFounderCandidates();loadFounderMarkets();}
      }
    }
    function clearAuthSession(){
      authState.session=null;
      authState.user=null;
      authState.role="free";
      authState.trialJustGranted=false;
      state.predictionDate="";
      state.predictionRole="";
      state.marketRecords=[];
      state.proPerformance=null;
      state.recordsLoaded=false;
      state.recordsAccessRole="";
      state.founderCandidateDate="";
      state.founderMarketDate="";
      state.founderMarketBundle=null;
      state.adminMembers=null;state.adminTransactions=null;state.adminSelectedMember=null;state.adminMembersOffset=0;state.adminTransactionsOffset=0;
      state.homeAnnouncementRole="";state.announcementLoginChecked="";state.announcementModalItem=null;
      saveAuthSession(null);
      renderAuthState();
    }
    async function fetchAuthUser(session){
      const payload=await authRequest("/user",{accessToken:session.access_token});
      return payload.user||payload;
    }
    async function claimNewMemberTrial(session){
      if(!session?.access_token)return null;
      try{
        const response=await fetch(`${API_BASE}/membership/trial/claim`,{method:"POST",headers:{Accept:"application/json",Authorization:`Bearer ${session.access_token}`},cache:"no-store"});
        const raw=await response.text();let payload={};if(raw){try{payload=JSON.parse(raw)}catch{payload={}}}
        if(!response.ok)return null;
        return payload;
      }catch{return null}
    }
    async function acceptAuthSession(payload){
      const session=normalizeSession(payload);
      if(!session)throw new Error("missing_session");
      session.user=session.user||await fetchAuthUser(session);
      const trial=await claimNewMemberTrial(session);
      if(trial?.granted){session.user=await fetchAuthUser(session);authState.trialJustGranted=true}
      authState.session=session;
      authState.user=session.user;
      authState.role=memberRole(session.user);
      saveAuthSession(session);
      renderAuthState();
      return session;
    }
    async function refreshAuthSession(refreshToken){
      const payload=await authRequest("/token?grant_type=refresh_token",{method:"POST",body:{refresh_token:refreshToken}});
      return acceptAuthSession(payload);
    }
    function setAuthNote(id,message,type=""){
      const note=document.getElementById(id);
      note.textContent=message;
      note.classList.toggle("error",type==="error");
      note.classList.toggle("success",type==="success");
    }
    function setAuthFormBusy(form,busy,busyText){
      const button=form.querySelector('button[type="submit"]');
      if(!button)return;
      if(!button.dataset.defaultText)button.dataset.defaultText=button.textContent;
      button.disabled=busy;
      button.textContent=busy?busyText:button.dataset.defaultText;
    }
    function authErrorMessage(error){
      const value=`${error?.code||""} ${error?.message||""}`.toLowerCase();
      if(value.includes("invalid_credentials")||value.includes("invalid login credentials"))return "電子信箱或密碼不正確。";
      if(value.includes("email_not_confirmed")||value.includes("email not confirmed"))return "請先到信箱完成帳號驗證，再回來登入。";
      if(value.includes("user_already_exists")||value.includes("already registered"))return "此電子信箱已經註冊，請直接登入。";
      if(value.includes("weak_password")||value.includes("password should"))return "密碼強度不足，請至少輸入 6 個字元。";
      if(value.includes("signup_disabled"))return "目前暫停新會員註冊。";
      if(value.includes("rate")||error?.status===429)return "操作過於頻繁，請稍後再試。";
      if(value.includes("request_timeout"))return "會員服務回應逾時，請稍後再試。";
      if(error instanceof TypeError)return "會員服務暫時無法連線，請檢查網路後重試。";
      return "操作未完成，請確認資料後再試。";
    }

    function announcementHeaders(includeAuth=true){
      const headers={Accept:"application/json","Content-Type":"application/json"};
      if(includeAuth&&authState.session?.access_token)headers.Authorization=`Bearer ${authState.session.access_token}`;
      return headers;
    }
    async function announcementFetch(path,{method="GET",body,admin=false}={}){
      const response=await fetch(`${API_BASE}${path}`,{method,headers:announcementHeaders(true),body:body===undefined?undefined:JSON.stringify(body),cache:"no-store"});
      const raw=await response.text();let payload={};if(raw){try{payload=JSON.parse(raw)}catch{payload={detail:raw}}}
      if(!response.ok){const error=new Error(payload.detail||payload.message||`HTTP ${response.status}`);error.status=response.status;throw error}
      return payload;
    }
    function announcementLevelLabel(severity){return severity==="emergency"?"緊急":severity==="important"?"重要":"公告"}
    function announcementDateLabel(item){
      const value=item.updated_at||item.created_at||item.starts_at;if(!value)return "";
      const date=new Date(value);if(Number.isNaN(date.getTime()))return "";
      return new Intl.DateTimeFormat("zh-TW",{timeZone:"Asia/Taipei",month:"2-digit",day:"2-digit",hour:"2-digit",minute:"2-digit",hour12:false}).format(date);
    }
    function announcementAction(item){
      if(!item?.action_page)return;
      closeAnnouncementModal(true);
      showPage(item.action_page);
      if(item.action_page==="membershipPage")window.setTimeout(()=>document.getElementById("pricingPlans")?.scrollIntoView({behavior:"smooth",block:"start"}),220);
    }
    function renderHomeAnnouncements(){
      const section=document.getElementById("homeAnnouncementsSection");const list=document.getElementById("homeAnnouncementList");if(!section||!list)return;
      const items=state.homeAnnouncements||[];section.hidden=!items.length;
      list.innerHTML=items.map(item=>`<article class="announcement-item ${escapeHtml(item.severity||"general")}"><span class="announcement-level">${announcementLevelLabel(item.severity)}</span><div><h4>${escapeHtml(item.title)}</h4><p>${escapeHtml(item.summary||item.body||"")}</p><span class="announcement-date">更新 ${escapeHtml(announcementDateLabel(item))}</span></div>${item.action_page&&item.action_label?`<button type="button" class="btn ghost small" data-home-announcement-action="${escapeHtml(item.id)}">${escapeHtml(item.action_label)}</button>`:""}</article>`).join("");
      list.querySelectorAll("[data-home-announcement-action]").forEach(button=>button.addEventListener("click",()=>announcementAction(items.find(item=>String(item.id)===button.dataset.homeAnnouncementAction))));
    }
    async function loadHomeAnnouncements(force=false){
      const role=isSignedIn()?authState.role:"guest";if(!force&&state.homeAnnouncementRole===role)return;
      try{const payload=await announcementFetch("/announcements/active?placement=home");state.homeAnnouncements=payload.items||[];state.homeAnnouncementRole=role;renderHomeAnnouncements()}catch{state.homeAnnouncements=[];state.homeAnnouncementRole=role;renderHomeAnnouncements()}
    }
    function announcementDismissKey(item){
      const version=String(item?.updated_at||item?.created_at||"").replace(/[^0-9]/g,"").slice(0,20);
      return `diamondmind.announcement.dismissed.${authState.user?.id||"guest"}.${item?.id}.${version}.${taiwanToday()}`;
    }
    function announcementWasDismissed(item){try{return localStorage.getItem(announcementDismissKey(item))==="1"}catch{return false}}
    function rememberAnnouncementDismissal(item){if(!item||!document.getElementById("announcementDismissToday")?.checked)return;try{localStorage.setItem(announcementDismissKey(item),"1")}catch{}}
    function displayAnnouncementModal(item,{preview=false}={}){
      if(!item)return;state.announcementModalItem=item;state.announcementModalPreview=preview;
      const modal=document.getElementById("announcementModal");modal.classList.remove("general","important","emergency");modal.classList.add(item.severity||"general");
      document.getElementById("announcementModalBadge").textContent=preview?"FOUNDER PREVIEW":item.severity==="emergency"?"緊急公告":item.severity==="important"?"重要公告":"DIAMONDMIND 公告";
      document.getElementById("announcementModalTitle").textContent=item.title||"最新公告";
      document.getElementById("announcementModalMeta").textContent=`${announcementDateLabel(item)||"即時公告"} · ${item.audience==="pro"?"Pro 會員":item.audience==="free"?"免費會員":"全部使用者"}`;
      document.getElementById("announcementModalBody").textContent=item.body||item.summary||"";
      const dismissible=!preview&&item.dismissible_today!==false&&item.severity!=="emergency";
      document.getElementById("announcementDismissRow").hidden=!dismissible;document.getElementById("announcementDismissToday").checked=false;
      const action=document.getElementById("announcementActionButton");action.hidden=!(item.action_page&&item.action_label);action.textContent=item.action_label||"前往查看";
      openModal("announcementModal");
    }
    function closeAnnouncementModal(remember=true){
      if(remember&&!state.announcementModalPreview)rememberAnnouncementDismissal(state.announcementModalItem);
      closeModals();state.announcementModalItem=null;state.announcementModalPreview=false;
    }
    document.getElementById("announcementAcknowledgeButton").addEventListener("click",()=>closeAnnouncementModal(true));
    document.getElementById("announcementActionButton").addEventListener("click",()=>announcementAction(state.announcementModalItem));
    async function maybeShowLoginAnnouncement(force=false){
      if(!isSignedIn())return;const checkKey=`${authState.user?.id||""}.${taiwanToday()}`;if(!force&&state.announcementLoginChecked===checkKey)return;state.announcementLoginChecked=checkKey;
      try{const payload=await announcementFetch("/announcements/active?placement=login");const item=(payload.items||[]).find(value=>!announcementWasDismissed(value));if(item)window.setTimeout(()=>displayAnnouncementModal(item),280)}catch{}
    }
    function toLocalDateTime(value){if(!value)return "";const d=new Date(value);if(Number.isNaN(d.getTime()))return "";const z=n=>String(n).padStart(2,"0");return `${d.getFullYear()}-${z(d.getMonth()+1)}-${z(d.getDate())}T${z(d.getHours())}:${z(d.getMinutes())}`}
    function fromLocalDateTime(value){if(!value)return null;const d=new Date(value);return Number.isNaN(d.getTime())?null:d.toISOString()}
    function announcementFormPayload(){
      const severity=document.getElementById("announcementSeverity").value;
      return {title:document.getElementById("announcementTitle").value.trim(),summary:document.getElementById("announcementSummary").value.trim()||null,body:document.getElementById("announcementBody").value.trim(),severity,audience:document.getElementById("announcementAudience").value,starts_at:fromLocalDateTime(document.getElementById("announcementStartsAt").value),ends_at:fromLocalDateTime(document.getElementById("announcementEndsAt").value),action_label:document.getElementById("announcementActionLabel").value.trim()||null,action_page:document.getElementById("announcementActionPage").value||null,show_home:document.getElementById("announcementShowHome").checked,show_login_modal:document.getElementById("announcementShowLogin").checked,dismissible_today:severity==="emergency"?false:document.getElementById("announcementDismissible").checked,is_active:document.getElementById("announcementActive").checked};
    }
    function setAnnouncementAdminNote(message,type=""){const note=document.getElementById("announcementAdminNote");if(!note)return;note.textContent=message;note.classList.toggle("error",type==="error");note.classList.toggle("success",type==="success")}
    function resetAnnouncementForm(){
      state.editingAnnouncementId=null;document.getElementById("announcementAdminForm").reset();document.getElementById("announcementShowHome").checked=true;document.getElementById("announcementShowLogin").checked=true;document.getElementById("announcementDismissible").checked=true;document.getElementById("announcementActive").checked=true;document.getElementById("announcementFormTitle").textContent="新增公告";document.getElementById("announcementSaveButton").textContent="發布公告";setAnnouncementAdminNote("");
    }
    function fillAnnouncementForm(item){
      state.editingAnnouncementId=item.id;document.getElementById("announcementTitle").value=item.title||"";document.getElementById("announcementSummary").value=item.summary||"";document.getElementById("announcementBody").value=item.body||"";document.getElementById("announcementSeverity").value=item.severity||"general";document.getElementById("announcementAudience").value=item.audience||"all";document.getElementById("announcementStartsAt").value=toLocalDateTime(item.starts_at);document.getElementById("announcementEndsAt").value=toLocalDateTime(item.ends_at);document.getElementById("announcementActionLabel").value=item.action_label||"";document.getElementById("announcementActionPage").value=item.action_page||"";document.getElementById("announcementShowHome").checked=Boolean(item.show_home);document.getElementById("announcementShowLogin").checked=Boolean(item.show_login_modal);document.getElementById("announcementDismissible").checked=Boolean(item.dismissible_today);document.getElementById("announcementActive").checked=Boolean(item.is_active);document.getElementById("announcementFormTitle").textContent="編輯公告";document.getElementById("announcementSaveButton").textContent="儲存修改";setAnnouncementAdminNote(`正在編輯：${item.title}`);window.scrollTo({top:0,behavior:"smooth"});
    }
    function renderAdminAnnouncements(){
      const list=document.getElementById("announcementAdminList");if(!list)return;const items=state.adminAnnouncements||[];
      if(!items.length){list.innerHTML='<div class="announcement-empty">目前尚未建立公告。</div>';return}
      list.innerHTML=items.map(item=>`<article class="announcement-admin-row"><div class="announcement-admin-row-top"><div><h3>${escapeHtml(item.title)}</h3><p>${escapeHtml(item.summary||item.body||"")}</p></div><span class="announcement-level">${announcementLevelLabel(item.severity)}</span></div><div class="announcement-admin-chips"><span>${item.is_active?"啟用中":"已暫停"}</span><span>${item.audience==="pro"?"Pro":item.audience==="free"?"免費會員":"全部"}</span><span>${item.show_home?"首頁":"不顯示首頁"}</span><span>${item.show_login_modal?"登入彈窗":"不彈窗"}</span><span>更新 ${escapeHtml(announcementDateLabel(item))}</span></div><div class="announcement-admin-actions"><button type="button" class="btn ghost small" data-ann-edit="${escapeHtml(item.id)}">編輯</button><button type="button" class="btn ghost small" data-ann-toggle="${escapeHtml(item.id)}">${item.is_active?"暫停":"啟用"}</button><button type="button" class="btn ghost small" data-ann-preview="${escapeHtml(item.id)}">預覽</button><button type="button" class="btn ghost small" data-ann-delete="${escapeHtml(item.id)}">刪除</button></div></article>`).join("");
      const find=id=>items.find(item=>String(item.id)===String(id));
      list.querySelectorAll("[data-ann-edit]").forEach(btn=>btn.addEventListener("click",()=>fillAnnouncementForm(find(btn.dataset.annEdit))));
      list.querySelectorAll("[data-ann-preview]").forEach(btn=>btn.addEventListener("click",()=>displayAnnouncementModal(find(btn.dataset.annPreview),{preview:true})));
      list.querySelectorAll("[data-ann-toggle]").forEach(btn=>btn.addEventListener("click",async()=>{const item=find(btn.dataset.annToggle);if(!item)return;try{await announcementFetch(`/admin/announcements/${item.id}`,{method:"PATCH",body:{...item,is_active:!item.is_active}});showToast(item.is_active?"公告已暫停":"公告已啟用");await loadAdminAnnouncements(true);await loadHomeAnnouncements(true)}catch(error){showToast(error.message)}}));
      list.querySelectorAll("[data-ann-delete]").forEach(btn=>btn.addEventListener("click",async()=>{const item=find(btn.dataset.annDelete);if(!item||!confirm(`確定刪除「${item.title}」？`))return;try{await announcementFetch(`/admin/announcements/${item.id}`,{method:"DELETE"});showToast("公告已刪除");if(state.editingAnnouncementId===item.id)resetAnnouncementForm();await loadAdminAnnouncements(true);await loadHomeAnnouncements(true)}catch(error){showToast(error.message)}}));
    }
    async function loadAdminAnnouncements(force=false){
      if(!isAdminMember())return;if(!force&&state.adminAnnouncements.length){renderAdminAnnouncements();return}
      try{const payload=await announcementFetch("/admin/announcements");state.adminAnnouncements=payload.items||[];renderAdminAnnouncements()}catch(error){document.getElementById("announcementAdminList").innerHTML=`<div class="announcement-empty">${escapeHtml(error.message)}</div>`}
    }
    document.getElementById("announcementAdminForm").addEventListener("submit",async event=>{event.preventDefault();const payload=announcementFormPayload();if(!payload.title||!payload.body){setAnnouncementAdminNote("請填寫公告標題與內容。","error");return}const button=document.getElementById("announcementSaveButton");button.disabled=true;try{const path=state.editingAnnouncementId?`/admin/announcements/${state.editingAnnouncementId}`:"/admin/announcements";await announcementFetch(path,{method:state.editingAnnouncementId?"PATCH":"POST",body:payload});setAnnouncementAdminNote(state.editingAnnouncementId?"公告修改完成。":"公告發布完成。","success");showToast(state.editingAnnouncementId?"公告已更新":"公告已發布");resetAnnouncementForm();await loadAdminAnnouncements(true);await loadHomeAnnouncements(true)}catch(error){setAnnouncementAdminNote(error.message,"error")}finally{button.disabled=false}});
    document.getElementById("announcementPreviewButton").addEventListener("click",()=>{const item={...announcementFormPayload(),id:"preview",updated_at:new Date().toISOString()};if(!item.title||!item.body){setAnnouncementAdminNote("請先填寫公告標題與內容。","error");return}displayAnnouncementModal(item,{preview:true})});
    document.getElementById("announcementResetButton").addEventListener("click",resetAnnouncementForm);
    document.getElementById("announcementAdminRefresh").addEventListener("click",()=>loadAdminAnnouncements(true));
    document.getElementById("announcementSeverity").addEventListener("change",event=>{if(event.target.value==="emergency"){document.getElementById("announcementDismissible").checked=false;document.getElementById("announcementDismissible").disabled=true}else document.getElementById("announcementDismissible").disabled=false});

    document.getElementById("loginForm").addEventListener("submit",async event=>{
      event.preventDefault();
      const form=event.currentTarget;
      const email=document.getElementById("loginEmail").value.trim();
      const password=document.getElementById("loginPassword").value;
      setAuthNote("loginNote","正在安全登入…");
      setAuthFormBusy(form,true,"登入中…");
      try{
        const payload=await authRequest("/token?grant_type=password",{method:"POST",body:{email,password}});
        await acceptAuthSession(payload);
        form.reset();
        closeModals();
        showPage("morePage");
        showToast(authState.trialJustGranted?"新會員 1 天 Pro 試用已自動開通":`歡迎回來，${memberDisplayName(authState.user)}`);authState.trialJustGranted=false;
        state.homeAnnouncementRole="";loadHomeAnnouncements(true);window.setTimeout(()=>maybeShowLoginAnnouncement(true),420);
        setAuthNote("loginNote","使用你註冊時的電子信箱與密碼登入。");
      }catch(error){setAuthNote("loginNote",authErrorMessage(error),"error")}
      finally{setAuthFormBusy(form,false,"登入中…")}
    });

    document.getElementById("registerForm").addEventListener("submit",async event=>{
      event.preventDefault();
      const form=event.currentTarget;
      const nickname=document.getElementById("registerNickname").value.trim();
      const email=document.getElementById("registerEmail").value.trim();
      const password=document.getElementById("registerPassword").value;
      setAuthNote("registerNote","正在建立安全帳號…");
      setAuthFormBusy(form,true,"建立中…");
      try{
        const redirect=`/signup?redirect_to=${encodeURIComponent(AUTH_REDIRECT_URL)}`;
        const payload=await authRequest(redirect,{method:"POST",body:{email,password,data:{nickname}}});
        if(payload.access_token){
          await acceptAuthSession(payload);
          form.reset();
          closeModals();
          showPage("morePage");
          showToast(authState.trialJustGranted?"帳號建立完成，1 天 Pro 試用已開通":`帳號建立完成，歡迎 ${memberDisplayName(authState.user)}`);authState.trialJustGranted=false;
          state.homeAnnouncementRole="";loadHomeAnnouncements(true);window.setTimeout(()=>maybeShowLoginAnnouncement(true),420);
        }else{
          form.reset();
          setAuthNote("registerNote","註冊資料已送出，請到信箱點擊驗證連結後再登入。","success");
          showToast("註冊成功，請到信箱完成驗證");
        }
      }catch(error){setAuthNote("registerNote",authErrorMessage(error),"error")}
      finally{setAuthFormBusy(form,false,"建立中…")}
    });

    document.querySelectorAll("[data-auth-logout]").forEach(button=>button.addEventListener("click",async()=>{
      const session=authState.session;
      button.disabled=true;
      try{
        if(session?.access_token)await authRequest("/logout?scope=local",{method:"POST",accessToken:session.access_token});
      }catch{}finally{
        clearAuthSession();
        button.disabled=false;
        showToast("已安全登出");
      }
    }));

    function consumeAuthCallback(){
      const params=new URLSearchParams(location.hash.replace(/^#/,""));
      const hasSession=params.has("access_token");
      const hasError=params.has("error")||params.has("error_description");
      if(!hasSession&&!hasError)return {handled:false};
      const result={handled:true,error:"",session:null};
      if(hasSession){
        result.session=normalizeSession({
          access_token:params.get("access_token"),refresh_token:params.get("refresh_token"),
          token_type:params.get("token_type"),expires_in:params.get("expires_in"),expires_at:params.get("expires_at")
        });
        if(result.session)saveAuthSession(result.session);
      }else result.error=params.get("error_description")||params.get("error")||"帳號驗證未完成";
      history.replaceState(null,"",`${location.pathname}${location.search}#more`);
      return result;
    }
    async function initializeAuth(callback){
      try{
        let session=callback?.session||loadAuthSession();
        if(!session){
          authState.ready=true;
          renderAuthState();
          if(callback?.error)showToast("驗證連結無效或已過期，請重新登入");
          return;
        }
        if(Number(session.expires_at||0)<=Math.floor(Date.now()/1000)+60&&session.refresh_token){
          await refreshAuthSession(session.refresh_token);
        }else{
          try{session.user=await fetchAuthUser(session)}catch(error){if(!session.user)throw error}
          authState.session=session;
          authState.user=session.user;
          authState.role=memberRole(session.user);
          saveAuthSession(session);
          renderAuthState();
        }
        if(callback?.session)showToast(`信箱驗證完成，歡迎 ${memberDisplayName(authState.user)}`);
      }catch(error){
        clearAuthSession();
        if(callback?.handled)showToast(authErrorMessage(error));
      }finally{authState.ready=true;handlePaymentReturn();loadHomeAnnouncements(true);if(isSignedIn())window.setTimeout(()=>maybeShowLoginAnnouncement(false),520)}
    }

    function escapeHtml(value){
      return String(value??"").replace(/[&<>"']/g,char=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[char]));
    }
    function resultLabel(result){
      return ({won:"命中",lost:"未中",push:"走水",void:"作廢",pending:"未結算"})[result]||"未結算";
    }
    function resultClass(result){return result==="won"?"win":result==="lost"?"loss":result==="push"?"push":result==="void"?"void":"pending"}
    function recordDate(value){
      const parts=String(value||"").split("-");
      return parts.length===3?`${parts[1]}/${parts[2]}`:"—";
    }
    function recordScore(row){
      return row.away_score==null||row.home_score==null?"尚未結算":`終場 ${row.away_score}–${row.home_score}`;
    }
    function asSelectionArray(value){
      if(Array.isArray(value))return value.filter(Boolean);
      return value?[value]:[];
    }
    function marketHistoryRows(bundle){
      const groups=[
        ["moneylines","獨贏",asSelectionArray(bundle.moneylines)],
        ["run_lines","讓分",asSelectionArray(bundle.run_lines||bundle.run_line)],
        ["totals","大小分",asSelectionArray(Array.isArray(bundle.totals)?bundle.totals:(bundle.total||bundle.totals))],
        ["two_leg","二關",asSelectionArray(bundle.parlays?.two_leg)],
        ["three_leg","三關",asSelectionArray(bundle.parlays?.three_leg)]
      ];
      return groups.flatMap(([key,name,selections])=>{
        const resultValue=bundle.results?.[key]??bundle.results?.[key.replace(/s$/,'')];
        const results=asSelectionArray(resultValue);
        return selections.flatMap((selection,index)=>{
          const result=results.find(item=>item?.candidate_id&&item.candidate_id===selection.candidate_id)||results[index]||{status:"pending"};
          const isParlay=key==="two_leg"||key==="three_leg";
          const legs=Array.isArray(selection.legs)?selection.legs:[];
          const pickLabel=isParlay
            ?legs.map(leg=>leg.pick?.label||leg.label).filter(Boolean).join(" ＋ ")
            :(selection.pick?.label||selection.label||"正式推薦");
          const matchup=isParlay
            ?legs.map(leg=>leg.matchup).filter(Boolean).join(" / ")
            :(selection.matchup||"");
          const price=isParlay?selection.combined_american_odds:selection.price;
          const probability=isParlay?selection.combined_model_probability:selection.model_probability;
          const score=result.away_score==null||result.home_score==null
            ?(result.status==="pending"?"等待賽果":isParlay?`${result.legs?.length||legs.length} 關已判定`:(result.result_note||"已判定"))
            :`終場 ${result.away_score}–${result.home_score}`;
          const league=isParlay?[...new Set(legs.map(leg=>leg.league||"MLB"))].join("＋"):(selection.league||"MLB");
          return [{
            key,
            filterKey:isParlay?"parlays":key,
            name,
            date:String(bundle.date||""),
            pickLabel:localizePickLabel(pickLabel,selection),
            matchup:localizeMatchup(matchup),
            price,
            probability,
            score,
            status:result.status||"pending",
            profitUnits:result.performance?.profit_units,
            league
          }];
        });
      });
    }
    function allMarketHistoryRows(){
      return state.marketRecords.flatMap(marketHistoryRows).sort((a,b)=>{
        const dateOrder=String(b.date||"").localeCompare(String(a.date||""));
        if(dateOrder)return dateOrder;
        const order={moneylines:0,run_lines:1,totals:2,two_leg:3,three_leg:4};
        return (order[a.key]??9)-(order[b.key]??9);
      });
    }
    function americanDecimalOdds(price){
      const value=Number(price);if(!Number.isFinite(value)||value===0)return null;
      if(value>1&&value<20&&!Number.isInteger(value))return value;
      if(value>=100)return 1+value/100;if(value<=-100)return 1+100/Math.abs(value);return null;
    }
    function marketRowProfit(row){
      if(row?.profitUnits!==undefined&&row.profitUnits!==null)return Number(row.profitUnits);
      const status=String(row?.status||"pending"),decimal=americanDecimalOdds(row?.price);
      if(status==="void")return 0;if(!["won","lost","push"].includes(status)||decimal===null)return null;
      if(status==="won")return Number((decimal-1).toFixed(4));if(status==="lost")return -1;return 0;
    }
    function formatUnits(value){
      const number=Number(value);if(!Number.isFinite(number))return "—";return `${number>0?"+":""}${number.toFixed(2)}u`;
    }
    function profitClass(value){const number=Number(value);return number>0?"profit-positive":number<0?"profit-negative":"profit-neutral"}
    function profitTone(value){const number=Number(value);return number>0?"green":number<0?"red":""}
    function marketRecordStats(rows){
      const won=rows.filter(row=>row.status==="won").length;
      const lost=rows.filter(row=>row.status==="lost").length;
      const push=rows.filter(row=>row.status==="push").length;
      const voided=rows.filter(row=>row.status==="void").length;
      const pending=rows.filter(row=>row.status==="pending").length;
      const decided=won+lost;
      const priced=rows.map(row=>({row,profit:marketRowProfit(row)})).filter(item=>item.profit!==null&&["won","lost","push"].includes(item.row.status));
      const stake=priced.length,profit=Number(priced.reduce((sum,item)=>sum+item.profit,0).toFixed(3));
      return {total:rows.length,decisions:decided,won,lost,push,void:voided,pending,settled:won+lost+push+voided,rate:decided?Number((won/decided*100).toFixed(1)):null,stake,profit,roi:stake?Number((profit/stake*100).toFixed(2)):null};
    }
    function proSummaryCard(label,value,tone=""){
      return `<div class="pro-record-summary-card"><small>${label}</small><b class="${tone}">${value}</b></div>`;
    }
    function renderProMarketVisuals(rows){
      const target=document.getElementById("proMarketVisuals");
      if(!target)return;
      const definitions=[
        ["moneylines","MONEYLINE","獨贏"],
        ["run_lines","RUN LINE","讓分"],
        ["totals","TOTALS","大小分"]
      ];
      target.innerHTML=definitions.map(([key,code,label])=>{
        const stats=marketRecordStats(rows.filter(row=>row.key===key));
        const rate=stats.rate==null?0:stats.rate;
        const rateText=stats.rate==null?"—":`${stats.rate}%`;
        return `<article class="pro-market-visual">
          <div class="pro-market-visual-top">
            <div class="pro-market-ring" style="background:conic-gradient(var(--green) 0 ${rate}%,rgba(255,255,255,.055) ${rate}% 100%)"><div><b>${rateText}</b><span>命中率</span></div></div>
            <div><span class="market-tag pro">${code}</span><h4>${label}戰績</h4><p>${stats.total?`${stats.total} 筆正式推薦，${stats.settled} 筆已結算。`:"尚無正式推薦紀錄。"}</p></div>
          </div>
          <div class="pro-market-legend"><span><b>${stats.total}</b>推薦</span><span class="win"><b>${stats.won}</b>命中</span><span><b>${stats.settled}</b>結算</span></div>
        </article>`;
      }).join("");
    }

    function performanceCurve(rows){
      const grouped={};rows.filter(row=>marketRowProfit(row)!==null&&["won","lost","push"].includes(row.status)).forEach(row=>{const date=String(row.date||"");grouped[date]=(grouped[date]||0)+marketRowProfit(row)});
      let cumulative=0;return Object.keys(grouped).sort().map(date=>({date,daily:Number(grouped[date].toFixed(3)),cumulative:Number((cumulative+=grouped[date]).toFixed(3))}));
    }
    function renderProLeaguePerformance(rows){
      const target=document.getElementById("proLeaguePerformance");if(!target)return;
      const backend=Array.isArray(state.proPerformance?.by_league)?state.proPerformance.by_league:[];
      const keys=[...new Set(rows.map(row=>row.league||"MLB"))];
      const items=backend.length?backend:keys.map(key=>({key,...marketRecordStats(rows.filter(row=>row.league===key))}));
      target.innerHTML=items.length?items.map(item=>{const local=backend.length?item:marketRecordStats(rows.filter(row=>row.league===item.key));const profit=backend.length?Number(item.profit_units||0):local.profit;const roi=backend.length?item.roi_percent:local.roi;return `<div class="pro-league-row"><div><b>${escapeHtml(item.key||"其他")}</b><span>${Number(item.decisions??local.decisions??0)} 筆有效決策 · 命中率 ${item.hit_rate==null?(local.rate==null?"—":`${local.rate}%`):`${item.hit_rate}%`}</span></div><strong class="${profitClass(profit)}">${formatUnits(profit)}</strong><strong class="${profitClass(roi)}">${roi==null?"—":`${Number(roi).toFixed(2)}%`}</strong></div>`}).join(""):'<div class="empty">尚無可計算績效的正式推薦。</div>';
    }
    function renderProProfitChart(rows){
      const target=document.getElementById("proProfitChart");if(!target)return;
      const backend=Array.isArray(state.proPerformance?.profit_curve)?state.proPerformance.profit_curve:[];
      const curve=backend.length?backend.map(item=>({date:item.date,cumulative:Number(item.cumulative_profit_units||0)})):performanceCurve(rows);
      if(!curve.length){target.innerHTML='<div class="empty">尚無已結算且具有效賠率的推薦。</div>';return}
      const width=680,height=170,padX=26,padY=22,values=curve.map(item=>item.cumulative),min=Math.min(0,...values),max=Math.max(0,...values),range=Math.max(.5,max-min);
      const x=index=>curve.length===1?width/2:padX+index*(width-padX*2)/(curve.length-1);const y=value=>padY+(max-value)*(height-padY*2)/range;const zeroY=y(0);const points=curve.map((item,index)=>`${x(index).toFixed(1)},${y(item.cumulative).toFixed(1)}`).join(" ");const area=`${padX},${zeroY.toFixed(1)} ${points} ${x(curve.length-1).toFixed(1)},${zeroY.toFixed(1)}`;
      const last=curve[curve.length-1],stats=marketRecordStats(rows);
      target.innerHTML=`<div class="pro-profit-chart-meta"><div><b class="${profitClass(last.cumulative)}">${formatUnits(last.cumulative)}</b><span>累計盈虧</span></div><div style="text-align:right"><b class="${profitClass(stats.roi)}">${stats.roi==null?"—":`${stats.roi}%`}</b><span>整體 ROI</span></div></div><svg class="pro-profit-svg" viewBox="0 0 ${width} ${height}" preserveAspectRatio="none" role="img" aria-label="Pro 推薦累計盈虧走勢"><line class="pro-profit-axis" x1="${padX}" y1="${zeroY}" x2="${width-padX}" y2="${zeroY}"></line><polygon class="pro-profit-area" points="${area}"></polygon><polyline class="pro-profit-line" points="${points}"></polyline>${curve.map((item,index)=>`<circle class="pro-profit-dot" cx="${x(index)}" cy="${y(item.cumulative)}" r="3"></circle>`).join("")}<text class="pro-profit-label" x="${padX}" y="${height-4}">${escapeHtml(recordDate(curve[0].date))}</text><text class="pro-profit-label" text-anchor="end" x="${width-padX}" y="${height-4}">${escapeHtml(recordDate(last.date))}</text></svg>`;
    }
    function renderProPerformance(rows){renderProLeaguePerformance(rows);renderProProfitChart(rows)}

    function renderMarketRecords(){
      const rows=allMarketHistoryRows();
      const container=document.getElementById("marketRecordsList");
      const count=document.getElementById("marketRecordCount");
      const summary=document.getElementById("proRecordSummary");
      const visuals=document.getElementById("proMarketVisuals");
      const toolbar=document.getElementById("proRecordListToolbar");
      const performanceLayout=document.getElementById("proPerformanceLayout");
      if(!container||!count||!summary||!visuals)return;
      if(!isProMember()){
        count.textContent="PRO";
        summary.hidden=true;
        visuals.hidden=true;
        if(toolbar)toolbar.hidden=true;
        if(performanceLayout)performanceLayout.hidden=true;
        container.innerHTML=`<div class="record-pro-gate">
          <div>
            <div class="record-pro-gate-icon" aria-hidden="true">🔒</div>
            <h3>Pro 推薦完整紀錄</h3>
            <p>升級 Pro 查看獨贏、讓分、大小分、二關與三關串關的歷史表現與賽後結果。</p>
            <button type="button" class="btn pro" data-records-upgrade>升級 Pro 查看完整紀錄</button>
          </div>
        </div>`;
        container.querySelector("[data-records-upgrade]")?.addEventListener("click",focusMembershipPlans);
        return;
      }
      const admin=isAdminMember();
      summary.hidden=false;
      summary.classList.toggle("member-view",!admin);
      visuals.hidden=false;
      if(toolbar)toolbar.hidden=false;
      if(performanceLayout){
        performanceLayout.hidden=!admin;
        performanceLayout.setAttribute("aria-hidden",admin?"false":"true");
      }
      const stats=marketRecordStats(rows);
      count.textContent=`${rows.length} 筆`;
      const summaryCards=[
        proSummaryCard("Pro 推薦總數",stats.total),
        proSummaryCard("Pro 推薦已結算",stats.settled),
        proSummaryCard("Pro 推薦命中",stats.won,"green"),
        proSummaryCard("Pro 推薦命中率",stats.rate==null?"—":`${stats.rate}%`,"green")
      ];
      summary.innerHTML=summaryCards.join("");
      renderProMarketVisuals(rows);
      if(admin)renderProPerformance(rows);
      else{
        const leagueTarget=document.getElementById("proLeaguePerformance");
        const chartTarget=document.getElementById("proProfitChart");
        if(leagueTarget)leagueTarget.innerHTML="";
        if(chartTarget)chartTarget.innerHTML="";
      }
      const filtered=rows.filter(row=>state.marketRecordFilter==="all"||row.filterKey===state.marketRecordFilter);
      container.innerHTML=filtered.length?filtered.map(row=>`<div class="pro-record-row">
        <div class="pro-record-date">${recordDate(row.date)}<br>${escapeHtml(row.league)}</div>
        <div class="pro-record-market">${escapeHtml(row.name)}</div>
        <div class="pro-record-pick"><b>${escapeHtml(row.pickLabel)}</b><small>${escapeHtml(row.matchup)}${row.probability!=null?` · 模型 ${Number(row.probability).toFixed(1)}%`:""}${row.price!=null?` · 賠率 ${row.price>0?"+":""}${row.price}`:""}</small></div>
        <div class="pro-record-score">${escapeHtml(row.score)}</div>
        <span class="result ${resultClass(row.status)}">${resultLabel(row.status)}</span>
      </div>`).join(""):`<div class="empty"><b>${state.recordsLoading?"Pro 推薦紀錄載入中":rows.length?"此分類尚無紀錄":"尚無 Pro 正式推薦紀錄"}</b>${state.recordsLoading?"正在讀取正式推薦與賽後結果。":rows.length?"可切換其他玩法查看。":"正式發布後，每一筆推薦都會獨立留存與結算。"}</div>`;
    }
    function setRecordsApiStatus(text,isError=false){
      ["homeRecordsApiStatus","recordsApiStatus"].forEach(id=>{
        const element=document.getElementById(id);
        if(!element)return;
        element.textContent=text;
        element.classList.toggle("demo-pill",isError);
      });
    }
    function renderRecords(){
      const rows=state.records;
      const stats=state.recordStats||{total:0,settled:0,won:0,lost:0,push:0,void:0,pending:0,hit_rate:null};
      const hasRate=stats.hit_rate!=null;
      const rate=hasRate?Number(stats.hit_rate):0;
      document.getElementById("statTotal").textContent=stats.total||0;
      document.getElementById("statSettled").textContent=stats.settled||0;
      document.getElementById("statWins").textContent=stats.won||0;
      document.getElementById("statRate").textContent=hasRate?`${rate}%`:"—";
      document.getElementById("homeHitRate").textContent=hasRate?`${rate}%`:"—";
      document.getElementById("homeRateBar").style.width=`${Math.max(0,Math.min(100,rate))}%`;
      document.getElementById("homeRecordCount").textContent=stats.settled?`${stats.won||0} 命中 / ${stats.settled} 場已結算`:"尚無已結算免費精選紀錄";

      const homeList=document.getElementById("homePickList");
      homeList.innerHTML=rows.length?rows.slice(0,4).map(row=>`
        <div class="pick-row">
          <div class="pick-main"><b>⚾ ${escapeHtml(localizeMatchup(row.matchup))} · ${escapeHtml(localizePickLabel(row.pick_label))}</b><small>${recordDate(row.recommendation_date)} · MLB · ${recordScore(row)}</small></div>
          <span class="result ${resultClass(row.status)}">${resultLabel(row.status)}</span>
        </div>`).join(""):`<div class="empty"><b>${state.recordsLoading?"免費精選紀錄載入中":"尚無免費精選紀錄"}</b>${state.recordsLoading?"正在連接 DiamondMind 紀錄資料庫。":"每日免費精選正式發布後會自動保留在這裡。"}</div>`;

      const filtered=rows.filter(x=>state.recordFilter==="all"||x.status===state.recordFilter);
      document.getElementById("recordsList").innerHTML=filtered.length?filtered.map(row=>`
        <div class="record-row">
          <div class="record-date">${recordDate(row.recommendation_date)}<br>MLB</div>
          <div class="record-pick"><b>${escapeHtml(localizeMatchup(row.matchup))}</b><small>${escapeHtml(localizePickLabel(row.pick_label))} · 信心 ${Number(row.confidence||0).toFixed(1)}%</small></div>
          <div class="record-score">${recordScore(row)}</div>
          <span class="result ${resultClass(row.status)}">${resultLabel(row.status)}</span>
        </div>`).join(""):`<div class="empty"><b>${state.recordsError?"紀錄服務暫時無法連線":state.recordsLoading?"免費精選紀錄載入中":rows.length?"沒有符合條件的紀錄":"尚無免費精選紀錄"}</b>${state.recordsError?"請稍後重新進入紀錄頁。":state.recordsLoading?"正在讀取 Supabase 真實資料。":"尚未發布的日期不會建立空白或展示紀錄。"}</div>`;
      renderMarketRecords();
    }

    async function loadRecords(force=false){
      if(state.recordsLoading||(!force&&state.recordsLoaded))return;
      state.recordsLoading=true;
      state.recordsError="";
      setRecordsApiStatus("真實資料連線中");
      renderRecords();
      try{
        const headers={};
        if(authState.session?.access_token)headers.Authorization=`Bearer ${authState.session.access_token}`;
        const payload=await fetchJsonWithTimeout(`${API_BASE}/records`,12000,{headers});
        if(payload.is_demo||payload.database!=="connected")throw new Error("Records database unavailable");
        state.records=Array.isArray(payload.items)?payload.items:[];
        state.marketRecords=isProMember()&&Array.isArray(payload.market_packages)
          ?payload.market_packages.filter(bundle=>{
            const date=String(bundle?.date||"");
            const mode=String(bundle?.publication?.mode||"");
            return (!date||date<=taiwanToday())&&mode!=="ai_auto";
          })
          :[];
        state.proPerformance=isAdminMember()&&payload.pro_performance?payload.pro_performance:null;
        state.recordStats=payload.stats||null;
        state.recordsAccessRole=authState.role;
        state.recordsLoaded=true;
        setRecordsApiStatus("真實紀錄已連線");
      }catch(error){
        state.records=[];
        state.marketRecords=[];
        state.proPerformance=null;
        state.recordStats=null;
        state.recordsLoaded=false;
        state.recordsAccessRole=authState.role;
        state.recordsError="紀錄 API 暫時無法連線";
        setRecordsApiStatus("紀錄 API 暫時離線",true);
      }finally{
        state.recordsLoading=false;
        renderRecords();
      }
    }

    document.querySelectorAll("[data-record-filter]").forEach(btn=>btn.addEventListener("click",()=>{
      state.recordFilter=btn.dataset.recordFilter;
      document.querySelectorAll("[data-record-filter]").forEach(x=>x.classList.toggle("active",x===btn));
      renderRecords();
    }));

    document.querySelectorAll("[data-market-record-filter]").forEach(btn=>btn.addEventListener("click",()=>{
      state.marketRecordFilter=btn.dataset.marketRecordFilter;
      document.querySelectorAll("[data-market-record-filter]").forEach(x=>x.classList.toggle("active",x===btn));
      renderMarketRecords();
    }));

    function shiftDate(dateStr,days){
      const [y,m,d]=dateStr.split("-").map(Number);
      const dt=new Date(Date.UTC(y,m-1,d));
      dt.setUTCDate(dt.getUTCDate()+days);
      return dt.toISOString().slice(0,10);
    }
    function gameTaiwanDate(dateString){
      const parts=new Intl.DateTimeFormat("en-CA",{timeZone:"Asia/Taipei",year:"numeric",month:"2-digit",day:"2-digit"}).formatToParts(new Date(dateString));
      const obj=Object.fromEntries(parts.map(p=>[p.type,p.value]));
      return `${obj.year}-${obj.month}-${obj.day}`;
    }
    function gameTime(dateString){
      return new Intl.DateTimeFormat("zh-TW",{timeZone:"Asia/Taipei",hour:"2-digit",minute:"2-digit",hour12:false}).format(new Date(dateString));
    }
    function gameStatus(game){
      const abstract=(game.status?.abstractGameState||"").toLowerCase();
      if(abstract==="live")return "live";
      if(abstract==="final")return "final";
      return "upcoming";
    }
    function statusText(game){
      if(game.status==="live"){
        const inning=game.inning?`${game.inningState||""}${game.inning}局`:"進行中";
        return inning;
      }
      if(game.status==="final")return "已結束";
      if(game.status==="postponed")return "延賽／取消";
      return "未開賽";
    }
    function normalizeGame(game){
      const awayTeam=game.teams?.away?.team||{};
      const homeTeam=game.teams?.home?.team||{};
      const awayId=Number(awayTeam.id)||null;
      const homeId=Number(homeTeam.id)||null;
      const away=allStarTeamById[awayId]?.name||awayTeam.name||"Away";
      const home=allStarTeamById[homeId]?.name||homeTeam.name||"Home";
      return {
        id:Number(game.gamePk),gameDate:game.gameDate,time:gameTime(game.gameDate),status:gameStatus(game),
        detailedState:game.status?.detailedState||"",
        inning:game.linescore?.currentInning||null,inningState:game.linescore?.inningState||"",
        away,home,awayZh:displayTeamName(away,awayId),homeZh:displayTeamName(home,homeId),
        awayAbbr:resolvedTeamAbbr(away,awayTeam.abbreviation,awayId,"AWY"),
        homeAbbr:resolvedTeamAbbr(home,homeTeam.abbreviation,homeId,"HME"),
        awayScore:game.teams?.away?.score,homeScore:game.teams?.home?.score,
        awayPitcher:game.teams?.away?.probablePitcher?.fullName||"尚未公布",
        homePitcher:game.teams?.home?.probablePitcher?.fullName||"尚未公布",
        venue:game.venue?.name||"",eventLabel:game.gameType==="A"?"明星賽":""
      };
    }

    function normalizeBackendGame(game){
      const awayId=Number(game.away?.id)||null;
      const homeId=Number(game.home?.id)||null;
      const away=allStarTeamById[awayId]?.name||game.away?.name||"Away";
      const home=allStarTeamById[homeId]?.name||game.home?.name||"Home";
      return {
        id:Number(game.game_pk),gameDate:game.game_date,time:game.time_taiwan||gameTime(game.game_date),status:game.status||"upcoming",
        detailedState:game.detailed_status||"",inning:game.inning||null,inningState:game.inning_state||"",
        away,home,awayZh:displayTeamName(away,awayId),homeZh:displayTeamName(home,homeId),
        awayAbbr:resolvedTeamAbbr(away,game.away?.abbr,awayId,"AWY"),homeAbbr:resolvedTeamAbbr(home,game.home?.abbr,homeId,"HME"),
        awayScore:game.away?.score,homeScore:game.home?.score,
        awayPitcher:game.away?.probable_pitcher?.name||"尚未公布",homePitcher:game.home?.probable_pitcher?.name||"尚未公布",
        venue:game.venue||"",eventLabel:game.event_label||""
      };
    }

    function normalizeLeagueGame(game,league){
      if(league==="MLB")return normalizeBackendGame(game);
      const away=game.away?.name||"Away";
      const home=game.home?.name||"Home";
      return {
        id:String(game.game_pk||game.external_game_id||`${league}-${away}-${home}`),league,gameDate:game.game_date||"",
        time:game.time_taiwan||(game.status==="final"?"已完賽":"時間待定"),status:game.status||"upcoming",
        detailedState:game.detailed_status||"",inning:game.inning||null,inningState:game.inning_state||"",
        away,home,awayZh:game.away?.name_zh||npbTeamZh[away]||away,homeZh:game.home?.name_zh||npbTeamZh[home]||home,
        awayAbbr:game.away?.abbr||"AWY",homeAbbr:game.home?.abbr||"HME",
        awayScore:game.away?.score,homeScore:game.home?.score,
        awayPitcher:game.away?.probable_pitcher?.name||"尚未公布",homePitcher:game.home?.probable_pitcher?.name||"尚未公布",
        awayPitcherAnnounced:game.away?.probable_pitcher?.announced===true,homePitcherAnnounced:game.home?.probable_pitcher?.announced===true,
        awayRecord:game.away?.record||null,homeRecord:game.home?.record||null,
        venue:game.venue||"",eventLabel:game.event_label||`${league} 例行賽`,analysisAvailable:game.analysis_available===true,
        sourceUrl:game.source_url||game.official_schedule_url||""
      };
    }

    function updateLeagueUi(){
      const ui=leagueUi[state.activeLeague]||leagueUi.MLB;
      document.getElementById("gamesKicker").textContent=ui.kicker;
      document.getElementById("gamesDescription").textContent=ui.description;
      document.getElementById("gamesConnectionLabel").textContent=ui.connection;
      document.querySelectorAll("[data-league]").forEach(button=>button.classList.toggle("active",button.dataset.league===state.activeLeague));
    }

    async function fetchJsonWithTimeout(url,timeout=6500,options={}){
      const controller=new AbortController();
      const timer=setTimeout(()=>controller.abort(),timeout);
      try{
        const response=await fetch(url,{...options,headers:{...(options.headers||{})},cache:"no-store",signal:controller.signal});
        if(!response.ok){
          const error=new Error(`HTTP ${response.status}`);
          error.status=response.status;
          throw error;
        }
        return await response.json();
      }finally{
        clearTimeout(timer);
      }
    }

    async function loadMlbDirect(date){
      const dates=[shiftDate(date,-1),date,shiftDate(date,1)];
      const responses=await Promise.all(dates.map(d=>fetch(`https://statsapi.mlb.com/api/v1/schedule?sportId=1&date=${encodeURIComponent(d)}&hydrate=probablePitcher,linescore,venue`,{cache:"no-store"})));
      if(responses.some(res=>!res.ok))throw new Error("MLB API response error");
      const payloads=await Promise.all(responses.map(res=>res.json()));
      const raw=payloads.flatMap(payload=>(payload.dates||[]).flatMap(day=>day.games||[]));
      const unique=[...new Map(raw.map(game=>[game.gamePk,game])).values()];
      return unique.filter(game=>gameTaiwanDate(game.gameDate)===date).sort((a,b)=>new Date(a.gameDate)-new Date(b.gameDate)).map(normalizeGame);
    }

    async function loadMlbGames(date,statusEl,list){
      try{
        const payload=await fetchJsonWithTimeout(`${API_BASE}/games?league=MLB&date=${encodeURIComponent(date)}`);
        state.games=(payload.items||[]).map(game=>normalizeLeagueGame(game,"MLB"));
        const cacheLabel=payload.meta?.cache==="stale"?"舊資料備援":"後端資料";
        statusEl.textContent=`已載入 ${state.games.length} 場 · ${cacheLabel} · 台灣日期 ${date}`;
      }catch(backendError){
        state.games=await loadMlbDirect(date);
        statusEl.textContent=`已載入 ${state.games.length} 場 · MLB 直連備援 · 台灣日期 ${date}`;
      }
    }

    async function loadNpbGames(date,statusEl){
      const payload=await fetchJsonWithTimeout(`${API_BASE}/games?league=NPB&date=${encodeURIComponent(date)}`,20000);
      state.games=(payload.items||[]).map(game=>normalizeLeagueGame(game,"NPB"));
      const cacheLabel=payload.meta?.cache==="stale"?"舊資料備援":"NPB 官方資料";
      statusEl.textContent=`已載入 ${state.games.length} 場 · ${cacheLabel} · 台灣日期 ${date} · AI BETA`;
    }

    async function loadLeagueGames(){
      const date=document.getElementById("scheduleDate").value||taiwanToday();
      const statusEl=document.getElementById("liveDataStatus");
      const list=document.getElementById("gamesList");
      updateLeagueUi();
      statusEl.textContent=`正在載入 ${date} 的 ${state.activeLeague} 賽事…`;
      list.innerHTML=`<div class="card empty"><b>資料同步中</b>正在依台灣日期整理 ${state.activeLeague} 完整賽程。</div>`;
      try{
        if(state.activeLeague==="NPB")await loadNpbGames(date,statusEl);
        else await loadMlbGames(date,statusEl,list);
        state.gamesLoaded=true;
        renderGames();
      }catch(error){
        state.games=[];
        state.gamesLoaded=false;
        statusEl.textContent=`${state.activeLeague} 賽程目前無法連線`;
        list.innerHTML=`<div class="card empty"><b>賽程連線失敗</b>${state.activeLeague==="NPB"?"NPB 官方來源可能暫時維護中，請稍後按重新整理。":"請確認網路後按重新整理。"}</div>`;
      }
    }

    function formatNpbRecord(record){
      if(!record)return "戰績待同步";
      const pct=record.pct_display||Number(record.pct||0).toFixed(3).replace(/^0/,"");
      return `${record.wins}-${record.losses}-${record.ties} · 勝率 ${pct} · ${record.league==="Central League"?"央聯":"洋聯"}第${record.rank}`;
    }

    function npbGameMeta(game){
      const awayPitcher=game.awayPitcherAnnounced?escapeHtml(game.awayPitcher):"尚未公布";
      const homePitcher=game.homePitcherAnnounced?escapeHtml(game.homePitcher):"尚未公布";
      return `例行賽 · 客：${awayPitcher}<br>主：${homePitcher}`;
    }

    function renderGames(){
      const filtered=state.games.filter(game=>state.gameFilter==="all"||game.status===state.gameFilter);
      const list=document.getElementById("gamesList");
      if(!filtered.length){
        list.innerHTML=`<div class="card empty"><b>目前沒有符合條件的賽事</b>可以切換日期或選擇「全部」。</div>`;
        return;
      }
      list.innerHTML=filtered.map(game=>`
        <article class="game-card" data-game-id="${escapeHtml(String(game.id))}" data-game-league="${escapeHtml(game.league||state.activeLeague)}" tabindex="0" role="button" aria-label="查看 ${game.awayZh} 對 ${game.homeZh}">
          <div class="game-time"><b>${game.time}</b><small>${game.venue||game.league||state.activeLeague}</small></div>
          <div class="game-teams">
            <div class="team-line"><span class="abbr">${game.awayAbbr}</span><span>${game.awayZh}</span><span class="score">${game.awayScore??""}</span></div>
            <div class="team-line"><span class="abbr">${game.homeAbbr}</span><span>${game.homeZh}</span><span class="score">${game.homeScore??""}</span></div>
          </div>
          <div class="pitchers">${(game.league||state.activeLeague)==="NPB"?npbGameMeta(game):`${game.eventLabel?`${escapeHtml(game.eventLabel)} · `:""}客：${escapeHtml(game.awayPitcher)}<br>主：${escapeHtml(game.homePitcher)}`}</div>
          <span class="status-label ${game.status}">${statusText(game)}</span>
          <span class="chevron">›</span>
        </article>`).join("");
      document.querySelectorAll("[data-game-id]").forEach(card=>{
        const open=()=>openGame(card.dataset.gameId);
        card.addEventListener("click",open);
        card.addEventListener("keydown",e=>{if(e.key==="Enter"||e.key===" "){e.preventDefault();open()}});
      });
    }

    function renderGameAnalysisGate(access={}){
      const guest=String(access.role||"guest").toLowerCase()==="guest";
      const accountCopy=guest?"登入免費會員後可選擇月繳、季繳或年繳方案。":"你目前是免費會員，可直接選擇 Pro 方案解鎖。";
      return `<div class="game-analysis-gate">
        <div class="game-analysis-gate-icon" aria-hidden="true">🔒</div>
        <h3>五大完整分析引擎</h3>
        <p>完整數據比較為 DiamondMind Pro 會員專屬內容。</p>
        <div class="locked-engine-list" aria-label="Pro 專屬分析模組">
          <div class="locked-engine-item"><span class="locked-engine-lock">🔒</span><span>先發投手分析</span></div>
          <div class="locked-engine-item"><span class="locked-engine-lock">🔒</span><span>打線強度分析</span></div>
          <div class="locked-engine-item"><span class="locked-engine-lock">🔒</span><span>牛棚狀態分析</span></div>
          <div class="locked-engine-item"><span class="locked-engine-lock">🔒</span><span>環境條件分析</span></div>
          <div class="locked-engine-item"><span class="locked-engine-lock">🔒</span><span>Statcast 進階數據</span></div>
        </div>
        <button type="button" class="btn pro" data-game-upgrade-pro>升級 Pro 解鎖完整賽事情報</button>
        <p class="game-analysis-gate-note">${escapeHtml(accountCopy)}</p>
      </div>`;
    }

    document.addEventListener("click",event=>{
      const button=event.target.closest("[data-game-upgrade-pro]");
      if(!button)return;
      focusMembershipPlans();
    });

    function renderNpbAnalysisGate(access={}){
      const guest=String(access.role||"guest").toLowerCase()==="guest";
      const accountCopy=guest?"登入免費會員後可選擇月繳、季繳或年繳方案。":"你目前是免費會員，可直接選擇 Pro 方案解鎖。";
      return `<div class="game-analysis-gate">
        <div class="game-analysis-gate-icon" aria-hidden="true">🔒</div>
        <h3>NPB 完整分析引擎</h3>
        <p>正式打線、先發近況、牛棚用量與賽前環境為 DiamondMind Pro 會員專屬內容。</p>
        <div class="locked-engine-list" aria-label="NPB Pro 專屬分析模組">
          <div class="locked-engine-item"><span class="locked-engine-lock">🔒</span><span>正式第 1～9 棒</span></div>
          <div class="locked-engine-item"><span class="locked-engine-lock">🔒</span><span>先發最近三場</span></div>
          <div class="locked-engine-item"><span class="locked-engine-lock">🔒</span><span>牛棚近三日用量</span></div>
          <div class="locked-engine-item"><span class="locked-engine-lock">🔒</span><span>一軍登錄與抹消</span></div>
          <div class="locked-engine-item"><span class="locked-engine-lock">🔒</span><span>球場、屋頂與天氣</span></div>
          <div class="locked-engine-item"><span class="locked-engine-lock">🔒</span><span>FIP／K%／BB%／ISO</span></div>
        </div>
        <button type="button" class="btn pro" data-game-upgrade-pro>升級 Pro 解鎖完整賽事情報</button>
        <p class="game-analysis-gate-note">${escapeHtml(accountCopy)}</p>
      </div>`;
    }

    function formatNpbMetricValue(label,value){
      if(value===null||value===undefined||value==="")return "—";
      const number=Number(value);
      if(!Number.isFinite(number))return escapeHtml(String(value));
      const text=String(label||"");
      if(text.includes("%")){
        const percentage=Math.abs(number)<=1?number*100:number;
        return `${percentage.toFixed(1)}%`;
      }
      if(text.includes("勝率")||text.includes("畢氏"))return number.toFixed(3).replace(/^0/,"");
      if(["OPS","ISO","WHIP","K/BB"].some(key=>text.includes(key)))return number.toFixed(3).replace(/^0(?=\.)/,"").replace(/0+$/,"").replace(/\.$/,"");
      if(text.includes("ERA")||text.includes("FIP")||text.includes("場均")||text.includes("局數"))return number.toFixed(2);
      if(text.includes("溫度"))return `${number.toFixed(1)}°`;
      return Number.isInteger(number)?String(number):number.toFixed(1);
    }

    function renderNpbMetricRows(metrics=[]){
      const rows=(metrics||[]).map(metric=>{
        const away=formatNpbMetricValue(metric.label,metric.away);
        const home=formatNpbMetricValue(metric.label,metric.home);
        const awayNumber=Number(metric.away);
        const homeNumber=Number(metric.home);
        const label=String(metric.label||"");
        const lowerBetter=["ERA","WHIP","失分","疲勞","抹消","近3日後援局數","近3日面對打者","打線 K%","先發 BB%"].some(key=>label.includes(key));
        let awayClass="";
        let homeClass="";
        if(metric.available!==false&&Number.isFinite(awayNumber)&&Number.isFinite(homeNumber)&&awayNumber!==homeNumber){
          const awayBetter=lowerBetter?awayNumber<homeNumber:awayNumber>homeNumber;
          awayClass=awayBetter?"better":"";
          homeClass=!awayBetter?"better":"";
        }
        return `<div class="engine-metric"><span>${escapeHtml(metric.label||"指標")}</span><span class="${awayClass}">${away}</span><span class="${homeClass}">${home}</span></div>`;
      }).join("");
      return rows||`<div class="engine-unavailable">此模組目前資料不足，權重已自動降低。</div>`;
    }

    function npbGroupCard(group={},fallback="",extraHtml=""){
      const quality=Math.round(Number(group.quality||0)*100);
      const rows=renderNpbMetricRows(group.metrics||[]);
      return `<section class="engine-module">
        <div class="engine-module-top"><b>${escapeHtml(group.label||fallback)}</b><span class="engine-quality ${quality<60?"low":""}">完整度 ${quality}%</span></div>
        <p class="engine-note">${escapeHtml(group.note||"依可取得資料動態評分")}</p>
        <div class="engine-metrics">
          <div class="engine-metric"><span>比較指標</span><span>客隊</span><span>主隊</span></div>
          ${rows}
        </div>
        ${extraHtml}
      </section>`;
    }

    function npbLineupPanel(lineup={},sideLabel="球隊"){
      const order=(lineup.batting_order||[]).slice(0,9);
      const status=lineup.official&&order.length===9?"正式打線":"尚未完整公布";
      const rows=order.length?order.map((player,index)=>`<li><span>${Number(player.batting_order||index+1)}</span><b>${escapeHtml(player.name||"—")}</b><small>${escapeHtml(player.position||"")}</small></li>`).join(""):`<li class="empty-row">賽前官方打線尚未公布</li>`;
      return `<div class="npb-detail-panel">
        <div class="npb-detail-title"><b>${escapeHtml(sideLabel)}</b><span class="${lineup.official?"ready":"waiting"}">${status}</span></div>
        <ol class="npb-lineup-list">${rows}</ol>
      </div>`;
    }

    function npbStarterPanel(pitcher={},sideLabel="球隊"){
      const recent=pitcher.recent_3||{};
      const logs=(recent.game_logs||[]).slice(0,3);
      const summary=recent.available?`${recent.starts||logs.length} 場 · ${formatNpbMetricValue("ERA",recent.era)} ERA · ${formatNpbMetricValue("WHIP",recent.whip)} WHIP`:`最近三次先發資料尚不足`;
      const items=logs.length?logs.map(log=>`<li><span>${escapeHtml(log.date||"")}</span><b>${formatNpbMetricValue("局數",log.innings)} IP</b><small>${Number(log.earned_runs||0)} ER · ${Number(log.strikeouts||0)} K</small></li>`).join(""):`<li class="empty-row">尚無可配對的近期先發紀錄</li>`;
      return `<div class="npb-detail-panel">
        <div class="npb-detail-title"><b>${escapeHtml(sideLabel)}｜${escapeHtml(pitcher.name||"先發未公布")}</b></div>
        <p class="npb-detail-summary">${escapeHtml(summary)}</p>
        <ul class="npb-mini-list">${items}</ul>
      </div>`;
    }

    function npbBullpenPanel(data={},sideLabel="球隊"){
      const recent=data.recent_3_days||{};
      const heavy=(recent.heavy_usage||[]).slice(0,4);
      const rows=heavy.length?heavy.map(player=>`<li><b>${escapeHtml(player.name||"—")}</b><span>${Number(player.appearances||0)} 場 · ${formatNpbMetricValue("局數",player.innings)} IP${player.back_to_back?" · 連投":""}</span></li>`).join(""):`<li class="empty-row">近三日沒有重度使用名單</li>`;
      return `<div class="npb-detail-panel">
        <div class="npb-detail-title"><b>${escapeHtml(sideLabel)}</b><span class="fatigue-${recent.fatigue_level==="高"?"high":recent.fatigue_level==="中"?"mid":"low"}">疲勞 ${escapeHtml(recent.fatigue_level||"—")}</span></div>
        <p class="npb-detail-summary">${Number(recent.appearances||0)} 次後援 · ${formatNpbMetricValue("局數",recent.innings)} IP · ${Number(recent.back_to_back_pitchers||0)} 人連投</p>
        <ul class="npb-compact-list">${rows}</ul>
      </div>`;
    }

    function npbRosterPanel(data={},sideLabel="球隊"){
      const registered=(data.registered||[]).slice(0,6);
      const deregistered=(data.deregistered||[]).slice(0,6);
      const rows=[
        ...registered.map(player=>`<li><span class="roster-in">登錄</span><b>${escapeHtml(player.name||"—")}</b><small>${escapeHtml(player.position||"")} · ${escapeHtml(player.date||"")}</small></li>`),
        ...deregistered.map(player=>`<li><span class="roster-out">抹消</span><b>${escapeHtml(player.name||"—")}</b><small>${escapeHtml(player.position||"")} · ${escapeHtml(player.date||"")}</small></li>`)
      ].join("")||`<li class="empty-row">近七日無相關一軍異動</li>`;
      return `<div class="npb-detail-panel">
        <div class="npb-detail-title"><b>${escapeHtml(sideLabel)}</b><span>${registered.length} 入／${deregistered.length} 出</span></div>
        <ul class="npb-roster-list">${rows}</ul>
      </div>`;
    }

    function renderNpbEnvironment(group={}){
      const venue=group.venue||{};
      const weather=group.weather||{};
      const run=group.run_environment||{};
      const roofMap={fixed_dome:"固定巨蛋",retractable:"可開閉屋頂",open_air:"戶外球場",unknown:"屋頂狀態待確認"};
      const weatherText=weather.available?`${weather.condition||"天氣"} · ${formatNpbMetricValue("溫度",weather.temperature_c)}C · 風 ${formatNpbMetricValue("風速",weather.wind_speed_mph)} mph ${weather.wind_direction_text||""}`:"天氣資料暫時不可用";
      const reasons=(run.reasons||[]).map(reason=>`<span>${escapeHtml(reason)}</span>`).join("")||`<span>中性環境基準</span>`;
      return `<div class="engine-extra npb-environment-extra">
        <div><b>球場</b><p>${escapeHtml(venue.name||venue.official_name_raw||"尚未確認")} · ${escapeHtml(roofMap[venue.roof_type]||venue.roof_type||"屋頂待確認")} · ${escapeHtml(venue.surface||"")}</p></div>
        <div><b>比賽時段</b><p>${escapeHtml(weatherText)}</p></div>
        <div class="npb-env-tags">${reasons}</div>
        <div><b>預估總分環境修正</b><p>${Number(run.run_adjustment||0)>=0?"+":""}${Number(run.run_adjustment||0).toFixed(2)} 分${run.weather_applied?"（已計入戶外天氣）":"（未套用戶外天氣）"}</p></div>
      </div>`;
    }

    function renderNpbModelBasis(payload){
      const analysis=payload.analysis||{};
      const basis=analysis.data_basis||{};
      const quality=Math.round(Number(basis.data_quality??analysis.data_quality??0)*100);
      const ready=basis.recommendation_ready===true;
      const tags=(basis.used_modules||[]).map(value=>`<span>${escapeHtml(value)}</span>`).join("");
      const missing=(basis.missing_core||[]);
      const missingText=missing.length?`目前缺少：${missing.join("、")}`:"核心資料已達正式分析標準";
      return `<section class="npb-basis-card">
        <div class="npb-basis-head"><div><h4>本場 AI 實際分析依據</h4><p>顯示模型本次真正採用的資料；未取得的欄位不會假裝已納入。</p></div><span class="npb-basis-score ${ready?"":"blocked"}">完整度 ${quality}%</span></div>
        <div class="npb-basis-tags">${tags||"<span>資料同步中</span>"}</div>
        <p class="npb-basis-missing">${escapeHtml(missingText)}${ready?" · 可列入正式推薦":" · 僅供分析，不自動發布新推薦"}</p>
      </section>`;
    }

    function renderNpbAnalysis(payload){
      const analysis=payload.analysis||{};
      const groups=analysis.analysis_groups||{};
      const starter=groups.starter||{};
      const offense=groups.offense||{};
      const bullpen=groups.bullpen||{};
      const availability=groups.availability||{};
      const environment=groups.environment||{};
      const advanced=groups.advanced||{};
      const team=groups.team||{};

      const starterExtra=`<div class="npb-detail-grid">${npbStarterPanel(starter.away_pitcher||{},"客隊")}${npbStarterPanel(starter.home_pitcher||{},"主隊")}</div>`;
      const lineupExtra=`<div class="npb-detail-grid">${npbLineupPanel(offense.away_lineup||{},"客隊第 1～9 棒")}${npbLineupPanel(offense.home_lineup||{},"主隊第 1～9 棒")}</div>`;
      const bullpenExtra=`<div class="npb-detail-grid">${npbBullpenPanel(bullpen.away||{},"客隊牛棚")}${npbBullpenPanel(bullpen.home||{},"主隊牛棚")}</div>`;
      const rosterExtra=`<div class="npb-detail-grid">${npbRosterPanel(availability.away||{},"客隊近七日")}${npbRosterPanel(availability.home||{},"主隊近七日")}</div><p class="npb-source-note">官方公示未提供統一傷病診斷；抹消代表目前不在一軍可用名單，系統不猜測傷勢。</p>`;

      const cards=[
        npbGroupCard(starter,"先發最近三場",starterExtra),
        npbGroupCard(offense,"正式先發打線",lineupExtra),
        npbGroupCard(bullpen,"牛棚近三日用量",bullpenExtra),
        npbGroupCard(availability,"登錄異動與缺陣",rosterExtra),
        npbGroupCard(environment,"球場與天氣",renderNpbEnvironment(environment)),
        npbGroupCard(advanced,"NPB 進階數據"),
        npbGroupCard(team,"球隊實力與近況")
      ].join("");

      return `${renderNpbModelBasis(payload)}<div class="engine-breakdown-head">
          <h3>NPB 完整分析引擎</h3>
          <span>正式打線 · 先發近三場 · 牛棚近三日 · 登錄異動 · 環境 · 進階數據</span>
        </div>
        <div class="engine-module-grid npb-complete-grid">${cards}</div>`;
    }

    async function loadNpbGameDetail(id){
      const aiStatus=document.getElementById("detailAiStatus");
      const headers={Accept:"application/json"};
      if(authState.session?.access_token)headers.Authorization=`Bearer ${authState.session.access_token}`;
      try{
        const payload=await fetchJsonWithTimeout(`${API_BASE}/npb/games/${encodeURIComponent(id)}`,60000,{headers});
        if(payload.analysis_locked||payload.access?.has_pro_access!==true){
          aiStatus.textContent="Pro 會員專屬";
          document.getElementById("detailEngineBreakdown").innerHTML=renderNpbAnalysisGate(payload.access||{role:isSignedIn()?"free":"guest"});
          return;
        }
        const detailGame=payload.game||{};
        const awayPitcher=detailGame.away?.probable_pitcher?.name;
        const homePitcher=detailGame.home?.probable_pitcher?.name;
        if(awayPitcher)document.getElementById("detailAwayPitcher").textContent=awayPitcher;
        if(homePitcher)document.getElementById("detailHomePitcher").textContent=homePitcher;
        const analysis=payload.analysis||{};
        const quality=Math.round(Number(analysis.data_quality||0)*100);
        const ready=analysis.official_recommendation_enabled===true;
        aiStatus.textContent=`NPB 完整引擎完成 · 資料完整度 ${quality}%${ready?" · 正式分析可用":" · 資料不足僅供分析"}`;
        document.getElementById("detailEngineBreakdown").innerHTML=renderNpbAnalysis(payload);
      }catch(error){
        if(error.status===401){
          aiStatus.textContent="登入已過期";
          document.getElementById("detailEngineBreakdown").innerHTML=renderNpbAnalysisGate({role:"guest"});
          return;
        }
        aiStatus.textContent="NPB AI 資料暫時無法載入";
        document.getElementById("detailEngineBreakdown").innerHTML=`<div class="engine-unavailable">官方球員數據或歷史賽果目前暫時無法同步，請稍後重新開啟。</div>`;
      }
    }

    function openGame(id){
      const game=state.games.find(x=>String(x.id)===String(id));
      if(!game)return;
      state.upgradeReturnGame=id;
      document.getElementById("gameModalTitle").textContent=`${game.awayAbbr} @ ${game.homeAbbr}`;
      document.getElementById("gameModalMeta").textContent=`${document.getElementById("scheduleDate").value} · ${game.time} · ${game.venue||game.league||state.activeLeague}`;
      document.getElementById("detailAwayAbbr").textContent=game.awayAbbr;
      document.getElementById("detailAwayName").textContent=game.awayZh;
      document.getElementById("detailHomeAbbr").textContent=game.homeAbbr;
      document.getElementById("detailHomeName").textContent=game.homeZh;
      document.getElementById("detailScore").textContent=game.status==="upcoming"?"VS":`${game.awayScore??0} : ${game.homeScore??0}`;
      document.getElementById("detailAwayPitcher").textContent=game.awayPitcher;
      document.getElementById("detailHomePitcher").textContent=game.homePitcher;
      document.getElementById("detailStatus").textContent=statusText(game);
      if((game.league||state.activeLeague)==="NPB"){
        document.getElementById("detailAiStatus").textContent=isProMember()?"正在載入 NPB AI 分析…":"Pro 會員專屬";
        const sourceLink=game.sourceUrl?`<div style="margin-top:12px"><a class="btn ghost small" href="${escapeHtml(game.sourceUrl)}" target="_blank" rel="noopener">查看 NPB 官方資料</a></div>`:"";
        document.getElementById("detailEngineBreakdown").innerHTML=isProMember()
          ?`<div class="engine-unavailable">正在整合球季戰績、最近十場、預告先發、打線與牛棚數據…</div>${sourceLink}`
          :`${renderNpbAnalysisGate({role:isSignedIn()?"free":"guest"})}${sourceLink}`;
        openModal("gameModal");
        if(isProMember())loadNpbGameDetail(id);
        return;
      }
      document.getElementById("detailAiStatus").textContent=isProMember()?"正在載入五大引擎…":"Pro 會員專屬";
      document.getElementById("detailEngineBreakdown").innerHTML=isProMember()?`<div class="engine-unavailable">正在整理先發、打線、牛棚、環境與進階數據…</div>`:renderGameAnalysisGate({role:isSignedIn()?"free":"guest"});
      openModal("gameModal");
      loadGameDetail(id);
    }

    async function loadGameDetail(id){
      const aiStatus=document.getElementById("detailAiStatus");
      const headers={Accept:"application/json"};
      if(authState.session?.access_token)headers.Authorization=`Bearer ${authState.session.access_token}`;
      try{
        const payload=await fetchJsonWithTimeout(`${API_BASE}/mlb/games/${id}`,45000,{headers});
        if(payload.analysis_locked||payload.access?.has_pro_access!==true){
          aiStatus.textContent="Pro 會員專屬";
          document.getElementById("detailEngineBreakdown").innerHTML=renderGameAnalysisGate(payload.access||{role:isSignedIn()?"free":"guest"});
          return;
        }
        const analysis=payload.analysis||{};
        const quality=Math.round(Number(analysis.data_quality||0)*100);
        aiStatus.textContent=analysis.pick?.label?`${analysis.pick.label} · 信心 ${analysis.confidence}% · 資料 ${quality}%`:"五大引擎已完成";
        renderEngineBreakdown(analysis.analysis_groups||{},"detailEngineBreakdown",{
          lineups:payload.lineups||analysis.lineups||{},
          bullpen:payload.bullpen||analysis.bullpen||{},
          environment:payload.environment||analysis.environment||{},
          starting_pitchers:payload.starting_pitchers||analysis.starting_pitchers||{}
        });
      }catch(error){
        if(error.status===401){
          aiStatus.textContent="登入已過期";
          document.getElementById("detailEngineBreakdown").innerHTML=renderGameAnalysisGate({role:"guest"});
          return;
        }
        aiStatus.textContent="後端暫時無法連線，顯示基本賽事資料";
        document.getElementById("detailEngineBreakdown").innerHTML=`<div class="engine-unavailable">完整引擎資料目前無法載入，請稍後重新開啟。</div>`;
      }
    }

    document.querySelectorAll("[data-game-filter]").forEach(btn=>btn.addEventListener("click",()=>{
      state.gameFilter=btn.dataset.gameFilter;
      document.querySelectorAll("[data-game-filter]").forEach(x=>x.classList.toggle("active",x===btn));
      renderGames();
    }));
    document.querySelectorAll("[data-league]:not([disabled])").forEach(button=>button.addEventListener("click",()=>{
      const league=button.dataset.league;
      if(!league||league===state.activeLeague)return;
      state.activeLeague=league;
      state.gamesLoaded=false;
      state.gameFilter="all";
      document.querySelectorAll("[data-game-filter]").forEach(filter=>filter.classList.toggle("active",filter.dataset.gameFilter==="all"));
      loadLeagueGames();
    }));
    document.getElementById("refreshGames").addEventListener("click",loadLeagueGames);
    document.getElementById("scheduleDate").addEventListener("change",()=>{
      state.predictionDate="";
      state.predictionRole="";
      loadLeagueGames();
      loadHomeLeagueSummary();
    });

    function formatAmericanOdds(value){
      const price=Number(value);
      if(!Number.isFinite(price))return "—";
      return price>0?`+${price}`:`${price}`;
    }

    function setProBodyMessage(key,message){
      const body=document.querySelector(`[data-pro-body="${key}"]`);
      if(!body)return;
      body.replaceChildren();
      const copy=document.createElement("p");
      copy.textContent=message;
      body.append(copy);
    }

    function renderLockedProPredictions(){
      setProBodyMessage("moneylines","所有已啟用棒球聯盟中，通過正式門檻的獨贏候選都會顯示。");
      setProBodyMessage("run_lines","所有通過正式門檻的讓分候選都會顯示。");
      setProBodyMessage("totals","所有通過正式門檻的大小分候選都會顯示。");
      if(isAdminMember())setProBodyMessage("watchlist","接近正式門檻的候選只供創辦人內部審核，不列入正式戰績。");
      setProBodyMessage("two_leg","最多 2 組，由已通過門檻的不同場次組成。");
      setProBodyMessage("three_leg","最多 1 組高風險組合，不為湊關硬選。");
      const note=document.getElementById("proPredictionNote");
      if(note)note.textContent=isAdminMember()
        ?"會員區只顯示正式發布推薦；觀察候選僅限創辦人內部審核。"
        :"MLB／NPB 玩法均優先使用真實盤口與固定門檻；沒有玩法通過時就不發布，不會為了出單降低標準。";
    }

    function memberVisibleSelectionSummary(value){
      const text=String(value||"").trim();
      if(!text)return "此推薦已正式發布並鎖定。";
      if(isAdminMember())return text;
      const internal=/(創辦人|觀察名單|觀察候選|內部審核|不(?:計入|記錄|列入|計)[^。！？]{0,16}戰績)/;
      const sentences=text.match(/[^。！？]+[。！？]?/g)||[text];
      const cleaned=sentences.filter(sentence=>!internal.test(sentence)).join("").trim();
      return cleaned||"此推薦已正式發布並鎖定。";
    }

    function publishedSelectionResult(results,key,selection,index){
      const group=asSelectionArray(results?.[key]??results?.[key.replace(/s$/,'')]);
      return group.find(item=>item?.candidate_id&&String(item.candidate_id)===String(selection?.candidate_id))||group[index]||{status:"pending"};
    }
    function selectionResultNode(result){
      const wrap=document.createElement("div");
      wrap.className="pro-selection-result";
      const status=String(result?.status||"pending");
      const badge=document.createElement("span");
      badge.className=`result ${resultClass(status)}`;
      badge.textContent=resultLabel(status);
      wrap.append(badge);
      if(result?.away_score!=null&&result?.home_score!=null){
        const score=document.createElement("small");
        score.textContent=`終場 ${result.away_score}–${result.home_score}`;
        wrap.append(score);
      }else if(status!=="pending"&&result?.result_note){
        const note=document.createElement("small");
        note.textContent=String(result.result_note);
        wrap.append(note);
      }
      return wrap;
    }

    function renderMarketList(key,selections,emptyMessage,results={}){
      const body=document.querySelector(`[data-pro-body="${key}"]`);
      if(!body)return;
      body.replaceChildren();
      const items=asSelectionArray(selections);
      if(!items.length){
        const empty=document.createElement("p");
        empty.textContent=emptyMessage;
        body.append(empty);
        return;
      }
      const list=document.createElement("div");
      list.className="pro-selection-list";
      items.forEach((selection,index)=>{
        const item=document.createElement("article");
        item.className="pro-selection-item";
        const no=document.createElement("span");
        no.className="pro-selection-no";
        no.textContent=`${index+1}`;
        const result=publishedSelectionResult(results,key,selection,index);
        const head=document.createElement("div");
        head.className="pro-selection-head";
        head.append(no,selectionResultNode(result));
        const pick=document.createElement("strong");
        pick.className="pro-pick";
        pick.textContent=localizePickLabel(selection.pick?.label||"今日正式推薦",selection);
        const matchup=document.createElement("p");
        matchup.className="pro-matchup";
        matchup.textContent=`${selection.league?`[${selection.league}] `:""}${localizeMatchup(selection.matchup||"棒球賽事")}${selection.time_taiwan?` · ${selection.time_taiwan}`:""}`;
        const metrics=document.createElement("div");
        metrics.className="pro-metrics";
        [
          selection.model_probability!=null?`模型 ${selection.model_probability}%`:null,
          selection.edge!=null?`優勢 ${Number(selection.edge)>0?"+":""}${selection.edge}%`:null,
          selection.price!=null?`盤口 ${formatAmericanOdds(selection.price)}`:null
        ].filter(Boolean).forEach(value=>{
          const chip=document.createElement("span");
          chip.textContent=value;
          metrics.append(chip);
        });
        const summary=document.createElement("p");
        summary.className="pro-summary";
        summary.textContent=memberVisibleSelectionSummary(selection.summary);
        item.append(head,pick,matchup,metrics,summary);
        list.append(item);
      });
      body.append(list);
    }

    function renderParlayList(key,parlays,results={}){
      const body=document.querySelector(`[data-pro-body="${key}"]`);
      if(!body)return;
      body.replaceChildren();
      const items=asSelectionArray(parlays);
      if(!items.length){
        const empty=document.createElement("p");
        empty.textContent="今日合格的不同場次不足，不為湊關強行發布。";
        body.append(empty);
        return;
      }
      const list=document.createElement("div");
      list.className="pro-selection-list";
      items.forEach((parlay,index)=>{
        const item=document.createElement("article");
        item.className="pro-selection-item";
        const no=document.createElement("span");
        no.className="pro-selection-no";
        no.textContent=`${index+1}`;
        const result=publishedSelectionResult(results,key,parlay,index);
        const head=document.createElement("div");
        head.className="pro-selection-head";
        head.append(no,selectionResultNode(result));
        const metrics=document.createElement("div");
        metrics.className="pro-metrics";
        [
          parlay.combined_model_probability!=null?`組合機率 ${parlay.combined_model_probability}%`:null,
          parlay.combined_american_odds!=null?`組合盤口 ${formatAmericanOdds(parlay.combined_american_odds)}`:null,
          parlay.risk?`風險 ${parlay.risk}`:null
        ].filter(Boolean).forEach(value=>{
          const chip=document.createElement("span");
          chip.textContent=value;
          metrics.append(chip);
        });
        const legs=document.createElement("ul");
        legs.className="parlay-legs";
        (parlay.legs||[]).forEach((leg,legIndex)=>{
          const row=document.createElement("li");
          const matchup=document.createElement("span");
          matchup.textContent=`${legIndex+1}. ${localizeMatchup(leg.matchup||"MLB")}`;
          const pick=document.createElement("b");
          pick.textContent=localizePickLabel(leg.pick?.label||"—",leg);
          row.append(matchup,pick);
          legs.append(row);
        });
        item.append(head,metrics,legs);
        list.append(item);
      });
      body.append(list);
    }

    const watchlistMarketLabels={moneylines:"獨贏",run_lines:"讓分",totals:"大小分"};
    function renderWatchlist(watchlist){
      const body=document.querySelector('[data-pro-body="watchlist"]');
      if(!body)return 0;
      body.replaceChildren();
      const items=[];
      Object.entries(watchlistMarketLabels).forEach(([group,label])=>{
        asSelectionArray(watchlist?.[group]).forEach(selection=>items.push({group,label,selection}));
      });
      if(!items.length){
        const empty=document.createElement("p");
        empty.textContent="今日沒有接近門檻的觀察項目；不會為了填滿版面加入低品質玩法。";
        body.append(empty);
        return 0;
      }
      const list=document.createElement("div");
      list.className="pro-selection-list";
      items.slice(0,9).forEach(({label,selection})=>{
        const item=document.createElement("article");
        item.className="pro-selection-item watchlist-item";
        const badge=document.createElement("span");
        badge.className="watchlist-label";
        badge.textContent=`${label}觀察 · 不計正式戰績`;
        const pick=document.createElement("strong");
        pick.className="pro-pick";
        pick.textContent=localizePickLabel(selection.pick?.label||"觀察項目",selection);
        const matchup=document.createElement("p");
        matchup.className="pro-matchup";
        matchup.textContent=`${selection.league?`[${selection.league}] `:""}${localizeMatchup(selection.matchup||"棒球賽事")}${selection.time_taiwan?` · ${selection.time_taiwan}`:""}`;
        const metrics=document.createElement("div");
        metrics.className="pro-metrics";
        [
          selection.model_probability!=null?`模型 ${selection.model_probability}%`:null,
          selection.edge!=null?`優勢 ${Number(selection.edge)>0?"+":""}${selection.edge}%`:null,
          selection.price!=null?`盤口 ${formatAmericanOdds(selection.price)}`:null
        ].filter(Boolean).forEach(value=>{
          const chip=document.createElement("span");
          chip.textContent=value;
          metrics.append(chip);
        });
        const reason=document.createElement("p");
        reason.className="watchlist-reason";
        const reasons=asSelectionArray(selection.watchlist_reasons);
        reason.textContent=reasons.length?reasons.join("；"):"接近正式門檻，等待名單或盤口更新。";
        item.append(badge,pick,matchup,metrics,reason);
        list.append(item);
      });
      body.append(list);
      return items.length;
    }

    function renderProPredictions(payload){
      if(payload?.pro_access!=="granted"){
        renderLockedProPredictions();
        return;
      }
      const moneylines=asSelectionArray(payload.moneylines);
      const runLines=asSelectionArray(payload.run_lines||payload.run_line);
      const totals=asSelectionArray(Array.isArray(payload.totals)?payload.totals:(payload.total||payload.totals));
      const twoLeg=asSelectionArray(payload.parlays?.two_leg);
      const threeLeg=asSelectionArray(payload.parlays?.three_leg);
      const publishedResults=payload.results||{};
      renderMarketList("moneylines",moneylines,"今日沒有獨贏玩法通過正式發布門檻。",publishedResults);
      renderMarketList("run_lines",runLines,"今日沒有讓分玩法通過正式發布門檻。",publishedResults);
      renderMarketList("totals",totals,"今日沒有大小分玩法通過正式發布門檻。",publishedResults);
      renderParlayList("two_leg",twoLeg,publishedResults);
      renderParlayList("three_leg",threeLeg,publishedResults);
      const admin=isAdminMember();
      const watchCount=admin?renderWatchlist(payload.watchlist||{}):0;
      const formalCount=moneylines.length+runLines.length+totals.length+twoLeg.length+threeLeg.length;
      const note=document.getElementById("proPredictionNote");
      if(!note)return;
      if(admin&&formalCount&&watchCount){
        note.textContent=`今日正式發布 ${formalCount} 項 Pro 推薦，另有 ${watchCount} 項創辦人觀察候選；觀察項目不結算、不計命中率。`;
      }else if(formalCount){
        note.textContent=`今日正式發布 ${formalCount} 項 Pro 推薦；全部已鎖定，後續不會更換。`;
      }else if(admin&&watchCount){
        note.textContent=`今日無正式 Pro 推薦；目前有 ${watchCount} 項候選只供創辦人內部審核。`;
      }else{
        note.textContent="今日沒有玩法通過正式發布門檻；DiamondMind 不會為了每天出單而降低標準。";
      }
    }


    const adminPlanLabels={trial_1d:"試用方案 · 1 天",gift_3d:"短期贈送 · 3 天",gift_7d:"短期贈送 · 7 天",monthly:"月方案",quarterly:"季方案",annual:"年方案",custom:"自訂到期時間",founder:"創辦人"};
    const adminStatusLabels={free:"免費",active:"有效",pending:"確認中",expired:"已到期",canceled:"已取消",payment_failed:"付款失敗",refunded:"已退款",founder:"永久權限"};
    function formatAdminDateTime(value){
      if(!value)return "—";
      const date=new Date(value);if(Number.isNaN(date.getTime()))return "—";
      return new Intl.DateTimeFormat("zh-TW",{timeZone:"Asia/Taipei",year:"numeric",month:"2-digit",day:"2-digit",hour:"2-digit",minute:"2-digit",hour12:false}).format(date);
    }
    function adminCurrency(value){const amount=Number(value||0);return `NT$${new Intl.NumberFormat("zh-TW").format(amount)}`}
    const settlementStatusLabels={pending:"等待",won:"命中",lost:"未中",push:"走水",void:"作廢"};
    const settlementGroupLabels={moneylines:"獨贏精選",run_lines:"讓分精選",totals:"大小分精選",two_leg:"二關串關",three_leg:"三關串關"};
    function settlementStatusLabel(value){return settlementStatusLabels[value]||value||"等待"}
    function settlementScore(item){
      const away=item?.away_score,home=item?.home_score;return away===null||away===undefined||home===null||home===undefined?"":` · ${away}:${home}`;
    }
    function settlementRow(item,label=""){
      const status=String(item?.status||"pending");const title=localizePickLabel(item?.pick_label||item?.label)||localizeMatchup(item?.matchup)||label||"推薦項目";
      const copy=[label,localizeMatchup(item?.matchup),item?.detailed_status,item?.result_note].filter(Boolean).join(" · ");
      return `<article class="settlement-row"><div class="settlement-row-main"><b>${escapeHtml(title)}${escapeHtml(settlementScore(item))}</b><span>${escapeHtml(copy||"等待官方賽果")}</span></div><span class="settlement-pill ${escapeHtml(status)}">${escapeHtml(settlementStatusLabel(status))}</span></article>`;
    }
    function renderSettlementDashboard(payload){
      state.settlementDashboard=payload;const summary=payload?.summary||{};
      document.getElementById("settlementTotal").textContent=summary.total??0;document.getElementById("settlementPending").textContent=summary.pending??0;document.getElementById("settlementSettled").textContent=summary.settled??0;document.getElementById("settlementNeutral").textContent=(Number(summary.push||0)+Number(summary.void||0));
      const publicRecord=payload?.public;const publicList=document.getElementById("settlementPublicList");const publicBadge=document.getElementById("settlementPublicBadge");
      if(!publicRecord){publicBadge.textContent="尚未發布";publicList.innerHTML='<div class="settlement-empty">此日期尚未發布免費精選。</div>'}
      else{const preview=publicRecord.preview||{};publicBadge.textContent=publicRecord.locked?"已鎖定":"未鎖定";publicList.innerHTML=settlementRow({...preview,pick_label:publicRecord.pick_label,matchup:publicRecord.matchup},"免費精選")}
      const packageData=payload?.package;const packageList=document.getElementById("settlementPackageList");const packageBadge=document.getElementById("settlementPackageBadge");
      if(!packageData){packageBadge.textContent="尚未發布";packageList.innerHTML='<div class="settlement-empty">此日期尚未發布 Pro 推薦。</div>'}
      else{const rows=[];Object.entries(packageData.groups||{}).forEach(([group,items])=>(items||[]).forEach(item=>rows.push(settlementRow(item,settlementGroupLabels[group]||group))));packageBadge.textContent=packageData.settled?"全部已結算":`${packageData.summary?.pending||0} 項等待`;packageList.innerHTML=rows.join("")||'<div class="settlement-empty">已建立推薦包，但沒有玩法項目。</div>'}
      const monitor=payload?.monitor||{};const last=monitor.last_run?formatAdminDateTime(monitor.last_run):"尚未執行";const errors=(payload?.errors||[]).length;document.getElementById("settlementMonitorNote").innerHTML=`<b>自動結算監控：${monitor.running===false?"已停止":"運作中"}</b><br>最後檢查：${escapeHtml(last)} · 本次免費結算 ${Number(monitor.free_settled_now||0)} 筆 · Pro 結算 ${Number(monitor.packages_settled_now||0)} 包${errors?` · ${errors} 場賽事暫時無法讀取`:""}`;
    }
    async function loadSettlementDashboard(force=false,runNow=false){
      if(!isAdminMember()||state.settlementLoading)return;const dateInput=document.getElementById("settlementDate");if(!dateInput.value)dateInput.value=state.settlementDate||taiwanToday();const target=dateInput.value;
      if(!force&&state.settlementDashboard&&state.settlementDate===target){renderSettlementDashboard(state.settlementDashboard);return}
      state.settlementLoading=true;const refresh=document.getElementById("settlementRefresh"),run=document.getElementById("settlementRun");if(refresh)refresh.disabled=true;if(run)run.disabled=true;
      try{const payload=await billingRequest(`/admin/settlement/${runNow?"run":"status"}?date=${encodeURIComponent(target)}`,{method:runNow?"POST":"GET",timeout:60000});const dashboard=runNow?(payload.dashboard||{}):payload;if(runNow)dashboard.monitor={running:true,last_run:new Date().toISOString(),free_settled_now:payload.free_settled_now||0,packages_settled_now:payload.packages_settled_now||0};state.settlementDate=target;renderSettlementDashboard(dashboard);if(runNow)showToast(payload.message||"結算檢查完成")}
      catch(error){document.getElementById("settlementPublicList").innerHTML=`<div class="settlement-empty">${escapeHtml(error.message||"載入失敗")}</div>`;document.getElementById("settlementPackageList").innerHTML='<div class="settlement-empty">請稍後再試。</div>'}
      finally{state.settlementLoading=false;if(refresh)refresh.disabled=false;if(run)run.disabled=false}
    }


    const modelMarketLabels={moneyline:"獨贏",run_line:"讓分",totals:"大小分",two_leg:"二關",three_leg:"三關",unknown:"其他"};
    const modelLeagueLabels={MLB:"MLB 美國職棒",NPB:"NPB 日本職棒","MLB+NPB":"跨聯盟串關",unknown:"其他聯盟"};
    const modelConfidenceLabels={under_60:"低於 60%","60_64":"60–64%","65_69":"65–69%","70_plus":"70% 以上",unknown:"未分類"};
    const modelPublicationLabels={ai_auto:"AI 正式推薦",founder_selected:"創辦人指定",unknown:"其他來源"};
    const modelModuleLabels={team_strength:"球隊實力",starter:"先發投手",lineup:"打線強度",bullpen:"牛棚狀態",advanced:"進階數據",environment:"環境條件"};
    function modelRate(value){return value===null||value===undefined?"—":`${Number(value).toFixed(1)}%`}
    function modelBreakdownRows(items,labels){
      if(!items?.length)return '<div class="settlement-empty">目前尚無已發布快照。</div>';
      return items.map(item=>`<div class="model-breakdown-row"><div><b>${escapeHtml(labels[item.key]||item.key)}</b><span>命中 ${Number(item.won||0)} · 未中 ${Number(item.lost||0)} · 盈虧 ${escapeHtml(formatUnits(item.profit_units))}</span></div><span>${item.roi_percent==null?"ROI —":`ROI ${Number(item.roi_percent).toFixed(2)}%`}</span><strong>${escapeHtml(modelRate(item.hit_rate))}</strong></div>`).join("");
    }
    function renderModelWeights(calibration={}){
      const list=document.getElementById("modelWeightList");if(!list)return;
      state.modelSuggestedWeights=calibration.recommended_weights||null;
      const modules=calibration.modules||[];
      list.innerHTML=modules.map(item=>{
        const current=Number(item.current_weight||0);const suggested=Number(item.recommended_weight||current);
        const direction=item.direction==="increase"?"建議提高":item.direction==="decrease"?"建議降低":"維持";
        return `<div class="model-weight-row"><label>${escapeHtml(item.label||modelModuleLabels[item.key]||item.key)}<small style="display:block;color:var(--muted);margin-top:3px">${escapeHtml(direction)} · 樣本 ${Number(item.sample||0)}</small></label><div class="model-weight-track"><div class="model-weight-fill" style="width:${Math.min(100,Math.max(0,current*100))}%"></div></div><input type="number" min="0" max="1" step="0.001" id="modelWeight_${escapeHtml(item.key)}" data-model-weight-key="${escapeHtml(item.key)}" value="${suggested.toFixed(3)}" aria-label="${escapeHtml(item.label||item.key)}權重"></div>`;
      }).join("")||'<div class="settlement-empty">尚無權重資料。</div>';
      const message=document.getElementById("modelCalibrationMessage");if(message)message.textContent=calibration.message||"尚無校正資料。";
      const apply=document.getElementById("modelApplyWeights");if(apply)apply.disabled=!calibration.ready;
      const use=document.getElementById("modelUseSuggested");if(use)use.disabled=!calibration.recommended_weights;
    }
    function renderModelSnapshots(items=[]){
      const list=document.getElementById("modelSnapshotList");if(!list)return;
      if(!items.length){list.innerHTML='<div class="settlement-empty">尚無模型快照；正式發布推薦後會自動建立。</div>';return}
      list.innerHTML=items.slice(0,30).map(item=>{
        const status=String(item.status||"pending");
        const mode=item.publication_snapshot?.mode;
        const source=item.source_type==="public"?"免費":item.source_type==="pro"?(mode==="founder_selected"?"PRO・創辦人指定":"PRO・AI 正式"):"TEST";
        const meta=[item.recommendation_date,source,modelMarketLabels[item.market]||item.market,item.confidence!=null?`信心 ${item.confidence}%`:null,item.data_quality!=null?`資料 ${Math.round(Number(item.data_quality)*100)}%`:null].filter(Boolean).join(" · ");
        return `<article class="model-snapshot-row"><div><b>${escapeHtml(item.pick_label||"推薦快照")}</b><span>${escapeHtml(meta)}</span></div><span class="model-status ${escapeHtml(status)}">${escapeHtml(settlementStatusLabel(status))}</span></article>`;
      }).join("");
    }
    function renderModelPerformance(payload,snapshots){
      state.modelPerformance=payload;state.modelSnapshots=snapshots;
      const summary=payload?.summary||{};
      document.getElementById("modelTotal").textContent=summary.total??0;
      document.getElementById("modelDecisions").textContent=summary.decisions??0;
      document.getElementById("modelHitRate").textContent=modelRate(summary.hit_rate);
      document.getElementById("modelProfit").textContent=formatUnits(summary.profit_units);
      document.getElementById("modelProfit").className=profitTone(summary.profit_units);
      document.getElementById("modelROI").textContent=summary.roi_percent==null?"—":`${Number(summary.roi_percent).toFixed(2)}%`;
      document.getElementById("modelROI").className=profitTone(summary.roi_percent);
      document.getElementById("modelPending").textContent=summary.pending??0;
      document.getElementById("modelMarketBreakdown").innerHTML=modelBreakdownRows(payload?.by_market||[],modelMarketLabels);
      document.getElementById("modelLeagueBreakdown").innerHTML=modelBreakdownRows(payload?.by_league||[],modelLeagueLabels);
      document.getElementById("modelConfidenceBreakdown").innerHTML=modelBreakdownRows(payload?.by_confidence||[],modelConfidenceLabels);
      document.getElementById("modelPublicationBreakdown").innerHTML=modelBreakdownRows(payload?.by_publication_mode||[],modelPublicationLabels);
      renderModelWeights(payload?.calibration||{});
      renderModelSnapshots(snapshots?.items||[]);
    }
    async function loadModelPerformance(force=false){
      if(!isAdminMember()||state.modelLoading)return;
      if(state.modelPerformance&&!force){renderModelPerformance(state.modelPerformance,state.modelSnapshots||{items:[]});return}
      state.modelLoading=true;const refresh=document.getElementById("modelRefresh");if(refresh)refresh.disabled=true;
      const range=document.getElementById("modelRange")?.value||"30d";const market=document.getElementById("modelMarket")?.value||"all";const source=document.getElementById("modelSource")?.value||"all";
      const params=new URLSearchParams({range,market,source_type:source});
      try{
        const [performance,snapshots]=await Promise.all([
          billingRequest(`/admin/model/performance?${params}`,{timeout:30000}),
          billingRequest(`/admin/model/snapshots?${params}&include_test=true&limit=250`,{timeout:30000})
        ]);
        renderModelPerformance(performance,snapshots);
      }catch(error){
        document.getElementById("modelMarketBreakdown").innerHTML=`<div class="settlement-empty">${escapeHtml(error.message||"模型績效載入失敗")}</div>`;
        document.getElementById("modelLeagueBreakdown").innerHTML='<div class="settlement-empty">聯盟績效暫時無法載入。</div>';
        document.getElementById("modelConfidenceBreakdown").innerHTML='<div class="settlement-empty">請確認已執行模型績效 SQL。</div>';
      }finally{state.modelLoading=false;if(refresh)refresh.disabled=false}
    }
    function useSuggestedModelWeights(){
      const weights=state.modelSuggestedWeights||{};Object.entries(weights).forEach(([key,value])=>{const input=document.getElementById(`modelWeight_${key}`);if(input)input.value=Number(value).toFixed(3)});showToast("已將建議權重填入輸入框，尚未正式套用");
    }
    async function applyModelWeights(){
      const calibration=state.modelPerformance?.calibration||{};if(!calibration.ready){showToast(calibration.message||"樣本數尚未達校正門檻");return}
      const weights={};document.querySelectorAll("[data-model-weight-key]").forEach(input=>weights[input.dataset.modelWeightKey]=Number(input.value||0));
      const sum=Object.values(weights).reduce((total,value)=>total+Number(value||0),0);if(sum<=0){showToast("權重總和必須大於 0");return}
      if(!window.confirm("確定啟用這組新模型權重嗎？\n\n只影響後續重新計算的賽事，已發布推薦不會更改。"))return;
      const button=document.getElementById("modelApplyWeights");if(button)button.disabled=true;
      try{const result=await billingRequest("/admin/model/calibration/apply",{method:"POST",body:{weights,note:"Founder confirmed from model performance dashboard",confirm:true},timeout:30000});showToast(result.message||"模型權重已啟用");state.modelPerformance=null;await loadModelPerformance(true)}
      catch(error){showToast(error.message||"權重套用失敗")}
      finally{if(button)button.disabled=false}
    }
    function updateModelTestSide(){
      const market=document.getElementById("modelTestMarket")?.value||"moneyline";const side=document.getElementById("modelTestSide");const line=document.getElementById("modelTestLine");if(!side||!line)return;
      side.innerHTML=market==="totals"?'<option value="over">大分</option><option value="under">小分</option>':'<option value="home">主隊</option><option value="away">客隊</option>';
      line.disabled=market==="moneyline";line.placeholder=market==="run_line"?"例如 -1.5":market==="totals"?"例如 8.5":"獨贏不需盤口";if(market==="moneyline")line.value="";
    }
    async function runModelTestSettlement(){
      const resultBox=document.getElementById("modelTestResult");const button=document.getElementById("modelRunTest");if(resultBox){resultBox.className="model-test-result";resultBox.textContent="正在建立 TEST 快照並執行結算…"}if(button)button.disabled=true;
      const market=document.getElementById("modelTestMarket")?.value||"moneyline";const lineRaw=document.getElementById("modelTestLine")?.value;
      const body={recommendation_date:document.getElementById("modelTestDate")?.value||taiwanToday(),market,pick_side:document.getElementById("modelTestSide")?.value||"home",line:lineRaw===""?null:Number(lineRaw),away_score:Number(document.getElementById("modelTestAwayScore")?.value||0),home_score:Number(document.getElementById("modelTestHomeScore")?.value||0),confidence:Number(document.getElementById("modelTestConfidence")?.value||65),data_quality:Number(document.getElementById("modelTestQuality")?.value||0.75),module_edges:{starter:0.08,lineup:0.05,bullpen:0.03,team_strength:0.02,advanced:0.04,environment:0.01}};
      try{const payload=await billingRequest("/admin/model/test-settlement",{method:"POST",body,timeout:30000});if(resultBox){resultBox.className="model-test-result success";resultBox.textContent=`測試完成：${settlementStatusLabel(payload.result?.status)}。TEST 快照已保存，但不計入真實績效。`}showToast("測試結算完成");state.modelPerformance=null;state.modelSnapshots=null;await loadModelPerformance(true);document.getElementById("modelSnapshotList")?.scrollIntoView({behavior:"smooth",block:"center"})}
      catch(error){if(resultBox){resultBox.className="model-test-result error";resultBox.textContent=error.message||"測試結算失敗"}}
      finally{if(button)button.disabled=false}
    }
    async function downloadModelCsv(kind){
      if(!isAdminMember())return;const range=document.getElementById("modelRange")?.value||"season";const button=document.getElementById(kind==="snapshots"?"modelExportSnapshots":"modelExportPerformance");const original=button?.textContent||"匯出 CSV";if(button){button.disabled=true;button.textContent="準備中…"}
      try{const response=await fetch(`${API_BASE}/admin/model/export/${kind}.csv?range=${encodeURIComponent(range)}`,{headers:{Accept:"text/csv",Authorization:`Bearer ${authState.session.access_token}`},cache:"no-store"});if(!response.ok)throw new Error(`HTTP ${response.status}`);const blob=await response.blob();const url=URL.createObjectURL(blob);const link=document.createElement("a");link.href=url;link.download=kind==="snapshots"?"diamondmind_model_snapshots.csv":"diamondmind_model_performance.csv";document.body.appendChild(link);link.click();link.remove();URL.revokeObjectURL(url);showToast("CSV 已準備下載")}
      catch(error){showToast(error.message||"CSV 匯出失敗")}
      finally{if(button){button.disabled=false;button.textContent=original}}
    }

    function adminRoleLabel(role){return role==="admin"?"創辦人":role==="pro"?"PRO":"FREE"}
    function operationsStatusLabel(status){return status==="pass"?"正常":status==="fail"?"異常":status==="warning"?"需注意":"待完成"}
    function operationsClass(status){return status==="pass"?"pass":status==="fail"?"fail":"warning"}
    function renderOperationsStatus(payload){
      state.operationsStatus=payload||{};
      const services=payload?.services||{},monitors=payload?.monitors||{},pregame=monitors.pregame||{},settlement=monitors.settlement||{};
      const ready=payload?.overall==="stage_ready";
      const overall=document.getElementById("operationsOverall"),badge=document.getElementById("operationsState");
      if(overall)overall.textContent=ready?"測試營運環境已就緒":"仍有項目需要處理";
      if(badge){badge.className=`operations-state ${ready?"pass":""}`;badge.textContent=ready?"STAGE READY":"ATTENTION"}
      document.getElementById("operationsGenerated").textContent=`檢查時間：${formatAdminDateTime(payload?.generated_at)} · Runtime：${formatAdminDateTime(payload?.runtime_started_at)}`;
      document.getElementById("operationsVersion").textContent=payload?.version||"—";
      const payment=document.getElementById("operationsPayment");payment.textContent=services.billing?services.billing_live?"正式環境":"測試環境":"未設定";payment.className=services.billing?(services.billing_live?"pass":"warning"):"fail";
      document.getElementById("operationsPaymentMeta").textContent=services.billing?`ECPay · ${services.billing_mode||"—"}`:"付款服務設定不完整";
      const db=document.getElementById("operationsDatabase");db.textContent=services.records_database?"已連線":"未設定";db.className=services.records_database?"pass":"fail";
      const odds=document.getElementById("operationsOdds");odds.textContent=services.odds_feed?"已設定":"未設定";odds.className=services.odds_feed?"pass":"warning";
      const scheduler=document.getElementById("operationsScheduler");scheduler.textContent=services.scheduler?"已設定":"未設定";scheduler.className=services.scheduler?"pass":"warning";
      const support=document.getElementById("operationsSupport");support.textContent=services.support_email||"尚未設定";support.className=services.support_email?"pass":"warning";
      const checks=payload?.checks||[];
      document.getElementById("operationsChecklist").innerHTML=checks.length?checks.map(item=>`<div class="operations-check ${operationsClass(item.status)}"><span class="operations-check-icon">${item.status==="pass"?"✓":item.status==="fail"?"!":"•"}</span><div><b>${escapeHtml(item.label||item.key||"檢查項目")} · ${operationsStatusLabel(item.status)}</b><p>${escapeHtml(item.detail||"")}</p></div></div>`).join(""):'<div class="admin-empty">沒有檢查項目。</div>';
      document.getElementById("operationsPregame").textContent=pregame.running===false?"已停止":pregame.last_error?"發生錯誤":"執行中";
      document.getElementById("operationsPregameLast").textContent=formatAdminDateTime(pregame.last_run)||"尚無紀錄";
      document.getElementById("operationsSettlement").textContent=settlement.running===false?"已停止":settlement.last_error?"發生錯誤":"執行中";
      document.getElementById("operationsSettlementLast").textContent=formatAdminDateTime(settlement.last_run)||"尚無紀錄";
      const errors=[...(payload?.monitor_errors||[])];const errorBox=document.getElementById("operationsErrors");
      errorBox.hidden=!errors.length;errorBox.textContent=errors.length?`監控錯誤：${errors.join(" / ")}`:"";
    }
    async function loadOperationsStatus(force=false){
      if(state.operationsLoading)return;
      if(state.operationsStatus&&!force){renderOperationsStatus(state.operationsStatus);return}
      state.operationsLoading=true;
      try{const payload=await billingRequest("/admin/operations/status",{timeout:30000});renderOperationsStatus(payload)}
      catch(error){showToast(error.message||"營運狀態載入失敗");const box=document.getElementById("operationsErrors");if(box){box.hidden=false;box.textContent=error.message||"營運狀態載入失敗"}}
      finally{state.operationsLoading=false}
    }
    document.getElementById("operationsRefresh")?.addEventListener("click",()=>{state.operationsStatus=null;loadOperationsStatus(true)});

    function adminRoleClass(role,status){if(role==="admin")return "admin";if(role==="pro")return "pro";if(["canceled","expired","payment_failed"].includes(status))return "canceled";return ""}
    function adminStatusClass(status){return status==="active"||status==="founder"?"success":["canceled","expired","payment_failed","refunded"].includes(status)?"failed":""}
    function setAdminTab(tab){
      state.adminTab=tab;
      document.querySelectorAll("[data-admin-tab]").forEach(button=>button.classList.toggle("active",button.dataset.adminTab===tab));
      document.getElementById("adminMembersPanel").hidden=tab!=="members";
      document.getElementById("adminTransactionsPanel").hidden=tab!=="transactions";
      if(tab==="transactions"&&!state.adminTransactions)loadAdminTransactions();
    }
    document.querySelectorAll("[data-admin-tab]").forEach(button=>button.addEventListener("click",()=>setAdminTab(button.dataset.adminTab)));

    function renderAdminSummary(summary={}){
      document.getElementById("adminTotalMembers").textContent=summary.total_members??"—";
      document.getElementById("adminActivePro").textContent=summary.active_pro??"—";
      document.getElementById("adminFreeMembers").textContent=summary.free_members??"—";
      document.getElementById("adminRevenue").textContent=summary.revenue_twd===undefined?"—":adminCurrency(summary.revenue_twd);
    }
    function renderAdminMembers(payload){
      const list=document.getElementById("adminMembersList");
      const items=payload?.members||[];
      renderAdminSummary(payload?.summary||{});
      if(!items.length){list.innerHTML='<div class="admin-empty">沒有符合條件的會員。</div>'}
      else list.innerHTML=items.map(item=>`<article class="admin-member-row" data-admin-member-id="${escapeHtml(item.id||"")}">
        <div class="admin-member-main"><b>${escapeHtml(item.name||"DiamondMind 會員")}</b><span>${escapeHtml(item.email||"—")}</span></div>
        <div><span class="admin-cell-label">角色</span><span class="admin-role ${adminRoleClass(item.role,item.status)}">${escapeHtml(adminRoleLabel(item.role))}</span></div>
        <div><span class="admin-cell-label">狀態</span><span class="admin-status-pill ${adminStatusClass(item.status)}">${escapeHtml(adminStatusLabels[item.status]||item.status||"—")}</span></div>
        <div class="admin-muted"><span class="admin-cell-label">有效期限</span>${escapeHtml(formatMembershipDate(item.pro_expires_at||item.current_period_end))}</div><div class="chevron">›</div>
      </article>`).join("");
      list.querySelectorAll("[data-admin-member-id]").forEach(row=>row.addEventListener("click",()=>openAdminMember(row.dataset.adminMemberId)));
      const page=payload?.pagination||{};const from=page.total?Number(page.offset||0)+1:0;const to=Math.min(Number(page.offset||0)+Number(page.limit||0),Number(page.total||0));
      document.getElementById("adminMembersPageInfo").textContent=`${from}–${to}／共 ${page.total||0} 位`;
      document.getElementById("adminMembersPrev").disabled=Number(page.offset||0)<=0;
      document.getElementById("adminMembersNext").disabled=!page.has_more;
    }
    async function loadAdminMembers(force=false){
      if(!isAdminMember()||state.adminLoading)return;
      if(state.adminMembers&&!force){renderAdminMembers(state.adminMembers);return}
      state.adminLoading=true;document.getElementById("adminMembersList").innerHTML='<div class="admin-empty">正在載入會員資料…</div>';
      const query=document.getElementById("adminMemberSearch")?.value.trim()||"";
      const role=document.getElementById("adminMemberRole")?.value||"all";
      const status=document.getElementById("adminMemberStatus")?.value||"all";
      const params=new URLSearchParams({query,role,status,limit:String(state.adminPageSize),offset:String(state.adminMembersOffset)});
      try{state.adminMembers=await billingRequest(`/admin/members?${params}`,{timeout:30000});renderAdminMembers(state.adminMembers)}
      catch(error){document.getElementById("adminMembersList").innerHTML=`<div class="admin-empty">${escapeHtml(error.message||"會員資料載入失敗")}</div>`}
      finally{state.adminLoading=false}
    }
    function renderAdminTransactions(payload){
      const list=document.getElementById("adminTransactionsList");const items=payload?.transactions||[];
      if(!items.length)list.innerHTML='<div class="admin-empty">沒有符合條件的交易紀錄。</div>';
      else list.innerHTML=items.map(item=>`<article class="admin-transaction-row" data-admin-transaction-id="${escapeHtml(item.id||item.merchant_trade_no||"")}" role="button" tabindex="0" aria-label="查看交易 ${escapeHtml(item.merchant_trade_no||"")}">
        <div class="admin-muted"><span class="admin-cell-label">時間</span>${escapeHtml(formatAdminDateTime(item.created_at))}</div>
        <div class="admin-member-main"><b>${escapeHtml(item.email||"未知會員")}</b><span>${escapeHtml(item.merchant_trade_no||"—")}</span></div>
        <div><span class="admin-cell-label">結果</span><span class="admin-status-pill ${item.success?"success":"failed"}">${item.success?"成功":"失敗"}</span></div>
        <div><span class="admin-cell-label">金額</span>${escapeHtml(adminCurrency(item.amount))}</div>
        <div class="admin-muted"><span class="admin-cell-label">訊息</span>${escapeHtml(item.rtn_msg||item.event_type||"—")}<span class="admin-row-link">查看完整明細 ›</span></div>
      </article>`).join("");
      list.querySelectorAll("[data-admin-transaction-id]").forEach(row=>{
        const open=()=>openAdminTransaction(row.dataset.adminTransactionId);
        row.addEventListener("click",open);row.addEventListener("keydown",event=>{if(event.key==="Enter"||event.key===" "){event.preventDefault();open()}});
      });
      const page=payload?.pagination||{};const from=page.total?Number(page.offset||0)+1:0;const to=Math.min(Number(page.offset||0)+Number(page.limit||0),Number(page.total||0));
      document.getElementById("adminTransactionsPageInfo").textContent=`${from}–${to}／共 ${page.total||0} 筆`;
      document.getElementById("adminTransactionsPrev").disabled=Number(page.offset||0)<=0;
      document.getElementById("adminTransactionsNext").disabled=!page.has_more;
    }
    async function loadAdminTransactions(force=false){
      if(!isAdminMember()||state.adminLoading)return;
      if(state.adminTransactions&&!force){renderAdminTransactions(state.adminTransactions);return}
      state.adminLoading=true;document.getElementById("adminTransactionsList").innerHTML='<div class="admin-empty">正在載入交易資料…</div>';
      const query=document.getElementById("adminTransactionSearch")?.value.trim()||"";const result=document.getElementById("adminTransactionResult")?.value||"all";
      const params=new URLSearchParams({query,result,limit:String(state.adminPageSize),offset:String(state.adminTransactionsOffset)});
      try{state.adminTransactions=await billingRequest(`/admin/transactions?${params}`,{timeout:30000});renderAdminTransactions(state.adminTransactions)}
      catch(error){document.getElementById("adminTransactionsList").innerHTML=`<div class="admin-empty">${escapeHtml(error.message||"交易資料載入失敗")}</div>`}
      finally{state.adminLoading=false}
    }
    function openAdminTransaction(transactionId){
      const items=state.adminTransactions?.transactions||[];const item=items.find(row=>String(row.id||row.merchant_trade_no||"")===String(transactionId));
      if(!item)return;state.adminSelectedTransaction=item;
      document.getElementById("adminTransactionDetailResult").textContent=item.success?"付款成功":"付款失敗";
      document.getElementById("adminTransactionDetailAmount").textContent=adminCurrency(item.amount);
      document.getElementById("adminTransactionDetailEmail").textContent=item.email||"—";
      document.getElementById("adminTransactionDetailMerchantNo").textContent=item.merchant_trade_no||"—";
      document.getElementById("adminTransactionDetailProviderNo").textContent=item.provider_trade_no||"—";
      document.getElementById("adminTransactionDetailTime").textContent=formatAdminDateTime(item.created_at);
      document.getElementById("adminTransactionDetailPaymentType").textContent=item.payment_type||"—";
      document.getElementById("adminTransactionDetailProvider").textContent=item.provider||"—";
      document.getElementById("adminTransactionDetailEvent").textContent=item.event_type||"—";
      document.getElementById("adminTransactionDetailMessage").textContent=item.rtn_msg||"—";
      openModal("adminTransactionModal");
    }
    async function copyAdminTransactionNo(){
      const value=state.adminSelectedTransaction?.merchant_trade_no;if(!value)return showToast("沒有可複製的交易編號");
      try{await navigator.clipboard.writeText(value);showToast("交易編號已複製")}catch{showToast("請長按交易編號手動複製")}
    }
    function adminExportParams(kind){
      if(kind==="members")return new URLSearchParams({query:document.getElementById("adminMemberSearch")?.value.trim()||"",role:document.getElementById("adminMemberRole")?.value||"all",status:document.getElementById("adminMemberStatus")?.value||"all"});
      return new URLSearchParams({query:document.getElementById("adminTransactionSearch")?.value.trim()||"",result:document.getElementById("adminTransactionResult")?.value||"all"});
    }
    async function downloadAdminCsv(kind){
      if(!isAdminMember()||!authState.session?.access_token)return;
      const button=document.getElementById(kind==="members"?"adminMembersExport":"adminTransactionsExport");const original=button?.textContent||"匯出 CSV";if(button){button.disabled=true;button.textContent="準備中…"}
      try{
        const params=adminExportParams(kind);const response=await fetch(`${API_BASE}/admin/export/${kind}.csv?${params}`,{headers:{Accept:"text/csv",Authorization:`Bearer ${authState.session.access_token}`},cache:"no-store"});
        if(!response.ok){let message=`HTTP ${response.status}`;try{const payload=await response.json();message=payload.detail||message}catch{}throw new Error(message)}
        const blob=await response.blob();const url=URL.createObjectURL(blob);const link=document.createElement("a");link.href=url;link.download=kind==="members"?"diamondmind_members.csv":"diamondmind_transactions.csv";document.body.appendChild(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);showToast("CSV 已開始下載");
      }catch(error){showToast(error.message||"CSV 匯出失敗")}finally{if(button){button.disabled=false;button.textContent=original}}
    }
    function adminHistoryItem(title,copy){return `<div class="admin-history-item"><b>${escapeHtml(title)}</b><span>${escapeHtml(copy)}</span></div>`}
    function renderAdminMemberDetail(payload){
      const member=payload?.member||{};state.adminSelectedMember=member;
      document.getElementById("adminMemberModalTitle").textContent=member.name||"會員資料";
      document.getElementById("adminMemberModalMeta").textContent=`會員 ID ${member.id||"—"}`;
      document.getElementById("adminDetailName").textContent=member.name||"DiamondMind 會員";
      document.getElementById("adminDetailEmail").textContent=member.email||"—";
      const role=document.getElementById("adminDetailRole");role.textContent=adminRoleLabel(member.role);role.className=`admin-role ${adminRoleClass(member.role,member.status)}`;
      const status=document.getElementById("adminDetailStatus");status.textContent=adminStatusLabels[member.status]||member.status||"—";status.className=`admin-status-pill ${adminStatusClass(member.status)}`;
      document.getElementById("adminDetailPlan").textContent=adminPlanLabels[member.plan]||member.plan||"免費方案";
      document.getElementById("adminDetailExpiry").textContent=formatMembershipDate(member.pro_expires_at||member.current_period_end);
      document.getElementById("adminDetailCreated").textContent=formatAdminDateTime(member.created_at);
      document.getElementById("adminDetailLastSignIn").textContent=formatAdminDateTime(member.last_sign_in_at);
      document.getElementById("adminDetailProvider").textContent=member.provider||"—";
      document.getElementById("adminDetailTrade").textContent=member.merchant_trade_no||"—";
      document.getElementById("adminMemberControls").hidden=member.role==="admin";
      document.getElementById("adminControlNote").value="";document.getElementById("adminControlPlan").value="trial_1d";document.getElementById("adminCustomExpiry").value="";document.getElementById("adminCustomExpiry").hidden=true;document.getElementById("adminControlNoteStatus").textContent="";
      const payments=payload?.payments||[];document.getElementById("adminMemberPayments").innerHTML=payments.length?payments.slice(0,8).map(item=>adminHistoryItem(`${item.success?"付款成功":"付款失敗"} · ${adminCurrency(item.amount)}`,`${formatAdminDateTime(item.created_at)} · ${item.merchant_trade_no||"—"} · ${item.rtn_msg||item.event_type||"—"}`)).join(""):'<div class="admin-empty">尚無付款紀錄。</div>';
      const audit=payload?.admin_events||[];document.getElementById("adminMemberAudit").innerHTML=audit.length?audit.slice(0,8).map(item=>adminHistoryItem(`${({grant:"開通／重設",extend:"延長",cancel:"取消"})[item.action]||item.action} · ${adminPlanLabels[item.plan_code]||"—"}`,`${formatAdminDateTime(item.created_at)} · 操作者 ${item.actor_email||"—"}${item.note?` · ${item.note}`:""}`)).join(""):'<div class="admin-empty">尚無人工調整紀錄。</div>';
    }
    async function openAdminMember(userId){
      if(!isAdminMember())return;openModal("adminMemberModal");document.getElementById("adminMemberModalTitle").textContent="正在載入會員…";
      try{const payload=await billingRequest(`/admin/members/${encodeURIComponent(userId)}`,{timeout:30000});renderAdminMemberDetail(payload)}
      catch(error){document.getElementById("adminMemberModalTitle").textContent="會員資料載入失敗";document.getElementById("adminMemberModalMeta").textContent=error.message||"請稍後重試"}
    }
    function adminCustomExpiryIso(){const value=document.getElementById("adminCustomExpiry").value;if(!value)return null;const date=new Date(value);return Number.isNaN(date.getTime())?null:date.toISOString()}
    function toggleAdminCustomExpiry(){const custom=document.getElementById("adminControlPlan").value==="custom";document.getElementById("adminCustomExpiry").hidden=!custom}
    function openAdminMembershipConfirm(action){
      const member=state.adminSelectedMember;if(!member?.id)return;
      const plan=document.getElementById("adminControlPlan").value;const note=document.getElementById("adminControlNote").value.trim();const customExpiresAt=plan==="custom"?adminCustomExpiryIso():null;
      if(action!=="cancel"&&plan==="custom"&&!customExpiresAt){document.getElementById("adminControlNoteStatus").textContent="請選擇有效的自訂到期時間";document.getElementById("adminControlNoteStatus").className="admin-note error";return}
      const actionLabel=({grant:"開通／重設 Pro",extend:"延長 Pro",cancel:"取消 Pro"})[action];
      state.adminPendingAction={action,plan:action==="cancel"?null:plan,note,custom_expires_at:action==="cancel"?null:customExpiresAt,memberId:member.id,email:member.email||"—"};
      document.getElementById("adminConfirmAction").textContent=actionLabel;
      document.getElementById("adminConfirmPlan").textContent=action==="cancel"?"立即恢復免費會員":plan==="custom"?`自訂至 ${formatAdminDateTime(customExpiresAt)}`:adminPlanLabels[plan]||plan;
      document.getElementById("adminConfirmMember").textContent=member.email||"—";
      document.getElementById("adminConfirmNote").textContent=note||"未填寫";
      document.getElementById("adminConfirmWarning").textContent=action==="cancel"?"取消後會立即收回 Pro 權限，但不會自動向綠界退款。":"執行後會立即更新會員到期日；所有操作都會保留操作者與時間紀錄。";
      document.getElementById("adminConfirmStatus").textContent="";openModal("adminMembershipConfirmModal");
    }
    async function applyAdminMembership(){
      const pending=state.adminPendingAction;if(!pending?.memberId)return;
      const status=document.getElementById("adminConfirmStatus");const submit=document.getElementById("adminConfirmSubmit");const cancel=document.getElementById("adminConfirmCancel");
      status.textContent="正在更新會員權限…";status.className="admin-note";submit.disabled=true;cancel.disabled=true;
      try{
        await billingRequest(`/admin/members/${encodeURIComponent(pending.memberId)}/membership`,{method:"POST",body:{action:pending.action,plan:pending.plan,note:pending.note,custom_expires_at:pending.custom_expires_at},timeout:30000});
        state.adminMembers=null;state.adminTransactions=null;state.adminPendingAction=null;closeModals();await loadAdminMembers(true);await openAdminMember(pending.memberId);showToast("會員權限已更新");
      }catch(error){status.textContent=error.message||"會員權限更新失敗";status.className="admin-note error"}
      finally{submit.disabled=false;cancel.disabled=false}
    }
    document.getElementById("adminControlPlan")?.addEventListener("change",toggleAdminCustomExpiry);
    document.querySelectorAll("[data-admin-membership-action]").forEach(button=>button.addEventListener("click",()=>openAdminMembershipConfirm(button.dataset.adminMembershipAction)));
    document.getElementById("adminConfirmSubmit")?.addEventListener("click",applyAdminMembership);
    document.getElementById("adminConfirmCancel")?.addEventListener("click",()=>{const id=state.adminPendingAction?.memberId;state.adminPendingAction=null;closeModals();if(id)openAdminMember(id)});
    document.getElementById("adminCopyTransactionNo")?.addEventListener("click",copyAdminTransactionNo);
    document.getElementById("adminMembersExport")?.addEventListener("click",()=>downloadAdminCsv("members"));
    document.getElementById("adminTransactionsExport")?.addEventListener("click",()=>downloadAdminCsv("transactions"));
    document.getElementById("adminMemberApply")?.addEventListener("click",()=>{state.adminMembersOffset=0;state.adminMembers=null;loadAdminMembers(true)});
    document.getElementById("adminTransactionApply")?.addEventListener("click",()=>{state.adminTransactionsOffset=0;state.adminTransactions=null;loadAdminTransactions(true)});
    document.getElementById("adminRefreshAll")?.addEventListener("click",()=>{state.adminMembers=null;state.adminTransactions=null;loadAdminMembers(true);if(state.adminTab==="transactions")loadAdminTransactions(true)});
    document.getElementById("adminMembersPrev")?.addEventListener("click",()=>{state.adminMembersOffset=Math.max(0,state.adminMembersOffset-state.adminPageSize);state.adminMembers=null;loadAdminMembers(true)});
    document.getElementById("adminMembersNext")?.addEventListener("click",()=>{state.adminMembersOffset+=state.adminPageSize;state.adminMembers=null;loadAdminMembers(true)});
    document.getElementById("adminTransactionsPrev")?.addEventListener("click",()=>{state.adminTransactionsOffset=Math.max(0,state.adminTransactionsOffset-state.adminPageSize);state.adminTransactions=null;loadAdminTransactions(true)});
    document.getElementById("adminTransactionsNext")?.addEventListener("click",()=>{state.adminTransactionsOffset+=state.adminPageSize;state.adminTransactions=null;loadAdminTransactions(true)});
    document.getElementById("settlementRefresh")?.addEventListener("click",()=>{state.settlementDashboard=null;loadSettlementDashboard(true,false)});
    document.getElementById("settlementRun")?.addEventListener("click",()=>loadSettlementDashboard(true,true));
    document.getElementById("modelRefresh")?.addEventListener("click",()=>{state.modelPerformance=null;state.modelSnapshots=null;loadModelPerformance(true)});
    document.getElementById("modelRange")?.addEventListener("change",()=>{state.modelPerformance=null;loadModelPerformance(true)});
    document.getElementById("modelMarket")?.addEventListener("change",()=>{state.modelPerformance=null;loadModelPerformance(true)});
    document.getElementById("modelSource")?.addEventListener("change",()=>{state.modelPerformance=null;loadModelPerformance(true)});
    document.getElementById("modelUseSuggested")?.addEventListener("click",useSuggestedModelWeights);
    document.getElementById("modelApplyWeights")?.addEventListener("click",applyModelWeights);
    document.getElementById("modelTestMarket")?.addEventListener("change",updateModelTestSide);
    document.getElementById("modelRunTest")?.addEventListener("click",runModelTestSettlement);
    document.getElementById("modelExportSnapshots")?.addEventListener("click",()=>downloadModelCsv("snapshots"));
    document.getElementById("modelExportPerformance")?.addEventListener("click",()=>downloadModelCsv("performance"));
    if(document.getElementById("modelTestDate"))document.getElementById("modelTestDate").value=taiwanToday();
    updateModelTestSide();
    document.getElementById("settlementDate")?.addEventListener("change",()=>{state.settlementDashboard=null;loadSettlementDashboard(true,false)});
    document.getElementById("adminMemberSearch")?.addEventListener("keydown",event=>{if(event.key==="Enter"){event.preventDefault();document.getElementById("adminMemberApply").click()}});
    document.getElementById("adminTransactionSearch")?.addEventListener("keydown",event=>{if(event.key==="Enter"){event.preventDefault();document.getElementById("adminTransactionApply").click()}});

    function founderDetailMessage(payload,fallback){
      const detail=payload?.detail;
      if(typeof detail==="string")return detail;
      if(detail&&typeof detail==="object"){
        return [detail.message,...(detail.blockers||[]),...(detail.warnings||[])].filter(Boolean).join("\n");
      }
      return fallback;
    }

    function renderFounderCandidates(payload){
      const status=document.getElementById("founderCandidateStatus");
      const list=document.getElementById("founderCandidates");
      if(!status||!list)return;
      status.textContent=payload.message||"候選場次已載入。";
      if(payload.locked){
        const selection=payload.selection||{};
        const confidence=Math.max(0,Math.min(100,Number(selection.confidence||0)));
        const sourceMode=String(selection.publication?.mode||"");
        const sourceLabel=sourceMode==="founder_selected"?"創辦人精選":"正式免費精選";
        const result=selection.result||{};
        const resultStatus=String(result.status||"pending");
        const resultLabels={won:"命中",lost:"未中",push:"走水",void:"作廢",pending:"等待賽果"};
        const score=result.away_score!=null&&result.home_score!=null?`終場 ${result.away_score}–${result.home_score}`:"";
        list.innerHTML=`<article class="founder-published-card">
          <div class="prediction-top"><span class="prediction-title">FOUNDER DAILY PICK</span><span class="micro-pill founder-source-chip">${escapeHtml(sourceLabel)} · 已發布鎖定</span></div>
          <div class="confidence-preview founder-published-preview">
            <div class="confidence-ring" style="background:conic-gradient(var(--green) 0 ${confidence}%,rgba(255,255,255,.05) ${confidence}%)"><div><b>${confidence.toFixed(1)}%</b><span>模型信心</span></div></div>
            <div class="matchup-preview"><h2>${escapeHtml(localizeMatchup(selection.matchup||"—"))}</h2><span>${escapeHtml(selection.time_taiwan||"")}</span><div class="pick-highlight"><small>創辦人正式推薦</small><b>${escapeHtml(localizePickLabel(selection.pick?.label||"—",selection))}</b></div></div>
          </div>
          <div class="founder-published-result"><span>發布後永久鎖定，會員端會以每日免費精選大卡片顯示。</span><b class="result ${resultClass(resultStatus)}">${escapeHtml(resultLabels[resultStatus]||"等待賽果")}${score?` · ${escapeHtml(score)}`:""}</b></div>
        </article>`;
        return;
      }
      const items=payload.items||[];
      if(!items.length){
        list.innerHTML=`<div class="founder-lock">目前沒有尚未開賽的候選場次。</div>`;
        return;
      }
      list.innerHTML=items.map(item=>{
        const notices=[
          ...(item.warnings||[]).map(message=>`<p class="founder-warning">提醒：${escapeHtml(message)}</p>`),
          ...(item.blockers||[]).map(message=>`<p class="founder-warning founder-blocker">阻擋：${escapeHtml(message)}</p>`)
        ].join("");
        const buttonText=item.can_publish?(item.requires_confirmation?"確認後指定":"指定為每日推薦"):"目前不可發布";
        return `<article class="founder-candidate ${item.can_publish?"":"blocked"}">
          <div class="founder-candidate-top"><b>${escapeHtml(localizeMatchup(item.matchup||"MLB"))}</b><span>${escapeHtml(item.time_taiwan||"時間待定")}</span></div>
          <div class="founder-tags">
            <span class="${item.event?.special?"special":""}">${escapeHtml(item.event?.label||"例行賽")}</span>
            <span>信心 ${Number(item.confidence||0).toFixed(1)}%</span>
            <span>資料完整度 ${Math.round(Number(item.data_quality||0)*100)}%</span>
            <span>${escapeHtml(localizePickLabel(item.pick?.label||"尚無推薦方向",item))}</span>
            <span>${escapeHtml(item.timing?.label||"賽前狀態待確認")}</span>
            <span>名單驗證 ${item.roster_validation?.status==="valid"?"通過":item.roster_validation?.status==="mismatch"?"不一致":"待確認"}</span>
            <span>打線驗證 ${Math.round(Number(item.lineup_validation_rate||0)*100)}%</span>
          </div>
          ${notices}
          <div class="founder-candidate-actions"><small>${escapeHtml(item.updated_at?`分析更新 ${formatAnalysisUpdatedAt(item.updated_at)} · `:"")}發布後即寫入公開紀錄，不能更換。</small><button type="button" class="btn ${item.can_publish?"primary":"ghost"} small" data-founder-publish="${Number(item.game_pk)}" ${item.can_publish?"":"disabled"}>${buttonText}</button></div>
        </article>`;
      }).join("");
      list.querySelectorAll("[data-founder-publish]").forEach(button=>button.addEventListener("click",()=>{
        const item=items.find(candidate=>Number(candidate.game_pk)===Number(button.dataset.founderPublish));
        if(item)publishFounderCandidate(item);
      }));
    }

    async function loadFounderCandidates(force=false){
      if(!isAdminMember()||state.founderCandidatesLoading)return;
      const input=document.getElementById("founderPredictionDate");
      const status=document.getElementById("founderCandidateStatus");
      const list=document.getElementById("founderCandidates");
      if(!input||!status||!list)return;
      if(!input.value)input.value=document.getElementById("scheduleDate")?.value||taiwanToday();
      const date=input.value;
      if(!force&&state.founderCandidateDate===date)return;
      state.founderCandidatesLoading=true;
      status.textContent="正在比較所有候選場次與特殊賽事類型…";
      list.replaceChildren();
      try{
        const payload=await fetchJsonWithTimeout(
          `${API_BASE}/admin/predictions/candidates?date=${encodeURIComponent(date)}`,
          20000,
          {headers:{Authorization:`Bearer ${authState.session.access_token}`}}
        );
        state.founderCandidateDate=date;
        renderFounderCandidates(payload);
      }catch(error){
        state.founderCandidateDate="";
        status.textContent=error.status===404?"找不到候選場次。":"創辦人候選場次暫時無法載入，請稍後再試。";
      }finally{
        state.founderCandidatesLoading=false;
      }
    }

    async function publishFounderCandidate(item){
      const input=document.getElementById("founderPredictionDate");
      const date=input?.value||taiwanToday();
      const warning=(item.warnings||[]).join("\n");
      const confirmation=`確定將 ${localizeMatchup(item.matchup)} · ${localizePickLabel(item.pick?.label||"此場",item)} 設為 ${date} 的正式每日推薦嗎？\n\n發布後永久鎖定，不能更換。${warning?`\n\n${warning}`:""}`;
      if(!window.confirm(confirmation))return;
      const status=document.getElementById("founderCandidateStatus");
      status.textContent="正在發布並寫入不可更換的公開紀錄…";
      try{
        const response=await fetch(`${API_BASE}/admin/predictions/publish`,{
          method:"POST",
          headers:{Authorization:`Bearer ${authState.session.access_token}`,"Content-Type":"application/json",Accept:"application/json"},
          body:JSON.stringify({date,game_pk:Number(item.game_pk),confirm_warning:Boolean(item.requires_confirmation)})
        });
        const payload=await response.json().catch(()=>({}));
        if(!response.ok)throw Object.assign(new Error(founderDetailMessage(payload,`HTTP ${response.status}`)),{status:response.status});
        showToast("創辦人指定場次已發布並鎖定");
        state.predictionDate="";
        state.founderCandidateDate="";
        await loadTopPrediction();
        await loadFounderCandidates(true);
      }catch(error){
        status.textContent=error.message||"發布失敗，請稍後再試。";
        showToast("指定場次未發布");
      }
    }

    document.getElementById("founderLoadCandidates")?.addEventListener("click",()=>loadFounderCandidates(true));
    document.getElementById("founderPredictionDate")?.addEventListener("change",()=>{
      state.founderCandidateDate="";
      loadFounderCandidates(true);
    });

    function founderMarketGroupConfig(bundle){
      const candidates=bundle?.candidates||{};
      const watchlist=bundle?.watchlist||{};
      const parlays=candidates.parlays||{};
      const limits=bundle?.limits||{};
      return [
        {key:"moneylines",title:"獨贏精選",items:asSelectionArray(candidates.moneylines),watchItems:asSelectionArray(watchlist.moneylines),max:Number(limits.moneylines||3)},
        {key:"run_lines",title:"讓分推薦",items:asSelectionArray(candidates.run_lines),watchItems:asSelectionArray(watchlist.run_lines),max:Number(limits.run_lines||3)},
        {key:"totals",title:"大小分推薦",items:asSelectionArray(candidates.totals),watchItems:asSelectionArray(watchlist.totals),max:Number(limits.totals||3)},
        {key:"two_leg",title:"二關串關",items:asSelectionArray(parlays.two_leg),watchItems:[],max:Number(limits.two_leg||2),parlay:true},
        {key:"three_leg",title:"三關串關",items:asSelectionArray(parlays.three_leg),watchItems:[],max:Number(limits.three_leg||1),parlay:true}
      ];
    }

    function founderMarketOptionCopy(item,isParlay,isWatchlist=false){
      if(isParlay){
        const picks=(item.legs||[]).map(leg=>localizePickLabel(leg.pick?.label||"—",leg)).join(" ＋ ");
        const matchups=(item.legs||[]).map(leg=>localizeMatchup(leg.matchup||"MLB")).join(" / ");
        return {
          title:picks||item.label||"串關候選",
          meta:`${matchups}${item.combined_model_probability!=null?` · 組合機率 ${item.combined_model_probability}%`:""}${item.combined_american_odds!=null?` · ${formatAmericanOdds(item.combined_american_odds)}`:""}`
        };
      }
      const reasons=asSelectionArray(item.watchlist_reasons);
      return {
        title:localizePickLabel(item.pick?.label||(isWatchlist?"觀察項目":"正式推薦"),item),
        meta:`${item.league?`[${item.league}] `:""}${localizeMatchup(item.matchup||"棒球賽事")}${item.model_probability!=null?` · 模型 ${item.model_probability}%`:""}${item.edge!=null?` · 優勢 ${Number(item.edge)>0?"+":""}${item.edge}%`:""}${item.price!=null?` · ${formatAmericanOdds(item.price)}`:""}${item.market_basis==="model_only"?" · 模型獨贏":""}${isWatchlist&&reasons.length?` · ${reasons.join("；")}`:""}`
      };
    }

    function collectFounderMarketSelections(){
      const result={moneylines:[],run_lines:[],totals:[],two_leg:[],three_leg:[]};
      document.querySelectorAll("[data-founder-market-group]:checked").forEach(input=>{
        const key=input.dataset.founderMarketGroup;
        if(result[key])result[key].push(input.dataset.candidateId||"");
      });
      return result;
    }

    function founderPromotedWatchlistCount(){
      return document.querySelectorAll('[data-founder-market-tier="watchlist"]:checked').length;
    }

    function updateFounderMarketSelectionCount(){
      const selected=collectFounderMarketSelections();
      const labels=[
        ["moneylines","獨贏"],["run_lines","讓分"],["totals","大小分"],["two_leg","二關"],["three_leg","三關"]
      ].map(([key,label])=>`${label} ${selected[key].length}`).join(" · ");
      const total=Object.values(selected).reduce((sum,items)=>sum+items.length,0);
      const promoted=founderPromotedWatchlistCount();
      const count=document.getElementById("founderMarketSelectedCount");
      const publish=document.getElementById("founderPublishMarkets");
      if(count)count.textContent=total?`已選 ${total} 個內容｜${labels}${promoted?`｜觀察升級 ${promoted}`:""}`:"尚未選擇任何玩法";
      if(publish)publish.disabled=!total||state.founderMarketsLoading;
    }

    function applyFounderAiMarkets(){
      const bundle=state.founderMarketBundle;
      if(!bundle||bundle.locked)return;
      const recommended=bundle.recommended||{};
      document.querySelectorAll("[data-founder-market-group]").forEach(input=>{
        const ids=recommended[input.dataset.founderMarketGroup]||[];
        input.checked=input.dataset.founderMarketTier!=="watchlist"&&ids.includes(input.dataset.candidateId);
      });
      updateFounderMarketSelectionCount();
      showToast("已套用全部跨聯盟正式候選");
    }

    function founderMarketOptionsHtml(group,items,tier,recommended){
      const isWatchlist=tier==="watchlist";
      if(!items.length)return "";
      const options=items.map(item=>{
        const copy=founderMarketOptionCopy(item,group.parlay,isWatchlist);
        const checked=!isWatchlist&&(recommended[group.key]||[]).includes(item.candidate_id);
        return `<label class="founder-market-option ${isWatchlist?"watchlist":""}">
          <input type="checkbox" data-founder-market-group="${group.key}" data-founder-market-tier="${tier}" data-candidate-id="${escapeHtml(item.candidate_id||"")}" ${checked?"checked":""}>
          <span><b>${escapeHtml(copy.title)}</b><small>${escapeHtml(copy.meta)}</small></span>
        </label>`;
      }).join("");
      return `<div class="founder-market-subhead ${isWatchlist?"watch":""}">${isWatchlist?"PRO 觀察名單｜勾選後會以創辦人指定發布":"正式候選"}</div><div class="founder-market-options">${options}</div>`;
    }

    function renderFounderMarketCandidates(payload){
      const status=document.getElementById("founderMarketStatus");
      const container=document.getElementById("founderMarketCandidates");
      const publish=document.getElementById("founderPublishMarkets");
      const aiButton=document.getElementById("founderUseAiMarkets");
      if(!status||!container)return;
      state.founderMarketBundle=payload;
      status.textContent=payload.message||"正式候選與創辦人觀察名單已載入。";
      if(payload.locked){
        const packageData=payload.package||{};
        const counts={
          moneylines:asSelectionArray(packageData.moneylines).length,
          run_lines:asSelectionArray(packageData.run_lines||packageData.run_line).length,
          totals:asSelectionArray(Array.isArray(packageData.totals)?packageData.totals:(packageData.total||packageData.totals)).length,
          two_leg:asSelectionArray(packageData.parlays?.two_leg).length,
          three_leg:asSelectionArray(packageData.parlays?.three_leg).length,
          watchlist:Object.values(packageData.watchlist||{}).reduce((sum,items)=>sum+asSelectionArray(items).length,0),
          founder:Number(packageData.publication?.founder_selected_count||0)
        };
        container.innerHTML=`<div class="founder-lock"><b>今日付費推薦已鎖定</b><br>獨贏 ${counts.moneylines} · 讓分 ${counts.run_lines} · 大小分 ${counts.totals} · 二關 ${counts.two_leg} · 三關 ${counts.three_leg}<br>觀察名單 ${counts.watchlist}${counts.founder?` · 創辦人指定 ${counts.founder}`:""}</div>`;
        if(publish)publish.disabled=true;
        if(aiButton)aiButton.disabled=true;
        const count=document.getElementById("founderMarketSelectedCount");
        if(count)count.textContent="已發布並永久鎖定";
        return;
      }
      if(aiButton)aiButton.disabled=false;
      const recommended=payload.recommended||{};
      const groups=founderMarketGroupConfig(payload);
      container.innerHTML=groups.map(group=>{
        const formalHtml=founderMarketOptionsHtml(group,group.items,"formal",recommended);
        const watchHtml=founderMarketOptionsHtml(group,group.watchItems,"watchlist",recommended);
        const options=formalHtml+watchHtml||`<div class="founder-lock">目前沒有符合正式或觀察標準的${escapeHtml(group.title)}候選。</div>`;
        return `<section class="founder-market-group" data-founder-market-section="${group.key}" data-max="${group.max}">
          <div class="founder-market-group-head"><b>${escapeHtml(group.title)}</b><span>${group.parlay?`最多選 ${group.max} 個 · `:"通過門檻可全選 · "}正式 ${group.items.length} · 觀察 ${group.watchItems.length}</span></div>
          ${options}
        </section>`;
      }).join("");
      container.querySelectorAll("[data-founder-market-group]").forEach(input=>input.addEventListener("change",()=>{
        const groupKey=input.dataset.founderMarketGroup;
        const max=Number(state.founderMarketBundle?.limits?.[groupKey]||0);
        const checked=container.querySelectorAll(`[data-founder-market-group="${groupKey}"]:checked`).length;
        if(max&&checked>max){
          input.checked=false;
          showToast(`此類型正式發布最多只能選 ${max} 個`);
        }else if(input.checked&&input.dataset.founderMarketTier==="watchlist"){
          showToast("此項會標記為創辦人指定，與 AI 正式推薦分開統計");
        }
        updateFounderMarketSelectionCount();
      }));
      updateFounderMarketSelectionCount();
    }


    async function loadFounderMarkets(force=false){
      if(!isAdminMember()||state.founderMarketsLoading)return;
      const input=document.getElementById("founderMarketDate");
      const status=document.getElementById("founderMarketStatus");
      const container=document.getElementById("founderMarketCandidates");
      if(!input||!status||!container)return;
      if(!input.value)input.value=document.getElementById("scheduleDate")?.value||taiwanToday();
      const date=input.value;
      if(!force&&state.founderMarketDate===date&&state.founderMarketBundle)return;
      state.founderMarketsLoading=true;
      document.getElementById("founderPublishMarkets").disabled=true;
      status.textContent="正在整合 MLB／NPB 真實盤口與官方數據模型候選…";
      container.replaceChildren();
      try{
        const payload=await fetchJsonWithTimeout(
          `${API_BASE}/admin/markets/candidates?date=${encodeURIComponent(date)}`,
          30000,
          {headers:{Authorization:`Bearer ${authState.session.access_token}`}}
        );
        state.founderMarketDate=date;
        renderFounderMarketCandidates(payload);
      }catch(error){
        state.founderMarketDate="";
        state.founderMarketBundle=null;
        status.textContent=error.message||"付費推薦候選暫時無法載入，請確認盤口 API 後重試。";
        container.innerHTML='<div class="founder-lock">目前無法建立正式會員玩法候選。</div>';
      }finally{
        state.founderMarketsLoading=false;
        updateFounderMarketSelectionCount();
      }
    }

    async function publishFounderMarkets(){
      if(!isAdminMember()||state.founderMarketsLoading)return;
      const input=document.getElementById("founderMarketDate");
      const date=input?.value||taiwanToday();
      const selected=collectFounderMarketSelections();
      const total=Object.values(selected).reduce((sum,items)=>sum+items.length,0);
      if(!total){showToast("請先選擇至少一個付費推薦");return;}
      const promoted=founderPromotedWatchlistCount();
      const summary=`獨贏 ${selected.moneylines.length}、讓分 ${selected.run_lines.length}、大小分 ${selected.totals.length}、二關 ${selected.two_leg.length}、三關 ${selected.three_leg.length}`;
      const promotedWarning=promoted?`\n\n其中 ${promoted} 項來自觀察名單，將標記為「創辦人指定」，不列入 AI 正式推薦統計。`:"";
      if(!window.confirm(`確定發布 ${date} 的付費會員推薦嗎？\n\n${summary}${promotedWarning}\n\n發布後永久鎖定，不能更換。`))return;
      const status=document.getElementById("founderMarketStatus");
      const button=document.getElementById("founderPublishMarkets");
      state.founderMarketsLoading=true;
      if(button)button.disabled=true;
      status.textContent="正在寫入付費會員正式推薦並永久鎖定…";
      try{
        const response=await fetch(`${API_BASE}/admin/markets/publish`,{
          method:"POST",
          headers:{Authorization:`Bearer ${authState.session.access_token}`,"Content-Type":"application/json",Accept:"application/json"},
          body:JSON.stringify({date,...selected})
        });
        const payload=await response.json().catch(()=>({}));
        if(!response.ok)throw new Error(founderDetailMessage(payload,`HTTP ${response.status}`));
        showToast("付費會員推薦已發布並鎖定");
        state.predictionDate="";
        state.founderMarketDate="";
        state.founderMarketBundle=null;
        await loadTopPrediction();
        await loadFounderMarkets(true);
        await loadRecords(true);
      }catch(error){
        status.textContent=error.message||"付費推薦發布失敗，請稍後再試。";
        showToast("付費推薦未發布");
      }finally{
        state.founderMarketsLoading=false;
        updateFounderMarketSelectionCount();
      }
    }

    document.getElementById("founderLoadMarkets")?.addEventListener("click",()=>loadFounderMarkets(true));
    document.getElementById("founderUseAiMarkets")?.addEventListener("click",applyFounderAiMarkets);
    document.getElementById("founderPublishMarkets")?.addEventListener("click",publishFounderMarkets);
    document.getElementById("founderMarketDate")?.addEventListener("change",()=>{
      state.founderMarketDate="";
      state.founderMarketBundle=null;
      loadFounderMarkets(true);
    });

    async function loadHomeLeagueSummary(){
      const date=document.getElementById("scheduleDate")?.value||taiwanToday();
      try{
        const payload=await fetchJsonWithTimeout(`${API_BASE}/leagues/summary?date=${encodeURIComponent(date)}`,30000);
        (payload.items||[]).forEach(item=>{
          const target=document.getElementById(`homeLeague${item.code}Count`);
          if(!target)return;
          if(item.available&&Number.isFinite(Number(item.count))){
            const details=[item.live?`進行中 ${item.live}`:null,item.final?`已結束 ${item.final}`:null].filter(Boolean).join(" · ");
            target.textContent=`今日 ${item.count} 場${details?` · ${details}`:""}`;
          }else if(item.code==="KBO"||item.code==="CPBL"){
            target.textContent="資料模組準備中";
          }else{
            target.textContent="今日資料暫時無法載入";
          }
        });
      }catch{
        ["MLB","NPB"].forEach(code=>{const target=document.getElementById(`homeLeague${code}Count`);if(target)target.textContent="今日資料暫時無法載入"});
      }
    }

    document.querySelectorAll(".home-league-card.active[data-home-league]").forEach(card=>card.addEventListener("click",()=>{
      const league=card.dataset.homeLeague;
      if(!league)return;
      state.activeLeague=league;
      state.gamesLoaded=false;
      showPage("gamesPage");
      loadLeagueGames();
    }));

    async function loadTopPrediction(){
      if(!isSignedIn()){
        renderPredictionAccess();
        return;
      }
      const date=document.getElementById("scheduleDate").value||taiwanToday();
      const accessKey=authState.role;
      if(state.predictionDate===date&&state.predictionRole===accessKey)return;
      const empty=document.getElementById("predictionEmpty");
      const preview=document.getElementById("predictionPreview");
      const title=document.getElementById("predictionEmptyTitle");
      const text=document.getElementById("predictionEmptyText");
      const apiStatus=document.getElementById("predictionApiStatus");
      empty.hidden=false;
      preview.hidden=true;
      const resultCard=document.getElementById("predictionResult");
      if(resultCard)resultCard.hidden=true;
      const sourceChip=document.getElementById("predictionSourceChip");
      const pickSourceLabel=document.getElementById("predictionPickLabel");
      if(sourceChip){sourceChip.textContent="免費會員每日一場";sourceChip.classList.remove("founder-source-chip")}
      if(pickSourceLabel)pickSourceLabel.textContent="AI 獨贏推薦";
      apiStatus.textContent="模型 API 連線中";
      apiStatus.classList.remove("demo-pill");
      title.textContent="AI 正在比較今日全部賽事";
      text.textContent="正在讀取先發投手、正式打線、牛棚負荷、天氣球場與 Statcast 進階數據。";
      try{
        const payload=await fetchJsonWithTimeout(
          `${API_BASE}/predictions/daily?date=${encodeURIComponent(date)}`,
          75000,
          {headers:{Authorization:`Bearer ${authState.session.access_token}`}}
        );
        state.predictionDate=date;
        state.predictionRole=payload.member?.role||accessKey;
        apiStatus.textContent="模型 API 已連線";
        apiStatus.classList.remove("demo-pill");
        renderProPredictions(payload);
        if(payload.moneyline){
          const selection=payload.moneyline;
          window.setDiamondMindPrediction({
            confidence:selection.confidence,
            matchup:selection.matchup,
            time:selection.time_taiwan,
            pick:selection.pick?.label||"—",
            factors:selection.factors||[],
            analysisGroups:selection.analysis_groups||{},
            engine:selection.engine||{},
            price:selection.price,
            edge:selection.edge,
            impliedProbability:selection.implied_probability,
            eventLabel:selection.publication?.event_label||selection.game?.event_label,
            founderSelected:selection.publication?.mode==="founder_selected",
            result:selection.result||null
          });
          loadRecords(true);
        }else{
          title.textContent="今日暫不發布 AI 精選";
          text.textContent=payload.message||"目前沒有場次達到最低信心門檻。";
        }
      }catch(error){
        try{
          const fallback=await fetchJsonWithTimeout(`${API_BASE}/predictions/top?date=${encodeURIComponent(date)}`,75000);
          state.predictionDate=date;
          state.predictionRole=accessKey;
          apiStatus.textContent="免費模型已連線 · 會員玩法稍後重試";
          apiStatus.classList.add("demo-pill");
          if(isProMember()){
            ["moneylines","run_lines","totals","two_leg","three_leg","watchlist"].forEach(key=>setProBodyMessage(key,"會員玩法目前暫時無法載入，請稍後重新整理。"));
          }else renderLockedProPredictions();
          if(fallback.published&&fallback.selection){
            const selection=fallback.selection;
            window.setDiamondMindPrediction({confidence:selection.confidence,matchup:selection.matchup,time:selection.time_taiwan,pick:selection.pick?.label||"—",factors:selection.factors||[],analysisGroups:selection.analysis_groups||{},engine:selection.engine||{},eventLabel:selection.publication?.event_label||selection.game?.event_label,founderSelected:selection.publication?.mode==="founder_selected",result:selection.result||null});
          }else{
            title.textContent="今日暫不發布 AI 精選";
            text.textContent=fallback.message||"目前沒有場次達到最低信心門檻。";
          }
        }catch(fallbackError){
          state.predictionDate="";
          state.predictionRole="";
          apiStatus.textContent="模型 API 暫時離線";
          apiStatus.classList.add("demo-pill");
          title.textContent="AI 服務暫時無法連線";
          text.textContent="賽事頁仍可使用 MLB 直連備援，請稍後再試。";
        }
      }
    }


    function formatAnalysisUpdatedAt(value){
      if(!value)return "更新時間未提供";
      const date=new Date(value);
      if(Number.isNaN(date.getTime()))return String(value);
      return new Intl.DateTimeFormat("zh-TW",{timeZone:"Asia/Taipei",month:"2-digit",day:"2-digit",hour:"2-digit",minute:"2-digit",hour12:false}).format(date);
    }

    function validationClass(status){
      return status==="valid"?"validation-ok":status==="mismatch"?"validation-bad":"validation-pending";
    }

    function formatEngineMetric(label,value){
      const number=Number(value);
      if(value==null||value===""||!Number.isFinite(number))return "—";
      if(/勝率|牛棚體力|可用度|近期負荷|可用性/.test(label)&&Math.abs(number)<=1.5)return `${(number*100).toFixed(1)}%`;
      if(/Hard Hit|Barrel/.test(label))return `${number.toFixed(1)}%`;
      if(/OPS|OBP|SLG|xwOBA|被打擊率/.test(label))return number.toFixed(3).replace(/^0/,"");
      if(/ERA|WHIP|K\/BB/.test(label))return number.toFixed(2);
      return Math.abs(number)>=100?number.toFixed(0):number.toFixed(2);
    }

    function engineExtraHtml(key,context){
      if(key==="starter"){
        const starters=context.starting_pitchers||{};
        const sideText=side=>{
          const pitcher=starters[side]||{};
          const stats=pitcher.stats||{};
          const name=pitcher.name&&pitcher.name!=="尚未公布"?pitcher.name:"尚未公布";
          const hand=stats.pitch_hand?` · ${stats.pitch_hand==="L"?"左投":"右投"}`:"";
          const quality=stats.data_quality!=null?` · 資料 ${Math.round(Number(stats.data_quality)*100)}%`:"";
          const validation=stats.roster_validation||{};
          const validationText=validation.status?` · 名單${validation.status==="valid"?"已驗證":validation.status==="mismatch"?"不一致":"待確認"}`:"";
          return `${name}${hand}${quality}${validationText}`;
        };
        return `<div class="engine-extra"><div><b>客隊預計先發</b><p>${escapeHtml(sideText("away"))}</p></div><div><b>主隊預計先發</b><p>${escapeHtml(sideText("home"))}</p></div></div>`;
      }
      if(key==="lineup"){
        const away=((context.lineups||{}).away||{}).official_lineup||{};
        const home=((context.lineups||{}).home||{}).official_lineup||{};
        const names=side=>(side.players||[]).map(player=>player.name).filter(Boolean).join("、");
        if(!away.players?.length&&!home.players?.length)return "";
        const validationText=value=>{const v=value.validation||{};return v.status?` · 名單${v.status==="valid"?"已驗證":v.status==="mismatch"?"不一致":"待確認"} ${Math.round(Number(v.validation_rate||0)*100)}%`:""};
        return `<div class="engine-extra"><div><b>客隊${away.confirmed?"正式":"預計核心"}打線</b><p>${escapeHtml((names(away)||"尚未公布")+validationText(away))}</p></div><div><b>主隊${home.confirmed?"正式":"預計核心"}打線</b><p>${escapeHtml((names(home)||"尚未公布")+validationText(home))}</p></div></div>`;
      }
      if(key==="bullpen"){
        const bullpen=context.bullpen||{};
        const sideHtml=(label,data={})=>{
          const recent=data.recent_3_days||{};
          const availability=data.availability||{};
          const closer=availability.closer||{};
          const workload=availability.workload_games==null?"近期場次資料不足":`近三日 ${availability.workload_games} 場 · ${recent.innings_pitched??"0.0"} 局 · ${recent.pitches??0} 球`;
          const role=availability.closer_role_confidence==="confirmed"?"角色明確":availability.closer_role_confidence==="probable"?"可能終結者":"角色未確認";
          const evidence=closer.name?` · ${closer.saves??0} SV${closer.games_finished!=null?` · ${closer.games_finished} GF`:""}`:"";
          const closerText=closer.name?`${closer.name}（${role}；${availability.closer_status||"狀態未定"}${evidence}）`:availability.closer_status||"終結者尚未辨識";
          return `<div><b>${label}</b><p>${escapeHtml(`${availability.freshness_status||"牛棚體力未確認"} · ${workload} · 終結者：${closerText}`)}</p></div>`;
        };
        return `<div class="engine-extra">${sideHtml("客隊牛棚",bullpen.away)}${sideHtml("主隊牛棚",bullpen.home)}</div>`;
      }
      if(key==="environment"){
        const environment=context.environment||{};
        const weather=environment.weather||{};
        const park=environment.park_factors||{};
        const venue=environment.venue||{};
        const temperature=weather.temperature_c!=null?`${weather.temperature_c}°C${weather.temperature_f!=null?` / ${weather.temperature_f}°F`:""}`:weather.temperature_f!=null?`${weather.temperature_f}°F`:"—";
        const parts=[
          venue.name,
          weather.available?`${weather.condition||"天氣"} ${temperature}`:null,
          weather.available?`風速 ${weather.wind_speed_mph??"—"} mph${weather.wind_direction_text?` ${weather.wind_direction_text}`:""}`:null,
          weather.time_local_label?`球場當地預報 ${weather.time_local_label}`:null,
          park.available?`得分因子 ${park.run_factor}`:null,
          environment.roof_closed?"屋頂關閉":null
        ].filter(Boolean);
        return parts.length?`<div class="engine-extra"><p>${escapeHtml(parts.join(" · "))}</p></div>`:"";
      }
      if(key==="advanced"){
        const away=((((context.lineups||{}).away||{}).official_lineup||{}).advanced)||{};
        const home=((((context.lineups||{}).home||{}).official_lineup||{}).advanced)||{};
        const basis=value=>value.basis==="official_lineup"?"正式打線":value.basis==="projected_core"?"預計核心打者":"資料未確認";
        const text=(label,value)=>{
          const sources=(value.sources||[]).map(source=>source.replaceAll("mlb_expected_statistics","MLB Expected Statistics").replaceAll("mlb_season_advanced","MLB Advanced Stats").replaceAll("savant_","Savant ").replaceAll("_"," ")).join(" + ");
          return `${label}：${basis(value)} · 覆蓋 ${value.coverage_players??value.players??0} 人${sources?` · ${sources}`:""}`;
        };
        if(!away.available&&!home.available)return "";
        return `<div class="engine-extra"><div><b>Statcast 覆蓋</b><p>${escapeHtml(text("客隊",away))}</p></div><div><b>Statcast 覆蓋</b><p>${escapeHtml(text("主隊",home))}</p></div></div>`;
      }
      return "";
    }

    function renderEngineBreakdown(groups,targetId,context={}){
      const target=document.getElementById(targetId);
      if(!target)return;
      const order=[
        ["starter","先發投手"],
        ["lineup","打線強度"],
        ["bullpen","牛棚狀態"],
        ["environment","環境條件"],
        ["advanced","進階數據"]
      ];
      const available=order.filter(([key])=>groups&&groups[key]);
      if(!available.length){
        target.innerHTML=`<div class="engine-unavailable">這筆推薦尚未保存完整引擎快照；新版本發布後的新推薦會顯示五大分析。</div>`;
        return;
      }
      const cards=available.map(([key,fallback])=>{
        const group=groups[key]||{};
        const metrics=(group.metrics||[]).filter(metric=>metric.available!==false||metric.away!=null||metric.home!=null);
        const rows=metrics.map(metric=>{
          const away=formatEngineMetric(metric.label,metric.away);
          const home=formatEngineMetric(metric.label,metric.home);
          const edge=Number(metric.edge_home);
          const awayClass=Number.isFinite(edge)&&edge<0?"better":"";
          const homeClass=Number.isFinite(edge)&&edge>0?"better":"";
          return `<div class="engine-metric"><span>${escapeHtml(metric.label||"指標")}</span><span class="${awayClass}">${away}</span><span class="${homeClass}">${home}</span></div>`;
        }).join("")||`<div class="engine-unavailable">此模組目前資料不足，權重已自動降低。</div>`;
        const quality=Math.round(Number(group.quality||0)*100);
        const meta=group.meta||{};
        const sources=(meta.sources||[]).filter(Boolean).join(" + ");
        const sourceMeta=`<div class="engine-source-meta">${meta.updated_at?`<span>最後更新 ${escapeHtml(formatAnalysisUpdatedAt(meta.updated_at))}</span>`:""}${sources?`<span>來源 ${escapeHtml(sources)}</span>`:""}${meta.roster_date?`<span>名單日期 ${escapeHtml(meta.roster_date)}</span>`:""}</div>`;
        return `<section class="engine-module"><div class="engine-module-top"><b>${escapeHtml(group.label||fallback)}</b><span class="engine-quality ${quality<60?"low":""}">完整度 ${quality}%</span></div><p class="engine-note">${escapeHtml(group.note||"依可取得資料動態評分")}</p><div class="engine-metrics"><div class="engine-metric"><span>比較指標</span><span>客隊</span><span>主隊</span></div>${rows}</div>${engineExtraHtml(key,context)}${sourceMeta}</section>`;
      }).join("");
      target.innerHTML=`<div class="engine-breakdown-head"><h3>五大完整分析引擎</h3><span>先發投手 · 打線火力 · 牛棚狀態 · 環境條件 · Statcast 進階數據</span></div><div class="engine-module-grid">${cards}</div>`;
    }

    function renderPredictionResult(result){
      const card=document.getElementById("predictionResult");
      const label=document.getElementById("predictionResultLabel");
      const score=document.getElementById("predictionResultScore");
      if(!card||!label||!score)return;
      const status=String(result?.status||"pending");
      if(status==="pending"){
        card.hidden=true;
        card.className="prediction-result";
        return;
      }
      const labels={won:"今日免費精選命中",lost:"今日免費精選未中",push:"今日免費精選走水",void:"賽事取消／推薦作廢"};
      label.textContent=labels[status]||"賽事已結算";
      if(result?.away_score!=null&&result?.home_score!=null){
        score.textContent=`終場 ${result.away_score}–${result.home_score}`;
      }else{
        score.textContent=result?.result_note||"已結算";
      }
      card.className=`prediction-result ${resultClass(status)}`;
      card.hidden=false;
    }

    window.setDiamondMindPrediction=function(prediction){
      if(!prediction)return;
      document.getElementById("predictionEmpty").hidden=true;
      document.getElementById("predictionPreview").hidden=false;
      document.getElementById("predictionConfidence").textContent=`${prediction.confidence}%`;
      document.querySelector(".confidence-ring").style.background=`conic-gradient(var(--green) 0 ${prediction.confidence}%,rgba(255,255,255,.05) ${prediction.confidence}%)`;
      document.getElementById("predictionMatchup").textContent=localizeMatchup(prediction.matchup);
      document.getElementById("predictionTime").textContent=prediction.time||"";
      document.getElementById("predictionPick").textContent=localizePickLabel(prediction.pick);
      const founderPick=Boolean(prediction.founderSelected)&&isAdminMember();
      const sourceChip=document.getElementById("predictionSourceChip");
      const pickSourceLabel=document.getElementById("predictionPickLabel");
      if(sourceChip){
        sourceChip.textContent=founderPick?"創辦人精選 · 已鎖定":"免費會員每日一場";
        sourceChip.classList.toggle("founder-source-chip",founderPick);
      }
      if(pickSourceLabel)pickSourceLabel.textContent=founderPick?"創辦人正式推薦":"AI 獨贏推薦";
      const meta=document.getElementById("predictionMarketMeta");
      meta.replaceChildren();
      [
        prediction.price!=null?`盤口 ${formatAmericanOdds(prediction.price)}`:null,
        prediction.edge!=null?`市場優勢 ${Number(prediction.edge)>0?"+":""}${prediction.edge}%`:null,
        prediction.impliedProbability!=null?`市場機率 ${prediction.impliedProbability}%`:null,
        prediction.eventLabel&&prediction.eventLabel!=="例行賽"?prediction.eventLabel:null
      ].filter(Boolean).forEach(value=>{
        const chip=document.createElement("span");
        chip.textContent=value;
        meta.append(chip);
      });
      const freeFactors=document.getElementById("predictionFactors");
      if(freeFactors)freeFactors.replaceChildren();
      const freeBreakdown=document.getElementById("predictionEngineBreakdown");
      if(freeBreakdown)freeBreakdown.replaceChildren();
      renderPredictionResult(prediction.result||null);
    };

    const authCallback=consumeAuthCallback();
    const initialHash=authCallback.handled?"more":location.hash.replace("#","");
    document.getElementById("scheduleDate").value=taiwanToday();
    if(document.getElementById("founderPredictionDate"))document.getElementById("founderPredictionDate").value=taiwanToday();
    document.getElementById("founderMarketDate").value=taiwanToday();
    renderRecords();
    renderAuthState();
    loadRecords();
    loadHomeAnnouncements(true);
    loadHomeLeagueSummary();
    if(initialHash&&pages.includes(`${initialHash}Page`))showPage(`${initialHash}Page`);
    initializeAuth(authCallback);
    