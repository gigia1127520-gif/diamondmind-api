-- DiamondMind V19.1.7
-- 必須執行一次：讓 recommendations 同時支援 MLB 數字 ID 與 NPB 文字 ID。
-- 可重複執行，不會刪除既有推薦紀錄。

begin;

-- 1) recommendations 改為多聯盟共用文字識別碼。
alter table public.recommendations
  add column if not exists league text;

update public.recommendations
set league = upper(
  coalesce(
    nullif(league, ''),
    nullif(prediction_snapshot ->> 'league', ''),
    nullif(prediction_snapshot -> 'publication' ->> 'league', ''),
    'MLB'
  )
);

update public.recommendations
set league = 'MLB'
where league not in ('MLB', 'NPB');

alter table public.recommendations
  alter column league set default 'MLB',
  alter column league set not null;

-- NPB game_pk 例如 npb_20260720_C_G，球隊 ID 也是縮寫，因此不能再用 bigint。
do $$
declare
  target_column text;
begin
  foreach target_column in array array[
    'game_pk',
    'away_team_id',
    'home_team_id',
    'pick_team_id',
    'opponent_team_id'
  ]
  loop
    if exists (
      select 1
      from information_schema.columns
      where table_schema = 'public'
        and table_name = 'recommendations'
        and column_name = target_column
        and data_type <> 'text'
    ) then
      execute format(
        'alter table public.recommendations alter column %I type text using %I::text',
        target_column,
        target_column
      );
    end if;
  end loop;
end
$$;

-- 2) 每天 MLB、NPB 各可有一筆免費推薦。
-- 移除舊版 recommendation_date 單欄唯一限制。
do $$
declare
  constraint_name text;
begin
  for constraint_name in
    select constraint_row.conname
    from pg_constraint as constraint_row
    join pg_class as table_row on table_row.oid = constraint_row.conrelid
    join pg_namespace as schema_row on schema_row.oid = table_row.relnamespace
    where schema_row.nspname = 'public'
      and table_row.relname = 'recommendations'
      and constraint_row.contype = 'u'
      and cardinality(constraint_row.conkey) = 1
      and (
        select attribute_row.attname
        from pg_attribute as attribute_row
        where attribute_row.attrelid = constraint_row.conrelid
          and attribute_row.attnum = constraint_row.conkey[1]
      ) = 'recommendation_date'
  loop
    execute format('alter table public.recommendations drop constraint %I', constraint_name);
  end loop;
end
$$;

-- 移除不是 constraint 建立的舊單欄唯一 index。
do $$
declare
  index_name text;
begin
  for index_name in
    select index_row.relname
    from pg_index as index_meta
    join pg_class as index_row on index_row.oid = index_meta.indexrelid
    join pg_class as table_row on table_row.oid = index_meta.indrelid
    join pg_namespace as schema_row on schema_row.oid = table_row.relnamespace
    where schema_row.nspname = 'public'
      and table_row.relname = 'recommendations'
      and index_meta.indisunique
      and not index_meta.indisprimary
      and index_meta.indnkeyatts = 1
      and pg_get_indexdef(index_meta.indexrelid) ~* '\(recommendation_date\)(\s+where.*)?$'
      and not exists (
        select 1
        from pg_constraint as constraint_row
        where constraint_row.conindid = index_meta.indexrelid
      )
  loop
    execute format('drop index public.%I', index_name);
  end loop;
end
$$;

alter table public.recommendations
  drop constraint if exists recommendations_league_check;

alter table public.recommendations
  add constraint recommendations_league_check
  check (league in ('MLB', 'NPB'));

-- 若同名 constraint 已存在就不重建。
do $$
begin
  if not exists (
    select 1
    from pg_constraint
    where conrelid = 'public.recommendations'::regclass
      and conname = 'recommendations_recommendation_date_league_key'
  ) then
    alter table public.recommendations
      add constraint recommendations_recommendation_date_league_key
      unique (recommendation_date, league);
  end if;
end
$$;

create index if not exists recommendations_league_date_status_idx
  on public.recommendations (league, recommendation_date desc, status);

-- 3) 模型快照也統一文字識別碼（舊環境若已執行，會安全略過）。
do $$
begin
  if to_regclass('public.model_snapshots') is not null then
    alter table public.model_snapshots
      add column if not exists league text not null default 'MLB';

    if exists (
      select 1 from information_schema.columns
      where table_schema='public' and table_name='model_snapshots'
        and column_name='game_pk' and data_type <> 'text'
    ) then
      alter table public.model_snapshots
        alter column game_pk type text using game_pk::text;
    end if;

    if exists (
      select 1 from information_schema.columns
      where table_schema='public' and table_name='model_snapshots'
        and column_name='pick_team_id' and data_type <> 'text'
    ) then
      alter table public.model_snapshots
        alter column pick_team_id type text using pick_team_id::text;
    end if;

    create index if not exists model_snapshots_league_date_idx
      on public.model_snapshots (league, recommendation_date desc);
  end if;
end
$$;

commit;

-- 要求 PostgREST 重新載入資料表結構。
notify pgrst, 'reload schema';

-- 成功時會顯示 recommendations 的欄位型別。
select column_name, data_type
from information_schema.columns
where table_schema = 'public'
  and table_name = 'recommendations'
  and column_name in (
    'league','game_pk','away_team_id','home_team_id','pick_team_id','opponent_team_id'
  )
order by column_name;
