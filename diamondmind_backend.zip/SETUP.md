# DiamondMind V17.0｜綠界付款測試與 Pro 自動開通

此版本先使用綠界 **Stage 測試環境**。測試交易不會產生真實扣款；付款成功通知驗證通過後，測試帳號會自動升級 Pro。

目前月／季／年皆為「單次固定期間」：

- 月方案：NT$399，開通 1 個月
- 季方案：NT$999，開通 3 個月
- 年方案：NT$2,999，開通 12 個月
- 不會自動續扣；到期後由會員自行續購

## 一、先執行 SQL（本版本唯一需要執行一次）

1. 登入 Supabase。
2. 開啟專案。
3. 點 **SQL Editor**。
4. 建立 New query。
5. 將 `PAYMENT_SETUP.sql` 全部貼上並按 **Run**。
6. 確認顯示成功，且 Table Editor 出現：
   - `member_subscriptions`
   - `payment_events`

## 二、Render 新增測試帳號環境變數

在 `diamondmind-api` → **Environment** 新增：

```text
ECPAY_MODE=stage
ECPAY_TEST_EMAILS=你用來測試付款的 DiamondMind 登入信箱
PUBLIC_API_BASE=https://diamondmind-api.onrender.com
FRONTEND_BASE_URL=https://gigia1127520-gif.github.io/diamondmind-web
```

`ECPAY_TEST_EMAILS` 必須與 DiamondMind 測試會員登入信箱完全相同。Stage 模式只允許此清單內的帳號建立測試付款，避免公開網站任何人用測試交易取得 Pro。

Stage 的官方測試 MerchantID／HashKey／HashIV 已在程式預設值內，不需自行新增。正式上線時必須改成你的綠界正式特店資料。

## 三、部署後端

1. 到 GitHub `diamondmind-api`。
2. 上傳 `diamondmind_backend.zip` 覆蓋原檔。
3. Commit changes。
4. 等 Render 部署完成。
5. 開啟：

```text
https://diamondmind-api.onrender.com/
```

應顯示：

```json
{"version":"17.0.1","status":"online"}
```

再開啟：

```text
https://diamondmind-api.onrender.com/api/v1/billing/config
```

應包含：

```json
{"enabled":true,"mode":"stage","live":false,"payment_model":"fixed_term"}
```

## 四、部署前端

1. 到 GitHub `diamondmind-web`。
2. 上傳 `index.html` 覆蓋原檔。
3. Commit changes。
4. 等 GitHub Pages 更新後，關閉 Safari 舊分頁再重新開啟。

## 五、測試付款

1. 用 `ECPAY_TEST_EMAILS` 裡的帳號登入 DiamondMind。
2. 到 Pro 會員方案。
3. 選月、季或年方案。
4. 勾選確認條款。
5. 按「前往綠界安全付款」。
6. Stage 測試卡可使用：

```text
卡號：4311-9522-2222-2222
安全碼：222（或任意三碼）
有效期限：填未來月份／年份
3D 驗證碼：1234
```

7. 付款完成回到 DiamondMind 後，系統會輪詢交易狀態並刷新會員權限。
8. 會員方案區應顯示 Pro 方案與有效期限，五大分析與 Pro 紀錄應解鎖。

## 六、正式收費前

正式收費需先完成綠界特店申請與信用卡收款開通，再於 Render 設定：

```text
ECPAY_MODE=production
ECPAY_MERCHANT_ID=你的正式特店編號
ECPAY_HASH_KEY=你的正式 HashKey
ECPAY_HASH_IV=你的正式 HashIV
```

正式金鑰只放 Render 後端環境變數，不能寫進 `index.html`、GitHub 或傳給會員。

## 安全機制

- 前端只向後端要求付款訂單，不取得 HashKey／HashIV。
- 後端驗證綠界 `CheckMacValue`、特店編號、交易編號與金額。
- 只有綠界 Server callback 驗證成功後才更新 Pro。
- Supabase secret/service role key只存在 Render 後端。
- 重複 callback 不會重複延長會員期限。


## V17.0.1 商品名稱編碼修正

付款 API 與綠界 ItemName 改用 ASCII 英文方案名稱，避免部分 iPhone/Safari 或付款頁顯示中文亂碼。網站前端仍顯示「月方案／季方案／年方案」。這次只需更新後端，不用重跑 SQL，也不用調整 Render 環境變數。
